import { runCommandReceipt } from '../../../scripts/orchestration/command-receipt.mjs';
import { resolve } from 'node:path';
const root=process.cwd(),out='work/orchestration/publication-recovery',browser=process.env.POPULOUS_BROWSER;
for(const [name,scenario,timeout] of [['training','scripts/local-render/training-entry.mjs',120000],['smoke','scripts/local-render/hut-smoke-secondary.mjs',120000],['response',`${out}/response-render.mjs`,120000],['early-observed',`${out}/early-observed-load.mjs`,480000]]) {
 const command=['node','scripts/local-render/harness.mjs','--game-root',root,'--browser',browser,'--port','4290','--output',`${out}/browser-${name}`,'--timeout',String(timeout),'--scenario',resolve(scenario)];
 const inputs=[`${out}/run-browser-after-early-failure.mjs`,scenario,'scripts/orchestration/command-receipt.mjs','scripts/local-render/harness.mjs','scripts/local-render/vite.config.mjs','scripts/browser-game.mjs','package-lock.json','node_modules/.package-lock.json',browser];
 const r=runCommandReceipt(root,{output:`${out}/browser-${name}-command.json`,command,inputs,env:{...process.env,PND_EXPECT_TRAINING_INTERPOLATION:'1'}});
 console.log(name,r.status,r.exitCode);if(r.status!=='passed')process.exit(1);
}
