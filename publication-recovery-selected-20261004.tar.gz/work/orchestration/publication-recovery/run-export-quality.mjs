import { runCommandReceipt } from '../../../scripts/orchestration/command-receipt.mjs';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
import { writeFileSync } from 'node:fs';
const root=process.cwd(), out='work/orchestration/publication-recovery', game=process.env.POPULOUS_GAME_ROOT, exe=process.env.POPULOUS_EXE;
const scripts=['training-interpolation','unit-interpolation','secondary-pool','hut-smoke-owner','hut-smoke-render-rng','hut-smoke-initial-phase','hut-smoke-first-visit','hut-smoke-puffs','ai-response-task','ai-producer-schedule','ai-training-capacity','mission2-rebuilding','mission3-preacher-task'];
const nativeInputs=[`${out}/run-export-quality.mjs`,'scripts/orchestration/command-receipt.mjs','package-lock.json','node_modules/.package-lock.json',exe,resolve('../prerequisites/env.sh'),...execFileSync('git',['ls-files','scripts/*.py'],{encoding:'utf8'}).trim().split('\n'),...['objects/objs0-2.dat','objects/shapes.dat','data/smoke.txt','levels/constant.dat','levels/levl2001.dat','levels/levl2002.dat','levels/levl2003.dat','levels/levl2002.hdr','levels/cpatr074.dat','levels/cpscr010.dat','levels/cpscr074.dat','levels/cpscr012.dat'].map(p=>resolve(game,p))];
const results=[];
const exp=runCommandReceipt(root,{output:`${out}/exports-with-executable.json`,command:['python','-B','scripts/decomp.py','check',exe],inputs:nativeInputs});
console.log('exports',exp.status,exp.exitCode); if(exp.status!=='passed')process.exit(1);
for(const name of ['format:check','lint','lint:standard','quality:health','quality:dupes','quality:unused']){
 const r=runCommandReceipt(root,{output:`${out}/quality-${name.replace(':','-')}.json`,command:['npm','run',name],inputs:[`${out}/run-export-quality.mjs`,'scripts/orchestration/command-receipt.mjs','package-lock.json','node_modules/.package-lock.json']});
 console.log(name,r.status,r.exitCode); results.push({name,status:r.status,exitCode:r.exitCode});
}
writeFileSync(`${out}/native-quality-index.json`,JSON.stringify(results,null,2)+'\n');
