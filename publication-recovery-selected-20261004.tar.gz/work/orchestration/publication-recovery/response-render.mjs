import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
export default async function ({ page, openMission, output, receipt, signal }) {
  await openMission(2)
  signal.throwIfAborted()
  const result = await page.evaluate(async () => {
    const s=window.testScene,w=s.world,m=await import('/app/model.ts'),{migrateCheckpoint}=await import('/app/game-store.ts'),{advanceGame}=await import('/app/game-clock.ts')
    cancelAnimationFrame(s.frame)
    const shaman=w.units.find(u=>u.team==='blue'&&u.kind==='shaman'),target=w.buildings.find(b=>b.team==='green'&&b.hp>0)
    if(!shaman||!target) throw Error('Missing authored participants')
    const commandTurn=w.turn
    m.setSelection(w,[shaman.id])
    if(!m.command(w,{x:target.x,z:target.z})) throw Error('Real movement command rejected')
    const find=()=>w.ai.tasks.find(t=>t.flags&1&&t.type===9&&t.responseScan?.entity)
    let visits=0
    while(w.turn<1000&&!find()) {advanceGame(w,s.gameClock,1/12); visits++}
    const task=find()
    if(!task||task.responseScan.entity!==shaman.id||task.phase!==3) throw Error('Native response candidate not reached in original bound')
    const detected={turn:w.turn,person:shaman.id,phase:task.phase,entity:task.responseScan.entity,flags:w.ai.flags}
    const resumed=migrateCheckpoint(structuredClone(w)), index=w.ai.tasks.indexOf(task), comparisons=[]
    let responded=false,cleaned=false
    for(let i=0;i<20;i++) {
      m.tick(w,1/12);m.tick(resumed,1/12)
      if(JSON.stringify(resumed.ai)!==JSON.stringify(w.ai)||resumed.randomState!==w.randomState) throw Error('AI/RNG checkpoint mismatch')
      comparisons.push({turn:w.turn,phase:task.phase,active:!!(task.flags&1),flags:w.ai.flags,randomState:w.randomState})
      if(task.phase===5&&task.flags&1) {responded=true;if((w.ai.flags&12)!==12||w.ai.tasks.some(t=>t.flags&1&&t.type===8)) throw Error('Incorrect response flags/scope')}
      if(!(w.ai.tasks[index].flags&1)) {cleaned=true;break}
    }
    if(!responded||!cleaned) throw Error('Response did not complete')
    const priorSpeed=w.speed;w.speed=0;s.focus(shaman);s.animate(s.previous);cancelAnimationFrame(s.frame);w.speed=priorSpeed
    const gl=s.renderer.getContext(), ext=gl.getExtension('WEBGL_debug_renderer_info')
    return {commandTurn,visits,detected,comparisons,responded,cleaned,level:w.outcome.level,status:w.status,contextLost:gl.isContextLost(),renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),method:'Public Mission2 entry; real model movement command and bounded fixed-turn diagnostic. No candidate/task/territory/outcome injection. Checkpoint AI/RNG comparison uses the ordinary tick path; rendered final scene is software-WebGL functional evidence.'}
  })
  assert.equal(result.level,2);assert.equal(result.status,'playing');assert.equal(result.contextLost,false);assert.deepEqual(receipt.errors,[])
  await page.screenshot({path:resolve(output,'response-complete.png')})
  writeFileSync(resolve(output,'response.json'),JSON.stringify(result,null,2)+'\n')
  return result
}
