import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd(); out=root/'work/orchestration/publication-recovery'
run=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
head,tree=run('rev-parse','HEAD'),run('rev-parse','HEAD^{tree}')
assert run('status','--porcelain')==''
assert run('diff','--name-only','b2368ebf64400e9ee3057300fabbe6611422d7ca','HEAD')=='scripts/local-render/early-missions.mjs'
assert (root/'scripts/local-render/early-missions.mjs').read_bytes()==(out/'early-observed-load.mjs').read_bytes()
receipts=[]
tracked=set(run('ls-files').splitlines())
for p in sorted(out.glob('*.json')):
 if not p.read_text().strip():continue
 d=json.loads(p.read_text())
 if not isinstance(d,dict):continue
 if d.get('kind')!='pnd-command-receipt':continue
 assert d.get('sourceAfter')==d['source'],p
 for k in ['stdout','stderr']:
  raw=Path(d['artifacts'][k]).read_bytes();assert hashlib.sha256(raw).hexdigest()==d[k+'Sha256'];assert raw.decode()==d[k]
 for name,h in d['source']['inputs'].items():
  if not Path(name).is_absolute() and name in tracked and name=='scripts/local-render/early-missions.mjs': data=subprocess.check_output(['git','show',d['source']['headOid']+':'+name])
  else:data=(root/name).read_bytes()
  assert hashlib.sha256(data).hexdigest()==h,(p,name)
 receipts.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':d['status'],'head':d['source']['headOid'],'exitCode':d['exitCode']})
artifacts=[]
for p in sorted(out.glob('browser-*/*')):
 if p.is_file():artifacts.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
m={'head':head,'tree':tree,'base':'7dcd89f9858600d9bd889d00a758fb78baa13f73','historicalAcceptedTree':'3342696913fc3ba1cdd9b44e7eb2a19528ba45a8','freshFullGateHead':'b2368ebf64400e9ee3057300fabbe6611422d7ca','finalDelta':['scripts/local-render/early-missions.mjs'],'equivalence':'All app, test, package, build and native inputs byte-identical to fresh full-gate head. Final maintained checker is byte-identical to the explicitly fingerprinted passed observed-load scenario; only actual Load observation changed. Historical tracked inputs checked at receipt head; ignored/external inputs checked against current retained bytes.','receipts':receipts,'renderArtifacts':artifacts,'retainedFailures':['exports.json: omitted EXE argument, no source execution','browser-early-command.json: exact stats comparison after real gameplay resumed; M2 tower completion proved by synchronous loaded0 at398 vs rendered1 at412'],'quality':'Global format/lint/standard/unused failed as disclosed;290 ESLint and1388 Oxlint diagnostics, unchanged2format paths, no added-app-line findings. Health/dupes exited0 with advisory findings.','limits':'Source-equivalent diagnostic and real-clock functional software-WebGL evidence; no original full-raster/hardware-performance or expanded AI/native allocator coverage.'}
(out/'final-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'head':head,'tree':tree,'receipts':len(receipts),'artifacts':len(artifacts),'manifestSHA':hashlib.sha256((out/'final-manifest.json').read_bytes()).hexdigest()}))
