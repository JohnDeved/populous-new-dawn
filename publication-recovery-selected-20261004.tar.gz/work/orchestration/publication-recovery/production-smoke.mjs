import assert from 'node:assert/strict'
import { chromium } from '@playwright/test'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { launchOptions } from '../../../scripts/local-render/harness.mjs'
import { bindGame } from '../../../scripts/browser-game.mjs'
const output=resolve('work/orchestration/publication-recovery/production-smoke')
mkdirSync(output,{recursive:true})
const report={url:'https://populous-new-dawn.webtorrent.workers.dev/',expectedCommit:'155e591760f5c60325bb7bf47eb8cc5f7021ab04',cloudflareVersion:'e72ccf3c-0721-4947-ab1a-373d83a7e6d7',startedAt:new Date().toISOString(),errors:[],warnings:[],method:'Fresh isolated browser context, primary public Mission1 entry, ordinary RAF and Skip Introduction. No saves/account state or simulation injection.',status:'running'}
let browser,page
const watchdog=setTimeout(()=>{report.timedOut=true;void browser?.close()},120000)
try {
 browser=await chromium.launch(launchOptions(process.env.POPULOUS_BROWSER))
 report.browser=browser.version()
 const context=await browser.newContext({viewport:{width:1440,height:1000}})
 page=await context.newPage();page.setDefaultTimeout(45000)
 page.on('pageerror',e=>report.errors.push(String(e)))
 page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text());if(m.type()==='warning')report.warnings.push(m.text())})
 const response=await page.goto(report.url,{waitUntil:'domcontentloaded'})
 report.httpStatus=response.status()
 assert.equal(report.httpStatus,200)
 const dialog=page.getByRole('dialog',{name:'Start game',exact:true})
 await dialog.waitFor()
 await dialog.getByRole('button',{name:'Select Mission 1',exact:true}).click()
 await dialog.getByRole('button',{name:'Start Mission 1',exact:true}).click()
 await bindGame(page)
 const skip=page.locator('.skip-introduction')
 await page.waitForFunction(()=>!!(window.testScene.world.flyby.flags&1)||!window.testScene.world.inputMask)
 if(await skip.isVisible())await skip.click()
 await page.waitForFunction(()=>!window.testScene.world.inputMask)
 const snap=()=>page.evaluate(()=>{const s=window.testScene,w=s.world,g=s.renderer.getContext(),d=g.getExtension('WEBGL_debug_renderer_info');return {mission:w.outcome.level,turn:w.turn,status:w.status,inputMask:w.inputMask,contextLost:g.isContextLost(),webgl:g.getParameter(g.VERSION),renderer:d?g.getParameter(d.UNMASKED_RENDERER_WEBGL):g.getParameter(g.RENDERER),canvas:[g.drawingBufferWidth,g.drawingBufferHeight],units:w.units.length}})
 report.before=await snap()
 await page.waitForFunction(t=>window.testScene.world.turn>=t+12,report.before.turn)
 report.after=await snap()
 assert.equal(report.after.mission,1);assert.equal(report.after.status,'playing');assert.equal(report.after.inputMask,0);assert.equal(report.after.contextLost,false);assert.ok(report.after.webgl.startsWith('WebGL 2.0'));assert.deepEqual(report.errors,[])
 report.assets=await page.evaluate(()=>performance.getEntriesByType('resource').map(r=>r.name).filter(x=>/\/(page|index)-[^/]+\.js/.test(x)))
 await page.screenshot({path:resolve(output,'mission1-live.png')})
 report.status='passed'
} catch(e) {
 report.status='failed';report.failure=e.stack??String(e)
 if(page)await page.screenshot({path:resolve(output,'failure.png')}).catch(()=>{})
 process.exitCode=1
} finally {
 clearTimeout(watchdog)
 if(browser)await browser.close()
 report.finishedAt=new Date().toISOString();report.ownedBrowserClosed=true
 writeFileSync(resolve(output,'result.json'),JSON.stringify(report,null,2)+'\n')
 console.log(JSON.stringify(report))
}
