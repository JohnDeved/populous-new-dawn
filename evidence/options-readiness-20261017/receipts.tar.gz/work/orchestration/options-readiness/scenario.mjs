import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { writeFileSync } from 'node:fs'
import { openCampaignFromMainMenu } from '../../../scripts/browser-new-game.mjs'
import { bindGame } from '../../../scripts/browser-game.mjs'

export default async function ({ browser, url, output }) {
  const expected = process.env.PND_OPTIONS_EXPECT ?? 'coupled'
  const cases = []
  const save = () => writeFileSync(resolve(output, 'options-readiness.json'), JSON.stringify({ expected, cases }, null, 2))
  for (const failure of ['none', 'slider-0', 'slider-1', 'slider-2', 'font-normal', 'font-highlight', 'font-low']) {
    const context = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 })
    const page = await context.newPage()
    page.setDefaultTimeout(25000)
    const errors = [], failedRequests = []
    page.on('pageerror', error => errors.push(String(error)))
    page.on('requestfailed', request => failedRequests.push({ url: request.url(), error: request.failure()?.errorText }))
    const blocked = failure.startsWith('slider-')
      ? [`options/frontend-${failure.at(-1)}.png`, `options/ingame-${failure.at(-1)}.png`]
      : failure.startsWith('font-')
        ? [`frontend/${{ 'font-normal': 'feft33we', 'font-highlight': 'fehi33we', 'font-low': 'felo33we' }[failure]}.png`, 'pause-font.png']
        : []
    await context.route('**/original/**/*.png', route => blocked.some(path => route.request().url().endsWith('/' + path)) ? route.abort('failed') : route.continue())
    await context.addInitScript(() => {
      window.optionsDecodes = []
      const decode = HTMLImageElement.prototype.decode
      HTMLImageElement.prototype.decode = function (...args) {
        const item = { src: this.src, state: 'pending' }
        window.optionsDecodes.push(item)
        return decode.apply(this, args).then(value => { item.state = 'resolved'; return value }, error => { item.state = 'rejected'; throw error })
      }
    })
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded' })
      const button = name => page.getByRole('button', { name, exact: true })
      for (const skin of failure.startsWith('font-') && failure !== 'font-normal' ? ['frontend'] : ['frontend', 'ingame']) {
        if (skin === 'ingame') {
          await button('Back').click()
          await openCampaignFromMainMenu(page)
          await button('Start Mission 1').click()
          await bindGame(page)
          const guard = page.getByRole('button', { name: 'Continue anyway', exact: false })
          if (await guard.isVisible()) await guard.click()
          await page.getByRole('button', { name: /^Skip introduction/ }).click()
          await page.waitForFunction(() => !window.testStore.getWorld().inputMask)
          await button('Game settings').click()
        }
        const before = await page.evaluate(() => window.optionsDecodes.length)
        await button('Options').click()
        await button('Sound').click()
        await page.waitForFunction(({ before, skin }) => {
          const items = window.optionsDecodes.slice(before)
          const slider = items.filter(item => item.src.includes(`/options/${skin}-`))
          const font = items.filter(item => skin === 'frontend' ? /\/(feft33we|fehi33we|felo33we)\.png$/.test(item.src) : item.src.endsWith('/pause-font.png'))
          return slider.length >= 3 && font.length >= (skin === 'frontend' ? 3 : 1) && [...slider, ...font].every(item => item.state !== 'pending')
        }, { before, skin })
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
        const options = page.locator('[data-original-options]')
        const state = await options.evaluate(root => {
          const slider = root.querySelector('input[type="range"]')
          return {
            artReady: root.dataset.artReady,
            glyphs: root.querySelectorAll('i').length,
            text: root.innerText,
            sliderAppearance: getComputedStyle(slider).appearance,
            sliderBackground: getComputedStyle(slider).backgroundImage,
            fontDecodes: window.optionsDecodes.filter(item => /\/(feft33we|fehi33we|felo33we|pause-font)\.png$/.test(item.src)),
          }
        })
        const fontExpected = expected === 'coupled' ? failure === 'none' : !failure.startsWith('font-')
        const sliderExpected = expected === 'coupled' ? failure === 'none' : !failure.startsWith('slider-')
        const entry = { failure, skin, state, blocked, status: 'observed' }
        cases.push(entry); save()
        assert.equal(state.glyphs > 0, fontExpected)
        assert.equal(state.artReady, String(sliderExpected))
        assert.equal(state.sliderBackground.includes(`/options/${skin}-0.png`), sliderExpected)
        const master = page.getByRole('slider', { name: 'Master volume', exact: true })
        await master.focus(); await page.keyboard.press('End'); assert.equal(await master.inputValue(), '1')
        await page.keyboard.press('Home'); assert.equal(await master.inputValue(), '0')
        const music = page.getByRole('slider', { name: 'Music volume', exact: true })
        await music.focus(); await page.keyboard.press('End'); assert.equal(await music.inputValue(), '1')
        await page.keyboard.press('Home'); assert.equal(await music.inputValue(), '0')
        await page.getByRole('heading', { name: 'Sound', exact: true }).focus()
        await page.mouse.move(0, 0)
        await page.screenshot({ path: resolve(output, `${skin}-${failure}.png`), style: '.world-viewport { visibility: hidden !important; }' })
        await button('Game').click()
        const rotation = options.locator('[data-option-key="rotation"]')
        const label = await rotation.getAttribute('aria-label')
        await rotation.click()
        assert.notEqual(await rotation.getAttribute('aria-label'), label)
        await button('Sound').click()
        if (skin === 'ingame') assert.equal(await page.evaluate(() => window.testStore.getWorld().paused), true)
        entry.status = 'passed'; save()
      }
      assert.deepEqual(errors, [])
      assert.ok(failedRequests.every(request => blocked.some(path => request.url.endsWith('/' + path))))
      if (blocked.length) assert.ok(failedRequests.length > 0)
    } catch (error) {
      const diagnostics = await page.evaluate(() => ({ body: document.body.innerText, inputMask: window.testStore?.getWorld().inputMask, flyby: window.testStore?.getWorld().flyby, decodes: window.optionsDecodes }))
      writeFileSync(resolve(output, `${failure}-failure.json`), JSON.stringify({ error: String(error), diagnostics }, null, 2))
      await page.screenshot({ path: resolve(output, `${failure}-failure.png`) }).catch(() => {})
      throw error
    } finally { await context.close() }
  }
  return { expected, cases, limits: ['Actual Home frontend and Mission 1 in-game Options; deliberate image request failures.', 'Screenshot comparison hides the animated world only; no scene or simulation mutation.', 'Plain Vite hosting; no native parity, deployed hosting, or hardware performance claim.'] }
}
