import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'

// Actual production Home, using the repository's reviewed local-render harness.
// No fixture component, injected game state, or original executable execution.
export default async function({page,context,url,output,receipt}) {
 const main=page.getByRole('dialog',{name:'Main menu',exact:true})
 const button=name=>main.getByRole('button',{name,exact:true})
 const panel=main.getByRole('region',{name:'Quit game',exact:true})
 await main.waitFor()
 await page.evaluate(async()=>{
  await Promise.all(['feft33we','fehi33we','felgspen'].map(name=>{const image=new Image();image.src=`/original/frontend/${name}.png`;return image.decode()}))
 })
 const baseline=[]
 const initialUrl=page.url()
 const initialHistory=await page.evaluate(()=>history.length)
 for(const [width,height] of [[640,480],[1280,960],[1920,1080],[3440,1440],[900,360]]) {
  await page.setViewportSize({width,height})
  await button('Quit').focus()
  await page.keyboard.press('Enter')
  await panel.waitFor()
  assert.equal(await main.getByRole('heading',{name:'Quit Game',exact:true}).count(),1)
  assert.equal(await main.getByRole('button',{name:'Yes',exact:true}).count(),0)
  assert.equal(await page.locator('.world-viewport canvas').count(),0)
  const observed=await panel.evaluate(el=>{const s=getComputedStyle(el);return {text:el.innerText,font:s.font,border:s.border,background:s.backgroundColor,bounds:el.getBoundingClientRect().toJSON(),active:document.activeElement?.textContent}})
  baseline.push({width,height,dpr:await page.evaluate(()=>devicePixelRatio),...observed})
  await page.screenshot({path:resolve(output,`quit-before-${width}x${height}.png`)})
  await button('Back').click()
  assert.equal(await button('Quit').evaluate(el=>el===document.activeElement),true)
 }
 await page.setViewportSize({width:1920,height:1080})
 const cdp=await context.newCDPSession(page)
 await cdp.send('Emulation.setDeviceMetricsOverride',{width:1920,height:1080,deviceScaleFactor:2,mobile:false})
 await button('Quit').focus();await page.keyboard.press('Enter');await panel.waitFor()
 assert.equal(await page.evaluate(()=>devicePixelRatio),2)
 const shot=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false})
 const png=Buffer.from(shot.data,'base64')
 assert.equal(png.readUInt32BE(16),3840);assert.equal(png.readUInt32BE(20),2160)
 writeFileSync(resolve(output,'quit-before-1920x1080-dpr2.png'),png)
 await cdp.send('Emulation.clearDeviceMetricsOverride');await cdp.detach()
 await page.keyboard.press('Escape')
 assert.equal(await button('Quit').evaluate(el=>el===document.activeElement),true)
 assert.equal(page.url(),initialUrl)
 assert.equal(await page.evaluate(()=>history.length),initialHistory)
 assert.equal(await page.locator('.world-viewport canvas').count(),0)
 writeFileSync(resolve(output,'baseline-observations.json'),JSON.stringify(baseline,null,2)+'\n')
 assert.deepEqual(receipt.errors,[])
 return {baseline,checks:['actual Home startup to Quit','baseline native/wide/odd/DPR2 captures','Back and Escape restore Quit focus','no navigation or world creation'],limits:['Baseline only, not new behavior acceptance','Software headless browser; no native screenshot or hardware performance claim']}
}
