import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'

// Affected-only actual Home replay for the one-line disabled-button opacity repair.
// Full pre-repair functional coverage is retained separately, never relabeled.
export default async function({page,context,browser,url,output,receipt}) {
 const checks=[]
 const main=()=>page.getByRole('dialog',{name:'Main menu',exact:true})
 const button=name=>main().getByRole('button',{name,exact:true})
 const quit=()=>page.locator('[data-original-quit-menu]')
 const settle=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))))
 const save=()=>writeFileSync(resolve(output,'progress.json'),JSON.stringify(checks,null,2)+'\n')
 const open=async()=>{await button('Quit').focus();await page.keyboard.press('Enter');await quit().waitFor();await page.waitForFunction(()=>document.activeElement?.matches('[data-original-quit-menu] [data-panel-back]'));await settle()}
 const assertMain=async()=>{await button('Quit').waitFor();assert.equal(await main().evaluate(el=>el.open),true);assert.equal(await button('Quit').evaluate(el=>el===document.activeElement),true)}
 const inspect=()=>quit().evaluate(el=>({viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},buttons:[...el.querySelectorAll('button')].map(b=>{const span=b.querySelector('span');return{label:b.getAttribute('aria-label'),disabled:b.disabled,ariaDisabled:b.getAttribute('aria-disabled'),buttonOpacity:getComputedStyle(b).opacity,labelOpacity:getComputedStyle(span).opacity,bounds:b.getBoundingClientRect().toJSON(),font:b.querySelector('i')?.style.backgroundImage??'fallback'}}),guidance:el.querySelector('p').innerText}))
 const check=async label=>{const value=await inspect(),yes=value.buttons[0];assert.equal(yes.label,'Yes');assert.equal(yes.disabled,true);assert.equal(yes.ariaDisabled,'true');assert.equal(yes.buttonOpacity,'1');assert.equal(yes.labelOpacity,'0.5');assert.equal(Number(yes.buttonOpacity)*Number(yes.labelOpacity),.5);for(const b of value.buttons){assert.ok(b.bounds.y>=0);assert.ok(b.bounds.y+b.bounds.height<=value.viewport.height+.01)}assert.match(value.guidance,/Yes is unavailable in this browser\. Close this browser tab to quit\. Only checkpoints successfully saved to browser storage/);checks.push({label,value});save()}
 await main().waitFor();await page.waitForFunction(()=>document.querySelector('[data-original-main-menu] nav button i'))
 for(const [width,height]of [[640,480],[1920,1080],[900,360]]){
  await page.setViewportSize({width,height});await open();await page.waitForFunction(()=>document.querySelector('#frontend-quit-question i')?.style.backgroundImage.includes('felo33we'));await check(`${width}x${height}`);await page.screenshot({path:resolve(output,`quit-after-${width}x${height}.png`)});await page.keyboard.press('Escape');await assertMain()
 }
 await page.setViewportSize({width:1920,height:1080});const cdp=await context.newCDPSession(page)
 await cdp.send('Emulation.setDeviceMetricsOverride',{width:1920,height:1080,deviceScaleFactor:2,mobile:false});await open();await check('actual DPR2');assert.equal(await page.evaluate(()=>devicePixelRatio),2)
 const shot=await cdp.send('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false}),png=Buffer.from(shot.data,'base64');assert.equal(png.readUInt32BE(16),3840);assert.equal(png.readUInt32BE(20),2160);writeFileSync(resolve(output,'quit-after-1920x1080-dpr2.png'),png);await cdp.send('Emulation.clearDeviceMetricsOverride');await cdp.detach()
 const before=await page.evaluate(()=>({url:location.href,history:history.length,storage:Object.fromEntries(Object.entries(localStorage))})),yes=button('Yes'),box=await yes.boundingBox()
 await page.mouse.click(box.x+box.width/2,box.y+box.height/2)
 await yes.evaluate(el=>{el.click();el.dispatchEvent(new MouseEvent('click',{bubbles:true}));for(const [key,code]of [['Enter','Enter'],[' ','Space']])for(const type of ['keydown','keyup'])el.dispatchEvent(new KeyboardEvent(type,{key,code,bubbles:true}));el.focus()})
 assert.equal(await yes.evaluate(el=>el===document.activeElement),false);await quit().waitFor();assert.deepEqual(await page.evaluate(()=>({url:location.href,history:history.length,storage:Object.fromEntries(Object.entries(localStorage))})),before)
 await button('Back').focus();await page.keyboard.press('Shift+Tab');assert.equal(await button('No').evaluate(el=>el===document.activeElement),true);await page.keyboard.press('Tab');assert.equal(await button('Back').evaluate(el=>el===document.activeElement),true);await page.keyboard.press('Space');await assertMain();checks.push({label:'disabled Yes inert under pointer, DOM click, Enter and Space; actual Tab skips disabled Yes',value:true});save()
 for(let i=0;i<3;i++){await open();await page.keyboard.press('Escape');await assertMain()}
 await context.close()
 for(const file of ['feft33we.png','fehi33we.png']){
  context=await browser.newContext({viewport:{width:640,height:480}});page=await context.newPage();page.setDefaultTimeout(25000);let aborted=0;page.on('pageerror',error=>receipt.errors.push(String(error)))
  await page.route(`**/original/frontend/${file}`,route=>{aborted++;return route.abort('failed')});await page.goto(url,{waitUntil:'networkidle'});await main().waitFor();await open();assert.ok(aborted>0)
  for(const [width,height]of [[640,480],[900,360]]){
   await page.setViewportSize({width,height});await settle();await check(`fallback ${file} ${width}x${height}`);assert.equal((await inspect()).buttons[0].font,'fallback');assert.equal(await button('Yes').innerText(),'Yes');await page.screenshot({path:resolve(output,`quit-fallback-${file.replace('.','-')}-${width}x${height}.png`)})
  }
  await page.keyboard.press('Enter');await assertMain();await context.close()
 }
 assert.deepEqual(receipt.errors,[])
 return {checks,limits:['Affected-only replay for sole one-line CSS opacity change from a336fa0d to38c37e9d; full a336fa0d functional suite remains separately source-bound','Actual unchanged production Home via plain React/Vite; no Vinext/Cloudflare/RSC hosting or original-native screenshot equivalence','Unavailable Yes remains a browser adaptation; no close-tab or native-exit handler is introduced']}
}
