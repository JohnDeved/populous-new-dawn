import assert from 'node:assert/strict'
import {resolve}from'node:path'
import {writeFileSync}from'node:fs'
export default async function({page,output}){
 const main=page.getByRole('dialog',{name:'Main menu',exact:true}),button=n=>main.getByRole('button',{name:n,exact:true}),quit=page.locator('[data-original-quit-menu]'),events=[]
 const save=async label=>{events.push({label,...await page.evaluate(()=>({active:document.activeElement?.outerHTML,quit:!!document.querySelector('[data-original-quit-menu]'),text:document.querySelector('[data-original-main-menu]')?.innerText,dialogOpen:document.querySelector('[data-original-main-menu]')?.open}))});writeFileSync(resolve(output,'events.json'),JSON.stringify(events,null,2)+'\n')}
 await main.waitFor();await page.setViewportSize({width:640,height:480})
 for(const method of ['pointer No','keyboard No','keyboard Back','Escape','Escape']){
  await button('Quit').focus();await page.keyboard.press('Enter');await quit.waitFor();await page.waitForTimeout(100);await save('open before '+method)
  if(method==='pointer No')await button('No').click()
  else if(method==='keyboard No'){await button('No').focus();await page.keyboard.press('Enter')}
  else if(method==='keyboard Back')await page.keyboard.press('Enter')
  else await page.keyboard.press('Escape')
  await page.waitForTimeout(100);await save('after '+method)
  if(await quit.count()){await page.screenshot({path:resolve(output,'failed-'+method.replaceAll(' ','-')+'.png')});throw Error('Quit still open after '+method)}
  await button('Quit').waitFor()
 }
 return events
}
