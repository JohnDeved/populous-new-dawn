# Actual Home baseline and candidate check plan

Base0d2ad770ed03f6d049b01bd71176f954a6e4e044. Initial candidate760e83e81d757127727be4797fce8618ba296d54; a46b6f011a9121f7a66f97ba1747b8cf2170efad adds only decomp/README.md and engineering/project-map.json. Git diff confirms app/public/package inputs identical between these two candidate commits. Browser receipts retain the actual immutable source760e83e; source equivalence is additional evidence, not relabeling.

## Actual Home browser setup

- Exact app/package source materialized by git archive into baseline-source-0d2ad770 and final-source-760e83e. No installed dependencies copied or installed. Public assets and installed dependencies consumed read-only.
- Plain React/Vite entry imports the unmodified production page.tsx and globals.css. It uses the real Home state, store, menus, event handlers and resource requests. No fake DOM, substitute Quit component, injected world or scene.
- This test excludes only Vinext/Cloudflare/RSC hosting/hydration. It is local frontend integration evidence, not a deployment or original-native screenshot claim.
- Optimizer writes go under each fixture/work/node_modules/.vite. Runner fingerprints shared dependency file metadata before/after and fails if changed. Full app/public hashes are verified before/after. Each run has a fresh output and terminal receipt with explicit cleanup.
- Actual installed Chrome Headless Shell via sandboxed remote-debugging-pipe. No unsafe launch flags. Actual browser executable hash/version retained in each receipt.
- Port4187 exclusively owned during these runs; no unknown process was killed. Both fixtures and scripts are task-owned in this directory. Space budget checked before each source copy; no dependency copy, cleanup or install performed here.

## Commands used/prepared

Baseline:
PATH=/tmp/selector-scene457/git-bin:$PATH taskset -c 0,1 node /tmp/quit-ui-scope/run-home-scenario.mjs /tmp/quit-ui-scope/baseline-fixture-0d2ad770 /tmp/quit-ui-scope/baseline-home-0d2ad770 /tmp/quit-ui-scope/capture-home-baseline.mjs 4187

Final:
PATH=/tmp/selector-scene457/git-bin:$PATH taskset -c 0,1 node /tmp/quit-ui-scope/run-home-scenario.mjs /tmp/quit-ui-scope/final-fixture-760e83e <fresh-output> /tmp/quit-ui-scope/capture-home-final.mjs 4187

Independent repeat diagnostic:
PATH=/tmp/selector-scene457/git-bin:$PATH taskset -c 0,1 node /tmp/quit-ui-scope/run-home-scenario.mjs /tmp/quit-ui-scope/final-fixture-760e83e /tmp/quit-ui-scope/diagnose-cancel-760e83e /tmp/quit-ui-scope/diagnose-repeated-cancel.mjs 4187

## Per-run status

- baseline-home-0d2ad770: PASSED exit0. Six actual Home screenshots:640×480,1280×960,1920×1080,3440×1440,900×360,true1920×1080/DPR2. Back/Escape restored focus, no world construction/navigation. Source identical, installed dependencies unchanged, cleanup verified.
- final-home-760e83e: FAILED exit1. Initial visual/geometry/DPR2/disabledYes/Tab/SpaceBack groups passed; later repeat-cancel root wait timed out. No complete acceptance from this receipt. Source and dependencies unchanged, cleanup verified. Exact attempted script retained as capture-home-final-attempt1.mjs.
- diagnose-cancel-760e83e: PASSED exit0. PointerNo, keyboardNo, keyboardBack, Escape, repeatedEscape each returned to root with Quit focused. Events log records actual DOM and focus. Same source, dependencies unchanged, cleanup verified. This does not erase prior failure.
- final-home-760e83e-attempt2: FAILED exit1 at the second repeated Escape after pointer No, keyboard No, keyboard Back and first Escape passed. Semantic Back-autofocus waiting did not resolve it. Source/dependencies unchanged and cleanup verified. Exact attempted scenario retained as capture-home-final-attempt2.mjs.
- diagnose-escape-760e83e: FAILED exit1. Five rapid cycles were attempted; the third Escape returned React state to main but native dialog.open became false, making the root menu hidden. Actual keydown/cancel events and DOM state are retained. This establishes a real repeated-native-dismissal bug, rather than only an autofocus/harness assumption.
- Writer repaired dialog Escape keydown to prevent default and invoke the same existing back handler, retaining onCancel fallback. App commit32f36084c185d4bb4536725dfd9d30bf28f6e7e2; test-only follow-up a336fa0d10263c889ce7333bce47420a988aeb7f. Exact current app/package snapshot retained as final-source-a336fa0d with its own final-fixture-a336fa0d. No earlier receipt was relabeled.
- diagnose-escape-a336fa0d: PASSED exit0. Twelve rapid Quit→Escape cycles kept the actual native dialog open and restored Quit focus; three nested Browser-help Escape cycles stayed in Options and restored help-link focus; following Escape returned root with Options focus. Source/dependencies unchanged, cleanup verified. No duplicate screenshot sweep.
- final-home-a336fa0d: PASSED exit0. Nineteen progress records cover six display/DPR states, disabled Yes, No/Back/Escape/reentry, unchanged navigation/storage/world state, glow/highlight, Options return, four real asset failures, reduced motion and a real-store failed-persistence case (persisted=false, available=true, two blocked IndexedDB opens). Fifteen screenshots. Source/dependencies unchanged, cleanup verified. Exact executed scenario preserved as capture-home-final-a336fa0d.mjs.
- Integrated visual review then found global disabled-button opacity0.4 multiplied by menu-label opacity0.5, making unavailable Yes excessively faint. Writer added the sole scoped CSS line `.quit .rows button:disabled { opacity: 1; }` in38c37e9d569b84b6b663b5e8e3b3eed77365c57b. No other app/public/package input changed froma336fa0d.
- final-source-38c37e9d hardlinks only the prior immutable snapshot; the changed CSS was atomically replaced with a distinct inode, verified. No mutable checkout files were hardlinked or modified.
- final-opacity-38c37e9d: FAILED exit1 before scenario execution due to an extra parenthesis in the new affected-only harness. Exact failed script retained as capture-opacity-repair-attempt1.mjs. This was a harness parse failure, not an application failure; cleanup/source/dependency checks passed.
- final-opacity-38c37e9d-attempt2: PASSED exit0 after syntax-checking the corrected harness. Native640×480, wide1920×1080, odd900×360, actual1920×1080/DPR2, normal/highlight atlas fallback at480/360. Eight screenshots. Computed disabled button opacity1 × label0.5, Yes pointer/DOM click/synthetic Enter and Space inert, actual Tab skip, repeated Escape and fallback Back cancellation. Source/dependencies unchanged, cleanup verified.
- Console qualification: no captured JavaScript/page errors. Initial normal context console errors were captured and empty; fresh failed-asset contexts collect pageerror only, so this is not a universal console-clean claim. Expected request-failure diagnostics are not application exceptions.
- Updated full scenario adds the computed opacity assertions and synthetic Space. It is ready for sole-writer promotion, but its updated whole-file hash was not run as an entire suite: existing functional assertions passed ona336fa0d, and the new assertions passed in the affected-only38c37e9d run. This source-transition attribution must remain explicit.

## Additional required gates, owned by writer/parent

- `npm run orchestration:plan -- --base 0d2ad770ed03f6d049b01bd71176f954a6e4e044` against actual candidate; inspect path mappings and command side effects. New proof/scenario paths require explicit review rather than ignoring unmapped paths.
- Focused frontend composition/menu1 tests and static SHA-locked menu read. Evidence for each scenario/test remains source-bound.
- `npm run check`, `npm run build`, `npm run format:check`, `npm run lint`, `npm run lint:standard`; report existing unrelated findings honestly and retain scoped attribution if broader gates fail.
- `npm run quality:health`, `npm run quality:dupes`, `npm run quality:unused` are advisory; retain findings or execution failures rather than marking them passes.
- Dedicated new Quit scenario covers ordinary pointer/keyboard cancel, repetition, disabledYes, geometry/font, original shadows/glow/input-mode ownership, display/DPR2, missing assets, reduced motion, Options return and truthful persistence copy. Real failed-storage setup calls the actual observed store.saveCheckpoint API, explicitly supplemental rather than shipped Save UI acceptance.
- Full original-main-menu.mjs includes Tutorial WebGL after its frontend path and must remain separately labeled if not run for this frontend-only change. Its old literal Quit-copy assertion was updated by the writer.
- Final reviewer validates full source diff, promoted scenario, proof packet, source equivalence and terminal raw evidence. Later source changes require affected checks again.
