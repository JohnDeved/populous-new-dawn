import {readFileSync,writeFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const expected='927fd7cbaa757c45a2f629700757e5d72e3c96f4'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex')
const manifest='/tmp/quit-menu457/test-inventory-'+expected+'.json'
const inventory=JSON.parse(readFileSync(manifest))
assert.equal(git('rev-parse','HEAD'),expected);assert.equal(git('status','--porcelain'),'')
assert.deepEqual(git('ls-files','tests/*.test.mjs').split('\n').sort(),Object.keys(inventory.files))
for(const [file,want]of Object.entries(inventory.files))assert.equal(hash(root+'/'+file),want)
const first=JSON.parse(readFileSync(root+'/work/orchestration/quit-menu457/927fd7cb/inventory-01.json'))
assert.equal(first.status,'invalidated');assert.equal(first.exitCode,0)
const output='work/orchestration/quit-menu457/927fd7cb/inventory-01-recovery1.json'
assert.equal(existsSync(root+'/'+output),false,'A recovery receipt must be fresh')
const result=runCommandReceipt(root,{output,command:['node','--test','--test-concurrency=1',...inventory.batches[0]],inputs:[manifest,import.meta.filename,'/tmp/quit-menu457/run-final-inventory-loaded.mjs','/tmp/quit-menu457/run-final-inventory-on-disk.mjs','/tmp/quit-menu457/runner-modification-provenance.json','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
assert.equal(result.status,'passed');assert.equal(hash(result.artifacts.stdout),result.stdoutSha256)
const text=readFileSync(result.artifacts.stdout,'utf8')
const count=label=>{const found=[...text.matchAll(new RegExp(`^(?:#|ℹ) ${label} (\\d+)\\s*$`,'gm'))];assert.ok(found.length);return Number(found.at(-1)[1])}
const counts=Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(label=>[label,count(label)]))
assert.equal(counts.tests,61);assert.equal(counts.pass,61);assert.equal(counts.fail+counts.cancelled+counts.skipped+counts.todo,0)
writeFileSync('/tmp/quit-menu457/batch1-recovery-summary.json',JSON.stringify({head:expected,output,files:inventory.batches[0],counts,status:result.status,excludedAttempt:'work/orchestration/quit-menu457/927fd7cb/inventory-01.json',reason:'Original receipt invalidated by an external runner-file change during execution; distinct frozen runner replays the exact ten-file batch. No prior passing test result is relabeled.'},null,2)+'\n')
console.log(JSON.stringify({output,status:result.status,counts}))
