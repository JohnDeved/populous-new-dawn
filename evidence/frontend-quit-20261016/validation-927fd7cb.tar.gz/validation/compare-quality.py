from pathlib import Path
import argparse,collections,datetime,difflib,hashlib,json,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--head',required=True);a=p.parse_args()
repo=Path('/tmp/populous-selector-scene-457');g='/tmp/selector-scene457/git-bin/git';head=a.head;baseline='adb0f10a1142cb9135192da63af756b43dbc035e'
b=repo/'work/orchestration/loading-recovery457'/baseline[:8];c=repo/'work/orchestration/quit-menu457'/head[:8]
def sha_bytes(x):return hashlib.sha256(x).hexdigest()
def sha(x):return sha_bytes(Path(x).read_bytes())
def git(*args):return subprocess.check_output([g,*args],cwd=repo,text=True).strip()
errors=[]
def read_receipt(path):
 d=json.loads(path.read_text());checks=[]
 if d.get('phase')!='finished':return {'path':str(path),'pending':True,'phase':d.get('phase')}
 for stream in ['stdout','stderr']:
  p=Path(d['artifacts'][stream]);raw=p.read_bytes()
  if sha_bytes(raw)!=d.get(stream+'Sha256') or raw.decode()!=d.get(stream):checks.append(stream+' raw mismatch')
 if d.get('source')!=d.get('sourceAfter'):checks.append('source/input fingerprint differs after run')
 if d.get('source',{}).get('trackedDiffSha256')!=sha_bytes(b''):checks.append('tested tracked diff was not empty')
 errors.extend(str(path)+': '+x for x in checks)
 return {'path':str(path),'receiptSha256':sha(path),'source':d.get('source'),'command':d.get('command'),'status':d.get('status'),'exitCode':d.get('exitCode'),'signal':d.get('signal'),'rawLogChecks':checks,'stdout':d.get('stdout',''),'stderr':d.get('stderr','')}
def eslint(s):
 result=[];path=None;lines=s.splitlines();i=0
 while i<len(lines):
  line=lines[i]
  if line.startswith(str(repo)+'/') and not re.search(r':\d+:\d+$',line):path=line[len(str(repo))+1:]
  m=re.match(r'^\s+(\d+):(\d+)\s+(error|warning)\s+(.+)$',line)
  if m:
   body=[m[4]];j=i+1
   while j<len(lines) and not re.match(r'^\s+\d+:\d+\s+(?:error|warning)\s+',lines[j]) and not (lines[j].startswith(str(repo)+'/') and not re.search(r':\d+:\d+$',lines[j])) and not lines[j].startswith('✖'):
    body.append(lines[j]);j+=1
   tail='\n'.join(body).rstrip();rule=tail.split()[-1]
   first=re.sub(r'\s+'+re.escape(rule)+r'\s*$','',m[4]).rstrip()
   # Rule/message are semantic identity. Full raw block is retained for source-frame inspection.
   result.append({'file':path,'line':int(m[1]),'column':int(m[2]),'severity':m[3],'rule':rule,'message':first,'rawBlock':'\n'.join(body).rstrip()});i=j-1
  i+=1
 return result
def oxlint(s):
 result=[]
 for l in s.splitlines():
  m=re.match(r'^(app/[^:]+):(\d+):(\d+): (warning|error) ([^:]+): (.*)$',l)
  if m:result.append({'file':m[1],'line':int(m[2]),'column':int(m[3]),'severity':m[4],'rule':m[5],'message':m[6]})
 return result
def key(x):return json.dumps({k:v for k,v in x.items() if k not in ['line','column','rawBlock']},sort_keys=True)
def delta(x,y):
 a=collections.Counter(map(key,x));b=collections.Counter(map(key,y))
 return {'baselineCount':len(x),'candidateCount':len(y),'added':[{'count':n,**json.loads(k)} for k,n in (b-a).items()],'removed':[{'count':n,**json.loads(k)} for k,n in (a-b).items()],'baselineSeverity':dict(collections.Counter(d['severity'] for d in x)),'candidateSeverity':dict(collections.Counter(d['severity'] for d in y))}
def normalized_locations(s):
 s=re.sub(r'(?P<p>(?:app|tests|scripts|qa|references|evidence)/[^\s():]+):\d+(?::\d+)?(?:-\d+)?',r'\g<p>:LOCATION',s)
 s=re.sub(r'(?m)^(\s+):\d+ ',r'\1:LOCATION ',s)
 return s
result={'kind':'quality-baseline-attribution','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scriptSha256':sha(__file__),'head':head,'baselineReceiptSource':git('rev-parse',baseline),'canonicalBase':git('rev-parse','0d2ad770ed03f6d049b01bd71176f954a6e4e044'),'baselineToCanonicalChangedFiles':git('diff','--name-only',baseline,'0d2ad770ed03f6d049b01bd71176f954a6e4e044').splitlines(),'candidateChanges':git('diff','--name-only','0d2ad770ed03f6d049b01bd71176f954a6e4e044',head).splitlines(),'currentHead':git('rev-parse','HEAD'),'currentStatus':git('status','--porcelain'),'gates':{},'errors':errors,'limits':['No tests, quality tools, build, browser, package or source changes performed. This only parses retained receipt/raw logs.','ESLint/oxlint comparison ignores location changes but preserves file, severity, rule, message and duplicate count. Full raw ESLint blocks are retained for context inspection.','Fallow human output is truncated. Displayed findings and summary deltas cannot prove identity of undisplayed diagnostics. Churn/LOC/threshold/clone counts are not normalized away.','Baseline and candidate quality commands use npm directly. Package/config/source identity and explicit input hashes are independently checked; changed source diagnostics remain visible.']}
for name in ['format','eslint','oxlint','health','dupes','unused']:
 bp=b/(name+'.json');cp=c/(name+'.json');br=read_receipt(bp);cr=read_receipt(cp) if cp.exists() else {'path':str(cp),'pending':True,'reason':'receipt absent'}
 row={'baseline':br,'candidate':cr};result['gates'][name]=row
 if cr.get('pending'):continue
 bi=br['source'].get('inputs',{});ci=cr['source'].get('inputs',{});shared=set(bi)&set(ci)
 row['sharedInputAlignment']={f:{'baseline':bi[f],'candidate':ci[f],'equal':bi[f]==ci[f]} for f in sorted(shared)}
 if any(bi[f]!=ci[f] for f in shared):errors.append(name+' shared input hash differs')
 for f,want in ci.items():
  path=Path(f) if Path(f).is_absolute() else repo/f
  if sha(path)!=want:errors.append(name+' candidate explicit input changed: '+f)
 for r,label in [(br,'baseline'),(cr,'candidate')]:
  expected=git('rev-parse',baseline) if label=='baseline' else head
  if r['source'].get('headOid')!=expected:errors.append(name+' '+label+' source HEAD mismatch')
 if name in ['eslint','oxlint']:
  parser=eslint if name=='eslint' else oxlint;bd=parser(br['stdout']);cd=parser(cr['stdout']);row['diagnostics']={'baseline':bd,'candidate':cd};row['comparison']=delta(bd,cd)
 elif name=='format':
  extract=lambda s:re.findall(r'^(app/\S+) \(\d+ms\)$',s,re.M)
  bf=extract(br['stdout']);cf=extract(cr['stdout']);row['comparison']={'baselineFiles':bf,'candidateFiles':cf,'addedFiles':sorted(set(cf)-set(bf)),'removedFiles':sorted(set(bf)-set(cf))}
 else:
  row['summaryLines']={label:[l for l in r['stdout'].splitlines()+r['stderr'].splitlines() if l.startswith(('■ Metrics:','● ','✗ ')) or 'analyzed (' in l] for label,r in [('baseline',br),('candidate',cr)]}
  row['locationNormalizedStdoutDiff']=list(difflib.unified_diff(normalized_locations(br['stdout']).splitlines(),normalized_locations(cr['stdout']).splitlines(),fromfile='baseline',tofile='candidate',lineterm=''))
result['inputTreeEquivalence']={f:{'baseline':git('rev-parse',baseline+':'+f),'canonical':git('rev-parse','0d2ad770ed03f6d049b01bd71176f954a6e4e044:'+f)} for f in ['app','public','tests','scripts','engineering','package.json','package-lock.json','eslint.config.mjs','tsconfig.json','.fallowrc.json','.oxfmtrc.json','.oxlintrc.json','vite.config.ts','next.config.ts']}
for f,x in result['inputTreeEquivalence'].items():
 if x['baseline']!=x['canonical']:errors.append('Baseline/canonical tree mismatch: '+f)
# Check the entire tracked code universe, including references/qa/evidence fixtures,
# rather than assuming Fallow only reads app/ or its configured entry points.
def tracked_code(revision):
 entries={}
 suffixes={'.js','.jsx','.mjs','.cjs','.ts','.tsx','.mts','.cts','.vue','.svelte','.astro','.css','.html'}
 for line in git('ls-tree','-r',revision).splitlines():
  meta,path=line.split('\t',1)
  if Path(path).suffix in suffixes:entries[path]=meta.split()[2]
 return entries
base_code=tracked_code(baseline);canonical_code=tracked_code(result['canonicalBase'])
code_changes={path:{'baseline':base_code.get(path),'canonical':canonical_code.get(path)} for path in sorted(set(base_code)|set(canonical_code)) if base_code.get(path)!=canonical_code.get(path)}
result['fullTrackedCodeInputEquivalence']={'extensions':['js','jsx','mjs','cjs','ts','tsx','mts','cts','vue','svelte','astro','css','html'],'baselineCount':len(base_code),'canonicalCount':len(canonical_code),'baselineManifestSha256':sha_bytes(json.dumps(base_code,sort_keys=True).encode()),'canonicalManifestSha256':sha_bytes(json.dumps(canonical_code,sort_keys=True).encode()),'changed':code_changes,'qualification':'Includes tracked code in references, qa, evidence and fixtures outside entry roots. All baseline-to-canonical changed paths are separately retained, including JSON receipts and archives. Git-history-derived churn metrics are reported without normalization.'}
if code_changes:errors.append('Full tracked code baseline/canonical mismatch')
Path(a.output).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':a.output,'errors':errors,'gates':{n:{'pending':r['candidate'].get('pending',False),'comparison':r.get('comparison'),'summaryLines':r.get('summaryLines')} for n,r in result['gates'].items()}},indent=2))
