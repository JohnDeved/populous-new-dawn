# Frontend Quit validation selection

Base: 0d2ad770ed03f6d049b01bd71176f954a6e4e044. Task: bounded frontend menu1 presentation and safe browser cancellation; refs #457.

The orchestration plan explicitly reports unknown frontend/proof paths and conservatively selects repository-check and production-build. Added startup evidence indexing may also select the persistence subsystem's existing mission/checkpoint jobs. These are routing suggestions; changed code and callers determine affected scope.

Required:
- All tracked tests/*.test.mjs, enumerated and hashed on the frozen clean candidate, in serial ten-file durable batches (434 files). No skipped inventory or reduced assertions.
- Equivalent npm run check stages: TypeScript, complete Node inventory, parity:check and orchestration:check. The monolithic aggregate is not rerun because the constrained cloud execution retains reliable terminal results per batch.
- Canonical exact-commit Cloudflare production build. Local npm run build is not run due to the verified storage-constrained runner; remote production build owns that gate.
- Focused frontend/quit/options unit checks; changed-source ESLint and formatting; all maintained TypeScript quality commands with explicit legacy attribution and raw failed statuses where applicable.
- Hash-locked read-only original PE/language menu descriptor reproduction, no original executable execution.
- Actual production Home browser baseline and repaired candidate: native/wide/short/DPR2, full menu composition, disabled Yes, No/Back/repeated Escape, focus, nested Options ownership, pointer and reduced-motion behavior, genuine asset-request failures, unchanged navigation/storage and explicit failed-storage session-only checkpoint wording.
- Fresh independent full-diff and evidence review.

No game/store/scene/save/mission/AI code changes. Broad mission4/8/9/19/20/21 and natural-victory rendered scenarios, original executable execution, new gameplay parity recording and hardware performance benchmarks are not applicable to this presentation slice. Full portable inventory remains required. The browser storage-failure setup uses the observed real store API only to establish an in-memory checkpoint after genuine IndexedDB failure; it is not new shipped Save UI evidence. The plain React/Vite Home bootstrap excludes Vinext/RSC/remote framework serving, covered separately by the canonical build.
