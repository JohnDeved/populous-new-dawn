import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
if(!process.argv.includes('--prepare')) while(existsSync('/tmp/quit-menu457/hold-heavy')) await new Promise(resolve=>setTimeout(resolve,1000))
const manifest=process.argv.find(value=>value.startsWith('--manifest='))?.slice(11) ?? `/tmp/quit-menu457/test-inventory-${execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()}.json`
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex')
const files=git('ls-files','tests/*.test.mjs').split('\n').sort()
if(process.argv.includes('--prepare')) {
 if(git('status','--porcelain'))throw Error('Prepare only from clean source')
 writeFileSync(manifest,JSON.stringify({head:git('rev-parse','HEAD'),files:Object.fromEntries(files.map(file=>[file,hash(`${root}/${file}`)])),batches:Array.from({length:Math.ceil(files.length/10)},(_,i)=>files.slice(i*10,i*10+10))},null,2)+'\n')
 console.log(`Prepared ${files.length} durable test-file entries`);process.exit(0)
}
const data=JSON.parse(readFileSync(manifest))
if(git('rev-parse','HEAD')!==data.head||git('status','--porcelain'))throw Error('Source drift')
if(JSON.stringify(files)!==JSON.stringify(Object.keys(data.files)))throw Error('Inventory drift')
for(const [file,expected] of Object.entries(data.files))if(hash(`${root}/${file}`)!==expected)throw Error(`Changed ${file}`)
const lastSummary=(text,label)=>{const values=[...text.matchAll(new RegExp(`^(?:#|ℹ) ${label} (\\d+)\\s*$`,'gm'))];if(!values.length)throw Error(`Missing final ${label} summary`);return Number(values.at(-1)[1])}
let failed=0,total=0;const batches=[]
for(const [index,batch] of data.batches.entries()) {
 const output=`work/orchestration/quit-menu457/${data.head.slice(0,8)}/inventory-${String(index+1).padStart(2,'0')}.json`
 let result
 if(existsSync(`${root}/${output}`)) {
  result=JSON.parse(readFileSync(`${root}/${output}`))
  if(result.status!=='passed'||result.source.headOid!==data.head)throw Error(`Review retained nonpass/source mismatch ${output}; never overwrite it`)
 }else result=runCommandReceipt(root,{output,command:['node','--test','--test-concurrency=1',...batch],inputs:[manifest,'/tmp/quit-menu457/run-final-inventory.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 const raw=readFileSync(result.artifacts.stdout,'utf8')
 if(hash(result.artifacts.stdout)!==result.stdoutSha256)throw Error('Raw stdout hash mismatch')
 const counts=Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(label=>[label,lastSummary(raw,label)]))
 if(result.status==='passed'&&(counts.fail||counts.cancelled||counts.tests!==counts.pass+counts.skipped+counts.todo))throw Error('Terminal summary disagrees with receipt')
 total+=counts.tests
 console.log(`Batch ${index+1}/${data.batches.length}: ${result.status}, ${batch.length} files, ${counts.tests} tests`)
 batches.push({index:index+1,files:batch,output,status:result.status,counts})
 if(result.status!=='passed')failed++
}
// Raw receipt schema owns log locations; parse summaries only after all terminal receipts exist.
writeFileSync(`/tmp/quit-menu457/inventory-terminal-${data.head}.json`,JSON.stringify({head:data.head,fileCount:files.length,testCount:total,batches,failed},null,2)+'\n')
console.log(`Terminal inventory: ${files.length} files, ${batches.length} batches, failed ${failed}`)
process.exitCode=failed?1:0
