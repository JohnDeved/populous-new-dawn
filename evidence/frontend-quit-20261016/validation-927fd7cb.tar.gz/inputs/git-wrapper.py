#!/usr/bin/python3
"""Task-only Git object routing; fixture repositories retain independent objects."""
import os,sys,subprocess
real='/usr/local/bin/git'
env=os.environ.copy()
for key in ('GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):
    env.pop(key,None)
a=sys.argv[1:];prefix=[];i=0
while i<len(a) and a[i].startswith('-'):
    flag=a[i];prefix.append(flag);i+=1
    if flag in ('-C','-c','--git-dir','--work-tree','--namespace','--config-env'):
        if i>=len(a):break
        prefix.append(a[i]);i+=1
probe=subprocess.run([real,*prefix,'rev-parse','--path-format=absolute','--git-common-dir'],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
if (a[i] if i<len(a) else '') not in ('init','clone') and probe.returncode==0 and os.path.realpath(probe.stdout.strip())=='/workspace/scratch/69fd8163d94e/populous-near-transfer/.git':
    env['GIT_OBJECT_DIRECTORY']='/tmp/selector-scene457/git-objects'
    env['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/tmp/selector457/git-objects:/tmp/ui460/git-objects:/workspace/scratch/69fd8163d94e/populous-near-transfer/.git/objects'
os.execve(real,[real,*a],env)
