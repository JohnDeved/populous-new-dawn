# Independent final inventory audit

Result: PASS for the complete canonical434-file test inventory at clean commit `927fd7cbaa757c45a2f629700757e5d72e3c96f4`.

-434 unique test files,44 eligible terminal receipts,2,795 tests passed.
-0 failed, cancelled, skipped or todo tests.
-No missing or duplicate accepted batches/files.
-Canonical tracked manifest also matches the direct filesystem `tests/*.test.mjs` glob used by `npm test`.
-All eligible receipts have exact canonical child arguments, expected repository cwd and finished phase.
-Every raw stdout/stderr SHA-256 and inline log copy matches; totals come from the LAST anchored top-level summary in each raw stdout log.
-Before/after source snapshots are identical for every eligible receipt; frozen candidate, clean tracked diff, declared input hashes, installed-lock fingerprint, and all434 current test hashes verify.

The accepted set is original batches2–44 (424 files,2,734 passes) plus distinct `inventory-01-recovery1.json` (10 files,61 passes). The original `inventory-01.json` remains invalidated and excluded. The original overall inventory exit1 and terminal `failed:1` remain preserved, not rewritten as a pass. Its raw2795-test total included the invalidated batch; the independently recomputed accepted total uses the fresh recovery instead, with no double counting.

## Runner provenance qualification

Original invocation loaded the reconstructed runner whose exact SHA-256 is `2275eb0e27109a0bd12d039a69c6f83ab09b6be334fea6c70bca44483b992af8`, matching the first receipt sourceBefore. At03:15:53.275884UTC, a single preinventory hold-loop line was added on disk; current/retained disk SHA-256 is `06837d92680c8a0898284367d8c88af727274202ab9be44153634948443d5fe9`, matching first receipt sourceAfter. The edit occurred within first-batch execution03:15:48.307–03:16:11.532UTC, correctly invalidating it.

The exact diff changes only a top-level preamble before the already-running inventory loop. Test argv, batch iteration, command-receipt calls and summary semantics are byte-identical. Later stable terminal receipts are accepted with this explicit loaded-versus-disk identity distinction, as independently agreed by the reviewer. This is semantic provenance supported by the first captured hash and reconstructed matching bytes, not a process-memory attestation and not a claim that later disk hashes identify loaded code.

The recovery uses a fresh stable runner with SHA-256 `a7979f8684a544ead3d4578c3d8962b3b0f5320508210a8d233fd618f9d7125a`, verifies all434 hashes and replays exactly the first ten files. Its seven declared inputs include both runner variants and the provenance sidecar. It passed61/61 at03:53:40.998–03:54:03.667UTC with identical before/after snapshots.

## Files and hashes

- `final-inventory-audit-927fd7cb.json`: full per-receipt commands, raw hashes, final counts, input checks and coverage. SHA-256 `8de4d4af8a0bd5ec825b5c4f3204960ffb438c00ed04400dd936d8c809ed2749`.
- `runner-provenance-audit.json` and `runner-diff.patch`: exact independent provenance checks.
- `canonical-crosscheck.json`: direct npm-test glob, expected cwd/kind/phase and tracked lock/receipt-engine hashes.
- `audit-inventory.py`: read-only auditor; it never launches tests or edits receipts/runners. Final audit embeds its SHA-256.
- Earlier `audit-*.json` snapshots retain terminal-only progress; in-progress/unknown raw logs were never counted.
- Raw receipts/logs remain under `/tmp/populous-selector-scene-457/work/orchestration/quit-menu457/927fd7cb/`; retained runner variants, manifest and original terminal summary under `/tmp/quit-menu457/`.

Frozen manifest SHA-256: `db6331992799fa0342b7907d41c25cc2755bd67731f61205a26353360e963406`.
Installed `.package-lock.json` SHA-256: `65e45d0a87d1ecd4fbf56508b9821eb3bfb3867c8477db4aaa1452eb2bed13d8`.
Tracked package-lock SHA-256: `c1599d8d7e3f028e290a13561c653cf926e739e98eb9ec1b476dbe1c2a4558ba`.

Qualification: this is complete canonical test-file coverage via serial10-file batches, not a claim of one monolithic `npm run check` invocation. Other type/parity/orchestration/build/quality gates are owned and reported separately by the writer. Installed-lock stability is verified; this inventory does not claim a byte fingerprint of every installed dependency. No competing heavy tests/browser were launched and no runner/source edits were made by this auditor.
