#!/usr/bin/env python3
"""Read-only audit of retained command receipts; never launches tests or edits evidence."""
import datetime,hashlib,json,re,subprocess,sys
from pathlib import Path
repo=Path('/tmp/populous-selector-scene-457')
base=Path('/tmp/quit-menu457')
head='927fd7cbaa757c45a2f629700757e5d72e3c96f4'
manifest=base/f'test-inventory-{head}.json'
receipt_root=repo/'work/orchestration/quit-menu457'/head[:8]
git='/tmp/selector-scene457/git-bin/git'
hash=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
run_git=lambda *args:subprocess.check_output([git,*args],cwd=repo,text=True).strip()
data=json.loads(manifest.read_text())
canonical=sorted(run_git('ls-files','tests/*.test.mjs').splitlines())
flat=sum(data['batches'],[])
empty=hashlib.sha256(b'').hexdigest()
expected={'manifest':hash(manifest),'installedLock':hash(repo/'node_modules/.package-lock.json'),'gitWrapper':hash(git)}
report={'auditorSha256':hash(__file__),'auditedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':run_git('rev-parse','HEAD'),'clean':not run_git('status','--porcelain'),'canonicalFiles':len(canonical),'manifestHeadMatches':data['head']==head,'manifestEntries':len(data['files']),'batchCount':len(data['batches']),'canonicalManifestMatch':list(data['files'])==canonical,'canonicalBatchMatch':flat==canonical and len(set(flat))==len(canonical),'changedTestHashes':[file for file,digest in data['files'].items() if hash(repo/file)!=digest],'fingerprints':expected,'receipts':[],'acceptedByBatch':{},'totals':{k:0 for k in ['tests','pass','fail','cancelled','skipped','todo']},'issues':[]}
for path in sorted(receipt_root.glob('inventory-*.json')):
 r=json.loads(path.read_text());entry={'path':str(path),'status':r['status'],'startedAt':r['startedAt'],'finishedAt':r.get('finishedAt'),'receiptSha256':hash(path),'accepted':False,'issues':[]}
 command=r.get('command',[]);files=command[3:];indices=[i+1 for i,batch in enumerate(data['batches']) if files==batch]
 entry.update(command=command,canonicalBatch=indices[0] if len(indices)==1 else None)
 if command[:3]!=['node','--test','--test-concurrency=1'] or len(indices)!=1:entry['issues'].append('Command is not one exact canonical batch')
 source=r.get('source',{});inputs=source.get('inputs',{})
 if source.get('headOid')!=head or source.get('trackedDiffSha256')!=empty:entry['issues'].append('Source HEAD or tracked diff mismatch')
 for key,digest in [(str(manifest),expected['manifest']),('node_modules/.package-lock.json',expected['installedLock']),(git,expected['gitWrapper'])]:
  if inputs.get(key)!=digest:entry['issues'].append(f'Fingerprint mismatch or absent: {key}')
 entry['runnerInputHashes']={k:v for k,v in inputs.items() if 'runner' in k or 'run-final-inventory' in k}
 entry['currentInputHashesMatch']={k:(Path(k) if Path(k).is_absolute() else repo/k).is_file() and hash(Path(k) if Path(k).is_absolute() else repo/k)==v for k,v in inputs.items()}
 if r['status']=='passed' and not all(entry['currentInputHashesMatch'].values()):entry['issues'].append('Current retained input bytes differ from passing receipt')
 if r.get('phase')=='finished':
  entry['beforeAfterIdentical']=source==r.get('sourceAfter')
  for stream in ['stdout','stderr']:
   raw=Path(r['artifacts'][stream]).read_text();entry[stream+'FileSha256']=hash(r['artifacts'][stream]);entry[stream+'HashMatches']=entry[stream+'FileSha256']==r.get(stream+'Sha256');entry[stream+'InlineMatches']=raw==r.get(stream)
   if not entry[stream+'HashMatches'] or not entry[stream+'InlineMatches']:entry['issues'].append(f'{stream} hash/inline mismatch')
   if stream=='stdout':
    matches={k:re.findall(r'^(?:#|ℹ) '+k+r' (\d+)\s*$',raw,re.M) for k in report['totals']}
    entry['lastTopLevelCounts']={k:int(v[-1]) for k,v in matches.items() if v}
    if any(not v for v in matches.values()):entry['issues'].append('Missing LAST top-level summary field')
  if r['status']=='passed':
   if not entry['beforeAfterIdentical']:entry['issues'].append('Passing receipt has source drift')
   if r.get('exitCode')!=0 or r.get('signal') or r.get('error'):entry['issues'].append('Passing receipt exit inconsistent')
   counts=entry['lastTopLevelCounts']
   if len(counts)==6 and (counts['fail'] or counts['cancelled'] or counts['tests']!=counts['pass']+counts['skipped']+counts['todo']):entry['issues'].append('Passing receipt totals inconsistent')
   entry['accepted']=not entry['issues']
   if entry['accepted']:
    key=str(indices[0]);report['acceptedByBatch'].setdefault(key,[]).append(str(path))
    for k,v in counts.items():report['totals'][k]+=v
  else:entry['qualification']='Excluded nonpassing/invalidated terminal attempt, retained separately'
 else:entry['qualification']='Pending/unknown receipt, excluded regardless of current raw log content'
 report['receipts'].append(entry)
 if entry['issues']:report['issues'].append({'path':str(path),'issues':entry['issues']})
report['duplicateAcceptedBatches']={k:v for k,v in report['acceptedByBatch'].items() if len(v)>1}
report['acceptedBatchCount']=len(report['acceptedByBatch'])
report['acceptedFileCount']=sum(len(data['batches'][int(k)-1]) for k in report['acceptedByBatch'])
report['missingAcceptedBatches']=[i+1 for i in range(len(data['batches'])) if str(i+1) not in report['acceptedByBatch']]
report['currentSourceValid']=report['head']==head and report['clean'] and report['manifestHeadMatches'] and report['canonicalManifestMatch'] and report['canonicalBatchMatch'] and not report['changedTestHashes']
report['terminalCoverageComplete']=report['currentSourceValid'] and not report['missingAcceptedBatches'] and not report['duplicateAcceptedBatches'] and not report['issues']
report['provenanceQualification']='For the original multi-batch invocation, retained loaded runner2275eb0e differs from per-batch disk-input hash06837d92 only by a never-executed preinventory hold. Later passes require this explicit semantic qualification, not a claim that disk bytes were loaded. Batch1invalidated must be replaced by a distinct stable-runner receipt; original preserved.'
output=Path(sys.argv[1]);output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['auditedAt','head','clean','canonicalFiles','acceptedBatchCount','acceptedFileCount','totals','missingAcceptedBatches','issues','terminalCoverageComplete']},indent=2))
