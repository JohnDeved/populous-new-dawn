import json, pathlib, statistics
root=pathlib.Path('/tmp/water-baseline-474')
archived_rows=[json.loads(line) for line in (root/'run-1.jsonl').read_text().splitlines()]
archived=next(row for row in archived_rows if row['type']=='correctness')
reference=None
runs=[]
expected_changes={'app/scene-terrain-runtime.ts','app/water-lighting.ts','tests/water-lighting.test.mjs'}
reference_inputs=None
for i,variant in enumerate(['baseline','candidate','candidate','baseline'],1):
    rows=[json.loads(line) for line in (root/f'pair-{i}-{variant}.jsonl').read_text().splitlines()]
    manifest=next(row for row in rows if row['type']=='manifest')
    correctness=next(row for row in rows if row['type']=='correctness')
    assert manifest['variant']==variant and correctness['status']=='pass' and correctness['dependenciesStable']
    if reference is None: reference=correctness
    assert correctness['phaseHashes']==reference['phaseHashes']==archived['phaseHashes'], 'Full 256-phase output mismatch'
    assert correctness['invariant']==archived['invariant'], 'Archived baseline input mismatch'
    assert correctness['invariant']==reference['invariant'], 'Input/immutable output mismatch'
    inputs={key.removeprefix(manifest['sourceRoot']+'/'):value for key,value in manifest['fingerprints'].items()}
    if reference_inputs is None: reference_inputs=inputs
    differences={key for key in inputs.keys()|reference_inputs.keys() if inputs.get(key)!=reference_inputs.get(key)}
    assert differences==(expected_changes if variant=='candidate' else set()), differences
    samples=[row for row in rows if row['type']=='sample']
    assert len(samples)==1024
    summaries=[row for row in rows if row['type']=='summary']
    for summary in summaries:
        elapsed=sorted(row['ns'] for row in samples if row['case']==summary['case'])
        assert len(elapsed)==512 and statistics.median(elapsed)==summary['medianNs']
    runs.append({'index':i,'variant':variant,'source':manifest['source'],'summaries':summaries})
report={'status':'pass','sequence':['baseline','candidate','candidate','baseline'],
        'all256PhaseHashesEqual':True,'onlyExpectedSourceDifferences':True,'runs':runs,
        'limits':'Four fresh Node processes; descriptive CPU-path comparison, not browser/FPS or project-wide gain.'}
(root/'paired-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
