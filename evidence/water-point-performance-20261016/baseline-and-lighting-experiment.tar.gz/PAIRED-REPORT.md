# Reviewed lighting-lookup candidate: paired CPU comparison

The source-reviewed scratch patch precomputes 192 exact packed JS-number lighting conversions and freezes returned cached objects. Unexpected shades fall back to the original helper. Attribute writes and versioning are unchanged. No production checkout edit or deployment occurred.

## Validation

Focused tests: 3 passed, 0 failed (all 192 conversions, exact Float32 channel bytes, cached-object mutation rejection, exceptional numeric values and surface truthiness).

Four fresh Node 24.19.0 processes ran serially in ABBA order after root reserved the local measurement lane. Each had 256 warmups and 512 measured calls per case, under a 120-second cap. All exited successfully. All 256 phase hashes and immutable inputs matched the archived original baseline. Every expected input fingerprint remained stable; cross-variant differences were exactly the caller and two added files. The last correctness comparison completed at approximately 11:12:18 UTC.

Snapshots were copied from main-identical dependencies captured at d5088d8fa5c75f1e17fce5b8397146a5074128c7; intended main is 673b89ad4d53821a592b80ccc87cf6fc6048fc58. Baseline source was isolated from the shared checkout; the candidate shared only owned snapshot hardlinks, with the changed caller inode detached before patching. Installed dependency implementations remained read-only and hash-bound.

## Changed-turn update results

All times in milliseconds, 98,304 vertices per call:

| Order | Variant | Median | p95 | p99 | Maximum |
|---|---|---:|---:|---:|---:|
| 1 | Baseline | 5.1317975 | 7.720835 | 11.531391 | 58.319313 |
| 2 | Candidate | 5.0158890 | 7.165107 | 10.247774 | 65.852269 |
| 3 | Candidate | 5.4278100 | 9.951165 | 17.235660 | 140.900087 |
| 4 | Baseline | 5.9899885 | 10.320982 | 22.994875 | 130.023956 |

Adjacent forward/reverse pairs show median reductions of 2.26% and 9.39%. Comparing the mean of the two process medians per variant yields 6.10% lower candidate time (5.560893 ms versus 5.2218495 ms, difference 0.3390435 ms). This is a descriptive statistic, not a confidence interval or guaranteed gain. Baseline median drift between runs was 16.72%, larger than the aggregate difference. Large tail spikes occurred in both variants; their cause was not established. Candidate maximum latency was higher in both adjacent comparisons.

Same-key medians were 152 / 146 / 287 / 148 ns in order. Timer overhead is material at this scale. No cache-hit improvement claim is appropriate.

## Interpretation and recommendation

The candidate is bit-exact over the measured fixture and has a modest positive median signal, but repeatability and browser benefit are not established. Do not publish a general 6% engine speedup or infer FPS. Keep the patch available for a controlled repeat or actual browser measurement; this experiment alone does not justify claiming a meaningful performance improvement. It is also not evidence that WASM, WebGPU or a language migration is required.

Scope remains Node CPU preparation of unchanged Mission 1 terrain. Terrain deformation, other missions, changing lighting, GPU upload, rendering, painter sorting, full callback performance and 120 FPS compliance remain outside this measurement. Available CPU quota and underlying VM contention were unknown. Memory data are observed process high-water values at recorded checkpoints, not a precise isolated allocation measurement.

## Artifacts and cleanup

- pair-{1-baseline,2-candidate,3-candidate,4-baseline}.jsonl: raw samples, source/asset fingerprints and output hashes
- paired-comparison.json: correctness and dependency comparison
- paired-effect-summary.json: exact descriptive calculations
- candidate-focused-tests.tap: focused results
- lighting-candidate.patch: source-reviewed proposed change
- paired-benchmark.mjs, run-paired.sh, compare-paired.py: reproducibility scripts
- snapshot-manifest.json: reconstructable snapshot hashes

After successful comparison, only the two owned generated source snapshots were removed, reclaiming 10,252,288 bytes. Shared checkout and installed dependencies were untouched. Reconstruct the snapshots before rerunning; the launcher currently cannot run without them. Raw evidence and patch remain retained.
