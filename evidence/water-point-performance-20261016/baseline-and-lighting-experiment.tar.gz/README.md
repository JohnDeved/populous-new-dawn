# Production updateWater baseline, 2026-10-16

Three fresh Node 24.19.0 processes ran serially after the parent confirmed the local typecheck had ended and reserved the measurement lane. No local browser or test job was authorized to overlap. Other workers could read or edit unrelated frontend source. Underlying VM contention and CPU entitlement remain unknown.

Actual run HEAD: d5088d8fa5c75f1e17fce5b8397146a5074128c7 (clean at each process start).
Intended main: 673b89ad4d53821a592b80ccc87cf6fc6048fc58.
All 335 tracked, resolved source/fixture/asset/config inputs matched intended-main Git blobs exactly. All 339 fingerprints matched before/after each run and across runs; the four external files are the scratch runner and loaded Three.js module/core and TypeScript implementation. Thus these are runs at the actual HEAD using main-identical measured dependencies, not runs claimed at another checkout commit.

## Method

Run from any directory:

BENCH_PROCESS_INDEX=1 timeout 120s node /tmp/water-baseline-474/benchmark.mjs --run > /tmp/water-baseline-474/run-1.jsonl 2> /tmp/water-baseline-474/run-1.stderr

Repeat indices 2 and 3 serially. All exited 0 within the cap, stderr empty. The original syntax and configuration-only checks passed before clearance. The runs together occupied approximately 10:59:30–11:00:18 UTC, including module loading, setup, correctness and hashing.

Mission 1 authored terrain and wave assets; actual GameScene updateWater and Three.js attribute writes; 98,304 vertices. Each process validates 256 wave phases, then uses 256 warmups and 512 individually timed calls per case. Changed-turn and unchanged-key cases are separate. No forced GC or dropped outliers. Timing surrounds only the production call with hrtime.bigint; setup, output hashing and turn assignment are outside. The unchanged-key measurement is small enough that timer overhead is material.

## Raw-derived results

Milliseconds, except explicitly stated cache-hit nanoseconds:

| Process | Changed median | p95 | p99 | maximum | Same-key median ns |
|---|---:|---:|---:|---:|---:|
| 1 | 5.4355455 | 7.264450 | 9.363617 | 14.032754 | 151 |
| 2 | 5.1665415 | 7.173250 | 8.934799 | 24.117302 | 146 |
| 3 | 5.2049180 | 7.099758 | 8.676771 | 17.591684 | 150 |

Import/transpilation/fingerprinting overhead before fixture setup: 7.269, 5.604 and 5.810 seconds, excluded from timing. Observed process high-water RSS at the recorded checkpoints was 467,012 / 491,196 / 468,600 KiB, including imports, setup and checks. Memory snapshots are not allocation-rate measurements.

## Correctness and scope

All 256 output hashes are retained per run for positions, diffuse light and highlights; phase 256 equals phase 0. Phase 23 animates both position and light. Shared corners agree at the wrap check. UV, land UV, surface, wave data, terrain arrays and acquired water texture remain unchanged. Changed calls increment the three attribute versions; same-key calls do not. Final measured outputs match reference phase hashes.

These reference hashes bind the current implementation for later differential comparisons; they are not an independent original-game correctness oracle. Coverage is an unchanged Mission 1 initial terrain across its water phases, not terrain deformation, other missions, or dynamic lighting states. GPU upload, painter sorting, browser scheduling and rendering are excluded. No FPS, engine-wide speedup, WASM gain or 120 FPS compliance is established.

Raw samples, full fingerprints and phase hashes: run-{1,2,3}.jsonl. Git comparison and runtime summaries: verification-summary.json. No tracked checkout edits, dependency installation, browser work or migration.
