#!/usr/bin/env bash
set -eu
[ "${1:-}" = "--reviewed-lane-granted" ] || { echo 'Requires completed source review and root measurement-lane clearance.' >&2; exit 2; }
base=/tmp/water-baseline-474
index=0
for variant in baseline candidate candidate baseline; do
  index=$((index+1))
  output="$base/pair-$index-$variant"
  [ ! -e "$output.jsonl" ] && [ ! -e "$output.stderr" ] || { echo "Refusing overwrite: $output" >&2; exit 2; }
  BENCH_SOURCE_ROOT="$base/$variant-source" BENCH_PROCESS_INDEX="$index" timeout 120s node "$base/paired-benchmark.mjs" --run > "$output.jsonl" 2> "$output.stderr"
  printf 'Completed %s %s\n' "$index" "$variant"
done
python3 "$base/compare-paired.py"
