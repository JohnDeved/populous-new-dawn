from pathlib import Path
p=Path('/workspace/scratch/69fd8163d94e/water-point-474-second')
s=(p/'paired-benchmark.mjs').read_text()
s=s.replace("import os from 'node:os'", "import os from 'node:os'\nimport { PerformanceObserver, performance } from 'node:perf_hooks'\nimport { setImmediate as yieldEventLoop } from 'node:timers/promises'")
s=s.replace("const config = { mission:", "const diagnosticMode = process.env.DIAGNOSTIC_MODE ?? 'block'\nassert.ok(['block', 'sample'].includes(diagnosticMode))\nconst config = { diagnosticMode, blockSize: 64, diagnosticOnly: true, mission:")
s=s.replace("production-updateWater-point-reuse-v1", "production-updateWater-gc-cpu-diagnostic-v1")
a=s.index('const rows = [], memory = []')
b=s.index('const mismatches=[]',a)
s=s[:a]+'''// GC timestamps and sample intervals use the same performance.now() clock.
// Observer delivery is asynchronous; drain after each complete case, never between calls or blocks.
const archived = readFileSync('/tmp/water-baseline-474/run-1.jsonl', 'utf8').trim().split('\\n').map(JSON.parse)
const reference = archived.find(row => row.type === 'correctness')
assert.deepEqual(phaseHashes, reference.phaseHashes, 'Archived phase mismatch')
assert.deepEqual(immutable, reference.invariant, 'Archived immutable-input mismatch')
const rows = [], memory = [], diagnosticRows = [], gcEvents = []
const captureGc = entries => {
  for (const entry of entries) gcEvents.push({ type: 'gc', startMs: entry.startTime,
    durationMs: entry.duration, endMs: entry.startTime + entry.duration,
    kind: entry.detail?.kind, flags: entry.detail?.flags })
}
const observer = new PerformanceObserver(list => captureGc(list.getEntries()))
assert.ok(PerformanceObserver.supportedEntryTypes.includes('gc'), 'GC entries unsupported')
observer.observe({ entryTypes: ['gc'] })
const flushGc = async () => { await yieldEventLoop(); captureGc(observer.takeRecords()) }
const switches = usage => ({ voluntary: usage.voluntaryContextSwitches, involuntary: usage.involuntaryContextSwitches })
// These controls characterize measurement-call overhead, not production workload perturbation.
// The observer stays enabled for both controls. No forced GC or outlier filtering.
async function controls(point) {
  for (const instrumented of [false, true]) {
    const n = 4096, times = new Float64Array(n)
    const wallStartMs = performance.now(), cpuStart = process.cpuUsage()
    for (let i = 0; i < n; i++) {
      if (instrumented) {
        const alignedStartMs = performance.now()
        const cpu = diagnosticMode === 'sample' ? process.cpuUsage() : null
        const t = process.hrtime.bigint(); times[i] = Number(process.hrtime.bigint() - t)
        if (cpu) process.cpuUsage(cpu)
        const alignedEndMs = performance.now()
        // Retain a dependency on both reads without logging or allocating per iteration.
        assert.ok(alignedEndMs >= alignedStartMs)
      } else { const t = process.hrtime.bigint(); times[i] = Number(process.hrtime.bigint() - t) }
    }
    const cpu = process.cpuUsage(cpuStart), wallEndMs = performance.now()
    diagnosticRows.push({ type: 'overhead-control', point, instrumented, count: n,
      wallStartMs, wallEndMs, totalWallMs: wallEndMs-wallStartMs, cpu,
      timerSamplesNs: Array.from(times), note: 'Empty-body control; not subtractable from workload timings.' })
    await flushGc()
  }
}
await controls('before')
let turn = 256
for (const name of config.cases) {
  for (let i=0; i<config.warmups; i++) { if (name==='changed-turn') world.turn=++turn; scene.updateWater() }
  await flushGc()
  const versions=mutableNames.map(n=>attributes[n].version)
  const n = config.repetitions
  const elapsed = new Float64Array(n), starts = new Float64Array(n), ends = new Float64Array(n)
  const userCpu = new Float64Array(n), systemCpu = new Float64Array(n)
  memory.push({ type:'memory', case:name, point:'before', ...process.memoryUsage(), usage:process.resourceUsage() })
  for (let base=0; base<n; base+=config.blockSize) {
    const stop=Math.min(base+config.blockSize,n)
    const resourceBefore = process.resourceUsage(), heapBefore=process.memoryUsage()
    const blockStartMs=performance.now(), cpuStart=process.cpuUsage()
    for (let i=base; i<stop; i++) {
      if (name==='changed-turn') world.turn=++turn
      starts[i]=performance.now()
      const sampleCpu = diagnosticMode === 'sample' ? process.cpuUsage() : null
      const before=process.hrtime.bigint(); scene.updateWater(); elapsed[i]=Number(process.hrtime.bigint()-before)
      if (sampleCpu) { const cpu=process.cpuUsage(sampleCpu); userCpu[i]=cpu.user; systemCpu[i]=cpu.system }
      ends[i]=performance.now()
    }
    const cpu=process.cpuUsage(cpuStart), blockEndMs=performance.now()
    const resourceAfter=process.resourceUsage(), heapAfter=process.memoryUsage()
    diagnosticRows.push({ type:'diagnostic-block', case:name, startIndex:base, endIndexExclusive:stop,
      blockStartMs, blockEndMs, wallMs:blockEndMs-blockStartMs, cpu,
      contextSwitchDelta:{ voluntary:resourceAfter.voluntaryContextSwitches-resourceBefore.voluntaryContextSwitches,
        involuntary:resourceAfter.involuntaryContextSwitches-resourceBefore.involuntaryContextSwitches },
      switchesBefore:switches(resourceBefore), switchesAfter:switches(resourceAfter), heapBefore,heapAfter })
  }
  await flushGc()
  memory.push({ type:'memory', case:name, point:'after', ...process.memoryUsage(), usage:process.resourceUsage() })
  mutableNames.forEach((n,i)=>assert.equal(attributes[n].version,versions[i]+(name==='changed-turn'?config.repetitions:0)))
  assert.deepEqual(output(), phaseHashes[world.turn & 255]); assert.deepEqual(invariant(),immutable)
  elapsed.forEach((ns,i)=>rows.push({type:'sample',case:name,repetition:i,
    turn:name==='changed-turn'?turn-config.repetitions+i+1:turn,
    phase:(name==='changed-turn'?turn-config.repetitions+i+1:turn)&255,
    ns,intervalStartMs:starts[i],intervalEndMs:ends[i],
    ...(diagnosticMode==='sample'?{processCpuMicroseconds:{user:userCpu[i],system:systemCpu[i]}}:{})}))
}
await controls('after')
await flushGc(); observer.disconnect()
for (const row of rows) row.overlappingGcEvents = gcEvents.map((gc,i)=>
  gc.startMs < row.intervalEndMs && gc.endMs > row.intervalStartMs ? i : -1).filter(i=>i>=0)
// Overlap uses slightly wider enclosing intervals, not exact hrtime boundaries.
// A GC overlap establishes correlation, not exclusive cause or stop-the-world duration.
''' + s[b:]
s=s.replace("for(const row of [...memory,...rows])", "for(const row of [...memory,...diagnosticRows,...gcEvents,...rows])")
s=s.replace("'VM CPU quota/contention unknown. Memory snapshots do not measure allocation rate.'", "'VM CPU quota/contention unknown. Memory snapshots do not measure allocation rate.',\n    'Diagnostic only: observer, aligned timers, CPU/resource reads and between-case yields alter execution; do not compare these timings to primary ABBA.',\n    'CPU usage is whole-process including helper threads; CPU/wall cannot prove main-thread descheduling. GC overlap is correlation.',\n    'Control timings characterize empty-body instrumentation only; they do not bound GC/JIT/scheduler perturbation or justify subtracting overhead.'")
(p/'diagnostic-benchmark.mjs').write_text(s)
