# Tail diagnostic runner (prepared, not executed)

Purpose: distinguish whether late long updateWater calls overlap observed GC, coincide with CPU/wall divergence or cluster in blocks with resource-switch/heap changes. This is exploratory attribution, not a replacement speed benchmark or a causal proof.

Sources remain the verified immutable baseline/candidate wrappers from the second experiment; no runtime, dependency, fixture or production source changes. All original 256 phase hashes and immutable inputs are asserted against archived run-1 before measurements. Resolved inputs remain fingerprinted before/after.

Command after lane approval (one variant/mode per fresh process):

BENCH_SOURCE_ROOT=/tmp/water-point-474-source/candidate DIAGNOSTIC_MODE=block BENCH_PROCESS_INDEX=1 timeout 120s node /workspace/scratch/69fd8163d94e/water-point-474-second/diagnostic-benchmark.mjs --run > candidate-block-diagnostic.jsonl 2> candidate-block-diagnostic.stderr

Use DIAGNOSTIC_MODE=sample only for a separately approved fresh process if finer CPU resolution is needed. Baseline source root is /tmp/water-point-474-source/baseline. Do not launch until the shared execution lane is granted. No execution, syntax check or configuration run has occurred yet.

Instrumentation:
- Preserve 256 warmups and 512 samples per changed-turn/same-key case, with original phase/index.
- Aligned performance.now start/end intervals enclose each existing hrtime call-duration measurement, allowing correlation with perf_hooks GC startTime/duration on the same monotonic origin.
- PerformanceObserver collects GC kind/flags/timestamps. Drain callbacks after each complete synchronous case; no yield between calls or blocks. Buffered callbacks may allocate after timing; GC caused by observer setup and other instrumentation can still perturb the run.
- Read process CPU usage and resource/memory data around 64-call blocks. Output voluntary/involuntary context-switch deltas. The default block mode does not query CPU per sample. Optional sample mode adds per-call process.cpuUsage reads, outside the core hrtime boundaries but inside the wider aligned interval.
- Retain every sample, block, raw GC event and overlap index; never discard tails or force GC.
- Empty-body controls before and after run 4,096 iterations each with timer-only and aligned-timer/optional-CPU instrumentation. Export every control sample plus total wall/CPU, permitting direct overhead characterization for each mode. Controls do not measure workload perturbation, are not a correction factor and must not be subtracted from updateWater durations.

Limits: GC interval overlap is correlation, and enclosing sample intervals include small measurement overhead. GC events are runtime-reported and their absence cannot exclude other collector work. Process CPU includes helper threads; CPU/wall divergence and context switches cannot prove main-thread scheduling loss. Heap/external deltas are not allocation rates. JIT and host contention remain unobserved hypotheses. These timings must not be pooled with primary ABBA or used for FPS/smoothness improvement claims.

Budget: runner 15 KiB plus small preparation script/documentation. Source wrappers already exist; no snapshots, dependencies or profiler installs. Expected runtime is comparable in order to prior roughly 13-second process runs, but unmeasured instrumentation can add work; retain 120-second cap. Reserve 2 MiB for raw output per diagnostic process and stop on source, correctness, timeout or resource failure. No diagnostic process has run yet.
