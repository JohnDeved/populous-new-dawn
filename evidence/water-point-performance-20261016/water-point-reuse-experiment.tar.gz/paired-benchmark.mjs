import assert from 'node:assert/strict'
import { readFileSync, existsSync, realpathSync, statfsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { registerHooks } from 'node:module'
import { pathToFileURL, fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'
import os from 'node:os'

const root = process.env.BENCH_SOURCE_ROOT
assert.ok(root, 'BENCH_SOURCE_ROOT must name a prepared snapshot')
const snapshot = JSON.parse(readFileSync('/workspace/scratch/69fd8163d94e/water-point-474-second/snapshot-manifest.json', 'utf8'))
assert.ok([snapshot.baseline, snapshot.candidate].includes(root), 'Unknown snapshot')
const variant = root === snapshot.baseline ? 'baseline' : 'candidate'
const expectedFiles = variant === 'baseline' ? snapshot.files : snapshot.candidateFiles
const git = '/tmp/selector-scene457/git-bin/git'
const config = { mission: 1, warmups: 256, repetitions: 512, phaseChecks: 256,
  sourceRoot: root, processIndex: Number(process.env.BENCH_PROCESS_INDEX ?? 0),
  cases: ['changed-turn', 'same-key'], variant, benchmark: 'production-updateWater-point-reuse-v1' }
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const fingerprints = new Map()
function remember(path) {
  path = realpathSync(path)
  const digest = hash(readFileSync(path))
  if (fingerprints.has(path)) assert.equal(digest, fingerprints.get(path), `Input changed during loading: ${path}`)
  else fingerprints.set(path, digest)
}
const fixed = ['package.json', 'package-lock.json', 'app/scene.ts',
  'app/scene-terrain-runtime.ts', 'app/water.ts', 'app/projection.ts',
  'tests/support/bloodlust-scene.mjs', 'tests/support/world-environment-scene.mjs',
  'tests/water-animation-callers.test.mjs']
for (const [file, digest] of Object.entries(expectedFiles)) {
  assert.equal(hash(readFileSync(`${root}/${file}`)), digest, `Snapshot drift: ${file}`)
}
for (const file of fixed) assert.ok(existsSync(`${root}/${file}`), `Missing ${file}`)
assert.ok(Number.isInteger(config.processIndex) && config.processIndex >= 0)
const available = statfsSync('/tmp'); assert.ok(available.bsize * available.bavail > 2 * 1024 * 1024)
if (process.argv.includes('--validate-config')) {
  console.log(JSON.stringify({ type: 'configuration', status: 'valid', ...config,
    node: process.version, note: 'No production imports, fixture execution or timing performed.' }))
  process.exit(0)
}
assert.deepEqual(process.argv.slice(2), ['--run'], 'Explicit --run required')
for (const file of Object.keys(expectedFiles)) remember(`${root}/${file}`)
remember(fileURLToPath(import.meta.url))
// Register before the existing fixture hooks so every resolution is fingerprinted,
// including source returned by the fixture transpiler instead of the default loader.
registerHooks({ resolve(specifier, context, next) {
  const result = next(specifier, context)
  if (result.url.startsWith('file:')) remember(fileURLToPath(result.url))
  return result
} })
const source = { baselineCommit: snapshot.baselineCommit, capturedFromHead: snapshot.capturedFromHead,
  variant, candidatePatchSha256: variant === 'candidate' ? snapshot.patchSha256 : null }
const dirty = 'Verified prepared snapshot; not a Git checkout'
const start = performance.now()
const { loadSceneFixture } = await import(pathToFileURL(`${root}/tests/support/bloodlust-scene.mjs`))
const { bindSceneEnvironment } = await import(pathToFileURL(`${root}/tests/support/world-environment-scene.mjs`))
const api = await loadSceneFixture()
const { GameScene } = await import(pathToFileURL(`${root}/app/scene.ts`))
const { initializeTerrain } = await import(pathToFileURL(`${root}/app/scene-terrain-runtime.ts`))
const THREE = await import(pathToFileURL(`${root}/node_modules/three/build/three.module.js`))
const importsMs = performance.now() - start
const originalFetch = globalThis.fetch
const assets = []
globalThis.fetch = async url => {
  assert.ok(typeof url === 'string' && url.startsWith('/original/') && !url.includes('..'))
  const path = `${root}/public${url}`; remember(path); assets.push(path)
  const bytes = readFileSync(path)
  return { ok: true, arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) }
}
const noop = () => {}
const world = api.createWorld(config.mission)
const scene = Object.assign(Object.create(GameScene.prototype), {
  world, terrainLoad: new AbortController(), terrainMap: new THREE.DataTexture(),
  waterMap: new THREE.DataTexture(new Uint8Array(256 * 256 * 4), 256, 256),
  waterScroll: { value: 0 }, updateTerrainTexture: noop, updateView: noop,
  view: {}, decorations: new THREE.Group(),
})
const setupStart = performance.now()
await bindSceneEnvironment(scene)
const initialized = initializeTerrain(scene); scene.terrain = initialized.terrain
await initialized.ready; scene.rebuildTerrain()
globalThis.fetch = originalFetch
const setupMs = performance.now() - setupStart
const attributes = scene.terrain.geometry.attributes
assert.equal(attributes.position.count, 98304)
const bytes = array => Buffer.from(array.buffer, array.byteOffset, array.byteLength)
const mutableNames = ['position', 'light', 'highlight']
const output = () => Object.fromEntries(mutableNames.map(n => [n, hash(bytes(attributes[n].array))]))
const invariant = () => ({ uv: hash(bytes(attributes.uv.array)), landUv: hash(bytes(attributes.landUv.array)),
  surface: hash(bytes(attributes.surface.array)), waterTexture: hash(bytes(scene.waterMap.image.data)),
  land: Object.fromEntries(Object.entries(world.land).filter(([,v]) => ArrayBuffer.isView(v)).map(([k,v]) => [k, hash(bytes(v))])),
  waves: hash(bytes(scene.waves)) })
const immutable = invariant(), phaseHashes = []
for (let turn = 0; turn < 256; turn++) {
  world.turn = turn; const versions = mutableNames.map(n => attributes[n].version)
  scene.updateWater()
  mutableNames.forEach((n,i) => assert.equal(attributes[n].version, versions[i]+1))
  phaseHashes.push(output())
}
world.turn = 256; scene.updateWater(); assert.deepEqual(output(), phaseHashes[0])
assert.notEqual(phaseHashes[23].position, phaseHashes[0].position)
assert.notEqual(phaseHashes[23].light, phaseHashes[0].light)
const shared = new Map()
for (let i=0; i<attributes.position.count; i++) {
  const p=attributes.position, key=`${p.getX(i)},${p.getZ(i)}`
  if (shared.has(key)) assert.equal(p.getY(i), shared.get(key)); else shared.set(key,p.getY(i))
}
assert.deepEqual(invariant(), immutable)
const rows = [], memory = []
let turn = 256
for (const name of config.cases) {
  for (let i=0; i<config.warmups; i++) { if (name==='changed-turn') world.turn=++turn; scene.updateWater() }
  const versions=mutableNames.map(n=>attributes[n].version)
  memory.push({ type:'memory', case:name, point:'before', ...process.memoryUsage(), usage:process.resourceUsage() })
  const elapsed = new Array(config.repetitions), cpuStart=process.cpuUsage()
  for (let i=0; i<config.repetitions; i++) {
    if (name==='changed-turn') world.turn=++turn
    const before=process.hrtime.bigint(); scene.updateWater(); elapsed[i]=Number(process.hrtime.bigint()-before)
  }
  const cpu=process.cpuUsage(cpuStart)
  memory.push({ type:'memory', case:name, point:'after', ...process.memoryUsage(), usage:process.resourceUsage(), timedCpu:cpu })
  mutableNames.forEach((n,i)=>assert.equal(attributes[n].version,versions[i]+(name==='changed-turn'?config.repetitions:0)))
  assert.deepEqual(output(), phaseHashes[world.turn & 255]); assert.deepEqual(invariant(),immutable)
  elapsed.forEach((ns,i)=>rows.push({type:'sample',case:name,repetition:i,turn:name==='changed-turn'?turn-config.repetitions+i+1:turn,ns}))
}
const mismatches=[]
for (const [path,digest] of fingerprints) if (hash(readFileSync(path))!==digest) mismatches.push(path)
assert.deepEqual(mismatches,[], 'Loaded dependency changed during benchmark')
const categoryCounts={}; for (const value of world.land.categories) categoryCounts[value & 15]=(categoryCounts[value & 15]??0)+1
console.log(JSON.stringify({type:'manifest',...config,source,dirty,versions:process.versions,flags:process.execArgv,
  cpu:os.cpus()[0]?.model,logicalCpus:os.cpus().length,totalMemory:os.totalmem(),platform:os.platform(),release:os.release(),
  importsMs,setupMs,assets,vertexCount:attributes.position.count,categoryCounts,
  caveats:['Node CPU-side preparation only; no browser, GPU upload, render, FPS or speedup claim.',
    'VM CPU quota/contention unknown. Memory snapshots do not measure allocation rate.'],
  fingerprints:Object.fromEntries(fingerprints)}))
for(const row of [...memory,...rows]) console.log(JSON.stringify({...row,processIndex:config.processIndex}))
console.log(JSON.stringify({type:'correctness',status:'pass',phaseHashes,invariant:immutable,dependenciesStable:true}))
for(const name of config.cases) {
  const samples=rows.filter(r=>r.case===name).map(r=>r.ns).sort((a,b)=>a-b)
  const p=q=>samples[Math.ceil(samples.length*q)-1]
  console.log(JSON.stringify({type:'summary',case:name,processIndex:config.processIndex,count:samples.length,
    medianNs:(samples[255]+samples[256])/2,p95Ns:p(.95),p99Ns:p(.99),maxNs:p(1),totalNs:samples.reduce((a,b)=>a+b,0)}))
}
scene.terrain.geometry.dispose(); scene.terrain.material.dispose(); scene.terrainMap.dispose(); scene.waterMap.dispose()
