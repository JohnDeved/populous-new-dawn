from pathlib import Path
import json,hashlib,statistics
p=Path(__file__).parent
out={'interpretation':'Diagnostic correlation only; not primary performance evidence. Process CPU includes helper threads. Unobserved GC cannot be ruled out.','runs':[]}
for filename in ['diagnostic-thread-1-candidate.jsonl','diagnostic-thread-2-baseline.jsonl']:
 f=p/filename;r=[json.loads(x) for x in f.read_text().splitlines()];m=next(x for x in r if x['type']=='manifest');correct=next(x for x in r if x['type']=='correctness');assert correct['status']=='pass' and correct['dependenciesStable']
 s=[x for x in r if x['type']=='sample' and x['case']=='changed-turn'];g=[x for x in r if x['type']=='gc'];b=[x for x in r if x['type']=='diagnostic-block' and x['case']=='changed-turn'];c=[x for x in r if x['type']=='overhead-control']
 assert len(s)==512 and len(b)==8
 for x in s:
  assert x['overlappingGcEvents']==[i for i,e in enumerate(g) if e['startMs']<x['intervalEndMs'] and e['endMs']>x['intervalStartMs']]
 out['runs'].append({'file':filename,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'variant':m['variant'],'gcEventsObserved':len(g),'changedCallsWithGcOverlap':sum(bool(x['overlappingGcEvents']) for x in s),'callsOver10ms':sum(x['ns']>1e7 for x in s),'callsOver10msWithGcOverlap':sum(x['ns']>1e7 and bool(x['overlappingGcEvents']) for x in s),'topTenCalls':sorted(s,key=lambda x:-x['ns'])[:10],'blocks':b,'controls':[{'point':x['point'],'instrumented':x['instrumented'],'count':x['count'],'wallMicrosecondsPerIteration':x['totalWallMs']*1000/x['count'],'medianInnerTimerNs':statistics.median(x['timerSamplesNs'])} for x in c]})
(p/'diagnostic-thread-summary.json').write_text(json.dumps(out,indent=2)+'\n')
(p/'diagnostic-thread-execution-receipt.json').write_text(json.dumps({'candidateExit':0,'baselineExit':0,'mode':'block','timeoutSecondsPerProcess':120,'preRunAvailableBytes':{'tmp':152145920,'workspace':294756352},'note':'Execution tools reported terminal exit zero for both serial processes. Lane released after baseline completion. No per-sample mode run.'},indent=2)+'\n')
