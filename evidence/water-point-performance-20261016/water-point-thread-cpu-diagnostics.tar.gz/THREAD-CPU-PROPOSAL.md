# Main-thread CPU diagnostic proposal (not executed)

Preserve the published v1 diagnostic unchanged. The separate diagnostic-thread-cpu-v2.mjs adds exactly one process.threadCpuUsage start/delta pair around each existing 64-call block, beside process CPU. It asserts API availability and reports raw user/system microseconds, process CPU, wall interval and existing context switches. No per-call CPU reads, yields, forced GC or production changes. Existing phase/archive/input/source/version assertions remain intact.

Interpretation: a material wall-minus-current-thread-CPU gap may identify time outside accounted main-thread execution, but cannot distinguish descheduling, blocking, quota or GC coordination. Near equality cannot distinguish JavaScript, native, JIT or GC work. Process CPU includes other threads; thread CPU does not. The intervals differ by endpoint call overhead and must not be treated as exact simultaneous measurements. Existing empty-body controls remain; two extra block boundary calls are an additional unmeasured overhead until execution, not grounds for correcting primary timings.

Proposed command, only after root approves and reviewer accepts:
BENCH_SOURCE_ROOT=/tmp/water-point-474-source/candidate DIAGNOSTIC_MODE=block BENCH_PROCESS_INDEX=1 timeout 120s node /workspace/scratch/69fd8163d94e/water-point-474-second/diagnostic-thread-cpu-v2.mjs --run > diagnostic-thread-1-candidate.jsonl 2> diagnostic-thread-1-candidate.stderr

One matching baseline process may follow only within root-authorized scope. Reserve 2 MiB on the output filesystem per process and retain the existing /tmp source guard. Previous v1 took approximately 13 seconds per process; v2 cost is not measured. No syntax/configuration check or run has occurred. Stop on API, source, correctness, timeout or resource failure. No primary speed, causal or FPS claim.
