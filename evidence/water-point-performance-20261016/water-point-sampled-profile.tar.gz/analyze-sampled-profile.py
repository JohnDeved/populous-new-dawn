import json,pathlib,hashlib,collections
p=pathlib.Path(__file__).parent
ref=next(x for x in map(json.loads,open('/tmp/water-baseline-474/run-1.jsonl')) if x['type']=='correctness')
results=[]
for tag in ['1-candidate','2-baseline']:
 r=list(map(json.loads,(p/f'profile-{tag}.jsonl').open()));a=json.load((p/f'profile-{tag}.cpuprofile').open());m=next(x for x in r if x['type']=='manifest');c=next(x for x in r if x['type']=='correctness');q=next(x for x in r if x['type']=='cpu-profile');assert c['phaseHashes']==ref['phaseHashes'] and c['invariant']==ref['invariant'] and c['dependenciesStable'];assert all(hashlib.sha256(pathlib.Path(k).read_bytes()).hexdigest()==v for k,v in m['fingerprints'].items());assert len(a['samples'])==len(a['timeDeltas'])==q['samples']
 s=[x for x in r if x['type']=='sample' and x['case']=='changed-turn'];b=[x for x in r if x['type']=='diagnostic-block' and x['case']=='changed-turn'];assert len(s)==512 and len(b)==8
 for case in ['changed-turn','same-key']:
  vals=sorted(x['ns'] for x in r if x['type']=='sample' and x['case']==case);z=next(x for x in r if x['type']=='summary' and x['case']==case);assert z['medianNs']==(vals[255]+vals[256])/2 and z['p95Ns']==vals[486] and z['p99Ns']==vals[506] and z['maxNs']==vals[-1] and z['totalNs']==sum(vals)
 # Offset intersection assumes inspector start/end timestamps occur within their request brackets and common monotonic rate; no assumption of common numeric origin.
 lo=max(q['profileStartBeforeMs']-a['startTime']/1000,q['profileStopBeforeMs']-a['endTime']/1000);hi=min(q['profileStartAfterMs']-a['startTime']/1000,q['profileStopAfterMs']-a['endTime']/1000);assert lo<=hi
 nodes={x['id']:x for x in a['nodes']};parents={k:x['id'] for x in a['nodes'] for k in x.get('children',[])};points=[];t=a['startTime']/1000
 for id,dt in zip(a['samples'],a['timeDeltas']):
  prev=t;t+=dt/1000;points.append((prev,t,id,dt/1000))
 regions=[]
 for label,start,end in [('all',b[0]['blockStartMs'],b[-1]['blockEndMs']),('first256',b[0]['blockStartMs'],b[3]['blockEndMs']),('last256',b[4]['blockStartMs'],b[7]['blockEndMs'])]:
  weights=collections.Counter();inc=collections.Counter();count=0
  for left,right,id,w in points:
   if left+lo>=start and right+hi<=end:
    count+=1;weights[nodes[id]['callFrame']['functionName']]+=w
    seen=set()
    while id in nodes:
     seen.add(nodes[id]['callFrame']['functionName']);id=parents.get(id)
    for name in seen:inc[name]+=w
  regions.append(dict(region=label,sampleCount=count,coveredWeightedMs=sum(weights.values()),selfMs=weights.most_common(10),inclusiveMs=inc.most_common(10)))
 out=dict(variant=tag,verified=True,hashes=len(m['fingerprints']),samples=len(points),profileSpanMs=(a['endTime']-a['startTime'])/1000,deltaSumMs=sum(a['timeDeltas'])/1000,maxDeltaMs=max(a['timeDeltas'])/1000,clockOffsetLowerMs=lo,clockOffsetUpperMs=hi,alignmentWidthMs=hi-lo,startRequestMs=q['profileStartAfterMs']-q['profileStartBeforeMs'],stopRequestMs=q['profileStopAfterMs']-q['profileStopBeforeMs'],summary=next(x for x in r if x['type']=='summary' and x['case']=='changed-turn'),regions=regions)
 results.append(out)
(p/'sampled-profile-analysis.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
