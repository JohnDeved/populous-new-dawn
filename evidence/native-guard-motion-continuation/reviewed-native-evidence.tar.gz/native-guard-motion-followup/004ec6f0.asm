004ec6f0 f60561c6890002           test byte ptr [0x89c661], 2
004ec6f7 53                       push ebx
004ec6f8 56                       push esi
004ec6f9 57                       push edi
004ec6fa 55                       push ebp
004ec6fb 0f853a030000             jne 0x4eca3b
004ec701 33d2                     xor edx, edx
004ec703 ff0588d18900             inc dword ptr [0x89d188]
004ec709 881567d18900             mov byte ptr [0x89d167], dl
004ec70f 3815bfea9600             cmp byte ptr [0x96eabf], dl
004ec715 7621                     jbe 0x4ec738
004ec717 b8ecdd8900               mov eax, 0x89ddec
004ec71c 8a08                     mov cl, byte ptr [eax]
004ec71e 84c9                     test cl, cl
004ec720 7404                     je 0x4ec726
004ec722 fec9                     dec cl
004ec724 8808                     mov byte ptr [eax], cl
004ec726 05650c0000               add eax, 0xc65
004ec72b 42                       inc edx
004ec72c 33c9                     xor ecx, ecx
004ec72e 8a0dbfea9600             mov cl, byte ptr [0x96eabf]
004ec734 3bca                     cmp ecx, edx
004ec736 7fe4                     jg 0x4ec71c
004ec738 b8b6579500               mov eax, 0x9557b6
004ec73d 33c9                     xor ecx, ecx
004ec73f 8b1580f46400             mov edx, dword ptr [0x64f480]
004ec745 8b1d90f46400             mov ebx, dword ptr [0x64f490]
004ec74b 8908                     mov dword ptr [eax], ecx
004ec74d 011594f46400             add dword ptr [0x64f494], edx
004ec753 894804                   mov dword ptr [eax + 4], ecx
004ec756 011d9cf46400             add dword ptr [0x64f49c], ebx
004ec75c a184f46400               mov eax, dword ptr [0x64f484]
004ec761 890d80f46400             mov dword ptr [0x64f480], ecx
004ec767 010598f46400             add dword ptr [0x64f498], eax
004ec76d 890d84f46400             mov dword ptr [0x64f484], ecx
004ec773 890d88f46400             mov dword ptr [0x64f488], ecx
004ec779 890d8cf46400             mov dword ptr [0x64f48c], ecx
004ec77f 890d90f46400             mov dword ptr [0x64f490], ecx
004ec785 880d60ce8900             mov byte ptr [0x89ce60], cl
004ec78b f60566c6890002           test byte ptr [0x89c666], 2
004ec792 7513                     jne 0x4ec7a7
004ec794 f6057cd1890020           test byte ptr [0x89d17c], 0x20
004ec79b 750a                     jne 0x4ec7a7
004ec79d e88ec6f2ff               call 0x418e30
004ec7a2 e89987ffff               call 0x4e4f40
004ec7a7 bec8d18900               mov esi, 0x89d1c8
004ec7ac e87feaf2ff               call 0x41b230
004ec7b1 bd04000000               mov ebp, 4
004ec7b6 e8f5a5f4ff               call 0x436db0
004ec7bb e83073faff               call 0x493af0
004ec7c0 e8ebfbffff               call 0x4ec3b0
004ec7c5 8b868d080000             mov eax, dword ptr [esi + 0x88d]
004ec7cb 85c0                     test eax, eax
004ec7cd 7419                     je 0x4ec7e8
004ec7cf 33db                     xor ebx, ebx
004ec7d1 8b7808                   mov edi, dword ptr [eax + 8]
004ec7d4 38582a                   cmp byte ptr [eax + 0x2a], bl
004ec7d7 7409                     je 0x4ec7e2
004ec7d9 50                       push eax
004ec7da e821480100               call 0x501000
004ec7df 83c404                   add esp, 4
004ec7e2 8bc7                     mov eax, edi
004ec7e4 85ff                     test edi, edi
004ec7e6 75e9                     jne 0x4ec7d1
004ec7e8 81c6650c0000             add esi, 0xc65
004ec7ee 4d                       dec ebp
004ec7ef 75d4                     jne 0x4ec7c5
004ec7f1 a15c038900               mov eax, dword ptr [0x89035c]
004ec7f6 85c0                     test eax, eax
004ec7f8 7412                     je 0x4ec80c
004ec7fa 8b7008                   mov esi, dword ptr [eax + 8]
004ec7fd 50                       push eax
004ec7fe e82dbe0200               call 0x518630
004ec803 83c404                   add esp, 4
004ec806 8bc6                     mov eax, esi
004ec808 85f6                     test esi, esi
004ec80a 75ee                     jne 0x4ec7fa
004ec80c 6a00                     push 0
004ec80e e83dd6f9ff               call 0x489e50
004ec813 83c404                   add esp, 4
004ec816 8b3558038900             mov esi, dword ptr [0x890358]
004ec81c 85f6                     test esi, esi
004ec81e 746e                     je 0x4ec88e
004ec820 33db                     xor ebx, ebx
004ec822 bd00800000               mov ebp, 0x8000
004ec827 8b7e08                   mov edi, dword ptr [esi + 8]
004ec82a 381d60ce8900             cmp byte ptr [0x89ce60], bl
004ec830 7544                     jne 0x4ec876
004ec832 a0f0c68900               mov al, byte ptr [0x89c6f0]
004ec837 384669                   cmp byte ptr [esi + 0x69], al
004ec83a 7405                     je 0x4ec841
004ec83c 38466a                   cmp byte ptr [esi + 0x6a], al
004ec83f 7535                     jne 0x4ec876
004ec841 c60560ce890001           mov byte ptr [0x89ce60], 1
004ec848 8d463d                   lea eax, [esi + 0x3d]
004ec84b 50                       push eax
004ec84c e8ff83f1ff               call 0x404c50
004ec851 66a3e5c68900             mov word ptr [0x89c6e5], ax
004ec857 83c404                   add esp, 4
004ec85a 0fbe05f0c68900           movsx eax, byte ptr [0x89c6f0]
004ec861 8bc8                     mov ecx, eax
004ec863 8d1480                   lea edx, [eax + eax*4]
004ec866 8d0451                   lea eax, [ecx + edx*2]
004ec869 8d14c0                   lea edx, [eax + eax*8]
004ec86c 8d04d1                   lea eax, [ecx + edx*8]
004ec86f 09ac8105db8900           or dword ptr [ecx + eax*4 + 0x89db05], ebp
004ec876 56                       push esi
004ec877 e834c70200               call 0x518fb0
004ec87c 83c404                   add esp, 4
004ec87f 56                       push esi
004ec880 e8cbd5f9ff               call 0x489e50
004ec885 83c404                   add esp, 4
004ec888 8bf7                     mov esi, edi
004ec88a 85ff                     test edi, edi
004ec88c 7599                     jne 0x4ec827
004ec88e 6a01                     push 1
004ec890 e8bbd5f9ff               call 0x489e50
004ec895 83c404                   add esp, 4
004ec898 a124038900               mov eax, dword ptr [0x890324]
004ec89d 830d69c6890040           or dword ptr [0x89c669], 0x40
004ec8a4 85c0                     test eax, eax
004ec8a6 741c                     je 0x4ec8c4
004ec8a8 33db                     xor ebx, ebx
004ec8aa 8b7004                   mov esi, dword ptr [eax + 4]
004ec8ad 38582c                   cmp byte ptr [eax + 0x2c], bl
004ec8b0 740c                     je 0x4ec8be
004ec8b2 50                       push eax
004ec8b3 fe402e                   inc byte ptr [eax + 0x2e]
004ec8b6 e8450e0000               call 0x4ed700
004ec8bb 83c404                   add esp, 4
004ec8be 8bc6                     mov eax, esi
004ec8c0 85f6                     test esi, esi
004ec8c2 75e6                     jne 0x4ec8aa
004ec8c4 832569c68900bf           and dword ptr [0x89c669], 0xffffffbf
004ec8cb a160038900               mov eax, dword ptr [0x890360]
004ec8d0 85c0                     test eax, eax
004ec8d2 7446                     je 0x4ec91a
004ec8d4 8b7008                   mov esi, dword ptr [eax + 8]
004ec8d7 33c9                     xor ecx, ecx
004ec8d9 8a482a                   mov cl, byte ptr [eax + 0x2a]
004ec8dc 83e902                   sub ecx, 2
004ec8df 83f908                   cmp ecx, 8
004ec8e2 7730                     ja 0x4ec914
004ec8e4 33d2                     xor edx, edx
004ec8e6 8a9180ca4e00             mov dl, byte ptr [ecx + 0x4eca80]
004ec8ec ff24956cca4e00           jmp dword ptr [edx*4 + 0x4eca6c]
004ec8f3 50                       push eax
004ec8f4 e88769f1ff               call 0x403280
004ec8f9 eb16                     jmp 0x4ec911
004ec8fb 50                       push eax
004ec8fc e8dfc5f8ff               call 0x478ee0
004ec901 eb0e                     jmp 0x4ec911
004ec903 50                       push eax
004ec904 e827f6fcff               call 0x4bbf30
004ec909 eb06                     jmp 0x4ec911
004ec90b 50                       push eax
004ec90c e89f5f0100               call 0x5028b0
004ec911 83c404                   add esp, 4
004ec914 8bc6                     mov eax, esi
004ec916 85f6                     test esi, esi
004ec918 75ba                     jne 0x4ec8d4
004ec91a e8d12e0000               call 0x4ef7f0
004ec91f e83c3b0000               call 0x4f0460
004ec924 a130038900               mov eax, dword ptr [0x890330]
004ec929 85c0                     test eax, eax
004ec92b 7415                     je 0x4ec942
004ec92d 8b7004                   mov esi, dword ptr [eax + 4]
004ec930 50                       push eax
004ec931 fe402e                   inc byte ptr [eax + 0x2e]
004ec934 e8c70d0000               call 0x4ed700
004ec939 83c404                   add esp, 4
004ec93c 8bc6                     mov eax, esi
004ec93e 85f6                     test esi, esi
004ec940 75eb                     jne 0x4ec92d
004ec942 e879010000               call 0x4ecac0
004ec947 e8044af1ff               call 0x401350
004ec94c 833d2803890000           cmp dword ptr [0x890328], 0
004ec953 7438                     je 0x4ec98d
004ec955 8b3d28038900             mov edi, dword ptr [0x890328]
004ec95b be80020000               mov esi, 0x280
004ec960 8b5f04                   mov ebx, dword ptr [edi + 4]
004ec963 fe4f2e                   dec byte ptr [edi + 0x2e]
004ec966 751f                     jne 0x4ec987
004ec968 83670cfe                 and dword ptr [edi + 0xc], 0xfffffffe
004ec96c 57                       push edi
004ec96d e8ce51f1ff               call 0x401b40
004ec972 83c404                   add esp, 4
004ec975 ff0d51c68900             dec dword ptr [0x89c651]
004ec97b 66397724                 cmp word ptr [edi + 0x24], si
004ec97f 7306                     jae 0x4ec987
004ec981 ff0d59c68900             dec dword ptr [0x89c659]
004ec987 8bfb                     mov edi, ebx
004ec989 85db                     test ebx, ebx
004ec98b 75d3                     jne 0x4ec960
