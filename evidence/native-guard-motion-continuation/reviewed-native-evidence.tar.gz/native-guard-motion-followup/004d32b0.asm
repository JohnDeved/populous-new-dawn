004d32b0 83ec08                   sub esp, 8
004d32b3 53                       push ebx
004d32b4 56                       push esi
004d32b5 8b742414                 mov esi, dword ptr [esp + 0x14]
004d32b9 57                       push edi
004d32ba 56                       push esi
004d32bb e8e00f0000               call 0x4d42a0
004d32c0 83c404                   add esp, 4
004d32c3 56                       push esi
004d32c4 e807cc0400               call 0x51fed0
004d32c9 83c404                   add esp, 4
004d32cc 56                       push esi
004d32cd e87e5d0100               call 0x4e9050
004d32d2 83c404                   add esp, 4
004d32d5 56                       push esi
004d32d6 e8253a0100               call 0x4e6d00
004d32db 83c404                   add esp, 4
004d32de 6683be9f00000000         cmp word ptr [esi + 0x9f], 0
004d32e6 7413                     je 0x4d32fb
004d32e8 8b460c                   mov eax, dword ptr [esi + 0xc]
004d32eb 25ffdfffff               and eax, 0xffffdfff
004d32f0 89460c                   mov dword ptr [esi + 0xc], eax
004d32f3 25fffff7ff               and eax, 0xfff7ffff
004d32f8 89460c                   mov dword ptr [esi + 0xc], eax
004d32fb 8b5614                   mov edx, dword ptr [esi + 0x14]
004d32fe f7c200000100             test edx, 0x10000
004d3304 7435                     je 0x4d333b
004d3306 668b4672                 mov ax, word ptr [esi + 0x72]
004d330a 33c9                     xor ecx, ecx
004d330c 663bc1                   cmp ax, cx
004d330f 7417                     je 0x4d3328
004d3311 0fb7c0                   movzx eax, ax
004d3314 8b048590038900           mov eax, dword ptr [eax*4 + 0x890390]
004d331b f6400c01                 test byte ptr [eax + 0xc], 1
004d331f 7507                     jne 0x4d3328
004d3321 38482a                   cmp byte ptr [eax + 0x2a], cl
004d3324 7402                     je 0x4d3328
004d3326 8bc8                     mov ecx, eax
004d3328 85c9                     test ecx, ecx
004d332a 750f                     jne 0x4d333b
004d332c 66c746720000             mov word ptr [esi + 0x72], 0
004d3332 81e2fffffeff             and edx, 0xfffeffff
004d3338 895614                   mov dword ptr [esi + 0x14], edx
004d333b 6a01                     push 1
004d333d 56                       push esi
004d333e e82dcf0000               call 0x4e0270
004d3343 83c408                   add esp, 8
004d3346 8a4e2b                   mov cl, byte ptr [esi + 0x2b]
004d3349 80f905                   cmp cl, 5
004d334c 7520                     jne 0x4d336e
004d334e 8a9eb2000000             mov bl, byte ptr [esi + 0xb2]
004d3354 8ac3                     mov al, bl
004d3356 243f                     and al, 0x3f
004d3358 7414                     je 0x4d336e
004d335a 33d2                     xor edx, edx
004d335c 8ad0                     mov dl, al
004d335e 4a                       dec edx
004d335f 7902                     jns 0x4d3363
004d3361 33d2                     xor edx, edx
004d3363 80e3c0                   and bl, 0xc0
004d3366 0ada                     or bl, dl
004d3368 889eb2000000             mov byte ptr [esi + 0xb2], bl
004d336e 8a5e2c                   mov bl, byte ptr [esi + 0x2c]
004d3371 33c0                     xor eax, eax
004d3373 8ac3                     mov al, bl
004d3375 48                       dec eax
004d3376 83f82b                   cmp eax, 0x2b
004d3379 0f8760070000             ja 0x4d3adf
004d337f ff2485183d4d00           jmp dword ptr [eax*4 + 0x4d3d18]
004d3386 668b4670                 mov ax, word ptr [esi + 0x70]
004d338a 32db                     xor bl, bl
004d338c 6648                     dec ax
004d338e 66894670                 mov word ptr [esi + 0x70], ax
004d3392 6685c0                   test ax, ax
004d3395 7e0d                     jle 0x4d33a4
004d3397 f7460c04200000           test dword ptr [esi + 0xc], 0x2004
004d339e 0f843d070000             je 0x4d3ae1
004d33a4 f6057cd1890002           test byte ptr [0x89d17c], 2
004d33ab 7422                     je 0x4d33cf
004d33ad 80f907                   cmp cl, 7
004d33b0 7507                     jne 0x4d33b9
004d33b2 b327                     mov bl, 0x27
004d33b4 e928070000               jmp 0x4d3ae1
004d33b9 33c0                     xor eax, eax
004d33bb 8ac1                     mov al, cl
004d33bd 8d0c80                   lea ecx, [eax + eax*4]
004d33c0 8d1489                   lea edx, [ecx + ecx*4]
004d33c3 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d33ca e912070000               jmp 0x4d3ae1
004d33cf 33c0                     xor eax, eax
004d33d1 8ac1                     mov al, cl
004d33d3 8d0c80                   lea ecx, [eax + eax*4]
004d33d6 8d1489                   lea edx, [ecx + ecx*4]
004d33d9 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d33e0 e9fc060000               jmp 0x4d3ae1
004d33e5 56                       push esi
004d33e6 e875270000               call 0x4d5b60
004d33eb 83c404                   add esp, 4
004d33ee 8ad8                     mov bl, al
004d33f0 e9ec060000               jmp 0x4d3ae1
004d33f5 56                       push esi
004d33f6 e8f5280000               call 0x4d5cf0
004d33fb 83c404                   add esp, 4
004d33fe 8ad8                     mov bl, al
004d3400 e9dc060000               jmp 0x4d3ae1
004d3405 66ff4e70                 dec word ptr [esi + 0x70]
004d3409 0f89d0060000             jns 0x4d3adf
004d340f 56                       push esi
004d3410 e8ab340000               call 0x4d68c0
004d3415 e9c2060000               jmp 0x4d3adc
004d341a 56                       push esi
004d341b e850350000               call 0x4d6970
004d3420 83c404                   add esp, 4
004d3423 8ad8                     mov bl, al
004d3425 e9b7060000               jmp 0x4d3ae1
004d342a 32db                     xor bl, bl
004d342c 56                       push esi
004d342d e8ae320000               call 0x4d66e0
004d3432 83c404                   add esp, 4
004d3435 85c0                     test eax, eax
004d3437 0f85a4060000             jne 0x4d3ae1
004d343d 668b4670                 mov ax, word ptr [esi + 0x70]
004d3441 6648                     dec ax
004d3443 66894670                 mov word ptr [esi + 0x70], ax
004d3447 6685c0                   test ax, ax
004d344a 7e5f                     jle 0x4d34ab
004d344c 8d7e4f                   lea edi, [esi + 0x4f]
004d344f 57                       push edi
004d3450 e8fb1bf3ff               call 0x405050
004d3455 83c404                   add esp, 4
004d3458 8a400c                   mov al, byte ptr [eax + 0xc]
004d345b 240f                     and al, 0xf
004d345d 33c9                     xor ecx, ecx
004d345f 8ac8                     mov cl, al
004d3461 8bc1                     mov eax, ecx
004d3463 c1e103                   shl ecx, 3
004d3466 2bc8                     sub ecx, eax
004d3468 f6044d28a35a003c         test byte ptr [ecx*2 + 0x5aa328], 0x3c
004d3470 7429                     je 0x4d349b
004d3472 8d463d                   lea eax, [esi + 0x3d]
004d3475 6a02                     push 2
004d3477 57                       push edi
004d3478 6a38                     push 0x38
004d347a 50                       push eax
004d347b e820f9f5ff               call 0x432da0
004d3480 83c410                   add esp, 0x10
004d3483 84c0                     test al, al
004d3485 0f8456060000             je 0x4d3ae1
004d348b 56                       push esi
004d348c b310                     mov bl, 0x10
004d348e e8dd130000               call 0x4d4870
004d3493 83c404                   add esp, 4
004d3496 e946060000               jmp 0x4d3ae1
004d349b 56                       push esi
004d349c e88ff9f2ff               call 0x402e30
004d34a1 83c404                   add esp, 4
004d34a4 8ad8                     mov bl, al
004d34a6 e936060000               jmp 0x4d3ae1
004d34ab 56                       push esi
004d34ac e87ff9f2ff               call 0x402e30
004d34b1 83c404                   add esp, 4
004d34b4 8ad8                     mov bl, al
004d34b6 e926060000               jmp 0x4d3ae1
004d34bb 668b4670                 mov ax, word ptr [esi + 0x70]
004d34bf 32db                     xor bl, bl
004d34c1 6648                     dec ax
004d34c3 66894670                 mov word ptr [esi + 0x70], ax
004d34c7 6685c0                   test ax, ax
004d34ca 7e1d                     jle 0x4d34e9
004d34cc f6462e03                 test byte ptr [esi + 0x2e], 3
004d34d0 0f850b060000             jne 0x4d3ae1
004d34d6 68ef288900               push 0x8928ef
004d34db 56                       push esi
004d34dc e89f680100               call 0x4e9d80
004d34e1 83c408                   add esp, 8
004d34e4 e9f8050000               jmp 0x4d3ae1
004d34e9 56                       push esi
004d34ea e841f9f2ff               call 0x402e30
004d34ef 83c404                   add esp, 4
004d34f2 8ad8                     mov bl, al
004d34f4 e9e8050000               jmp 0x4d3ae1
004d34f9 56                       push esi
004d34fa e8d12b0000               call 0x4d60d0
004d34ff 83c404                   add esp, 4
004d3502 8ad8                     mov bl, al
004d3504 e9d8050000               jmp 0x4d3ae1
004d3509 56                       push esi
004d350a e8d1490000               call 0x4d7ee0
004d350f 83c404                   add esp, 4
004d3512 8ad8                     mov bl, al
004d3514 e9c8050000               jmp 0x4d3ae1
004d3519 56                       push esi
004d351a e871f0f5ff               call 0x432590
004d351f 83c404                   add esp, 4
004d3522 8ad8                     mov bl, al
004d3524 e9b8050000               jmp 0x4d3ae1
004d3529 32db                     xor bl, bl
004d352b 56                       push esi
004d352c e8df350000               call 0x4d6b10
004d3531 83c404                   add esp, 4
004d3534 f6460d20                 test byte ptr [esi + 0xd], 0x20
004d3538 0f84a3050000             je 0x4d3ae1
004d353e f6057cd1890002           test byte ptr [0x89d17c], 2
004d3545 7424                     je 0x4d356b
004d3547 8a462b                   mov al, byte ptr [esi + 0x2b]
004d354a 3c07                     cmp al, 7
004d354c 7507                     jne 0x4d3555
004d354e b327                     mov bl, 0x27
004d3550 e98c050000               jmp 0x4d3ae1
004d3555 33c9                     xor ecx, ecx
004d3557 8ac8                     mov cl, al
004d3559 8d0489                   lea eax, [ecx + ecx*4]
004d355c 8d1480                   lea edx, [eax + eax*4]
004d355f 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d3566 e976050000               jmp 0x4d3ae1
004d356b 33c0                     xor eax, eax
004d356d 8a462b                   mov al, byte ptr [esi + 0x2b]
004d3570 8d0c80                   lea ecx, [eax + eax*4]
004d3573 8d1489                   lea edx, [ecx + ecx*4]
004d3576 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d357d e95f050000               jmp 0x4d3ae1
004d3582 32db                     xor bl, bl
004d3584 56                       push esi
004d3585 e886350000               call 0x4d6b10
004d358a 83c404                   add esp, 4
004d358d f6460d20                 test byte ptr [esi + 0xd], 0x20
004d3591 0f844a050000             je 0x4d3ae1
004d3597 56                       push esi
004d3598 e893f8f2ff               call 0x402e30
004d359d 83c404                   add esp, 4
004d35a0 8ad8                     mov bl, al
004d35a2 e93a050000               jmp 0x4d3ae1
004d35a7 66ff4e70                 dec word ptr [esi + 0x70]
004d35ab 7909                     jns 0x4d35b6
004d35ad 56                       push esi
004d35ae e80d330000               call 0x4d68c0
004d35b3 83c404                   add esp, 4
004d35b6 f6462e07                 test byte ptr [esi + 0x2e], 7
004d35ba 0f851f050000             jne 0x4d3adf
004d35c0 668b463d                 mov ax, word ptr [esi + 0x3d]
004d35c4 66c1e808                 shr ax, 8
004d35c8 8d7e68                   lea edi, [esi + 0x68]
004d35cb 24fe                     and al, 0xfe
004d35cd 57                       push edi
004d35ce 88442410                 mov byte ptr [esp + 0x10], al
004d35d2 668b463f                 mov ax, word ptr [esi + 0x3f]
004d35d6 66c1e808                 shr ax, 8
004d35da 24fe                     and al, 0xfe
004d35dc 88442411                 mov byte ptr [esp + 0x11], al
004d35e0 e86b16f3ff               call 0x404c50
004d35e5 8b4c2410                 mov ecx, dword ptr [esp + 0x10]
004d35e9 83c404                   add esp, 4
004d35ec 50                       push eax
004d35ed 51                       push ecx
004d35ee e89dcff7ff               call 0x450590
004d35f3 83c408                   add esp, 8
004d35f6 83f809                   cmp eax, 9
004d35f9 0f8ee0040000             jle 0x4d3adf
004d35ff 57                       push edi
004d3600 56                       push esi
004d3601 e87a670100               call 0x4e9d80
004d3606 83c408                   add esp, 8
004d3609 e9d1040000               jmp 0x4d3adf
004d360e 56                       push esi
004d360f e8fc340000               call 0x4d6b10
004d3614 83c404                   add esp, 4
004d3617 f6462e0f                 test byte ptr [esi + 0x2e], 0xf
004d361b 740d                     je 0x4d362a
004d361d f60561c6890008           test byte ptr [0x89c661], 8
004d3624 0f84b5040000             je 0x4d3adf
004d362a 56                       push esi
004d362b e850b60100               call 0x4eec80
004d3630 e9a7040000               jmp 0x4d3adc
004d3635 56                       push esi
004d3636 e8a5350000               call 0x4d6be0
004d363b 83c404                   add esp, 4
004d363e 8ad8                     mov bl, al
004d3640 e99c040000               jmp 0x4d3ae1
004d3645 56                       push esi
004d3646 e8f5370000               call 0x4d6e40
004d364b 83c404                   add esp, 4
004d364e 8ad8                     mov bl, al
004d3650 e98c040000               jmp 0x4d3ae1
004d3655 32db                     xor bl, bl
004d3657 385e7e                   cmp byte ptr [esi + 0x7e], bl
004d365a 7516                     jne 0x4d3672
004d365c 8d463d                   lea eax, [esi + 0x3d]
004d365f 8d4e4f                   lea ecx, [esi + 0x4f]
004d3662 51                       push ecx
004d3663 50                       push eax
004d3664 e867070000               call 0x4d3dd0
004d3669 83c408                   add esp, 8
004d366c 84c0                     test al, al
004d366e 7402                     je 0x4d3672
004d3670 b313                     mov bl, 0x13
004d3672 8b460c                   mov eax, dword ptr [esi + 0xc]
004d3675 a904200000               test eax, 0x2004
004d367a 7513                     jne 0x4d368f
004d367c f6462e0f                 test byte ptr [esi + 0x2e], 0xf
004d3680 0f855b040000             jne 0x4d3ae1
004d3686 f6c408                   test ah, 8
004d3689 0f8452040000             je 0x4d3ae1
004d368f 668b4668                 mov ax, word ptr [esi + 0x68]
004d3693 6a00                     push 0
004d3695 6689442410               mov word ptr [esp + 0x10], ax
004d369a 8d442410                 lea eax, [esp + 0x10]
004d369e 668b4e6a                 mov cx, word ptr [esi + 0x6a]
004d36a2 50                       push eax
004d36a3 66894c2416               mov word ptr [esp + 0x16], cx
004d36a8 66c74424180000           mov word ptr [esp + 0x18], 0
004d36af e84c4b0400               call 0x518200
004d36b4 83c408                   add esp, 8
004d36b7 84c0                     test al, al
004d36b9 0f8422040000             je 0x4d3ae1
004d36bf 834e0c10                 or dword ptr [esi + 0xc], 0x10
004d36c3 e919040000               jmp 0x4d3ae1
004d36c8 32db                     xor bl, bl
004d36ca 8d463d                   lea eax, [esi + 0x3d]
004d36cd 6800020000               push 0x200
004d36d2 8d4e4f                   lea ecx, [esi + 0x4f]
004d36d5 51                       push ecx
004d36d6 6a38                     push 0x38
004d36d8 50                       push eax
004d36d9 e8c2f6f5ff               call 0x432da0
004d36de 83c410                   add esp, 0x10
004d36e1 84c0                     test al, al
004d36e3 0f84f8030000             je 0x4d3ae1
004d36e9 8a5e7d                   mov bl, byte ptr [esi + 0x7d]
004d36ec e9f0030000               jmp 0x4d3ae1
004d36f1 56                       push esi
004d36f2 e8e93c0000               call 0x4d73e0
004d36f7 83c404                   add esp, 4
004d36fa 8ad8                     mov bl, al
004d36fc e9e0030000               jmp 0x4d3ae1
004d3701 668b4670                 mov ax, word ptr [esi + 0x70]
004d3705 6685c0                   test ax, ax
004d3708 740f                     je 0x4d3719
004d370a 6648                     dec ax
004d370c 66894670                 mov word ptr [esi + 0x70], ax
004d3710 6685c0                   test ax, ax
004d3713 7f04                     jg 0x4d3719
004d3715 804e3502                 or byte ptr [esi + 0x35], 2
004d3719 0fbe462f                 movsx eax, byte ptr [esi + 0x2f]
004d371d 8bc8                     mov ecx, eax
004d371f 8d1480                   lea edx, [eax + eax*4]
004d3722 8d0451                   lea eax, [ecx + edx*2]
004d3725 8d1cc0                   lea ebx, [eax + eax*8]
004d3728 8d14d9                   lea edx, [ecx + ebx*8]
004d372b 80bc91e7dd890001         cmp byte ptr [ecx + edx*4 + 0x89dde7], 1
004d3733 0f85a6030000             jne 0x4d3adf
004d3739 668b8683000000           mov ax, word ptr [esi + 0x83]
004d3740 33c9                     xor ecx, ecx
004d3742 6640                     inc ax
004d3744 66898683000000           mov word ptr [esi + 0x83], ax
004d374b 0fbfc0                   movsx eax, ax
004d374e 668b4e24                 mov cx, word ptr [esi + 0x24]
004d3752 81e1ff000000             and ecx, 0xff
004d3758 81c100040000             add ecx, 0x400
004d375e 3bc8                     cmp ecx, eax
004d3760 0f8f79030000             jg 0x4d3adf
004d3766 66c786830000000000       mov word ptr [esi + 0x83], 0
004d376f 56                       push esi
004d3770 e8db630000               call 0x4d9b50
004d3775 e962030000               jmp 0x4d3adc
004d377a 668b4670                 mov ax, word ptr [esi + 0x70]
004d377e 6648                     dec ax
004d3780 66894670                 mov word ptr [esi + 0x70], ax
004d3784 6685c0                   test ax, ax
004d3787 0f8f52030000             jg 0x4d3adf
004d378d 8d7e49                   lea edi, [esi + 0x49]
004d3790 57                       push edi
004d3791 e85a5f0100               call 0x4e96f0
004d3796 83c404                   add esp, 4
004d3799 57                       push edi
004d379a e8315f0100               call 0x4e96d0
004d379f 83c404                   add esp, 4
004d37a2 8d7e3d                   lea edi, [esi + 0x3d]
004d37a5 66c7465f0000             mov word ptr [esi + 0x5f], 0
004d37ab 56                       push esi
004d37ac e83ffaffff               call 0x4d31f0
004d37b1 83c404                   add esp, 4
004d37b4 57                       push edi
004d37b5 56                       push esi
004d37b6 e815660100               call 0x4e9dd0
004d37bb 83c408                   add esp, 8
004d37be 80bea800000000           cmp byte ptr [esi + 0xa8], 0
004d37c5 7430                     je 0x4d37f7
004d37c7 8b07                     mov eax, dword ptr [edi]
004d37c9 8944240c                 mov dword ptr [esp + 0xc], eax
004d37cd 8d44240c                 lea eax, [esp + 0xc]
004d37d1 50                       push eax
004d37d2 56                       push esi
004d37d3 e848edf5ff               call 0x432520
004d37d8 8d4c2414                 lea ecx, [esp + 0x14]
004d37dc 83c408                   add esp, 8
004d37df 51                       push ecx
004d37e0 56                       push esi
004d37e1 e88af6f2ff               call 0x402e70
004d37e6 668b4e5d                 mov cx, word ptr [esi + 0x5d]
004d37ea 83c408                   add esp, 8
004d37ed 51                       push ecx
004d37ee 56                       push esi
004d37ef e80c060000               call 0x4d3e00
004d37f4 83c408                   add esp, 8
004d37f7 56                       push esi
004d37f8 e833060000               call 0x4d3e30
004d37fd e9da020000               jmp 0x4d3adc
004d3802 56                       push esi
004d3803 e8a84b0000               call 0x4d83b0
004d3808 83c404                   add esp, 4
004d380b 8ad8                     mov bl, al
004d380d e9cf020000               jmp 0x4d3ae1
004d3812 56                       push esi
004d3813 e828560000               call 0x4d8e40
004d3818 83c404                   add esp, 4
004d381b 8ad8                     mov bl, al
004d381d e9bf020000               jmp 0x4d3ae1
004d3822 56                       push esi
004d3823 e8384d0400               call 0x518560
004d3828 83c404                   add esp, 4
004d382b 8ad8                     mov bl, al
004d382d e9af020000               jmp 0x4d3ae1
004d3832 32db                     xor bl, bl
004d3834 f6461010                 test byte ptr [esi + 0x10], 0x10
004d3838 750d                     jne 0x4d3847
004d383a 6a00                     push 0
004d383c 6a51                     push 0x51
004d383e 56                       push esi
004d383f e80c68fbff               call 0x48a050
004d3844 83c40c                   add esp, 0xc
004d3847 66ff4e70                 dec word ptr [esi + 0x70]
004d384b 0f8990020000             jns 0x4d3ae1
004d3851 56                       push esi
004d3852 e8d9f5f2ff               call 0x402e30
004d3857 83c404                   add esp, 4
004d385a 8ad8                     mov bl, al
004d385c 8b463d                   mov eax, dword ptr [esi + 0x3d]
004d385f 8944240c                 mov dword ptr [esp + 0xc], eax
004d3863 8d44240c                 lea eax, [esp + 0xc]
004d3867 50                       push eax
004d3868 56                       push esi
004d3869 e8b2ecf5ff               call 0x432520
004d386e 8d4c2414                 lea ecx, [esp + 0x14]
004d3872 83c408                   add esp, 8
004d3875 51                       push ecx
004d3876 56                       push esi
004d3877 e8f4f5f2ff               call 0x402e70
004d387c 83c408                   add esp, 8
004d387f e95d020000               jmp 0x4d3ae1
004d3884 56                       push esi
004d3885 e8f6b30100               call 0x4eec80
004d388a 83c404                   add esp, 4
004d388d 8b460c                   mov eax, dword ptr [esi + 0xc]
004d3890 25ffffefff               and eax, 0xffefffff
004d3895 89460c                   mov dword ptr [esi + 0xc], eax
004d3898 a900001000               test eax, 0x100000
004d389d 751c                     jne 0x4d38bb
004d389f 8a462c                   mov al, byte ptr [esi + 0x2c]
004d38a2 56                       push esi
004d38a3 88467d                   mov byte ptr [esi + 0x7d], al
004d38a6 e8459e0100               call 0x4ed6f0
004d38ab 83c404                   add esp, 4
004d38ae c6462c03                 mov byte ptr [esi + 0x2c], 3
004d38b2 56                       push esi
004d38b3 e8889d0100               call 0x4ed640
004d38b8 83c404                   add esp, 4
004d38bb 83660cfd                 and dword ptr [esi + 0xc], 0xfffffffd
004d38bf e91b020000               jmp 0x4d3adf
004d38c4 56                       push esi
004d38c5 e8b6800000               call 0x4db980
004d38ca 83c404                   add esp, 4
004d38cd 8ad8                     mov bl, al
004d38cf e90d020000               jmp 0x4d3ae1
004d38d4 56                       push esi
004d38d5 e8864c0400               call 0x518560
004d38da 83c404                   add esp, 4
004d38dd 8ad8                     mov bl, al
004d38df e9fd010000               jmp 0x4d3ae1
004d38e4 32c0                     xor al, al
004d38e6 6683be9f00000000         cmp word ptr [esi + 0x9f], 0
004d38ee 7509                     jne 0x4d38f9
004d38f0 56                       push esi
004d38f1 e83af5f2ff               call 0x402e30
004d38f6 83c404                   add esp, 4
004d38f9 8ad8                     mov bl, al
004d38fb e9e1010000               jmp 0x4d3ae1
004d3900 56                       push esi
004d3901 e87a570000               call 0x4d9080
004d3906 83c404                   add esp, 4
004d3909 8ad8                     mov bl, al
004d390b e9d1010000               jmp 0x4d3ae1
004d3910 56                       push esi
004d3911 e80a5b0000               call 0x4d9420
004d3916 83c404                   add esp, 4
004d3919 8ad8                     mov bl, al
004d391b e9c1010000               jmp 0x4d3ae1
004d3920 56                       push esi
004d3921 e82a5d0000               call 0x4d9650
004d3926 83c404                   add esp, 4
004d3929 8ad8                     mov bl, al
004d392b e9b1010000               jmp 0x4d3ae1
004d3930 668b4672                 mov ax, word ptr [esi + 0x72]
004d3934 32db                     xor bl, bl
004d3936 50                       push eax
004d3937 e8a43ef3ff               call 0x4077e0
004d393c 83c404                   add esp, 4
004d393f 85c0                     test eax, eax
004d3941 7460                     je 0x4d39a3
004d3943 83c03d                   add eax, 0x3d
004d3946 8d4e3d                   lea ecx, [esi + 0x3d]
004d3949 50                       push eax
004d394a 51                       push ecx
004d394b e870ebf5ff               call 0x4324c0
004d3950 668bf8                   mov di, ax
004d3953 83c408                   add esp, 8
004d3956 56                       push esi
004d3957 e8046b0100               call 0x4ea460
004d395c 83c404                   add esp, 4
004d395f 8b4e0c                   mov ecx, dword ptr [esi + 0xc]
004d3962 81c980000000             or ecx, 0x80
004d3968 894e0c                   mov dword ptr [esi + 0xc], ecx
004d396b 81c900100000             or ecx, 0x1000
004d3971 894e0c                   mov dword ptr [esi + 0xc], ecx
004d3974 66897e57                 mov word ptr [esi + 0x57], di
004d3978 668b4670                 mov ax, word ptr [esi + 0x70]
004d397c 6648                     dec ax
004d397e 66894670                 mov word ptr [esi + 0x70], ax
004d3982 6685c0                   test ax, ax
004d3985 7e0c                     jle 0x4d3993
004d3987 f7c104200000             test ecx, 0x2004
004d398d 0f844e010000             je 0x4d3ae1
004d3993 56                       push esi
004d3994 e897f4f2ff               call 0x402e30
004d3999 83c404                   add esp, 4
004d399c 8ad8                     mov bl, al
004d399e e93e010000               jmp 0x4d3ae1
004d39a3 56                       push esi
004d39a4 e887f4f2ff               call 0x402e30
004d39a9 83c404                   add esp, 4
004d39ac 8ad8                     mov bl, al
004d39ae e92e010000               jmp 0x4d3ae1
004d39b3 668b4670                 mov ax, word ptr [esi + 0x70]
004d39b7 32db                     xor bl, bl
004d39b9 6648                     dec ax
004d39bb 66894670                 mov word ptr [esi + 0x70], ax
004d39bf 6685c0                   test ax, ax
004d39c2 0f8f19010000             jg 0x4d3ae1
004d39c8 f6057cd1890002           test byte ptr [0x89d17c], 2
004d39cf 7422                     je 0x4d39f3
004d39d1 80f907                   cmp cl, 7
004d39d4 7507                     jne 0x4d39dd
004d39d6 b327                     mov bl, 0x27
004d39d8 e904010000               jmp 0x4d3ae1
004d39dd 33c0                     xor eax, eax
004d39df 8ac1                     mov al, cl
004d39e1 8d0c80                   lea ecx, [eax + eax*4]
004d39e4 8d1489                   lea edx, [ecx + ecx*4]
004d39e7 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d39ee e9ee000000               jmp 0x4d3ae1
004d39f3 33c0                     xor eax, eax
004d39f5 8ac1                     mov al, cl
004d39f7 8d0c80                   lea ecx, [eax + eax*4]
004d39fa 8d1489                   lea edx, [ecx + ecx*4]
004d39fd 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d3a04 e9d8000000               jmp 0x4d3ae1
004d3a09 56                       push esi
004d3a0a e811b80000               call 0x4df220
004d3a0f 83c404                   add esp, 4
004d3a12 8ad8                     mov bl, al
004d3a14 e9c8000000               jmp 0x4d3ae1
004d3a19 56                       push esi
004d3a1a e831ba0000               call 0x4df450
004d3a1f 83c404                   add esp, 4
004d3a22 8ad8                     mov bl, al
004d3a24 e9b8000000               jmp 0x4d3ae1
004d3a29 56                       push esi
004d3a2a e841bc0000               call 0x4df670
004d3a2f 83c404                   add esp, 4
004d3a32 8ad8                     mov bl, al
004d3a34 e9a8000000               jmp 0x4d3ae1
004d3a39 56                       push esi
004d3a3a e881c20000               call 0x4dfcc0
004d3a3f 83c404                   add esp, 4
004d3a42 8ad8                     mov bl, al
004d3a44 e998000000               jmp 0x4d3ae1
004d3a49 56                       push esi
004d3a4a e811cd0000               call 0x4e0760
004d3a4f 83c404                   add esp, 4
004d3a52 8ad8                     mov bl, al
004d3a54 e988000000               jmp 0x4d3ae1
004d3a59 56                       push esi
004d3a5a e891d00000               call 0x4e0af0
004d3a5f 83c404                   add esp, 4
004d3a62 8ad8                     mov bl, al
004d3a64 eb7b                     jmp 0x4d3ae1
004d3a66 56                       push esi
004d3a67 e804ee0000               call 0x4e2870
004d3a6c 83c404                   add esp, 4
004d3a6f 8ad8                     mov bl, al
004d3a71 eb6e                     jmp 0x4d3ae1
004d3a73 56                       push esi
004d3a74 e867f50000               call 0x4e2fe0
004d3a79 83c404                   add esp, 4
004d3a7c 8ad8                     mov bl, al
004d3a7e eb61                     jmp 0x4d3ae1
004d3a80 8a462d                   mov al, byte ptr [esi + 0x2d]
004d3a83 fec0                     inc al
004d3a85 88462d                   mov byte ptr [esi + 0x2d], al
004d3a88 3c02                     cmp al, 2
004d3a8a 7253                     jb 0x4d3adf
004d3a8c 33d2                     xor edx, edx
004d3a8e 8ad0                     mov dl, al
004d3a90 83fa02                   cmp edx, 2
004d3a93 7407                     je 0x4d3a9c
004d3a95 83fa12                   cmp edx, 0x12
004d3a98 741a                     je 0x4d3ab4
004d3a9a eb43                     jmp 0x4d3adf
004d3a9c 33c0                     xor eax, eax
004d3a9e 8ac1                     mov al, cl
004d3aa0 668b0445366f5a00         mov ax, word ptr [eax*2 + 0x5a6f36]
004d3aa8 50                       push eax
004d3aa9 56                       push esi
004d3aaa e891050000               call 0x4d4040
004d3aaf 83c408                   add esp, 8
004d3ab2 eb2b                     jmp 0x4d3adf
004d3ab4 8b460c                   mov eax, dword ptr [esi + 0xc]
004d3ab7 25ffffefff               and eax, 0xffefffff
004d3abc 89460c                   mov dword ptr [esi + 0xc], eax
004d3abf a900001000               test eax, 0x100000
004d3ac4 7519                     jne 0x4d3adf
004d3ac6 56                       push esi
004d3ac7 885e7d                   mov byte ptr [esi + 0x7d], bl
004d3aca e8219c0100               call 0x4ed6f0
004d3acf 83c404                   add esp, 4
004d3ad2 c6462c03                 mov byte ptr [esi + 0x2c], 3
004d3ad6 56                       push esi
004d3ad7 e8649b0100               call 0x4ed640
004d3adc 83c404                   add esp, 4
004d3adf 32db                     xor bl, bl
004d3ae1 8a461e                   mov al, byte ptr [esi + 0x1e]
004d3ae4 84c0                     test al, al
004d3ae6 7405                     je 0x4d3aed
004d3ae8 fec8                     dec al
004d3aea 88461e                   mov byte ptr [esi + 0x1e], al
004d3aed 807e2a00                 cmp byte ptr [esi + 0x2a], 0
004d3af1 0f84f0010000             je 0x4d3ce7
004d3af7 84db                     test bl, bl
004d3af9 7421                     je 0x4d3b1c
004d3afb f6460e10                 test byte ptr [esi + 0xe], 0x10
004d3aff 751b                     jne 0x4d3b1c
004d3b01 8a462c                   mov al, byte ptr [esi + 0x2c]
004d3b04 56                       push esi
004d3b05 88467d                   mov byte ptr [esi + 0x7d], al
004d3b08 e8e39b0100               call 0x4ed6f0
004d3b0d 83c404                   add esp, 4
004d3b10 885e2c                   mov byte ptr [esi + 0x2c], bl
004d3b13 56                       push esi
004d3b14 e8279b0100               call 0x4ed640
004d3b19 83c404                   add esp, 4
004d3b1c 33c0                     xor eax, eax
004d3b1e 8a462c                   mov al, byte ptr [esi + 0x2c]
004d3b21 f68480796f5a0001         test byte ptr [eax + eax*4 + 0x5a6f79], 1
004d3b29 7509                     jne 0x4d3b34
004d3b2b 56                       push esi
004d3b2c e86f080000               call 0x4d43a0
004d3b31 83c404                   add esp, 4
004d3b34 807e2fff                 cmp byte ptr [esi + 0x2f], 0xff
004d3b38 0f84a9010000             je 0x4d3ce7
004d3b3e 56                       push esi
004d3b3f e84c0b0000               call 0x4d4690
004d3b44 83c404                   add esp, 4
004d3b47 56                       push esi
004d3b48 e883600000               call 0x4d9bd0
004d3b4d 83c404                   add esp, 4
004d3b50 56                       push esi
004d3b51 e8fab30000               call 0x4def50
004d3b56 83c404                   add esp, 4
004d3b59 56                       push esi
004d3b5a e841670000               call 0x4da2a0
004d3b5f 83c404                   add esp, 4
004d3b62 f6057cd1890002           test byte ptr [0x89d17c], 2
004d3b69 7418                     je 0x4d3b83
004d3b6b 833d70aa960000           cmp dword ptr [0x96aa70], 0
004d3b72 740f                     je 0x4d3b83
004d3b74 56                       push esi
004d3b75 a170aa9600               mov eax, dword ptr [0x96aa70]
004d3b7a 50                       push eax
004d3b7b e8a04cfaff               call 0x478820
004d3b80 83c408                   add esp, 8
004d3b83 80bea400000000           cmp byte ptr [esi + 0xa4], 0
004d3b8a 7409                     je 0x4d3b95
004d3b8c 56                       push esi
004d3b8d e86e560000               call 0x4d9200
004d3b92 83c404                   add esp, 4
004d3b95 f6461140                 test byte ptr [esi + 0x11], 0x40
004d3b99 7409                     je 0x4d3ba4
004d3b9b 56                       push esi
004d3b9c e80f570000               call 0x4d92b0
004d3ba1 83c404                   add esp, 4
004d3ba4 8b4610                   mov eax, dword ptr [esi + 0x10]
004d3ba7 2500100000               and eax, 0x1000
004d3bac 0f84c2000000             je 0x4d3c74
004d3bb2 8a96a3000000             mov dl, byte ptr [esi + 0xa3]
004d3bb8 84d2                     test dl, dl
004d3bba 0f84b4000000             je 0x4d3c74
004d3bc0 8a0df0c68900             mov cl, byte ptr [0x89c6f0]
004d3bc6 384e2f                   cmp byte ptr [esi + 0x2f], cl
004d3bc9 7542                     jne 0x4d3c0d
004d3bcb 33c9                     xor ecx, ecx
004d3bcd bfff000000               mov edi, 0xff
004d3bd2 80fa18                   cmp dl, 0x18
004d3bd5 731e                     jae 0x4d3bf5
004d3bd7 b901000000               mov ecx, 1
004d3bdc bf04000000               mov edi, 4
004d3be1 80fa0e                   cmp dl, 0xe
004d3be4 7305                     jae 0x4d3beb
004d3be6 bf02000000               mov edi, 2
004d3beb 80fa06                   cmp dl, 6
004d3bee 7305                     jae 0x4d3bf5
004d3bf0 bf01000000               mov edi, 1
004d3bf5 85c9                     test ecx, ecx
004d3bf7 7414                     je 0x4d3c0d
004d3bf9 853d84d18900             test dword ptr [0x89d184], edi
004d3bff 7406                     je 0x4d3c07
004d3c01 804e3640                 or byte ptr [esi + 0x36], 0x40
004d3c05 eb06                     jmp 0x4d3c0d
004d3c07 66816635ffbf             and word ptr [esi + 0x35], 0xbfff
004d3c0d f6462e07                 test byte ptr [esi + 0x2e], 7
004d3c11 7561                     jne 0x4d3c74
004d3c13 feca                     dec dl
004d3c15 8896a3000000             mov byte ptr [esi + 0xa3], dl
004d3c1b 7557                     jne 0x4d3c74
004d3c1d 85c0                     test eax, eax
004d3c1f 7453                     je 0x4d3c74
004d3c21 6a00                     push 0
004d3c23 6a35                     push 0x35
004d3c25 56                       push esi
004d3c26 e82564fbff               call 0x48a050
004d3c2b 816610ffefffff           and dword ptr [esi + 0x10], 0xffffefff
004d3c32 0fbe0df0c68900           movsx ecx, byte ptr [0x89c6f0]
004d3c39 8d1489                   lea edx, [ecx + ecx*4]
004d3c3c 83c40c                   add esp, 0xc
004d3c3f 8bc1                     mov eax, ecx
004d3c41 8d0c50                   lea ecx, [eax + edx*2]
004d3c44 8d1cc9                   lea ebx, [ecx + ecx*8]
004d3c47 8d14d8                   lea edx, [eax + ebx*8]
004d3c4a f6849005db890008         test byte ptr [eax + edx*4 + 0x89db05], 8
004d3c52 7408                     je 0x4d3c5c
004d3c54 66816635ffbf             and word ptr [esi + 0x35], 0xbfff
004d3c5a eb18                     jmp 0x4d3c74
004d3c5c a0f0c68900               mov al, byte ptr [0x89c6f0]
004d3c61 38462f                   cmp byte ptr [esi + 0x2f], al
004d3c64 7508                     jne 0x4d3c6e
004d3c66 66816635ffbf             and word ptr [esi + 0x35], 0xbfff
004d3c6c eb06                     jmp 0x4d3c74
004d3c6e 66816635efff             and word ptr [esi + 0x35], 0xffef
004d3c74 8a86a5000000             mov al, byte ptr [esi + 0xa5]
004d3c7a 84c0                     test al, al
004d3c7c 7417                     je 0x4d3c95
004d3c7e f6462e07                 test byte ptr [esi + 0x2e], 7
004d3c82 7511                     jne 0x4d3c95
004d3c84 fec8                     dec al
004d3c86 8886a5000000             mov byte ptr [esi + 0xa5], al
004d3c8c 7507                     jne 0x4d3c95
004d3c8e 816614ff7fffff           and dword ptr [esi + 0x14], 0xffff7fff
004d3c95 8a86b1000000             mov al, byte ptr [esi + 0xb1]
004d3c9b 84c0                     test al, al
004d3c9d 7417                     je 0x4d3cb6
004d3c9f f6462e07                 test byte ptr [esi + 0x2e], 7
004d3ca3 7511                     jne 0x4d3cb6
004d3ca5 fec8                     dec al
004d3ca7 8886b1000000             mov byte ptr [esi + 0xb1], al
004d3cad 7507                     jne 0x4d3cb6
004d3caf 816614fffff7ff           and dword ptr [esi + 0x14], 0xfff7ffff
004d3cb6 0fbe4e2f                 movsx ecx, byte ptr [esi + 0x2f]
004d3cba 8bc1                     mov eax, ecx
004d3cbc 8d1489                   lea edx, [ecx + ecx*4]
004d3cbf 8d0c50                   lea ecx, [eax + edx*2]
004d3cc2 8d1cc9                   lea ebx, [ecx + ecx*8]
004d3cc5 8d14d8                   lea edx, [eax + ebx*8]
004d3cc8 f6849009db890002         test byte ptr [eax + edx*4 + 0x89db09], 2
004d3cd0 7415                     je 0x4d3ce7
004d3cd2 f6460e80                 test byte ptr [esi + 0xe], 0x80
004d3cd6 740f                     je 0x4d3ce7
004d3cd8 f6461701                 test byte ptr [esi + 0x17], 1
004d3cdc 7409                     je 0x4d3ce7
004d3cde 56                       push esi
004d3cdf e89cb40100               call 0x4ef180
004d3ce4 83c404                   add esp, 4
004d3ce7 8b460c                   mov eax, dword ptr [esi + 0xc]
004d3cea 83e0fb                   and eax, 0xfffffffb
004d3ced 89460c                   mov dword ptr [esi + 0xc], eax
004d3cf0 25ffdfffff               and eax, 0xffffdfff
004d3cf5 89460c                   mov dword ptr [esi + 0xc], eax
004d3cf8 f6461104                 test byte ptr [esi + 0x11], 4
004d3cfc 740b                     je 0x4d3d09
004d3cfe 804e3680                 or byte ptr [esi + 0x36], 0x80
004d3d02 5f                       pop edi
004d3d03 5e                       pop esi
004d3d04 5b                       pop ebx
004d3d05 83c408                   add esp, 8
004d3d08 c3                       ret 
004d3d09 66816635ff7f             and word ptr [esi + 0x35], 0x7fff
004d3d0f 5f                       pop edi
004d3d10 5e                       pop esi
004d3d11 5b                       pop ebx
004d3d12 83c408                   add esp, 8
004d3d15 c3                       ret 
004d3d16 8bff                     mov edi, edi
004d3d18 8633                     xchg byte ptr [ebx], dh
004d3d1a 4d                       dec ebp
004d3d1b 00e5                     add ch, ah
004d3d1d 334d00                   xor ecx, dword ptr [ebp]
004d3d20 f5                       cmc 
004d3d21 334d00                   xor ecx, dword ptr [ebp]
004d3d24 05344d001a               add eax, 0x1a004d34
004d3d29 344d                     xor al, 0x4d
004d3d2b 002a                     add byte ptr [edx], ch
004d3d2d 344d                     xor al, 0x4d
004d3d2f 00bb344d00f9             add byte ptr [ebx - 0x6ffb2cc], bh
004d3d35 344d                     xor al, 0x4d
004d3d37 0009                     add byte ptr [ecx], cl
004d3d39 354d001935               xor eax, 0x3519004d
004d3d3e 4d                       dec ebp
004d3d3f 0029                     add byte ptr [ecx], ch
004d3d41 354d008235               xor eax, 0x3582004d
004d3d46 4d                       dec ebp
004d3d47 00a7354d000e             add byte ptr [edi + 0xe004d35], ah
004d3d4d 364d                     dec ebp
004d3d4f 0035364d0045             add byte ptr [0x45004d36], dh
004d3d55 364d                     dec ebp
004d3d57 005536                   add byte ptr [ebp + 0x36], dl
004d3d5a 4d                       dec ebp
004d3d5b 00c8                     add al, cl
004d3d5d 364d                     dec ebp
004d3d5f 00f1                     add cl, dh
004d3d61 364d                     dec ebp
004d3d63 00df                     add bh, bl
004d3d65 3a4d00                   cmp cl, byte ptr [ebp]
004d3d68 0137                     add dword ptr [edi], esi
004d3d6a 4d                       dec ebp
004d3d6b 007a37                   add byte ptr [edx + 0x37], bh
004d3d6e 4d                       dec ebp
004d3d6f 0002                     add byte ptr [edx], al
004d3d71 384d00                   cmp byte ptr [ebp], cl
004d3d74 1238                     adc bh, byte ptr [eax]
004d3d76 4d                       dec ebp
004d3d77 0022                     add byte ptr [edx], ah
004d3d79 384d00                   cmp byte ptr [ebp], cl
004d3d7c 3238                     xor bh, byte ptr [eax]
004d3d7e 4d                       dec ebp
004d3d7f 0084384d00c438           add byte ptr [eax + edi + 0x38c4004d], al
004d3d86 4d                       dec ebp
004d3d87 00d4                     add ah, dl
004d3d89 384d00                   cmp byte ptr [ebp], cl
004d3d8c e438                     in al, 0x38
004d3d8e 4d                       dec ebp
004d3d8f 0000                     add byte ptr [eax], al
004d3d91 394d00                   cmp dword ptr [ebp], ecx
004d3d94 1039                     adc byte ptr [ecx], bh
004d3d96 4d                       dec ebp
004d3d97 0020                     add byte ptr [eax], ah
004d3d99 394d00                   cmp dword ptr [ebp], ecx
004d3d9c 3039                     xor byte ptr [ecx], bh
004d3d9e 4d                       dec ebp
004d3d9f 00b3394d0009             add byte ptr [ebx + 0x9004d39], dh
004d3da5 3a4d00                   cmp cl, byte ptr [ebp]
004d3da8 193a                     sbb dword ptr [edx], edi
004d3daa 4d                       dec ebp
004d3dab 0029                     add byte ptr [ecx], ch
004d3dad 3a4d00                   cmp cl, byte ptr [ebp]
004d3db0 393a                     cmp dword ptr [edx], edi
004d3db2 4d                       dec ebp
004d3db3 00493a                   add byte ptr [ecx + 0x3a], cl
004d3db6 4d                       dec ebp
004d3db7 00593a                   add byte ptr [ecx + 0x3a], bl
004d3dba 4d                       dec ebp
004d3dbb 00663a                   add byte ptr [esi + 0x3a], ah
004d3dbe 4d                       dec ebp
004d3dbf 00733a                   add byte ptr [ebx + 0x3a], dh
004d3dc2 4d                       dec ebp
004d3dc3 00803a4d00cc             add byte ptr [eax - 0x33ffb2c6], al
004d3dc9 cc                       int3 
004d3dca cc                       int3 
004d3dcb cc                       int3 
004d3dcc cc                       int3 
004d3dcd cc                       int3 
004d3dce cc                       int3 
004d3dcf cc                       int3 
