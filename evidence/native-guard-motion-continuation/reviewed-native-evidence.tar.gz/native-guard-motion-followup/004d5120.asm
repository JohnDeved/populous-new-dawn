004d5120 83ec28                   sub esp, 0x28
004d5123 c644240300               mov byte ptr [esp + 3], 0
004d5128 53                       push ebx
004d5129 56                       push esi
004d512a 8b742434                 mov esi, dword ptr [esp + 0x34]
004d512e 57                       push edi
004d512f 668b465d                 mov ax, word ptr [esi + 0x5d]
004d5133 55                       push ebp
004d5134 6a10                     push 0x10
004d5136 6a00                     push 0
004d5138 50                       push eax
004d5139 6a02                     push 2
004d513b e8b051fcff               call 0x49a2f0
004d5140 83c410                   add esp, 0x10
004d5143 33c9                     xor ecx, ecx
004d5145 8ac8                     mov cl, al
004d5147 894c242c                 mov dword ptr [esp + 0x2c], ecx
004d514b 85c9                     test ecx, ecx
004d514d 0f84bf020000             je 0x4d5412
004d5153 8b4668                   mov eax, dword ptr [esi + 0x68]
004d5156 89442428                 mov dword ptr [esp + 0x28], eax
004d515a 668b4c242a               mov cx, word ptr [esp + 0x2a]
004d515f 88642420                 mov byte ptr [esp + 0x20], ah
004d5163 33c0                     xor eax, eax
004d5165 886c2421                 mov byte ptr [esp + 0x21], ch
004d5169 668b442420               mov ax, word ptr [esp + 0x20]
004d516e 33c9                     xor ecx, ecx
004d5170 668b4c2420               mov cx, word ptr [esp + 0x20]
004d5175 25fe000000               and eax, 0xfe
004d517a 03c0                     add eax, eax
004d517c 81e100fe0000             and ecx, 0xfe00
004d5182 0bc1                     or eax, ecx
004d5184 8d0c85e4038a00           lea ecx, [eax*4 + 0x8a03e4]
004d518b f6410102                 test byte ptr [ecx + 1], 2
004d518f 7420                     je 0x4d51b1
004d5191 8d442428                 lea eax, [esp + 0x28]
004d5195 50                       push eax
004d5196 33c0                     xor eax, eax
004d5198 668b4108                 mov ax, word ptr [ecx + 8]
004d519c 25ff030000               and eax, 0x3ff
004d51a1 8b0c8590038900           mov ecx, dword ptr [eax*4 + 0x890390]
004d51a8 51                       push ecx
004d51a9 e802f3f2ff               call 0x4044b0
004d51ae 83c408                   add esp, 8
004d51b1 668b442428               mov ax, word ptr [esp + 0x28]
004d51b6 66c1e808                 shr ax, 8
004d51ba 24fe                     and al, 0xfe
004d51bc 88442420                 mov byte ptr [esp + 0x20], al
004d51c0 668b44242a               mov ax, word ptr [esp + 0x2a]
004d51c5 66c1e808                 shr ax, 8
004d51c9 24fe                     and al, 0xfe
004d51cb 88442421                 mov byte ptr [esp + 0x21], al
004d51cf 668b4c2420               mov cx, word ptr [esp + 0x20]
004d51d4 66894c2416               mov word ptr [esp + 0x16], cx
004d51d9 80642416fe               and byte ptr [esp + 0x16], 0xfe
004d51de 80642417fe               and byte ptr [esp + 0x17], 0xfe
004d51e3 8d442434                 lea eax, [esp + 0x34]
004d51e7 8d4c2430                 lea ecx, [esp + 0x30]
004d51eb 8b54242c                 mov edx, dword ptr [esp + 0x2c]
004d51ef 50                       push eax
004d51f0 51                       push ecx
004d51f1 52                       push edx
004d51f2 e8f951fcff               call 0x49a3f0
004d51f7 83c40c                   add esp, 0xc
004d51fa 84c0                     test al, al
004d51fc 0f8403020000             je 0x4d5405
004d5202 8b442430                 mov eax, dword ptr [esp + 0x30]
004d5206 02c0                     add al, al
004d5208 02442416                 add al, byte ptr [esp + 0x16]
004d520c 8844241a                 mov byte ptr [esp + 0x1a], al
004d5210 8b442434                 mov eax, dword ptr [esp + 0x34]
004d5214 02c0                     add al, al
004d5216 33c9                     xor ecx, ecx
004d5218 02442417                 add al, byte ptr [esp + 0x17]
004d521c 8844241b                 mov byte ptr [esp + 0x1b], al
004d5220 33c0                     xor eax, eax
004d5222 668b44241a               mov ax, word ptr [esp + 0x1a]
004d5227 668b4c241a               mov cx, word ptr [esp + 0x1a]
004d522c 25fe000000               and eax, 0xfe
004d5231 03c0                     add eax, eax
004d5233 81e100fe0000             and ecx, 0xfe00
004d5239 0bc1                     or eax, ecx
004d523b 8064241e0f               and byte ptr [esp + 0x1e], 0xf
004d5240 8d1485e4038a00           lea edx, [eax*4 + 0x8a03e4]
004d5247 89542420                 mov dword ptr [esp + 0x20], edx
004d524b 52                       push edx
004d524c e84f030000               call 0x4d55a0
004d5251 83c404                   add esp, 4
004d5254 84c0                     test al, al
004d5256 0f849e010000             je 0x4d53fa
004d525c bb01000000               mov ebx, 1
004d5261 668b4c241a               mov cx, word ptr [esp + 0x1a]
004d5266 8bc3                     mov eax, ebx
004d5268 66894c2418               mov word ptr [esp + 0x18], cx
004d526d 3244241e                 xor al, byte ptr [esp + 0x1e]
004d5271 c644241200               mov byte ptr [esp + 0x12], 0
004d5276 80642418fe               and byte ptr [esp + 0x18], 0xfe
004d527b 240f                     and al, 0xf
004d527d 3044241e                 xor byte ptr [esp + 0x1e], al
004d5281 660fb6442418             movzx ax, byte ptr [esp + 0x18]
004d5287 6640                     inc ax
004d5289 80642419fe               and byte ptr [esp + 0x19], 0xfe
004d528e 66c1e008                 shl ax, 8
004d5292 6689442424               mov word ptr [esp + 0x24], ax
004d5297 660fb6442419             movzx ax, byte ptr [esp + 0x19]
004d529d 6640                     inc ax
004d529f 66c1e008                 shl ax, 8
004d52a3 f644241ef0               test byte ptr [esp + 0x1e], 0xf0
004d52a8 6689442426               mov word ptr [esp + 0x26], ax
004d52ad 7414                     je 0x4d52c3
004d52af 8a44241e                 mov al, byte ptr [esp + 0x1e]
004d52b3 33c9                     xor ecx, ecx
004d52b5 c0e804                   shr al, 4
004d52b8 8ac8                     mov cl, al
004d52ba 8b148dd95e8900           mov edx, dword ptr [ecx*4 + 0x895ed9]
004d52c1 eb06                     jmp 0x4d52c9
004d52c3 8b15f15e8900             mov edx, dword ptr [0x895ef1]
004d52c9 8a44241e                 mov al, byte ptr [esp + 0x1e]
004d52cd 33c9                     xor ecx, ecx
004d52cf 240f                     and al, 0xf
004d52d1 8ac8                     mov cl, al
004d52d3 8d048a                   lea eax, [edx + ecx*4]
004d52d6 668b10                   mov dx, word ptr [eax]
004d52d9 6601542424               add word ptr [esp + 0x24], dx
004d52de 668b4002                 mov ax, word ptr [eax + 2]
004d52e2 6601442426               add word ptr [esp + 0x26], ax
004d52e7 668b442424               mov ax, word ptr [esp + 0x24]
004d52ec 66c1e808                 shr ax, 8
004d52f0 33c9                     xor ecx, ecx
004d52f2 24fe                     and al, 0xfe
004d52f4 8a4e30                   mov cl, byte ptr [esi + 0x30]
004d52f7 88442414                 mov byte ptr [esp + 0x14], al
004d52fb 8d1489                   lea edx, [ecx + ecx*4]
004d52fe 668b442426               mov ax, word ptr [esp + 0x26]
004d5303 66c1e808                 shr ax, 8
004d5307 24fe                     and al, 0xfe
004d5309 88442415                 mov byte ptr [esp + 0x15], al
004d530d 8bc1                     mov eax, ecx
004d530f 8d0c92                   lea ecx, [edx + edx*4]
004d5312 0fbfbc01a07b5a00         movsx edi, word ptr [ecx + eax + 0x5a7ba0]
004d531a 8b442414                 mov eax, dword ptr [esp + 0x14]
004d531e 50                       push eax
004d531f e8dca2f7ff               call 0x44f600
004d5324 83c404                   add esp, 4
004d5327 3bf8                     cmp edi, eax
004d5329 7c16                     jl 0x4d5341
004d532b 8d442424                 lea eax, [esp + 0x24]
004d532f 50                       push eax
004d5330 e84ba6f7ff               call 0x44f980
004d5335 83c404                   add esp, 4
004d5338 84c0                     test al, al
004d533a 7405                     je 0x4d5341
004d533c c644241201               mov byte ptr [esp + 0x12], 1
004d5341 807c241200               cmp byte ptr [esp + 0x12], 0
004d5346 746d                     je 0x4d53b5
004d5348 bf01000000               mov edi, 1
004d534d 8b442420                 mov eax, dword ptr [esp + 0x20]
004d5351 0fbf4806                 movsx ecx, word ptr [eax + 6]
004d5355 c644241301               mov byte ptr [esp + 0x13], 1
004d535a 8b2c8d90038900           mov ebp, dword ptr [ecx*4 + 0x890390]
004d5361 85ed                     test ebp, ebp
004d5363 7449                     je 0x4d53ae
004d5365 8bc7                     mov eax, edi
004d5367 38452a                   cmp byte ptr [ebp + 0x2a], al
004d536a 752a                     jne 0x4d5396
004d536c 3bf5                     cmp esi, ebp
004d536e 7426                     je 0x4d5396
004d5370 66854576                 test word ptr [ebp + 0x76], ax
004d5374 7420                     je 0x4d5396
004d5376 668b4c241a               mov cx, word ptr [esp + 0x1a]
004d537b 66398d80000000           cmp word ptr [ebp + 0x80], cx
004d5382 7512                     jne 0x4d5396
004d5384 47                       inc edi
004d5385 8a8d82000000             mov cl, byte ptr [ebp + 0x82]
004d538b 80e10f                   and cl, 0xf
004d538e 33d2                     xor edx, edx
004d5390 8ad1                     mov dl, cl
004d5392 3bd3                     cmp edx, ebx
004d5394 7413                     je 0x4d53a9
004d5396 33c9                     xor ecx, ecx
004d5398 668b4d20                 mov cx, word ptr [ebp + 0x20]
004d539c 8b2c8d90038900           mov ebp, dword ptr [ecx*4 + 0x890390]
004d53a3 85ed                     test ebp, ebp
004d53a5 75c0                     jne 0x4d5367
004d53a7 eb05                     jmp 0x4d53ae
004d53a9 c644241300               mov byte ptr [esp + 0x13], 0
004d53ae 807c241300               cmp byte ptr [esp + 0x13], 0
004d53b3 750c                     jne 0x4d53c1
004d53b5 43                       inc ebx
004d53b6 83fb06                   cmp ebx, 6
004d53b9 0f8ea2feffff             jle 0x4d5261
004d53bf eb39                     jmp 0x4d53fa
004d53c1 8a8682000000             mov al, byte ptr [esi + 0x82]
004d53c7 4f                       dec edi
004d53c8 32d8                     xor bl, al
004d53ca 80e30f                   and bl, 0xf
004d53cd 32d8                     xor bl, al
004d53cf 83ff01                   cmp edi, 1
004d53d2 1ac0                     sbb al, al
004d53d4 889e82000000             mov byte ptr [esi + 0x82], bl
004d53da f6d8                     neg al
004d53dc c0e004                   shl al, 4
004d53df 8ac8                     mov cl, al
004d53e1 32cb                     xor cl, bl
004d53e3 80e10f                   and cl, 0xf
004d53e6 32c8                     xor cl, al
004d53e8 668b44241a               mov ax, word ptr [esp + 0x1a]
004d53ed 888e82000000             mov byte ptr [esi + 0x82], cl
004d53f3 66898680000000           mov word ptr [esi + 0x80], ax
004d53fa 807c241300               cmp byte ptr [esp + 0x13], 0
004d53ff 0f84defdffff             je 0x4d51e3
004d5405 8b44242c                 mov eax, dword ptr [esp + 0x2c]
004d5409 50                       push eax
004d540a e8c151fcff               call 0x49a5d0
004d540f 83c404                   add esp, 4
004d5412 8a442413                 mov al, byte ptr [esp + 0x13]
004d5416 5d                       pop ebp
004d5417 5f                       pop edi
004d5418 5e                       pop esi
004d5419 5b                       pop ebx
004d541a 83c428                   add esp, 0x28
004d541d c3                       ret 
004d541e cc                       int3 
004d541f cc                       int3 
