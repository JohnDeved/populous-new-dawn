"""Read-only audit of the frozen four-case witness; never alters native results."""
import json,hashlib,sys
from pathlib import Path
base=Path(__file__).resolve().parent
path=Path(sys.argv[1]) if len(sys.argv)>1 else base/'result-03.json'
r=json.loads(path.read_text())
assert r['status']=='passed'
assert r['identity']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
assert len(r['cases'])==4
cases={c['label']:c for c in r['cases']}
summary={}
def visit(c,n,kind='person'):
 return next(s for s in c['stages'] if s['label']==f'{kind} visit {n}')
for name,c in cases.items():
 assert c['status']=='passed' and len(c['stages'])==49
 for n in range(1,25):
  st=visit(c,n);anim=visit(c,n,'animation')
  assert st['after']['id']==1 and st['after']['personPointer']=='02000000'
  assert st['after']['counter']==n and st['after']['stamp']==n
  assert not any(e.get('supplied') for e in st['events']+anim['events'])
  names=[(e['name'],e['event']) for e in st['events']]
  assert names.index(('physics','enter'))<names.index(('route-advance','enter'))<names.index(('physics','return'))
  if ('guard','enter') in names:assert names.index(('physics','return'))<names.index(('guard','enter'))
  assert anim['before']==st['after']
  assert all(anim['before'][k]==anim['after'][k] for k in ('id','x','y','speed','route','state','status'))
  assert anim['after']['source']==anim['before']['source']
 changes=[]
 for n in range(1,25):
  st=visit(c,n)
  changes.append({'visit':n,'position':[st['after']['x'],st['after']['y']],
   'delta':[st['after']['x']-st['before']['x'],st['after']['y']-st['before']['y']],
   'velocity':[st['after']['vx'],st['after']['vh'],st['after']['vy']],
   'speed':st['after']['speed'],'route':st['after']['route'],'pursuit':st['after']['pursuit'],
   'state':st['after']['state'],'status':st['after']['status'],'source':st['after']['source'],
   'phaseAfterPerson':[st['after']['f1'],st['after']['f2']],
   'phaseAfterAnimation':[visit(c,n,'animation')['after']['f1'],visit(c,n,'animation')['after']['f2']]})
 summary[name]={'timeline':changes}
for name,clear_at,delta in [('near-guard',4,[61,17]),('far-guard',20,[63,8])]:
 c=cases[name];st=visit(c,clear_at)
 enters=[e for e in st['events'] if e['name']=='guard' and e['event']=='enter']
 returns=[e for e in st['events'] if e['name']=='guard' and e['event']=='return']
 assert len(enters)==len(returns)==1
 before,after=enters[0]['snapshot'],returns[0]['snapshot']
 assert before['pursuit'] and not after['pursuit']
 changed=[k for k in before if before[k]!=after[k]]
 assert set(changed)<=set(['flags2','pursuit','assignment'])
 following=visit(c,clear_at+1)
 assert [following['after']['x']-following['before']['x'],following['after']['y']-following['before']['y']]==delta
 assert following['after']['source']==40 and following['after']['speed']==61
 summary[name]['nearBoundary']={'visit':clear_at,'entry':before,'return':after,'changedFields':changed,'followingVisit':following['after']}
for name,first in [('target-loss',13),('move-control',12)]:
 c=cases[name]
 assert visit(c,first-1)['after']['speed']>0
 for n in range(first,25):
  p=visit(c,n)['after'];assert (p['x'],p['y'],p['speed'],p['state'],p['source'])==(4864,4352,0,19,48)
  if n>first:assert summary[name]['timeline'][n-1]['delta']==[0,0]
 assert any(visit(c,first)['after'][k] for k in ('vx','vy'))
 summary[name]['firstSettledVisit']=first
summary['checks']={'personVisits':96,'animationVisits':96,'totalStages':196,'personOrAnimationSuppliedLeaves':0,
 'resultSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'status':'passed'}
print(json.dumps(summary,indent=2))
