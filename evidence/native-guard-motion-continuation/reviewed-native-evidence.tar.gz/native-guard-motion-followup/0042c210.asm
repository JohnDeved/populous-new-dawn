0042c210 83ec38                   sub esp, 0x38
0042c213 33c9                     xor ecx, ecx
0042c215 b801000000               mov eax, 1
0042c21a 890dd95e8900             mov dword ptr [0x895ed9], ecx
0042c220 53                       push ebx
0042c221 56                       push esi
0042c222 57                       push edi
0042c223 55                       push ebp
0042c224 8d148dfd5e8900           lea edx, [ecx*4 + 0x895efd]
0042c22b 40                       inc eax
0042c22c 03c8                     add ecx, eax
0042c22e 891485d55e8900           mov dword ptr [eax*4 + 0x895ed5], edx
0042c235 83f808                   cmp eax, 8
0042c238 7eea                     jle 0x42c224
0042c23a c744242400000000         mov dword ptr [esp + 0x24], 0
0042c242 c744242800000000         mov dword ptr [esp + 0x28], 0
0042c24a c744242c50000000         mov dword ptr [esp + 0x2c], 0x50
0042c252 c744243064000000         mov dword ptr [esp + 0x30], 0x64
0042c25a c744243478000000         mov dword ptr [esp + 0x34], 0x78
0042c262 c744243882000000         mov dword ptr [esp + 0x38], 0x82
0042c26a c744243c8c000000         mov dword ptr [esp + 0x3c], 0x8c
0042c272 c744244096000000         mov dword ptr [esp + 0x40], 0x96
0042c27a c7442444a0000000         mov dword ptr [esp + 0x44], 0xa0
0042c282 c744241001000000         mov dword ptr [esp + 0x10], 1
0042c28a bf04000000               mov edi, 4
0042c28f b800080000               mov eax, 0x800
0042c294 33ed                     xor ebp, ebp
0042c296 99                       cdq 
0042c297 f77c2410                 idiv dword ptr [esp + 0x10]
0042c29b 8b9fd95e8900             mov ebx, dword ptr [edi + 0x895ed9]
0042c2a1 8944241c                 mov dword ptr [esp + 0x1c], eax
0042c2a5 83c304                   add ebx, 4
0042c2a8 83ff04                   cmp edi, 4
0042c2ab 7c51                     jl 0x42c2fe
0042c2ad 8b743c24                 mov esi, dword ptr [esp + edi + 0x24]
0042c2b1 8b442410                 mov eax, dword ptr [esp + 0x10]
0042c2b5 89442420                 mov dword ptr [esp + 0x20], eax
0042c2b9 66c74424140000           mov word ptr [esp + 0x14], 0
0042c2c0 66c74424160000           mov word ptr [esp + 0x16], 0
0042c2c7 85f6                     test esi, esi
0042c2c9 740f                     je 0x42c2da
0042c2cb 8d442414                 lea eax, [esp + 0x14]
0042c2cf 56                       push esi
0042c2d0 55                       push ebp
0042c2d1 50                       push eax
0042c2d2 e899a70b00               call 0x4e6a70
0042c2d7 83c40c                   add esp, 0xc
0042c2da 668b442414               mov ax, word ptr [esp + 0x14]
0042c2df 036c241c                 add ebp, dword ptr [esp + 0x1c]
0042c2e3 668903                   mov word ptr [ebx], ax
0042c2e6 81e5ff070000             and ebp, 0x7ff
0042c2ec 668b4c2416               mov cx, word ptr [esp + 0x16]
0042c2f1 83c304                   add ebx, 4
0042c2f4 66894bfe                 mov word ptr [ebx - 2], cx
0042c2f8 ff4c2420                 dec dword ptr [esp + 0x20]
0042c2fc 75bb                     jne 0x42c2b9
0042c2fe 83c704                   add edi, 4
0042c301 ff442410                 inc dword ptr [esp + 0x10]
0042c305 83ff20                   cmp edi, 0x20
0042c308 7e85                     jle 0x42c28f
0042c30a 5d                       pop ebp
0042c30b 5f                       pop edi
0042c30c 5e                       pop esi
0042c30d 5b                       pop ebx
0042c30e 83c438                   add esp, 0x38
0042c311 c3                       ret 
0042c312 cc                       int3 
0042c313 cc                       int3 
0042c314 cc                       int3 
0042c315 cc                       int3 
0042c316 cc                       int3 
0042c317 cc                       int3 
0042c318 cc                       int3 
0042c319 cc                       int3 
0042c31a cc                       int3 
0042c31b cc                       int3 
0042c31c cc                       int3 
0042c31d cc                       int3 
0042c31e cc                       int3 
0042c31f cc                       int3 
0042c320 83ec10                   sub esp, 0x10
0042c323 53                       push ebx
0042c324 56                       push esi
0042c325 57                       push edi
0042c326 55                       push ebp
0042c327 68b05a5a00               push 0x5a5ab0
0042c32c e87ffb0600               call 0x49beb0
0042c331 83c404                   add esp, 4
0042c334 3c01                     cmp al, 1
0042c336 1ac0                     sbb al, al
0042c338 f6d8                     neg al
0042c33a 88442413                 mov byte ptr [esp + 0x13], al
0042c33e 84c0                     test al, al
0042c340 7517                     jne 0x42c359
0042c342 68d05b5a00               push 0x5a5bd0
0042c347 e864fb0600               call 0x49beb0
0042c34c 83c404                   add esp, 4
