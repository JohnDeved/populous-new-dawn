"""Bounded original person scheduler segment, motion, command, and animation composition.

Supplied fixture: one Firewarrior and one stationary Shaman; flat height 0 native
terrain, fully passable walk mask, empty building/collision environment. Native
G/pool/preparation/state/physics/route/guard/animation routines execute. The real
allocated-person loop 004ec898..004ec8cb increments the class counter and calls
004ed700, which calls complete 004d32b0 and stamps the animation visit. Global
turn/sprite counters are supplied once per visit; wall-clock/rendering, other-world
scheduler phases, real allocation history, and arbitrary-terrain parity are not
claimed. The original EXE is mapped for Unicorn only, never OS-executed.
"""
import sys, json, struct, hashlib, traceback
scope_doc=__doc__
from pathlib import Path
from collections import deque
exe, root, baseline = map(Path,sys.argv[1:4])
# Reuse the established fixture/PE/constants/animation projection, not its results.
base_text=baseline.read_text().split("report={'identity':identity",1)[0]
base_text=base_text.replace('cpu.hook_add(UC_HOOK_CODE,hook)', '# baseline hook replaced by observer below')
exec(compile(base_text,str(baseline),'exec'),globals())
fields.update({'tribe':(0x2f,'b'),'physics':(0x30,'B'),'h':(0x41,'h'),
 'vx':(0x49,'h'),'vh':(0x4b,'h'),'vy':(0x4d,'h'),'dx':(0x43,'h'),'dy':(0x45,'h'),'dh':(0x47,'h'),
 'destinationX':(0x53,'H'),'destinationY':(0x55,'H'),'turnX':(0x57,'H'),'turnY':(0x59,'H'),
 'heading':(0x5d,'H'),'route':(0x63,'h'),'routeIndex':(0x67,'B'),'motionTimer':(0x61,'h'),
 'motionMode':(0x66,'B'),'anchorX':(0x68,'H'),'anchorY':(0x6a,'H'),'slowTurn':(0x7e,'B'),
 'cellNext':(0x20,'H'),'cellPrevious':(0x22,'H'),'life':(0x6e,'h')})
base_snap=snap
def snap():
 d=base_snap();d.update(personPointer=f'{p:08x}',targetPointer=f'{read(0x890390+73*4,"I"):08x}',
  pursuit=bool(d['flags2']&0x2000000),routePoolSha256=hashlib.sha256(cpu.mem_read(0x955c29,401*109)).hexdigest())
 d['routeRecordHex']=bytes(cpu.mem_read(0x955c29+d['route']*109,109)).hex() if d['route'] else None
 return d
leaves.clear();leaves.update({0x47a550:'selection-ui-refresh',0x48a050:'audio',0x436330:'command-acknowledgement'})
observed.update({0x4ec898:'scheduler-person-loop',0x4ed700:'class-dispatch',0x4d32b0:'person-processor',
 0x4e9050:'unsupported-ground-check',0x4e6d00:'physics',0x4eadc0:'route-advance',0x4ee580:'cell-insert',
 0x4e9d80:'destination',0x4e9e80:'route-plan',0x4ea970:'route-build',0x4ea460:'route-release',
 0x4ee770:'animation-list',0x4d43a0:'health-tail',0x4d4690:'combat-tail',0x4d9bd0:'tail-4d9bd0',
 0x4def50:'tail-4def50',0x4da2a0:'tail-4da2a0',0x438dc0:'move-order'})
watched_returns={};calls=[];recent=deque(maxlen=24)
class Boundary(Exception):pass
abort_addresses={0x4ed8a0:'unit allocation requires genuine free pool',0x401b40:'free-list world mutation'}
def hook2(c,a,size,u):
 recent.append(f'{a:08x}')
 sp=c.reg_read(UC_X86_REG_ESP)
 if a in watched_returns and watched_returns[a] and sp==watched_returns[a][-1][0]+4:
  _,name=watched_returns[a].pop();events.append({'event':'return','name':name,'address':f'{a:08x}','snapshot':snap()})
 if a in abort_addresses:raise Boundary(f'{abort_addresses[a]} at {a:08x}; caller return {read(sp,"I"):08x}')
 if a not in observed and a not in leaves:return
 name=observed.get(a,leaves.get(a));ret=read(sp,'I')
 e={'event':'enter','name':name,'address':f'{a:08x}','callerReturn':f'{ret:08x}','snapshot':snap()}
 if a in leaves:
  e['supplied']=True;c.reg_write(UC_X86_REG_EAX,0);c.reg_write(UC_X86_REG_EIP,ret);c.reg_write(UC_X86_REG_ESP,sp+4)
 else:
  watched_returns.setdefault(ret,[]).append((sp,name))
 events.append(e)
cpu.hook_add(UC_HOOK_CODE,hook2)
from unicorn import UC_HOOK_MEM_INVALID
invalid_memory=[]
def invalid(c,access,address,size,value,user):
 invalid_memory.append({'access':access,'address':f'{address:08x}','size':size,'eip':f'{cpu.reg_read(UC_X86_REG_EIP):08x}'})
 return False
cpu.hook_add(UC_HOOK_MEM_INVALID,invalid)
report={'identity':identity,'python':sys.version,'unicorn':unicorn_version,'capstone':capstone_version,
 'fixtureAssumptions':['Dedicated synthetic person records, not a captured original save','Firewarrior id1 at4096,4096; Shaman id73 at+600 or+1800 x, same y','Initial state19/source48/f1=1/f2=3; speed and velocity zero; goal,destination,turn point=current position','Flat zero-height terrain/category0 flags0; all-walkable mask; no building or combat targets','Shaman remains a real target/collision record but is not scheduled; stationary target supplied','Native startup0042c210 and pinned MWSEARCH.DAT loaded; original constants and sprite frame counts','Single allocated-person list; original class-counter and stamp operations; supplied global turn and sprite counter','LevelFlags2=0x50000 suppresses formation/footprint world effects inherited from accepted fixture','No OS, wall-clock, renderer, allocation-history, or arbitrary-world parity claim'],
 'scope':scope_doc,'sourceHead':'c20a297f5f815ce404f796b08f77ea56396f96da','cases':[],
 'suppliedLeaves':{f'{a:08x}':n for a,n in leaves.items()},'inputs':{}}
for path in [exe,exe.parent/'data/mwsearch.dat',exe.parent/'levels/constant.dat',exe.parent/'data/vstart-0.ani',exe.parent/'data/vfra-0.ani',root/'scripts/decomp.py',baseline,Path(__file__),root/'app/original-rules.json',root/'app/original-constants.json']:
 report['inputs'][str(path.resolve())]=hashlib.sha256(path.read_bytes()).hexdigest()
def stage(label,entry,*args,end=None):
 events.clear();watched_returns.clear();before=snap()
 if end:
  write(stack,'I',stop);cpu.reg_write(UC_X86_REG_ESP,stack)
  cpu.emu_start(entry,end,timeout=3000000,count=3000000)
  assert cpu.reg_read(UC_X86_REG_EIP)==end
 else:call(entry,*args)
 row={'label':label,'entry':f'{entry:08x}','stop':f'{end:08x}' if end else 'return','before':before,'after':snap(),'events':list(events)}
 report['cases'][-1]['stages'].append(row)
 return row

# Established check-native-resting-slots.py startup input and original producer.
search_data=(exe.parent/'data/mwsearch.dat').read_bytes()
assert hashlib.sha256(search_data).hexdigest()=='0c39b12d160658863c2df89aa34484dff459e48ea0b5634658b7473ca940fae0'
cpu.mem_write(0x8929cd,search_data)
call(0x42c210)
report['restingSlotProducer']={'entry':'0042c210','defaultPointer':f'{read(0x895ef1,"I"):08x}','searchFileSha256':hashlib.sha256(search_data).hexdigest()}
pristine=[(a,bytes(cpu.mem_read(a,b-a+1))) for a,b,_ in cpu.mem_regions()]

def new_fixture(distance):
 for address,data in pristine:cpu.mem_write(address,data)
 fixture()
 # Baseline flags 0x50000 suppress formation/footprint effects. No physics leaf.
 # Flat native terrain, native default category 0, no obstacles or buildings.
 write(0x890324,'I',p);write(0x890330,'I',0)
 cpu.mem_write(0x955c29,bytes(401*109));write(0x9557ae,'hhh',0,0,0)
 write(0x9557b6,'II',0,0);write(0x9557c0,'B',0);write(0x9557c8,'I',0)
 write(s+0x3d,'HH',4096+distance,4096)
 write(p+0x53,'HHHH',4096,4096,4096,4096)
 for obj in (p,s):
  write(obj+0x6c,'hh',1000,1000)
  call(0x4ee470,obj,obj+0x3d)
 events.clear();watched_returns.clear()

for label,distance,visits in [('near-guard',600,24),('far-guard',1800,24),('target-loss',600,24),('move-control',600,24)]:
 report['cases'].append({'label':label,'initialTargetDistance':distance,'requestedVisits':visits,'stages':[]})
 try:
  new_fixture(distance)
  report['cases'][-1]['initialSnapshot']=snap()
  if label=='move-control':
   write(packet+4,'IIB',3,((4096+distance)>>8)|((4096>>8)<<8),0x57)
   stage('native command3 producer',0x444f60,tribe,packet)
  else:stage('native G producer',0x443b40,0,1)
  for turn in range(1,visits+1):
   if label=='target-loss' and turn==5:
    write(s+0xc,'I',read(s+0xc,'I')|1)
    report['cases'][-1]['intervention']={'beforeVisit':turn,'targetFlags2SetBit':1,'reason':'explicit target-loss input'}
   write(0x897981,'I',turn);write(0x89d188,'I',turn)
   stage(f'person visit {turn}',0x4ec898,end=0x4ec8cb)
   stage(f'animation visit {turn}',0x4ee770)
  report['cases'][-1]['status']='passed'
 except Exception as error:
  report['cases'][-1].update(status='blocked',error=str(error),traceback=traceback.format_exc(),
   failure={'eip':f'{cpu.reg_read(UC_X86_REG_EIP):08x}','recent':list(recent),'snapshot':snap(),'events':list(events),'invalidMemory':list(invalid_memory)})
  invalid_memory.clear()
report['status']='passed' if all(c['status']=='passed' for c in report['cases']) else 'partial-with-explicit-boundary'
print(json.dumps(report,indent=2))
if report['status']!='passed':sys.exit(2)
