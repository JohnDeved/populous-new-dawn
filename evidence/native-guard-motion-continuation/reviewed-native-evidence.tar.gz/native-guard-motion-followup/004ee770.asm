004ee770 f60561c6890002           test byte ptr [0x89c661], 2
004ee777 56                       push esi
004ee778 7534                     jne 0x4ee7ae
004ee77a 8b3524038900             mov esi, dword ptr [0x890324]
004ee780 85f6                     test esi, esi
004ee782 7410                     je 0x4ee794
004ee784 56                       push esi
004ee785 e826000000               call 0x4ee7b0
004ee78a 83c404                   add esp, 4
004ee78d 8b7604                   mov esi, dword ptr [esi + 4]
004ee790 85f6                     test esi, esi
004ee792 75f0                     jne 0x4ee784
004ee794 8b3530038900             mov esi, dword ptr [0x890330]
004ee79a 85f6                     test esi, esi
004ee79c 7410                     je 0x4ee7ae
004ee79e 56                       push esi
004ee79f e80c000000               call 0x4ee7b0
004ee7a4 83c404                   add esp, 4
004ee7a7 8b7604                   mov esi, dword ptr [esi + 4]
004ee7aa 85f6                     test esi, esi
004ee7ac 75f0                     jne 0x4ee79e
004ee7ae 5e                       pop esi
004ee7af c3                       ret 
