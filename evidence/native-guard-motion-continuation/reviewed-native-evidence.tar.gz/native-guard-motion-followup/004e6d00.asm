004e6d00 83ec1c                   sub esp, 0x1c
004e6d03 53                       push ebx
004e6d04 56                       push esi
004e6d05 57                       push edi
004e6d06 33db                     xor ebx, ebx
004e6d08 8b74242c                 mov esi, dword ptr [esp + 0x2c]
004e6d0c 55                       push ebp
004e6d0d 885c2420                 mov byte ptr [esp + 0x20], bl
004e6d11 8b4e0c                   mov ecx, dword ptr [esi + 0xc]
004e6d14 f6c540                   test ch, 0x40
004e6d17 0f85590b0000             jne 0x4e7876
004e6d1d 8d463d                   lea eax, [esi + 0x3d]
004e6d20 8d7c2410                 lea edi, [esp + 0x10]
004e6d24 8b10                     mov edx, dword ptr [eax]
004e6d26 8917                     mov dword ptr [edi], edx
004e6d28 668b4004                 mov ax, word ptr [eax + 4]
004e6d2c 66894704                 mov word ptr [edi + 4], ax
004e6d30 33c0                     xor eax, eax
004e6d32 8a4630                   mov al, byte ptr [esi + 0x30]
004e6d35 8d2c80                   lea ebp, [eax + eax*4]
004e6d38 8bd0                     mov edx, eax
004e6d3a 885c2418                 mov byte ptr [esp + 0x18], bl
004e6d3e 8d44ad00                 lea eax, [ebp + ebp*4]
004e6d42 f6c520                   test ch, 0x20
004e6d45 8dac10907b5a00           lea ebp, [eax + edx + 0x5a7b90]
004e6d4c 744a                     je 0x4e6d98
004e6d4e c644241801               mov byte ptr [esp + 0x18], 1
004e6d53 8d4649                   lea eax, [esi + 0x49]
004e6d56 50                       push eax
004e6d57 56                       push esi
004e6d58 e8230c0000               call 0x4e7980
004e6d5d 668b4649                 mov ax, word ptr [esi + 0x49]
004e6d61 83c408                   add esp, 8
004e6d64 6601442410               add word ptr [esp + 0x10], ax
004e6d69 668b4e4b                 mov cx, word ptr [esi + 0x4b]
004e6d6d 66014c2414               add word ptr [esp + 0x14], cx
004e6d72 668b564d                 mov dx, word ptr [esi + 0x4d]
004e6d76 6601542412               add word ptr [esp + 0x12], dx
004e6d7b 668b4512                 mov ax, word ptr [ebp + 0x12]
004e6d7f 6629464b                 sub word ptr [esi + 0x4b], ax
004e6d83 f6451804                 test byte ptr [ebp + 0x18], 4
004e6d87 750f                     jne 0x4e6d98
004e6d89 8d442410                 lea eax, [esp + 0x10]
004e6d8d 53                       push ebx
004e6d8e 50                       push eax
004e6d8f 56                       push esi
004e6d90 e84b2e0000               call 0x4e9be0
004e6d95 83c40c                   add esp, 0xc
004e6d98 807c241800               cmp byte ptr [esp + 0x18], 0
004e6d9d 7421                     je 0x4e6dc0
004e6d9f f6460c02                 test byte ptr [esi + 0xc], 2
004e6da3 750d                     jne 0x4e6db2
004e6da5 8d442410                 lea eax, [esp + 0x10]
004e6da9 50                       push eax
004e6daa e8a1c9f7ff               call 0x463750
004e6daf 83c404                   add esp, 4
004e6db2 8d442410                 lea eax, [esp + 0x10]
004e6db6 50                       push eax
004e6db7 56                       push esi
004e6db8 e8c3770000               call 0x4ee580
004e6dbd 83c408                   add esp, 8
004e6dc0 8b460c                   mov eax, dword ptr [esi + 0xc]
004e6dc3 a900000800               test eax, 0x80000
004e6dc8 0f8539050000             jne 0x4e7307
004e6dce c744242000000000         mov dword ptr [esp + 0x20], 0
004e6dd6 f6462e03                 test byte ptr [esi + 0x2e], 3
004e6dda 7508                     jne 0x4e6de4
004e6ddc 0d00100000               or eax, 0x1000
004e6de1 89460c                   mov dword ptr [esi + 0xc], eax
004e6de4 8b460c                   mov eax, dword ptr [esi + 0xc]
004e6de7 f6c410                   test ah, 0x10
004e6dea 0f84b0010000             je 0x4e6fa0
004e6df0 f6c408                   test ah, 8
004e6df3 0f85a7010000             jne 0x4e6fa0
004e6df9 a880                     test al, 0x80
004e6dfb 756e                     jne 0x4e6e6b
004e6dfd 8b442410                 mov eax, dword ptr [esp + 0x10]
004e6e01 394657                   cmp dword ptr [esi + 0x57], eax
004e6e04 745f                     je 0x4e6e65
004e6e06 668b4657                 mov ax, word ptr [esi + 0x57]
004e6e0a 662b463d                 sub ax, word ptr [esi + 0x3d]
004e6e0e 0fb7f8                   movzx edi, ax
004e6e11 668b4659                 mov ax, word ptr [esi + 0x59]
004e6e15 8bcf                     mov ecx, edi
004e6e17 662b463f                 sub ax, word ptr [esi + 0x3f]
004e6e1b 85ff                     test edi, edi
004e6e1d 0fb7c0                   movzx eax, ax
004e6e20 7d04                     jge 0x4e6e26
004e6e22 8bcf                     mov ecx, edi
004e6e24 f7d9                     neg ecx
004e6e26 8bd0                     mov edx, eax
004e6e28 85c0                     test eax, eax
004e6e2a 7d04                     jge 0x4e6e30
004e6e2c 8bd0                     mov edx, eax
004e6e2e f7da                     neg edx
004e6e30 81f900800000             cmp ecx, 0x8000
004e6e36 7c06                     jl 0x4e6e3e
004e6e38 8db90000ffff             lea edi, [ecx - 0x10000]
004e6e3e 81fa00800000             cmp edx, 0x8000
004e6e44 7c06                     jl 0x4e6e4c
004e6e46 8d820000ffff             lea eax, [edx - 0x10000]
004e6e4c f7d8                     neg eax
004e6e4e 50                       push eax
004e6e4f 57                       push edi
004e6e50 e81ff20900               call 0x586074
004e6e55 83c408                   add esp, 8
004e6e58 33c9                     xor ecx, ecx
004e6e5a 668bc8                   mov cx, ax
004e6e5d 81e1ff070000             and ecx, 0x7ff
004e6e63 eb0a                     jmp 0x4e6e6f
004e6e65 0fbf4e5d                 movsx ecx, word ptr [esi + 0x5d]
004e6e69 eb04                     jmp 0x4e6e6f
004e6e6b 0fbf4e57                 movsx ecx, word ptr [esi + 0x57]
004e6e6f 807e7e00                 cmp byte ptr [esi + 0x7e], 0
004e6e73 0f859f000000             jne 0x4e6f18
004e6e79 8b460c                   mov eax, dword ptr [esi + 0xc]
004e6e7c a900082000               test eax, 0x200800
004e6e81 0f8507010000             jne 0x4e6f8e
004e6e87 0fbf565d                 movsx edx, word ptr [esi + 0x5d]
004e6e8b 0fbff9                   movsx edi, cx
004e6e8e 2bfa                     sub edi, edx
004e6e90 8bc7                     mov eax, edi
004e6e92 7904                     jns 0x4e6e98
004e6e94 8bc7                     mov eax, edi
004e6e96 f7d8                     neg eax
004e6e98 3d00040000               cmp eax, 0x400
004e6e9d 7e09                     jle 0x4e6ea8
004e6e9f b900080000               mov ecx, 0x800
004e6ea4 2bc8                     sub ecx, eax
004e6ea6 8bc1                     mov eax, ecx
004e6ea8 0fbfc8                   movsx ecx, ax
004e6eab 6633c0                   xor ax, ax
004e6eae 85ff                     test edi, edi
004e6eb0 742d                     je 0x4e6edf
004e6eb2 8bc7                     mov eax, edi
004e6eb4 7d04                     jge 0x4e6eba
004e6eb6 8bc7                     mov eax, edi
004e6eb8 f7d8                     neg eax
004e6eba 3d00040000               cmp eax, 0x400
004e6ebf 7e12                     jle 0x4e6ed3
004e6ec1 85ff                     test edi, edi
004e6ec3 7d08                     jge 0x4e6ecd
004e6ec5 81c700080000             add edi, 0x800
004e6ecb eb06                     jmp 0x4e6ed3
004e6ecd 81ef00080000             sub edi, 0x800
004e6ed3 66b80100                 mov ax, 1
004e6ed7 85ff                     test edi, edi
004e6ed9 7d04                     jge 0x4e6edf
004e6edb 66b8ffff                 mov ax, 0xffff
004e6edf 0fbff8                   movsx edi, ax
004e6ee2 33c0                     xor eax, eax
004e6ee4 8a4630                   mov al, byte ptr [esi + 0x30]
004e6ee7 89442418                 mov dword ptr [esp + 0x18], eax
004e6eeb 8d1c80                   lea ebx, [eax + eax*4]
004e6eee 8d049b                   lea eax, [ebx + ebx*4]
004e6ef1 8b5c2418                 mov ebx, dword ptr [esp + 0x18]
004e6ef5 0fbf8418907b5a00         movsx eax, word ptr [eax + ebx + 0x5a7b90]
004e6efd 3bc8                     cmp ecx, eax
004e6eff 7e0a                     jle 0x4e6f0b
004e6f01 c744242001000000         mov dword ptr [esp + 0x20], 1
004e6f09 8bc8                     mov ecx, eax
004e6f0b 0fafcf                   imul ecx, edi
004e6f0e 03ca                     add ecx, edx
004e6f10 81e1ff070000             and ecx, 0x7ff
004e6f16 eb76                     jmp 0x4e6f8e
004e6f18 0fbf7e5d                 movsx edi, word ptr [esi + 0x5d]
004e6f1c 0fbfc9                   movsx ecx, cx
004e6f1f 2bcf                     sub ecx, edi
004e6f21 8bc1                     mov eax, ecx
004e6f23 7904                     jns 0x4e6f29
004e6f25 8bc1                     mov eax, ecx
004e6f27 f7d8                     neg eax
004e6f29 3d00040000               cmp eax, 0x400
004e6f2e 7e09                     jle 0x4e6f39
004e6f30 ba00080000               mov edx, 0x800
004e6f35 2bd0                     sub edx, eax
004e6f37 8bc2                     mov eax, edx
004e6f39 0fbfc0                   movsx eax, ax
004e6f3c 6633db                   xor bx, bx
004e6f3f 85c9                     test ecx, ecx
004e6f41 742e                     je 0x4e6f71
004e6f43 8bd1                     mov edx, ecx
004e6f45 7d04                     jge 0x4e6f4b
004e6f47 8bd1                     mov edx, ecx
004e6f49 f7da                     neg edx
004e6f4b 81fa00040000             cmp edx, 0x400
004e6f51 7e12                     jle 0x4e6f65
004e6f53 85c9                     test ecx, ecx
004e6f55 7d08                     jge 0x4e6f5f
004e6f57 81c100080000             add ecx, 0x800
004e6f5d eb06                     jmp 0x4e6f65
004e6f5f 81e900080000             sub ecx, 0x800
004e6f65 66bb0100                 mov bx, 1
004e6f69 85c9                     test ecx, ecx
004e6f6b 7d04                     jge 0x4e6f71
004e6f6d 66bbffff                 mov bx, 0xffff
004e6f71 99                       cdq 
004e6f72 c744241800000000         mov dword ptr [esp + 0x18], 0
004e6f7a 8a4e7e                   mov cl, byte ptr [esi + 0x7e]
004e6f7d 884c2418                 mov byte ptr [esp + 0x18], cl
004e6f81 f77c2418                 idiv dword ptr [esp + 0x18]
004e6f85 0fbfd3                   movsx edx, bx
004e6f88 0fafc2                   imul eax, edx
004e6f8b 8d0c38                   lea ecx, [eax + edi]
004e6f8e 837c242000               cmp dword ptr [esp + 0x20], 0
004e6f93 66894e5d                 mov word ptr [esi + 0x5d], cx
004e6f97 7507                     jne 0x4e6fa0
004e6f99 81660cffefffff           and dword ptr [esi + 0xc], 0xffffefff
004e6fa0 8b460c                   mov eax, dword ptr [esi + 0xc]
004e6fa3 a820                     test al, 0x20
004e6fa5 7515                     jne 0x4e6fbc
004e6fa7 f6c480                   test ah, 0x80
004e6faa 668b465d                 mov ax, word ptr [esi + 0x5d]
004e6fae 7408                     je 0x4e6fb8
004e6fb0 66050004                 add ax, 0x400
004e6fb4 6625ff07                 and ax, 0x7ff
004e6fb8 66894626                 mov word ptr [esi + 0x26], ax
004e6fbc 8b442412                 mov eax, dword ptr [esp + 0x12]
004e6fc0 8b4c2410                 mov ecx, dword ptr [esp + 0x10]
004e6fc4 50                       push eax
004e6fc5 51                       push ecx
004e6fc6 e87579f6ff               call 0x44e940
004e6fcb 83c408                   add esp, 8
004e6fce 663b442414               cmp ax, word ptr [esp + 0x14]
004e6fd3 0f8cf4010000             jl 0x4e71cd
004e6fd9 f6461104                 test byte ptr [esi + 0x11], 4
004e6fdd 7415                     je 0x4e6ff4
004e6fdf 8d442410                 lea eax, [esp + 0x10]
004e6fe3 8a4e2f                   mov cl, byte ptr [esi + 0x2f]
004e6fe6 50                       push eax
004e6fe7 51                       push ecx
004e6fe8 6a03                     push 3
004e6fea 6a07                     push 7
004e6fec e8af680000               call 0x4ed8a0
004e6ff1 83c410                   add esp, 0x10
004e6ff4 816610fffbffff           and dword ptr [esi + 0x10], 0xfffffbff
004e6ffb 0fbf465f                 movsx eax, word ptr [esi + 0x5f]
004e6fff 89442418                 mov dword ptr [esp + 0x18], eax
004e7003 8b460c                   mov eax, dword ptr [esi + 0xc]
004e7006 f6c402                   test ah, 2
004e7009 7444                     je 0x4e704f
004e700b a880                     test al, 0x80
004e700d 7540                     jne 0x4e704f
004e700f 8d7e57                   lea edi, [esi + 0x57]
004e7012 6800040000               push 0x400
004e7017 57                       push edi
004e7018 8d463d                   lea eax, [esi + 0x3d]
004e701b 6a38                     push 0x38
004e701d 50                       push eax
004e701e e8ed090000               call 0x4e7a10
004e7023 83c410                   add esp, 0x10
004e7026 84c0                     test al, al
004e7028 7425                     je 0x4e704f
004e702a 8d463d                   lea eax, [esi + 0x3d]
004e702d 50                       push eax
004e702e 57                       push edi
004e702f e81c94f6ff               call 0x450450
004e7034 0fbf4e5f                 movsx ecx, word ptr [esi + 0x5f]
004e7038 0fafc9                   imul ecx, ecx
004e703b 83c408                   add esp, 8
004e703e 3bc8                     cmp ecx, eax
004e7040 7e0d                     jle 0x4e704f
004e7042 50                       push eax
004e7043 e8b8ef0900               call 0x586000
004e7048 8944241c                 mov dword ptr [esp + 0x1c], eax
004e704c 83c404                   add esp, 4
004e704f 837c241800               cmp dword ptr [esp + 0x18], 0
004e7054 0f847e060000             je 0x4e76d8
004e705a 56                       push esi
004e705b 8d7e4d                   lea edi, [esi + 0x4d]
004e705e 8d5e4b                   lea ebx, [esi + 0x4b]
004e7061 e8ea280000               call 0x4e9950
004e7066 66c746490000             mov word ptr [esi + 0x49], 0
004e706c 66c7070000               mov word ptr [edi], 0
004e7071 83c404                   add esp, 4
004e7074 66833b00                 cmp word ptr [ebx], 0
004e7078 7d05                     jge 0x4e707f
004e707a 66c7030000               mov word ptr [ebx], 0
004e707f 8b4c2418                 mov ecx, dword ptr [esp + 0x18]
004e7083 8d542410                 lea edx, [esp + 0x10]
004e7087 0fbf465d                 movsx eax, word ptr [esi + 0x5d]
004e708b 50                       push eax
004e708c 51                       push ecx
004e708d 52                       push edx
004e708e 8d4649                   lea eax, [esi + 0x49]
004e7091 50                       push eax
004e7092 e859230000               call 0x4e93f0
004e7097 83c410                   add esp, 0x10
004e709a 33c0                     xor eax, eax
004e709c 8a4630                   mov al, byte ptr [esi + 0x30]
004e709f 8bc8                     mov ecx, eax
004e70a1 8d1480                   lea edx, [eax + eax*4]
004e70a4 8d0492                   lea eax, [edx + edx*4]
004e70a7 03c1                     add eax, ecx
004e70a9 0fbf6e49                 movsx ebp, word ptr [esi + 0x49]
004e70ad 0fbf90987b5a00           movsx edx, word ptr [eax + 0x5a7b98]
004e70b4 0fbf889a7b5a00           movsx ecx, word ptr [eax + 0x5a7b9a]
004e70bb 8bc2                     mov eax, edx
004e70bd f7d8                     neg eax
004e70bf 3be8                     cmp ebp, eax
004e70c1 7d12                     jge 0x4e70d5
004e70c3 89542418                 mov dword ptr [esp + 0x18], edx
004e70c7 66f75c2418               neg word ptr [esp + 0x18]
004e70cc 668b6c2418               mov bp, word ptr [esp + 0x18]
004e70d1 66896e49                 mov word ptr [esi + 0x49], bp
004e70d5 0fbf6e49                 movsx ebp, word ptr [esi + 0x49]
004e70d9 3bea                     cmp ebp, edx
004e70db 7e04                     jle 0x4e70e1
004e70dd 66895649                 mov word ptr [esi + 0x49], dx
004e70e1 0fbf2f                   movsx ebp, word ptr [edi]
004e70e4 3be8                     cmp ebp, eax
004e70e6 7d08                     jge 0x4e70f0
004e70e8 8bc2                     mov eax, edx
004e70ea 66f7d8                   neg ax
004e70ed 668907                   mov word ptr [edi], ax
004e70f0 0fbf07                   movsx eax, word ptr [edi]
004e70f3 3bc2                     cmp eax, edx
004e70f5 7e03                     jle 0x4e70fa
004e70f7 668917                   mov word ptr [edi], dx
004e70fa 0fbf03                   movsx eax, word ptr [ebx]
004e70fd 8bd1                     mov edx, ecx
004e70ff f7da                     neg edx
004e7101 3bc2                     cmp eax, edx
004e7103 7d08                     jge 0x4e710d
004e7105 8bc1                     mov eax, ecx
004e7107 66f7d8                   neg ax
004e710a 668903                   mov word ptr [ebx], ax
004e710d 0fbf03                   movsx eax, word ptr [ebx]
004e7110 3bc1                     cmp eax, ecx
004e7112 7e03                     jle 0x4e7117
004e7114 66890b                   mov word ptr [ebx], cx
004e7117 668b4649                 mov ax, word ptr [esi + 0x49]
004e711b 6601442410               add word ptr [esp + 0x10], ax
004e7120 668b0b                   mov cx, word ptr [ebx]
004e7123 66014c2414               add word ptr [esp + 0x14], cx
004e7128 668b17                   mov dx, word ptr [edi]
004e712b 6601542412               add word ptr [esp + 0x12], dx
004e7130 8b442412                 mov eax, dword ptr [esp + 0x12]
004e7134 8b4c2410                 mov ecx, dword ptr [esp + 0x10]
004e7138 50                       push eax
004e7139 51                       push ecx
004e713a e80178f6ff               call 0x44e940
004e713f 668944241c               mov word ptr [esp + 0x1c], ax
004e7144 8d4c2418                 lea ecx, [esp + 0x18]
004e7148 83c408                   add esp, 8
004e714b 51                       push ecx
004e714c 56                       push esi
004e714d e87e070300               call 0x5178d0
004e7152 83c408                   add esp, 8
004e7155 33c9                     xor ecx, ecx
004e7157 8ac8                     mov cl, al
004e7159 85c9                     test ecx, ecx
004e715b 0f8477050000             je 0x4e76d8
004e7161 837c242000               cmp dword ptr [esp + 0x20], 0
004e7166 7537                     jne 0x4e719f
004e7168 8d442410                 lea eax, [esp + 0x10]
004e716c 50                       push eax
004e716d 56                       push esi
004e716e e8ad250000               call 0x4e9720
004e7173 83c408                   add esp, 8
004e7176 84c0                     test al, al
004e7178 0f855a050000             jne 0x4e76d8
004e717e 56                       push esi
004e717f 8d463d                   lea eax, [esi + 0x3d]
004e7182 50                       push eax
004e7183 e8f8060000               call 0x4e7880
004e7188 83c408                   add esp, 8
004e718b 84c0                     test al, al
004e718d 0f8445050000             je 0x4e76d8
004e7193 814e0c00000800           or dword ptr [esi + 0xc], 0x80000
004e719a e939050000               jmp 0x4e76d8
004e719f 668b463d                 mov ax, word ptr [esi + 0x3d]
004e71a3 6689442410               mov word ptr [esp + 0x10], ax
004e71a8 668b4e3f                 mov cx, word ptr [esi + 0x3f]
004e71ac 66894c2412               mov word ptr [esp + 0x12], cx
004e71b1 8b4c2412                 mov ecx, dword ptr [esp + 0x12]
004e71b5 8b442410                 mov eax, dword ptr [esp + 0x10]
004e71b9 51                       push ecx
004e71ba 50                       push eax
004e71bb e88077f6ff               call 0x44e940
004e71c0 668944241c               mov word ptr [esp + 0x1c], ax
004e71c5 83c408                   add esp, 8
004e71c8 e90b050000               jmp 0x4e76d8
004e71cd 814e1000040000           or dword ptr [esi + 0x10], 0x400
004e71d4 f6460e04                 test byte ptr [esi + 0xe], 4
004e71d8 7508                     jne 0x4e71e2
004e71da 668b4512                 mov ax, word ptr [ebp + 0x12]
004e71de 6629464b                 sub word ptr [esi + 0x4b], ax
004e71e2 668b7e49                 mov di, word ptr [esi + 0x49]
004e71e6 8d4e4d                   lea ecx, [esi + 0x4d]
004e71e9 0fbfd7                   movsx edx, di
004e71ec 0fbf19                   movsx ebx, word ptr [ecx]
004e71ef 8bc2                     mov eax, edx
004e71f1 85d2                     test edx, edx
004e71f3 7d04                     jge 0x4e71f9
004e71f5 8bc2                     mov eax, edx
004e71f7 f7d8                     neg eax
004e71f9 83f802                   cmp eax, 2
004e71fc 7c10                     jl 0x4e720e
004e71fe 85d2                     test edx, edx
004e7200 7e06                     jle 0x4e7208
004e7202 6683ef02                 sub di, 2
004e7206 eb09                     jmp 0x4e7211
004e7208 6683c702                 add di, 2
004e720c eb03                     jmp 0x4e7211
004e720e 662bfa                   sub di, dx
004e7211 66897e49                 mov word ptr [esi + 0x49], di
004e7215 8bc3                     mov eax, ebx
004e7217 85db                     test ebx, ebx
004e7219 7d04                     jge 0x4e721f
004e721b 8bc3                     mov eax, ebx
004e721d f7d8                     neg eax
004e721f 83f802                   cmp eax, 2
004e7222 7c10                     jl 0x4e7234
004e7224 85db                     test ebx, ebx
004e7226 7e06                     jle 0x4e722e
004e7228 66832902                 sub word ptr [ecx], 2
004e722c eb09                     jmp 0x4e7237
004e722e 66830102                 add word ptr [ecx], 2
004e7232 eb03                     jmp 0x4e7237
004e7234 662919                   sub word ptr [ecx], bx
004e7237 33d2                     xor edx, edx
004e7239 8a5630                   mov dl, byte ptr [esi + 0x30]
004e723c 8bc2                     mov eax, edx
004e723e 8d1c92                   lea ebx, [edx + edx*4]
004e7241 8d149b                   lea edx, [ebx + ebx*4]
004e7244 03c2                     add eax, edx
004e7246 0fbfb8987b5a00           movsx edi, word ptr [eax + 0x5a7b98]
004e724d 0fbf909a7b5a00           movsx edx, word ptr [eax + 0x5a7b9a]
004e7254 0fbf4649                 movsx eax, word ptr [esi + 0x49]
004e7258 8bdf                     mov ebx, edi
004e725a f7db                     neg ebx
004e725c 3bc3                     cmp eax, ebx
004e725e 7d09                     jge 0x4e7269
004e7260 8bc7                     mov eax, edi
004e7262 66f7d8                   neg ax
004e7265 66894649                 mov word ptr [esi + 0x49], ax
004e7269 0fbf4649                 movsx eax, word ptr [esi + 0x49]
004e726d 3bc7                     cmp eax, edi
004e726f 7e04                     jle 0x4e7275
004e7271 66897e49                 mov word ptr [esi + 0x49], di
004e7275 0fbf01                   movsx eax, word ptr [ecx]
004e7278 3bc3                     cmp eax, ebx
004e727a 7d08                     jge 0x4e7284
004e727c 8bc7                     mov eax, edi
004e727e 66f7d8                   neg ax
004e7281 668901                   mov word ptr [ecx], ax
004e7284 0fbf01                   movsx eax, word ptr [ecx]
004e7287 3bc7                     cmp eax, edi
004e7289 7e03                     jle 0x4e728e
004e728b 668939                   mov word ptr [ecx], di
004e728e 8d7e4b                   lea edi, [esi + 0x4b]
004e7291 8bda                     mov ebx, edx
004e7293 f7db                     neg ebx
004e7295 0fbf07                   movsx eax, word ptr [edi]
004e7298 3bc3                     cmp eax, ebx
004e729a 7d08                     jge 0x4e72a4
004e729c 8bc2                     mov eax, edx
004e729e 66f7d8                   neg ax
004e72a1 668907                   mov word ptr [edi], ax
004e72a4 0fbf07                   movsx eax, word ptr [edi]
004e72a7 3bc2                     cmp eax, edx
004e72a9 7e03                     jle 0x4e72ae
004e72ab 668917                   mov word ptr [edi], dx
004e72ae 668b4649                 mov ax, word ptr [esi + 0x49]
004e72b2 6a01                     push 1
004e72b4 6601442414               add word ptr [esp + 0x14], ax
004e72b9 8d442414                 lea eax, [esp + 0x14]
004e72bd 668b17                   mov dx, word ptr [edi]
004e72c0 50                       push eax
004e72c1 660154241c               add word ptr [esp + 0x1c], dx
004e72c6 56                       push esi
004e72c7 668b09                   mov cx, word ptr [ecx]
004e72ca 66014c241e               add word ptr [esp + 0x1e], cx
004e72cf e80c290000               call 0x4e9be0
004e72d4 8b4c241e                 mov ecx, dword ptr [esp + 0x1e]
004e72d8 8b54241c                 mov edx, dword ptr [esp + 0x1c]
004e72dc 83c40c                   add esp, 0xc
004e72df 51                       push ecx
004e72e0 52                       push edx
004e72e1 e85a76f6ff               call 0x44e940
004e72e6 83c408                   add esp, 8
004e72e9 663b442414               cmp ax, word ptr [esp + 0x14]
004e72ee 0f8ce4030000             jl 0x4e76d8
004e72f4 814e0c00100000           or dword ptr [esi + 0xc], 0x1000
004e72fb 816610fffbffff           and dword ptr [esi + 0x10], 0xfffffbff
004e7302 e9d1030000               jmp 0x4e76d8
004e7307 8b442412                 mov eax, dword ptr [esp + 0x12]
004e730b 8b4c2410                 mov ecx, dword ptr [esp + 0x10]
004e730f 50                       push eax
004e7310 51                       push ecx
004e7311 e82a76f6ff               call 0x44e940
004e7316 83c408                   add esp, 8
004e7319 663b442414               cmp ax, word ptr [esp + 0x14]
004e731e 0f8cb7020000             jl 0x4e75db
004e7324 8b4610                   mov eax, dword ptr [esi + 0x10]
004e7327 f6c404                   test ah, 4
004e732a 7405                     je 0x4e7331
004e732c c644242001               mov byte ptr [esp + 0x20], 1
004e7331 25fffbffff               and eax, 0xfffffbff
004e7336 807c242000               cmp byte ptr [esp + 0x20], 0
004e733b 894610                   mov dword ptr [esi + 0x10], eax
004e733e 0f84c2000000             je 0x4e7406
004e7344 668b564b                 mov dx, word ptr [esi + 0x4b]
004e7348 6683fa9c                 cmp dx, -0x64
004e734c 0f8f8c000000             jg 0x4e73de
004e7352 668b442410               mov ax, word ptr [esp + 0x10]
004e7357 88642418                 mov byte ptr [esp + 0x18], ah
004e735b 33c0                     xor eax, eax
004e735d 668b4c2412               mov cx, word ptr [esp + 0x12]
004e7362 886c2419                 mov byte ptr [esp + 0x19], ch
004e7366 33c9                     xor ecx, ecx
004e7368 668b442418               mov ax, word ptr [esp + 0x18]
004e736d 668b4c2418               mov cx, word ptr [esp + 0x18]
004e7372 25fe000000               and eax, 0xfe
004e7377 03c0                     add eax, eax
004e7379 81e100fe0000             and ecx, 0xfe00
004e737f 0bc1                     or eax, ecx
004e7381 33c9                     xor ecx, ecx
004e7383 8a0485f0038a00           mov al, byte ptr [eax*4 + 0x8a03f0]
004e738a 240f                     and al, 0xf
004e738c 8ac8                     mov cl, al
004e738e 8bc1                     mov eax, ecx
004e7390 c1e103                   shl ecx, 3
004e7393 2bc8                     sub ecx, eax
004e7395 f6044d28a35a0002         test byte ptr [ecx*2 + 0x5aa328], 2
004e739d 753f                     jne 0x4e73de
004e739f 6681fa38ff               cmp dx, 0xff38
004e73a4 7f13                     jg 0x4e73b9
004e73a6 6a01                     push 1
004e73a8 a134a55a00               mov eax, dword ptr [0x5aa534]
004e73ad 50                       push eax
004e73ae 6aff                     push -1
004e73b0 56                       push esi
004e73b1 e8ca2cffff               call 0x4da080
004e73b6 83c410                   add esp, 0x10
004e73b9 66837e6e00               cmp word ptr [esi + 0x6e], 0
004e73be 7e1e                     jle 0x4e73de
004e73c0 8a462b                   mov al, byte ptr [esi + 0x2b]
004e73c3 3c07                     cmp al, 7
004e73c5 7506                     jne 0x4e73cd
004e73c7 6a00                     push 0
004e73c9 6a1b                     push 0x1b
004e73cb eb08                     jmp 0x4e73d5
004e73cd 3c01                     cmp al, 1
004e73cf 740d                     je 0x4e73de
004e73d1 6a00                     push 0
004e73d3 6a09                     push 9
004e73d5 56                       push esi
004e73d6 e8752cfaff               call 0x48a050
004e73db 83c40c                   add esp, 0xc
004e73de 33c0                     xor eax, eax
004e73e0 8a462a                   mov al, byte ptr [esi + 0x2a]
004e73e3 83f801                   cmp eax, 1
004e73e6 7509                     jne 0x4e73f1
004e73e8 56                       push esi
004e73e9 e8b2cafeff               call 0x4d3ea0
004e73ee 83c404                   add esp, 4
004e73f1 8d442410                 lea eax, [esp + 0x10]
004e73f5 8a4e2f                   mov cl, byte ptr [esi + 0x2f]
004e73f8 50                       push eax
004e73f9 51                       push ecx
004e73fa 6a03                     push 3
004e73fc 6a07                     push 7
004e73fe e89d640000               call 0x4ed8a0
004e7403 83c410                   add esp, 0x10
004e7406 8d442418                 lea eax, [esp + 0x18]
004e740a 8d4c2410                 lea ecx, [esp + 0x10]
004e740e 50                       push eax
004e740f 8d5e4b                   lea ebx, [esi + 0x4b]
004e7412 51                       push ecx
004e7413 e808480000               call 0x4ebc20
004e7418 668b542420               mov dx, word ptr [esp + 0x20]
004e741d 83c408                   add esp, 8
004e7420 66015649                 add word ptr [esi + 0x49], dx
004e7424 8d7e4d                   lea edi, [esi + 0x4d]
004e7427 895c2424                 mov dword ptr [esp + 0x24], ebx
004e742b 668b44241a               mov ax, word ptr [esp + 0x1a]
004e7430 660103                   add word ptr [ebx], ax
004e7433 668b07                   mov ax, word ptr [edi]
004e7436 33d2                     xor edx, edx
004e7438 660344241c               add ax, word ptr [esp + 0x1c]
004e743d 6689442428               mov word ptr [esp + 0x28], ax
004e7442 668907                   mov word ptr [edi], ax
004e7445 33c0                     xor eax, eax
004e7447 8a442413                 mov al, byte ptr [esp + 0x13]
004e744b 8a542411                 mov dl, byte ptr [esp + 0x11]
004e744f c1e008                   shl eax, 8
004e7452 8b1d74aa9600             mov ebx, dword ptr [0x96aa74]
004e7458 03c2                     add eax, edx
004e745a 895c2418                 mov dword ptr [esp + 0x18], ebx
004e745e 99                       cdq 
004e745f 83e207                   and edx, 7
004e7462 89442420                 mov dword ptr [esp + 0x20], eax
004e7466 03c2                     add eax, edx
004e7468 8b5c2420                 mov ebx, dword ptr [esp + 0x20]
004e746c c1f803                   sar eax, 3
004e746f b201                     mov dl, 1
004e7471 80e307                   and bl, 7
004e7474 8acb                     mov cl, bl
004e7476 d2e2                     shl dl, cl
004e7478 8b4c2418                 mov ecx, dword ptr [esp + 0x18]
004e747c 841401                   test byte ptr [ecx + eax], dl
004e747f 0f84b2000000             je 0x4e7537
004e7485 8a442411                 mov al, byte ptr [esp + 0x11]
004e7489 88442418                 mov byte ptr [esp + 0x18], al
004e748d 33c0                     xor eax, eax
004e748f 8a4c2413                 mov cl, byte ptr [esp + 0x13]
004e7493 884c2419                 mov byte ptr [esp + 0x19], cl
004e7497 668b442418               mov ax, word ptr [esp + 0x18]
004e749c 25fe000000               and eax, 0xfe
004e74a1 8d0c4500000000           lea ecx, [eax*2]
004e74a8 33c0                     xor eax, eax
004e74aa 668b442418               mov ax, word ptr [esp + 0x18]
004e74af 2500fe0000               and eax, 0xfe00
004e74b4 0bc8                     or ecx, eax
004e74b6 8a048df0038a00           mov al, byte ptr [ecx*4 + 0x8a03f0]
004e74bd 33c9                     xor ecx, ecx
004e74bf 240f                     and al, 0xf
004e74c1 8ac8                     mov cl, al
004e74c3 8bc1                     mov eax, ecx
004e74c5 c1e103                   shl ecx, 3
004e74c8 2bc8                     sub ecx, eax
004e74ca 8a044d28a35a00           mov al, byte ptr [ecx*2 + 0x5aa328]
004e74d1 a83e                     test al, 0x3e
004e74d3 7506                     jne 0x4e74db
004e74d5 0fbf5514                 movsx edx, word ptr [ebp + 0x14]
004e74d9 eb04                     jmp 0x4e74df
004e74db 0fbf5516                 movsx edx, word ptr [ebp + 0x16]
004e74df 668b4649                 mov ax, word ptr [esi + 0x49]
004e74e3 0fbf4c2428               movsx ecx, word ptr [esp + 0x28]
004e74e8 0fbfd8                   movsx ebx, ax
004e74eb 85db                     test ebx, ebx
004e74ed 7c06                     jl 0x4e74f5
004e74ef 895c2418                 mov dword ptr [esp + 0x18], ebx
004e74f3 eb08                     jmp 0x4e74fd
004e74f5 8beb                     mov ebp, ebx
004e74f7 f7dd                     neg ebp
004e74f9 896c2418                 mov dword ptr [esp + 0x18], ebp
004e74fd 3b542418                 cmp edx, dword ptr [esp + 0x18]
004e7501 7f0e                     jg 0x4e7511
004e7503 85db                     test ebx, ebx
004e7505 7e05                     jle 0x4e750c
004e7507 662bc2                   sub ax, dx
004e750a eb08                     jmp 0x4e7514
004e750c 6603c2                   add ax, dx
004e750f eb03                     jmp 0x4e7514
004e7511 662bc3                   sub ax, bx
004e7514 66894649                 mov word ptr [esi + 0x49], ax
004e7518 85c9                     test ecx, ecx
004e751a 8bc1                     mov eax, ecx
004e751c 7d04                     jge 0x4e7522
004e751e 8bc1                     mov eax, ecx
004e7520 f7d8                     neg eax
004e7522 3bd0                     cmp edx, eax
004e7524 7f0e                     jg 0x4e7534
004e7526 85c9                     test ecx, ecx
004e7528 7e05                     jle 0x4e752f
004e752a 662917                   sub word ptr [edi], dx
004e752d eb08                     jmp 0x4e7537
004e752f 660117                   add word ptr [edi], dx
004e7532 eb03                     jmp 0x4e7537
004e7534 66290f                   sub word ptr [edi], cx
004e7537 8d4649                   lea eax, [esi + 0x49]
004e753a 50                       push eax
004e753b 56                       push esi
004e753c e8af030000               call 0x4e78f0
004e7541 668b4649                 mov ax, word ptr [esi + 0x49]
004e7545 83c408                   add esp, 8
004e7548 6601442410               add word ptr [esp + 0x10], ax
004e754d 8b542424                 mov edx, dword ptr [esp + 0x24]
004e7551 668b0a                   mov cx, word ptr [edx]
004e7554 66014c2414               add word ptr [esp + 0x14], cx
004e7559 668b07                   mov ax, word ptr [edi]
004e755c 6601442412               add word ptr [esp + 0x12], ax
004e7561 668b442410               mov ax, word ptr [esp + 0x10]
004e7566 662b463d                 sub ax, word ptr [esi + 0x3d]
004e756a 0fb7f8                   movzx edi, ax
004e756d 668b442412               mov ax, word ptr [esp + 0x12]
004e7572 8bd7                     mov edx, edi
004e7574 662b463f                 sub ax, word ptr [esi + 0x3f]
004e7578 85ff                     test edi, edi
004e757a 0fb7c8                   movzx ecx, ax
004e757d 7d04                     jge 0x4e7583
004e757f 8bd7                     mov edx, edi
004e7581 f7da                     neg edx
004e7583 8bc1                     mov eax, ecx
004e7585 85c9                     test ecx, ecx
004e7587 7d04                     jge 0x4e758d
004e7589 8bc1                     mov eax, ecx
004e758b f7d8                     neg eax
004e758d 81fa00800000             cmp edx, 0x8000
004e7593 7c06                     jl 0x4e759b
004e7595 8dba0000ffff             lea edi, [edx - 0x10000]
004e759b 3d00800000               cmp eax, 0x8000
004e75a0 7c06                     jl 0x4e75a8
004e75a2 8d880000ffff             lea ecx, [eax - 0x10000]
004e75a8 f7d9                     neg ecx
004e75aa 51                       push ecx
004e75ab 57                       push edi
004e75ac e8c3ea0900               call 0x586074
004e75b1 83c408                   add esp, 8
004e75b4 33c9                     xor ecx, ecx
004e75b6 668bc8                   mov cx, ax
004e75b9 81e1ff070000             and ecx, 0x7ff
004e75bf f6460d80                 test byte ptr [esi + 0xd], 0x80
004e75c3 8bc1                     mov eax, ecx
004e75c5 740b                     je 0x4e75d2
004e75c7 8d8100040000             lea eax, [ecx + 0x400]
004e75cd 25ff070000               and eax, 0x7ff
004e75d2 66894e5d                 mov word ptr [esi + 0x5d], cx
004e75d6 e9db000000               jmp 0x4e76b6
004e75db f6461104                 test byte ptr [esi + 0x11], 4
004e75df 7534                     jne 0x4e7615
004e75e1 807e2b07                 cmp byte ptr [esi + 0x2b], 7
004e75e5 7517                     jne 0x4e75fe
004e75e7 a0f0c68900               mov al, byte ptr [0x89c6f0]
004e75ec 6a00                     push 0
004e75ee 38462f                   cmp byte ptr [esi + 0x2f], al
004e75f1 7504                     jne 0x4e75f7
004e75f3 6a1a                     push 0x1a
004e75f5 eb15                     jmp 0x4e760c
004e75f7 6889000000               push 0x89
004e75fc eb0e                     jmp 0x4e760c
004e75fe 66837e4b5a               cmp word ptr [esi + 0x4b], 0x5a
004e7603 7e10                     jle 0x4e7615
004e7605 6a00                     push 0
004e7607 68c4000000               push 0xc4
004e760c 56                       push esi
004e760d e83e2afaff               call 0x48a050
004e7612 83c40c                   add esp, 0xc
004e7615 814e1000040000           or dword ptr [esi + 0x10], 0x400
004e761c f6460e04                 test byte ptr [esi + 0xe], 4
004e7620 7508                     jne 0x4e762a
004e7622 668b4512                 mov ax, word ptr [ebp + 0x12]
004e7626 6629464b                 sub word ptr [esi + 0x4b], ax
004e762a 668b4e49                 mov cx, word ptr [esi + 0x49]
004e762e 8d7e4d                   lea edi, [esi + 0x4d]
004e7631 0fbfd1                   movsx edx, cx
004e7634 0fbf1f                   movsx ebx, word ptr [edi]
004e7637 8bc2                     mov eax, edx
004e7639 85d2                     test edx, edx
004e763b 7d04                     jge 0x4e7641
004e763d 8bc2                     mov eax, edx
004e763f f7d8                     neg eax
004e7641 83f802                   cmp eax, 2
004e7644 7c10                     jl 0x4e7656
004e7646 85d2                     test edx, edx
004e7648 7e06                     jle 0x4e7650
004e764a 6683e902                 sub cx, 2
004e764e eb09                     jmp 0x4e7659
004e7650 6683c102                 add cx, 2
004e7654 eb03                     jmp 0x4e7659
004e7656 662bca                   sub cx, dx
004e7659 66894e49                 mov word ptr [esi + 0x49], cx
004e765d 8bc3                     mov eax, ebx
004e765f 85db                     test ebx, ebx
004e7661 7d04                     jge 0x4e7667
004e7663 8bc3                     mov eax, ebx
004e7665 f7d8                     neg eax
004e7667 83f802                   cmp eax, 2
004e766a 7c10                     jl 0x4e767c
004e766c 85db                     test ebx, ebx
004e766e 7e06                     jle 0x4e7676
004e7670 66832f02                 sub word ptr [edi], 2
004e7674 eb09                     jmp 0x4e767f
004e7676 66830702                 add word ptr [edi], 2
004e767a eb03                     jmp 0x4e767f
004e767c 66291f                   sub word ptr [edi], bx
004e767f 8d4649                   lea eax, [esi + 0x49]
004e7682 50                       push eax
004e7683 56                       push esi
004e7684 e867020000               call 0x4e78f0
004e7689 668b4649                 mov ax, word ptr [esi + 0x49]
004e768d 83c408                   add esp, 8
004e7690 6601442410               add word ptr [esp + 0x10], ax
004e7695 668b4e4b                 mov cx, word ptr [esi + 0x4b]
004e7699 66014c2414               add word ptr [esp + 0x14], cx
004e769e 668b17                   mov dx, word ptr [edi]
004e76a1 6601542412               add word ptr [esp + 0x12], dx
004e76a6 668b465d                 mov ax, word ptr [esi + 0x5d]
004e76aa 66059300                 add ax, 0x93
004e76ae 6625ff07                 and ax, 0x7ff
004e76b2 6689465d                 mov word ptr [esi + 0x5d], ax
004e76b6 66894626                 mov word ptr [esi + 0x26], ax
004e76ba 6a01                     push 1
004e76bc 8d442414                 lea eax, [esp + 0x14]
004e76c0 50                       push eax
004e76c1 56                       push esi
004e76c2 e819250000               call 0x4e9be0
004e76c7 8d44241c                 lea eax, [esp + 0x1c]
004e76cb 83c40c                   add esp, 0xc
004e76ce 50                       push eax
004e76cf 56                       push esi
004e76d0 e88b1a0000               call 0x4e9160
004e76d5 83c408                   add esp, 8
004e76d8 f6460c02                 test byte ptr [esi + 0xc], 2
004e76dc 7523                     jne 0x4e7701
004e76de 8b442412                 mov eax, dword ptr [esp + 0x12]
004e76e2 8b4c2410                 mov ecx, dword ptr [esp + 0x10]
004e76e6 50                       push eax
004e76e7 51                       push ecx
004e76e8 e85372f6ff               call 0x44e940
004e76ed 0fbf4c241c               movsx ecx, word ptr [esp + 0x1c]
004e76f2 0fbfc0                   movsx eax, ax
004e76f5 83c408                   add esp, 8
004e76f8 3bc8                     cmp ecx, eax
004e76fa 7d05                     jge 0x4e7701
004e76fc 6689442414               mov word ptr [esp + 0x14], ax
004e7701 8d442410                 lea eax, [esp + 0x10]
004e7705 50                       push eax
004e7706 56                       push esi
004e7707 e8746e0000               call 0x4ee580
004e770c 83c408                   add esp, 8
004e770f 66837e1c00               cmp word ptr [esi + 0x1c], 0
004e7714 746a                     je 0x4e7780
004e7716 668b4e3d                 mov cx, word ptr [esi + 0x3d]
004e771a 886c2418                 mov byte ptr [esp + 0x18], ch
004e771e 33c9                     xor ecx, ecx
004e7720 668b563f                 mov dx, word ptr [esi + 0x3f]
004e7724 88742419                 mov byte ptr [esp + 0x19], dh
004e7728 33d2                     xor edx, edx
004e772a 668b4c2418               mov cx, word ptr [esp + 0x18]
004e772f 668b542418               mov dx, word ptr [esp + 0x18]
004e7734 81e1fe000000             and ecx, 0xfe
004e773a 03c9                     add ecx, ecx
004e773c 81e200fe0000             and edx, 0xfe00
004e7742 0bca                     or ecx, edx
004e7744 8d0c8de4038a00           lea ecx, [ecx*4 + 0x8a03e4]
004e774b f6410102                 test byte ptr [ecx + 1], 2
004e774f 7429                     je 0x4e777a
004e7751 33d2                     xor edx, edx
004e7753 668b5108                 mov dx, word ptr [ecx + 8]
004e7757 81e2ff030000             and edx, 0x3ff
004e775d 8b0c9590038900           mov ecx, dword ptr [edx*4 + 0x890390]
004e7764 33d2                     xor edx, edx
004e7766 8a512b                   mov dl, byte ptr [ecx + 0x2b]
004e7769 8d1cd2                   lea ebx, [edx + edx*8]
004e776c 8d145a                   lea edx, [edx + ebx*2]
004e776f 66833c954e725a0000       cmp word ptr [edx*4 + 0x5a724e], 0
004e7778 7506                     jne 0x4e7780
004e777a 66c7461c0000             mov word ptr [esi + 0x1c], 0
004e7780 f605a85d890004           test byte ptr [0x895da8], 4
004e7787 0f84e0000000             je 0x4e786d
004e778d 33c9                     xor ecx, ecx
004e778f 85c0                     test eax, eax
004e7791 0f84d6000000             je 0x4e786d
004e7797 a0f0c68900               mov al, byte ptr [0x89c6f0]
004e779c 38462f                   cmp byte ptr [esi + 0x2f], al
004e779f 0f85c8000000             jne 0x4e786d
004e77a5 8d463d                   lea eax, [esi + 0x3d]
004e77a8 8d7c2418                 lea edi, [esp + 0x18]
004e77ac 884c2424                 mov byte ptr [esp + 0x24], cl
004e77b0 8b10                     mov edx, dword ptr [eax]
004e77b2 8917                     mov dword ptr [edi], edx
004e77b4 668b4004                 mov ax, word ptr [eax + 4]
004e77b8 66894704                 mov word ptr [edi + 4], ax
004e77bc 33c0                     xor eax, eax
004e77be 668b465d                 mov ax, word ptr [esi + 0x5d]
004e77c2 25ff070000               and eax, 0x7ff
004e77c7 c1e002                   shl eax, 2
004e77ca 8b90e8dd5d00             mov edx, dword ptr [eax + 0x5ddde8]
004e77d0 8b80e8e55d00             mov eax, dword ptr [eax + 0x5de5e8]
004e77d6 c1e209                   shl edx, 9
004e77d9 c1fa10                   sar edx, 0x10
004e77dc c1e009                   shl eax, 9
004e77df 89542420                 mov dword ptr [esp + 0x20], edx
004e77e3 c1f810                   sar eax, 0x10
004e77e6 668b54241a               mov dx, word ptr [esp + 0x1a]
004e77eb 89442428                 mov dword ptr [esp + 0x28], eax
004e77ef 668b442418               mov ax, word ptr [esp + 0x18]
004e77f4 33ff                     xor edi, edi
004e77f6 33db                     xor ebx, ebx
004e77f8 88642418                 mov byte ptr [esp + 0x18], ah
004e77fc 88742419                 mov byte ptr [esp + 0x19], dh
004e7800 668b7c2418               mov di, word ptr [esp + 0x18]
004e7805 668b5c2418               mov bx, word ptr [esp + 0x18]
004e780a 81e7fe000000             and edi, 0xfe
004e7810 03ff                     add edi, edi
004e7812 81e300fe0000             and ebx, 0xfe00
004e7818 0bfb                     or edi, ebx
004e781a f604bde4038a0008         test byte ptr [edi*4 + 0x8a03e4], 8
004e7822 7412                     je 0x4e7836
004e7824 6603442420               add ax, word ptr [esp + 0x20]
004e7829 41                       inc ecx
004e782a 6603542428               add dx, word ptr [esp + 0x28]
004e782f 83f905                   cmp ecx, 5
004e7832 7cc0                     jl 0x4e77f4
004e7834 eb05                     jmp 0x4e783b
004e7836 c644242401               mov byte ptr [esp + 0x24], 1
004e783b 807c242400               cmp byte ptr [esp + 0x24], 0
004e7840 742b                     je 0x4e786d
004e7842 668b463d                 mov ax, word ptr [esi + 0x3d]
004e7846 66c1e808                 shr ax, 8
004e784a 24fe                     and al, 0xfe
004e784c 88442418                 mov byte ptr [esp + 0x18], al
004e7850 668b463f                 mov ax, word ptr [esi + 0x3f]
004e7854 66c1e808                 shr ax, 8
004e7858 24fe                     and al, 0xfe
004e785a 88442419                 mov byte ptr [esp + 0x19], al
004e785e 8b4c2418                 mov ecx, dword ptr [esp + 0x18]
004e7862 51                       push ecx
004e7863 6a02                     push 2
004e7865 e8a68df6ff               call 0x450610
004e786a 83c408                   add esp, 8
004e786d 56                       push esi
004e786e e84d350000               call 0x4eadc0
004e7873 83c404                   add esp, 4
004e7876 5d                       pop ebp
004e7877 5f                       pop edi
004e7878 5e                       pop esi
004e7879 5b                       pop ebx
004e787a 83c41c                   add esp, 0x1c
004e787d c3                       ret 
004e787e cc                       int3 
004e787f cc                       int3 
