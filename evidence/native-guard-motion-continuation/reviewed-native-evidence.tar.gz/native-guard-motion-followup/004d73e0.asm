004d73e0 83ec30                   sub esp, 0x30
004d73e3 53                       push ebx
004d73e4 56                       push esi
004d73e5 57                       push edi
004d73e6 33db                     xor ebx, ebx
004d73e8 8b742440                 mov esi, dword ptr [esp + 0x40]
004d73ec 55                       push ebp
004d73ed 885c2413                 mov byte ptr [esp + 0x13], bl
004d73f1 56                       push esi
004d73f2 e889b00100               call 0x4f2480
004d73f7 83c404                   add esp, 4
004d73fa 85c0                     test eax, eax
004d73fc 750d                     jne 0x4d740b
004d73fe f6461108                 test byte ptr [esi + 0x11], 8
004d7402 7507                     jne 0x4d740b
004d7404 66ff8687000000           inc word ptr [esi + 0x87]
004d740b f7460c04200000           test dword ptr [esi + 0xc], 0x2004
004d7412 0f85740a0000             jne 0x4d7e8c
004d7418 33c0                     xor eax, eax
004d741a 8a462d                   mov al, byte ptr [esi + 0x2d]
004d741d 85c0                     test eax, eax
004d741f 0f8587000000             jne 0x4d74ac
004d7425 f686820000000f           test byte ptr [esi + 0x82], 0xf
004d742c 741a                     je 0x4d7448
004d742e 8d8680000000             lea eax, [esi + 0x80]
004d7434 50                       push eax
004d7435 56                       push esi
004d7436 e8e5dfffff               call 0x4d5420
004d743b 83c408                   add esp, 8
004d743e 84c0                     test al, al
004d7440 7406                     je 0x4d7448
004d7442 c6462d01                 mov byte ptr [esi + 0x2d], 1
004d7446 eb64                     jmp 0x4d74ac
004d7448 56                       push esi
004d7449 e8d2dcffff               call 0x4d5120
004d744e 83c404                   add esp, 4
004d7451 84c0                     test al, al
004d7453 7452                     je 0x4d74a7
004d7455 8d8680000000             lea eax, [esi + 0x80]
004d745b 8d4c2434                 lea ecx, [esp + 0x34]
004d745f 51                       push ecx
004d7460 50                       push eax
004d7461 e8eae1ffff               call 0x4d5650
004d7466 0fbf44243c               movsx eax, word ptr [esp + 0x3c]
004d746b 0fbf4e3d                 movsx ecx, word ptr [esi + 0x3d]
004d746f 83c408                   add esp, 8
004d7472 2bc1                     sub eax, ecx
004d7474 99                       cdq 
004d7475 33c2                     xor eax, edx
004d7477 2bc2                     sub eax, edx
004d7479 83f830                   cmp eax, 0x30
004d747c 7d17                     jge 0x4d7495
004d747e 0fbf442436               movsx eax, word ptr [esp + 0x36]
004d7483 0fbf4e3f                 movsx ecx, word ptr [esi + 0x3f]
004d7487 2bc1                     sub eax, ecx
004d7489 99                       cdq 
004d748a 33c2                     xor eax, edx
004d748c 2bc2                     sub eax, edx
004d748e 83f830                   cmp eax, 0x30
004d7491 b001                     mov al, 1
004d7493 7c02                     jl 0x4d7497
004d7495 32c0                     xor al, al
004d7497 84c0                     test al, al
004d7499 7506                     jne 0x4d74a1
004d749b c6462d01                 mov byte ptr [esi + 0x2d], 1
004d749f eb0b                     jmp 0x4d74ac
004d74a1 c6462d03                 mov byte ptr [esi + 0x2d], 3
004d74a5 eb05                     jmp 0x4d74ac
004d74a7 c644241301               mov byte ptr [esp + 0x13], 1
004d74ac 33c0                     xor eax, eax
004d74ae 8a462d                   mov al, byte ptr [esi + 0x2d]
004d74b1 83f801                   cmp eax, 1
004d74b4 740e                     je 0x4d74c4
004d74b6 83f802                   cmp eax, 2
004d74b9 0f84fa000000             je 0x4d75b9
004d74bf e99b010000               jmp 0x4d765f
004d74c4 8b460c                   mov eax, dword ptr [esi + 0xc]
004d74c7 56                       push esi
004d74c8 c6462d02                 mov byte ptr [esi + 0x2d], 2
004d74cc 0d00002000               or eax, 0x200000
004d74d1 89460c                   mov dword ptr [esi + 0xc], eax
004d74d4 0d00020000               or eax, 0x200
004d74d9 89460c                   mov dword ptr [esi + 0xc], eax
004d74dc e87ff1ffff               call 0x4d6660
004d74e1 83c404                   add esp, 4
004d74e4 66837e7801               cmp word ptr [esi + 0x78], 1
004d74e9 1bc0                     sbb eax, eax
004d74eb 83e0fc                   and eax, 0xfffffffc
004d74ee 83c005                   add eax, 5
004d74f1 50                       push eax
004d74f2 56                       push esi
004d74f3 e8f8caffff               call 0x4d3ff0
004d74f8 668b8e80000000           mov cx, word ptr [esi + 0x80]
004d74ff 83c408                   add esp, 8
004d7502 66894c241a               mov word ptr [esp + 0x1a], cx
004d7507 b8fe000000               mov eax, 0xfe
004d750c 2044241a                 and byte ptr [esp + 0x1a], al
004d7510 2044241b                 and byte ptr [esp + 0x1b], al
004d7514 660fb644241a             movzx ax, byte ptr [esp + 0x1a]
004d751a 6640                     inc ax
004d751c 8a8e82000000             mov cl, byte ptr [esi + 0x82]
004d7522 66c1e008                 shl ax, 8
004d7526 6689442420               mov word ptr [esp + 0x20], ax
004d752b 660fb644241b             movzx ax, byte ptr [esp + 0x1b]
004d7531 6640                     inc ax
004d7533 66c1e008                 shl ax, 8
004d7537 f6c1f0                   test cl, 0xf0
004d753a 6689442422               mov word ptr [esp + 0x22], ax
004d753f 7412                     je 0x4d7553
004d7541 8ac1                     mov al, cl
004d7543 33d2                     xor edx, edx
004d7545 c0e804                   shr al, 4
004d7548 8ad0                     mov dl, al
004d754a 8b0495d95e8900           mov eax, dword ptr [edx*4 + 0x895ed9]
004d7551 eb05                     jmp 0x4d7558
004d7553 a1f15e8900               mov eax, dword ptr [0x895ef1]
004d7558 80e10f                   and cl, 0xf
004d755b 33d2                     xor edx, edx
004d755d 8ad1                     mov dl, cl
004d755f 8d0490                   lea eax, [eax + edx*4]
004d7562 668b08                   mov cx, word ptr [eax]
004d7565 66014c2420               add word ptr [esp + 0x20], cx
004d756a 668b4002                 mov ax, word ptr [eax + 2]
004d756e 0fbf4e3d                 movsx ecx, word ptr [esi + 0x3d]
004d7572 6601442422               add word ptr [esp + 0x22], ax
004d7577 0fbf442420               movsx eax, word ptr [esp + 0x20]
004d757c 2bc1                     sub eax, ecx
004d757e 99                       cdq 
004d757f 33c2                     xor eax, edx
004d7581 2bc2                     sub eax, edx
004d7583 3dd8000000               cmp eax, 0xd8
004d7588 7d1d                     jge 0x4d75a7
004d758a 0fbf442422               movsx eax, word ptr [esp + 0x22]
004d758f 0fbf4e3f                 movsx ecx, word ptr [esi + 0x3f]
004d7593 2bc1                     sub eax, ecx
004d7595 99                       cdq 
004d7596 33c2                     xor eax, edx
004d7598 2bc2                     sub eax, edx
004d759a 3dd8000000               cmp eax, 0xd8
004d759f 7d06                     jge 0x4d75a7
004d75a1 834e0c20                 or dword ptr [esi + 0xc], 0x20
004d75a5 eb04                     jmp 0x4d75ab
004d75a7 83660cdf                 and dword ptr [esi + 0xc], 0xffffffdf
004d75ab 8d442420                 lea eax, [esp + 0x20]
004d75af 50                       push eax
004d75b0 56                       push esi
004d75b1 e81a280100               call 0x4e9dd0
004d75b6 83c408                   add esp, 8
004d75b9 bb01000000               mov ebx, 1
004d75be 8dbe80000000             lea edi, [esi + 0x80]
004d75c4 57                       push edi
004d75c5 56                       push esi
004d75c6 e855deffff               call 0x4d5420
004d75cb 83c408                   add esp, 8
004d75ce 84c0                     test al, al
004d75d0 7446                     je 0x4d7618
004d75d2 8d442430                 lea eax, [esp + 0x30]
004d75d6 50                       push eax
004d75d7 57                       push edi
004d75d8 e873e0ffff               call 0x4d5650
004d75dd 0fbf442438               movsx eax, word ptr [esp + 0x38]
004d75e2 0fbf4e3d                 movsx ecx, word ptr [esi + 0x3d]
004d75e6 83c408                   add esp, 8
004d75e9 2bc1                     sub eax, ecx
004d75eb 99                       cdq 
004d75ec 33c2                     xor eax, edx
004d75ee 2bc2                     sub eax, edx
004d75f0 83f830                   cmp eax, 0x30
004d75f3 7d17                     jge 0x4d760c
004d75f5 0fbf442432               movsx eax, word ptr [esp + 0x32]
004d75fa 0fbf4e3f                 movsx ecx, word ptr [esi + 0x3f]
004d75fe 2bc1                     sub eax, ecx
004d7600 99                       cdq 
004d7601 33c2                     xor eax, edx
004d7603 2bc2                     sub eax, edx
004d7605 83f830                   cmp eax, 0x30
004d7608 8ac3                     mov al, bl
004d760a 7c02                     jl 0x4d760e
004d760c 32c0                     xor al, al
004d760e 84c0                     test al, al
004d7610 740a                     je 0x4d761c
004d7612 c6462d03                 mov byte ptr [esi + 0x2d], 3
004d7616 eb04                     jmp 0x4d761c
004d7618 c6462d00                 mov byte ptr [esi + 0x2d], 0
004d761c 807e2d02                 cmp byte ptr [esi + 0x2d], 2
004d7620 743d                     je 0x4d765f
004d7622 668b465d                 mov ax, word ptr [esi + 0x5d]
004d7626 8b4e0c                   mov ecx, dword ptr [esi + 0xc]
004d7629 f6c180                   test cl, 0x80
004d762c 7404                     je 0x4d7632
004d762e 66894657                 mov word ptr [esi + 0x57], ax
004d7632 f6c580                   test ch, 0x80
004d7635 6689465d                 mov word ptr [esi + 0x5d], ax
004d7639 7408                     je 0x4d7643
004d763b 66050004                 add ax, 0x400
004d763f 6625ff07                 and ax, 0x7ff
004d7643 66894626                 mov word ptr [esi + 0x26], ax
004d7647 83e1df                   and ecx, 0xffffffdf
004d764a 894e0c                   mov dword ptr [esi + 0xc], ecx
004d764d 81e1ffffdfff             and ecx, 0xffdfffff
004d7653 894e0c                   mov dword ptr [esi + 0xc], ecx
004d7656 81e1fffdffff             and ecx, 0xfffffdff
004d765c 894e0c                   mov dword ptr [esi + 0xc], ecx
004d765f 33c0                     xor eax, eax
004d7661 8a462d                   mov al, byte ptr [esi + 0x2d]
004d7664 83e803                   sub eax, 3
004d7667 83f807                   cmp eax, 7
004d766a 0f873c020000             ja 0x4d78ac
004d7670 ff2485bc7e4d00           jmp dword ptr [eax*4 + 0x4d7ebc]
004d7677 8a9682000000             mov dl, byte ptr [esi + 0x82]
004d767d 8dbe80000000             lea edi, [esi + 0x80]
004d7683 668b0f                   mov cx, word ptr [edi]
004d7686 8d44241c                 lea eax, [esp + 0x1c]
004d768a c6462d04                 mov byte ptr [esi + 0x2d], 4
004d768e 66c746700a00             mov word ptr [esi + 0x70], 0xa
004d7694 668908                   mov word ptr [eax], cx
004d7697 885002                   mov byte ptr [eax + 2], dl
004d769a 668b44241c               mov ax, word ptr [esp + 0x1c]
004d769f 6689442418               mov word ptr [esp + 0x18], ax
004d76a4 b8fe000000               mov eax, 0xfe
004d76a9 20442418                 and byte ptr [esp + 0x18], al
004d76ad 20442419                 and byte ptr [esp + 0x19], al
004d76b1 660fb6442418             movzx ax, byte ptr [esp + 0x18]
004d76b7 6640                     inc ax
004d76b9 66c1e008                 shl ax, 8
004d76bd 6689442420               mov word ptr [esp + 0x20], ax
004d76c2 660fb6442419             movzx ax, byte ptr [esp + 0x19]
004d76c8 6640                     inc ax
004d76ca 66c1e008                 shl ax, 8
004d76ce 6689442422               mov word ptr [esp + 0x22], ax
004d76d3 8a44241e                 mov al, byte ptr [esp + 0x1e]
004d76d7 a8f0                     test al, 0xf0
004d76d9 7412                     je 0x4d76ed
004d76db 8ac8                     mov cl, al
004d76dd 33d2                     xor edx, edx
004d76df c0e904                   shr cl, 4
004d76e2 8ad1                     mov dl, cl
004d76e4 8b1495d95e8900           mov edx, dword ptr [edx*4 + 0x895ed9]
004d76eb eb06                     jmp 0x4d76f3
004d76ed 8b15f15e8900             mov edx, dword ptr [0x895ef1]
004d76f3 240f                     and al, 0xf
004d76f5 33c9                     xor ecx, ecx
004d76f7 8ac8                     mov cl, al
004d76f9 8d048a                   lea eax, [edx + ecx*4]
004d76fc 668b10                   mov dx, word ptr [eax]
004d76ff 6601542420               add word ptr [esp + 0x20], dx
004d7704 668b4002                 mov ax, word ptr [eax + 2]
004d7708 668b4c2420               mov cx, word ptr [esp + 0x20]
004d770d 6601442422               add word ptr [esp + 0x22], ax
004d7712 668b542422               mov dx, word ptr [esp + 0x22]
004d7717 66894c2438               mov word ptr [esp + 0x38], cx
004d771c 8b4c2438                 mov ecx, dword ptr [esp + 0x38]
004d7720 668954243a               mov word ptr [esp + 0x3a], dx
004d7725 8b54243a                 mov edx, dword ptr [esp + 0x3a]
004d7729 52                       push edx
004d772a 51                       push ecx
004d772b e81072f7ff               call 0x44e940
004d7730 6689442444               mov word ptr [esp + 0x44], ax
004d7735 8d4c2440                 lea ecx, [esp + 0x40]
004d7739 83c408                   add esp, 8
004d773c 51                       push ecx
004d773d 56                       push esi
004d773e e83d6e0100               call 0x4ee580
004d7743 66c7465f0000             mov word ptr [esi + 0x5f], 0
004d7749 83c408                   add esp, 8
004d774c b800000000               mov eax, 0
004d7751 816610fffbffff           and dword ptr [esi + 0x10], 0xfffffbff
004d7758 66837e7801               cmp word ptr [esi + 0x78], 1
004d775d 83d0ff                   adc eax, -1
004d7760 83e004                   and eax, 4
004d7763 50                       push eax
004d7764 56                       push esi
004d7765 e886c8ffff               call 0x4d3ff0
004d776a 83c408                   add esp, 8
004d776d 8a8e82000000             mov cl, byte ptr [esi + 0x82]
004d7773 80e1f0                   and cl, 0xf0
004d7776 80f910                   cmp cl, 0x10
004d7779 0f86ba000000             jbe 0x4d7839
004d777f 668b17                   mov dx, word ptr [edi]
004d7782 8d4c241c                 lea ecx, [esp + 0x1c]
004d7786 668911                   mov word ptr [ecx], dx
004d7789 8a4702                   mov al, byte ptr [edi + 2]
004d778c 884102                   mov byte ptr [ecx + 2], al
004d778f 8a4c241e                 mov cl, byte ptr [esp + 0x1e]
004d7793 668b54241c               mov dx, word ptr [esp + 0x1c]
004d7798 80e1f0                   and cl, 0xf0
004d779b 6689542416               mov word ptr [esp + 0x16], dx
004d77a0 bafe000000               mov edx, 0xfe
004d77a5 20542416                 and byte ptr [esp + 0x16], dl
004d77a9 20542417                 and byte ptr [esp + 0x17], dl
004d77ad 660fb6542416             movzx dx, byte ptr [esp + 0x16]
004d77b3 6642                     inc dx
004d77b5 66c1e208                 shl dx, 8
004d77b9 6689542420               mov word ptr [esp + 0x20], dx
004d77be 660fb6542417             movzx dx, byte ptr [esp + 0x17]
004d77c4 6642                     inc dx
004d77c6 66c1e208                 shl dx, 8
004d77ca f6c1f0                   test cl, 0xf0
004d77cd 6689542422               mov word ptr [esp + 0x22], dx
004d77d2 7412                     je 0x4d77e6
004d77d4 8ac1                     mov al, cl
004d77d6 33d2                     xor edx, edx
004d77d8 c0e804                   shr al, 4
004d77db 8ad0                     mov dl, al
004d77dd 8b0495d95e8900           mov eax, dword ptr [edx*4 + 0x895ed9]
004d77e4 eb05                     jmp 0x4d77eb
004d77e6 a1f15e8900               mov eax, dword ptr [0x895ef1]
004d77eb 80e10f                   and cl, 0xf
004d77ee 33d2                     xor edx, edx
004d77f0 8ad1                     mov dl, cl
004d77f2 8d0490                   lea eax, [eax + edx*4]
004d77f5 8d542420                 lea edx, [esp + 0x20]
004d77f9 668b08                   mov cx, word ptr [eax]
004d77fc 52                       push edx
004d77fd 66014c2424               add word ptr [esp + 0x24], cx
004d7802 56                       push esi
004d7803 668b4002                 mov ax, word ptr [eax + 2]
004d7807 660144242a               add word ptr [esp + 0x2a], ax
004d780c e8bf250100               call 0x4e9dd0
004d7811 668b465d                 mov ax, word ptr [esi + 0x5d]
004d7815 83c408                   add esp, 8
004d7818 8b4e0c                   mov ecx, dword ptr [esi + 0xc]
004d781b f6c180                   test cl, 0x80
004d781e 7404                     je 0x4d7824
004d7820 66894657                 mov word ptr [esi + 0x57], ax
004d7824 f6c580                   test ch, 0x80
004d7827 6689465d                 mov word ptr [esi + 0x5d], ax
004d782b 7408                     je 0x4d7835
004d782d 66050004                 add ax, 0x400
004d7831 6625ff07                 and ax, 0x7ff
004d7835 66894626                 mov word ptr [esi + 0x26], ax
004d7839 668b4670                 mov ax, word ptr [esi + 0x70]
004d783d b301                     mov bl, 1
004d783f 6648                     dec ax
004d7841 66894670                 mov word ptr [esi + 0x70], ax
004d7845 7565                     jne 0x4d78ac
004d7847 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d784e 0fbf7e78                 movsx edi, word ptr [esi + 0x78]
004d7852 c6462d05                 mov byte ptr [esi + 0x2d], 5
004d7856 85ff                     test edi, edi
004d7858 7439                     je 0x4d7893
004d785a 7e2d                     jle 0x4d7889
004d785c 8d6e3d                   lea ebp, [esi + 0x3d]
004d785f 55                       push ebp
004d7860 68ff000000               push 0xff
004d7865 6a0b                     push 0xb
004d7867 6a05                     push 5
004d7869 e832600100               call 0x4ed8a0
004d786e 83c410                   add esp, 0x10
004d7871 85c0                     test eax, eax
004d7873 7414                     je 0x4d7889
004d7875 83ef64                   sub edi, 0x64
004d7878 6a00                     push 0
004d787a 6a0b                     push 0xb
004d787c 56                       push esi
004d787d e8ce27fbff               call 0x48a050
004d7882 83c40c                   add esp, 0xc
004d7885 85ff                     test edi, edi
004d7887 7fd6                     jg 0x4d785f
004d7889 85ff                     test edi, edi
004d788b 7d02                     jge 0x4d788f
004d788d 33ff                     xor edi, edi
004d788f 66897e78                 mov word ptr [esi + 0x78], di
004d7893 56                       push esi
004d7894 e807c6ffff               call 0x4d3ea0
004d7899 668b8680000000           mov ax, word ptr [esi + 0x80]
004d78a0 83c404                   add esp, 4
004d78a3 50                       push eax
004d78a4 e847deffff               call 0x4d56f0
004d78a9 83c404                   add esp, 4
004d78ac 84db                     test bl, bl
004d78ae 0f84fa050000             je 0x4d7eae
004d78b4 f6462e03                 test byte ptr [esi + 0x2e], 3
004d78b8 0f85f0050000             jne 0x4d7eae
004d78be 668b4676                 mov ax, word ptr [esi + 0x76]
004d78c2 a802                     test al, 2
004d78c4 0f84e4050000             je 0x4d7eae
004d78ca c6462d01                 mov byte ptr [esi + 0x2d], 1
004d78ce 6625fdff                 and ax, 0xfffd
004d78d2 66894676                 mov word ptr [esi + 0x76], ax
004d78d6 e9d3050000               jmp 0x4d7eae
004d78db b301                     mov bl, 1
004d78dd 8b460c                   mov eax, dword ptr [esi + 0xc]
004d78e0 a900000040               test eax, 0x40000000
004d78e5 7455                     je 0x4d793c
004d78e7 25ffffffbf               and eax, 0xbfffffff
004d78ec ba00000000               mov edx, 0
004d78f1 66837e7801               cmp word ptr [esi + 0x78], 1
004d78f6 83d2ff                   adc edx, -1
004d78f9 89460c                   mov dword ptr [esi + 0xc], eax
004d78fc 6683e204                 and dx, 4
004d7900 a900000800               test eax, 0x80000
004d7905 7416                     je 0x4d791d
004d7907 f6461104                 test byte ptr [esi + 0x11], 4
004d790b 66ba0c00                 mov dx, 0xc
004d790f 750c                     jne 0x4d791d
004d7911 66ba0200                 mov dx, 2
004d7915 25ff7fffff               and eax, 0xffff7fff
004d791a 89460c                   mov dword ptr [esi + 0xc], eax
004d791d 0fbfc2                   movsx eax, dx
004d7920 33c9                     xor ecx, ecx
004d7922 8d14c0                   lea edx, [eax + eax*8]
004d7925 8a4e2b                   mov cl, byte ptr [esi + 0x2b]
004d7928 03ca                     add ecx, edx
004d792a 668b044d506d5a00         mov ax, word ptr [ecx*2 + 0x5a6d50]
004d7932 50                       push eax
004d7933 56                       push esi
004d7934 e807c7ffff               call 0x4d4040
004d7939 83c408                   add esp, 8
004d793c f6462e1f                 test byte ptr [esi + 0x2e], 0x1f
004d7940 0f8566ffffff             jne 0x4d78ac
004d7946 a178d18900               mov eax, dword ptr [0x89d178]
004d794b 8bc8                     mov ecx, eax
004d794d 8d14c0                   lea edx, [eax + eax*8]
004d7950 8d04d1                   lea eax, [ecx + edx*8]
004d7953 8d0481                   lea eax, [ecx + eax*4]
004d7956 c1e002                   shl eax, 2
004d7959 8d04c1                   lea eax, [ecx + eax*8]
004d795c 05df240000               add eax, 0x24df
004d7961 a378d18900               mov dword ptr [0x89d178], eax
004d7966 8944242c                 mov dword ptr [esp + 0x2c], eax
004d796a c14c242c0d               ror dword ptr [esp + 0x2c], 0xd
004d796f 8b44242c                 mov eax, dword ptr [esp + 0x2c]
004d7973 a378d18900               mov dword ptr [0x89d178], eax
004d7978 241f                     and al, 0x1f
004d797a 3c12                     cmp al, 0x12
004d797c 760b                     jbe 0x4d7989
004d797e c6462d06                 mov byte ptr [esi + 0x2d], 6
004d7982 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d7989 a178d18900               mov eax, dword ptr [0x89d178]
004d798e 8bc8                     mov ecx, eax
004d7990 8d14c0                   lea edx, [eax + eax*8]
004d7993 8d04d1                   lea eax, [ecx + edx*8]
004d7996 8d0481                   lea eax, [ecx + eax*4]
004d7999 c1e002                   shl eax, 2
004d799c 8d04c1                   lea eax, [ecx + eax*8]
004d799f 05df240000               add eax, 0x24df
004d79a4 a378d18900               mov dword ptr [0x89d178], eax
004d79a9 89442428                 mov dword ptr [esp + 0x28], eax
004d79ad c14c24280d               ror dword ptr [esp + 0x28], 0xd
004d79b2 8b442428                 mov eax, dword ptr [esp + 0x28]
004d79b6 a378d18900               mov dword ptr [0x89d178], eax
004d79bb 243f                     and al, 0x3f
004d79bd 3c3c                     cmp al, 0x3c
004d79bf 0f86e7feffff             jbe 0x4d78ac
004d79c5 c6462d0a                 mov byte ptr [esi + 0x2d], 0xa
004d79c9 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d79d0 e9d7feffff               jmp 0x4d78ac
004d79d5 c6462d07                 mov byte ptr [esi + 0x2d], 7
004d79d9 a178d18900               mov eax, dword ptr [0x89d178]
004d79de 8bc8                     mov ecx, eax
004d79e0 8d14c0                   lea edx, [eax + eax*8]
004d79e3 8d04d1                   lea eax, [ecx + edx*8]
004d79e6 8d0481                   lea eax, [ecx + eax*4]
004d79e9 c1e002                   shl eax, 2
004d79ec 8d04c1                   lea eax, [ecx + eax*8]
004d79ef 05df240000               add eax, 0x24df
004d79f4 a378d18900               mov dword ptr [0x89d178], eax
004d79f9 89442424                 mov dword ptr [esp + 0x24], eax
004d79fd c14c24240d               ror dword ptr [esp + 0x24], 0xd
004d7a02 8b442424                 mov eax, dword ptr [esp + 0x24]
004d7a06 b91c000000               mov ecx, 0x1c
004d7a0b 2bd2                     sub edx, edx
004d7a0d a378d18900               mov dword ptr [0x89d178], eax
004d7a12 f7f1                     div ecx
004d7a14 6683c204                 add dx, 4
004d7a18 66895670                 mov word ptr [esi + 0x70], dx
004d7a1c 0fbf7e5d                 movsx edi, word ptr [esi + 0x5d]
004d7a20 6683e201                 and dx, 1
004d7a24 56                       push esi
004d7a25 6683fa01                 cmp dx, 1
004d7a29 1bc0                     sbb eax, eax
004d7a2b 2500faffff               and eax, 0xfffffa00
004d7a30 0500030000               add eax, 0x300
004d7a35 03f8                     add edi, eax
004d7a37 e8242a0100               call 0x4ea460
004d7a3c 81e7ff070000             and edi, 0x7ff
004d7a42 83c404                   add esp, 4
004d7a45 66897e57                 mov word ptr [esi + 0x57], di
004d7a49 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7a4c 0d80000000               or eax, 0x80
004d7a51 89460c                   mov dword ptr [esi + 0xc], eax
004d7a54 0d00100000               or eax, 0x1000
004d7a59 89460c                   mov dword ptr [esi + 0xc], eax
004d7a5c 0d00002000               or eax, 0x200000
004d7a61 89460c                   mov dword ptr [esi + 0xc], eax
004d7a64 668b4670                 mov ax, word ptr [esi + 0x70]
004d7a68 b301                     mov bl, 1
004d7a6a 6648                     dec ax
004d7a6c 66894670                 mov word ptr [esi + 0x70], ax
004d7a70 0f8536feffff             jne 0x4d78ac
004d7a76 8d8680000000             lea eax, [esi + 0x80]
004d7a7c 8d4c241c                 lea ecx, [esp + 0x1c]
004d7a80 668b10                   mov dx, word ptr [eax]
004d7a83 8a4002                   mov al, byte ptr [eax + 2]
004d7a86 c6462d05                 mov byte ptr [esi + 0x2d], 5
004d7a8a 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d7a91 668911                   mov word ptr [ecx], dx
004d7a94 884102                   mov byte ptr [ecx + 2], al
004d7a97 8a44241e                 mov al, byte ptr [esp + 0x1e]
004d7a9b 668b4c241c               mov cx, word ptr [esp + 0x1c]
004d7aa0 24f0                     and al, 0xf0
004d7aa2 66894c2414               mov word ptr [esp + 0x14], cx
004d7aa7 b9fe000000               mov ecx, 0xfe
004d7aac 204c2414                 and byte ptr [esp + 0x14], cl
004d7ab0 204c2415                 and byte ptr [esp + 0x15], cl
004d7ab4 660fb64c2414             movzx cx, byte ptr [esp + 0x14]
004d7aba 6641                     inc cx
004d7abc 66c1e108                 shl cx, 8
004d7ac0 66894c2420               mov word ptr [esp + 0x20], cx
004d7ac5 660fb64c2415             movzx cx, byte ptr [esp + 0x15]
004d7acb 6641                     inc cx
004d7acd 66c1e108                 shl cx, 8
004d7ad1 a8f0                     test al, 0xf0
004d7ad3 66894c2422               mov word ptr [esp + 0x22], cx
004d7ad8 0f8474030000             je 0x4d7e52
004d7ade 8ac8                     mov cl, al
004d7ae0 33d2                     xor edx, edx
004d7ae2 c0e904                   shr cl, 4
004d7ae5 8ad1                     mov dl, cl
004d7ae7 8b1495d95e8900           mov edx, dword ptr [edx*4 + 0x895ed9]
004d7aee e965030000               jmp 0x4d7e58
004d7af3 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7af6 a900000040               test eax, 0x40000000
004d7afb 0f84abfdffff             je 0x4d78ac
004d7b01 25ffffffbf               and eax, 0xbfffffff
004d7b06 ba00000000               mov edx, 0
004d7b0b 66c7465f0000             mov word ptr [esi + 0x5f], 0
004d7b11 66837e7801               cmp word ptr [esi + 0x78], 1
004d7b16 83d2ff                   adc edx, -1
004d7b19 89460c                   mov dword ptr [esi + 0xc], eax
004d7b1c 6683e204                 and dx, 4
004d7b20 a900000800               test eax, 0x80000
004d7b25 7416                     je 0x4d7b3d
004d7b27 f6461104                 test byte ptr [esi + 0x11], 4
004d7b2b 66ba0c00                 mov dx, 0xc
004d7b2f 750c                     jne 0x4d7b3d
004d7b31 66ba0200                 mov dx, 2
004d7b35 25ff7fffff               and eax, 0xffff7fff
004d7b3a 89460c                   mov dword ptr [esi + 0xc], eax
004d7b3d 0fbfc2                   movsx eax, dx
004d7b40 33c9                     xor ecx, ecx
004d7b42 8d14c0                   lea edx, [eax + eax*8]
004d7b45 8a4e2b                   mov cl, byte ptr [esi + 0x2b]
004d7b48 03ca                     add ecx, edx
004d7b4a 668b044d506d5a00         mov ax, word ptr [ecx*2 + 0x5a6d50]
004d7b52 50                       push eax
004d7b53 56                       push esi
004d7b54 e8e7c4ffff               call 0x4d4040
004d7b59 0fbf7e78                 movsx edi, word ptr [esi + 0x78]
004d7b5d 83c408                   add esp, 8
004d7b60 85ff                     test edi, edi
004d7b62 0f8444fdffff             je 0x4d78ac
004d7b68 7e2d                     jle 0x4d7b97
004d7b6a 8d6e3d                   lea ebp, [esi + 0x3d]
004d7b6d 55                       push ebp
004d7b6e 68ff000000               push 0xff
004d7b73 6a0b                     push 0xb
004d7b75 6a05                     push 5
004d7b77 e8245d0100               call 0x4ed8a0
004d7b7c 83c410                   add esp, 0x10
004d7b7f 85c0                     test eax, eax
004d7b81 7414                     je 0x4d7b97
004d7b83 83ef64                   sub edi, 0x64
004d7b86 6a00                     push 0
004d7b88 6a0b                     push 0xb
004d7b8a 56                       push esi
004d7b8b e8c024fbff               call 0x48a050
004d7b90 83c40c                   add esp, 0xc
004d7b93 85ff                     test edi, edi
004d7b95 7fd6                     jg 0x4d7b6d
004d7b97 85ff                     test edi, edi
004d7b99 7d02                     jge 0x4d7b9d
004d7b9b 33ff                     xor edi, edi
004d7b9d 66897e78                 mov word ptr [esi + 0x78], di
004d7ba1 e906fdffff               jmp 0x4d78ac
004d7ba6 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7ba9 a900000040               test eax, 0x40000000
004d7bae 7430                     je 0x4d7be0
004d7bb0 66c746702000             mov word ptr [esi + 0x70], 0x20
004d7bb6 c686a800000001           mov byte ptr [esi + 0xa8], 1
004d7bbd 25ffffffbf               and eax, 0xbfffffff
004d7bc2 89460c                   mov dword ptr [esi + 0xc], eax
004d7bc5 33c0                     xor eax, eax
004d7bc7 8a462b                   mov al, byte ptr [esi + 0x2b]
004d7bca 804e7610                 or byte ptr [esi + 0x76], 0x10
004d7bce 668b0445866d5a00         mov ax, word ptr [eax*2 + 0x5a6d86]
004d7bd6 50                       push eax
004d7bd7 56                       push esi
004d7bd8 e863c4ffff               call 0x4d4040
004d7bdd 83c408                   add esp, 8
004d7be0 56                       push esi
004d7be1 e82aefffff               call 0x4d6b10
004d7be6 83c404                   add esp, 4
004d7be9 f6462e03                 test byte ptr [esi + 0x2e], 3
004d7bed 0f8597000000             jne 0x4d7c8a
004d7bf3 0fbe462f                 movsx eax, byte ptr [esi + 0x2f]
004d7bf7 8bc8                     mov ecx, eax
004d7bf9 8d1480                   lea edx, [eax + eax*4]
004d7bfc 8d0451                   lea eax, [ecx + edx*2]
004d7bff 8d2cc0                   lea ebp, [eax + eax*8]
004d7c02 8d14e9                   lea edx, [ecx + ebp*8]
004d7c05 8b849165da8900           mov eax, dword ptr [ecx + edx*4 + 0x89da65]
004d7c0c 85c0                     test eax, eax
004d7c0e 747a                     je 0x4d7c8a
004d7c10 668b483d                 mov cx, word ptr [eax + 0x3d]
004d7c14 662b4e3d                 sub cx, word ptr [esi + 0x3d]
004d7c18 0fb7d1                   movzx edx, cx
004d7c1b 668b403f                 mov ax, word ptr [eax + 0x3f]
004d7c1f 8bca                     mov ecx, edx
004d7c21 662b463f                 sub ax, word ptr [esi + 0x3f]
004d7c25 85d2                     test edx, edx
004d7c27 0fb7c0                   movzx eax, ax
004d7c2a 7d04                     jge 0x4d7c30
004d7c2c 8bca                     mov ecx, edx
004d7c2e f7d9                     neg ecx
004d7c30 8bf8                     mov edi, eax
004d7c32 85c0                     test eax, eax
004d7c34 7d04                     jge 0x4d7c3a
004d7c36 8bf8                     mov edi, eax
004d7c38 f7df                     neg edi
004d7c3a 81f900800000             cmp ecx, 0x8000
004d7c40 7c06                     jl 0x4d7c48
004d7c42 8d910000ffff             lea edx, [ecx - 0x10000]
004d7c48 81ff00800000             cmp edi, 0x8000
004d7c4e 7c06                     jl 0x4d7c56
004d7c50 8d870000ffff             lea eax, [edi - 0x10000]
004d7c56 f7d8                     neg eax
004d7c58 50                       push eax
004d7c59 52                       push edx
004d7c5a e815e40a00               call 0x586074
004d7c5f 668bf8                   mov di, ax
004d7c62 83c408                   add esp, 8
004d7c65 6681e7ff07               and di, 0x7ff
004d7c6a 56                       push esi
004d7c6b e8f0270100               call 0x4ea460
004d7c70 66897e57                 mov word ptr [esi + 0x57], di
004d7c74 83c404                   add esp, 4
004d7c77 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7c7a 0d80000000               or eax, 0x80
004d7c7f 89460c                   mov dword ptr [esi + 0xc], eax
004d7c82 0d00100000               or eax, 0x1000
004d7c87 89460c                   mov dword ptr [esi + 0xc], eax
004d7c8a 66ff4e70                 dec word ptr [esi + 0x70]
004d7c8e 0f8518fcffff             jne 0x4d78ac
004d7c94 0fbe462f                 movsx eax, byte ptr [esi + 0x2f]
004d7c98 8d2c80                   lea ebp, [eax + eax*4]
004d7c9b b101                     mov cl, 1
004d7c9d 8bd0                     mov edx, eax
004d7c9f 8d046a                   lea eax, [edx + ebp*2]
004d7ca2 8d3cc0                   lea edi, [eax + eax*8]
004d7ca5 8d2cfa                   lea ebp, [edx + edi*8]
004d7ca8 8bbcaa65da8900           mov edi, dword ptr [edx + ebp*4 + 0x89da65]
004d7caf 85ff                     test edi, edi
004d7cb1 742e                     je 0x4d7ce1
004d7cb3 0fbf473d                 movsx eax, word ptr [edi + 0x3d]
004d7cb7 0fbf563d                 movsx edx, word ptr [esi + 0x3d]
004d7cbb 2bc2                     sub eax, edx
004d7cbd 99                       cdq 
004d7cbe 33c2                     xor eax, edx
004d7cc0 2bc2                     sub eax, edx
004d7cc2 3d38090000               cmp eax, 0x938
004d7cc7 7d18                     jge 0x4d7ce1
004d7cc9 0fbf473f                 movsx eax, word ptr [edi + 0x3f]
004d7ccd 0fbf563f                 movsx edx, word ptr [esi + 0x3f]
004d7cd1 2bc2                     sub eax, edx
004d7cd3 99                       cdq 
004d7cd4 33c2                     xor eax, edx
004d7cd6 2bc2                     sub eax, edx
004d7cd8 3d38090000               cmp eax, 0x938
004d7cdd 7d02                     jge 0x4d7ce1
004d7cdf 32c9                     xor cl, cl
004d7ce1 84c9                     test cl, cl
004d7ce3 7416                     je 0x4d7cfb
004d7ce5 c6462d05                 mov byte ptr [esi + 0x2d], 5
004d7ce9 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d7cf0 56                       push esi
004d7cf1 e8aac1ffff               call 0x4d3ea0
004d7cf6 e9aefbffff               jmp 0x4d78a9
004d7cfb 66c746702000             mov word ptr [esi + 0x70], 0x20
004d7d01 e9a6fbffff               jmp 0x4d78ac
004d7d06 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7d09 a900000040               test eax, 0x40000000
004d7d0e 0f8498000000             je 0x4d7dac
004d7d14 25ffffffbf               and eax, 0xbfffffff
004d7d19 89460c                   mov dword ptr [esi + 0xc], eax
004d7d1c 33c0                     xor eax, eax
004d7d1e 8a462b                   mov al, byte ptr [esi + 0x2b]
004d7d21 83f802                   cmp eax, 2
004d7d24 7412                     je 0x4d7d38
004d7d26 83f803                   cmp eax, 3
004d7d29 7414                     je 0x4d7d3f
004d7d2b 83f806                   cmp eax, 6
004d7d2e 7422                     je 0x4d7d52
004d7d30 66c746700000             mov word ptr [esi + 0x70], 0
004d7d36 eb3a                     jmp 0x4d7d72
004d7d38 68a1000000               push 0xa1
004d7d3d eb24                     jmp 0x4d7d63
004d7d3f 8a8682000000             mov al, byte ptr [esi + 0x82]
004d7d45 24f0                     and al, 0xf0
004d7d47 3c10                     cmp al, 0x10
004d7d49 7727                     ja 0x4d7d72
004d7d4b 68a2000000               push 0xa2
004d7d50 eb11                     jmp 0x4d7d63
004d7d52 8a8682000000             mov al, byte ptr [esi + 0x82]
004d7d58 24f0                     and al, 0xf0
004d7d5a 3c10                     cmp al, 0x10
004d7d5c 7714                     ja 0x4d7d72
004d7d5e 68a3000000               push 0xa3
004d7d63 56                       push esi
004d7d64 e8d7c2ffff               call 0x4d4040
004d7d69 66c746700100             mov word ptr [esi + 0x70], 1
004d7d6f 83c408                   add esp, 8
004d7d72 66837e7000               cmp word ptr [esi + 0x70], 0
004d7d77 7433                     je 0x4d7dac
004d7d79 33c9                     xor ecx, ecx
004d7d7b 8a4e3a                   mov cl, byte ptr [esi + 0x3a]
004d7d7e 0fbf05dc6a5a00           movsx eax, word ptr [0x5a6adc]
004d7d85 8d2c89                   lea ebp, [ecx + ecx*4]
004d7d88 660fbe9469fb6a5a00       movsx dx, byte ptr [ecx + ebp*2 + 0x5a6afb]
004d7d91 6642                     inc dx
004d7d93 8d2c40                   lea ebp, [eax + eax*2]
004d7d96 8b0d44df5900             mov ecx, dword ptr [0x59df44]
004d7d9c 660fb6446901             movzx ax, byte ptr [ecx + ebp*2 + 1]
004d7da2 660fafd0                 imul dx, ax
004d7da6 6642                     inc dx
004d7da8 66895670                 mov word ptr [esi + 0x70], dx
004d7dac 668b4670                 mov ax, word ptr [esi + 0x70]
004d7db0 6648                     dec ax
004d7db2 66894670                 mov word ptr [esi + 0x70], ax
004d7db6 6685c0                   test ax, ax
004d7db9 7f16                     jg 0x4d7dd1
004d7dbb 814e0c00000040           or dword ptr [esi + 0xc], 0x40000000
004d7dc2 66c746700000             mov word ptr [esi + 0x70], 0
004d7dc8 c6462d05                 mov byte ptr [esi + 0x2d], 5
004d7dcc e9dbfaffff               jmp 0x4d78ac
004d7dd1 66837e3700               cmp word ptr [esi + 0x37], 0
004d7dd6 0f85d0faffff             jne 0x4d78ac
004d7ddc 0fbf4633                 movsx eax, word ptr [esi + 0x33]
004d7de0 8b1544df5900             mov edx, dword ptr [0x59df44]
004d7de6 33c9                     xor ecx, ecx
004d7de8 8d2c40                   lea ebp, [eax + eax*2]
004d7deb 33c0                     xor eax, eax
004d7ded 8a4639                   mov al, byte ptr [esi + 0x39]
004d7df0 8a4c6a01                 mov cl, byte ptr [edx + ebp*2 + 1]
004d7df4 49                       dec ecx
004d7df5 3bc8                     cmp ecx, eax
004d7df7 0f8faffaffff             jg 0x4d78ac
004d7dfd ba00000000               mov edx, 0
004d7e02 8b460c                   mov eax, dword ptr [esi + 0xc]
004d7e05 66837e7801               cmp word ptr [esi + 0x78], 1
004d7e0a 83d2ff                   adc edx, -1
004d7e0d 6683e204                 and dx, 4
004d7e11 a900000800               test eax, 0x80000
004d7e16 7416                     je 0x4d7e2e
004d7e18 f6461104                 test byte ptr [esi + 0x11], 4
004d7e1c 66ba0c00                 mov dx, 0xc
004d7e20 750c                     jne 0x4d7e2e
004d7e22 66ba0200                 mov dx, 2
004d7e26 25ff7fffff               and eax, 0xffff7fff
004d7e2b 89460c                   mov dword ptr [esi + 0xc], eax
004d7e2e 0fbfc2                   movsx eax, dx
004d7e31 33c9                     xor ecx, ecx
004d7e33 8d14c0                   lea edx, [eax + eax*8]
004d7e36 8a4e2b                   mov cl, byte ptr [esi + 0x2b]
004d7e39 03ca                     add ecx, edx
004d7e3b 668b044d506d5a00         mov ax, word ptr [ecx*2 + 0x5a6d50]
004d7e43 50                       push eax
004d7e44 56                       push esi
004d7e45 e8f6c1ffff               call 0x4d4040
004d7e4a 83c408                   add esp, 8
004d7e4d e95afaffff               jmp 0x4d78ac
004d7e52 8b15f15e8900             mov edx, dword ptr [0x895ef1]
004d7e58 240f                     and al, 0xf
004d7e5a 33c9                     xor ecx, ecx
004d7e5c 8ac8                     mov cl, al
004d7e5e 8d048a                   lea eax, [edx + ecx*4]
004d7e61 8d4c2420                 lea ecx, [esp + 0x20]
004d7e65 668b10                   mov dx, word ptr [eax]
004d7e68 51                       push ecx
004d7e69 6601542424               add word ptr [esp + 0x24], dx
004d7e6e 56                       push esi
004d7e6f 668b4002                 mov ax, word ptr [eax + 2]
004d7e73 660144242a               add word ptr [esp + 0x2a], ax
004d7e78 e8531f0100               call 0x4e9dd0
004d7e7d 81660cffffdfff           and dword ptr [esi + 0xc], 0xffdfffff
004d7e84 83c408                   add esp, 8
004d7e87 e920faffff               jmp 0x4d78ac
004d7e8c 6800020000               push 0x200
004d7e91 8d464f                   lea eax, [esi + 0x4f]
004d7e94 50                       push eax
004d7e95 8d4e3d                   lea ecx, [esi + 0x3d]
004d7e98 6a38                     push 0x38
004d7e9a 51                       push ecx
004d7e9b e800aff5ff               call 0x432da0
004d7ea0 83c410                   add esp, 0x10
004d7ea3 84c0                     test al, al
004d7ea5 7507                     jne 0x4d7eae
004d7ea7 8a467d                   mov al, byte ptr [esi + 0x7d]
004d7eaa 88442413                 mov byte ptr [esp + 0x13], al
004d7eae 8a442413                 mov al, byte ptr [esp + 0x13]
004d7eb2 5d                       pop ebp
004d7eb3 5f                       pop edi
004d7eb4 5e                       pop esi
004d7eb5 5b                       pop ebx
004d7eb6 83c430                   add esp, 0x30
004d7eb9 c3                       ret 
004d7eba 8bff                     mov edi, edi
004d7ebc 7776                     ja 0x4d7f34
004d7ebe 4d                       dec ebp
004d7ebf 0039                     add byte ptr [ecx], bh
004d7ec1 784d                     js 0x4d7f10
004d7ec3 00db                     add bl, bl
004d7ec5 784d                     js 0x4d7f14
004d7ec7 00d5                     add ch, dl
004d7ec9 794d                     jns 0x4d7f18
004d7ecb 00647a4d                 add byte ptr [edx + edi*2 + 0x4d], ah
004d7ecf 00f3                     add bl, dh
004d7ed1 7a4d                     jp 0x4d7f20
004d7ed3 00a67b4d0006             add byte ptr [esi + 0x6004d7b], ah
004d7ed9 7d4d                     jge 0x4d7f28
004d7edb 00cc                     add ah, cl
004d7edd cc                       int3 
004d7ede cc                       int3 
004d7edf cc                       int3 
004d7ee0 83ec04                   sub esp, 4
004d7ee3 53                       push ebx
004d7ee4 56                       push esi
004d7ee5 57                       push edi
004d7ee6 33db                     xor ebx, ebx
004d7ee8 33f6                     xor esi, esi
004d7eea 8b7c2414                 mov edi, dword ptr [esp + 0x14]
004d7eee 668b4772                 mov ax, word ptr [edi + 0x72]
004d7ef2 885c240f                 mov byte ptr [esp + 0xf], bl
004d7ef6 663bc3                   cmp ax, bx
004d7ef9 7417                     je 0x4d7f12
004d7efb 0fb7c0                   movzx eax, ax
004d7efe 8b048590038900           mov eax, dword ptr [eax*4 + 0x890390]
004d7f05 f6400c01                 test byte ptr [eax + 0xc], 1
004d7f09 7507                     jne 0x4d7f12
004d7f0b 38582a                   cmp byte ptr [eax + 0x2a], bl
004d7f0e 7402                     je 0x4d7f12
004d7f10 8bf0                     mov esi, eax
004d7f12 85f6                     test esi, esi
004d7f14 7452                     je 0x4d7f68
004d7f16 80bea600000000           cmp byte ptr [esi + 0xa6], 0
004d7f1d 7449                     je 0x4d7f68
004d7f1f f6472e0f                 test byte ptr [edi + 0x2e], 0xf
004d7f23 740d                     je 0x4d7f32
004d7f25 8d463d                   lea eax, [esi + 0x3d]
004d7f28 50                       push eax
004d7f29 57                       push edi
004d7f2a e8511e0100               call 0x4e9d80
004d7f2f 83c408                   add esp, 8
004d7f32 f6472e07                 test byte ptr [edi + 0x2e], 7
004d7f36 7435                     je 0x4d7f6d
004d7f38 0fbf463d                 movsx eax, word ptr [esi + 0x3d]
004d7f3c 0fbf4f3d                 movsx ecx, word ptr [edi + 0x3d]
004d7f40 2bc1                     sub eax, ecx
004d7f42 99                       cdq 
004d7f43 33c2                     xor eax, edx
004d7f45 2bc2                     sub eax, edx
004d7f47 3d38080000               cmp eax, 0x838
004d7f4c 7d1f                     jge 0x4d7f6d
004d7f4e 0fbf463f                 movsx eax, word ptr [esi + 0x3f]
004d7f52 0fbf4f3f                 movsx ecx, word ptr [edi + 0x3f]
004d7f56 2bc1                     sub eax, ecx
004d7f58 99                       cdq 
004d7f59 33c2                     xor eax, edx
004d7f5b 2bc2                     sub eax, edx
004d7f5d 3d38080000               cmp eax, 0x838
004d7f62 7d09                     jge 0x4d7f6d
004d7f64 b308                     mov bl, 8
004d7f66 eb05                     jmp 0x4d7f6d
004d7f68 c644240f01               mov byte ptr [esp + 0xf], 1
004d7f6d 807c240f00               cmp byte ptr [esp + 0xf], 0
004d7f72 744d                     je 0x4d7fc1
004d7f74 66c747720000             mov word ptr [edi + 0x72], 0
004d7f7a f6057cd1890002           test byte ptr [0x89d17c], 2
004d7f81 742c                     je 0x4d7faf
004d7f83 8a472b                   mov al, byte ptr [edi + 0x2b]
004d7f86 3c07                     cmp al, 7
004d7f88 750b                     jne 0x4d7f95
004d7f8a b327                     mov bl, 0x27
004d7f8c 5f                       pop edi
004d7f8d 8ac3                     mov al, bl
004d7f8f 5e                       pop esi
004d7f90 5b                       pop ebx
004d7f91 83c404                   add esp, 4
004d7f94 c3                       ret 
004d7f95 33c9                     xor ecx, ecx
004d7f97 5f                       pop edi
004d7f98 8ac8                     mov cl, al
004d7f9a 5e                       pop esi
004d7f9b 8d0489                   lea eax, [ecx + ecx*4]
004d7f9e 8d1480                   lea edx, [eax + eax*4]
004d7fa1 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d7fa8 8ac3                     mov al, bl
004d7faa 5b                       pop ebx
004d7fab 83c404                   add esp, 4
004d7fae c3                       ret 
004d7faf 33c0                     xor eax, eax
004d7fb1 8a472b                   mov al, byte ptr [edi + 0x2b]
004d7fb4 8d0c80                   lea ecx, [eax + eax*4]
004d7fb7 8d1489                   lea edx, [ecx + ecx*4]
004d7fba 8a1c5564705a00           mov bl, byte ptr [edx*2 + 0x5a7064]
004d7fc1 8ac3                     mov al, bl
004d7fc3 5f                       pop edi
004d7fc4 5e                       pop esi
004d7fc5 5b                       pop ebx
004d7fc6 83c404                   add esp, 4
004d7fc9 c3                       ret 
004d7fca cc                       int3 
004d7fcb cc                       int3 
004d7fcc cc                       int3 
004d7fcd cc                       int3 
004d7fce cc                       int3 
004d7fcf cc                       int3 
