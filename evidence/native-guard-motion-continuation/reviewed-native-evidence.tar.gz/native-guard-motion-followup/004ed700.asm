004ed700 56                       push esi
004ed701 33c0                     xor eax, eax
004ed703 8b742408                 mov esi, dword ptr [esp + 8]
004ed707 8a462a                   mov al, byte ptr [esi + 0x2a]
004ed70a 48                       dec eax
004ed70b 83f80a                   cmp eax, 0xa
004ed70e 0f87ce000000             ja 0x4ed7e2
004ed714 ff2485ecd74e00           jmp dword ptr [eax*4 + 0x4ed7ec]
004ed71b 56                       push esi
004ed71c e88f5bfeff               call 0x4d32b0
004ed721 83c404                   add esp, 4
004ed724 a181798900               mov eax, dword ptr [0x897981]
004ed729 894618                   mov dword ptr [esi + 0x18], eax
004ed72c 5e                       pop esi
004ed72d c3                       ret 
004ed72e 56                       push esi
004ed72f e84c5bf1ff               call 0x403280
004ed734 83c404                   add esp, 4
004ed737 a181798900               mov eax, dword ptr [0x897981]
004ed73c 894618                   mov dword ptr [esi + 0x18], eax
004ed73f 5e                       pop esi
004ed740 c3                       ret 
004ed741 56                       push esi
004ed742 e8d989f5ff               call 0x446120
004ed747 83c404                   add esp, 4
004ed74a a181798900               mov eax, dword ptr [0x897981]
004ed74f 894618                   mov dword ptr [esi + 0x18], eax
004ed752 5e                       pop esi
004ed753 c3                       ret 
004ed754 56                       push esi
004ed755 e82660f7ff               call 0x463780
004ed75a 83c404                   add esp, 4
004ed75d a181798900               mov eax, dword ptr [0x897981]
004ed762 894618                   mov dword ptr [esi + 0x18], eax
004ed765 5e                       pop esi
004ed766 c3                       ret 
004ed767 56                       push esi
004ed768 e8138dfbff               call 0x4a6480
004ed76d 83c404                   add esp, 4
004ed770 a181798900               mov eax, dword ptr [0x897981]
004ed775 894618                   mov dword ptr [esi + 0x18], eax
004ed778 5e                       pop esi
004ed779 c3                       ret 
004ed77a 56                       push esi
004ed77b e870d10000               call 0x4fa8f0
004ed780 83c404                   add esp, 4
004ed783 a181798900               mov eax, dword ptr [0x897981]
004ed788 894618                   mov dword ptr [esi + 0x18], eax
004ed78b 5e                       pop esi
004ed78c c3                       ret 
004ed78d 56                       push esi
004ed78e e8bdcf0100               call 0x50a750
004ed793 83c404                   add esp, 4
004ed796 a181798900               mov eax, dword ptr [0x897981]
004ed79b 894618                   mov dword ptr [esi + 0x18], eax
004ed79e 5e                       pop esi
004ed79f c3                       ret 
004ed7a0 56                       push esi
004ed7a1 e88ad6fcff               call 0x4bae30
004ed7a6 83c404                   add esp, 4
004ed7a9 a181798900               mov eax, dword ptr [0x897981]
004ed7ae 894618                   mov dword ptr [esi + 0x18], eax
004ed7b1 5e                       pop esi
004ed7b2 c3                       ret 
004ed7b3 56                       push esi
004ed7b4 e827aafcff               call 0x4b81e0
004ed7b9 83c404                   add esp, 4
004ed7bc a181798900               mov eax, dword ptr [0x897981]
004ed7c1 894618                   mov dword ptr [esi + 0x18], eax
004ed7c4 5e                       pop esi
004ed7c5 c3                       ret 
004ed7c6 56                       push esi
004ed7c7 e8f4360100               call 0x500ec0
004ed7cc 83c404                   add esp, 4
004ed7cf a181798900               mov eax, dword ptr [0x897981]
004ed7d4 894618                   mov dword ptr [esi + 0x18], eax
004ed7d7 5e                       pop esi
004ed7d8 c3                       ret 
004ed7d9 56                       push esi
004ed7da e86141fdff               call 0x4c1940
004ed7df 83c404                   add esp, 4
004ed7e2 a181798900               mov eax, dword ptr [0x897981]
004ed7e7 894618                   mov dword ptr [esi + 0x18], eax
004ed7ea 5e                       pop esi
004ed7eb c3                       ret 
004ed7ec 1bd7                     sbb edx, edi
004ed7ee 4e                       dec esi
004ed7ef 002e                     add byte ptr [esi], ch
004ed7f1 d7                       xlatb 
004ed7f2 4e                       dec esi
004ed7f3 0041d7                   add byte ptr [ecx - 0x29], al
004ed7f6 4e                       dec esi
004ed7f7 0054d74e                 add byte ptr [edi + edx*8 + 0x4e], dl
004ed7fb 0067d7                   add byte ptr [edi - 0x29], ah
004ed7fe 4e                       dec esi
004ed7ff 007ad7                   add byte ptr [edx - 0x29], bh
004ed802 4e                       dec esi
004ed803 008dd74e00a0             add byte ptr [ebp - 0x5fffb129], cl
004ed809 d7                       xlatb 
004ed80a 4e                       dec esi
004ed80b 00b3d74e00c6             add byte ptr [ebx - 0x39ffb129], dh
004ed811 d7                       xlatb 
004ed812 4e                       dec esi
004ed813 00d9                     add cl, bl
004ed815 d7                       xlatb 
004ed816 4e                       dec esi
004ed817 00cc                     add ah, cl
004ed819 cc                       int3 
004ed81a cc                       int3 
004ed81b cc                       int3 
004ed81c cc                       int3 
004ed81d cc                       int3 
004ed81e cc                       int3 
004ed81f cc                       int3 
