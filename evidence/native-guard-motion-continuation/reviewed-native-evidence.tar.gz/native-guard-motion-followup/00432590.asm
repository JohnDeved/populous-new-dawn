00432590 83ec14                   sub esp, 0x14
00432593 53                       push ebx
00432594 56                       push esi
00432595 57                       push edi
00432596 33db                     xor ebx, ebx
00432598 55                       push ebp
00432599 33ff                     xor edi, edi
0043259b 33ed                     xor ebp, ebp
0043259d 8b742428                 mov esi, dword ptr [esp + 0x28]
004325a1 33c9                     xor ecx, ecx
004325a3 885c2413                 mov byte ptr [esp + 0x13], bl
004325a7 668b8e9b000000           mov cx, word ptr [esi + 0x9b]
004325ae 895c2420                 mov dword ptr [esp + 0x20], ebx
004325b2 895c241c                 mov dword ptr [esp + 0x1c], ebx
004325b6 3bcb                     cmp ecx, ebx
004325b8 7405                     je 0x4325bf
004325ba 8d0489                   lea eax, [ecx + ecx*4]
004325bd eb19                     jmp 0x4325d8
004325bf 33c0                     xor eax, eax
004325c1 33d2                     xor edx, edx
004325c3 8a86a6000000             mov al, byte ptr [esi + 0xa6]
004325c9 668b94468b000000         mov dx, word ptr [esi + eax*2 + 0x8b]
004325d1 85d2                     test edx, edx
004325d3 740a                     je 0x4325df
004325d5 8d0492                   lea eax, [edx + edx*4]
004325d8 8d3c4530889300           lea edi, [eax*2 + 0x938830]
004325df 85ff                     test edi, edi
004325e1 0f8471040000             je 0x432a58
004325e7 f6470101                 test byte ptr [edi + 1], 1
004325eb 7407                     je 0x4325f4
004325ed bb01000000               mov ebx, 1
004325f2 eb0f                     jmp 0x432603
004325f4 f6461310                 test byte ptr [esi + 0x13], 0x10
004325f8 7409                     je 0x432603
004325fa bd01000000               mov ebp, 1
004325ff 896c2420                 mov dword ptr [esp + 0x20], ebp
00432603 85db                     test ebx, ebx
00432605 0f855a040000             jne 0x432a65
0043260b 85ed                     test ebp, ebp
0043260d 0f854a040000             jne 0x432a5d
00432613 f6462e07                 test byte ptr [esi + 0x2e], 7
00432617 0f8504010000             jne 0x432721
0043261d 8b5614                   mov edx, dword ptr [esi + 0x14]
00432620 f6c280                   test dl, 0x80
00432623 0f8487000000             je 0x4326b0
00432629 6683be9f00000000         cmp word ptr [esi + 0x9f], 0
00432631 7474                     je 0x4326a7
00432633 c744241800000000         mov dword ptr [esp + 0x18], 0
0043263b 85c9                     test ecx, ecx
0043263d 7524                     jne 0x432663
0043263f 8a86a6000000             mov al, byte ptr [esi + 0xa6]
00432645 33c9                     xor ecx, ecx
00432647 c744241400000000         mov dword ptr [esp + 0x14], 0
0043264f 88442414                 mov byte ptr [esp + 0x14], al
00432653 8b442414                 mov eax, dword ptr [esp + 0x14]
00432657 668b8c468b000000         mov cx, word ptr [esi + eax*2 + 0x8b]
0043265f 85c9                     test ecx, ecx
00432661 740e                     je 0x432671
00432663 8d0489                   lea eax, [ecx + ecx*4]
00432666 8d0c4530889300           lea ecx, [eax*2 + 0x938830]
0043266d 894c2418                 mov dword ptr [esp + 0x18], ecx
00432671 837c241800               cmp dword ptr [esp + 0x18], 0
00432676 742f                     je 0x4326a7
00432678 8d442414                 lea eax, [esp + 0x14]
0043267c 8b4c2418                 mov ecx, dword ptr [esp + 0x18]
00432680 50                       push eax
00432681 51                       push ecx
00432682 e839630000               call 0x4389c0
00432687 8d4c241c                 lea ecx, [esp + 0x1c]
0043268b 83c408                   add esp, 8
0043268e 6a00                     push 0
00432690 51                       push ecx
00432691 56                       push esi
00432692 e8b92e0000               call 0x435550
00432697 83c40c                   add esp, 0xc
0043269a 84c0                     test al, al
0043269c 7412                     je 0x4326b0
0043269e 8166147fffffff           and dword ptr [esi + 0x14], 0xffffff7f
004326a5 eb09                     jmp 0x4326b0
004326a7 81e27fffffff             and edx, 0xffffff7f
004326ad 895614                   mov dword ptr [esi + 0x14], edx
004326b0 33c0                     xor eax, eax
004326b2 8a86a7000000             mov al, byte ptr [esi + 0xa7]
004326b8 8d1480                   lea edx, [eax + eax*4]
004326bb 8d0450                   lea eax, [eax + edx*2]
004326be f60445cc7d5a0004         test byte ptr [eax*2 + 0x5a7dcc], 4
004326c6 7455                     je 0x43271d
004326c8 8b4e10                   mov ecx, dword ptr [esi + 0x10]
004326cb f6c108                   test cl, 8
004326ce 7551                     jne 0x432721
004326d0 668b869f000000           mov ax, word ptr [esi + 0x9f]
004326d7 6685c0                   test ax, ax
004326da 7439                     je 0x432715
004326dc 50                       push eax
004326dd e8fe50fdff               call 0x4077e0
004326e2 83c404                   add esp, 4
004326e5 85c0                     test eax, eax
004326e7 7426                     je 0x43270f
004326e9 6a00                     push 0
004326eb 6a01                     push 1
004326ed 50                       push eax
004326ee e83d480300               call 0x466f30
004326f3 83c40c                   add esp, 0xc
004326f6 84c0                     test al, al
004326f8 7427                     je 0x432721
004326fa 6a00                     push 0
004326fc 56                       push esi
004326fd e87e450300               call 0x466c80
00432702 83c408                   add esp, 8
00432705 84c0                     test al, al
00432707 7418                     je 0x432721
00432709 834e1008                 or dword ptr [esi + 0x10], 8
0043270d eb12                     jmp 0x432721
0043270f 834e1008                 or dword ptr [esi + 0x10], 8
00432713 eb0c                     jmp 0x432721
00432715 83c908                   or ecx, 8
00432718 894e10                   mov dword ptr [esi + 0x10], ecx
0043271b eb04                     jmp 0x432721
0043271d 836610f7                 and dword ptr [esi + 0x10], 0xfffffff7
00432721 33c0                     xor eax, eax
00432723 8a07                     mov al, byte ptr [edi]
00432725 83e803                   sub eax, 3
00432728 83f81e                   cmp eax, 0x1e
0043272b 0f870d030000             ja 0x432a3e
00432731 ff2485182d4300           jmp dword ptr [eax*4 + 0x432d18]
00432738 57                       push edi
00432739 56                       push esi
0043273a e8810f0000               call 0x4336c0
0043273f e9f3020000               jmp 0x432a37
00432744 57                       push edi
00432745 56                       push esi
00432746 e8b5100000               call 0x433800
0043274b e9e7020000               jmp 0x432a37
00432750 bb01000000               mov ebx, 1
00432755 e9e4020000               jmp 0x432a3e
0043275a 57                       push edi
0043275b 56                       push esi
0043275c e8bf2d0600               call 0x495520
00432761 e9d1020000               jmp 0x432a37
00432766 57                       push edi
00432767 56                       push esi
00432768 e833190000               call 0x4340a0
0043276d e9c5020000               jmp 0x432a37
00432772 57                       push edi
00432773 56                       push esi
00432774 e8971e0000               call 0x434610
00432779 e9b9020000               jmp 0x432a37
0043277e c644241400               mov byte ptr [esp + 0x14], 0
00432783 f6462e01                 test byte ptr [esi + 0x2e], 1
00432787 7546                     jne 0x4327cf
00432789 0fbf464f                 movsx eax, word ptr [esi + 0x4f]
0043278d 0fbf4e3d                 movsx ecx, word ptr [esi + 0x3d]
00432791 2bc1                     sub eax, ecx
00432793 99                       cdq 
00432794 33c2                     xor eax, edx
00432796 2bc2                     sub eax, edx
00432798 83f870                   cmp eax, 0x70
0043279b 7d1b                     jge 0x4327b8
0043279d 0fbf4651                 movsx eax, word ptr [esi + 0x51]
004327a1 0fbf4e3f                 movsx ecx, word ptr [esi + 0x3f]
004327a5 2bc1                     sub eax, ecx
004327a7 99                       cdq 
004327a8 33c2                     xor eax, edx
004327aa 2bc2                     sub eax, edx
004327ac 83f870                   cmp eax, 0x70
004327af 7d07                     jge 0x4327b8
004327b1 c644241401               mov byte ptr [esp + 0x14], 1
004327b6 eb05                     jmp 0x4327bd
004327b8 c644241400               mov byte ptr [esp + 0x14], 0
004327bd 807c241400               cmp byte ptr [esp + 0x14], 0
004327c2 740b                     je 0x4327cf
004327c4 6a00                     push 0
004327c6 56                       push esi
004327c7 e8f4300a00               call 0x4d58c0
004327cc 83c408                   add esp, 8
004327cf 33db                     xor ebx, ebx
004327d1 8a5c2414                 mov bl, byte ptr [esp + 0x14]
004327d5 e964020000               jmp 0x432a3e
004327da 57                       push edi
004327db 56                       push esi
004327dc e84f520600               call 0x497a30
004327e1 e951020000               jmp 0x432a37
004327e6 57                       push edi
004327e7 56                       push esi
004327e8 e823770e00               call 0x519f10
004327ed e945020000               jmp 0x432a37
004327f2 57                       push edi
004327f3 56                       push esi
004327f4 e807720000               call 0x439a00
004327f9 e939020000               jmp 0x432a37
004327fe bb01000000               mov ebx, 1
00432803 e936020000               jmp 0x432a3e
00432808 57                       push edi
00432809 56                       push esi
0043280a e821750000               call 0x439d30
0043280f e923020000               jmp 0x432a37
00432814 33c0                     xor eax, eax
00432816 8a4706                   mov al, byte ptr [edi + 6]
00432819 50                       push eax
0043281a 56                       push esi
0043281b e840bf0a00               call 0x4de760
00432820 668b869f000000           mov ax, word ptr [esi + 0x9f]
00432827 83c408                   add esp, 8
0043282a 6685c0                   test ax, ax
0043282d 741a                     je 0x432849
0043282f 0fb7c0                   movzx eax, ax
00432832 8b1c8590038900           mov ebx, dword ptr [eax*4 + 0x890390]
00432839 85db                     test ebx, ebx
0043283b 740c                     je 0x432849
0043283d 56                       push esi
0043283e e8fdbe0a00               call 0x4de740
00432843 83c404                   add esp, 4
00432846 88432f                   mov byte ptr [ebx + 0x2f], al
00432849 bb01000000               mov ebx, 1
0043284e e9eb010000               jmp 0x432a3e
00432853 57                       push edi
00432854 56                       push esi
00432855 e8767c0000               call 0x43a4d0
0043285a e9d8010000               jmp 0x432a37
0043285f 57                       push edi
00432860 56                       push esi
00432861 e8aa110000               call 0x433a10
00432866 e9cc010000               jmp 0x432a37
0043286b 57                       push edi
0043286c 56                       push esi
0043286d e82e7a0e00               call 0x51a2a0
00432872 e9c0010000               jmp 0x432a37
00432877 bb01000000               mov ebx, 1
0043287c e9bd010000               jmp 0x432a3e
00432881 57                       push edi
00432882 56                       push esi
00432883 e8187a0e00               call 0x51a2a0
00432888 e9aa010000               jmp 0x432a37
0043288d 57                       push edi
0043288e 56                       push esi
0043288f e8cc280000               call 0x435160
00432894 e99e010000               jmp 0x432a37
00432899 6a01                     push 1
0043289b 8d4706                   lea eax, [edi + 6]
0043289e 50                       push eax
0043289f bb01000000               mov ebx, 1
004328a4 56                       push esi
004328a5 e8a62c0000               call 0x435550
004328aa 83c40c                   add esp, 0xc
004328ad e98c010000               jmp 0x432a3e
004328b2 bb01000000               mov ebx, 1
004328b7 e982010000               jmp 0x432a3e
004328bc c644241800               mov byte ptr [esp + 0x18], 0
004328c1 57                       push edi
004328c2 56                       push esi
004328c3 e8f80d0000               call 0x4336c0
004328c8 83c408                   add esp, 8
004328cb 84c0                     test al, al
004328cd 7465                     je 0x432934
004328cf c644241801               mov byte ptr [esp + 0x18], 1
004328d4 8d442414                 lea eax, [esp + 0x14]
004328d8 50                       push eax
004328d9 57                       push edi
004328da e8e1600000               call 0x4389c0
004328df 8d44241c                 lea eax, [esp + 0x1c]
004328e3 83c408                   add esp, 8
004328e6 50                       push eax
004328e7 e86427fdff               call 0x405050
004328ec 0fbf4006                 movsx eax, word ptr [eax + 6]
004328f0 83c404                   add esp, 4
004328f3 8b148590038900           mov edx, dword ptr [eax*4 + 0x890390]
004328fa 85d2                     test edx, edx
004328fc 7436                     je 0x432934
004328fe b80a000000               mov eax, 0xa
00432903 b910000000               mov ecx, 0x10
00432908 38422a                   cmp byte ptr [edx + 0x2a], al
0043290b 7505                     jne 0x432912
0043290d 384a2b                   cmp byte ptr [edx + 0x2b], cl
00432910 741c                     je 0x43292e
00432912 33db                     xor ebx, ebx
00432914 668b5a20                 mov bx, word ptr [edx + 0x20]
00432918 8b149d90038900           mov edx, dword ptr [ebx*4 + 0x890390]
0043291f 85d2                     test edx, edx
00432921 75e5                     jne 0x432908
00432923 33db                     xor ebx, ebx
00432925 8a5c2418                 mov bl, byte ptr [esp + 0x18]
00432929 e910010000               jmp 0x432a3e
0043292e 66c742700000             mov word ptr [edx + 0x70], 0
00432934 33db                     xor ebx, ebx
00432936 8a5c2418                 mov bl, byte ptr [esp + 0x18]
0043293a e9ff000000               jmp 0x432a3e
0043293f bb01000000               mov ebx, 1
00432944 e9f5000000               jmp 0x432a3e
00432949 57                       push edi
0043294a 56                       push esi
0043294b e870930000               call 0x43bcc0
00432950 e9e2000000               jmp 0x432a37
00432955 57                       push edi
00432956 56                       push esi
00432957 e884d30e00               call 0x51fce0
0043295c e9d6000000               jmp 0x432a37
00432961 33c0                     xor eax, eax
00432963 668b4706                 mov ax, word ptr [edi + 6]
00432967 8b1c8590038900           mov ebx, dword ptr [eax*4 + 0x890390]
0043296e 8a462d                   mov al, byte ptr [esi + 0x2d]
00432971 c644241200               mov byte ptr [esp + 0x12], 0
00432976 84c0                     test al, al
00432978 7560                     jne 0x4329da
0043297a fec0                     inc al
0043297c 88462d                   mov byte ptr [esi + 0x2d], al
0043297f 8b4b3d                   mov ecx, dword ptr [ebx + 0x3d]
00432982 894c2414                 mov dword ptr [esp + 0x14], ecx
00432986 894c2418                 mov dword ptr [esp + 0x18], ecx
0043298a 8d4c2418                 lea ecx, [esp + 0x18]
0043298e 51                       push ecx
0043298f e8bc26fdff               call 0x405050
00432994 83c404                   add esp, 4
00432997 f6400102                 test byte ptr [eax + 1], 2
0043299b 7421                     je 0x4329be
0043299d 8d4c2418                 lea ecx, [esp + 0x18]
004329a1 51                       push ecx
004329a2 33c9                     xor ecx, ecx
004329a4 668b4808                 mov cx, word ptr [eax + 8]
004329a8 81e1ff030000             and ecx, 0x3ff
004329ae 8b048d90038900           mov eax, dword ptr [ecx*4 + 0x890390]
004329b5 50                       push eax
004329b6 e8f51afdff               call 0x4044b0
004329bb 83c408                   add esp, 8
004329be 8d442418                 lea eax, [esp + 0x18]
004329c2 50                       push eax
004329c3 56                       push esi
004329c4 e8a704fdff               call 0x402e70
004329c9 8d44241c                 lea eax, [esp + 0x1c]
004329cd 83c408                   add esp, 8
004329d0 50                       push eax
004329d1 56                       push esi
004329d2 e8a9730b00               call 0x4e9d80
004329d7 83c408                   add esp, 8
004329da f6462e01                 test byte ptr [esi + 0x2e], 1
004329de 7521                     jne 0x432a01
004329e0 6a38                     push 0x38
004329e2 8d464f                   lea eax, [esi + 0x4f]
004329e5 50                       push eax
004329e6 8d4e3d                   lea ecx, [esi + 0x3d]
004329e9 6a38                     push 0x38
004329eb 51                       push ecx
004329ec e8af030000               call 0x432da0
004329f1 83c410                   add esp, 0x10
004329f4 84c0                     test al, al
004329f6 7409                     je 0x432a01
004329f8 56                       push esi
004329f9 e8e2240a00               call 0x4d4ee0
004329fe 83c404                   add esp, 4
00432a01 66837b7a00               cmp word ptr [ebx + 0x7a], 0
00432a06 7405                     je 0x432a0d
00432a08 c644241201               mov byte ptr [esp + 0x12], 1
00432a0d 33db                     xor ebx, ebx
00432a0f 8a5c2412                 mov bl, byte ptr [esp + 0x12]
00432a13 eb29                     jmp 0x432a3e
00432a15 57                       push edi
00432a16 56                       push esi
00432a17 e884b00000               call 0x43daa0
00432a1c eb19                     jmp 0x432a37
00432a1e 57                       push edi
00432a1f 56                       push esi
00432a20 e8ab7a0000               call 0x43a4d0
00432a25 eb10                     jmp 0x432a37
00432a27 57                       push edi
00432a28 56                       push esi
00432a29 e8a27a0000               call 0x43a4d0
00432a2e eb07                     jmp 0x432a37
00432a30 57                       push edi
00432a31 56                       push esi
00432a32 e8699d0000               call 0x43c7a0
00432a37 83c408                   add esp, 8
00432a3a 33db                     xor ebx, ebx
00432a3c 8ad8                     mov bl, al
00432a3e f605a65d890004           test byte ptr [0x895da6], 4
00432a45 7516                     jne 0x432a5d
00432a47 f6467608                 test byte ptr [esi + 0x76], 8
00432a4b 7410                     je 0x432a5d
00432a4d 56                       push esi
00432a4e e86dee0c00               call 0x5018c0
00432a53 83c404                   add esp, 4
00432a56 eb05                     jmp 0x432a5d
00432a58 bd01000000               mov ebp, 1
00432a5d 85db                     test ebx, ebx
00432a5f 0f8449010000             je 0x432bae
00432a65 836614fe                 and dword ptr [esi + 0x14], 0xfffffffe
00432a69 8b463d                   mov eax, dword ptr [esi + 0x3d]
00432a6c 85ff                     test edi, edi
00432a6e c744241c01000000         mov dword ptr [esp + 0x1c], 1
00432a76 89442418                 mov dword ptr [esp + 0x18], eax
00432a7a 0f848e000000             je 0x432b0e
00432a80 33c0                     xor eax, eax
00432a82 8a07                     mov al, byte ptr [edi]
00432a84 8d1480                   lea edx, [eax + eax*4]
00432a87 8d0450                   lea eax, [eax + edx*2]
00432a8a 8b0445ca7d5a00           mov eax, dword ptr [eax*2 + 0x5a7dca]
00432a91 f6c401                   test ah, 1
00432a94 0f85be000000             jne 0x432b58
00432a9a a820                     test al, 0x20
00432a9c 742e                     je 0x432acc
00432a9e 8d442418                 lea eax, [esp + 0x18]
00432aa2 50                       push eax
00432aa3 57                       push edi
00432aa4 e8175f0000               call 0x4389c0
00432aa9 8b442420                 mov eax, dword ptr [esp + 0x20]
00432aad 8944241c                 mov dword ptr [esp + 0x1c], eax
00432ab1 8d44241c                 lea eax, [esp + 0x1c]
00432ab5 83c408                   add esp, 8
00432ab8 50                       push eax
00432ab9 56                       push esi
00432aba e861faffff               call 0x432520
00432abf 8d4c241c                 lea ecx, [esp + 0x1c]
00432ac3 83c408                   add esp, 8
00432ac6 51                       push ecx
00432ac7 e983000000               jmp 0x432b4f
00432acc 8b442418                 mov eax, dword ptr [esp + 0x18]
00432ad0 89442414                 mov dword ptr [esp + 0x14], eax
00432ad4 8d442414                 lea eax, [esp + 0x14]
00432ad8 50                       push eax
00432ad9 e87225fdff               call 0x405050
00432ade 83c404                   add esp, 4
00432ae1 f6400102                 test byte ptr [eax + 1], 2
00432ae5 7421                     je 0x432b08
00432ae7 8d4c2414                 lea ecx, [esp + 0x14]
00432aeb 51                       push ecx
00432aec 33c9                     xor ecx, ecx
00432aee 668b4808                 mov cx, word ptr [eax + 8]
00432af2 81e1ff030000             and ecx, 0x3ff
00432af8 8b048d90038900           mov eax, dword ptr [ecx*4 + 0x890390]
00432aff 50                       push eax
00432b00 e8ab19fdff               call 0x4044b0
00432b05 83c408                   add esp, 8
00432b08 8d442414                 lea eax, [esp + 0x14]
00432b0c eb40                     jmp 0x432b4e
00432b0e 8b442418                 mov eax, dword ptr [esp + 0x18]
00432b12 89442414                 mov dword ptr [esp + 0x14], eax
00432b16 8d442414                 lea eax, [esp + 0x14]
00432b1a 50                       push eax
00432b1b e83025fdff               call 0x405050
00432b20 83c404                   add esp, 4
00432b23 f6400102                 test byte ptr [eax + 1], 2
00432b27 7421                     je 0x432b4a
00432b29 8d4c2414                 lea ecx, [esp + 0x14]
00432b2d 51                       push ecx
00432b2e 33c9                     xor ecx, ecx
00432b30 668b4808                 mov cx, word ptr [eax + 8]
00432b34 81e1ff030000             and ecx, 0x3ff
00432b3a 8b048d90038900           mov eax, dword ptr [ecx*4 + 0x890390]
00432b41 50                       push eax
00432b42 e86919fdff               call 0x4044b0
00432b47 83c408                   add esp, 8
00432b4a 8d442414                 lea eax, [esp + 0x14]
00432b4e 50                       push eax
00432b4f 56                       push esi
00432b50 e81b03fdff               call 0x402e70
00432b55 83c408                   add esp, 8
00432b58 6683be9b00000000         cmp word ptr [esi + 0x9b], 0
00432b60 b101                     mov cl, 1
00432b62 7528                     jne 0x432b8c
00432b64 33c0                     xor eax, eax
00432b66 8a86a7000000             mov al, byte ptr [esi + 0xa7]
00432b6c 8d1c80                   lea ebx, [eax + eax*4]
00432b6f 8d0458                   lea eax, [eax + ebx*2]
00432b72 f60445cb7d5a0080         test byte ptr [eax*2 + 0x5a7dcb], 0x80
00432b7a 7508                     jne 0x432b84
00432b7c 8a86a6000000             mov al, byte ptr [esi + 0xa6]
00432b82 eb0a                     jmp 0x432b8e
00432b84 32c9                     xor cl, cl
00432b86 8a442414                 mov al, byte ptr [esp + 0x14]
00432b8a eb02                     jmp 0x432b8e
00432b8c b0ff                     mov al, 0xff
00432b8e 84c9                     test cl, cl
00432b90 740a                     je 0x432b9c
00432b92 50                       push eax
00432b93 56                       push esi
00432b94 e837390000               call 0x4364d0
00432b99 83c408                   add esp, 8
00432b9c 56                       push esi
00432b9d e80e3b0000               call 0x4366b0
00432ba2 83c404                   add esp, 4
00432ba5 84c0                     test al, al
00432ba7 7505                     jne 0x432bae
00432ba9 bd01000000               mov ebp, 1
00432bae 85ed                     test ebp, ebp
00432bb0 0f8456010000             je 0x432d0c
00432bb6 837c241c00               cmp dword ptr [esp + 0x1c], 0
00432bbb 0f85e7000000             jne 0x432ca8
00432bc1 8b463d                   mov eax, dword ptr [esi + 0x3d]
00432bc4 85ff                     test edi, edi
00432bc6 8944241c                 mov dword ptr [esp + 0x1c], eax
00432bca 0f848e000000             je 0x432c5e
00432bd0 33c9                     xor ecx, ecx
00432bd2 8a0f                     mov cl, byte ptr [edi]
00432bd4 8d1489                   lea edx, [ecx + ecx*4]
00432bd7 8d0c51                   lea ecx, [ecx + edx*2]
00432bda 8b044dca7d5a00           mov eax, dword ptr [ecx*2 + 0x5a7dca]
00432be1 f6c401                   test ah, 1
00432be4 0f85be000000             jne 0x432ca8
00432bea a820                     test al, 0x20
00432bec 742e                     je 0x432c1c
00432bee 8d44241c                 lea eax, [esp + 0x1c]
00432bf2 50                       push eax
00432bf3 57                       push edi
00432bf4 e8c75d0000               call 0x4389c0
00432bf9 8b442424                 mov eax, dword ptr [esp + 0x24]
00432bfd 8944241c                 mov dword ptr [esp + 0x1c], eax
00432c01 8d44241c                 lea eax, [esp + 0x1c]
00432c05 83c408                   add esp, 8
00432c08 50                       push eax
00432c09 56                       push esi
00432c0a e811f9ffff               call 0x432520
00432c0f 8d4c241c                 lea ecx, [esp + 0x1c]
00432c13 83c408                   add esp, 8
00432c16 51                       push ecx
00432c17 e983000000               jmp 0x432c9f
00432c1c 8b44241c                 mov eax, dword ptr [esp + 0x1c]
00432c20 89442414                 mov dword ptr [esp + 0x14], eax
00432c24 8d442414                 lea eax, [esp + 0x14]
00432c28 50                       push eax
00432c29 e82224fdff               call 0x405050
00432c2e 83c404                   add esp, 4
00432c31 f6400102                 test byte ptr [eax + 1], 2
00432c35 7421                     je 0x432c58
00432c37 8d4c2414                 lea ecx, [esp + 0x14]
00432c3b 51                       push ecx
00432c3c 33c9                     xor ecx, ecx
00432c3e 668b4808                 mov cx, word ptr [eax + 8]
00432c42 81e1ff030000             and ecx, 0x3ff
00432c48 8b048d90038900           mov eax, dword ptr [ecx*4 + 0x890390]
00432c4f 50                       push eax
00432c50 e85b18fdff               call 0x4044b0
00432c55 83c408                   add esp, 8
00432c58 8d442414                 lea eax, [esp + 0x14]
00432c5c eb40                     jmp 0x432c9e
00432c5e 8b44241c                 mov eax, dword ptr [esp + 0x1c]
00432c62 89442414                 mov dword ptr [esp + 0x14], eax
00432c66 8d442414                 lea eax, [esp + 0x14]
00432c6a 50                       push eax
00432c6b e8e023fdff               call 0x405050
00432c70 83c404                   add esp, 4
00432c73 f6400102                 test byte ptr [eax + 1], 2
00432c77 7421                     je 0x432c9a
00432c79 8d4c2414                 lea ecx, [esp + 0x14]
00432c7d 51                       push ecx
00432c7e 33c9                     xor ecx, ecx
00432c80 668b4808                 mov cx, word ptr [eax + 8]
00432c84 81e1ff030000             and ecx, 0x3ff
00432c8a 8b048d90038900           mov eax, dword ptr [ecx*4 + 0x890390]
00432c91 50                       push eax
00432c92 e81918fdff               call 0x4044b0
00432c97 83c408                   add esp, 8
00432c9a 8d442414                 lea eax, [esp + 0x14]
00432c9e 50                       push eax
00432c9f 56                       push esi
00432ca0 e8cb01fdff               call 0x402e70
00432ca5 83c408                   add esp, 8
00432ca8 f6461710                 test byte ptr [esi + 0x17], 0x10
00432cac 7514                     jne 0x432cc2
00432cae 85ff                     test edi, edi
00432cb0 741b                     je 0x432ccd
00432cb2 8a4701                   mov al, byte ptr [edi + 1]
00432cb5 a840                     test al, 0x40
00432cb7 7414                     je 0x432ccd
00432cb9 a880                     test al, 0x80
00432cbb 7510                     jne 0x432ccd
00432cbd 803f16                   cmp byte ptr [edi], 0x16
00432cc0 740b                     je 0x432ccd
00432cc2 6a00                     push 0
00432cc4 56                       push esi
00432cc5 e8b63f0300               call 0x466c80
00432cca 83c408                   add esp, 8
00432ccd 816614ffffffef           and dword ptr [esi + 0x14], 0xefffffff
00432cd4 837c242000               cmp dword ptr [esp + 0x20], 0
00432cd9 750f                     jne 0x432cea
00432cdb 56                       push esi
00432cdc e8bf050b00               call 0x4e32a0
00432ce1 88442417                 mov byte ptr [esp + 0x17], al
00432ce5 83c404                   add esp, 4
00432ce8 eb22                     jmp 0x432d0c
00432cea f6460e10                 test byte ptr [esi + 0xe], 0x10
00432cee 751c                     jne 0x432d0c
00432cf0 8a462c                   mov al, byte ptr [esi + 0x2c]
00432cf3 56                       push esi
00432cf4 88467d                   mov byte ptr [esi + 0x7d], al
00432cf7 e8f4a90b00               call 0x4ed6f0
00432cfc 83c404                   add esp, 4
