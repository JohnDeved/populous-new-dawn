"""Reviewer assertions. Reads frozen packet and replay; prints JSON only."""
import collections
import hashlib
import json
import os
import struct
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
packet = base.parent / 'native-guard-motion-followup'
root = Path('/workspace/scratch/69fd8163d94e/cloud-dev-20261004/native-shaman-guard-fix')
exe = Path(os.environ['POPULOUS_EXE'])
sys.path.insert(0, str(root / 'scripts'))
import unicorn
import capstone
from decomp import native_cpu

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original = packet / 'result-03.json'
replay = base / 'reviewer-result.json'
assert original.read_bytes() == replay.read_bytes(), 'Exact replay differs'
assert (base / 'reviewer-result.stderr').read_bytes() == b''
assert (base / 'verifier.stderr').read_bytes() == b''
assert (base / 'verifier.stdout.json').read_bytes() == (packet / 'verified-summary.json').read_bytes()
r = json.loads(replay.read_text())
cpu, identity = native_cpu(exe)
decoder = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
disassembly_checks = []
for path in sorted(packet.glob('*.asm')):
    count = 0
    for line in path.read_text().splitlines():
        address, encoded, assembly = line.split(None, 2)
        address, raw = int(address, 16), bytes.fromhex(encoded)
        assert bytes(cpu.mem_read(address, len(raw))) == raw, (path.name, hex(address))
        instruction = next(decoder.disasm(raw, address))
        assert instruction.size == len(raw)
        assert (instruction.mnemonic + ' ' + instruction.op_str).strip() == assembly.strip()
        count += 1
    disassembly_checks.append({'file': path.name, 'instructions': count, 'status': 'passed'})

receipt = json.loads((packet / 'receipt.json').read_text())
index = json.loads((root / 'decomp/exports.json').read_text())
assert index['executableSha256'] == identity['sha256']
indexed = []
for path, digest in receipt['sourceReferences'].items():
    if path.startswith('decomp/generated/'):
        assert index['files'][Path(path).name] == digest
        indexed.append(path)

def instruction_at(address):
    return next(decoder.disasm(bytes(cpu.mem_read(address, 16)), address))

native_edges = {0x4d32bb: 0x4d42a0, 0x4d32c4: 0x51fed0, 0x4d32cd: 0x4e9050,
                0x4d32d6: 0x4e6d00, 0x4e786e: 0x4eadc0, 0x4d351a: 0x432590,
                0x432a17: 0x43daa0, 0x4ed71c: 0x4d32b0, 0x4ec8b6: 0x4ed700,
                0x4ee785: 0x4ee7b0, 0x4d36f2: 0x4d73e0, 0x4d7765: 0x4d3ff0}
for caller, target in native_edges.items():
    i = instruction_at(caller)
    assert i.mnemonic == 'call' and int(i.op_str, 16) == target
assert instruction_at(0x4d7743).op_str == 'word ptr [esi + 0x5f], 0'
assert instruction_at(0x43db7f).op_str == 'dword ptr [edi + 0xc], 0xfdffffff'
assert struct.unpack('<I', cpu.mem_read(0x4ed7ec, 4))[0] == 0x4ed71b
assert struct.unpack('<I', cpu.mem_read(0x4d3d18 + 9 * 4, 4))[0] == 0x4d3519

rules = json.loads((root / 'app/original-rules.json').read_text())
assert rules['terrainCategoryFlags'][0] == 1
assert rules['personModels'][6]['physics'] == 17
assert rules['animationDescriptors'][18]['mode'] == 2
starts = list(struct.iter_unpack('<HH', (exe.parent / 'data/vstart-0.ani').read_bytes()))
frames = list(struct.iter_unpack('<HBBBBH', (exe.parent / 'data/vfra-0.ani').read_bytes()))
frame_counts = []
for start, unused in starts:
    cursor, seen = start, set()
    while cursor and cursor not in seen:
        seen.add(cursor)
        cursor = frames[cursor][-1]
    assert cursor in (0, start)
    frame_counts.append(len(seen) & 255)

cases = {c['label']: c for c in r['cases']}
assert set(cases) == {'near-guard', 'far-guard', 'target-loss', 'move-control'}
supplied = []
counts = collections.Counter()
case_summary = {}
def visit(c, n, animation=False):
    return c['stages'][2*n if animation else 2*n-1]
def delta(stage):
    return [stage['after'][k] - stage['before'][k] for k in ('x', 'y')]

for name, c in cases.items():
    assert c['status'] == 'passed' and len(c['stages']) == 49
    init = c['initialSnapshot']
    assert (init['id'], init['model'], init['physics'], init['state'], init['speed'], init['source']) == (1, 6, 17, 19, 0, 48)
    assert (init['x'], init['y'], init['goalX'], init['goalY'], init['destinationX'], init['destinationY'], init['turnX'], init['turnY']) == (4096,) * 8
    producer = c['stages'][0]
    for s in c['stages']:
        for e in s['events']:
            if e.get('supplied'):
                supplied.append([name, s['label'], e['address'], e['name']])
    if name != 'move-control':
        assert producer['entry'] == '00443b40'
        p = producer['after']
        assert p['commands'] == [1, 0, 0, 0, 0, 0, 0, 0]
        assert (p['orders'][1]['model'], p['orders'][1]['references'], p['orders'][1]['a']) == (30, 1, 73)
        assert p['flags2'] & 16 and p['state'] == 19 and p['status'] == 0
        p = visit(c, 1)['after']
        assert (p['state'], p['status'], p['target'], p['guardCount'], p['substate']) == (10, 30, 73, 1, 1)
        first_names = [(e['name'], e['event']) for e in visit(c, 1)['events']]
        assert first_names.index(('recover-movement', 'enter')) < first_names.index(('destination', 'enter'))
    else:
        assert producer['entry'] == '00444f60'
        assert (producer['after']['orders'][1]['model'], producer['after']['goalX'], producer['after']['goalY']) == (3, 4736, 4224)
    for n in range(1, 25):
        st, an = visit(c, n), visit(c, n, True)
        assert st['label'] == f'person visit {n}' and an['label'] == f'animation visit {n}'
        assert st['entry'] == '004ec898' and st['stop'] == '004ec8cb'
        assert an['entry'] == '004ee770' and an['stop'] == 'return'
        if n > 1:
            assert st['before'] == visit(c, n-1, True)['after']
        names = [(e['name'], e['event']) for e in st['events']]
        order = [('class-dispatch','enter'), ('person-processor','enter'), ('prepare-person','enter'),
                 ('prepare-person','return'), ('unsupported-ground-check','enter'),
                 ('unsupported-ground-check','return'), ('physics','enter'), ('route-advance','enter'),
                 ('route-advance','return'), ('physics','return')]
        positions = [names.index(e) for e in order]
        assert positions == sorted(positions)
        for e in st['events']:
            if e['event'] == 'enter':
                counts[e['name']] += 1
                if e['name'] == 'physics': assert e['callerReturn'] == '004d32db'
                if e['name'] == 'unsupported-ground-check': assert e['callerReturn'] == '004d32d2'
                if e['name'] == 'guard':
                    assert e['callerReturn'] == '00432a1c'
                    assert names.index(('physics','return')) < names.index(('guard','enter')) < names.index(('guard','return'))
        tail = [('health-tail','enter'), ('health-tail','return'), ('combat-tail','enter'), ('combat-tail','return'),
                ('tail-4d9bd0','enter'), ('tail-4d9bd0','return'), ('tail-4def50','enter'), ('tail-4def50','return'),
                ('tail-4da2a0','enter'), ('tail-4da2a0','return'), ('person-processor','return'), ('class-dispatch','return')]
        positions = [names.index(e) for e in tail]
        assert positions == sorted(positions)
        assert names.index(('physics','return')) < positions[0]
        assert st['after']['counter'] == n == st['after']['stamp']
        assert st['after'] == an['before']
        assert not any(e.get('supplied') for e in st['events'] + an['events'])
        assert [e['name'] for e in an['events'] if e['event']=='enter'] == ['animation-list','animation-visit']
        before, after = an['before'], an['after']
        descriptor = rules['animationDescriptors'][before['draw']]
        assert descriptor['mode'] == 2
        f1, f2 = before['f1'], before['f2']
        if not f1:
            f1, f2 = descriptor['step'], (f2 + 1) & 255
            if frame_counts[before['source']] <= f2: f2 = 0
        else: f1 -= 1
        assert (after['f1'], after['f2']) == (f1, f2)
        assert {k: v for k, v in before.items() if k not in ('f1', 'f2')} == {k: v for k, v in after.items() if k not in ('f1', 'f2')}
    case_summary[name] = {'personVisits':24, 'animationVisits':24, 'finalPosition':[visit(c,24)['after'][k] for k in ('x','y')]}

assert supplied == [['move-control','native command3 producer','00436330','command-acknowledgement'],
                    ['move-control','native command3 producer','0047a550','selection-ui-refresh']]
for name, clear_at, expected_delta in [('near-guard',4,[61,17]),('far-guard',20,[63,8])]:
    c = cases[name]
    st = visit(c, clear_at)
    guard = [e for e in st['events'] if e['name'] == 'guard']
    before, after = guard[0]['snapshot'], guard[-1]['snapshot']
    assert before['pursuit'] and not after['pursuit']
    changes = [k for k in before if before[k] != after[k]]
    assert set(changes) <= {'flags2','pursuit','assignment'}
    assert delta(visit(c, clear_at+1)) == expected_delta
    for n in range(clear_at,25):
        a = visit(c,n)['after']
        assert (a['state'], a['status'], a['speed'], a['source']) == (10,30,61,40)
        assert delta(visit(c,n)) != [0,0]
    case_summary[name].update(clearVisit=clear_at, guardChangedSnapshotFields=changes, followingDelta=expected_delta)
assert visit(cases['near-guard'],10)['after']['route'] == 1
assert visit(cases['near-guard'],11)['after']['route'] == 0
assert visit(cases['far-guard'],4)['after']['pursuit']
for name, first, velocity in [('target-loss',13,[57,0,18]),('move-control',12,[65,0,20])]:
    c = cases[name]
    assert visit(c,first-1)['after']['speed'] > 0
    for n in range(first,25):
        a = visit(c,n)['after']
        assert (a['x'],a['y'],a['speed'],a['state'],a['source'],a['route']) == (4864,4352,0,19,48,0)
        assert [a[k] for k in ('vx','vh','vy')] == velocity
        if n>first: assert delta(visit(c,n)) == [0,0]
    case_summary[name].update(firstSettledVisit=first, settledVelocity=velocity, settlingDelta=delta(visit(c,first)))
assert cases['target-loss']['intervention'] == {'beforeVisit':5,'targetFlags2SetBit':1,'reason':'explicit target-loss input'}
assert visit(cases['target-loss'],5)['after']['state'] == 17
assert delta(visit(cases['target-loss'],5)) == [61,17]
assert (visit(cases['target-loss'],10)['after']['state'],visit(cases['target-loss'],10)['after']['source'],visit(cases['target-loss'],10)['after']['speed']) == (19,48,65)
assert visit(cases['target-loss'],11)['after']['source'] == 40

tool_files = [Path(sys.executable).resolve(), Path(unicorn.__file__), Path(capstone.__file__), root/'decomp/tools.json', root/'decomp/exports.json']
for module in [unicorn,capstone]:
    tool_files += list(Path(module.__file__).parent.glob('lib/*.so*'))
print(json.dumps({'status':'passed','byteIdenticalReplay':True,'replayBytes':replay.stat().st_size,
    'resultSha256':sha(replay),'verifierSummaryByteIdentical':True,'disassembly':disassembly_checks,
    'indexedExportsChecked':indexed,'nativeCallEdges':{f'{a:08x}':f'{b:08x}' for a,b in native_edges.items()},
    'personEntryCounts':dict(counts),'cases':case_summary,'suppliedLeafEvents':supplied,
    'toolchain':{'python':sys.version,'unicorn':unicorn.__version__,'capstone':capstone.__version__,'affinity':sorted(os.sched_getaffinity(0)),
                'files':{str(p):sha(p) for p in tool_files}},
    'limits':['Exact same frozen synthetic world and case order; memory resets between cases, CPU registers retain ordinary call-return state',
              'Reaction call proven by unconditional native instruction bytes, not a separately named hook event',
              'Native rows snapshot selected fields and route bytes, not all native memory',
              'No port execution, browser, scheduler outer loop, live campaign, arbitrary world, or full Guard parity acceptance']},indent=2))
