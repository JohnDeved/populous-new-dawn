import assert from 'node:assert/strict'
import { readFileSync, existsSync, realpathSync, statfsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { registerHooks } from 'node:module'
import { pathToFileURL, fileURLToPath } from 'node:url'
import os from 'node:os'

const snapshot = JSON.parse(readFileSync(process.env.PAINTER_SOURCE_MANIFEST,'utf8'))
const verifyOnly=process.argv.includes('--verify')
const reference=JSON.parse(readFileSync('/workspace/scratch/69fd8163d94e/painter-baseline-474/run-1.jsonl','utf8').trim().split('\n').at(-1))
const root = snapshot.sourceRoot, expectedFiles = snapshot.files
const config = { benchmark:'terrain-only-production-painter-v1', mission:1, warmups:32, repetitions:128,
  cases:['static','water','camera'], width:1920,height:1080,sourceRoot:root,targetCommit:snapshot.targetCommit }
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const fingerprints = new Map()
function remember(path) {
  path = realpathSync(path)
  const digest = hash(readFileSync(path))
  if (fingerprints.has(path)) assert.equal(digest, fingerprints.get(path), `Input changed during loading: ${path}`)
  else fingerprints.set(path, digest)
}
const fixed = ['package.json', 'package-lock.json', 'app/scene.ts',
  'app/scene-terrain-runtime.ts', 'app/water.ts', 'app/projection.ts',
  'tests/support/bloodlust-scene.mjs', 'tests/support/world-environment-scene.mjs',
  'tests/water-animation-callers.test.mjs']
for (const [file, digest] of Object.entries(expectedFiles)) {
  assert.equal(hash(readFileSync(`${root}/${file}`)), digest, `Snapshot drift: ${file}`)
}
for (const file of fixed) assert.ok(existsSync(`${root}/${file}`), `Missing ${file}`)
const outputFs=statfsSync('/workspace/scratch/69fd8163d94e'); assert.ok(outputFs.bsize*outputFs.bavail>4*1024*1024)
const available = statfsSync('/tmp'); assert.ok(available.bsize * available.bavail > 2 * 1024 * 1024)
if (process.argv.includes('--validate-config')) {
  console.log(JSON.stringify({ type: 'configuration', status: 'valid', ...config,
    node: process.version, note: 'No production imports, fixture execution or timing performed.' }))
  process.exit(0)
}
assert.deepEqual(process.argv.slice(2),[verifyOnly?'--verify':'--run'])
for (const file of Object.keys(expectedFiles)) remember(`${root}/${file}`)
remember(fileURLToPath(import.meta.url))
// Register before the existing fixture hooks so every resolution is fingerprinted,
// including source returned by the fixture transpiler instead of the default loader.
registerHooks({ resolve(specifier, context, next) {
  const result = next(specifier, context)
  if (result.url.startsWith('file:')) remember(fileURLToPath(result.url))
  return result
} })
const start = performance.now()
const { loadSceneFixture } = await import(pathToFileURL(`${root}/tests/support/bloodlust-scene.mjs`))
const { bindSceneEnvironment } = await import(pathToFileURL(`${root}/tests/support/world-environment-scene.mjs`))
const api = await loadSceneFixture()
const { GameScene } = await import(pathToFileURL(`${root}/app/scene.ts`))
const { RenderView } = await import(pathToFileURL(`${root}/app/render-view.ts`))
const { initializeTerrain } = await import(pathToFileURL(`${root}/app/scene-terrain-runtime.ts`))
const { painterDepth, comparePolygons } = await import(pathToFileURL(`${root}/app/painter-order.ts`))
const THREE = await import(pathToFileURL(`${root}/node_modules/three/build/three.module.js`))
const importsMs = performance.now() - start
const originalFetch = globalThis.fetch
const assets = []
globalThis.fetch = async url => {
  assert.ok(typeof url === 'string' && url.startsWith('/original/') && !url.includes('..'))
  const path = `${root}/public${url}`; remember(path); assets.push(path)
  const bytes = readFileSync(path)
  return { ok: true, arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) }
}
const noop = () => {}
const world = api.createWorld(config.mission)
const scene = Object.assign(Object.create(GameScene.prototype), {
  world, terrainLoad: new AbortController(), terrainMap: new THREE.DataTexture(),
  waterMap: new THREE.DataTexture(new Uint8Array(256 * 256 * 4), 256, 256),
  waterScroll: { value: 0 }, updateTerrainTexture: noop, updateView: noop,
  view: new RenderView(), decorations: new THREE.Group(), scene: new THREE.Scene(),
})
scene.updateView = () => scene.view.update(config.width,config.height,{x:2,z:30},0,0,false)
const setupStart = performance.now()
await bindSceneEnvironment(scene)
const initialized = initializeTerrain(scene); scene.terrain = initialized.terrain
await initialized.ready; scene.rebuildTerrain()
globalThis.fetch = originalFetch
const setupMs = performance.now() - setupStart
const terrain=scene.terrain, view=scene.view, painter=view.painter
scene.scene.add(terrain)
painter.landFlags=world.land.flags; painter.land=world.land; painter.cells=world.objectCells
view.prepare(scene.scene)
assert.equal(view.projection.width,config.width);assert.equal(view.projection.height,config.height)
assert.deepEqual(view.terrainHeights,[Math.min(0,...world.land.heights),Math.max(63,...world.land.heights)])
assert.equal(terrain.geometry.attributes.position.count,98304)
const originalMaterial=terrain.material, originalGroups=terrain.geometry.groups
assert.equal(originalMaterial.transparent,false)
let installedSort, sortInstallCount=0
const renderer={setTransparentSort:fn=>{installedSort=fn;sortInstallCount++}}
const bytes=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength)
const input=()=>({world:hash(JSON.stringify(world)),waves:hash(bytes(scene.waves)),
 geometry:Object.fromEntries(Object.entries(terrain.geometry.attributes).map(([n,a])=>[n,hash(bytes(a.array))])),
 index:hash(bytes(terrain.geometry.index.array)),drawRange:{...terrain.geometry.drawRange},
 instanceCount:terrain.count,instanceMatrices:hash(bytes(terrain.instanceMatrix.array))})
const output=()=>({texture:{width:painter.texture.image.width,height:painter.texture.image.height,hash:hash(bytes(painter.texture.image.data))},
 commands:hash(JSON.stringify(painter.commandsBySlot)),range:[...painter.ranges.get(terrain)],objectId:terrain.id,
 submittedIndex:hash(bytes(terrain.geometry.index.array.subarray(0,terrain.geometry.drawRange.count))),
 submittedCount:terrain.geometry.drawRange.count,instances:terrain.count,matrices:hash(bytes(terrain.instanceMatrix.array))})
const prepare=(name,index)=>{
 if(name==='water'){world.turn=index&255;scene.updateWater()}
 view.update(config.width,config.height,{x:2,z:30},name==='camera'?(index%64)*Math.PI/32:0,0,false)
 scene.scene.updateMatrixWorld(true)
 view.updateTerrainVisibility(terrain)
}
const run=()=>{
 const version=painter.texture.version,sorts=sortInstallCount
 const start=verifyOnly?0n:process.hrtime.bigint()
 try {painter.update(scene.scene,renderer)} finally {painter.afterRender()}
 const ns=verifyOnly?0:Number(process.hrtime.bigint()-start)
 assert.equal(painter.texture.version,version+1);assert.equal(sortInstallCount,sorts+1)
 assert.equal(typeof installedSort,'function');assert.equal(painter.transparentMeshes.length,0)
 assert.equal(terrain.material,originalMaterial);assert.equal(terrain.geometry.groups,originalGroups)
 return ns
}
const check=()=>{
 let accepted=0
 for(const command of painter.commandsBySlot)if(command){
  accepted++;assert.equal(painter.commandsBySlot[command.slot],command)
  assert.ok(Number.isFinite(painter.texture.image.data[command.slot]))
 }
 assert.ok(accepted>0,'Fixture must submit nonzero commands')
 const ordered=painter.commandsBySlot.filter(Boolean).sort(comparePolygons),stretch=Math.max(1,accepted/16000)
 ordered.forEach((c,i)=>assert.equal(painter.texture.image.data[c.slot],painterDepth(i/stretch)))
 for(let slot=0;slot<painter.texture.image.data.length;slot++)if(!painter.commandsBySlot[slot])assert.equal(painter.texture.image.data[slot],2)
 assert.deepEqual(painter.ranges.get(terrain),[0,32768])
 assert.equal(painter.commandsBySlot.length,32768*terrain.count)
 return accepted
}
const checks=[]
// Deterministic repeatability with accepted real geometry, waves and visibility.
for(const [name,index] of [['static',0],['water',0],['water',23],['water',255],['water',256],['camera',16],['camera',32]]){
 prepare(name,index);const worldBefore=structuredClone(world),before=input();run();const a=output(),accepted=check();run()
 assert.deepEqual(output(),a);assert.deepEqual(input(),before);assert.deepEqual(world,worldBefore)
 assert.deepEqual(a,reference.checks.find(c=>c.name===name&&c.index===index).output)
 checks.push({name,index,accepted,output:a})
}
const rows=[],summaries=[],states=[],memory=[]
const census={waterCalls:0,replacedBuffers:0,newPayloadBytes:0}
for(const name of config.cases){
 for(let i=0;i<config.warmups;i++){prepare(name,i);run()}
 memory.push({case:name,point:'before',...process.memoryUsage(),usage:process.resourceUsage()})
 for(let i=0;i<config.repetitions;i++){prepare(name,config.warmups+i);const previous=verifyOnly&&name==='water'?painter.centers.get(terrain.geometry.attributes.position)?.positions.array:null;const ns=run();if(previous){census.waterCalls++;const current=painter.centers.get(terrain.geometry.attributes.position).positions.array;if(current!==previous){census.replacedBuffers++;census.newPayloadBytes+=current.byteLength}}rows.push({type:'sample',case:name,index:i,ns})}
 const accepted=check(),a=output(),worldBefore=structuredClone(world),before=input();run();assert.deepEqual(output(),a);assert.deepEqual(input(),before);assert.deepEqual(world,worldBefore)
 assert.deepEqual(a,reference.states.find(s=>s.case===name).output)
 const position=terrain.geometry.attributes.position,cached=painter.vertices.get(position,true)
 states.push({case:name,accepted,output:a,positionVersion:position.version,
  uniqueSourceVertices:new Set(cached.source).size,sourceVertices:cached.source.length,
  retainedVertexTypedBytes:cached.source.byteLength+cached.seen.byteLength+cached.depth.byteLength,
  centerTypedBytes:painter.triangleCenters(position).array.byteLength})
 memory.push({case:name,point:'after',...process.memoryUsage(),usage:process.resourceUsage()})
 const v=rows.filter(r=>r.case===name).map(r=>r.ns).sort((a,b)=>a-b)
 summaries.push({type:'summary',case:name,count:v.length,medianNs:(v[63]+v[64])/2,p95Ns:v[Math.ceil(v.length*.95)-1],p99Ns:v[Math.ceil(v.length*.99)-1],maxNs:v.at(-1),totalNs:v.reduce((a,b)=>a+b,0)})
}
for(const [path,digest] of fingerprints)assert.equal(hash(readFileSync(path)),digest,`Input drift ${path}`)
console.log(JSON.stringify({type:'manifest',...config,verifyOnly,importsMs,setupMs,versions:process.versions,cpu:os.cpus()[0]?.model,
 sourceProvenance:snapshot.sourceProvenance,fingerprints:Object.fromEntries(fingerprints),assets,
 caveats:['Terrain only: excludes models/sprites/selection/alpha-sort execution. Renderer boundary only captures sort installation.',
 'CPU update plus afterRender only; view/visibility/water preparation, hashing, setup, GPU/browser/rendering excluded.',
 'Deterministic regression outputs, not native visual parity. VM contention unknown; no FPS inference.',
 'Memory checkpoints are not allocation rates. afterRender restoration check is vacuous for alpha on opaque terrain.']}))
for(const r of rows)console.log(JSON.stringify(r))
for(const r of summaries)console.log(JSON.stringify(r))
console.log(JSON.stringify({type:'correctness',status:'pass',checks,states,memory,census,dependenciesStable:true}))
terrain.geometry.dispose();terrain.material.dispose();scene.terrainMap.dispose();scene.waterMap.dispose();view.dispose()
