# Painter center allocation census and sampled profile

One completed baseline diagnostic, no optimization. First attempt failed before its first measured sample due to a scratch loop-local variable shadowing the position attribute. Failed runner/stdout/stderr retained as water-centers-profile-attempt1.*. The repaired runner changes only those diagnostic references; retry completed exit 0 with empty stderr.

## Verified result
All 128 changed-water samples replaced center backing storage, each 786,432 bytes, totaling 100,663,296 bytes (96 MiB) cumulative new payload. An unchanged-version control retained the identical array. This is an observed allocation-identity census, not resident memory, allocator throughput, or GC causation. The initial control retains one old buffer; per-sample census retains the prior array only until that iteration ends, never a collection of all arrays.

All seven untimed correctness check records match the earlier baseline exactly. The final water-case texture/commands/range/indices/matrix output matches exactly. All 339 current loaded-input hashes match. The 128 raw sample rows contain version progression and backing-byte observations.

## Profiling limit
The in-process CPU profiler samples at 1 ms. Profiler.start costs 384.518 ms outside timed calls. Conservatively intersected start/stop clock-offset bounds are 14.631 ms wide, larger than individual painter calls; zero weighted samples can be assigned unambiguously to a specific painter interval. Therefore profiling is interpreted only across the whole loop, which includes water/camera/visibility preparation outside the timed painter call.

Whole-loop separately resolved weighted samples include updateWater 627.815 ms, Painter update 355.920 ms, run 314.376 ms, waterPoint 222.321 ms, dot 101.146 ms, projectPoint 58.072 ms, comparePolygons 16.704 ms, and triangleCenters 13.019 ms. Inlined/unresolved work prevents using the triangleCenters label as its complete cost. There are 24 observed GC entries and 11 painter enclosing intervals overlap an entry; this does not establish the centers allocation as their cause.

Instrumented painter median/p95/p99/max: 7.754/10.410/11.968/12.816 ms. These are diagnostic-only, not a speed comparison.

## Recommendation
A single isolated storage-reuse experiment is justified by the observed 96 MiB replacement payload and source-consumer audit. It may claim allocation elimination only after its own census verifies it. No speedup is established. Preserve exact Float64 ordered accumulation, per-attribute isolation, proper interleaved versions and count-change reallocation. Explicitly document mutable cache lifetime instead of silently weakening the old fresh-identity assertion. Stop profiling here; no repeated run to force clearer sampling.

Artifacts: water-centers-profile.mjs/.jsonl/.stderr, water-centers.cpuprofile, water-centers-profile-attempt1.*, WATER-CENTERS-PROFILE-SHA256SUMS. Source manifest and original run-1.jsonl provide comparison baseline.
