import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
const root='/tmp/populous-selector-scene-457',git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim(),head=git('rev-parse','HEAD')
if(git('status','--porcelain'))throw Error('Dirty source')
const manifest='/tmp/selector-scene457/test-inventory-70c1b94673fbb6148e7a340e1de9c350fd427982.json'
const inventory=JSON.parse(readFileSync(manifest)),results=[]
for(const number of [18,36]){
 const files=inventory.batches[number-1],output=`work/orchestration/selector-scene457/${head.slice(0,8)}/inventory-${number}-repaired-1.json`
 const receipt=runCommandReceipt(root,{output,command:['node','--test','--test-concurrency=1',...files],inputs:[manifest,...files,'/tmp/selector-scene457/run-repaired-batches.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 const counts=Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(label=>{const matches=[...receipt.stdout.matchAll(new RegExp(`^(?:#|ℹ) ${label} (\\d+)\\s*$`,'gm'))];if(!matches.length)throw Error('Missing final summary');return [label,Number(matches.at(-1)[1])]}))
 results.push({number,head,output,status:receipt.status,files,counts});console.log(JSON.stringify(results.at(-1)))
 if(receipt.status!=='passed')process.exitCode=1
}
writeFileSync(`/tmp/selector-scene457/repaired-batches-${head}.json`,JSON.stringify(results,null,2)+'\n')
