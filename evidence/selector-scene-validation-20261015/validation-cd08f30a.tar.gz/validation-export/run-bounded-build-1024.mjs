import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
import {execFileSync} from 'node:child_process'
const root='/tmp/populous-selector-scene-457'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
const head=git('rev-parse','HEAD')
if(head!=='cd08f30aec9fcda2d78fda366d445f72e561828e'||git('status','--porcelain'))throw Error('Source must remain exact clean candidate')
const receipt=runCommandReceipt(root,{
 output:'work/orchestration/selector-scene457/cd08f30a/build-heap1024-after-cleanup-1.json',
 command:['env','NODE_OPTIONS=--max-old-space-size=1024','RAYON_NUM_THREADS=1','TOKIO_WORKER_THREADS=1','UV_THREADPOOL_SIZE=1','npm','run','build'],
 inputs:['/tmp/selector-scene457/run-bounded-build-1024.mjs','/tmp/selector-scene457/build-heap1024-before.txt','/tmp/selector-scene-checks/cleanup-current-selector-receipt.json','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json'],
})
console.log(JSON.stringify({status:receipt.status,exitCode:receipt.exitCode,head:receipt.source.headOid}))
process.exitCode=receipt.status==='passed'?0:1
