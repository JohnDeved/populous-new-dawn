import {execFileSync} from 'node:child_process'
import {existsSync,readFileSync} from 'node:fs'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
const head=git('rev-parse','HEAD')
if(git('status','--porcelain'))throw Error('Source must be committed and clean')
const gates={
 typecheck:['node','node_modules/typescript/bin/tsc','--noEmit','--incremental','false'],
 parity:['npm','run','parity:check'],
 orchestration:['npm','run','orchestration:check'],
 build:['env','NODE_OPTIONS=--max-old-space-size=2048','npm','run','build'],
 eslint:['npm','run','lint'],
 oxlint:['npm','run','lint:standard'],
 format:['npm','run','format:check'],
 health:['npm','run','quality:health'],
 dupes:['npm','run','quality:dupes'],
 unused:['npm','run','quality:unused'],
}
const requested=process.argv.slice(2)
for(const name of requested.length?requested:Object.keys(gates)){
 if(!gates[name])throw Error('Unknown gate '+name)
 const output=`work/orchestration/selector-scene457/${head.slice(0,8)}/${name}.json`
 if(existsSync(`${root}/${output}`)){
  const existing=JSON.parse(readFileSync(`${root}/${output}`))
  if(existing.status!=='passed'||existing.source.headOid!==head)throw Error(`Review retained ${output}; never overwrite`)
  console.log(`${name}: already passed`);continue
 }
 const receipt=runCommandReceipt(root,{output,command:gates[name],inputs:['/tmp/selector-scene457/run-final-gates.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 console.log(`${name}: ${receipt.status}, exit ${receipt.exitCode}`)
 if(receipt.status!=='passed')process.exitCode=1
 if(git('rev-parse','HEAD')!==head||git('status','--porcelain'))throw Error('Source changed during gates')
}
