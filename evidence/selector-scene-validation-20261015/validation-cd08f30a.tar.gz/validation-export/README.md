# PR465 validation handoff

Candidate cd08f30aec9fcda2d78fda366d445f72e561828e. Application subtree is unchanged
from 70c1b946; the intervening reviewed diff fixes two readiness guards for omitted
fixture signalCode, updates VM import stubs and the native-default Load assertion,
adds a signal-exit test, and removes one unused browser-test helper.

Full initial inventory: 429 files, 43 batches, 2759 tests, 2748 pass, 11 fail.
Both full failed batches were rerun at cd08f30a: batch18 87/87, batch36 81/81.
Independent replacement accounting: all429 files covered,2760 pass,zero failures,
skips or cancellations. These tests did not all run at the same head. All original
failed receipts remain under the original head and are included verbatim.

Final candidate typecheck, parity, orchestration, health and duplication passed.
Global ESLint/Oxlint/format/unused checks remain failed; baseline attribution is
included. New unused helper error is removed at cd08f30a. Retained native-panel
initial autofocus is the prior focus pattern adapted to the native-default UI.

Production-target build evidence: canonical Cloudflare check116708241907 is
SUCCESS at exactcd08f30a, build83fd6241-e6fb-4c1a-a4ef-50fe59d2d6c8,
version21cf3753-2fb5-4ba5-b4c2-0b129d2681c5. Committed deployment configuration
records npm run build:cloudflare, which chains the full vinext build with the
Cloudflare target. Root independently verified served current SSR/client assets.
Remote raw phase logs/live dashboard command were not available. Independent
review accepts this production-target build evidence for the bounded PR.

All four local ordinary Sites-target build attempts remain FAILED exit137, including
native-thread/heap-bounded attempts and an audited generated-cache cleanup. The
1024MB attempt completed client output then died in SSR rendering. No cause proved.
The remote-only browser attempt failed initial navigation with ERR_EMPTY_RESPONSE,
so no remote rendered-UI claim is made. These limits are not overwritten by remote
build SUCCESS.

Live render/settled focus/ribbon pixels/responsive/DPR and repeated lifecycle passed
at52e645ad. Complete native text/cursor/tooltip/fallback diagnostic passed at22fdd9ee.
Their exact receipts/screenshots are committed in evidence/selector-scene-*.
Later changes preserve production timing/pixels and carry-forward is reviewed.
Live asset/context recovery, real visibility and paused-world identity remain
BLOCKED/NOT VERIFIED after retained browser/server failures. Static helper tests
are not a substitute for these missing live paths. No original-runtime pixel or
hardware-FPS parity, no full issue17/457 closure, and root alone owns merge.

Absolute paths in raw receipts identify the execution inputs. Raw stdout/stderr,
source hashes, installed dependency lock binding and runners are retained.
