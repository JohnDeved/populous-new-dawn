import { runCommandReceipt } from '../../../scripts/orchestration/command-receipt.mjs';
import { writeFileSync } from 'node:fs';
const repo = process.cwd();
const files = ['app/hud-tasks.ts', 'app/follower-tasks-runtime.ts', 'app/follower-tasks-view.tsx', 'app/hud.tsx', 'app/page.tsx', 'app/scene.ts', 'app/scene-input-runtime.ts'];
const env = { ...process.env, TMPDIR: '/workspace/scratch/69fd8163d94e/cloud-dev-20261004/follower-controls-verify-58-tmp', npm_config_cache: repo + '/work/cache/npm', XDG_CACHE_HOME: repo + '/work/cache/xdg', XDG_CONFIG_HOME: repo + '/work/cache/config', XDG_DATA_HOME: repo + '/work/cache/data', CLOUDFLARE_CF_FETCH_ENABLED: 'false', WRANGLER_SEND_METRICS: 'false', WRANGLER_WRITE_LOGS: 'false', WRANGLER_LOG_PATH: repo + '/work/cache/wrangler.log', MINIFLARE_REGISTRY_PATH: repo + '/work/cache/registry' };
const plans = [
 ['check', ['npm','run','check']],
 ['build', ['npm','run','build']],
 ['format', ['./node_modules/.bin/oxfmt','--check', ...files]],
 ['eslint', ['./node_modules/.bin/eslint', ...files]],
 ['oxlint', ['./node_modules/.bin/oxlint', ...files]],
 ['fallow-health', ['./node_modules/.bin/fallow','health','--no-cache','--changed-since','25491a5','--hotspots','--targets','--format','json']],
 ['fallow-dupes', ['./node_modules/.bin/fallow','dupes','--no-cache','--changed-since','25491a5','--format','json']],
 ['fallow-unused', ['./node_modules/.bin/fallow','dead-code','--no-cache','--changed-since','25491a5','--format','json']],
];
const results=[];
for (const [name, command] of plans) {
 const receipt=runCommandReceipt(repo, { output: 'work/orchestration/follower-final/' + name + '.json', command, env, inputs: ['work/orchestration/follower-final/run.mjs','work/orchestration/follower-final/dependency-transfer.json','scripts/orchestration/command-receipt.mjs','package-lock.json','node_modules/.package-lock.json'] });
 const result={name,status:receipt.status,exitCode:receipt.exitCode,head:receipt.source.headOid,finishedAt:receipt.finishedAt,stdoutSha256:receipt.stdoutSha256,stderrSha256:receipt.stderrSha256}; results.push(result); console.log(JSON.stringify(result));
 if (receipt.status==='invalidated') throw Error('Source or inputs changed: '+name);
}
writeFileSync('work/orchestration/follower-final/terminal.json', JSON.stringify({status:'terminal',finishedAt:new Date().toISOString(),results,limits:'Functional validation in independent writable directories; historical unknown panel run is untouched. No machine-idleness or performance claim.'},null,2)+'\n');
process.exitCode=results.filter(r=>['check','build'].includes(r.name)).every(r=>r.status==='passed') ? 0 : 1;
