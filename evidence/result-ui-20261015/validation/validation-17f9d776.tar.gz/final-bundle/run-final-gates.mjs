import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
if(git('status','--porcelain'))throw Error('Run only on clean committed source')
const head=git('rev-parse','HEAD'), prefix=`work/orchestration/result-screen457/${head.slice(0,8)}`
const inputs=['package-lock.json','node_modules/.package-lock.json','/tmp/selector-scene457/git-bin/git','/tmp/result-screen457/run-final-gates.mjs']
const gates=[
 ['typecheck',['npm','run','typecheck']],
 ['parity',['npm','run','parity:check']],
 ['orchestration',['npm','run','orchestration:check']],
 ['format',['npm','run','format:check']],
 ['oxlint',['npm','run','lint:standard']],
 ['eslint',['npm','run','lint']],
 ['focused-format',['node_modules/.bin/oxfmt','--check','app/original-result-layout.ts','app/original-result-screen.tsx','app/page.tsx']],
 ['focused-lint',['node_modules/.bin/eslint','app/original-result-layout.ts','app/original-result-screen.tsx','scripts/result-ui-fixture/capture.mjs','tests/original-result-screen.test.mjs']],
 ...['health','dupes','unused'].map(kind=>[`quality-${kind}`,['node','scripts/performance-queue.mjs','foreground','120000','--','npm','run',`quality:${kind}`]])
]
const results=[]
for(const [name,command] of gates){
 const output=`${prefix}/${name}.json`
 const result=runCommandReceipt(root,{output,command,inputs})
 results.push({name,output,status:result.status,exitCode:result.exitCode,signal:result.signal})
 console.log(`${name}: ${result.status} (exit ${result.exitCode})`)
 writeFileSync(`/tmp/result-screen457/gates-${head}.json`,JSON.stringify({head,complete:results.length===gates.length,results},null,2)+'\n')
 if(result.status==='invalidated')throw Error('Source drift invalidates further gate results')
}
