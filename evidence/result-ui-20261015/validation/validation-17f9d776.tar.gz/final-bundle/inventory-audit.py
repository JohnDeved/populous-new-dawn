from pathlib import Path
import argparse,collections,datetime,hashlib,json,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--repo',default='/tmp/populous-selector-scene-457');p.add_argument('--git',default='/tmp/selector-scene457/git-bin/git');p.add_argument('--output',required=True);args=p.parse_args()
repo=Path(args.repo);manifest=Path(args.manifest);data=json.loads(manifest.read_text());head=data['head'];root=repo/'work/orchestration/result-screen457'/head[:8]
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(path):return sha_bytes(Path(path).read_bytes())
def git(*a):return subprocess.check_output([args.git,*a],cwd=repo,text=True).strip()
errors=[]
def require(value,message):
 if not value:errors.append(message)
expected=list(data['files']);flat=[f for batch in data['batches'] for f in batch];dupes=[f for f,n in collections.Counter(flat).items() if n>1]
tracked=git('ls-tree','-r','--name-only',head,'--','tests').splitlines();canonical=sorted(f for f in tracked if re.fullmatch(r'tests/[^/]+\.test\.mjs',f))
require(expected==sorted(expected),'Manifest file keys are not sorted')
require(expected==canonical,'Manifest differs from canonical tracked top-level test glob')
require(flat==expected,'Batch coverage/order differs from expected file inventory')
require(not dupes,'Duplicate files: '+repr(dupes))
source_mismatches=[]
for f,want in data['files'].items():
 if sha(repo/f)!=want:source_mismatches.append(f)
require(not source_mismatches,'Current test hashes differ: '+repr(source_mismatches))
current_head=git('rev-parse','HEAD');current_diff=git('diff',head,'--name-only');current_status=git('status','--porcelain')
results=[];totals=collections.Counter();covered=[];pending=[];seen_commands=[]
for i,batch in enumerate(data['batches'],1):
 path=root/f'inventory-{i:02}.json'
 if not path.exists():pending.append({'batch':i,'reason':'receipt absent'});continue
 d=json.loads(path.read_text());local=[]
 def check(v,m):
  if not v:local.append(m)
 if d.get('phase')!='finished':
  pending.append({'batch':i,'reason':d.get('phase',d.get('status','unfinished')),'receiptSha256':sha(path)});continue
 check(d.get('source',{}).get('headOid')==head,'Wrong tested HEAD')
 check(d.get('source')==d.get('sourceAfter'),'Source/input fingerprint changed during run')
 check(d.get('source',{}).get('trackedDiffSha256')==sha_bytes(b''),'Tested source diff was not empty')
 check(d.get('cwd')==str(repo),'Unexpected command cwd')
 command=['node','--test','--test-concurrency=1',*batch]
 check(d.get('command')==command,'Command/test-file list differs from manifest batch')
 seen_commands.extend(d.get('command',[])[3:])
 input_hashes={}
 for f,want in d.get('source',{}).get('inputs',{}).items():
  full=Path(f) if Path(f).is_absolute() else repo/f
  actual=sha(full);input_hashes[f]={'expected':want,'actual':actual,'matches':actual==want};check(actual==want,'Current explicit input hash differs: '+f)
 check(str(manifest) in input_hashes,'Missing inventory manifest input')
 check('node_modules/.package-lock.json' in input_hashes,'Missing installed dependency lock input')
 logs={}
 for kind in ['stdout','stderr']:
  f=Path(d['artifacts'][kind]);b=f.read_bytes();text=b.decode();want=d.get(kind+'Sha256');actual=sha_bytes(b)
  check(actual==want,'Raw '+kind+' hash differs')
  check(text==d.get(kind),'Raw '+kind+' differs from embedded receipt text')
  logs[kind]={'path':str(f),'bytes':len(b),'sha256':actual}
 raw=Path(d['artifacts']['stdout']).read_text();counts={};occurrences={}
 for label in ['tests','suites','pass','fail','cancelled','skipped','todo']:
  matches=list(re.finditer(r'^(?:#|ℹ) '+label+r' (\d+)\s*$',raw,re.M));occurrences[label]=[int(m.group(1)) for m in matches]
  check(bool(matches),'Missing top-level final '+label+' count')
  if matches:counts[label]=int(matches[-1].group(1))
 check(d.get('status')=='passed','Receipt not passed: '+str(d.get('status')))
 check(d.get('exitCode')==0 and d.get('signal') is None,'Nonzero exit or signal')
 if len(counts)==7:
  check(counts['tests']>0,'No tests executed')
  check(counts['fail']==0 and counts['cancelled']==0,'Terminal failed/cancelled tests')
  check(counts['tests']==counts['pass']+counts['skipped']+counts['todo'],'Terminal test count arithmetic mismatch')
  totals.update(counts)
 if not local:covered.extend(batch)
 results.append({'batch':i,'fileCount':len(batch),'files':batch,'receipt':str(path),'receiptSha256':sha(path),'status':'verified' if not local else 'rejected','reportedStatus':d.get('status'),'counts':counts,'summaryOccurrences':occurrences,'rawLogs':logs,'inputHashes':input_hashes,'errors':local})
 errors.extend(f'Batch{i}: {m}' for m in local)
require(len(seen_commands)==len(set(seen_commands)),'Duplicate command files across terminal receipts')
terminal=manifest.parent/f'inventory-terminal-{head}.json'
terminal_result=None
if terminal.exists():
 t=json.loads(terminal.read_text());terminal_result={'path':str(terminal),'sha256':sha(terminal),'reportedFileCount':t.get('fileCount'),'reportedTestCount':t.get('testCount'),'reportedFailed':t.get('failed')}
 require(t.get('head')==head,'Terminal summary HEAD differs')
 require(t.get('fileCount')==len(expected),'Terminal summary file count differs')
 require(t.get('testCount')==totals['tests'],'Terminal summary test count differs from audited LAST counts')
 require(t.get('failed')==sum(r['reportedStatus']!='passed' for r in results),'Terminal summary failure count differs')
 require(len(t.get('batches',[]))==len(data['batches']),'Terminal summary batch coverage differs')
 for tr,rr in zip(t.get('batches',[]),results):
  require(tr.get('index')==rr['batch'] and tr.get('files')==rr['files'],'Terminal batch identity differs')
  require(all(tr.get('counts',{}).get(k)==rr['counts'].get(k) for k in ['tests','pass','fail','cancelled','skipped','todo']),'Terminal counts differ from independently audited LAST counts')
report={'kind':'independent-result-screen-test-inventory-audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditorScriptSha256':sha(__file__),'status':'failed' if errors else ('pending' if pending else 'passed'),'head':head,'manifest':str(manifest),'manifestSha256':sha(manifest),'canonicalFileCount':len(canonical),'inventoryFileCount':len(expected),'plannedBatches':len(data['batches']),'verifiedFiles':len(covered),'verifiedBatches':sum(r['status']=='verified' for r in results),'terminalReceipts':len(results),'totalsFromLastTopLevelSummaries':dict(totals),'pending':pending,'errors':errors,'sourceNow':{'head':current_head,'status':current_status,'pathsChangedSinceTestedHead':current_diff.splitlines()},'batches':results,'terminalSummary':terminal_result,'repairSubstitutions':[],'limits':['Read-only receipt audit; no tests/build/browser launched by this auditor.','Counts use the LAST unindented top-level summary for each label, preserving all earlier occurrences for inspection.','In-progress receipts and missing receipts are pending, never passes. No repair substitution accepted unless separately reviewed and explicitly recorded.']}
Path(args.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','head','inventoryFileCount','verifiedFiles','verifiedBatches','terminalReceipts','totalsFromLastTopLevelSummaries','errors']},indent=2));sys.exit(1 if errors else 0)
