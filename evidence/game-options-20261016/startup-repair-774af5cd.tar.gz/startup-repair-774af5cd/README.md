# Repaired-head actual Home startup check

Source: clean `774af5cd968935603f61bfed3ab5ec750e25eac6`. Terminal result: passed. All 1,105 production input hashes remained unchanged during this episode; receipt includes exact browser/scenario/entry provenance.

The unchanged production Home component, global CSS and original public assets were mounted through the existing local plain React/Vite entry. Framework bootstrap/RSC/hydration and deployment were excluded. This episode did not create a GameScene or repeat camera/restart checks.

Passed checks:
- Native 640×480 five-row geometry: center x320; top y139/169/199/229/259; three unavailable rows inert; every control in bounds.
- Repeated Enter/Space toggles preserve the actual button node and keyboard focus, with correct alternating values.
- Game → Sound → Graphics → Direct3D → Game roundtrip: exclusive category contents, selected heading focus and retained choices. Browser-help return focus and full-page preference reload also passed.
- Storage-write failure: readable non-overlapping notice, values retained across category/back/reentry within the session, and unsaved values restored to defaults on full reload.

Screenshots `frontend-game-640x480.png`, `frontend-game-category-roundtrip-640x480.png`, and `frontend-game-storage-failure-640x480.png` were visually inspected. They are actual repaired-head captures, not baseline comparisons.

`source-relationship.json` records the boundary with earlier live evidence: exactly `app/original-options.tsx` changed from browser-tested 580df36b; the other 1,104 inputs are identical. Prior actual camera/store/preferences/listener evidence is carried forward across the reviewed disjoint JSX-guard repair, not relabeled as a fresh gameplay run. Both earlier ordinary-Restart renderer crashes remain unresolved and retained separately.
