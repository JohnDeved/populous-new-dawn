import assert from 'node:assert/strict'
import {createServer} from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/postcss'
import {chromium} from '@playwright/test'
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
const repo=resolve(process.env.POPULOUS_GAME_ROOT??process.cwd()),root=resolve(process.env.POPULOUS_FIXTURE_ROOT),output=resolve(process.env.POPULOUS_OPTIONS_OUTPUT)
const port=Number(process.env.POPULOUS_OPTIONS_PORT??4183),browserPath=process.env.POPULOUS_BROWSER
if(!browserPath)throw Error('POPULOUS_BROWSER must identify installed official Chrome Headless Shell')
if(!Number.isInteger(port)||port<1024||port>65535||[4190,6000,6666,10080].includes(port))throw Error('Use an allowed unprivileged port')
if(existsSync(resolve(output,'receipt.json')))throw Error('Use a fresh output directory')
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex'),source=JSON.parse(readFileSync(resolve(root,'source.json'),'utf8'))
const receipt={status:'running',startedAt:new Date().toISOString(),command:{repo,root,output,port,browserPath,node:process.version},source,scenarioSha256:hash(import.meta.filename),fixtureSha256:hash(resolve(root,'main.tsx')),checks:[],captures:[],errors:[],limits:source.limits}
mkdirSync(output,{recursive:true})
const save=()=>writeFileSync(resolve(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n')
const stage=name=>{receipt.stage=name;save()}
let server,browser,page,context,timer
const button=name=>page.getByRole('button',{name,exact:true}),options=()=>page.locator('[data-original-options]')
const rotation=()=>page.getByRole('button',{name:/^Rotation : </}),flip=()=>page.getByRole('button',{name:/^Flip Rotation : </})
const readPrefs=()=>page.evaluate(()=>window.testSceneRef?.current?.gamePreferences)
const settle=()=>page.evaluate(()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done))))
async function check(name,fn){stage(name);const details=await fn();receipt.checks.push({name,status:'passed',details});save()}
async function capture(name){await page.screenshot({path:resolve(output,name+'.png')});receipt.captures.push({name:name+'.png',viewport:await page.evaluate(()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio})),skin:await options().getAttribute('data-skin')});save()}
async function label(control){return control().getAttribute('aria-label')}
async function setPrefs(rotationName,reversed){if(!(await label(rotation)).includes(`<${rotationName}>`))await rotation().click();if(!(await label(flip)).includes(`<${reversed?'Yes':'No'}>`))await flip().click()}
async function menuOptions(){await button('Game settings').click();await button('Options').click();await options().waitFor();assert.equal(await options().getAttribute('data-category'),'Game')}
async function continueFromOptions(){await button('Back').click();await button('Continue Game').click();await page.locator('dialog[open]').waitFor({state:'hidden'});await page.locator('canvas.battlefield').focus();await page.mouse.move(700,400);await settle()}
async function diagnostic(name){const state=await page.evaluate(()=>{const s=window.testSceneRef?.current,w=s?.world;return {url:location.href,hidden:document.hidden,focus:document.hasFocus(),active:document.activeElement?.outerHTML?.slice(0,300),openDialogs:[...document.querySelectorAll('dialog[open]')].map(x=>x.getAttribute('aria-label')),scene:!!s,connected:!!s?.renderer.domElement.isConnected,started:s?.started,disposed:s?.disposed,modalSuspended:s?.modalSuspended,preferences:s?.gamePreferences,world:w&&{turn:w.turn,time:w.time,paused:w.paused,inputMask:w.inputMask,flyby:structuredClone(w.flyby),levelStart:structuredClone(w.levelStart),status:w.status},body:document.body.innerText.slice(0,3000)}});writeFileSync(resolve(output,name+'.json'),JSON.stringify(state,null,2)+'\n');await page.screenshot({path:resolve(output,name+'.png')});return state}
async function readyForInput(label){await diagnostic(label+'-post-skip');const guard=page.getByRole('button',{name:/^Continue anyway/});if(await guard.isVisible())await guard.click();if(await button('Resume game').isVisible()){await button('Resume game').click();await diagnostic(label+'-ordinary-resume')}try{await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask,null,{timeout:60000})}catch(e){await diagnostic(label+'-readiness-timeout');throw e}}
async function snapshot(){return page.evaluate(async()=>{const s=window.testSceneRef.current,w=s.world,digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(w)));return {worldHash:[...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,'0')).join(''),camera:{...s.cameraPosition},frame:s.gameClock.animationFrame,animationTime:s.gameClock.animationTime,modal:s.modalSuspended,paused:w.paused,connected:s.renderer.domElement.isConnected}})}
async function expectRealKey(keys,expected){
 await page.locator('canvas.battlefield').focus();await page.mouse.move(700,400)
 const before=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition}))
 try{
  for(const key of keys)await page.keyboard.down(key)
  await page.waitForFunction(expected=>window.testSceneRef.current.navigationButtons()===expected,expected,{timeout:5000})
  await page.waitForFunction(before=>{const a=window.testSceneRef.current.cameraPosition;return a.x!==before.x||a.y!==before.y||a.angle!==before.angle},before,{timeout:5000})
 }finally{for(const key of [...keys].reverse())await page.keyboard.up(key)}
 await page.waitForFunction(()=>window.testSceneRef.current.navigationButtons()===0)
 const after=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition})),delta=((after.angle-before.angle+1024)&2047)-1024
 if(expected&48){assert.notEqual(delta,0);assert.equal(Math.sign(delta),expected&32?1:-1);assert.equal(after.x,before.x);assert.equal(after.y,before.y)}else{assert.equal(delta,0);assert.ok(after.x!==before.x||after.y!==before.y)}
 const still=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition}));await page.waitForTimeout(100);assert.deepEqual(await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition})),still,'released real keys must stop movement')
 return {keys,expected,before,after,delta}
}
try{
 save();stage('create-plain-react-vite')
 server=await createServer({configFile:false,root,publicDir:resolve(repo,'public'),cacheDir:resolve(root,'.vite'),plugins:[react()],css:{postcss:{plugins:[tailwindcss({base:root})]}},server:{host:'127.0.0.1',port,strictPort:true,fs:{allow:[root,repo]}},logLevel:'warn'})
 await server.listen();stage('launch-sandboxed-browser')
 browser=await chromium.launch({executablePath:resolve(browserPath),headless:true,chromiumSandbox:true,ignoreDefaultArgs:true,args:['--remote-debugging-pipe'],timeout:30000})
 receipt.browser=browser.version();context=await browser.newContext({viewport:{width:1280,height:960}});page=await context.newPage()
 page.setDefaultTimeout(20000);page.on('pageerror',error=>receipt.errors.push(String(error)));page.on('crash',()=>{receipt.errors.push('Page crashed');save()})
 timer=setTimeout(()=>{receipt.timedOut=true;void browser.close()},120000)
 stage('open-actual-home');await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:45000});await button('Options').waitFor()
 await page.setViewportSize({width:640,height:480})
 await check('actual Home native-size five Game rows and original-art geometry',async()=>{
  await button('Options').click();await options().and(page.locator('[data-art-ready="true"]')).waitFor();await setPrefs('Control Cursor',true)
  await capture('frontend-game-640x480')
  const geometry=[]
  for(const [role,name,y]of [['note','Tooltips : <Unavailable>',139],['button','Rotation : <Control Cursor>',169],['button','Flip Rotation : <Yes>',199],['note','Stay Selected : <Unavailable>',229],['note','Autocast Spell : <Unavailable>',259]]){
   const row=page.getByRole(role,{name,exact:true}),box=await row.boundingBox(),rootBox=await options().boundingBox()
   assert.ok(box);assert.ok(rootBox);const position={name,center:(box.x-rootBox.x+box.width/2)*640/rootBox.width,y:(box.y-rootBox.y)*480/rootBox.height}
   geometry.push(position);assert.equal(position.center,320);assert.equal(position.y,y)
   if(role==='note'){assert.equal(await row.getAttribute('tabindex'),null);assert.equal(await row.locator('button,input,select').count(),0)}
  }
  assert.equal(await page.getByRole('button',{name:/^(Tooltips|Stay Selected|Autocast Spell)/}).count(),0)
  for(const b of await options().locator('button').all()){const box=await b.boundingBox();assert.ok(box.x>=-1&&box.x+box.width<=641&&box.y>=-1&&box.y+box.height<=481)}
  return {geometry,unsupportedInert:true}
 })
 await check('storage-write failure preserves session choices and shows readable native-size notice',async()=>{
  await context.close();context=await browser.newContext({viewport:{width:640,height:480}})
  await context.addInitScript(()=>{const write=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==='populous-game-preferences')throw Error('fixture quota denied');return write.call(this,key,value)}})
  page=await context.newPage();page.setDefaultTimeout(20000);page.on('pageerror',e=>receipt.errors.push(String(e)))
  await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded'});await button('Options').click();await setPrefs('Control Cursor',true);await options().and(page.locator('[data-art-ready="true"]')).waitFor()
  const notice=page.getByRole('status').filter({hasText:/session.*storage|storage.*session/i});await notice.waitFor();await capture('frontend-game-storage-failure-640x480')
  const text=await notice.innerText(),noticeBox=await notice.boundingBox(),linkBox=await button('Browser compatibility and help').boundingBox()
  assert.equal(await page.evaluate(()=>localStorage.getItem('populous-game-preferences')),null)
  await button('Sound').click();await button('Game').click();assert.equal(await label(rotation),'Rotation : <Control Cursor>');assert.equal(await label(flip),'Flip Rotation : <Yes>')
  await button('Back').click();await button('Options').click();assert.equal(await label(rotation),'Rotation : <Control Cursor>');assert.equal(await label(flip),'Flip Rotation : <Yes>')
  assert.ok(noticeBox.y+noticeBox.height<=linkBox.y||linkBox.y+linkBox.height<=noticeBox.y,'Storage notice must not overlap compatibility link')
  await page.reload({waitUntil:'domcontentloaded'});await button('Options').click();assert.equal(await label(rotation),'Rotation : <Cursor>');assert.equal(await label(flip),'Flip Rotation : <No>')
  return {text,noticeBox,linkBox,sessionRetention:true,reloadDefaults:true}
 })
 for(const [file,expected]of Object.entries(source.files))assert.equal(hash(resolve(repo,file)),expected,`Production source/asset changed: ${file}`)
 assert.deepEqual(receipt.errors,[])
 receipt.status='passed'
}catch(error){try{if(page&&!page.isClosed())await diagnostic('failure-state')}catch(diagnosticError){receipt.diagnosticFailure=String(diagnosticError)}receipt.status='failed';receipt.failure=String(error);receipt.stack=error.stack;receipt.checks.push({name:receipt.stage,status:'failed',error:String(error)});process.exitCode=1}
finally{const mismatches=[];for(const [file,expected]of Object.entries(source.files)){try{const actual=hash(resolve(repo,file));if(actual!==expected)mismatches.push({file,expected,actual})}catch(e){mismatches.push({file,error:String(e)})}}receipt.sourceVerification={checkedAt:new Date().toISOString(),fileCount:Object.keys(source.files).length,status:mismatches.length?'failed':'passed',mismatches};if(mismatches.length){receipt.status='failed';process.exitCode=1}clearTimeout(timer);await browser?.close();await server?.close();receipt.finishedAt=new Date().toISOString();save();console.log(JSON.stringify({status:receipt.status,checks:receipt.checks.map(({name,status})=>({name,status})),failure:receipt.failure,receipt:resolve(output,'receipt.json')},null,2))}
