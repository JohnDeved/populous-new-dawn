# Actual Home Game-options validation

## Reusable local route

`prepare-home-fixture.py` writes a separate plain React entry importing the unchanged production `app/page.tsx` and `app/globals.css`. Its Vite config in `capture-home.mjs` uses only the React plugin, existing Tailwind PostCSS handling, and production `public/` assets. It excludes Vinext/Cloudflare/RSC server startup and hydration. It does not replace the Page owner, scene, store, input listeners, preference functions, or game modules.

Prepare with the actual repository's existing dependencies and verified git wrapper on PATH:

```
python3 prepare-home-fixture.py --game-root ABSOLUTE_REPO --fixture-root FRESH_FIXTURE
```

Set these environment variables for the capture runner:

- POPULOUS_GAME_ROOT: repository
- POPULOUS_FIXTURE_ROOT: prepared fixture directory
- POPULOUS_OPTIONS_OUTPUT: fresh evidence directory
- POPULOUS_OPTIONS_PORT: an available allowed local port, default 4183
- POPULOUS_BROWSER: installed official Chrome Headless Shell
- NODE_OPTIONS=--max-old-space-size=512

Run `node capture-home.mjs` only after coordinating the heavy lane. The runner uses the browser sandbox and no unsafe renderer or certificate flags. It preserves receipts, explicit production source/asset fingerprints, post-introduction diagnostic state/screenshots, and failures. A 240-second wall-time bound closes only this invocation's browser/server; individual native input-readiness windows are 60 seconds, matching the existing lifecycle check. It never directly unlocks or mutates the world to establish readiness. Ordinary Skip/Resume/Continue UI actions may be used.

`game-preferences-navigation.test.mjs` is the focused Node integration test, now copied into the writer's checkout. It imports the real camera helpers and extracts the actual key map and navigation caller using TypeScript AST. Controlled scene/document data are explicit for these unit/caller tests. These are not the browser witness; the separate actual-Home runner provides actual constructor/listener/UI/frame evidence.

## Scope of the browser witness

- Production startup and in-game Options rendering/labels, inert unsupported rows, focused repeated Enter/Space and mouse choices
- Browser preference persistence/reload and actual newly constructed scene attachment
- Scene/world identity and exact paused modal state preservation during setting changes
- Compatibility help following both settings
- Real DOM keyboard events through production listeners, navigation mapping and automatic camera updates; no manual key sets or stepping
- Rotation/Flip/Ctrl combinations, Delete and fixed Q/A aliases, directional output and release stopping
- Actual UI Restart Level scene replacement and current preferences
- Native/modern display captures and backward navigation
- localStorage write failure: explicit notice, session values and actual new-scene attachment

No framework bootstrap, deployed site, remote certificate, native full-frame parity, hardware performance, game balance, mission completion, or AI claim follows from this fixture. Observation aliases use the existing `scripts/browser-game.mjs` React-ref discovery and never supply a fake scene.

## Evidence inventory

Attempt 1: `home-browser-580df36b-attempt1/receipt.json`, failed at the post-introduction inputMask-clear wait after 20 seconds. Actual Home startup/reload and actual GameScene binding succeeded. No page errors; the failure is not a server or constructor failure. `unconditional-source-check.json` confirms all 1,105 production source/assets unchanged. Preserved runner and entry record the exact attempted scenario.

Attempt 2: `home-browser-580df36b-attempt2/receipt.json`, corrected diagnostic scenario with a 60-second ordinary readiness window, unconditional final source verification and failure snapshots. Consult its terminal status/check list rather than inferring a pass from this README. The source identity remains runtime commit `580df36b636bd0cb81c4dfa99ce97243736801d2` unless the receipt reports drift.

No comparable before-Game capture from base `04a84dab17c809d188e5a734e99d34addfc5a1d` is present in this packet. Prior Sound/result images must not be relabeled as Game before evidence.

## Terminal result of corrected attempt 2

Five groups passed: startup/inert rows/repeated control identity; full page preference reload; actual initial Mission 1 GameScene attachment; live in-game identity/freeze/help; and 20 real DOM camera-key cases covering all four settings combinations. Chrome then crashed waiting for the new canvas after the ordinary Restart Level confirmation. Replacement continuity is blocked, not passed. Later 640x480 and storage-failure stages were not run. All 1,105 production source/asset fingerprints passed the unconditional final check; zero JavaScript page errors preceded the renderer crash. The failed attempt is retained and no unchanged retry was made.

## Separate bounded startup and replacement episodes

`startup-browser-580df36b/receipt.json` passed the startup-only 640×480 episode. It records exact row center x=320 and top y=139/169/199/229/259, three inert unsupported rows, all controls fitting the viewport, and a visible storage-failure notice without overlap. On denied preference writes, production choices survived category/back/reentry within the session; full reload returned the unsaved choices to browser defaults. This episode did not start a game or establish storage-failure attachment to a new scene. Both screenshots are from actual Home: `frontend-game-640x480.png` for normally persisted Control Cursor/Yes, and `frontend-game-storage-failure-640x480.png` for the failure notice.

`replacement-browser-580df36b/receipt.json` preserves the separate fresh, focused replacement episode. Ordinary first Mission 1 and Skip UI succeeded, and nondefault in-game choices preserved actual scene/world identity. After the ordinary Restart Level confirmation, Chrome again crashed while awaiting the replacement canvas. No replacement preference/key assertion passed. This episode used WeakMap IDs/WeakRefs and removed only observation aliases, avoiding instrumented strong retention of the prior scene; that does not establish the cause of either crash. No further restart retry was made.

`verification-summary.json` collects all four episodes, their checks and limits. Each episode retains exact runner/fixture/source hashes and successful or failed receipt, plus screenshots captured before riskier transitions. All 1,105 browser production input fingerprints remained unchanged. `source-equivalence-580df36b-d81ccc6f.json` independently verifies those same inputs against final candidate `d81ccc6f037a817f312956f7b227a4a92107a414`; the app/public git diff from browser-tested `580df36b636bd0cb81c4dfa99ce97243736801d2` is empty.

## Final test inventory audit

`inventory-audit.py` is a read-only independent auditor for the writer's final 432-file inventory. It checks canonical tracked coverage, no duplicates, exact ordered batch commands, clean tested/current source identity, manifest and dependency input fingerprints, raw stdout/stderr hashes, and the last unindented top-level test summaries. Missing or in-progress receipts remain pending. The terminal inventory report is compared to independently derived counts. It does not run tests, a build, or a browser. See the newest audit output for its status; this document does not predeclare that pending inventory a pass.
