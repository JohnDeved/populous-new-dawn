# Actual Home Game-options validation

## Reusable local route

`prepare-home-fixture.py` writes a separate plain React entry importing the unchanged production `app/page.tsx` and `app/globals.css`. Its Vite config in `capture-home.mjs` uses only the React plugin, existing Tailwind PostCSS handling, and production `public/` assets. It excludes Vinext/Cloudflare/RSC server startup and hydration. It does not replace the Page owner, scene, store, input listeners, preference functions, or game modules.

Prepare with the actual repository's existing dependencies and verified git wrapper on PATH:

```
python3 prepare-home-fixture.py --game-root ABSOLUTE_REPO --fixture-root FRESH_FIXTURE
```

Set these environment variables for the capture runner:

- POPULOUS_GAME_ROOT: repository
- POPULOUS_FIXTURE_ROOT: prepared fixture directory
- POPULOUS_OPTIONS_OUTPUT: fresh evidence directory
- POPULOUS_OPTIONS_PORT: an available allowed local port, default 4183
- POPULOUS_BROWSER: installed official Chrome Headless Shell
- NODE_OPTIONS=--max-old-space-size=512

Run `node capture-home.mjs` only after coordinating the heavy lane. The runner uses the browser sandbox and no unsafe renderer or certificate flags. It preserves receipts, explicit production source/asset fingerprints, post-introduction diagnostic state/screenshots, and failures. A 240-second wall-time bound closes only this invocation's browser/server; individual native input-readiness windows are 60 seconds, matching the existing lifecycle check. It never directly unlocks or mutates the world to establish readiness. Ordinary Skip/Resume/Continue UI actions may be used.

`game-preferences-navigation.test.mjs` is the focused Node integration test, now copied into the writer's checkout. It imports the real camera helpers and extracts the actual key map and navigation caller using TypeScript AST. Controlled scene/document data are explicit for these unit/caller tests. These are not the browser witness; the separate actual-Home runner provides actual constructor/listener/UI/frame evidence.

## Scope of the browser witness

- Production startup and in-game Options rendering/labels, inert unsupported rows, focused repeated Enter/Space and mouse choices
- Browser preference persistence/reload and actual newly constructed scene attachment
- Scene/world identity and exact paused modal state preservation during setting changes
- Compatibility help following both settings
- Real DOM keyboard events through production listeners, navigation mapping and automatic camera updates; no manual key sets or stepping
- Rotation/Flip/Ctrl combinations, Delete and fixed Q/A aliases, directional output and release stopping
- Actual UI Restart Level scene replacement and current preferences
- Native/modern display captures and backward navigation
- localStorage write failure: explicit notice, session values and actual new-scene attachment

No framework bootstrap, deployed site, remote certificate, native full-frame parity, hardware performance, game balance, mission completion, or AI claim follows from this fixture. Observation aliases use the existing `scripts/browser-game.mjs` React-ref discovery and never supply a fake scene.

## Evidence inventory

Attempt 1: `home-browser-580df36b-attempt1/receipt.json`, failed at the post-introduction inputMask-clear wait after 20 seconds. Actual Home startup/reload and actual GameScene binding succeeded. No page errors; the failure is not a server or constructor failure. `unconditional-source-check.json` confirms all 1,105 production source/assets unchanged. Preserved runner and entry record the exact attempted scenario.

Attempt 2: `home-browser-580df36b-attempt2/receipt.json`, corrected diagnostic scenario with a 60-second ordinary readiness window, unconditional final source verification and failure snapshots. Consult its terminal status/check list rather than inferring a pass from this README. The source identity remains runtime commit `580df36b636bd0cb81c4dfa99ce97243736801d2` unless the receipt reports drift.

No comparable before-Game capture from base `04a84dab17c809d188e5a734e99d34addfc5a1d` is present in this packet. Prior Sound/result images must not be relabeled as Game before evidence.
