import assert from 'node:assert/strict'
import {createServer} from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/postcss'
import {chromium} from '@playwright/test'
import {mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
const repo=resolve(process.env.POPULOUS_GAME_ROOT??process.cwd()),root=resolve(process.env.POPULOUS_FIXTURE_ROOT),output=resolve(process.env.POPULOUS_OPTIONS_OUTPUT)
const port=Number(process.env.POPULOUS_OPTIONS_PORT??4183),browserPath=process.env.POPULOUS_BROWSER
if(!browserPath)throw Error('POPULOUS_BROWSER must identify installed official Chrome Headless Shell')
if(!Number.isInteger(port)||port<1024||port>65535||[4190,6000,6666,10080].includes(port))throw Error('Use an allowed unprivileged port')
if(existsSync(resolve(output,'receipt.json')))throw Error('Use a fresh output directory')
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex'),source=JSON.parse(readFileSync(resolve(root,'source.json'),'utf8'))
const receipt={status:'running',startedAt:new Date().toISOString(),command:{repo,root,output,port,browserPath,node:process.version},source,scenarioSha256:hash(import.meta.filename),fixtureSha256:hash(resolve(root,'main.tsx')),checks:[],captures:[],errors:[],limits:source.limits}
mkdirSync(output,{recursive:true})
const save=()=>writeFileSync(resolve(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n')
const stage=name=>{receipt.stage=name;save()}
let server,browser,page,context,timer
const button=name=>page.getByRole('button',{name,exact:true}),options=()=>page.locator('[data-original-options]')
const rotation=()=>page.getByRole('button',{name:/^Rotation : </}),flip=()=>page.getByRole('button',{name:/^Flip Rotation : </})
const readPrefs=()=>page.evaluate(()=>window.testSceneRef?.current?.gamePreferences)
const settle=()=>page.evaluate(()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done))))
async function check(name,fn){stage(name);const details=await fn();receipt.checks.push({name,status:'passed',details});save()}
async function capture(name){await page.screenshot({path:resolve(output,name+'.png')});receipt.captures.push({name:name+'.png',viewport:await page.evaluate(()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio})),skin:await options().getAttribute('data-skin')});save()}
async function label(control){return control().getAttribute('aria-label')}
async function setPrefs(rotationName,reversed){if(!(await label(rotation)).includes(`<${rotationName}>`))await rotation().click();if(!(await label(flip)).includes(`<${reversed?'Yes':'No'}>`))await flip().click()}
async function menuOptions(){await button('Game settings').click();await button('Options').click();await options().waitFor();assert.equal(await options().getAttribute('data-category'),'Game')}
async function continueFromOptions(){await button('Back').click();await button('Continue Game').click();await page.locator('dialog[open]').waitFor({state:'hidden'});await page.locator('canvas.battlefield').focus();await page.mouse.move(700,400);await settle()}
async function diagnostic(name){const state=await page.evaluate(()=>{const s=window.testSceneRef?.current,w=s?.world;return {url:location.href,hidden:document.hidden,focus:document.hasFocus(),active:document.activeElement?.outerHTML?.slice(0,300),openDialogs:[...document.querySelectorAll('dialog[open]')].map(x=>x.getAttribute('aria-label')),scene:!!s,connected:!!s?.renderer.domElement.isConnected,started:s?.started,disposed:s?.disposed,modalSuspended:s?.modalSuspended,preferences:s?.gamePreferences,world:w&&{turn:w.turn,time:w.time,paused:w.paused,inputMask:w.inputMask,flyby:structuredClone(w.flyby),levelStart:structuredClone(w.levelStart),status:w.status},body:document.body.innerText.slice(0,3000)}});writeFileSync(resolve(output,name+'.json'),JSON.stringify(state,null,2)+'\n');await page.screenshot({path:resolve(output,name+'.png')});return state}
async function readyForInput(label){await diagnostic(label+'-post-skip');const guard=page.getByRole('button',{name:/^Continue anyway/});if(await guard.isVisible())await guard.click();if(await button('Resume game').isVisible()){await button('Resume game').click();await diagnostic(label+'-ordinary-resume')}try{await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask,null,{timeout:60000})}catch(e){await diagnostic(label+'-readiness-timeout');throw e}}
async function snapshot(){return page.evaluate(async()=>{const s=window.testSceneRef.current,w=s.world,digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(w)));return {worldHash:[...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,'0')).join(''),camera:{...s.cameraPosition},frame:s.gameClock.animationFrame,animationTime:s.gameClock.animationTime,modal:s.modalSuspended,paused:w.paused,connected:s.renderer.domElement.isConnected}})}
async function expectRealKey(keys,expected){
 await page.locator('canvas.battlefield').focus();await page.mouse.move(700,400)
 const before=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition}))
 try{
  for(const key of keys)await page.keyboard.down(key)
  await page.waitForFunction(expected=>window.testSceneRef.current.navigationButtons()===expected,expected,{timeout:5000})
  await page.waitForFunction(before=>{const a=window.testSceneRef.current.cameraPosition;return a.x!==before.x||a.y!==before.y||a.angle!==before.angle},before,{timeout:5000})
 }finally{for(const key of [...keys].reverse())await page.keyboard.up(key)}
 await page.waitForFunction(()=>window.testSceneRef.current.navigationButtons()===0)
 const after=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition})),delta=((after.angle-before.angle+1024)&2047)-1024
 if(expected&48){assert.notEqual(delta,0);assert.equal(Math.sign(delta),expected&32?1:-1);assert.equal(after.x,before.x);assert.equal(after.y,before.y)}else{assert.equal(delta,0);assert.ok(after.x!==before.x||after.y!==before.y)}
 const still=await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition}));await page.waitForTimeout(100);assert.deepEqual(await page.evaluate(()=>({...window.testSceneRef.current.cameraPosition})),still,'released real keys must stop movement')
 return {keys,expected,before,after,delta}
}
try{
 save();stage('create-plain-react-vite')
 server=await createServer({configFile:false,root,publicDir:resolve(repo,'public'),cacheDir:resolve(root,'.vite'),plugins:[react()],css:{postcss:{plugins:[tailwindcss({base:root})]}},server:{host:'127.0.0.1',port,strictPort:true,fs:{allow:[root,repo]}},logLevel:'warn'})
 await server.listen();stage('launch-sandboxed-browser')
 browser=await chromium.launch({executablePath:resolve(browserPath),headless:true,chromiumSandbox:true,ignoreDefaultArgs:true,args:['--remote-debugging-pipe'],timeout:30000})
 receipt.browser=browser.version();context=await browser.newContext({viewport:{width:1280,height:960}});page=await context.newPage()
 page.setDefaultTimeout(20000);page.on('pageerror',error=>receipt.errors.push(String(error)));page.on('crash',()=>{receipt.errors.push('Page crashed');save()})
 timer=setTimeout(()=>{receipt.timedOut=true;void browser.close()},240000)
 stage('open-actual-home');await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded',timeout:45000});await button('Options').waitFor()
 await check('actual Home startup Game rows, unsupported rows inert, repeated pointer/keyboard focus identity',async()=>{
  await button('Options').click();await options().waitFor();assert.equal(await options().getAttribute('data-category'),'Game')
  assert.equal(await label(rotation),'Rotation : <Cursor>');assert.equal(await label(flip),'Flip Rotation : <No>')
  for(const name of ['Tooltips','Stay Selected','Autocast Spell'])assert.equal(await page.getByRole('button',{name:new RegExp('^'+name)}).count(),0)
  await options().and(page.locator('[data-art-ready="true"]')).waitFor()
  await rotation().focus();await rotation().evaluate(e=>window.rotationNode=e)
  for(const key of ['Enter','Space','Enter','Space']){await page.keyboard.press(key);assert.equal(await rotation().evaluate(e=>e===document.activeElement&&e===window.rotationNode),true)}
  await flip().focus();await flip().evaluate(e=>window.flipNode=e)
  for(const key of ['Space','Enter','Space','Enter']){await page.keyboard.press(key);assert.equal(await flip().evaluate(e=>e===document.activeElement&&e===window.flipNode),true)}
  await setPrefs('Control Cursor',true);await capture('frontend-game-1280x960')
  const stored=await page.evaluate(()=>JSON.parse(localStorage.getItem('populous-game-preferences')));assert.deepEqual(stored,{version:1,rotation:'control-cursor',flipRotation:true})
  await button('Sound').click();await button('Game').click();assert.equal(await label(rotation),'Rotation : <Control Cursor>');assert.equal(await label(flip),'Flip Rotation : <Yes>')
  await page.keyboard.press('Escape');assert.equal(await button('Options').evaluate(e=>e===document.activeElement),true)
  return {stored,stableControlIdentity:true,unavailableControls:3}
 })
 await check('full-page reload restores production preference owner before scene creation',async()=>{
  await page.reload({waitUntil:'domcontentloaded'});await button('Options').click();assert.equal(await label(rotation),'Rotation : <Control Cursor>');assert.equal(await label(flip),'Flip Rotation : <Yes>');await button('Back').click();return {restored:true}
 })
 const {bindGame}=await import(pathToFileURL(resolve(repo,'scripts/browser-game.mjs')).href)
 await check('ordinary Mission1 launch creates and attaches real GameScene with startup preferences',async()=>{
  await button('New Game').click();await button('Start Mission 1').click();await bindGame(page)
  await page.waitForFunction(()=>window.testSceneRef.current.world.flyby.flags&1||!window.testSceneRef.current.world.inputMask)
  const skip=page.locator('.skip-introduction');if(await skip.isVisible())await skip.click()
  await readyForInput('first-scene')
  const small=page.getByRole('button',{name:/^Continue anyway/});if(await small.isVisible())await small.click()
  if(await button('Pause game').isVisible())await button('Pause game').click()
  assert.deepEqual(await readPrefs(),{rotation:'control-cursor',flipRotation:true})
  await page.evaluate(()=>{window.initialScene=window.testSceneRef.current;window.initialWorld=window.testStore.getWorld()})
  receipt.renderer=await page.evaluate(()=>{const g=window.testSceneRef.current.renderer.getContext(),d=g.getExtension('WEBGL_debug_renderer_info');return{renderer:d?g.getParameter(d.UNMASKED_RENDERER_WEBGL):g.getParameter(g.RENDERER),version:g.getParameter(g.VERSION)}})
  return {preferences:await readPrefs(),connected:await page.locator('canvas.battlefield').count()===1}
 })
 await check('in-game actual Options toggles keep real scene/world identities and modal freeze; help follows mapping',async()=>{
  await menuOptions();const before=await snapshot();assert.equal(before.modal,true)
  await setPrefs('Cursor',false);await setPrefs('Control Cursor',true);await page.waitForTimeout(120);assert.deepEqual(await snapshot(),before)
  assert.equal(await page.evaluate(()=>window.testSceneRef.current===window.initialScene&&window.testStore.getWorld()===window.initialWorld),true)
  await button('Browser compatibility and help').click();const help=await page.locator('[aria-label="Browser compatibility and help"]').innerText();assert.match(help,/Pan left \/ right/);assert.match(help,/Keyboard turn direction is reversed/)
  await page.keyboard.press('Escape');assert.equal(await options().getAttribute('data-category'),'Game')
  await capture('ingame-game-1280x960');return {preserved:true,freeze:before,help}
 })
 await check('actual production keyboard listeners and camera movement honor all Rotation/Flip/Ctrl combinations',async()=>{
  const results=[]
  for(const rotationName of ['Cursor','Control Cursor'])for(const reversed of [false,true]){
   await setPrefs(rotationName,reversed);await continueFromOptions()
   const swapped=rotationName==='Control Cursor'
   results.push(await expectRealKey(['ArrowLeft'],swapped?4:reversed?32:16))
   results.push(await expectRealKey(['Control','ArrowLeft'],swapped?(reversed?32:16):4))
   results.push(await expectRealKey(['Delete'],swapped?(reversed?32:16):4))
   results.push(await expectRealKey(['q'],reversed?32:16))
   results.push(await expectRealKey(['a'],4))
   await menuOptions()
  }
  assert.equal(await page.evaluate(()=>window.testSceneRef.current===window.initialScene),true)
  return {realDomKeyCases:results,scenePreserved:true}
 })
 await check('ordinary Restart Level builds a different real scene and attaches current settings',async()=>{
  await setPrefs('Control Cursor',true);await button('Back').click();await button('Restart Level').click();await button('Yes').click();await bindGame(page)
  await page.waitForFunction(()=>window.testSceneRef.current!==window.initialScene)
  assert.deepEqual(await readPrefs(),{rotation:'control-cursor',flipRotation:true})
  assert.equal(await page.evaluate(()=>window.initialScene.disposed),true)
  await page.waitForFunction(()=>window.testSceneRef.current.world.flyby.flags&1||!window.testSceneRef.current.world.inputMask)
  const skip=page.locator('.skip-introduction');if(await skip.isVisible())await skip.click();await readyForInput('replacement-scene')
  if(await button('Pause game').isVisible())await button('Pause game').click()
  const moved=await expectRealKey(['Control','ArrowLeft'],32);await menuOptions();return {replacement:true,preferences:await readPrefs(),moved}
 })
 await check('actual skin/native size layout and backward navigation retain preferences',async()=>{
  await page.setViewportSize({width:640,height:480});await settle();await capture('ingame-game-640x480')
  for(const b of [rotation(),flip()]){const box=await b.boundingBox();assert.ok(box.x>=0&&box.x+box.width<=640&&box.y>=0&&box.y+box.height<=480)}
  await page.setViewportSize({width:1280,height:960});await page.keyboard.press('Escape');assert.equal(await button('Options').evaluate(e=>e===document.activeElement),true)
  await button('Quit Game').click();await button('Yes').click();await button('Options').click();assert.equal(await label(rotation),'Rotation : <Control Cursor>');assert.equal(await label(flip),'Flip Rotation : <Yes>')
  await page.setViewportSize({width:640,height:480});await capture('frontend-game-640x480');return {sharedValues:true}
 })
 await check('production localStorage write failure keeps live session values and explicit notice',async()=>{
  await context.close();context=await browser.newContext({viewport:{width:1280,height:960}})
  await context.addInitScript(()=>{const write=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key==='populous-game-preferences')throw Error('fixture quota denied');return write.call(this,key,value)}})
  page=await context.newPage();page.setDefaultTimeout(20000);page.on('pageerror',e=>receipt.errors.push(String(e)))
  await page.goto(`http://127.0.0.1:${port}`,{waitUntil:'domcontentloaded'});await button('Options').click();await setPrefs('Control Cursor',true)
  await page.getByRole('status').filter({hasText:/session.*storage|storage.*session/i}).waitFor();const notice=await page.getByRole('status').filter({hasText:/session.*storage|storage.*session/i}).innerText()
  await button('Back').click();await button('New Game').click();await button('Start Mission 1').click();await bindGame(page);assert.deepEqual(await readPrefs(),{rotation:'control-cursor',flipRotation:true})
  return {notice,attachedSessionPreferences:await readPrefs(),saved:await page.evaluate(()=>localStorage.getItem('populous-game-preferences'))}
 })
 for(const [file,expected]of Object.entries(source.files))assert.equal(hash(resolve(repo,file)),expected,`Production source/asset changed: ${file}`)
 assert.deepEqual(receipt.errors,[])
 receipt.status='passed'
}catch(error){try{if(page&&!page.isClosed())await diagnostic('failure-state')}catch(diagnosticError){receipt.diagnosticFailure=String(diagnosticError)}receipt.status='failed';receipt.failure=String(error);receipt.stack=error.stack;receipt.checks.push({name:receipt.stage,status:'failed',error:String(error)});process.exitCode=1}
finally{const mismatches=[];for(const [file,expected]of Object.entries(source.files)){try{const actual=hash(resolve(repo,file));if(actual!==expected)mismatches.push({file,expected,actual})}catch(e){mismatches.push({file,error:String(e)})}}receipt.sourceVerification={checkedAt:new Date().toISOString(),fileCount:Object.keys(source.files).length,status:mismatches.length?'failed':'passed',mismatches};if(mismatches.length){receipt.status='failed';process.exitCode=1}clearTimeout(timer);await browser?.close();await server?.close();receipt.finishedAt=new Date().toISOString();save();console.log(JSON.stringify({status:receipt.status,checks:receipt.checks.map(({name,status})=>({name,status})),failure:receipt.failure,receipt:resolve(output,'receipt.json')},null,2))}
