from pathlib import Path
import datetime,hashlib,json,re,subprocess
root=Path('/tmp/populous-selector-scene-457');head='d81ccc6f037a817f312956f7b227a4a92107a414';folder=root/'work/orchestration/game-options457'/head[:8]
manifest=Path('/tmp/game-options-checks/test-inventory-'+head+'.json');plan=json.loads(manifest.read_text());original=folder/'inventory-28.json';repeat=folder/'inventory-28-diagnostic1.json';a=json.loads(original.read_text());b=json.loads(repeat.read_text());errors=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(v,m):
 if not v:errors.append(m)
check(a['phase']=='finished' and a['status']=='failed' and a['exitCode']==1,'Original failed receipt not retained')
check(b['phase']=='finished' and b['status']=='passed' and b['exitCode']==0 and b['signal'] is None,'Diagnostic did not finish successfully')
check(a['command']==b['command']==['node','--test','--test-concurrency=1',*plan['batches'][27]],'Whole-batch command changed')
check(a['cwd']==b['cwd']==str(root),'Working directory changed')
check(a['source']['headOid']==b['source']['headOid']==head,'Tested HEAD changed')
check(a['source']==a['sourceAfter'] and b['source']==b['sourceAfter'],'Source/input fingerprint changed during run')
check(a['source']['trackedDiffSha256']==b['source']['trackedDiffSha256']==hashlib.sha256(b'').hexdigest(),'Tested source was not clean')
inputs={}
for f,want in b['source']['inputs'].items():
 p=Path(f) if Path(f).is_absolute() else root/f;actual=sha(p);inputs[f]={'expected':want,'actual':actual,'matches':actual==want};check(actual==want,'Diagnostic explicit input changed: '+f)
for f,want in plan['files'].items():check(sha(root/f)==want,'Inventory source changed: '+f)
counts={}
logs={}
for label,d in [('original',a),('diagnostic',b)]:
 logs[label]={}
 for stream in ['stdout','stderr']:
  p=Path(d['artifacts'][stream]);actual=sha(p);check(actual==d[stream+'Sha256'] and p.read_text()==d[stream],label+' '+stream+' mismatch');logs[label][stream]={'path':str(p),'sha256':actual}
 text=Path(d['artifacts']['stdout']).read_text();counts[label]={}
 for name in ['tests','pass','fail','cancelled','skipped','todo']:
  found=list(re.finditer(r'^(?:#|ℹ) '+name+r' (\d+)\s*$',text,re.M));check(bool(found),label+' missing final '+name)
  if found:counts[label][name]=int(found[-1][1])
check(counts.get('original')=={'tests':49,'pass':48,'fail':1,'cancelled':0,'skipped':0,'todo':0},'Original failure counts differ')
check(counts.get('diagnostic')=={'tests':49,'pass':49,'fail':0,'cancelled':0,'skipped':0,'todo':0},'Diagnostic counts differ')
git=lambda *args:subprocess.check_output(['/tmp/selector-scene457/git-bin/git',*args],cwd=root,text=True).strip()
check(git('rev-parse','HEAD')==head and not git('status','--porcelain'),'Current HEAD/status changed')
report={'kind':'independent-retained-batch28-diagnostic-audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'failed' if errors else 'passed','head':head,'scriptSha256':sha(__file__),'command':b['command'],'originalReceipt':{'path':str(original),'sha256':sha(original),'status':a['status']},'diagnosticReceipt':{'path':str(repeat),'sha256':sha(repeat),'status':b['status']},'manifestSha256':sha(manifest),'inputHashes':inputs,'rawLogs':logs,'counts':counts,'errors':errors,'interpretation':'Original full inventory remains 2,784 pass / 1 fail out of 2,785. The separate unchanged whole-batch diagnostic passed 49/49; all 432 files have passing execution coverage across original plus diagnostic. No repair substitution or all-green original run is claimed.'}
out=Path('/tmp/game-options-checks/inventory-28-diagnostic-audit-d81ccc6f.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','counts','errors','interpretation']},indent=2))
