import {readFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const expected='d81ccc6f037a817f312956f7b227a4a92107a414'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
if(git('rev-parse','HEAD')!==expected||git('status','--porcelain'))throw Error('Source drift')
const original='work/orchestration/game-options457/d81ccc6f/inventory-28.json'
const receipt=JSON.parse(readFileSync(`${root}/${original}`,'utf8'))
if(receipt.source.headOid!==expected||receipt.status!=='failed')throw Error('Unexpected original result')
const result=runCommandReceipt(root,{
 output:'work/orchestration/game-options457/d81ccc6f/inventory-28-diagnostic1.json',
 command:receipt.command,
 inputs:[original,'/tmp/game-options-checks/run-batch28-diagnostic.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json'],
})
console.log(JSON.stringify({status:result.status,exitCode:result.exitCode,originalInventoryStatus:'failed',scope:'one separately authorized whole-batch diagnostic rerun; no source or assertion changes'}))
process.exitCode=result.status==='passed'?0:1
