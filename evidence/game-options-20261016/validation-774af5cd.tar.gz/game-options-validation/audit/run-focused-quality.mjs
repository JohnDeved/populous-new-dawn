import {execFileSync} from 'node:child_process'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const expected='774af5cd968935603f61bfed3ab5ec750e25eac6'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
if(git('rev-parse','HEAD')!==expected||git('status','--porcelain'))throw Error('Source drift')
const files=['app/game-preferences.ts','app/original-options.tsx','app/page.tsx','app/scene-input-runtime.ts','app/scene.ts']
for(const [name,command]of [
 ['affected-tests',['node','--test','--test-concurrency=1','tests/game-preferences.test.mjs','tests/game-preferences-navigation.test.mjs','tests/original-options.test.mjs','tests/audio-preferences.test.mjs','tests/pause-menu-ownership.test.mjs','tests/orchestration.test.mjs']],
 ['focused-format',['node_modules/.bin/oxfmt','--check',...files]],
 ['focused-lint',['node_modules/.bin/eslint',...files]],
 ['new-module-lint',['node_modules/.bin/eslint','app/game-preferences.ts','app/original-options.tsx']],
]){
 const result=runCommandReceipt(root,{output:`work/orchestration/game-options457/774af5cd/${name}.json`,command,inputs:['/tmp/game-options-checks/run-focused-quality.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 console.log(`${name}: ${result.status}, exit ${result.exitCode}`)
 if(result.status!=='passed')process.exitCode=1
}
