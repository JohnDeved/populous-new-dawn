# Original evidence archive for PR 203

This is a bounded selection of original, unredacted technical evidence bytes.
It is separate from the published portable bundle, which contains 19 selected
path-redacted receipts and a source patch. Existing receipt commands, source
labels, timestamps, stdout/stderr and local workspace paths remain unchanged.

The archive retains final and failed command receipts with both raw streams;
final and earlier independent technical reviews; complete passing and failed
browser receipt/report JSON; screenshots; and the original-search correction
history. Passed receipts at331f162 and the first Swamp extension are superseded
for search-dependent claims. The intact-table failed old-three-hit assertion
and corrected two-hit guarded matrix are preserved. Final review is authoritative
for acceptance and explicitly retains five new cycle diagnostics, the26+6 test
count correction, and the exact32e511b/7b96393/8fe6631 source correspondence.

The indexed native research note is copied exactly from the tested feature and
predates final rendered acceptance; final review and browser receipts record the
subsequent outcome. Some early exploratory logs lack a frozen-source receipt and
remain historical diagnostic records, not substitutes for the guarded proof.

Only files enumerated in INVENTORY.json are included under originals/. No game
executables/data, tool binaries, dependencies, caches, browser profiles, auth files,
environment files or unrelated material are included. PNG files are game-test
screenshots. Exact per-file SHA-256 values permit byte verification after reset.
The second harness copy of the failed startup screenshot is omitted as redundant.
