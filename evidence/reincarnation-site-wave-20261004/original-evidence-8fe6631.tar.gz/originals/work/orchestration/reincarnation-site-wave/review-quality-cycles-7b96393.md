# ACCEPT: bounded quality repair and explicit cycle disposition

Reviewed clean `7b96393433ed3e23ce06c9116da1837e3f10e592` against32e511b and full
feature basef78e5c1. The only delta combines duplicate imports, separates site
initialization from its local binding, replaces copied reverse with `toReversed`,
and renames a shadowing callback parameter. Evaluation order and the dense unit
array's iteration order are preserved. Native and browser checker bytes are
unchanged. No modifying check, native/browser run, build or full-package job was
executed by reviewer.

## Five cycle findings are introduced participation, not unchanged baseline

Built a static value-import/re-export graph from the actual Git blobs using the
TypeScript parser. Type-only imports/exports are excluded; dynamic imports are
not initialization edges. Tarjan analysis finds the existing world/runtime SCC
has38 modules atf78e5c1 and40 at7b96393. The only added members are the two new
wave modules; no existing separate subsystem enters the SCC. Full membership and
the five shortest return paths are in `cycle-graph-7b96393.json`.

Exact paths (all names below are app modules):

- reincarnation-wave-runtime → live-people → model → world-turn → reincarnation-wave-runtime.
- reincarnation-wave-runtime → campaign-runtime → live-combat → combat-targets → computer-spells → spell-casting → live-people → model → world-turn → reincarnation-wave-runtime.
- reincarnation-wave-runtime → world-effects → campaign-runtime → live-combat → combat-targets → computer-spells → spell-casting → live-people → model → world-turn → reincarnation-wave-runtime.
- reincarnation-wave-runtime → site-wave-effects → world-effects → campaign-runtime → live-combat → combat-targets → computer-spells → spell-casting → live-people → model → world-turn → reincarnation-wave-runtime.
- site-wave-effects → world-effects → campaign-runtime → live-combat → combat-targets → computer-spells → spell-casting → live-people → model → world-initialization → level-start-runtime → site-wave-effects.

The four cycle-bearing runtime imports start at lines2,3,8,18 of the new runtime;
the site helper's cycle-bearing import starts at line2. In particular, the terrain
adapter and type-only `stepLevelStartWave` import do not add another value cycle.

## Initialization analysis and disposition

Both new modules contain only imports and function declarations at module scope.
Their cyclic imported bindings are read when the exported functions run, after
module initialization. The allocation default parameter is evaluated at function
invocation. There are no new top-level state allocations, cyclic constant reads,
module callbacks, registrations or other eager side effects. The incoming calls
from world-turn and level-start-runtime likewise occur inside runtime functions.

Four independent fresh Node processes imported reincarnation-wave-runtime,
site-wave-effects, world-turn and model first, respectively; each then imported
model, created Mission1 and completed its first tick. All passed. These small
probes support module initialization, not rendered gameplay or performance.

ACCEPT the five diagnosed cycles as bounded adapter participation in the existing
world composition graph. A broad facade/core refactor or callback-injection layer
would exceed this repair's benefit; removing only campaignPosition's cycle edge
would not remove the required live-person/effect integration cycles. Keep the
diagnostics visible. `lint:standard` is FAILED and these five findings cannot be
described as unchanged baseline findings or a clean lint pass.

## Receipt correspondence

Verified raw stdout/stderr hashes and stable source identities for prior
`final-32e511b/check.json` and `build.json` (both passed), plus exact7b96393
`quality-repair-focused.json` (26/26 wave/startup),
`quality-repair-person-panic.json` (separate6/6),
`quality-repair-typecheck.json` (passed) and `quality-repair-oxlint.json` (failed,
only the five cycle diagnostics). There is no single32-test final-head receipt;
the two successful test groups total32.

Final source-bound aggregate/build decisions and rendered acceptance remain under
the parent's resource coordination. This review does not certify full-game parity,
native pool exhaustion or hardware performance.

## Explicit evidence-carry disposition

ACCEPT CARRY of the passed32e511b full check/build receipts to7b96393 through this
reviewed complete two-file correspondence. Retain their original32e511b source
labels; do not relabel them as reruns on7b96393. No full check/build rerun is needed
for this delta. Current explicit input hashes still match those receipts.

Combined imports preserve runtime import edges and order after type erasure.
Separating `??=` preserves initialization-before-allocation and the same site
object on ordinary World arrays. `toReversed()` preserves the copied newest-first
iteration of the ordinary unit array and does not mutate it. The callback
parameter rename is local. There are no dependency, manifest, asset, native probe,
browser checker, routing or public API changes in32e511b..7b96393.

The exact final-head typecheck plus26 wave/startup and separate6 actual panic
tests cover the changed paths. Four fresh initialization probes also passed.
Remaining final native/rendered gates run on7b96393 under the parent's grant.
Five genuine new cycle findings stay disclosed and Oxlint stays failed; evidence
carry does not convert that quality result into a pass.
