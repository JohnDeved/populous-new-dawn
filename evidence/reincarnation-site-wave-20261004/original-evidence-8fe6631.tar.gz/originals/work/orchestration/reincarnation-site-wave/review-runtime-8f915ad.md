# Runtime source review: REJECT pending two repairs

Reviewed base `f78e5c17757ce061b8b159da150536ee690e6b6f` through head
`8f915ad5f4bba09a59b61b79fb32b3d36052e31a`, read-only. The initial tracked tree
was clean. The owner subsequently created an untracked browser checker; it is
outside this review. No native/browser/build/full-package job was run by reviewer.

## P1: boarded targets throw instead of receiving the wave

New call site: `app/reincarnation-wave-runtime.ts:90`.
`initializeLivePanic` initializes state26, whose deselection reaches
`app/person-state.ts:231`; `app/live-people.ts:501` supplies `unexpected` for
`deselectPassengers`. Any eligible live person with a nonzero vehicle therefore
throws `Legacy handoff contains an unowned native assignment`, after changing the
person to state26 and before damage or wave completion.

Read-only Node reproduction used Mission22's authored Boat and Balloon separately,
created a Spy at the vehicle, and used shipped `command` plus ordinary `tick` to
board. A staged opposing wave in the passenger's cell throws for both model1
(vehicle95) and model3 (vehicle1). This is a live boarding/consumer reproduction,
not a natural-wave travel claim. Original `00445750.c` shows passenger selection
flags propagating through the active vehicle; it does not eject those passengers.

Repair the actual deselection consumer without adding Swarm-specific filters or
ejection. Cover both vehicle models, other seated passengers, retained attachment,
damage, and continuation through subsequent ordinary turns.

## P2: entry-owner handoff discards the live command queue

New call site: `app/reincarnation-wave-runtime.ts:90`.
The active entry person is correctly obtained by `syncLivePersonCells`, but
`app/live-people.ts:571` invokes `cancelBuildingEntry`, which calls
`clearPersonOrders` at `app/live-building-entry.ts:436`. The wave therefore drops
the live person's building-entry orders and their pool references.

Read-only Node reproduction used a flat `createWorldState(1)`, a completed Blue
Hut, a Blue Brave, and shipped `command(hut)` plus `tick` to entry substate5. Before
the staged enemy wave: queue `[1,0,0,0,0,0,0,0]`, active orders1, state10, outside.
After: the same person is adopted as `u.native`, state26, but queue is all zeros
and active orders0. Original `0050c840.c` calls `004ed6f0` (indexed no-op) followed
by `004d2740` state26; `004a3940` clears work flags/target, not the queue. The
state initializer does not establish this queue deletion.

Use an ownership transfer for this mode2 path that retires the entry wrapper and
route as needed while preserving the actual person's commands and references.
Regress panic expiry and resumption, not just immediate state26 adoption.

## Reviewed portions without a further source finding

- Producer remains a one-shot remaining6 event and runs after the snapshotted,
  newest-first effect traversal. The first wave visit is next turn; successful
  model12 spawn does not own wave lifetime.
- Height uses current-ground raise followed by existing nearest64/ties-down clamp
  to64..1024. Saved site, tribe/mode/id, radii, visit and orbit state are retained
  as checkpoint data. Busy allocation consumes identity and preserves old wave.
- Eligibility and descriptor damage match the corrected native target matrix;
  protected transitions retain repeated endpoints, damage, and unchanged panic
  RNG. Shield/Bloodlust/global suppression reuse the correct damage consumer.
- Visited-cell Swamps are marked expired and skipped later in the same traversal;
  startup mode1's existing omission remains explicit.
- Shared visual/terrain extraction preserves the prior startup consumer and
  geometry operations. Scene guards make only the controller group empty.
- The encounter test uses a real nonempty command queue and actual owner; it
  meaningfully checks adoption and wrapper cleanup, but misses the two boundaries
  above.

## Evidence and remaining gates

Reused exact-head `focused-8f915ad.json` (24/24, including14 startup regressions)
and `format-focused-8f915ad.json` (all8 changed TypeScript files). Read
`check-plan-8f915ad.json`, the full feature diff, relevant callers/indexed originals,
repository instructions and TypeScript workflow. New helpers are narrow and shared
instead of duplicating startup geometry; no additional readability defect found.
Source-bound full `format:check`, `lint`, `lint:standard` and advisory Fallow
evidence still need final coordination; legacy Oxlint findings must be separated
from introduced findings.

Corrected independently accepted native contract is3b947c1, with intact mapped
search and244 constants guarded at each boundary. Superseded three-hit evidence
is not used. Standard full check/build and final rendered natural-death, successful
spawn, intruder/Swamp, fresh-page checkpoint and viewport evidence remain pending.
No full-game, original-renderer, whole-pool exhaustion or hardware-performance
claim is made; issue30 remains open.
