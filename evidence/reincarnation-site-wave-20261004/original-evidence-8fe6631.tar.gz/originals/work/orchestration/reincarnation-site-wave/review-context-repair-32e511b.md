# ACCEPT: context expectation repair

Reviewed clean head `32e511ba86b7611843164ac4b9b43a115125682d` against07ec3a1.
The sole changed line adds the three already-reviewed reincarnation-wave check IDs
to the exact expected Shaman-context list. It matches the actual11-item routing
manifest; it does not change routing or remove acceptance.

The24KB budget, terrain-check exclusion, full evidence visibility and projected
purpose/limits/commands/prerequisites/side-effects/resources assertions remain
unchanged. `context-repair-frozen.json` passes all27 tests in the whole orchestration
test file; verified its raw stdout/stderr hashes and stable exact source identity.
Inspected the preserved07ec3a1 aggregate failure: actual11 versus stale expected8
is the failed assertion. That prior aggregate remains failed, not a full pass.

No app, checker or native delta; earlier source and checker preflight applies.
No heavy, native or browser job was run by reviewer. Final aggregate/build/quality
and terminal rendered evidence remain pending under parent lane coordination.
