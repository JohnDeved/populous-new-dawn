# Final ACCEPT: bounded ordinary reincarnation site wave

Accepted exact head: `8fe6631979f81dd462c6fa10468fca98d3b82361`.
Tree: `a60fe2581dcdf476aee2c6addaa18c3f6e790959`.
Repository was clean. This final review incorporates the full feature/source and
repair reviews already retained in this directory; it does not broaden issue30
or record parity. No new native, browser, full-check, build or source-edit job was
performed by reviewer.

## Terminal rendered evidence independently inspected

Read the exact checker, command receipt, terminal harness receipt, report and
cleanup receipt. Verified the harness result equals the standalone report, source
and sourceAfter are identical, current Git commit/tree match, and explicit checker,
harness and browser binary input hashes match actual files. The harness completed
in41.520 seconds with exit0, sandboxed Chrome Headless Shell154.0.8037.92,
`--remote-debugging-pipe` only, and no page/console errors. The subsequent retained
cleanup receipt verifies port4193 ECONNREFUSED and unchanged source.

Observed outcomes:

- Startup begins turn0/inputMask128 with a nonselectable command18 Shaman. Six
  batches produce samples11,23,35,47,59,71; the visible Skip control is clicked at
  turn71, followed by actual ready=true/inputMask0/selectable state19/phase4.
  No readiness flag or native field is injected.
- The shipped Mission2 selection and ordinary attack consumer drive actual combat
  damage/death: old Shaman54 begins with100HP atturn71, has injury and41 fighting
  observations, and dies atturn349. Body1268 has467remaining. Combat is advanced
  with ordinary fixed turns; this is not pointer-picking or uninterrupted manual
  gameplay evidence.
- Atturn810 remaining6, then turn811 allocation1276: remaining5, mode2/tribe0,
  visits0/orbits0, saved center40192/23808/128, busy1 and one new sound158 serial51.
  Turn812 is the first visit with32orbits. Turn815 hasvisit4 and13,074 independently
  toggled framebuffer pixels contributed by orbit groups; the controller is empty.
- The fresh-page load retains turn815, RNG3483598134, nextId1437, site heights,
  tribe flags, seven light owners, wave identity/geometry/orbits and terrain. Restored
  orbit groups contribute13,086 pixels. This is same-browser fresh-page persistence,
  not cross-process/profile restart proof.
- Atturn816 a new live Shaman1469 exists and remaining is0 while the same wave
  remains atvisit5. Sixteen further turns finish the21-visit wave; after six cleanup
  turns, wave/orbit effects, orbit meshes, owned lights and busy bit are absent.
- Only afterward, a separately labeled staged fixture checks enemy Brave50→25HP
  and state26, protected Brave50→0HP with state17 retained, and unchanged friendly,
  Wildman and Shaman HP. It uses directly supplied targets and a wave, so it is not
  natural enemy-travel acceptance.
- The staged in-cell Swamp contributes2,283 pixels before removal. After the wave
  and one ordinary turn it has no effect/mesh and retains remaining32000/counter3,
  proving its later processor was skipped. The outside Swamp and mesh remain and
  its lifetime decrements to31999. Mode1 startup's pre-existing Swamp omission is
  deliberately outside this repair.

Viewed all nine actual PNGs: before, during, checkpoint, respawn, intrusion,
Swamp before/after,1024×768 and1920×1080. The wave is visible, restoration retains
the ring, respawn is visible, the outside Swamp remains, and neither resize shows
a blocking layout/rendering defect in the captured scene. These are temporal
candidate frames, not old-code versus new-code or original versus port comparisons.
No f78e5c1 baseline render was run. Warnings for texture update without image data,
software WebGL fallback and ReadPixels stalls remain in the receipt; no hardware
performance or exact original raster claim is supported.

## Source/evidence correspondence and quality disposition

Reconfirmed ACCEPT CARRY of original-labeled32e511b full check/build through the
complete reviewed two-file style delta to7b96393; the only later8fe6631 delta is
the independently reviewed startup checker repair. Final7b typecheck and26 actual
wave/startup tests plus a separately verified6 person-panic tests pass. The first
26-case command contains the nonexistent `panic.test.mjs` argument; its original
receipt remains intact and is never represented as32 tests.

Final7b native level-start and model12 reincarnation receipts pass. The composed
mode2 wave/panic/damage/passenger proof retains its actuald0e4510 source label and
unchanged script/input hashes: 17 target cases,18 Swamp cases and6 passenger cases,
with full mapped search and244 constants guarded at every setup/native boundary.
The protected centered target receives exactly two hits, not the invalidated old
three-hit claim. Supplied leaves and unsuccessful native spawn stub remain disclosed;
the successful spawn here is the live browser acceptance.

Root formatting and ESLint remain failed, not silently converted to clean gates.
Independently verified the two root format-failing files are byte-identical to
accepted main; all213 changed-path ESLint diagnostics match acceptedb381851 by
path/rule/message/severity/exact affected source text. Changed-file format passes.
Fallow health/duplication completed with advisory results; unused-code advisory
returns1 and is retained. No unsupported deletion was made.

Oxlint remains failed with five genuine new import-cycle diagnostics in the two
wave adapters. The explicit accepted disposition is bounded participation in the
existing world/runtime SCC:38→40 members, only these two added; no eager cyclic
reads/allocations/callbacks in either module, and four fresh import orders complete
world creation and first tick. These findings are not described as unchanged
baseline debt or a clean lint pass.

Failures remain preserved: corrupt-search early native receipts stay superseded;
the intact old-three-hit expectation failure remains invalidated by corrected
evidence;6293323 failed typecheck before tests;07ec3a1 failed the stale context
expectation;7b96393 failed browser startup before combat and has its cleanup receipt;
root quality and advisory failures remain honestly labeled. Reviewed repairs and
the final terminal browser receipt establish this bounded result.

## Independently verified receipt hashes

All38 indexed files and the raw stdout/stderr of all27 indexed command receipts
were hash-verified against `gate-evidence-final-8fe6631.json`; source-before/after
identity and recorded statuses were also checked. Important SHA256 values:

- Evidence index: `2c78b093d17ceda866007755da315417629e8246a494c5178210dbbd327e3c6d`
- Browser command: `5ef5268b625dcad4bcec4b31774045d73039f8058a83047a9ac1fdda79fee782`
- Terminal browser receipt: `707859c04e62e13f762ab24f1d2ea6e1f6fa95a4fa26eae64cde9a395fecb631`
- Browser report: `150ea9418c07f8ce2abd4aa4c6a793bdf76c6883bddf299ef5b4f3440683981b`
- Browser cleanup: `ca5594dda287702e7e0e871ba4a3e871f3854b63e5fa75508970b2967c0a38e7`
- 32e511b full check: `17cfedeab31fbbd97bd916b5b06d013f6dbd3663ba1c733592da7569e991c846`
- 32e511b build: `aa3460baa8f73dcdd1e9ceff719640d4e83b89fac2dc8b6e1826f12214e77ff5`
- d0e4510 composed native wave: `01c0f88912fce0b1417903d26335b21d173311cdc69b9bb40839fcfe40af661f`
- 7b96393 native level-start: `fe1549b8115e00b4aa67daa1a9e300a0f37a5c035261f8a08574c453e01a8a65`
- 7b96393 native reincarnation: `c5df0d3fe357c27c283923f9f697c50b97c97503eade04bf711cba7be5302670`
- Final checker: `b52cd9475e6fcc00e15d3e7c9cca0d6056e5ed8d7cb86c61ec4efed589d1d314`

Final verdict is ACCEPT for this bounded feature at the exact head above. Issue30
remains open; whole native pool exhaustion, full-game parity, exact native raster,
pointer picking, cross-process persistence and hardware performance are not claimed.
