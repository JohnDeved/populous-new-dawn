# Startup checker repair proposal: acceptable

Inspected clean7b96393 checker source and preserved
`final-7b96393/browser/report.json` plus actual `failure.png`. The report fails
before combat at the fixed startup readiness assertion; the screenshot still
shows the ordinary Skip introduction control. The one-shot visibility check at
turn16 can precede its later UI/flyby activation.

Accept the proposed checker-only correction: advance bounded24-frame batches,
yield to React, click the visible Skip control, and use the existing
`readShamanReadiness(page)` observer which rebinds the current scene/store. Exit
only on actual `ready === true` for Mission2. Preserve initial/latest snapshots,
batch count and observed skip timing; fail bounded with the last exact state.
Check the harness abort signal each batch. No input-mask/person/native-field
mutation and no async Promise predicate inside Playwright waitForFunction.

This assesses the proposal, not yet-frozen code or a new browser result. Final
checker source preflight and a parent-granted terminal browser run remain needed.
The failed browser attempt stays preserved and failed. Unchanged app/native and
reviewed full-check/build correspondence are unaffected by a setup-only checker
repair. Reviewer used source reads and viewed the existing screenshot; no browser,
native or heavy job was started.
