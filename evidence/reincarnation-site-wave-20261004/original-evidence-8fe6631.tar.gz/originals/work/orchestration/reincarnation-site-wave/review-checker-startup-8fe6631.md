# ACCEPT: frozen startup-only checker repair

Reviewed clean `8fe6631979f81dd462c6fa10468fca98d3b82361` against7b96393.
The complete delta is confined to the browser checker startup block and its
import of the existing read-only readiness observer.

The loop advances at most80 batches of24 controlled scene frames, checks the
harness abort signal each batch, yields for React, and clicks only the visible
ordinary Skip introduction button. Each readiness read uses the established
rebinding observer; exit requires literal `ready === true`, and Mission2 is
asserted. Initial/sampled readiness, batch count and actual skip turns remain in
the report, including failure. There is no injected native state or input mask.
The pre-existing pacing freeze occurs only after true readiness.

`node --check scripts/check-browser-reincarnation-wave.mjs` passes. Verified
`checker-startup-preflight-8fe6631.json` passed ESLint status, exact source identity,
stable before/after fingerprint and raw stdout/stderr hashes.

ACCEPT browser source preflight. App/native/tests are unchanged, so prior native,
focused/type evidence and the explicitly reviewed32e511b→7b96393 full check/build
correspondence carry through this checker-only commit with original labels intact.
No aggregate/native repetition is required for this delta. The failed7b96393
browser attempt remains failed; a terminal rendered run using this checker is
still required under the parent's next resource grant. No browser/heavy job was
started by reviewer. Five reviewed new cycle findings remain disclosed.
