# Re-review of d0e4510

Head: `d0e4510cd6c5ff71f96d5c7ea4c2f9cb92f9a620`.
Full feature base remains `f78e5c17757ce061b8b159da150536ee690e6b6f`.
Reviewed complete repair delta from8f915ad, all added checks/mappings, native probe
extension and full new browser checker. Tracked tree was clean when reviewed.
No native, browser, build or full-package job was run by reviewer.

## Source preflight: ACCEPT; final gates pending

Both prior source blockers are resolved:

- State26 supplies the actual passenger deselection consumer. It follows active
  occupied vehicle slots, reuses `markPersonSelected(false)`, clears only bit128
  in selection/flags3, and retains seats, attachment and orders. The native probe
  extension actually executes00445750, seeds low selection bit4 and tests6
  Boat/Balloon active/count combinations under the existing intact-input guards.
- Mode2 requests entry-order preservation while retiring the entry wrapper.
  Other cancellation defaults are unchanged. At panic expiry `adoptLiveOrders`
  transfers the same person back to the correct controller. The added regression
  reaches ordinary Hut entry substate5, verifies identical person/queue/pool during
  panic, resumes the original entry and checks its command reference is released
  on completion. This closes the resource boundary beyond immediate state26.

No additional source finding in the repaired delta. Shared helper reuse and
explicit mode2 preservation are proportional; no unnecessary new machinery found.
Current accepted mainb381851 adds QA-only harness work; adopting it must preserve
the reviewed app/checker correspondence and precede final source-bound gates.

## Browser checker preflight: pending bounded repairs

`scripts/check-browser-reincarnation-wave.mjs` has a valid separation between the
natural Mission2 combat/death/respawn path and staged cell targets. Pacing and
camera are controlled; direct command consumer use is honestly distinguished
from pointer picking. Fresh-page checkpoint, independent post-spawn lifetime,
orbit pixel contribution, empty controller and resize checks are present.

Before launching, repair these evidence gaps:

1. The described staged Swamp acceptance is absent. Add rendered existing Swamp,
   visited removal, retained outside Swamp/neighbor and later-turn processor skip
   checks without mixing those fixtures into natural-death evidence.
2. Cleanup claims light removal but only inspects effects, meshes and busy bit.
   Assert no wave/orbit-owned `w.lights` records remain after cleanup.
3. Observe the very next turn explicitly: visits1 and32orbits. Current code jumps
   from visits0 to visits4, leaving the promised first-visit check indirect.

Use the granted sandboxed browser/server lane and a unique output directory.
Source review alone cannot establish terminal rendered acceptance.

## Verified receipts and quality attribution

Inspected exact-head `focused-d0e4510.json` (32/32),
`format-focused-d0e4510.json` (11 app files), `native-d0e4510.json` and
`eslint-compare-d0e4510.json`, with their raw stdout/stderr hashes and unchanged
before/after source identities. Native input and probe hashes match the actual
files; probe SHA256 is
`a14dad04230853d0ecd941d204f6603c7e68c36b6b750cfdbd7a3bf55344fc32`.

Independently checked the ESLint comparison more strictly than its count summary:
all211 diagnostics match basef78e5c1 by exact path, rule, message, severity and
affected source text. There are210 in world-turn and1 in scene-effects; no newly
introduced or removed messages in changed paths. This is inherited-finding
attribution, not a passing full `npm run lint`. Full format/lint/standard and
advisory Fallow evidence remain for final coordination.

A small direct Node feasibility check emulated startup to turn80 and ordinary
attack on authored Warrior13; the Shaman became injured, fought, died at turn515,
left the unit list and produced model12 with467remaining. The check's startup
control setup is staged and is not browser, UI or natural-frame evidence.

Full check/build and terminal rendered natural-death, checkpoint, spawn,
intrusion/Swamp and cleanup receipts remain pending. No full native game, whole
pool exhaustion, renderer parity or hardware-performance claim; issue30 stays open.
