# Source and browser-checker preflight ACCEPT

Frozen reviewed head: `5b8c56efc80b1c96a061478c8ab7f64b32158d45`.
Tracked tree clean at review. This is preflight for the granted serialized browser
lane, not permission to overlap the active M3 run and not terminal acceptance.

The complete app diff from reviewed repaird0e4510 is empty. Accepted mainb381851
is an ancestor through c99e8ab; that merge brings only accepted QA/harness changes.
The source findings,32 focused tests, native proof extension and inherited ESLint
attribution in `review-runtime-d0e4510.md` therefore retain exact app correspondence.

Reviewed checker delta d0e4510..5b8c56e and current supported harness invocation.
Syntax-only `node --check scripts/check-browser-reincarnation-wave.mjs` exits0.
No native/browser/full-check/build was run by reviewer.

The three previous checker gaps are closed:

- The next ordinary turn is explicitly observed at visits1 with32orbits and an
  empty controller group, before continuation to visit4.
- Fresh-page checkpoint compares site/flags/light-owner/wave/terrain state and
  requires restored orbit pixel contribution. Cleanup checks no wave/orbit-owned
  light records, effects or meshes remain.
- The separate staged phase renders an older in-cell Swamp before removal, checks
  the removed effect/mesh afterward, retains the outside Swamp and its mesh, and
  verifies its ordinary one-turn lifetime decrement. Retained inside-Swamp reference
  must have unchanged counter and remaining lifetime after that turn, so late
  processing cannot be hidden by final array filtering. These fixtures remain
  explicitly separate from natural combat/death/respawn evidence.

The checker now exports a scenario for the accepted sandboxed local-render harness,
uses its owned page/server/output and cancellation signal, and navigates with
DOMContentLoaded. Terminal harness `receipt.json` is the outcome authority; the
scenario's `report.json` alone does not establish successful cleanup/terminality.

One manifest-only correction remains: `engineering/checks.json`'s new harness
command must pass `--output $POPULOUS_ARTIFACT_DIR`. Its existing env declaration
does not affect the harness by itself, so the currently mapped command would use
the shared default output. The run owner can already avoid that by supplying a
unique explicit output. The harness owns its server/port; the old POPULOUS_URL
description is no longer consumed by this scenario.

Full check/build, final quality and terminal rendered natural-death/respawn,
checkpoint, resize and staged-consumer receipts remain pending. No original-game
raster, full pool exhaustion or hardware-performance claim is accepted; issue30
remains open.
