import {FpsGraph} from '/tmp/populous-selector-scene-457/app/fps-graph.ts'
import '/tmp/populous-selector-scene-457/app/globals.css'
const canvas=document.createElement('canvas');const gl=canvas.getContext('webgl2')!;
const graph=new FpsGraph(gl);document.body.append(graph.element);
for(let i=0;i<32;i++)graph.update(i*1000/120,1,2,7,'Component fixture',5);
document.body.style.background='#26313c';
