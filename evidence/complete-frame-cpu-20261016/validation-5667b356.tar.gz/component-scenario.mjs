import assert from 'node:assert/strict'
export default async ({page,output,receipt})=>{
 await page.setViewportSize({width:640,height:480});await page.locator('[data-metric="callback"]').waitFor();
 const result=await page.evaluate(()=>{const el=document.querySelector('.fps-graph'),r=el.getBoundingClientRect();return {kind:'Component-only real FpsGraph and production CSS; synthetic sample values, not game performance',bounds:r.toJSON(),text:el.innerText,overflow:el.scrollHeight>el.clientHeight}})
 assert.ok(result.bounds.x>=0&&result.bounds.y>=0&&result.bounds.right<=640&&result.bounds.bottom<=480,JSON.stringify(result.bounds));
 assert.equal(result.overflow,false);assert.match(result.text,/5.00 ms/);assert.match(result.text,/120 FPS: 8.33 ms/);
 await page.screenshot({path:`${output}/component-640x480.jpg`,type:'jpeg',quality:80});assert.deepEqual(receipt.errors,[]);return result;
}
