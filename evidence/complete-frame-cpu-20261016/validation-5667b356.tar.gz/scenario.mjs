import assert from 'node:assert/strict'
import { bindGame, showAllMissions } from '/tmp/populous-selector-scene-457/scripts/browser-game.mjs'
export default async ({page,url,output,receipt}) => {
 await page.setViewportSize({width:640,height:480})
 await page.goto(`${url}/?fps`,{waitUntil:'domcontentloaded'})
 await showAllMissions(page)
 await page.getByRole('button',{name:'Mission 1',exact:true}).focus()
 await page.keyboard.press('Enter')
 await bindGame(page)
 const guard=page.getByRole('button',{name:/^Continue anyway/})
 if(await guard.isVisible()) await guard.click()
 await page.waitForFunction(()=>window.testSceneRef.current.world.flyby.flags&1||!window.testSceneRef.current.world.inputMask)
 const skip=page.locator('.skip-introduction');if(await skip.isVisible())await skip.click()
 const resume=page.getByRole('button',{name:'Resume game',exact:true});if(await resume.isVisible())await resume.click()
 await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask,null,{timeout:60000})
 await page.waitForFunction(()=>document.querySelector('[data-metric="callback"]')?.textContent?.endsWith(' ms'))
 const result=await page.evaluate(()=>{
  const overlay=document.querySelector('.fps-graph'),r=overlay.getBoundingClientRect(),s=window.testSceneRef.current.fpsGraph.samples
  return {bounds:{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right},text:overlay.innerText,callbackMs:s.callbackMs,simulationMs:s.simulationMs,renderMs:s.renderMs,frames:s.count,canvas:document.querySelector('canvas')?.getBoundingClientRect().toJSON()}
 })
 assert.ok(result.bounds.x>=0&&result.bounds.y>=0&&result.bounds.right<=640&&result.bounds.bottom<=480,JSON.stringify(result.bounds))
 assert.ok(result.callbackMs>=result.simulationMs+result.renderMs)
 assert.match(result.text,/120 FPS: 8.33 ms/)
 assert.match(result.text,/excludes overlay \+ GPU/)
 await page.screenshot({path:`output-placeholder` .replace('output-placeholder',`${output}/callback-640x480.jpg`),type:'jpeg',quality:80})
 await page.evaluate(()=>document.activeElement?.blur());await page.keyboard.press('F8')
 assert.equal(await page.locator('.fps-graph').count(),0)
 await page.keyboard.press('F8');await page.waitForFunction(()=>document.querySelector('[data-metric="callback"]')?.textContent?.endsWith(' ms'))
 assert.deepEqual(receipt.errors,[])
 return result
}
