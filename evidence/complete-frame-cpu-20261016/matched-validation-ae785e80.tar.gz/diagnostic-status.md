# Matched diagnostic status

Candidate integration ae785e80022ad61f353512b2aeefd7206c880585 merges main167d8808.
Telemetry product and focused tests are unchanged from reviewed5667b356.

First baseline attempt (main167d8808) timed out after10s waiting for inputMask=0;
it did not crash. Stages establish early setup: bound turn0/mask128/flyby16,
notice dismissed atturn0, conditional immediate Skip checked atturn2 before
intro button appeared. On timeout scene had reachedturn124/mask64 with visible
Skip introduction and working telemetry. Thus the test's immediate conditional
Skip can miss an asynchronously appearing intro. This is not an explanation of
the earlier candidate page crash.

Root authorized one corrected matched pair. Only setup repair: explicitly wait
up to10s for the real Skip introduction button to become visible, then click.
All source, mission, viewport, browser, timing and reserve constraints unchanged.
Prior scenario retained as scenario-before-skip-fix.mjs; prior run as base-run.
