import assert from 'node:assert/strict'
import {writeFileSync,readFileSync,statfsSync} from 'node:fs'
import {bindGame,showAllMissions} from '/tmp/populous-selector-scene-457/scripts/browser-game.mjs'
export default async({page,output,receipt})=>{
 const stages=[]
 const stage=async name=>{
  const disk=statfsSync('/tmp'),free=disk.bavail*disk.bsize
  const state=await page.evaluate(()=>{const s=window.testSceneRef?.current;return {scene:!!s,turn:s?.world.turn,inputMask:s?.world.inputMask,flyby:s?.world.flyby.flags,paused:s?.world.paused,modal:s?.modalSuspended,active:document.activeElement?.tagName,notice:!!document.querySelector('.desktop-recommendation'),telemetry:!!document.querySelector('.fps-graph'),canvas:s?.renderer.domElement.getBoundingClientRect().toJSON(),losses:window.contextLosses??0}})
  stages.push({name,at:new Date().toISOString(),freeDiskBytes:free,memory:readFileSync('/proc/meminfo','utf8').split('\n').filter(x=>/^(MemAvailable|MemFree|MemTotal):/.test(x)),state})
  writeFileSync(`${output}/stages.json`,JSON.stringify(stages,null,2))
  assert.ok(free>=40*1024*1024,'Disk reserve below40MiB')
 }
 await stage('initial Home640 direct fps')
 await showAllMissions(page);await stage('selector')
 await page.getByRole('button',{name:'Mission 1',exact:true}).press('Enter')
 await bindGame(page);await stage('bound')
 await page.evaluate(()=>{window.contextLosses=0;window.testSceneRef.current.renderer.domElement.addEventListener('webglcontextlost',()=>window.contextLosses++)})
 const notice=page.locator('.desktop-recommendation');if(await notice.isVisible())await notice.getByRole('button',{name:/Continue anyway/}).click()
 await stage('notice handled')
 const skip=page.locator('.skip-introduction');await skip.waitFor({state:'visible',timeout:10000});await skip.click()
 await stage('visible skip handled')
 await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask,null,{timeout:10000})
 await page.waitForFunction(()=>document.querySelector('[data-metric="frame"]')?.textContent?.endsWith(' ms'),null,{timeout:10000})
 await stage('live telemetry')
 const candidate=receipt.source.sourceCommit==='ae785e80022ad61f353512b2aeefd7206c880585'
 const result=await page.evaluate(()=>{const el=document.querySelector('.fps-graph'),s=window.testSceneRef.current.fpsGraph.samples;return {bounds:el.getBoundingClientRect().toJSON(),text:el.innerText,callback:s.callbackMs,simulation:s.simulationMs,render:s.renderMs}})
 assert.ok(result.bounds.bottom<=480&&result.bounds.right<=640)
 if(candidate){assert.ok(result.callback>=result.simulation+result.render);assert.match(result.text,/120 FPS: 8.33 ms/)}
 await page.screenshot({path:`${output}/live-640x480.jpg`,type:'jpeg',quality:75})
 await page.evaluate(()=>document.activeElement?.blur());await page.keyboard.press('F8');assert.equal(await page.locator('.fps-graph').count(),0);await stage('F8 off')
 await page.keyboard.press('F8');await page.waitForFunction(()=>document.querySelector('[data-metric="frame"]')?.textContent?.endsWith(' ms'),null,{timeout:10000});await stage('F8 on')
 assert.deepEqual(receipt.errors,[]);return{candidate,...result,stages}
}
