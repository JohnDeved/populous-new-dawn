import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
const base = '14077605612ccf2572c63b5a66356cf3e7967976'
const files = ['app/person-state.ts', 'app/world-turn.ts']
const report = []
for (const file of files) {
 const previous = execFileSync('git', ['show', `${base}:${file}`], { encoding: 'utf8' })
 const current = readFileSync(file, 'utf8')
 const lint = input => {
  const r = spawnSync('node_modules/.bin/eslint', ['--stdin', '--stdin-filename', file, '--format', 'json'], { input, encoding: 'utf8' })
  if (![0, 1].includes(r.status)) throw Error(r.stderr)
  const diagnostics = JSON.parse(r.stdout)[0].messages.map(({ ruleId, severity, message }) => ({ ruleId, severity, message }))
  return { exitCode: r.status, diagnostics }
 }
 const before = lint(previous), after = lint(current)
 if (JSON.stringify(before) !== JSON.stringify(after)) throw Error(`Changed diagnostic set: ${file}`)
 report.push({ file, baseline: before, candidate: after, introduced: 0 })
}
writeFileSync('work/orchestration/transport-idle/quality-comparison.json', JSON.stringify({ base, head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), report }, null, 2))
console.log('PASS: both changed TypeScript files retain exact baseline ESLint rule/message/severity sets; zero introduced diagnostics')
