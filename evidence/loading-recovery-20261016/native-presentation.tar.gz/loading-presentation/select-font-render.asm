
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00516d30 <.text+0x115d30>:
  516d30:	83 3d 78 a0 5d 00 00 	cmp    DWORD PTR ds:0x5da078,0x0
  516d37:	75 16                	jne    0x516d4f
  516d39:	81 7c 24 04 98 16 59 	cmp    DWORD PTR [esp+0x4],0x591698
  516d40:	00 
  516d41:	b8 f0 a1 5d 00       	mov    eax,0x5da1f0
  516d46:	74 0b                	je     0x516d53
  516d48:	b8 00 a2 5d 00       	mov    eax,0x5da200
  516d4d:	eb 04                	jmp    0x516d53
  516d4f:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  516d53:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  516d57:	51                   	push   ecx
  516d58:	50                   	push   eax
  516d59:	e8 42 0d 01 00       	call   0x527aa0
  516d5e:	83 c4 08             	add    esp,0x8
  516d61:	c3                   	ret
