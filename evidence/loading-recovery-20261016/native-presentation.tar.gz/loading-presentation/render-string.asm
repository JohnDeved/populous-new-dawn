
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00527960 <.text+0x126960>:
  527960:	53                   	push   ebx
  527961:	56                   	push   esi
  527962:	8b 5c 24 10          	mov    ebx,DWORD PTR [esp+0x10]
  527966:	57                   	push   edi
  527967:	8b 7c 24 18          	mov    edi,DWORD PTR [esp+0x18]
  52796b:	55                   	push   ebp
  52796c:	66 83 3f 00          	cmp    WORD PTR [edi],0x0
  527970:	8b 6c 24 14          	mov    ebp,DWORD PTR [esp+0x14]
  527974:	8b f5                	mov    esi,ebp
  527976:	74 49                	je     0x5279c1
  527978:	66 8b 07             	mov    ax,WORD PTR [edi]
  52797b:	66 3d 0a 00          	cmp    ax,0xa
  52797f:	75 13                	jne    0x527994
  527981:	6a 20                	push   0x20
  527983:	8b f5                	mov    esi,ebp
  527985:	83 c7 02             	add    edi,0x2
  527988:	e8 b3 01 00 00       	call   0x527b40
  52798d:	83 c4 04             	add    esp,0x4
  527990:	03 d8                	add    ebx,eax
  527992:	eb 27                	jmp    0x5279bb
  527994:	83 c7 02             	add    edi,0x2
  527997:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  52799b:	8b 54 24 20          	mov    edx,DWORD PTR [esp+0x20]
  52799f:	51                   	push   ecx
  5279a0:	52                   	push   edx
  5279a1:	33 c9                	xor    ecx,ecx
  5279a3:	8a c8                	mov    cl,al
  5279a5:	a1 04 09 5e 00       	mov    eax,ds:0x5e0904
  5279aa:	51                   	push   ecx
  5279ab:	53                   	push   ebx
  5279ac:	56                   	push   esi
  5279ad:	50                   	push   eax
  5279ae:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  5279b3:	ff 50 0c             	call   DWORD PTR [eax+0xc]
  5279b6:	83 c4 18             	add    esp,0x18
  5279b9:	03 f0                	add    esi,eax
  5279bb:	66 83 3f 00          	cmp    WORD PTR [edi],0x0
  5279bf:	75 b7                	jne    0x527978
  5279c1:	5d                   	pop    ebp
  5279c2:	5f                   	pop    edi
  5279c3:	5e                   	pop    esi
  5279c4:	5b                   	pop    ebx
  5279c5:	c3                   	ret
