
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004fd7c0 <.text+0xfc7c0>:
  4fd7c0:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  4fd7c6:	55                   	push   ebp
  4fd7c7:	8b ec                	mov    ebp,esp
  4fd7c9:	6a ff                	push   0xffffffff
  4fd7cb:	68 7f da 4f 00       	push   0x4fda7f
  4fd7d0:	50                   	push   eax
  4fd7d1:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4fd7d8:	83 ec 0c             	sub    esp,0xc
  4fd7db:	c7 05 48 90 a6 00 00 	mov    DWORD PTR ds:0xa69048,0x0
  4fd7e2:	00 00 00 
  4fd7e5:	53                   	push   ebx
  4fd7e6:	56                   	push   esi
  4fd7e7:	57                   	push   edi
  4fd7e8:	a1 48 90 a6 00       	mov    eax,ds:0xa69048
  4fd7ed:	c1 e0 04             	shl    eax,0x4
  4fd7f0:	ff 05 48 90 a6 00    	inc    DWORD PTR ds:0xa69048
  4fd7f6:	8b 8c 40 08 5b 5d 00 	mov    ecx,DWORD PTR [eax+eax*2+0x5d5b08]
  4fd7fd:	80 39 23             	cmp    BYTE PTR [ecx],0x23
  4fd800:	75 e6                	jne    0x4fd7e8
  4fd802:	be 08 5b 5d 00       	mov    esi,0x5d5b08
  4fd807:	33 db                	xor    ebx,ebx
  4fd809:	ff 0d 48 90 a6 00    	dec    DWORD PTR ds:0xa69048
  4fd80f:	39 1d 48 90 a6 00    	cmp    DWORD PTR ds:0xa69048,ebx
  4fd815:	0f 8e 2d 02 00 00    	jle    0x4fda48
  4fd81b:	a1 6a bc 89 00       	mov    eax,ds:0x89bc6a
  4fd820:	83 f8 07             	cmp    eax,0x7
  4fd823:	74 09                	je     0x4fd82e
  4fd825:	83 f8 08             	cmp    eax,0x8
  4fd828:	74 09                	je     0x4fd833
  4fd82a:	8b 06                	mov    eax,DWORD PTR [esi]
  4fd82c:	eb 08                	jmp    0x4fd836
  4fd82e:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  4fd831:	eb 03                	jmp    0x4fd836
  4fd833:	8b 46 08             	mov    eax,DWORD PTR [esi+0x8]
  4fd836:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  4fd839:	e8 d2 59 f9 ff       	call   0x493210
  4fd83e:	6a 18                	push   0x18
  4fd840:	85 c0                	test   eax,eax
  4fd842:	0f 84 02 01 00 00    	je     0x4fd94a
  4fd848:	e8 53 d4 05 00       	call   0x55aca0
  4fd84d:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  4fd850:	83 c4 04             	add    esp,0x4
  4fd853:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4fd85a:	8b f8                	mov    edi,eax
  4fd85c:	85 ff                	test   edi,edi
  4fd85e:	74 43                	je     0x4fd8a3
  4fd860:	89 7d ec             	mov    DWORD PTR [ebp-0x14],edi
  4fd863:	c7 07 c0 f0 58 00    	mov    DWORD PTR [edi],0x58f0c0
  4fd869:	c7 47 04 00 00 00 00 	mov    DWORD PTR [edi+0x4],0x0
  4fd870:	c7 47 08 00 00 00 00 	mov    DWORD PTR [edi+0x8],0x0
  4fd877:	c6 45 fc 01          	mov    BYTE PTR [ebp-0x4],0x1
  4fd87b:	c6 45 fc 00          	mov    BYTE PTR [ebp-0x4],0x0
  4fd87f:	c7 07 b0 f0 58 00    	mov    DWORD PTR [edi],0x58f0b0
  4fd885:	c7 47 04 00 00 00 00 	mov    DWORD PTR [edi+0x4],0x0
  4fd88c:	c7 47 0c 00 00 00 00 	mov    DWORD PTR [edi+0xc],0x0
  4fd893:	c7 47 14 00 00 00 00 	mov    DWORD PTR [edi+0x14],0x0
  4fd89a:	c7 47 10 00 00 00 00 	mov    DWORD PTR [edi+0x10],0x0
  4fd8a1:	eb 02                	jmp    0x4fd8a5
  4fd8a3:	33 c0                	xor    eax,eax
  4fd8a5:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fd8ac:	89 46 20             	mov    DWORD PTR [esi+0x20],eax
  4fd8af:	83 fb 0b             	cmp    ebx,0xb
  4fd8b2:	c7 46 2c 01 00 00 00 	mov    DWORD PTR [esi+0x2c],0x1
  4fd8b9:	0f 87 79 01 00 00    	ja     0x4fda38
  4fd8bf:	33 c0                	xor    eax,eax
  4fd8c1:	8a 83 ac da 4f 00    	mov    al,BYTE PTR [ebx+0x4fdaac]
  4fd8c7:	ff 24 85 98 da 4f 00 	jmp    DWORD PTR [eax*4+0x4fda98]
  4fd8ce:	83 3d 6a bc 89 00 0b 	cmp    DWORD PTR ds:0x89bc6a,0xb
  4fd8d5:	75 1b                	jne    0x4fd8f2
  4fd8d7:	a1 fc 98 6a 00       	mov    eax,ds:0x6a98fc
  4fd8dc:	8b 4e 20             	mov    ecx,DWORD PTR [esi+0x20]
  4fd8df:	89 41 0c             	mov    DWORD PTR [ecx+0xc],eax
  4fd8e2:	b8 0c 00 00 00       	mov    eax,0xc
  4fd8e7:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  4fd8ea:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  4fd8ed:	e9 46 01 00 00       	jmp    0x4fda38
  4fd8f2:	a1 f0 98 6a 00       	mov    eax,ds:0x6a98f0
  4fd8f7:	8b 4e 20             	mov    ecx,DWORD PTR [esi+0x20]
  4fd8fa:	89 41 0c             	mov    DWORD PTR [ecx+0xc],eax
  4fd8fd:	c7 46 28 10 00 00 00 	mov    DWORD PTR [esi+0x28],0x10
  4fd904:	c7 46 24 10 00 00 00 	mov    DWORD PTR [esi+0x24],0x10
  4fd90b:	e9 28 01 00 00       	jmp    0x4fda38
  4fd910:	8b 0d f0 98 6a 00    	mov    ecx,DWORD PTR ds:0x6a98f0
  4fd916:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fd919:	89 48 0c             	mov    DWORD PTR [eax+0xc],ecx
  4fd91c:	c7 46 28 10 00 00 00 	mov    DWORD PTR [esi+0x28],0x10
  4fd923:	c7 46 24 10 00 00 00 	mov    DWORD PTR [esi+0x24],0x10
  4fd92a:	e9 09 01 00 00       	jmp    0x4fda38
  4fd92f:	a1 f4 98 6a 00       	mov    eax,ds:0x6a98f4
  4fd934:	8b 4e 20             	mov    ecx,DWORD PTR [esi+0x20]
  4fd937:	89 41 0c             	mov    DWORD PTR [ecx+0xc],eax
  4fd93a:	b8 18 00 00 00       	mov    eax,0x18
  4fd93f:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  4fd942:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  4fd945:	e9 ee 00 00 00       	jmp    0x4fda38
  4fd94a:	e8 51 d3 05 00       	call   0x55aca0
  4fd94f:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  4fd952:	83 c4 04             	add    esp,0x4
  4fd955:	8b f8                	mov    edi,eax
  4fd957:	b8 02 00 00 00       	mov    eax,0x2
  4fd95c:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  4fd95f:	85 ff                	test   edi,edi
  4fd961:	74 44                	je     0x4fd9a7
  4fd963:	89 7d e8             	mov    DWORD PTR [ebp-0x18],edi
  4fd966:	c7 07 c0 f0 58 00    	mov    DWORD PTR [edi],0x58f0c0
  4fd96c:	c7 47 04 00 00 00 00 	mov    DWORD PTR [edi+0x4],0x0
  4fd973:	c7 47 08 00 00 00 00 	mov    DWORD PTR [edi+0x8],0x0
  4fd97a:	c6 45 fc 03          	mov    BYTE PTR [ebp-0x4],0x3
  4fd97e:	c7 07 b0 f0 58 00    	mov    DWORD PTR [edi],0x58f0b0
  4fd984:	88 45 fc             	mov    BYTE PTR [ebp-0x4],al
  4fd987:	c7 47 04 00 00 00 00 	mov    DWORD PTR [edi+0x4],0x0
  4fd98e:	c7 47 0c 00 00 00 00 	mov    DWORD PTR [edi+0xc],0x0
  4fd995:	c7 47 14 00 00 00 00 	mov    DWORD PTR [edi+0x14],0x0
  4fd99c:	c7 47 10 00 00 00 00 	mov    DWORD PTR [edi+0x10],0x0
  4fd9a3:	8b c7                	mov    eax,edi
  4fd9a5:	eb 02                	jmp    0x4fd9a9
  4fd9a7:	33 c0                	xor    eax,eax
  4fd9a9:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fd9b0:	89 46 20             	mov    DWORD PTR [esi+0x20],eax
  4fd9b3:	e8 48 58 fa ff       	call   0x4a3200
  4fd9b8:	e8 63 63 fa ff       	call   0x4a3d20
  4fd9bd:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  4fd9c0:	50                   	push   eax
  4fd9c1:	68 23 cd 89 00       	push   0x89cd23
  4fd9c6:	e8 e5 27 00 00       	call   0x5001b0
  4fd9cb:	83 c4 08             	add    esp,0x8
  4fd9ce:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fd9d1:	50                   	push   eax
  4fd9d2:	6a 00                	push   0x0
  4fd9d4:	68 23 cd 89 00       	push   0x89cd23
  4fd9d9:	e8 a2 99 02 00       	call   0x527380
  4fd9de:	c7 46 2c 00 00 00 00 	mov    DWORD PTR [esi+0x2c],0x0
  4fd9e5:	c7 46 24 00 00 00 00 	mov    DWORD PTR [esi+0x24],0x0
  4fd9ec:	c7 46 28 00 00 00 00 	mov    DWORD PTR [esi+0x28],0x0
  4fd9f3:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fd9f6:	83 c4 0c             	add    esp,0xc
  4fd9f9:	33 c9                	xor    ecx,ecx
  4fd9fb:	39 48 10             	cmp    DWORD PTR [eax+0x10],ecx
  4fd9fe:	76 38                	jbe    0x4fda38
  4fda00:	33 d2                	xor    edx,edx
  4fda02:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fda05:	8b 78 0c             	mov    edi,DWORD PTR [eax+0xc]
  4fda08:	33 c0                	xor    eax,eax
  4fda0a:	66 8b 44 17 04       	mov    ax,WORD PTR [edi+edx*1+0x4]
  4fda0f:	39 46 24             	cmp    DWORD PTR [esi+0x24],eax
  4fda12:	7d 03                	jge    0x4fda17
  4fda14:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  4fda17:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fda1a:	8b 78 0c             	mov    edi,DWORD PTR [eax+0xc]
  4fda1d:	33 c0                	xor    eax,eax
  4fda1f:	66 8b 44 17 06       	mov    ax,WORD PTR [edi+edx*1+0x6]
  4fda24:	39 46 28             	cmp    DWORD PTR [esi+0x28],eax
  4fda27:	7d 03                	jge    0x4fda2c
  4fda29:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  4fda2c:	8b 46 20             	mov    eax,DWORD PTR [esi+0x20]
  4fda2f:	83 c2 08             	add    edx,0x8
  4fda32:	41                   	inc    ecx
  4fda33:	39 48 10             	cmp    DWORD PTR [eax+0x10],ecx
  4fda36:	77 ca                	ja     0x4fda02
  4fda38:	43                   	inc    ebx
  4fda39:	83 c6 30             	add    esi,0x30
  4fda3c:	39 1d 48 90 a6 00    	cmp    DWORD PTR ds:0xa69048,ebx
  4fda42:	0f 8f d3 fd ff ff    	jg     0x4fd81b
  4fda48:	8b 45 f4             	mov    eax,DWORD PTR [ebp-0xc]
  4fda4b:	5f                   	pop    edi
  4fda4c:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  4fda52:	5e                   	pop    esi
  4fda53:	5b                   	pop    ebx
  4fda54:	8b e5                	mov    esp,ebp
  4fda56:	c7 05 4c 90 a6 00 08 	mov    DWORD PTR ds:0xa6904c,0x5d5b08
  4fda5d:	5b 5d 00 
