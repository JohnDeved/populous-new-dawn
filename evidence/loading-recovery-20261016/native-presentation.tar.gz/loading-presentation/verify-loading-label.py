"""Independently decode PSFB masks/PNG and verify narrow generated label output."""
from pathlib import Path
import hashlib,json,struct,zlib,subprocess,sys
ROOT=Path('/tmp/loading-ui-research'); GAME=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app')
def sha(b):return hashlib.sha256(b).hexdigest()
def png(path):
 b=path.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';p=8;payload=b''
 while p<len(b):
  n=struct.unpack_from('>I',b,p)[0];kind=b[p+4:p+8];d=b[p+8:p+8+n];assert zlib.crc32(kind+d)&0xffffffff==struct.unpack_from('>I',b,p+8+n)[0];p+=n+12
  if kind==b'IHDR':w,h,depth,color,*_=struct.unpack('>IIBBBBB',d);assert(depth,color)==(8,6)
  elif kind==b'IDAT':payload+=d
 raw=zlib.decompress(payload);assert len(raw)==h*(w*4+1);out=bytearray()
 for y in range(h):assert raw[y*(w*4+1)]==0;out.extend(raw[y*(w*4+1)+1:(y+1)*(w*4+1)])
 return w,h,bytes(out)
data=(GAME/'data/fenew/FEFT20WE.spr').read_bytes();label='Loading...';mask=bytearray(81*19);x=0
for c in label:
 w,h,off=struct.unpack_from('<HHI',data,8+(ord(c)-32)*8)
 for y in range(h):
  xx=0
  while True:
   run=struct.unpack_from('b',data,off)[0];off+=1
   if run==0:break
   if run<0:xx-=run
   else:
    mask[y*81+x+xx:y*81+x+xx+run]=b'\xff'*run;xx+=run;off+=run
   assert xx<=w
 x+=w
assert x==81
expected=bytearray(82*20*4)
for offset,gray in [(0,131),(1,255)]:
 for y in range(19):
  for x in range(81):
   if mask[y*81+x]:p=((y+offset)*82+x+offset)*4;expected[p:p+4]=bytes([gray,gray,gray,255])
w,h,rgba=png(ROOT/'generated/loading-label.png');assert(w,h)==(82,20);assert rgba==expected
metadata=json.loads((ROOT/'generated/loading-label.json').read_text());assert metadata['maskSha256']==sha(mask);assert metadata['rgbaSha256']==sha(expected)
cmd=[sys.executable,'-B',str(ROOT/'import-loading-label.py'),str(GAME),'--decoder','/tmp/populous-selector-scene-457/scripts/import-original.py','--output',str(ROOT/'reproduced')]
subprocess.run(cmd,check=True,capture_output=True)
for name in ['loading-label.png','loading-label.json']:assert (ROOT/'generated'/name).read_bytes()==(ROOT/'reproduced'/name).read_bytes()
# Re-run in place to confirm identity and no source dependence on output state.
subprocess.run(cmd,check=True,capture_output=True)
for name in ['loading-label.png','loading-label.json']:assert (ROOT/'generated'/name).read_bytes()==(ROOT/'reproduced'/name).read_bytes()
reject=[]
files={p.relative_to(GAME).as_posix().lower():p for p in GAME.rglob('*')if p.is_file()}
for index,name in enumerate(metadata['inputs']):
 badroot=ROOT/'hash-rejection-inputs'/str(index);out=ROOT/'hash-rejection-output'/str(index);out.mkdir(parents=True,exist_ok=True);(out/'sentinel').write_bytes(b'preserve')
 for input_name in metadata['inputs']:
  dest=badroot/input_name;dest.parent.mkdir(parents=True,exist_ok=True);raw=files[input_name].read_bytes()
  dest.write_bytes(bytes([raw[0]^1])+raw[1:]if input_name==name else raw)
 p=subprocess.run([sys.executable,'-B',str(ROOT/'import-loading-label.py'),str(badroot),'--decoder','/tmp/populous-selector-scene-457/scripts/import-original.py','--output',str(out)],capture_output=True,text=True)
 assert p.returncode==1 and 'Source hash mismatch: '+name in p.stderr and list(out.iterdir())==[out/'sentinel'] and (out/'sentinel').read_bytes()==b'preserve'
 reject.append({'input':name,'exitCode':p.returncode,'outputUnchanged':True})
result={'status':'PASS_INDEPENDENT_LOADING_LABEL','pixelComparison':'all 1640 pixels and RGBA channels match independent decoder/compositor','width':w,'height':h,'rgbaSha256':sha(rgba),'pngSha256':sha((ROOT/'generated/loading-label.png').read_bytes()),'sourceLabelMaskSha256':sha(mask),'reproduction':'fresh output and in-place byte-identical PNG/JSON','corruptInputRejections':reject,'limits':'Static data only; no native execution, GPU raster, browser/runtime integration or full game validation.'}
(ROOT/'import-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
