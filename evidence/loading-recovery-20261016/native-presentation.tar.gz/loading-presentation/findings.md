# Original loading presentation: bounded static research

2026-10-16. Assigned #457 loading/recovery presentation in JohnDeved/populous-new-dawn. Initial checkout /tmp/populous-selector-scene-457 was clean at362139efb8f5d44be0144e69b329ff48747f0109. The UI worker owns all repository edits; this worker wrote only /tmp/loading-ui-research. Git identity was read through the supplied wrapper /tmp/selector-scene457/git-bin/git. No original EXE execution, emulation, Ghidra export, native probe, notification-controller investigation, save-format investigation, browser work or fixture recording was performed.

## Useful result and safe reuse contract

The ordinary Western loading label uses frontend slot1, **data/fenew/FEFT20WE.spr**, not the menu's style2 font or the result F00T3 font. English language515 is `Loading...`. Its measured width is81 and height19. Glyph advances in order are8,14,10,11,4,10,12,4,4,4. The code makes two solid-colour software-surface text passes: **gray RGB(131,131,131) at the first origin, then white RGB(255,255,255) at(+1,+1)**. Those are palette values before original device-format packing. A black shadow is unsupported. The composite is82×20 including the offset.

Reuse the previously proved130×161 white/nonzero loadlog2 mask. For a normal viewport W×H with the logo available:

- logoX=trunc((W−130)/2), logoY=trunc((H−161)/2)
- firstLabelX=trunc((W−81)/2)
- firstLabelY=logoY−19+2−trunc(19/2)=logoY−26
- second pass adds1 to both first-label coordinates

At640×480: logo(255,159), label first(279,133), label second(280,134). At641×481: logo(255,160), label first(280,134), label second(281,135). **Do not use a constant label offset from the mask's left edge or centre the82px composite**: the original centres the81px measured text, then extends the second pass. The native512×384 mode has separate compatibility offsets and is not part of this ordinary-viewport contract.

The clear is **current system-palette index0**, not a background picture or universally literal RGB0. Supplied frontend fepal1 has black at0; pal0-c hasRGB(13,15,6). This packet does not bind the active palette for every show caller. Opaque black is a reasonable explicitly documented browser compatibility clear; do not claim full original background-RGB fidelity. Neither frontend face artwork nor result stone panel belongs in this loading primitive.

Browser cold-checkpoint boot, errors, retry choices and responsive recovery layout remain explicit browser adaptations. No original retry/error card or spinner/progress-percent style was established. Preserve existing readiness, cancellation and retry ownership. Do not invent a minimum delay from two native back-buffer passes.

## Exact evidence chain

All original data is under /workspace/scratch/69fd8163d94e/populous-research-inputs/game/app (case varies in real filenames). `static-evidence.json` retains source hashes,20 bounded byte-window hashes/file offsets, raw data records and GNU objdump2.44 listing hashes. `retain-static-evidence.py` reproduces these static excerpts using the existing hash-validating PE32 reader from scripts/check-static-mission18-sky.py. It never imports Capstone, Unicorn, the broad importer main or original code.

### Font selection and metrics

- loading-leaf.asm00522d20 reads pointer[005d5b58], then+0xc glyph table;00522d35–00522d3a chooses text-render table00591698 for the Western path.
- font-bank-init.asm004fd7c0 uses the array at005d5b08 with stride0x30. The slot1 record005d5b38 has sprite object at+0x20=005d5b58. Its normal/Western path pointer005d5a88 is `data\\fenew\\feft20we.spr`. Font modes7/8 select separate Eastern-European/Russian paths;9–11 use separate language engines, excluded here.
-004fd9b0 stores the sprite object;004fd9bd–004fd9d9 resolves/loads the selected file; object+0xc is the loaded glyph table. No external font is substituted.
- software font vtable00591698 contains metrics00527a30 and solid renderer00527a60.00516d30 substitutes005da1f0 only when graphics state005da078 is0; that table uses equivalent metrics00516b80 but a GPU rendering path outside this software-raster claim.
- measure-string.asm0049a630 sums glyph advances from00527b10. Both metric leaves read unsigned width/height at8byte entries indexedcodepoint−32. A (code65) is10×19; the loading leaf requests height with00527b40 at00522d76/00522f2b. The earlier helper name containing “width” is misleading; its return is the second metric (height).
-00522d80–00522d8c subtracts measured text width from signed screen width before signed divide by2.00522e39–00522e61 separately centres the logo.00522f30–00522f35 subtracts glyph-A height and adds2; both draw branches additionally subtract half that height. The first pass is at00522f5d onwards, second at00522fff onwards.

### FE/FF colours and solid masks

-00522c84 guards a present palette;00522c8d–00522c95 calls004a32d0(palette,1), then updates indicesFF andFE through004b25a0. reset-loading-colours.asm004a3305–004a3328 setsFF RGB255 andFE RGB131.
- publish-palette-wrapper.asm004b25a0 calls004b1850. publish-system-palette.asm004b1862–004b1873 copies the indexed entry into the UI palette;004b18de–004b18ee copies the entire palette to system buffer00d05528. Entry flags are updated separately; the three RGB bytes remain those values.
- read-indexed-text-colour.asm00415f70 reads chosen palette entry into the8byte colour argument as BGRA plus index. FE is selected by00522f5d, FF by00522fff. Second-pass origin is explicitly incremented by1 in both Western and alternate-language drawing branches.
- render-string.asm00527960 advances each glyph by the solid renderer's returned width. solid-glyph-dispatch.asm00527a60 calls0052c300. solid-glyph-wrapper.asm dispatches active surface vtable+0x3c.
- lock-surface-backends.asm005281c0 chooses surface backend by bit depth. Original data jump table at00528280 and byte table00528294 map16bit to0052823f, writing backend00d05b18. surface-backend-initializers.asm00527c80 installs vtable005919f0; its+0x3c is00546190.
- solid-glyph-16bit.asm is the unclipped/unflipped rendering path from00546190 through00546419. At00546359 positive run length is sign-extended;0054635d advances the source pointer across all literal pixel-index bytes without reading them.00546366–005463df packs the supplied colour for the destination device.005463e9 repeatedly writes that same word. Negative runs preserve destination. Therefore the original source palette colours of FEFT20WE are irrelevant in this path; its positive-RLE occupancy is the mask.
- This proves a useful normal16bit software rendering branch, not a full original loading lifecycle or every device/path. Clipped/flipped branches, other bit depths, alternate language renderers and GPU texture processing were not certified. PNG uses pre-device RGB131/255, without guessing RGB555/RGB565 quantization.

### Clear/background

-00522ce8–00522cfc constructs an indexed colour with index0 via004525d0, supplies null rect and calls00529940 before testing whether show==1.
- read-indexed-clear-colour.asm004525d0 reads system palette00d05528+index*4, just like the text-colour constructor.
- clear-indexed-surface.asm00529940 takes that colour, converts according to8/16/24/32bit surface format, and at00529b22–00529b4b dispatches the surface Blt-style fill.16bit conversion uses supplied RGB, not a forced zero. The8bit branch uses the supplied index.
- static-evidence.json records fepal1 index0[0,0,0,0] and pal0-c index0[13,15,6,0]. These are static source examples, not proof that every loading caller uses those exact palettes. Existing frontend-menu-composition.md independently binds frontend fepal1 to startup.

## Inputs and hashes

- D3DPopTB.exe:2275840bytes, SHA2563a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f
- data/fenew/FEFT20WE.spr:25842bytes, SHA256fc705fe271d131d7bec0023fc07ebf1f7fe91596e260b5d23e6004a380d4ea4b
- language/lang00.dat:207264bytes, SHA256e826c478746d666a3ea9ea36cb7804d1d226d5f83084230987b1de293066cf7d
- data/loadlog2.dat:20930bytes, SHA256ef0b112f4fa1d357637380f287e5f517538dd79eff75b1b42b2c0955e9d61a56
- data/fenew/fepal1.dat:1024bytes, SHA2563d5dde1ab7c351635efdc58f4fee879f85b842bb044d8a83a0d21eede1bac02f
- data/pal0-c.dat:1024bytes, SHA2566c61cd586fc96ef5f777c71966a9ac1875491a4a521342ba06d108df5e92bf53

## Importer and verification handoff

`import-loading-label.py` is an importer-ready candidate for scripts/import-loading-label.py. It validates all three pinnedEXE/font/language hashes before creating output. It extracts only the existing import-original.py sprites/png function definitions, never runs that broad importer, decodes source run occupancy with a white dummy palette, and paints gray then white at(+1,+1). It writes only loading-label.png and loading-label.json into the selected output directory. The JSON retains font metrics, independent measured dimensions, native origin formulas, source/decoder/output hashes and boundaries. Repository owner integrates it.

Command (passed, exit0):

python3 -B /tmp/loading-ui-research/import-loading-label.py /workspace/scratch/69fd8163d94e/populous-research-inputs/game/app --output /tmp/loading-ui-research/generated --decoder /tmp/populous-selector-scene-457/scripts/import-original.py

Generated82×20 PNG SHA2569b5344c17384895329eea031ab56c0243600022970bdfb814ed7ce25feb625c9; decoded RGBA SHA2563022d6d77a73c6178be532eb2697ac7b77df25bc61b3980b69a4dc0b7a742f55;81×19 opacity-mask SHA25654bec866a3e2c08a23166775596533314761878480150ee31ab83e62e767a9ed.

Command (passed, exit0): python3 -B /tmp/loading-ui-research/verify-loading-label.py

`import-validation.json` records an independent PSFB-mask decoder and independent PNG/CRC/deflate reader: all1640pixels/allRGBA channels match independently composed two-pass expectation. Fresh-output and in-place repetition produce identicalPNG/JSON. Separate corruptedEXE/font/language inputs each exit1 before touching pre-existing output. Generated label pixels were visually inspected. These are source-asset/import checks, not runtime/browser/UI parity checks.

Command (passed, exit0): python3 -B /tmp/loading-ui-research/retain-static-evidence.py

The first retention attempt used lower-case loadlog2.dat against a mixed-case extracted filename and failed with FileNotFoundError; this was corrected with case-insensitive input lookup. No native action was denied or attempted. Capstone is unavailable in defaultPython; static objdump and the existing hash-validating PE reader sufficed, without installing anything.

## Durable publication recommendation

Integrate the useful font/clear findings into decomp/research/loading-art.md; retain source-bound raw excerpts/data manifest in a scoped loading-presentation evidence directory and link it. Keep the existing loading-mask checker as historical proof; do not silently claim this packet reran it or changed its certified scope. Candidate importer and its narrow independent validator can be retained if the parent/reviewer accepts them. Do not broaden claims to all native loading/error lifecycles, exact hardware pixels or notification controls.
