
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00516b80 <.text+0x115b80>:
  516b80:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  516b84:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  516b88:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  516b8c:	8d 0c c8             	lea    ecx,[eax+ecx*8]
  516b8f:	33 c0                	xor    eax,eax
  516b91:	66 8b 81 04 ff ff ff 	mov    ax,WORD PTR [ecx-0xfc]
  516b98:	89 02                	mov    DWORD PTR [edx],eax
  516b9a:	33 c0                	xor    eax,eax
  516b9c:	66 8b 81 06 ff ff ff 	mov    ax,WORD PTR [ecx-0xfa]
  516ba3:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  516ba6:	c3                   	ret
  516ba7:	cc                   	int3
  516ba8:	cc                   	int3
  516ba9:	cc                   	int3
  516baa:	cc                   	int3
  516bab:	cc                   	int3
  516bac:	cc                   	int3
  516bad:	cc                   	int3
  516bae:	cc                   	int3
  516baf:	cc                   	int3
