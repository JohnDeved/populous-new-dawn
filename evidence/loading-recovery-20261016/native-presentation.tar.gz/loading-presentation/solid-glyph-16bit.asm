
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00546190 <.text+0x145190>:
  546190:	8b 54 24 0c          	mov    edx,DWORD PTR [esp+0xc]
  546194:	83 ec 14             	sub    esp,0x14
  546197:	66 8b 42 04          	mov    ax,WORD PTR [edx+0x4]
  54619b:	53                   	push   ebx
  54619c:	56                   	push   esi
  54619d:	57                   	push   edi
  54619e:	55                   	push   ebp
  54619f:	33 ed                	xor    ebp,ebp
  5461a1:	66 85 c0             	test   ax,ax
  5461a4:	0f 84 84 0a 00 00    	je     0x546c2e
  5461aa:	66 8b 5a 06          	mov    bx,WORD PTR [edx+0x6]
  5461ae:	66 85 db             	test   bx,bx
  5461b1:	0f 84 77 0a 00 00    	je     0x546c2e
  5461b7:	8b 74 24 28          	mov    esi,DWORD PTR [esp+0x28]
  5461bb:	8b 7c 24 2c          	mov    edi,DWORD PTR [esp+0x2c]
  5461bf:	89 6c 24 1c          	mov    DWORD PTR [esp+0x1c],ebp
  5461c3:	3b 35 e0 5a d0 00    	cmp    esi,DWORD PTR ds:0xd05ae0
  5461c9:	0f b7 c8             	movzx  ecx,ax
  5461cc:	0f b7 db             	movzx  ebx,bx
  5461cf:	89 4c 24 10          	mov    DWORD PTR [esp+0x10],ecx
  5461d3:	89 5c 24 14          	mov    DWORD PTR [esp+0x14],ebx
  5461d7:	7d 31                	jge    0x54620a
  5461d9:	f6 05 14 5b d0 00 01 	test   BYTE PTR ds:0xd05b14,0x1
  5461e0:	75 0b                	jne    0x5461ed
  5461e2:	a1 e0 5a d0 00       	mov    eax,ds:0xd05ae0
  5461e7:	2b c6                	sub    eax,esi
  5461e9:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  5461ed:	2b 35 e0 5a d0 00    	sub    esi,DWORD PTR ds:0xd05ae0
  5461f3:	03 f1                	add    esi,ecx
  5461f5:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  5461f9:	8b 35 e0 5a d0 00    	mov    esi,DWORD PTR ds:0xd05ae0
  5461ff:	83 7c 24 10 00       	cmp    DWORD PTR [esp+0x10],0x0
  546204:	0f 8e 24 0a 00 00    	jle    0x546c2e
  54620a:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  54620e:	03 c6                	add    eax,esi
  546210:	3b 05 e8 5a d0 00    	cmp    eax,DWORD PTR ds:0xd05ae8
  546216:	7e 2c                	jle    0x546244
  546218:	f6 05 14 5b d0 00 01 	test   BYTE PTR ds:0xd05b14,0x1
  54621f:	74 10                	je     0x546231
  546221:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  546225:	2b 05 e8 5a d0 00    	sub    eax,DWORD PTR ds:0xd05ae8
  54622b:	03 c6                	add    eax,esi
  54622d:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  546231:	a1 e8 5a d0 00       	mov    eax,ds:0xd05ae8
  546236:	2b c6                	sub    eax,esi
  546238:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  54623c:	85 c0                	test   eax,eax
  54623e:	0f 8e ea 09 00 00    	jle    0x546c2e
  546244:	3b 3d e4 5a d0 00    	cmp    edi,DWORD PTR ds:0xd05ae4
  54624a:	7d 2c                	jge    0x546278
  54624c:	f6 05 14 5b d0 00 02 	test   BYTE PTR ds:0xd05b14,0x2
  546253:	75 08                	jne    0x54625d
  546255:	8b 2d e4 5a d0 00    	mov    ebp,DWORD PTR ds:0xd05ae4
  54625b:	2b ef                	sub    ebp,edi
  54625d:	8b 1d e4 5a d0 00    	mov    ebx,DWORD PTR ds:0xd05ae4
  546263:	29 5c 24 14          	sub    DWORD PTR [esp+0x14],ebx
  546267:	01 7c 24 14          	add    DWORD PTR [esp+0x14],edi
  54626b:	8b fb                	mov    edi,ebx
  54626d:	83 7c 24 14 00       	cmp    DWORD PTR [esp+0x14],0x0
  546272:	0f 8e b6 09 00 00    	jle    0x546c2e
  546278:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  54627c:	03 c7                	add    eax,edi
  54627e:	3b 05 ec 5a d0 00    	cmp    eax,DWORD PTR ds:0xd05aec
  546284:	7e 29                	jle    0x5462af
  546286:	f6 05 14 5b d0 00 02 	test   BYTE PTR ds:0xd05b14,0x2
  54628d:	74 0d                	je     0x54629c
  54628f:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  546293:	2b 05 ec 5a d0 00    	sub    eax,DWORD PTR ds:0xd05aec
  546299:	8d 2c 38             	lea    ebp,[eax+edi*1]
  54629c:	a1 ec 5a d0 00       	mov    eax,ds:0xd05aec
  5462a1:	2b c7                	sub    eax,edi
  5462a3:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  5462a7:	85 c0                	test   eax,eax
  5462a9:	0f 8e 7f 09 00 00    	jle    0x546c2e
  5462af:	a1 14 5b d0 00       	mov    eax,ds:0xd05b14
  5462b4:	83 e0 01             	and    eax,0x1
  5462b7:	74 08                	je     0x5462c1
  5462b9:	8b 5c 24 10          	mov    ebx,DWORD PTR [esp+0x10]
  5462bd:	8d 74 33 ff          	lea    esi,[ebx+esi*1-0x1]
  5462c1:	f6 05 14 5b d0 00 02 	test   BYTE PTR ds:0xd05b14,0x2
  5462c8:	74 15                	je     0x5462df
  5462ca:	8b 5c 24 14          	mov    ebx,DWORD PTR [esp+0x14]
  5462ce:	8d 7c 3b ff          	lea    edi,[ebx+edi*1-0x1]
  5462d2:	8b 1d 08 5b d0 00    	mov    ebx,DWORD PTR ds:0xd05b08
  5462d8:	8b 5b 0c             	mov    ebx,DWORD PTR [ebx+0xc]
  5462db:	f7 db                	neg    ebx
  5462dd:	eb 09                	jmp    0x5462e8
  5462df:	8b 1d 08 5b d0 00    	mov    ebx,DWORD PTR ds:0xd05b08
  5462e5:	8b 5b 0c             	mov    ebx,DWORD PTR [ebx+0xc]
  5462e8:	8b 12                	mov    edx,DWORD PTR [edx]
  5462ea:	89 5c 24 20          	mov    DWORD PTR [esp+0x20],ebx
  5462ee:	4d                   	dec    ebp
  5462ef:	78 19                	js     0x54630a
  5462f1:	80 3a 00             	cmp    BYTE PTR [edx],0x0
  5462f4:	74 11                	je     0x546307
  5462f6:	8a 1a                	mov    bl,BYTE PTR [edx]
  5462f8:	84 db                	test   bl,bl
  5462fa:	7e 05                	jle    0x546301
  5462fc:	0f be db             	movsx  ebx,bl
  5462ff:	03 d3                	add    edx,ebx
  546301:	42                   	inc    edx
  546302:	80 3a 00             	cmp    BYTE PTR [edx],0x0
  546305:	75 ef                	jne    0x5462f6
  546307:	42                   	inc    edx
  546308:	eb e4                	jmp    0x5462ee
  54630a:	8b 1d 08 5b d0 00    	mov    ebx,DWORD PTR ds:0xd05b08
  546310:	8b 5b 0c             	mov    ebx,DWORD PTR [ebx+0xc]
  546313:	0f af df             	imul   ebx,edi
  546316:	3b 4c 24 10          	cmp    ecx,DWORD PTR [esp+0x10]
  54631a:	8d 34 73             	lea    esi,[ebx+esi*2]
  54631d:	89 74 24 18          	mov    DWORD PTR [esp+0x18],esi
  546321:	0f 85 dd 01 00 00    	jne    0x546504
  546327:	85 c0                	test   eax,eax
  546329:	0f 85 eb 00 00 00    	jne    0x54641a
  54632f:	ff 4c 24 14          	dec    DWORD PTR [esp+0x14]
  546333:	0f 88 f5 08 00 00    	js     0x546c2e
  546339:	8b 7c 24 18          	mov    edi,DWORD PTR [esp+0x18]
  54633d:	80 3a 00             	cmp    BYTE PTR [edx],0x0
  546340:	0f 84 b7 00 00 00    	je     0x5463fd
  546346:	8a 02                	mov    al,BYTE PTR [edx]
  546348:	84 c0                	test   al,al
  54634a:	7d 0d                	jge    0x546359
  54634c:	0f be c0             	movsx  eax,al
  54634f:	03 c0                	add    eax,eax
  546351:	42                   	inc    edx
  546352:	2b f8                	sub    edi,eax
  546354:	e9 9b 00 00 00       	jmp    0x5463f4
  546359:	0f be f0             	movsx  esi,al
  54635c:	42                   	inc    edx
  54635d:	03 d6                	add    edx,esi
  54635f:	4e                   	dec    esi
  546360:	0f 88 8e 00 00 00    	js     0x5463f4
  546366:	8b 5c 24 34          	mov    ebx,DWORD PTR [esp+0x34]
  54636a:	8a 0d 36 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b36
  546370:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  546374:	83 c7 02             	add    edi,0x2
  546377:	d3 eb                	shr    ebx,cl
  546379:	8a 0d 34 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b34
  54637f:	66 d3 e3             	shl    bx,cl
  546382:	66 23 1d 30 5b d0 00 	and    bx,WORD PTR ds:0xd05b30
  546389:	8a 0d 3e 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b3e
  54638f:	d3 e8                	shr    eax,cl
  546391:	8a 0d 3c 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b3c
  546397:	66 d3 e0             	shl    ax,cl
  54639a:	66 23 05 38 5b d0 00 	and    ax,WORD PTR ds:0xd05b38
  5463a1:	8a 0d 46 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b46
  5463a7:	66 0b d8             	or     bx,ax
  5463aa:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  5463ae:	d3 e8                	shr    eax,cl
  5463b0:	8a 0d 44 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b44
  5463b6:	66 d3 e0             	shl    ax,cl
  5463b9:	66 23 05 40 5b d0 00 	and    ax,WORD PTR ds:0xd05b40
  5463c0:	8a 0d 2e 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b2e
  5463c6:	66 0b d8             	or     bx,ax
  5463c9:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  5463cd:	d3 e8                	shr    eax,cl
  5463cf:	8a 0d 2c 5b d0 00    	mov    cl,BYTE PTR ds:0xd05b2c
  5463d5:	66 d3 e0             	shl    ax,cl
  5463d8:	66 23 05 28 5b d0 00 	and    ax,WORD PTR ds:0xd05b28
  5463df:	8b 0d 24 5b d0 00    	mov    ecx,DWORD PTR ds:0xd05b24
  5463e5:	66 0b d8             	or     bx,ax
  5463e8:	4e                   	dec    esi
  5463e9:	66 89 5c 39 fe       	mov    WORD PTR [ecx+edi*1-0x2],bx
  5463ee:	0f 89 72 ff ff ff    	jns    0x546366
  5463f4:	80 3a 00             	cmp    BYTE PTR [edx],0x0
  5463f7:	0f 85 49 ff ff ff    	jne    0x546346
  5463fd:	42                   	inc    edx
  5463fe:	8b 74 24 20          	mov    esi,DWORD PTR [esp+0x20]
  546402:	01 74 24 18          	add    DWORD PTR [esp+0x18],esi
  546406:	ff 4c 24 14          	dec    DWORD PTR [esp+0x14]
  54640a:	0f 89 29 ff ff ff    	jns    0x546339
  546410:	5d                   	pop    ebp
  546411:	5f                   	pop    edi
  546412:	5e                   	pop    esi
  546413:	5b                   	pop    ebx
  546414:	83 c4 14             	add    esp,0x14
  546417:	c2 14 00             	ret    0x14
