
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004b1850 <.text+0xb0850>:
  4b1850:	53                   	push   ebx
  4b1851:	56                   	push   esi
  4b1852:	57                   	push   edi
  4b1853:	8b d9                	mov    ebx,ecx
  4b1855:	8b 54 24 14          	mov    edx,DWORD PTR [esp+0x14]
  4b1859:	55                   	push   ebp
  4b185a:	8b 6c 24 1c          	mov    ebp,DWORD PTR [esp+0x1c]
  4b185e:	8b 74 24 14          	mov    esi,DWORD PTR [esp+0x14]
  4b1862:	8d bc 93 0c 01 00 00 	lea    edi,[ebx+edx*4+0x10c]
  4b1869:	8d 0c ad 00 00 00 00 	lea    ecx,[ebp*4+0x0]
  4b1870:	c1 e9 02             	shr    ecx,0x2
  4b1873:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  4b1875:	83 3d 44 dc 5c 00 00 	cmp    DWORD PTR ds:0x5cdc44,0x0
  4b187c:	75 3e                	jne    0x4b18bc
  4b187e:	8d 8b 0f 01 00 00    	lea    ecx,[ebx+0x10f]
  4b1884:	b8 0a 00 00 00       	mov    eax,0xa
  4b1889:	c6 01 40             	mov    BYTE PTR [ecx],0x40
  4b188c:	83 c1 04             	add    ecx,0x4
  4b188f:	48                   	dec    eax
  4b1890:	75 f7                	jne    0x4b1889
  4b1892:	8d 8b 37 01 00 00    	lea    ecx,[ebx+0x137]
  4b1898:	b8 ec 00 00 00       	mov    eax,0xec
  4b189d:	c6 01 41             	mov    BYTE PTR [ecx],0x41
  4b18a0:	83 c1 04             	add    ecx,0x4
  4b18a3:	48                   	dec    eax
  4b18a4:	75 f7                	jne    0x4b189d
  4b18a6:	8d 83 e7 04 00 00    	lea    eax,[ebx+0x4e7]
  4b18ac:	b9 0a 00 00 00       	mov    ecx,0xa
  4b18b1:	c6 00 40             	mov    BYTE PTR [eax],0x40
  4b18b4:	83 c0 04             	add    eax,0x4
  4b18b7:	49                   	dec    ecx
  4b18b8:	75 f7                	jne    0x4b18b1
  4b18ba:	eb 22                	jmp    0x4b18de
  4b18bc:	8d 8b 13 01 00 00    	lea    ecx,[ebx+0x113]
  4b18c2:	b8 fe 00 00 00       	mov    eax,0xfe
  4b18c7:	c6 83 0f 01 00 00 40 	mov    BYTE PTR [ebx+0x10f],0x40
  4b18ce:	c6 01 41             	mov    BYTE PTR [ecx],0x41
  4b18d1:	83 c1 04             	add    ecx,0x4
  4b18d4:	48                   	dec    eax
  4b18d5:	75 f7                	jne    0x4b18ce
  4b18d7:	c6 83 0b 05 00 00 40 	mov    BYTE PTR [ebx+0x50b],0x40
  4b18de:	8d b3 0c 01 00 00    	lea    esi,[ebx+0x10c]
  4b18e4:	bf 28 55 d0 00       	mov    edi,0xd05528
  4b18e9:	b9 00 01 00 00       	mov    ecx,0x100
  4b18ee:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
