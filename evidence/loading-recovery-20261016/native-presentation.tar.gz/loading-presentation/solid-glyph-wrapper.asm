
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

0052c300 <.text+0x12b300>:
  52c300:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  52c304:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  52c308:	8b 54 24 0c          	mov    edx,DWORD PTR [esp+0xc]
  52c30c:	50                   	push   eax
  52c30d:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  52c311:	51                   	push   ecx
  52c312:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  52c316:	52                   	push   edx
  52c317:	50                   	push   eax
  52c318:	8b 15 f0 5a d0 00    	mov    edx,DWORD PTR ds:0xd05af0
  52c31e:	51                   	push   ecx
  52c31f:	8b 02                	mov    eax,DWORD PTR [edx]
  52c321:	8b ca                	mov    ecx,edx
  52c323:	ff 50 3c             	call   DWORD PTR [eax+0x3c]
  52c326:	c3                   	ret
