
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

0049a630 <.text+0x99630>:
  49a630:	53                   	push   ebx
  49a631:	56                   	push   esi
  49a632:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
  49a636:	57                   	push   edi
  49a637:	33 ff                	xor    edi,edi
  49a639:	66 39 3e             	cmp    WORD PTR [esi],di
  49a63c:	74 29                	je     0x49a667
  49a63e:	33 db                	xor    ebx,ebx
  49a640:	66 8b 1e             	mov    bx,WORD PTR [esi]
  49a643:	e8 c8 8b ff ff       	call   0x493210
  49a648:	53                   	push   ebx
  49a649:	85 c0                	test   eax,eax
  49a64b:	74 07                	je     0x49a654
  49a64d:	e8 7e 81 fb ff       	call   0x4527d0
  49a652:	eb 05                	jmp    0x49a659
  49a654:	e8 b7 d4 08 00       	call   0x527b10
  49a659:	83 c4 04             	add    esp,0x4
  49a65c:	03 f8                	add    edi,eax
  49a65e:	83 c6 02             	add    esi,0x2
  49a661:	66 83 3e 00          	cmp    WORD PTR [esi],0x0
  49a665:	75 d7                	jne    0x49a63e
  49a667:	8b c7                	mov    eax,edi
  49a669:	5f                   	pop    edi
  49a66a:	5e                   	pop    esi
  49a66b:	5b                   	pop    ebx
  49a66c:	c3                   	ret
