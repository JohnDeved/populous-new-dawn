
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00527a30 <.text+0x126a30>:
  527a30:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  527a34:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  527a38:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  527a3c:	8d 0c c8             	lea    ecx,[eax+ecx*8]
  527a3f:	33 c0                	xor    eax,eax
  527a41:	66 8b 81 04 ff ff ff 	mov    ax,WORD PTR [ecx-0xfc]
  527a48:	89 02                	mov    DWORD PTR [edx],eax
  527a4a:	33 c0                	xor    eax,eax
  527a4c:	66 8b 81 06 ff ff ff 	mov    ax,WORD PTR [ecx-0xfa]
  527a53:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  527a56:	c3                   	ret
  527a57:	cc                   	int3
  527a58:	cc                   	int3
  527a59:	cc                   	int3
  527a5a:	cc                   	int3
  527a5b:	cc                   	int3
  527a5c:	cc                   	int3
  527a5d:	cc                   	int3
  527a5e:	cc                   	int3
  527a5f:	cc                   	int3
