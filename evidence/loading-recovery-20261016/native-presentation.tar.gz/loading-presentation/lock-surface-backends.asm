
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

005281c0 <.text+0x1271c0>:
  5281c0:	8b 4c 24 04          	mov    ecx,DWORD PTR [esp+0x4]
  5281c4:	85 c9                	test   ecx,ecx
  5281c6:	0f 84 a9 00 00 00    	je     0x528275
  5281cc:	8d 41 18             	lea    eax,[ecx+0x18]
  5281cf:	a3 08 5b d0 00       	mov    ds:0xd05b08,eax
  5281d4:	8b 10                	mov    edx,DWORD PTR [eax]
  5281d6:	89 15 24 5b d0 00    	mov    DWORD PTR ds:0xd05b24,edx
  5281dc:	8b 01                	mov    eax,DWORD PTR [ecx]
  5281de:	a3 14 5b d0 00       	mov    ds:0xd05b14,eax
  5281e3:	6a 00                	push   0x0
  5281e5:	8b 51 04             	mov    edx,DWORD PTR [ecx+0x4]
  5281e8:	89 15 48 5b d0 00    	mov    DWORD PTR ds:0xd05b48,edx
  5281ee:	8b 41 08             	mov    eax,DWORD PTR [ecx+0x8]
  5281f1:	a3 0c 5b d0 00       	mov    ds:0xd05b0c,eax
  5281f6:	8b 49 0c             	mov    ecx,DWORD PTR [ecx+0xc]
  5281f9:	89 0d d8 5a d0 00    	mov    DWORD PTR ds:0xd05ad8,ecx
  5281ff:	e8 dc fc ff ff       	call   0x527ee0
  528204:	83 c4 04             	add    esp,0x4
  528207:	8b 0d 08 5b d0 00    	mov    ecx,DWORD PTR ds:0xd05b08
  52820d:	8b 41 20             	mov    eax,DWORD PTR [ecx+0x20]
  528210:	83 e8 08             	sub    eax,0x8
  528213:	83 f8 18             	cmp    eax,0x18
  528216:	77 0f                	ja     0x528227
  528218:	33 c9                	xor    ecx,ecx
  52821a:	8a 88 94 82 52 00    	mov    cl,BYTE PTR [eax+0x528294]
  528220:	ff 24 8d 80 82 52 00 	jmp    DWORD PTR [ecx*4+0x528280]
  528227:	c7 05 f0 5a d0 00 10 	mov    DWORD PTR ds:0xd05af0,0xd05b10
  52822e:	5b d0 00 
  528231:	eb 2e                	jmp    0x528261
  528233:	c7 05 f0 5a d0 00 10 	mov    DWORD PTR ds:0xd05af0,0xd05b10
  52823a:	5b d0 00 
  52823d:	eb 22                	jmp    0x528261
  52823f:	c7 05 f0 5a d0 00 18 	mov    DWORD PTR ds:0xd05af0,0xd05b18
  528246:	5b d0 00 
  528249:	eb 16                	jmp    0x528261
  52824b:	c7 05 f0 5a d0 00 1c 	mov    DWORD PTR ds:0xd05af0,0xd05b1c
  528252:	5b d0 00 
  528255:	eb 0a                	jmp    0x528261
  528257:	c7 05 f0 5a d0 00 20 	mov    DWORD PTR ds:0xd05af0,0xd05b20
  52825e:	5b d0 00 
  528261:	a1 08 5b d0 00       	mov    eax,ds:0xd05b08
  528266:	b9 28 5b d0 00       	mov    ecx,0xd05b28
  52826b:	83 c0 10             	add    eax,0x10
  52826e:	50                   	push   eax
  52826f:	e8 1c eb 01 00       	call   0x546d90
  528274:	c3                   	ret
  528275:	c7 05 08 5b d0 00 00 	mov    DWORD PTR ds:0xd05b08,0x0
  52827c:	00 00 00 
  52827f:	c3                   	ret
