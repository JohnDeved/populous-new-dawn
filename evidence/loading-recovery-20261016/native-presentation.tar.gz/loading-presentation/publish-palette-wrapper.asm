
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004b25a0 <.text+0xb15a0>:
  4b25a0:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b25a6:	85 c9                	test   ecx,ecx
  4b25a8:	74 14                	je     0x4b25be
  4b25aa:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  4b25ae:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  4b25b2:	50                   	push   eax
  4b25b3:	52                   	push   edx
  4b25b4:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  4b25b8:	50                   	push   eax
  4b25b9:	e8 92 f2 ff ff       	call   0x4b1850
  4b25be:	c3                   	ret
