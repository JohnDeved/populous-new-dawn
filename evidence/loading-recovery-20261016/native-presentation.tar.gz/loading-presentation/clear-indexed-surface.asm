
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00529940 <.text+0x128940>:
  529940:	81 ec 84 00 00 00    	sub    esp,0x84
  529946:	c7 44 24 20 64 00 00 	mov    DWORD PTR [esp+0x20],0x64
  52994d:	00 
  52994e:	56                   	push   esi
  52994f:	8b b4 24 8c 00 00 00 	mov    esi,DWORD PTR [esp+0x8c]
  529956:	8b 46 38             	mov    eax,DWORD PTR [esi+0x38]
  529959:	83 e8 08             	sub    eax,0x8
  52995c:	83 f8 18             	cmp    eax,0x18
  52995f:	0f 87 bd 01 00 00    	ja     0x529b22
  529965:	33 c9                	xor    ecx,ecx
  529967:	8a 88 78 9b 52 00    	mov    cl,BYTE PTR [eax+0x529b78]
  52996d:	ff 24 8d 64 9b 52 00 	jmp    DWORD PTR [ecx*4+0x529b64]
  529974:	33 c0                	xor    eax,eax
  529976:	8a 84 24 98 00 00 00 	mov    al,BYTE PTR [esp+0x98]
  52997d:	89 44 24 74          	mov    DWORD PTR [esp+0x74],eax
  529981:	e9 9c 01 00 00       	jmp    0x529b22
  529986:	33 c0                	xor    eax,eax
  529988:	66 89 44 24 0a       	mov    WORD PTR [esp+0xa],ax
  52998d:	66 89 44 24 08       	mov    WORD PTR [esp+0x8],ax
  529992:	89 44 24 04          	mov    DWORD PTR [esp+0x4],eax
  529996:	66 89 44 24 12       	mov    WORD PTR [esp+0x12],ax
  52999b:	66 89 44 24 10       	mov    WORD PTR [esp+0x10],ax
  5299a0:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  5299a4:	8d 4e 28             	lea    ecx,[esi+0x28]
  5299a7:	66 89 44 24 1a       	mov    WORD PTR [esp+0x1a],ax
  5299ac:	51                   	push   ecx
  5299ad:	66 89 44 24 1c       	mov    WORD PTR [esp+0x1c],ax
  5299b2:	8d 4c 24 08          	lea    ecx,[esp+0x8]
  5299b6:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  5299ba:	66 89 44 24 26       	mov    WORD PTR [esp+0x26],ax
  5299bf:	66 89 44 24 24       	mov    WORD PTR [esp+0x24],ax
  5299c4:	89 44 24 20          	mov    DWORD PTR [esp+0x20],eax
  5299c8:	e8 c3 d3 01 00       	call   0x546d90
  5299cd:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [esp+0x94]
  5299d4:	8a 4c 24 1a          	mov    cl,BYTE PTR [esp+0x1a]
  5299d8:	d3 ea                	shr    edx,cl
  5299da:	8a 4c 24 18          	mov    cl,BYTE PTR [esp+0x18]
  5299de:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  5299e5:	d3 e2                	shl    edx,cl
  5299e7:	23 54 24 14          	and    edx,DWORD PTR [esp+0x14]
  5299eb:	8a 4c 24 22          	mov    cl,BYTE PTR [esp+0x22]
  5299ef:	d3 e8                	shr    eax,cl
  5299f1:	8a 4c 24 20          	mov    cl,BYTE PTR [esp+0x20]
  5299f5:	d3 e0                	shl    eax,cl
  5299f7:	23 44 24 1c          	and    eax,DWORD PTR [esp+0x1c]
  5299fb:	8a 4c 24 12          	mov    cl,BYTE PTR [esp+0x12]
  5299ff:	0b d0                	or     edx,eax
  529a01:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  529a08:	d3 e8                	shr    eax,cl
  529a0a:	8a 4c 24 10          	mov    cl,BYTE PTR [esp+0x10]
  529a0e:	d3 e0                	shl    eax,cl
  529a10:	23 44 24 0c          	and    eax,DWORD PTR [esp+0xc]
  529a14:	8a 4c 24 0a          	mov    cl,BYTE PTR [esp+0xa]
  529a18:	0b d0                	or     edx,eax
  529a1a:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  529a21:	d3 e8                	shr    eax,cl
  529a23:	8a 4c 24 08          	mov    cl,BYTE PTR [esp+0x8]
  529a27:	d3 e0                	shl    eax,cl
  529a29:	23 44 24 04          	and    eax,DWORD PTR [esp+0x4]
  529a2d:	0b d0                	or     edx,eax
  529a2f:	0f b7 c2             	movzx  eax,dx
  529a32:	8b c8                	mov    ecx,eax
  529a34:	c1 e1 10             	shl    ecx,0x10
  529a37:	e9 e0 00 00 00       	jmp    0x529b1c
  529a3c:	33 c0                	xor    eax,eax
  529a3e:	66 89 44 24 0a       	mov    WORD PTR [esp+0xa],ax
  529a43:	66 89 44 24 08       	mov    WORD PTR [esp+0x8],ax
  529a48:	89 44 24 04          	mov    DWORD PTR [esp+0x4],eax
  529a4c:	66 89 44 24 12       	mov    WORD PTR [esp+0x12],ax
  529a51:	66 89 44 24 10       	mov    WORD PTR [esp+0x10],ax
  529a56:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  529a5a:	8d 4e 28             	lea    ecx,[esi+0x28]
  529a5d:	66 89 44 24 1a       	mov    WORD PTR [esp+0x1a],ax
  529a62:	51                   	push   ecx
  529a63:	66 89 44 24 1c       	mov    WORD PTR [esp+0x1c],ax
  529a68:	8d 4c 24 08          	lea    ecx,[esp+0x8]
  529a6c:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  529a70:	66 89 44 24 26       	mov    WORD PTR [esp+0x26],ax
  529a75:	66 89 44 24 24       	mov    WORD PTR [esp+0x24],ax
  529a7a:	89 44 24 20          	mov    DWORD PTR [esp+0x20],eax
  529a7e:	e8 0d d3 01 00       	call   0x546d90
  529a83:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [esp+0x94]
  529a8a:	8a 4c 24 1a          	mov    cl,BYTE PTR [esp+0x1a]
  529a8e:	d3 ea                	shr    edx,cl
  529a90:	8a 4c 24 18          	mov    cl,BYTE PTR [esp+0x18]
  529a94:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  529a9b:	d3 e2                	shl    edx,cl
  529a9d:	23 54 24 14          	and    edx,DWORD PTR [esp+0x14]
  529aa1:	8a 4c 24 22          	mov    cl,BYTE PTR [esp+0x22]
  529aa5:	d3 e8                	shr    eax,cl
  529aa7:	8a 4c 24 20          	mov    cl,BYTE PTR [esp+0x20]
  529aab:	d3 e0                	shl    eax,cl
  529aad:	23 44 24 1c          	and    eax,DWORD PTR [esp+0x1c]
  529ab1:	8a 4c 24 12          	mov    cl,BYTE PTR [esp+0x12]
  529ab5:	0b d0                	or     edx,eax
  529ab7:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  529abe:	d3 e8                	shr    eax,cl
  529ac0:	8a 4c 24 10          	mov    cl,BYTE PTR [esp+0x10]
  529ac4:	d3 e0                	shl    eax,cl
  529ac6:	23 44 24 0c          	and    eax,DWORD PTR [esp+0xc]
  529aca:	8a 4c 24 0a          	mov    cl,BYTE PTR [esp+0xa]
  529ace:	0b d0                	or     edx,eax
  529ad0:	8b 84 24 94 00 00 00 	mov    eax,DWORD PTR [esp+0x94]
  529ad7:	d3 e8                	shr    eax,cl
  529ad9:	8a 4c 24 08          	mov    cl,BYTE PTR [esp+0x8]
  529add:	d3 e0                	shl    eax,cl
  529adf:	23 44 24 04          	and    eax,DWORD PTR [esp+0x4]
  529ae3:	0b d0                	or     edx,eax
  529ae5:	89 54 24 74          	mov    DWORD PTR [esp+0x74],edx
  529ae9:	eb 37                	jmp    0x529b22
  529aeb:	33 c9                	xor    ecx,ecx
  529aed:	33 c0                	xor    eax,eax
  529aef:	8a 8c 24 97 00 00 00 	mov    cl,BYTE PTR [esp+0x97]
  529af6:	8a 84 24 95 00 00 00 	mov    al,BYTE PTR [esp+0x95]
  529afd:	c1 e1 10             	shl    ecx,0x10
  529b00:	0b c8                	or     ecx,eax
  529b02:	33 c0                	xor    eax,eax
  529b04:	c1 e1 08             	shl    ecx,0x8
  529b07:	8a 84 24 96 00 00 00 	mov    al,BYTE PTR [esp+0x96]
  529b0e:	c1 e0 10             	shl    eax,0x10
  529b11:	0b c8                	or     ecx,eax
  529b13:	33 c0                	xor    eax,eax
  529b15:	8a 84 24 94 00 00 00 	mov    al,BYTE PTR [esp+0x94]
  529b1c:	0b c8                	or     ecx,eax
  529b1e:	89 4c 24 74          	mov    DWORD PTR [esp+0x74],ecx
  529b22:	8b 4e 4c             	mov    ecx,DWORD PTR [esi+0x4c]
  529b25:	8d 44 24 24          	lea    eax,[esp+0x24]
  529b29:	50                   	push   eax
  529b2a:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [esp+0xa0]
  529b31:	8b 94 24 94 00 00 00 	mov    edx,DWORD PTR [esp+0x94]
  529b38:	35 00 00 00 01       	xor    eax,0x1000000
  529b3d:	8b 31                	mov    esi,DWORD PTR [ecx]
  529b3f:	0d 00 04 00 00       	or     eax,0x400
  529b44:	50                   	push   eax
  529b45:	6a 00                	push   0x0
  529b47:	6a 00                	push   0x0
  529b49:	52                   	push   edx
  529b4a:	51                   	push   ecx
  529b4b:	ff 56 14             	call   DWORD PTR [esi+0x14]
  529b4e:	5e                   	pop    esi
  529b4f:	83 f8 01             	cmp    eax,0x1
  529b52:	b8 00 00 00 00       	mov    eax,0x0
  529b57:	83 d0 ff             	adc    eax,0xffffffff
  529b5a:	81 c4 84 00 00 00    	add    esp,0x84
  529b60:	c3                   	ret
