"""Retain only bounded original byte/data excerpts; never run original code."""
from pathlib import Path
import hashlib,importlib.util,json,struct,subprocess
ROOT=Path('/tmp/populous-selector-scene-457'); OUT=Path('/tmp/loading-ui-research'); GAME=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app'); EXE=GAME/'D3DPopTB.exe'
s=importlib.util.spec_from_file_location('reader',ROOT/'scripts/check-static-mission18-sky.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);p=m.PE32(EXE)
ranges={
 'loading-leaf':(0x522c00,0x52316b),
 'font-bank-init':(0x4fd7c0,0x4fda60),
 'font-type':(0x493210,0x49322b),
 'measure-string':(0x49a630,0x49a66d),
 'select-font-render':(0x516d30,0x516d62),
 'set-text-render':(0x527aa0,0x527b10),
 'western-metrics-software':(0x527a30,0x527a60),
 'western-metrics-gpu':(0x516b80,0x516bb0),
 'render-string':(0x527960,0x5279c6),
 'solid-glyph-dispatch':(0x527a60,0x527a95),
 'solid-glyph-wrapper':(0x52c300,0x52c327),
 'surface-backend-initializers':(0x527c60,0x527ccb),
 'lock-surface-backends':(0x5281c0,0x528280),
 'solid-glyph-16bit':(0x546190,0x54641a),
 'reset-loading-colours':(0x4a32d0,0x4a3330),
 'publish-palette-wrapper':(0x4b25a0,0x4b25bf),
 'publish-system-palette':(0x4b1850,0x4b18f0),
 'read-indexed-text-colour':(0x415f70,0x415fa6),
 'read-indexed-clear-colour':(0x4525d0,0x452606),
 'clear-indexed-surface':(0x529940,0x529b61),
}
records={}
for name,(start,end) in ranges.items():
 raw=p.read(start,end-start);asm=subprocess.check_output(['objdump','-d','-Mintel',f'--start-address={start:#x}',f'--stop-address={end:#x}',str(EXE)])
 (OUT/(name+'.asm')).write_bytes(asm)
 records[name]={'start':f'{start:08x}','endExclusive':f'{end:08x}','bytes':len(raw),'sha256':m.sha256(raw),'fileOffset':p.offset(start,len(raw)),'listingSha256':m.sha256(asm)}
records['data']={}
for name,start,size in [('font-slot1',0x5d5b38,0x30),('font-western-path',0x5d5a88,24),('software-font-vtable',0x591698,16),('gpu-font-vtable',0x5da1f0,16),('16bit-surface-vtable',0x5919f0,64),('surface-depth-dispatch',0x528280,46)]:
 raw=p.read(start,size);records['data'][name]={'start':f'{start:08x}','size':size,'sha256':m.sha256(raw),'hex':raw.hex()}
inputs={}
files={f.relative_to(GAME).as_posix().lower():f for f in GAME.rglob('*') if f.is_file()}
for name in ['D3DPopTB.exe','data/fenew/FEFT20WE.spr','language/lang00.dat','data/loadlog2.dat','data/fenew/fepal1.dat','data/pal0-c.dat','data/plspl0-c.dat']:
 d=files[name.lower()].read_bytes();inputs[name]={'sha256':m.sha256(d),'bytes':len(d)}
 if 'pal' in name: inputs[name]['index0']=list(d[:4])
record={'exeSHA256':m.sha256(p.data),'tool':subprocess.check_output(['objdump','--version']).decode().splitlines()[0], 'python':'Python standard library; retained PE32 reader only', 'readerSha256':m.sha256((ROOT/'scripts/check-static-mission18-sky.py').read_bytes()),'windows':records,'inputs':inputs,'authority':'Static data/disassembly only; no original execution, emulator, Ghidra export or GPU screenshot.'}
(OUT/'static-evidence.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS_STATIC_RETAIN','windows':len(ranges),'inputs':inputs},indent=2))
