
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00527c60 <.text+0x126c60>:
  527c60:	c7 05 10 5b d0 00 b0 	mov    DWORD PTR ds:0xd05b10,0x5919b0
  527c67:	19 59 00 
  527c6a:	c3                   	ret
  527c6b:	cc                   	int3
  527c6c:	cc                   	int3
  527c6d:	cc                   	int3
  527c6e:	cc                   	int3
  527c6f:	cc                   	int3
  527c70:	e9 0b 00 00 00       	jmp    0x527c80
  527c75:	cc                   	int3
  527c76:	cc                   	int3
  527c77:	cc                   	int3
  527c78:	cc                   	int3
  527c79:	cc                   	int3
  527c7a:	cc                   	int3
  527c7b:	cc                   	int3
  527c7c:	cc                   	int3
  527c7d:	cc                   	int3
  527c7e:	cc                   	int3
  527c7f:	cc                   	int3
  527c80:	c7 05 18 5b d0 00 f0 	mov    DWORD PTR ds:0xd05b18,0x5919f0
  527c87:	19 59 00 
  527c8a:	c3                   	ret
  527c8b:	cc                   	int3
  527c8c:	cc                   	int3
  527c8d:	cc                   	int3
  527c8e:	cc                   	int3
  527c8f:	cc                   	int3
  527c90:	e9 0b 00 00 00       	jmp    0x527ca0
  527c95:	cc                   	int3
  527c96:	cc                   	int3
  527c97:	cc                   	int3
  527c98:	cc                   	int3
  527c99:	cc                   	int3
  527c9a:	cc                   	int3
  527c9b:	cc                   	int3
  527c9c:	cc                   	int3
  527c9d:	cc                   	int3
  527c9e:	cc                   	int3
  527c9f:	cc                   	int3
  527ca0:	c7 05 1c 5b d0 00 30 	mov    DWORD PTR ds:0xd05b1c,0x591a30
  527ca7:	1a 59 00 
  527caa:	c3                   	ret
  527cab:	cc                   	int3
  527cac:	cc                   	int3
  527cad:	cc                   	int3
  527cae:	cc                   	int3
  527caf:	cc                   	int3
  527cb0:	e9 0b 00 00 00       	jmp    0x527cc0
  527cb5:	cc                   	int3
  527cb6:	cc                   	int3
  527cb7:	cc                   	int3
  527cb8:	cc                   	int3
  527cb9:	cc                   	int3
  527cba:	cc                   	int3
  527cbb:	cc                   	int3
  527cbc:	cc                   	int3
  527cbd:	cc                   	int3
  527cbe:	cc                   	int3
  527cbf:	cc                   	int3
  527cc0:	c7 05 20 5b d0 00 70 	mov    DWORD PTR ds:0xd05b20,0x591a70
  527cc7:	1a 59 00 
  527cca:	c3                   	ret
