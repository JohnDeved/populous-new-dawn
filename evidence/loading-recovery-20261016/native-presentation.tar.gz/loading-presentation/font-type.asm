
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00493210 <.text+0x92210>:
  493210:	a1 6a bc 89 00       	mov    eax,ds:0x89bc6a
  493215:	83 f8 09             	cmp    eax,0x9
  493218:	7c 05                	jl     0x49321f
  49321a:	83 f8 0b             	cmp    eax,0xb
  49321d:	7e 03                	jle    0x493222
  49321f:	33 c0                	xor    eax,eax
  493221:	c3                   	ret
  493222:	b8 01 00 00 00       	mov    eax,0x1
  493227:	c3                   	ret
  493228:	cc                   	int3
  493229:	cc                   	int3
  49322a:	cc                   	int3
