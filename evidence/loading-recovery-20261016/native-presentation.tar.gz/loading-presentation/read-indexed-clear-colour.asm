
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004525d0 <.text+0x515d0>:
  4525d0:	8a 44 24 04          	mov    al,BYTE PTR [esp+0x4]
  4525d4:	33 d2                	xor    edx,edx
  4525d6:	8a d0                	mov    dl,al
  4525d8:	88 41 04             	mov    BYTE PTR [ecx+0x4],al
  4525db:	8d 04 95 00 00 00 00 	lea    eax,[edx*4+0x0]
  4525e2:	8a 14 95 28 55 d0 00 	mov    dl,BYTE PTR [edx*4+0xd05528]
  4525e9:	88 51 02             	mov    BYTE PTR [ecx+0x2],dl
  4525ec:	8a 90 29 55 d0 00    	mov    dl,BYTE PTR [eax+0xd05529]
  4525f2:	88 51 01             	mov    BYTE PTR [ecx+0x1],dl
  4525f5:	8a 80 2a 55 d0 00    	mov    al,BYTE PTR [eax+0xd0552a]
  4525fb:	c6 41 03 ff          	mov    BYTE PTR [ecx+0x3],0xff
  4525ff:	88 01                	mov    BYTE PTR [ecx],al
  452601:	8b c1                	mov    eax,ecx
  452603:	c2 04 00             	ret    0x4
