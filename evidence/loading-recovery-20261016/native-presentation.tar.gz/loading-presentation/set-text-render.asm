
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00527aa0 <.text+0x126aa0>:
  527aa0:	83 3d 00 09 5e 00 00 	cmp    DWORD PTR ds:0x5e0900,0x0
  527aa7:	56                   	push   esi
  527aa8:	57                   	push   edi
  527aa9:	74 24                	je     0x527acf
  527aab:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  527ab0:	8b 40 04             	mov    eax,DWORD PTR [eax+0x4]
  527ab3:	85 c0                	test   eax,eax
  527ab5:	74 18                	je     0x527acf
  527ab7:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  527abb:	8b 7c 24 0c          	mov    edi,DWORD PTR [esp+0xc]
  527abf:	56                   	push   esi
  527ac0:	8b 0d 04 09 5e 00    	mov    ecx,DWORD PTR ds:0x5e0904
  527ac6:	57                   	push   edi
  527ac7:	51                   	push   ecx
  527ac8:	ff d0                	call   eax
  527aca:	83 c4 0c             	add    esp,0xc
  527acd:	eb 08                	jmp    0x527ad7
  527acf:	8b 7c 24 0c          	mov    edi,DWORD PTR [esp+0xc]
  527ad3:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  527ad7:	89 3d 00 09 5e 00    	mov    DWORD PTR ds:0x5e0900,edi
  527add:	8b 07                	mov    eax,DWORD PTR [edi]
  527adf:	85 c0                	test   eax,eax
  527ae1:	74 21                	je     0x527b04
  527ae3:	56                   	push   esi
  527ae4:	68 04 09 5e 00       	push   0x5e0904
  527ae9:	ff d0                	call   eax
  527aeb:	83 c4 08             	add    esp,0x8
  527aee:	85 c0                	test   eax,eax
  527af0:	74 18                	je     0x527b0a
  527af2:	b8 ff ff ff ff       	mov    eax,0xffffffff
  527af7:	5f                   	pop    edi
  527af8:	c7 05 00 09 5e 00 00 	mov    DWORD PTR ds:0x5e0900,0x0
  527aff:	00 00 00 
  527b02:	5e                   	pop    esi
  527b03:	c3                   	ret
  527b04:	89 35 04 09 5e 00    	mov    DWORD PTR ds:0x5e0904,esi
  527b0a:	33 c0                	xor    eax,eax
  527b0c:	5f                   	pop    edi
  527b0d:	5e                   	pop    esi
  527b0e:	c3                   	ret
  527b0f:	cc                   	int3
