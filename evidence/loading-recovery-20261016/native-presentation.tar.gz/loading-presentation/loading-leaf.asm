
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00522c00 <.text+0x121c00>:
  522c00:	81 ec 1c 01 00 00    	sub    esp,0x11c
  522c06:	a0 40 df 59 00       	mov    al,ds:0x59df40
  522c0b:	80 3d f3 c6 89 00 00 	cmp    BYTE PTR ds:0x89c6f3,0x0
  522c12:	88 44 24 03          	mov    BYTE PTR [esp+0x3],al
  522c16:	53                   	push   ebx
  522c17:	56                   	push   esi
  522c18:	57                   	push   edi
  522c19:	55                   	push   ebp
  522c1a:	0f 84 40 05 00 00    	je     0x523160
  522c20:	83 3d 8c df 5c 00 00 	cmp    DWORD PTR ds:0x5cdf8c,0x0
  522c27:	0f 84 33 05 00 00    	je     0x523160
  522c2d:	80 3d 33 ce 89 00 00 	cmp    BYTE PTR ds:0x89ce33,0x0
  522c34:	74 15                	je     0x522c4b
  522c36:	c6 05 33 ce 89 00 00 	mov    BYTE PTR ds:0x89ce33,0x0
  522c3d:	6a 00                	push   0x0
  522c3f:	6a 00                	push   0x0
  522c41:	6a 00                	push   0x0
  522c43:	e8 b8 9d fd ff       	call   0x4fca00
  522c48:	83 c4 0c             	add    esp,0xc
  522c4b:	80 7c 24 13 00       	cmp    BYTE PTR [esp+0x13],0x0
  522c50:	74 1a                	je     0x522c6c
  522c52:	e8 f9 f9 f8 ff       	call   0x4b2650
  522c57:	50                   	push   eax
  522c58:	e8 03 72 00 00       	call   0x529e60
  522c5d:	c6 05 40 df 59 00 00 	mov    BYTE PTR ds:0x59df40,0x0
  522c64:	83 c4 04             	add    esp,0x4
  522c67:	e8 84 a6 fd ff       	call   0x4fd2f0
  522c6c:	be 02 00 00 00       	mov    esi,0x2
  522c71:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  522c76:	83 b8 c0 00 00 00 00 	cmp    DWORD PTR [eax+0xc0],0x0
  522c7d:	74 05                	je     0x522c84
  522c7f:	be 01 00 00 00       	mov    esi,0x1
  522c84:	83 3d 24 df 59 00 00 	cmp    DWORD PTR ds:0x59df24,0x0
  522c8b:	74 44                	je     0x522cd1
  522c8d:	6a 01                	push   0x1
  522c8f:	a1 24 df 59 00       	mov    eax,ds:0x59df24
  522c94:	50                   	push   eax
  522c95:	e8 36 06 f8 ff       	call   0x4a32d0
  522c9a:	83 c4 08             	add    esp,0x8
  522c9d:	a1 24 df 59 00       	mov    eax,ds:0x59df24
  522ca2:	05 fc 03 00 00       	add    eax,0x3fc
  522ca7:	6a 01                	push   0x1
  522ca9:	68 ff 00 00 00       	push   0xff
  522cae:	50                   	push   eax
  522caf:	e8 ec f8 f8 ff       	call   0x4b25a0
  522cb4:	83 c4 0c             	add    esp,0xc
  522cb7:	a1 24 df 59 00       	mov    eax,ds:0x59df24
  522cbc:	05 f8 03 00 00       	add    eax,0x3f8
  522cc1:	6a 01                	push   0x1
  522cc3:	68 fe 00 00 00       	push   0xfe
  522cc8:	50                   	push   eax
  522cc9:	e8 d2 f8 f8 ff       	call   0x4b25a0
  522cce:	83 c4 0c             	add    esp,0xc
  522cd1:	c7 44 24 28 02 00 00 	mov    DWORD PTR [esp+0x28],0x2
  522cd8:	00 
  522cd9:	e8 72 f9 f8 ff       	call   0x4b2650
  522cde:	8b f8                	mov    edi,eax
  522ce0:	85 ff                	test   edi,edi
  522ce2:	0f 84 d5 03 00 00    	je     0x5230bd
  522ce8:	6a 00                	push   0x0
  522cea:	83 ec 08             	sub    esp,0x8
  522ced:	89 64 24 28          	mov    DWORD PTR [esp+0x28],esp
  522cf1:	6a 00                	push   0x0
  522cf3:	8b 4c 24 2c          	mov    ecx,DWORD PTR [esp+0x2c]
  522cf7:	e8 d4 f8 f2 ff       	call   0x4525d0
  522cfc:	6a 00                	push   0x0
  522cfe:	57                   	push   edi
  522cff:	e8 3c 6c 00 00       	call   0x529940
  522d04:	83 c4 14             	add    esp,0x14
  522d07:	33 c0                	xor    eax,eax
  522d09:	8a 84 24 30 01 00 00 	mov    al,BYTE PTR [esp+0x130]
  522d10:	83 f8 01             	cmp    eax,0x1
  522d13:	0f 85 a4 03 00 00    	jne    0x5230bd
  522d19:	e8 f2 04 f7 ff       	call   0x493210
  522d1e:	85 c0                	test   eax,eax
  522d20:	a1 58 5b 5d 00       	mov    eax,ds:0x5d5b58
  522d25:	8b 48 0c             	mov    ecx,DWORD PTR [eax+0xc]
  522d28:	51                   	push   ecx
  522d29:	74 0a                	je     0x522d35
  522d2b:	e8 10 ee f2 ff       	call   0x451b40
  522d30:	83 c4 04             	add    esp,0x4
  522d33:	eb 0d                	jmp    0x522d42
  522d35:	68 98 16 59 00       	push   0x591698
  522d3a:	e8 f1 3f ff ff       	call   0x516d30
  522d3f:	83 c4 08             	add    esp,0x8
  522d42:	a1 b4 33 97 00       	mov    eax,ds:0x9733b4
  522d47:	8d 4c 24 2c          	lea    ecx,[esp+0x2c]
  522d4b:	50                   	push   eax
  522d4c:	51                   	push   ecx
  522d4d:	e8 6e 88 03 00       	call   0x55b5c0
  522d52:	8d 4c 24 34          	lea    ecx,[esp+0x34]
  522d56:	83 c4 08             	add    esp,0x8
  522d59:	51                   	push   ecx
  522d5a:	e8 d1 78 f7 ff       	call   0x49a630
  522d5f:	83 c4 04             	add    esp,0x4
  522d62:	8b f8                	mov    edi,eax
  522d64:	e8 a7 04 f7 ff       	call   0x493210
  522d69:	6a 41                	push   0x41
  522d6b:	85 c0                	test   eax,eax
  522d6d:	74 07                	je     0x522d76
  522d6f:	e8 7c fa f2 ff       	call   0x4527f0
  522d74:	eb 05                	jmp    0x522d7b
  522d76:	e8 c5 4d 00 00       	call   0x527b40
  522d7b:	83 c4 04             	add    esp,0x4
  522d7e:	8b c8                	mov    ecx,eax
  522d80:	0f bf 05 cf c6 89 00 	movsx  eax,WORD PTR ds:0x89c6cf
  522d87:	2b c7                	sub    eax,edi
  522d89:	99                   	cdq
  522d8a:	2b c2                	sub    eax,edx
  522d8c:	c1 f8 01             	sar    eax,0x1
  522d8f:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  522d93:	0f bf 05 d1 c6 89 00 	movsx  eax,WORD PTR ds:0x89c6d1
  522d9a:	2b c1                	sub    eax,ecx
  522d9c:	99                   	cdq
  522d9d:	2b c2                	sub    eax,edx
  522d9f:	c1 f8 01             	sar    eax,0x1
  522da2:	66 81 3d cf c6 89 00 	cmp    WORD PTR ds:0x89c6cf,0x200
  522da9:	00 02 
  522dab:	8b f8                	mov    edi,eax
  522dad:	75 1d                	jne    0x522dcc
  522daf:	66 81 3d d1 c6 89 00 	cmp    WORD PTR ds:0x89c6d1,0x180
  522db6:	80 01 
  522db8:	75 12                	jne    0x522dcc
  522dba:	e8 41 6b f7 ff       	call   0x499900
  522dbf:	85 c0                	test   eax,eax
  522dc1:	74 09                	je     0x522dcc
  522dc3:	a1 78 90 a6 00       	mov    eax,ds:0xa69078
  522dc8:	01 44 24 14          	add    DWORD PTR [esp+0x14],eax
  522dcc:	ff 05 44 a4 5c 00    	inc    DWORD PTR ds:0x5ca444
  522dd2:	e8 89 a4 fd ff       	call   0x4fd260
  522dd7:	6a 00                	push   0x0
  522dd9:	e8 72 f8 f8 ff       	call   0x4b2650
  522dde:	50                   	push   eax
  522ddf:	e8 ec 6f 00 00       	call   0x529dd0
  522de4:	83 c4 08             	add    esp,0x8
  522de7:	83 f8 01             	cmp    eax,0x1
  522dea:	1a c0                	sbb    al,al
  522dec:	f6 d8                	neg    al
  522dee:	a2 40 df 59 00       	mov    ds:0x59df40,al
  522df3:	e8 58 f8 f8 ff       	call   0x4b2650
  522df8:	50                   	push   eax
  522df9:	e8 c2 53 00 00       	call   0x5281c0
  522dfe:	83 c4 04             	add    esp,0x4
  522e01:	e8 4a f8 f8 ff       	call   0x4b2650
  522e06:	8b 48 24             	mov    ecx,DWORD PTR [eax+0x24]
  522e09:	66 89 0d d5 c6 89 00 	mov    WORD PTR ds:0x89c6d5,cx
  522e10:	e8 3b f8 f8 ff       	call   0x4b2650
  522e15:	8b 48 20             	mov    ecx,DWORD PTR [eax+0x20]
  522e18:	80 3d 40 df 59 00 00 	cmp    BYTE PTR ds:0x59df40,0x0
  522e1f:	66 89 0d d7 c6 89 00 	mov    WORD PTR ds:0x89c6d7,cx
  522e26:	0f 84 91 02 00 00    	je     0x5230bd
  522e2c:	83 3d e8 d8 5c 00 00 	cmp    DWORD PTR ds:0x5cd8e8,0x0
  522e33:	0f 84 ff 00 00 00    	je     0x522f38
  522e39:	0f bf 05 cf c6 89 00 	movsx  eax,WORD PTR ds:0x89c6cf
  522e40:	2d 82 00 00 00       	sub    eax,0x82
  522e45:	99                   	cdq
  522e46:	2b c2                	sub    eax,edx
  522e48:	c1 f8 01             	sar    eax,0x1
  522e4b:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  522e4f:	0f bf 05 d1 c6 89 00 	movsx  eax,WORD PTR ds:0x89c6d1
  522e56:	2d a1 00 00 00       	sub    eax,0xa1
  522e5b:	99                   	cdq
  522e5c:	2b c2                	sub    eax,edx
  522e5e:	c1 f8 01             	sar    eax,0x1
  522e61:	8b f8                	mov    edi,eax
  522e63:	e8 e8 f7 f8 ff       	call   0x4b2650
  522e68:	66 81 3d cf c6 89 00 	cmp    WORD PTR ds:0x89c6cf,0x200
  522e6f:	00 02 
  522e71:	8b 58 18             	mov    ebx,DWORD PTR [eax+0x18]
  522e74:	75 2d                	jne    0x522ea3
  522e76:	66 81 3d d1 c6 89 00 	cmp    WORD PTR ds:0x89c6d1,0x180
  522e7d:	80 01 
  522e7f:	75 22                	jne    0x522ea3
  522e81:	e8 7a 6a f7 ff       	call   0x499900
  522e86:	85 c0                	test   eax,eax
  522e88:	74 19                	je     0x522ea3
  522e8a:	e8 c1 f7 f8 ff       	call   0x4b2650
  522e8f:	0f bf 0d d5 c6 89 00 	movsx  ecx,WORD PTR ds:0x89c6d5
  522e96:	c1 e1 04             	shl    ecx,0x4
  522e99:	8b 40 18             	mov    eax,DWORD PTR [eax+0x18]
  522e9c:	8d 14 49             	lea    edx,[ecx+ecx*2]
  522e9f:	8d 5c 02 40          	lea    ebx,[edx+eax*1+0x40]
  522ea3:	8b ce                	mov    ecx,esi
  522ea5:	8b 15 e8 d8 5c 00    	mov    edx,DWORD PTR ds:0x5cd8e8
  522eab:	0f bf 05 d5 c6 89 00 	movsx  eax,WORD PTR ds:0x89c6d5
  522eb2:	0f af c7             	imul   eax,edi
  522eb5:	0f af 4c 24 18       	imul   ecx,DWORD PTR [esp+0x18]
  522eba:	03 c1                	add    eax,ecx
  522ebc:	8d 0c 18             	lea    ecx,[eax+ebx*1]
  522ebf:	33 db                	xor    ebx,ebx
  522ec1:	39 15 ec d8 5c 00    	cmp    DWORD PTR ds:0x5cd8ec,edx
  522ec7:	76 36                	jbe    0x522eff
  522ec9:	81 fb 82 00 00 00    	cmp    ebx,0x82
  522ecf:	7c 18                	jl     0x522ee9
  522ed1:	33 db                	xor    ebx,ebx
  522ed3:	8b c6                	mov    eax,esi
  522ed5:	0f bf 2d d5 c6 89 00 	movsx  ebp,WORD PTR ds:0x89c6d5
  522edc:	c1 e0 07             	shl    eax,0x7
  522edf:	03 c6                	add    eax,esi
  522ee1:	03 c6                	add    eax,esi
  522ee3:	f7 d8                	neg    eax
  522ee5:	03 c5                	add    eax,ebp
  522ee7:	03 c8                	add    ecx,eax
  522ee9:	80 3a 00             	cmp    BYTE PTR [edx],0x0
  522eec:	74 05                	je     0x522ef3
  522eee:	66 c7 01 ff ff       	mov    WORD PTR [ecx],0xffff
  522ef3:	03 ce                	add    ecx,esi
  522ef5:	42                   	inc    edx
  522ef6:	43                   	inc    ebx
  522ef7:	39 15 ec d8 5c 00    	cmp    DWORD PTR ds:0x5cd8ec,edx
  522efd:	77 ca                	ja     0x522ec9
  522eff:	e8 0c 03 f7 ff       	call   0x493210
  522f04:	6a 41                	push   0x41
  522f06:	85 c0                	test   eax,eax
  522f08:	74 07                	je     0x522f11
  522f0a:	e8 c1 f8 f2 ff       	call   0x4527d0
  522f0f:	eb 05                	jmp    0x522f16
  522f11:	e8 fa 4b 00 00       	call   0x527b10
  522f16:	83 c4 04             	add    esp,0x4
  522f19:	e8 f2 02 f7 ff       	call   0x493210
  522f1e:	6a 41                	push   0x41
  522f20:	85 c0                	test   eax,eax
  522f22:	74 07                	je     0x522f2b
  522f24:	e8 c7 f8 f2 ff       	call   0x4527f0
  522f29:	eb 05                	jmp    0x522f30
  522f2b:	e8 10 4c 00 00       	call   0x527b40
  522f30:	83 c4 04             	add    esp,0x4
  522f33:	2b f8                	sub    edi,eax
  522f35:	83 c7 02             	add    edi,0x2
  522f38:	66 81 3d cf c6 89 00 	cmp    WORD PTR ds:0x89c6cf,0x200
  522f3f:	00 02 
  522f41:	75 1a                	jne    0x522f5d
  522f43:	66 81 3d d1 c6 89 00 	cmp    WORD PTR ds:0x89c6d1,0x180
  522f4a:	80 01 
  522f4c:	75 0f                	jne    0x522f5d
  522f4e:	e8 ad 69 f7 ff       	call   0x499900
  522f53:	85 c0                	test   eax,eax
  522f55:	74 06                	je     0x522f5d
  522f57:	03 3d 7c 90 a6 00    	add    edi,DWORD PTR ds:0xa6907c
  522f5d:	c6 05 9c 48 98 00 fe 	mov    BYTE PTR ds:0x98489c,0xfe
  522f64:	e8 a7 02 f7 ff       	call   0x493210
  522f69:	85 c0                	test   eax,eax
  522f6b:	74 41                	je     0x522fae
  522f6d:	e8 9e 02 f7 ff       	call   0x493210
  522f72:	6a 41                	push   0x41
  522f74:	85 c0                	test   eax,eax
  522f76:	74 07                	je     0x522f7f
  522f78:	e8 73 f8 f2 ff       	call   0x4527f0
  522f7d:	eb 05                	jmp    0x522f84
  522f7f:	e8 bc 4b 00 00       	call   0x527b40
  522f84:	8d 54 24 30          	lea    edx,[esp+0x30]
  522f88:	83 c4 04             	add    esp,0x4
  522f8b:	8a 0d 9c 48 98 00    	mov    cl,BYTE PTR ds:0x98489c
  522f91:	51                   	push   ecx
  522f92:	52                   	push   edx
  522f93:	99                   	cdq
  522f94:	8b cf                	mov    ecx,edi
  522f96:	2b c2                	sub    eax,edx
  522f98:	c1 f8 01             	sar    eax,0x1
  522f9b:	66 2b c8             	sub    cx,ax
  522f9e:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  522fa2:	51                   	push   ecx
  522fa3:	50                   	push   eax
  522fa4:	e8 f7 eb f2 ff       	call   0x451ba0
  522fa9:	83 c4 10             	add    esp,0x10
  522fac:	eb 51                	jmp    0x522fff
  522fae:	e8 5d 02 f7 ff       	call   0x493210
  522fb3:	6a 41                	push   0x41
  522fb5:	85 c0                	test   eax,eax
  522fb7:	74 07                	je     0x522fc0
  522fb9:	e8 32 f8 f2 ff       	call   0x4527f0
  522fbe:	eb 05                	jmp    0x522fc5
  522fc0:	e8 7b 4b 00 00       	call   0x527b40
  522fc5:	83 c4 04             	add    esp,0x4
  522fc8:	8b d8                	mov    ebx,eax
  522fca:	83 ec 08             	sub    esp,0x8
  522fcd:	a0 9c 48 98 00       	mov    al,ds:0x98489c
  522fd2:	89 64 24 28          	mov    DWORD PTR [esp+0x28],esp
  522fd6:	50                   	push   eax
  522fd7:	8b 4c 24 2c          	mov    ecx,DWORD PTR [esp+0x2c]
  522fdb:	e8 90 2f ef ff       	call   0x415f70
  522fe0:	8d 44 24 34          	lea    eax,[esp+0x34]
  522fe4:	8b cf                	mov    ecx,edi
  522fe6:	50                   	push   eax
  522fe7:	8b c3                	mov    eax,ebx
  522fe9:	99                   	cdq
  522fea:	2b c2                	sub    eax,edx
  522fec:	c1 f8 01             	sar    eax,0x1
  522fef:	2b c8                	sub    ecx,eax
  522ff1:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  522ff5:	51                   	push   ecx
  522ff6:	50                   	push   eax
  522ff7:	e8 64 49 00 00       	call   0x527960
  522ffc:	83 c4 14             	add    esp,0x14
  522fff:	c6 05 9c 48 98 00 ff 	mov    BYTE PTR ds:0x98489c,0xff
  523006:	e8 05 02 f7 ff       	call   0x493210
  52300b:	85 c0                	test   eax,eax
  52300d:	74 43                	je     0x523052
  52300f:	e8 fc 01 f7 ff       	call   0x493210
  523014:	6a 41                	push   0x41
  523016:	85 c0                	test   eax,eax
  523018:	74 07                	je     0x523021
  52301a:	e8 d1 f7 f2 ff       	call   0x4527f0
  52301f:	eb 05                	jmp    0x523026
  523021:	e8 1a 4b 00 00       	call   0x527b40
  523026:	8d 54 24 30          	lea    edx,[esp+0x30]
  52302a:	83 c4 04             	add    esp,0x4
  52302d:	8a 0d 9c 48 98 00    	mov    cl,BYTE PTR ds:0x98489c
  523033:	51                   	push   ecx
  523034:	52                   	push   edx
  523035:	99                   	cdq
  523036:	2b c2                	sub    eax,edx
  523038:	c1 f8 01             	sar    eax,0x1
  52303b:	66 2b f8             	sub    di,ax
  52303e:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  523042:	66 47                	inc    di
  523044:	66 40                	inc    ax
  523046:	57                   	push   edi
  523047:	50                   	push   eax
  523048:	e8 53 eb f2 ff       	call   0x451ba0
  52304d:	83 c4 10             	add    esp,0x10
  523050:	eb 51                	jmp    0x5230a3
  523052:	e8 b9 01 f7 ff       	call   0x493210
  523057:	6a 41                	push   0x41
  523059:	85 c0                	test   eax,eax
  52305b:	74 07                	je     0x523064
  52305d:	e8 8e f7 f2 ff       	call   0x4527f0
  523062:	eb 05                	jmp    0x523069
  523064:	e8 d7 4a 00 00       	call   0x527b40
  523069:	83 c4 04             	add    esp,0x4
  52306c:	8b d8                	mov    ebx,eax
  52306e:	83 ec 08             	sub    esp,0x8
  523071:	a0 9c 48 98 00       	mov    al,ds:0x98489c
  523076:	89 64 24 2c          	mov    DWORD PTR [esp+0x2c],esp
  52307a:	50                   	push   eax
  52307b:	8b 4c 24 30          	mov    ecx,DWORD PTR [esp+0x30]
  52307f:	e8 ec 2e ef ff       	call   0x415f70
  523084:	8d 44 24 34          	lea    eax,[esp+0x34]
  523088:	50                   	push   eax
  523089:	8b c3                	mov    eax,ebx
  52308b:	99                   	cdq
  52308c:	2b c2                	sub    eax,edx
  52308e:	c1 f8 01             	sar    eax,0x1
  523091:	2b f8                	sub    edi,eax
  523093:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  523097:	47                   	inc    edi
  523098:	40                   	inc    eax
  523099:	57                   	push   edi
  52309a:	50                   	push   eax
  52309b:	e8 c0 48 00 00       	call   0x527960
  5230a0:	83 c4 14             	add    esp,0x14
  5230a3:	e8 a8 f5 f8 ff       	call   0x4b2650
  5230a8:	50                   	push   eax
  5230a9:	e8 b2 6d 00 00       	call   0x529e60
  5230ae:	c6 05 40 df 59 00 00 	mov    BYTE PTR ds:0x59df40,0x0
  5230b5:	83 c4 04             	add    esp,0x4
  5230b8:	e8 33 a2 fd ff       	call   0x4fd2f0
  5230bd:	66 81 3d cf c6 89 00 	cmp    WORD PTR ds:0x89c6cf,0x200
  5230c4:	00 02 
  5230c6:	75 2a                	jne    0x5230f2
  5230c8:	66 81 3d d1 c6 89 00 	cmp    WORD PTR ds:0x89c6d1,0x180
  5230cf:	80 01 
  5230d1:	75 1f                	jne    0x5230f2
  5230d3:	e8 28 68 f7 ff       	call   0x499900
  5230d8:	85 c0                	test   eax,eax
  5230da:	74 16                	je     0x5230f2
  5230dc:	6a 00                	push   0x0
  5230de:	68 90 90 a6 00       	push   0xa69090
  5230e3:	68 78 90 a6 00       	push   0xa69078
  5230e8:	e8 13 80 00 00       	call   0x52b100
  5230ed:	83 c4 0c             	add    esp,0xc
  5230f0:	eb 0a                	jmp    0x5230fc
  5230f2:	6a 00                	push   0x0
  5230f4:	e8 d7 f4 f8 ff       	call   0x4b25d0
  5230f9:	83 c4 04             	add    esp,0x4
  5230fc:	ff 4c 24 28          	dec    DWORD PTR [esp+0x28]
  523100:	0f 85 d3 fb ff ff    	jne    0x522cd9
  523106:	80 7c 24 13 00       	cmp    BYTE PTR [esp+0x13],0x0
  52310b:	74 53                	je     0x523160
  52310d:	ff 05 44 a4 5c 00    	inc    DWORD PTR ds:0x5ca444
  523113:	e8 48 a1 fd ff       	call   0x4fd260
  523118:	6a 00                	push   0x0
  52311a:	e8 31 f5 f8 ff       	call   0x4b2650
  52311f:	50                   	push   eax
  523120:	e8 ab 6c 00 00       	call   0x529dd0
  523125:	83 c4 08             	add    esp,0x8
  523128:	83 f8 01             	cmp    eax,0x1
  52312b:	1a c0                	sbb    al,al
  52312d:	f6 d8                	neg    al
  52312f:	a2 40 df 59 00       	mov    ds:0x59df40,al
  523134:	e8 17 f5 f8 ff       	call   0x4b2650
  523139:	50                   	push   eax
  52313a:	e8 81 50 00 00       	call   0x5281c0
  52313f:	83 c4 04             	add    esp,0x4
  523142:	e8 09 f5 f8 ff       	call   0x4b2650
  523147:	8b 48 24             	mov    ecx,DWORD PTR [eax+0x24]
  52314a:	66 89 0d d5 c6 89 00 	mov    WORD PTR ds:0x89c6d5,cx
  523151:	e8 fa f4 f8 ff       	call   0x4b2650
  523156:	8b 48 20             	mov    ecx,DWORD PTR [eax+0x20]
  523159:	66 89 0d d7 c6 89 00 	mov    WORD PTR ds:0x89c6d7,cx
  523160:	5d                   	pop    ebp
  523161:	5f                   	pop    edi
  523162:	5e                   	pop    esi
  523163:	5b                   	pop    ebx
  523164:	81 c4 1c 01 00 00    	add    esp,0x11c
  52316a:	c3                   	ret
