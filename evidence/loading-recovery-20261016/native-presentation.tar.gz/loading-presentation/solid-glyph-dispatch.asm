
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00527a60 <.text+0x126a60>:
  527a60:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a64:	56                   	push   esi
  527a65:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  527a69:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  527a6d:	8d b4 c8 00 ff ff ff 	lea    esi,[eax+ecx*8-0x100]
  527a74:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  527a78:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  527a7c:	51                   	push   ecx
  527a7d:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a81:	50                   	push   eax
  527a82:	56                   	push   esi
  527a83:	52                   	push   edx
  527a84:	51                   	push   ecx
  527a85:	e8 76 48 00 00       	call   0x52c300
  527a8a:	83 c4 14             	add    esp,0x14
  527a8d:	33 c0                	xor    eax,eax
  527a8f:	66 8b 46 04          	mov    ax,WORD PTR [esi+0x4]
  527a93:	5e                   	pop    esi
  527a94:	c3                   	ret
