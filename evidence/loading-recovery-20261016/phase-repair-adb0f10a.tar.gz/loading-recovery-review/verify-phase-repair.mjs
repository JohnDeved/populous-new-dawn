import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const repo='/tmp/populous-selector-scene-457',base='42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a',head='adb0f10a1142cb9135192da63af756b43dbc035e'
const git=(...args)=>execFileSync('/tmp/selector-scene457/git-bin/git',args,{cwd:repo,encoding:'utf8'}),sha=s=>createHash('sha256').update(s).digest('hex')
const before=git('show',`${base}:app/page.tsx`),after=git('show',`${head}:app/page.tsx`)
const declaration="  const pendingLoadingPhase = startup === 'loading' ? 'restore' : 'loading'\n"
const oldExpression="error ? 'failed' : startup === 'loading' ? 'restore' : 'loading'",newExpression="error ? 'failed' : pendingLoadingPhase"
assert.equal(after,before.replace('  return (\n    <main',declaration+'  return (\n    <main').replace(`phase={${oldExpression}}`,`phase={${newExpression}}`))
assert.deepEqual(git('diff','--name-only',base,head).trim().split('\n'),['app/page.tsx'])
assert.equal(git('rev-parse','HEAD').trim(),head)
assert.equal(git('status','--short'),'')
assert.equal(readFileSync(repo+'/app/page.tsx','utf8'),after)
assert.ok(after.includes("useState<'loading' | 'choice' | 'playing'>('loading')"))
const guard="startup === 'loading' || (startup === 'playing' && (!ready || error))",key="error ? 'failed' : startup"
for(const source of [before,after]){assert.ok(source.includes(`{(${guard}) && (`));assert.ok(source.includes(`key={${key}}`));assert.ok(source.includes('onRetry={retryLoad}'))}
const oldFn=new Function('startup','error','ready',`return {phase:${oldExpression},key:${key},visible:Boolean(${guard})}`)
const newFn=new Function('startup','error','ready',`${declaration}return {phase:${newExpression},key:${key},visible:Boolean(${guard})}`)
const cases=[]
for(const startup of ['loading','choice','playing'])for(const error of [null,'','resource failure'])for(const ready of [false,true]){const oldResult=oldFn(startup,error,ready),newResult=newFn(startup,error,ready);assert.deepEqual(newResult,oldResult);cases.push({startup,error,ready,before:oldResult,after:newResult})}
const result={kind:'independent-exact-phase-refactor-equivalence',at:new Date().toISOString(),status:'passed',base,head,scriptSha256:sha(readFileSync(import.meta.filename)),changedFiles:['app/page.tsx'],statusBefore:git('status','--short'),pageSha256:{base:sha(before),head:sha(after)},exactMechanicalDelta:true,cases,conclusion:['All 18 startup/error/readiness cases preserve phase, visibility and key; error-first precedence is unchanged.','The full page source differs only by one pure local scalar declaration and its substitution into phase. Existing callbacks, hooks, render guard and key are byte-identical. No new function or object is created.','433 files / 2789 tests executed at 42e9e2bc may support this head through this explicit equivalence. They remain old-head executions.','Native/art/DPR/missing-art/rendered evidence is unchanged-source or mechanically-equivalent carry-forward, not new-head execution.','Broader browser wrappers remain failed, and their unvisited lifecycle branches remain unverified.']}
writeFileSync('/tmp/loading-recovery-review/phase-equivalence-adb0f10a.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({status:result.status,head,cases:cases.length,scriptSha256:result.scriptSha256}))
