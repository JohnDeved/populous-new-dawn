import {createRoot} from 'react-dom/client'
import Home from '/tmp/populous-selector-scene-457/app/page.tsx'
import '/tmp/populous-selector-scene-457/app/globals.css'
createRoot(document.getElementById('root')!).render(<Home />)
