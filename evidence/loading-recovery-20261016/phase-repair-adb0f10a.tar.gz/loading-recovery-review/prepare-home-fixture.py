from pathlib import Path
import argparse, hashlib, json, subprocess
p=argparse.ArgumentParser(description='Prepare a plain-React entry for the unchanged production Home component.')
p.add_argument('--game-root',required=True)
p.add_argument('--fixture-root',required=True)
a=p.parse_args(); root=Path(a.game_root).resolve(); out=Path(a.fixture_root).resolve()
out.mkdir(parents=True,exist_ok=True)
node=out/'node_modules'
if not node.exists(): node.symlink_to(root/'node_modules',target_is_directory=True)
if node.resolve()!=(root/'node_modules').resolve(): raise SystemExit('Unexpected fixture dependency location')
files={}
for folder in ['app','public']:
 for file in sorted((root/folder).rglob('*')):
  if file.is_file(): files[str(file.relative_to(root))]=hashlib.sha256(file.read_bytes()).hexdigest()
for name in ['package.json','package-lock.json','scripts/browser-game.mjs']:
 files[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
meta={'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceStatus':subprocess.check_output(['git','status','--short'],cwd=root,text=True),'files':files,'limits':['Unchanged production Home, production global CSS and all original assets mounted through a plain React/Vite entry.','Production store, GameScene constructor, async attachment, input listeners and preference ownership are used unchanged.','Only Vinext/Cloudflare/RSC serving and hydration are excluded; this is local browser integration evidence, not deployed framework or remote TLS evidence.','Observation uses the existing browser-game.mjs React-ref discovery; no injected scenes, manual key sets, overwritten callbacks, fake world, or helper substitution.','Headless software rendering does not certify hardware performance or native full-frame parity.']}
(out/'source.json').write_text(json.dumps(meta,indent=2)+'\n')
(out/'package.json').write_text('{"private":true,"type":"module"}\n')
(out/'index.html').write_text('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Actual Home Game options check</title></head><body><div id="root"></div><script type="module" src="/main.tsx"></script></body></html>\n')
(out/'main.tsx').write_text("import {createRoot} from 'react-dom/client'\nimport Home from '"+str(root)+"/app/page.tsx'\nimport '"+str(root)+"/app/globals.css'\ncreateRoot(document.getElementById('root')!).render(<Home />)\n")
print(json.dumps({'sourceCommit':meta['sourceCommit'],'sourceStatus':meta['sourceStatus'],'files':len(files),'fixture':str(out),'limits':meta['limits']},indent=2))
