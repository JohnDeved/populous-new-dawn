from pathlib import Path
import hashlib,json,tarfile,datetime
root=Path('/tmp/loading-recovery-review')
files=[root/name for name in ['phase-review-adb0f10a.md','phase-equivalence-adb0f10a.json','verify-phase-repair.mjs','capture-phase-repair.mjs','prepare-home-fixture.py','phase-browser-adb0f10a.log','broad-wrapper-qualification-42e9e2bc.json','package-phase-repair.py']]
files+=list((root/'phase-browser-adb0f10a').glob('*'))
files+=[root/'phase-fixture-adb0f10a'/name for name in ['main.tsx','index.html','package.json','source.json']]
files=sorted(set(files));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((root/'phase-browser-adb0f10a/receipt.json').read_text());assert sha(root/'capture-phase-repair.mjs')==d['runnerSha256'];eq=json.loads((root/'phase-equivalence-adb0f10a.json').read_text());assert sha(root/'verify-phase-repair.mjs')==eq['scriptSha256']
m={'kind':'independent-loading-phase-repair-supplement','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':d['source']['sourceCommit'],'previousHead':eq['base'],'browserStatus':d['status'],'sourceVerification':d['sourceVerification'],'equivalenceStatus':eq['status'],'equivalenceCases':len(eq['cases']),'files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in files},'priorPacket':{'path':'loading-recovery-browser-evidence-42e9e2bc.tar.gz','sha256':sha(root/'loading-recovery-browser-evidence-42e9e2bc.tar.gz')},'scope':'Bounded phase-refactor review. Prior evidence remains attributed to its original source; see phase-review-adb0f10a.md.'}
mp=root/'phase-packet-manifest-adb0f10a.json';mp.write_text(json.dumps(m,indent=2)+'\n');out=root/'loading-phase-repair-adb0f10a.tar.gz'
with tarfile.open(out,'w:gz')as tar:
 for p in files+[mp]:tar.add(p,arcname='loading-recovery-review/'+str(p.relative_to(root)))
print(json.dumps({'manifest':str(mp),'manifestSha256':sha(mp),'archive':str(out),'archiveSha256':sha(out),'bytes':out.stat().st_size,'files':len(files),'priorPacketSha256':m['priorPacket']['sha256']},indent=2))
