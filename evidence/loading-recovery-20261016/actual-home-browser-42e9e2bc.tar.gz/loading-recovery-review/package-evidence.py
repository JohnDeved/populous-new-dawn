from pathlib import Path
import hashlib,json,tarfile,datetime
root=Path('/tmp/loading-recovery-review');folders=['baseline','final-core-42e9e2bc','final-dpr-42e9e2bc','final-missing-42e9e2bc','final-repeat-42e9e2bc','final-retry-42e9e2bc','independent-label'];files=[]
for folder in folders:files.extend(p for p in (root/folder).rglob('*')if p.is_file())
for folder in ['baseline-fixture','final-fixture-42e9e2bc']:
 files.extend(root/folder/name for name in ['main.tsx','index.html','package.json','source.json'])
for name in ['README.md','prepare-home-fixture.py','capture-baseline.mjs','capture-final-42e9e2bc.mjs','capture-retry-42e9e2bc.mjs','audit-static.py','static-evidence-audit.json','independent-label-validation.json','package-evidence.py']:files.append(root/name)
files.extend(root.glob('*.log'))
files=sorted(set(files));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();episodes=[]
for folder in folders[:6]:
 p=root/folder/'receipt.json';d=json.loads(p.read_text());runner='capture-baseline.mjs'if folder=='baseline'else'capture-retry-42e9e2bc.mjs'if folder.startswith(('final-repeat','final-retry'))else'capture-final-42e9e2bc.mjs';assert sha(root/runner)==d['runnerSha256'];episodes.append({'path':str(p.relative_to(root)),'status':d['status'],'sourceCommit':d['source']['sourceCommit'],'sourceStatus':d['source']['sourceStatus'],'sourceVerification':d['sourceVerification'],'runner':runner,'runnerSha256':sha(root/runner),'checks':[{'name':c['name'],'status':c['status']}for c in d['checks']],'failure':d.get('failure')})
m={'kind':'independent-loading-recovery-browser-review','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a','base':'4687490198313ccf0f55d85c1cbcbd680d720cea','episodes':episodes,'files':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in files},'scope':'See README.md for source review, exact injections and explicit failed cumulative-activation boundary.'};mp=root/'packet-manifest.json';mp.write_text(json.dumps(m,indent=2)+'\n');out=root/'loading-recovery-browser-evidence-42e9e2bc.tar.gz'
with tarfile.open(out,'w:gz')as tar:
 for p in files+[mp]:tar.add(p,arcname='loading-recovery-review/'+str(p.relative_to(root)))
print(json.dumps({'manifest':str(mp),'manifestSha256':sha(mp),'archive':str(out),'archiveSha256':sha(out),'bytes':out.stat().st_size,'episodes':[{k:e[k]for k in ['path','status']}for e in episodes]},indent=2))
