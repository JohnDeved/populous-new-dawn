from pathlib import Path
import hashlib,importlib.util,json
root=Path('/tmp/populous-selector-scene-457');out=Path('/tmp/loading-ui-research');game=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app');d=json.loads((out/'static-evidence.json').read_text());sp=importlib.util.spec_from_file_location('reader',root/'scripts/check-static-mission18-sky.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);p=m.PE32(game/'D3DPopTB.exe');sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(p.data)==d['exeSHA256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
for name,w in d['windows'].items():
 if name=='data':
  for data in w.values():
   assert p.read(int(data['start'],16),data['size']).hex()==data['hex'];assert sha(bytes.fromhex(data['hex']))==data['sha256']
 else:
  assert sha(p.read(int(w['start'],16),w['bytes']))==w['sha256'];assert sha((out/(name+'.asm')).read_bytes())==w['listingSha256']
files={f.relative_to(game).as_posix().lower():f for f in game.rglob('*')if f.is_file()}
for name,v in d['inputs'].items():assert sha(files[name.lower()].read_bytes())==v['sha256']
r={'status':'passed','exeSha256':sha(p.data),'staticEvidenceSha256':sha((out/'static-evidence.json').read_bytes()),'auditorSha256':sha(Path(__file__).read_bytes()),'codeWindows':len(d['windows'])-1,'dataWindows':len(d['windows']['data']),'inputs':len(d['inputs']),'scope':'Read-only independent byte/listing/input identity check; source semantics reviewed separately. No original code executed.'};Path('/tmp/loading-recovery-review/static-evidence-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
