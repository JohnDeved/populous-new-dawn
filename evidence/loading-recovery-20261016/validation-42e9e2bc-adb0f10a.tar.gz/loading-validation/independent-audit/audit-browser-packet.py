from pathlib import Path
import datetime,hashlib,json,struct,subprocess,tarfile
root=Path('/tmp/loading-recovery-review');repo=Path('/tmp/populous-selector-scene-457');out=Path('/tmp/loading-validation-audit/browser-packet-audit-42e9e2bc.json');git='/tmp/selector-scene457/git-bin/git';mp=root/'packet-manifest.json';archive=root/'loading-recovery-browser-evidence-42e9e2bc.tar.gz';m=json.loads(mp.read_text());errors=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def g(*args):return subprocess.check_output([git,*args],cwd=repo)
def ck(v,message):
 if not v:errors.append(message)
ck(sha(mp)=='3bb638d93a97ffbdd5dc69b76d5a7fa05dd51fc88401a36db070562f0e6a3f5e','Reported manifest hash mismatch');ck(sha(archive)=='8dc3723b89e2818f77dc44d5be0b2e9456b1a4b6fb670a9ad14d83f084bfc830','Reported archive hash mismatch')
for p,d in m['files'].items():
 f=root/p;ck(f.is_file(),'Missing packet file: '+p)
 if f.is_file():ck(sha(f)==d['sha256'],'Packet file hash mismatch: '+p);ck(f.stat().st_size==d['bytes'],'Packet file byte count mismatch: '+p)
with tarfile.open(archive,'r:gz') as t:
 members={x.name.removeprefix('loading-recovery-review/'):x for x in t.getmembers() if x.isfile()};ck(set(members)==set(m['files'])|{'packet-manifest.json'},'Archive file inventory differs from manifest')
 for p,d in m['files'].items():
  if p in members:ck(hashlib.sha256(t.extractfile(members[p]).read()).hexdigest()==d['sha256'],'Archived file hash mismatch: '+p)
 if 'packet-manifest.json' in members:ck(t.extractfile(members['packet-manifest.json']).read()==mp.read_bytes(),'Archived manifest does not match external manifest')
now=g('rev-parse','HEAD').decode().strip();source_audits={};episodes=[]
for e in m['episodes']:
 p=root/e['path'];r=json.loads(p.read_text());source=r['source'];head=source['sourceCommit'];ck(head==e['sourceCommit'],'Episode source label mismatch: '+str(p));ck(r['status']==e['status'],'Episode status label mismatch: '+str(p));ck(source['sourceStatus']==e['sourceStatus'],'Episode source-status label mismatch: '+str(p));ck(r.get('sourceVerification')==e['sourceVerification'],'Episode source verification label mismatch: '+str(p));ck([{'name':x['name'],'status':x['status']} for x in r['checks']]==e['checks'],'Episode check coverage differs: '+str(p));ck(r.get('failure')==e['failure'],'Episode failure label differs: '+str(p))
 runner=root/e['runner'];ck(sha(runner)==r['runnerSha256']==e['runnerSha256'],'Runner linkage mismatch: '+str(p));fixture=Path(r['command']['root']);ck(sha(fixture/'main.tsx')==r['fixtureSha256'],'Fixture entry linkage mismatch: '+str(p));ck(json.loads((fixture/'source.json').read_text())==source,'Fixture source linkage mismatch: '+str(p))
 if head not in source_audits:
  canonical=g('ls-tree','-r','--name-only',head,'--','app','public','package.json','package-lock.json','scripts/browser-game.mjs').decode().splitlines();ck(sorted(canonical)==sorted(source['files']),'Source file inventory mismatch at '+head)
  changed=set(g('diff','--name-only',head,now).decode().splitlines());mismatches=[]
  for f,want in source['files'].items():
   raw=g('show',head+':'+f) if f in changed else (repo/f).read_bytes()
   if hashlib.sha256(raw).hexdigest()!=want:mismatches.append(f)
  ck(not mismatches,'Source fingerprints mismatch at '+head+': '+repr(mismatches));source_audits[head]={'fileCount':len(source['files']),'canonicalCount':len(canonical),'mismatches':mismatches,'method':'Canonical git tree inventory; unchanged blobs hashed from current clean candidate, changed historical blobs read through git show','sourceStatus':source['sourceStatus']}
 captures=[]
 for c in r['captures']:
  cp=p.parent/c['name'];label=str(cp.relative_to(root));ck(label in m['files'],'Screenshot missing from manifest: '+label);raw=cp.read_bytes();ck(raw[:8]==b'\x89PNG\r\n\x1a\n','Not PNG: '+label);w,h=struct.unpack('>II',raw[16:24]);v=c['viewport'];expected=[round(v['width']*v['dpr']),round(v['height']*v['dpr'])];ck([w,h]==expected,'Screenshot dimensions disagree with viewport/DPR label: '+label);captures.append({'path':label,'sha256':sha(cp),'dimensions':[w,h],'viewport':v})
 episodes.append({'path':e['path'],'status':r['status'],'sourceCommit':head,'runner':e['runner'],'checks':e['checks'],'captures':captures,'failure':e['failure']})
ck(g('rev-parse','HEAD').decode().strip()==now,'HEAD changed during packet audit');ck(not g('status','--porcelain').decode(),'Checkout not clean during packet audit')
report={'kind':'independent-browser-packet-bookkeeping-audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'failed' if errors else 'passed','head':m['head'],'base':m['base'],'scriptSha256':sha(__file__),'manifest':str(mp),'manifestSha256':sha(mp),'archive':str(archive),'archiveSha256':sha(archive),'packetFiles':len(m['files']),'archivePrefix':'loading-recovery-review/','auditorCorrection':'Initial audit assumed root-relative archive members; corrected to exact verified loading-recovery-review/ prefix. Original prefix-mismatch audit retained; no source evidence or test outcome changed.','sourceAudit':source_audits,'episodes':episodes,'errors':errors,'limits':['Only evidence identity, coverage labels, source fingerprints, archive contents and screenshot dimensions audited. Native/code/visual assertions remain reviewer-owned.','Baseline accurately records three dirty loading-check scripts excluded from its browser source manifest; app/public and used browser helper hashes match canonical base.','Failed cumulative retry activation attempt retained unchanged. Independent later repeated-key and single-retry episodes do not retroactively pass cumulative activation.','Plain React/Vite production Home fixture excludes deployed Vinext/Cloudflare/RSC/hydration; headless software rendering is not hardware performance or native full-frame fidelity.']}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','packetFiles','manifestSha256','archiveSha256','sourceAudit','errors']},indent=2))
