from pathlib import Path
import argparse,datetime,hashlib,json,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--frozen',required=True);p.add_argument('--root',required=True);p.add_argument('--output',required=True);p.add_argument('--reconciliation');p.add_argument('--repo',default='/tmp/populous-selector-scene-457');p.add_argument('--git',default='/tmp/selector-scene457/git-bin/git');args=p.parse_args()
repo=Path(args.repo);root=Path(args.root);frozen_path=Path(args.frozen);frozen=json.loads(frozen_path.read_text());head=frozen['head'];errors=[];results=[];pending=[];retained=[];recovery=json.loads(Path(args.reconciliation).read_text()) if args.reconciliation else None
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def g(*a):return subprocess.check_output([args.git,*a],cwd=repo)
def check(v,m):
 if not v:errors.append(m)
now={'head':g('rev-parse','HEAD').decode().strip(),'tree':g('rev-parse','HEAD^{tree}').decode().strip(),'status':g('status','--porcelain').decode(),'trackedDiffSha256':hashlib.sha256(g('diff','HEAD','--binary')).hexdigest()}
check(now['head']==head,'Current HEAD differs from frozen candidate')
check(now['tree']==frozen['tree'],'Current tree differs from frozen candidate')
check(not now['status'],'Current checkout is not clean')
check(now['trackedDiffSha256']==frozen['trackedDiffSha256'],'Current tracked diff differs from frozen candidate')
frozen_checks={}
for f,want in frozen['inputs'].items():
 fp=Path(f) if Path(f).is_absolute() else repo/f
 actual=sha(fp) if fp.is_file() else None
 frozen_checks[f]={'expected':want,'actual':actual,'matches':actual==want};check(actual==want,'Frozen input drift: '+f)
for receipt in sorted(root.glob('*.json')):
 d=json.loads(receipt.read_text())
 if d.get('kind')!='pnd-command-receipt':continue
 local=[]
 def chk(v,m):
  if not v:local.append(m)
 source=d.get('source',{});chk(source.get('headOid')==head,'Wrong tested source HEAD');chk(source.get('trackedDiffSha256')==frozen['trackedDiffSha256'],'Tested tracked diff not frozen empty diff');chk(d.get('cwd')==str(repo),'Wrong command cwd')
 ih={}
 for f,want in source.get('inputs',{}).items():
  fp=Path(f) if Path(f).is_absolute() else repo/f;actual=sha(fp) if fp.is_file() else None
  ih[f]={'expected':want,'actual':actual,'matches':actual==want,'frozenExpected':frozen['inputs'].get(f)}
  chk(actual==want,'Explicit input drift: '+f)
  if f in frozen['inputs']:chk(want==frozen['inputs'][f],'Explicit input differs from frozen baseline: '+f)
 for f in ['node_modules/.package-lock.json']:chk(f in ih,'Missing required input: '+f)
 if not receipt.stem.startswith('browser-'):chk(args.git in ih,'Missing wrapper input: '+args.git)
 if receipt.stem.startswith('inventory-'):
  for f in frozen['inputs']:
   if f.endswith('/run-final-inventory.mjs') or '/test-inventory-' in f:chk(f in ih,'Missing inventory input: '+f)
 logs={};counts={};occurrences={}
 if d.get('phase')!='finished':
  if recovery and str(receipt)==recovery['mapping']['originalReceipt']:
   chk(d.get('phase')=='prepared' and d.get('status')=='unknown','Original interruption state changed')
   for kind in ['original','stdout','stderr']:
    snap=recovery[kind];chk(sha(snap['path'])==snap['sha256'],'Original interrupted '+kind+' hash changed')
   retained.append({'path':str(receipt),'status':d.get('status'),'phase':d.get('phase'),'reconciliation':args.reconciliation,'reconciliationSha256':sha(args.reconciliation),'rawSnapshots':{k:recovery[k] for k in ['original','stdout','stderr']}})
  else:pending.append(str(receipt))
 else:
  chk(source==d.get('sourceAfter'),'Source/input fingerprints changed during command')
  for kind in ['stdout','stderr']:
   path=Path(d.get('artifacts',{}).get(kind,''))
   if not path.is_file():chk(False,'Missing raw '+kind);continue
   raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest();txt=raw.decode()
   chk(actual==d.get(kind+'Sha256'),'Raw '+kind+' SHA mismatch');chk(txt==d.get(kind),'Raw '+kind+' does not equal embedded text')
   logs[kind]={'path':str(path),'bytes':len(raw),'sha256':actual}
   if kind=='stdout':
    for label in ['tests','suites','pass','fail','cancelled','skipped','todo']:
     matches=list(re.finditer(r'^(?:#|ℹ) '+label+r' (\d+)\s*$',txt,re.M));occurrences[label]=[int(m.group(1)) for m in matches]
     if matches:counts[label]=int(matches[-1].group(1))
  if d.get('status')=='passed':chk(d.get('exitCode')==0 and d.get('signal') is None,'Passed status inconsistent with exit/signal')
  elif d.get('status')=='failed':chk(d.get('exitCode')!=0 or d.get('signal') is not None or d.get('error') is not None,'Failed status lacks nonzero exit/signal/error')
  else:chk(False,'Terminal command invalidated or unexpected status: '+str(d.get('status')))
 results.append({'path':str(receipt),'sha256':sha(receipt),'runId':d.get('runId'),'command':d.get('command'),'startedAt':d.get('startedAt'),'finishedAt':d.get('finishedAt'),'reportedStatus':d.get('status'),'phase':d.get('phase'),'exitCode':d.get('exitCode'),'signal':d.get('signal'),'integrityStatus':'failed' if local else ('pending' if d.get('phase')!='finished' else 'passed'),'sourceBeforeEqualsAfter':source==d.get('sourceAfter'),'inputs':ih,'wrapperInputRecorded':args.git in ih,'rawLogs':logs,'lastTopLevelCounts':counts,'summaryOccurrences':occurrences,'errors':local})
 errors.extend(str(receipt)+': '+e for e in local)
ids=[r['runId'] for r in results];check(len(ids)==len(set(ids)),'Duplicate receipt run IDs')
report={'kind':'independent-loading-command-receipt-audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditorSha256':sha(__file__),'frozenSnapshot':str(frozen_path),'frozenSha256':sha(frozen_path),'head':head,'sourceNow':now,'frozenInputChecks':frozen_checks,'integrityStatus':'failed' if errors else ('pending' if pending else 'passed'),'reportedOutcomeCounts':dict(__import__('collections').Counter(r['reportedStatus'] for r in results)),'pending':pending,'retainedUnknownInterruptions':retained,'errors':errors,'receipts':results,'substitutions':[],'limits':['Read-only receipt and artifact audit. No tests, builds, browser sessions or original executables were run.','Receipt integrity and command outcome are distinct. Failed results remain failed; diagnostic retries never replace original evidence.','A passed receipt records tool exit/source identity, not independent acceptance of product assertions or advisory findings.','Browser receipts do not record the git-wrapper input; this is disclosed separately and does not erase their retained failures. Inventory and gate receipts require it.']}
Path(args.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['head','integrityStatus','reportedOutcomeCounts','pending','errors']},indent=2));sys.exit(bool(errors))
