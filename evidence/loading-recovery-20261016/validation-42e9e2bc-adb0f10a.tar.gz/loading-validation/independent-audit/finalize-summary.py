from pathlib import Path
import datetime,hashlib,json
p=Path('/tmp/loading-validation-audit');q=json.loads((p/'quality-attribution-final-adb0f10a.json').read_text());a=json.loads((p/'receipts-final-adb0f10a.json').read_text());i=json.loads((p/'inventory-final-42e9e2bc.json').read_text());br=json.loads((p/'browser-packet-audit-42e9e2bc.json').read_text());pr=json.loads((p/'phase-packet-audit-adb0f10a.json').read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
cloud=Path('/tmp/loading-recovery457/cloudflare-adb0f10a-checkrollup-0234.json');c=json.loads(cloud.read_text());assert c['headRefOid']==a['head'];assert all(x['conclusion']=='SUCCESS' for x in c['statusCheckRollup'])
result={'kind':'qualified-independent-loading-validation-aggregate','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditorScope':'Read-only canonical inventory, source/input/receipt integrity, raw-log LAST top-level totals, normalized quality attribution and browser artifact bookkeeping; no tests/build/browser executed by auditor.','implementationHead':i['head'],'repairHead':a['head'],'inventory':{'status':i['status'],'canonicalFiles':i['canonicalFileCount'],'selectedBatches':i['verifiedBatches'],'totals':i['totalsFromLastTopLevelSummaries'],'recovery':i['repairSubstitutions'],'executionSource':'42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a','repairCarryForward':'Reviewer-owned exact mechanical equivalence and18finite cases, not new-head full-suite execution.'},'repairReceipts':{'integrity':a['integrityStatus'],'reportedOutcomes':a['reportedOutcomeCounts'],'gates':[{k:r[k] for k in ['path','command','reportedStatus','exitCode','lastTopLevelCounts','sha256']} for r in a['receipts']]},'quality':{n:{'reportedStatus':r['candidate']['status'],'comparison':r.get('comparison'),'summaryLines':r.get('summaryLines')} for n,r in q['gates'].items()},'browser':{'originalPacketBookkeeping':br['status'],'originalEpisodes':len(br['episodes']),'originalEpisodeOutcomes':[{'path':r['path'],'status':r['status']} for r in br['episodes']],'repairPacketBookkeeping':pr['status'],'repairGroups':len(pr['browserChecks']),'repairSourceFiles':pr['sourceFiles'],'limits':pr['limits']},'canonicalRemoteBuild':{'snapshot':str(cloud),'snapshotSha256':sha(cloud),'head':c['headRefOid'],'checks':c['statusCheckRollup'],'claim':'Retained exact-head canonical Workers check SUCCESS, not local build execution or deployed UI/TLS verification.'},'errors':i['errors']+a['errors']+q['errors']+br['errors']+pr['errors'],'limits':['Original batch24 unknown/prepared after executor transport loss is preserved with exact receipt/partial-log hashes. Explicit distinct recovery covers its exact10files. No silent retry substitution.','Three broad browser wrapper commands failed; lifecycle branches not reached remain not-run. The original cumulative retry activation also failed. Later bounded episodes do not erase these outcomes.','Source/input fingerprints, installed dependency lock and raw stdout/stderr hashes matched before/after all completed command receipts.','Format,ESLint,Oxlint and Fallow-unused remain failed commands; normalized attribution does not convert failures into passes.','Fallow human output is truncated; summary/display identity cannot establish identity of undisplayed diagnostics.','Final docs/evidence commits require unchanged execution-source tree verification and exact-head remote check; those later outcomes are outside this snapshot.']}
(p/'qualified-final-aggregate-adb0f10a.json').write_text(json.dumps(result,indent=2)+'\n')
md='''# Independent loading/recovery validation audit

Repair candidate: `adb0f10a1142cb9135192da63af756b43dbc035e`.
Full inventory execution source: `42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a`.
Canonical base: `4687490198313ccf0f55d85c1cbcbd680d720cea`.

## Result

Evidence integrity checks pass, with the qualifications below. No tests, builds,
browsers, original executables, installs or repository edits were performed by this auditor.
Native/code/visual assertions and merge acceptance remain the reviewer/parent's responsibility.

- Exact canonical inventory: 433 tracked top-level test files, 44 selected batches,
  2,789 passed; zero failed, cancelled, skipped or todo. Totals use the LAST
  unindented top-level summary in every raw output, not intermediate nested totals.
- Original batch 24 remains unknown/prepared after executor transport loss. Its
  receipt and partial stdout/stderr hashes are unchanged. Explicit separately
  recorded recovery passed its exact ten files. No original result was overwritten.
- Repaired head: four focused tests passed, changed-file formatting passed, and
  fresh typecheck, parity and orchestration checks passed. Full inventory remains
  old-head execution; the sole +2/−1 `app/page.tsx` scalar extraction is covered by
  the reviewer's exact-delta/18-case equivalence and a new browser episode.
- All 57 original-head and 11 repaired-head command receipts retain their true
  statuses. Original: 49 passed, seven failed, one retained unknown. Repaired:
  seven passed, four failed. Completed receipt/source/input identities and raw
  stdout/stderr hashes pass; no unexplained drift or active pending receipt remains.

## Quality attribution

Baseline `774af5cd` is independently source/config-equivalent to canonical `46874901`.

- Global formatting still fails only on unchanged `app/viewport-bounds.ts`.
- ESLint: 392 errors unchanged; eight to nine warnings. Two intentional intrinsic
  image warnings in the new loading component replace one former page warning.
- Oxlint: both introduced nested-ternary warnings were repaired. Final 1,434
  diagnostics exactly match baseline file/severity/rule/message/duplicate counts:
  673 errors and 761 warnings. Location-only shifts are excluded from identity.
- Fallow health/dupes commands exit zero; unused exits one. Clone groups remain
  807; 19,156 duplicated lines across 382 files. Dead-code summary counts remain
  99 files, one export, three dependencies, 294 unresolved imports, one unlisted
  dependency and 20 cycles. Health LOC rises 250,419→250,611, threshold findings
  2,702→2,704, churn hotspots 0→1. These changes are preserved. Human output is
  truncated, so undisplayed diagnostics are not claimed identical.

## Browser/build boundaries

- Original packet: 55 files plus manifest independently rehashed; all screenshot
  dimensions agree with viewport/DPR labels; exact baseline 1,105 and candidate
  1,108 source-file inventories verified. Its failed cumulative-activation attempt
  remains failed. The baseline's three dirty helper scripts are accurately recorded.
- Separate repair supplement: 17 files plus manifest, 1,108 production hashes,
  four reported browser groups and 18 equivalence case labels verified. It ends in
  a second intentional failure and makes no new ready-activation claim.
- All three broad wrapper failures remain failed. Unreached restart, Continue,
  checkpoint and stale-atlas branches remain not-run. Narrow passes do not erase
  broader failures or establish their causes.
- Exact repaired-head canonical Workers check is recorded as SUCCESS. There is
  no local build receipt or deployed UI/TLS proof. Plain React/Vite fixture,
  headless/software-rendering and native full-frame limitations remain explicit.

See `qualified-final-aggregate-adb0f10a.json` and the final audit manifest for exact
receipt paths, commands, hashes, failures, source relationships and raw totals.
Clean pre-repair and pre-evidence snapshots establish the audited sources before
later changes. Later documentation/evidence commits still require source-equivalence
and exact-head remote-check verification.
'''
(p/'FINAL-AUDIT.md').write_text(md)
files=['FINAL-AUDIT.md','qualified-final-aggregate-adb0f10a.json','inventory-final-42e9e2bc.json','receipts-final-42e9e2bc.json','receipts-final-adb0f10a.json','quality-attribution-final-42e9e2bc.json','quality-attribution-final-adb0f10a.json','browser-packet-audit-42e9e2bc.json','phase-packet-audit-adb0f10a.json','frozen-inputs-42e9e2bc.json','frozen-inputs-adb0f10a.json','clean-pre-repair-42e9e2bc.json','clean-pre-evidence-adb0f10a.json','inventory-audit.py','audit-receipts.py','compare-quality.py','compare-quality-adb0f10a.py','audit-browser-packet.py','audit-phase-packet.py','finalize-summary.py']
manifest={'kind':'independent-loading-validation-audit-artifacts','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repairHead':a['head'],'files':{f:{'sha256':sha(p/f),'bytes':(p/f).stat().st_size} for f in files}}
(p/'final-audit-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'summary':str(p/'FINAL-AUDIT.md'),'aggregate':str(p/'qualified-final-aggregate-adb0f10a.json'),'manifest':str(p/'final-audit-manifest.json'),'files':len(files),'errors':result['errors']},indent=2))
