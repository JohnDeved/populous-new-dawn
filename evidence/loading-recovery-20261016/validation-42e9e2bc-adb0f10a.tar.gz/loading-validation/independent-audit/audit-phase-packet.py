from pathlib import Path
import datetime,hashlib,json,struct,subprocess,tarfile
root=Path('/tmp/loading-recovery-review');repo=Path('/tmp/populous-selector-scene-457');mp=root/'phase-packet-manifest-adb0f10a.json';arc=root/'loading-phase-repair-adb0f10a.tar.gz';m=json.loads(mp.read_text());errors=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(v,msg):
 if not v:errors.append(msg)
def git(*a):return subprocess.check_output(['/tmp/selector-scene457/git-bin/git',*a],cwd=repo)
ck(sha(mp)=='54719c95e94ef7bcf8c63e07201f5ccc4eb228df1ff47b276c11b6fb1ee5ba40','Manifest hash mismatch');ck(sha(arc)=='5b92bf2087cba297d3d6cf52d336acbd6dfd1d847cee14b409ffd0129cf8bcac','Archive hash mismatch')
for p,d in m['files'].items():ck(sha(root/p)==d['sha256'],'File hash mismatch: '+p);ck((root/p).stat().st_size==d['bytes'],'File byte count mismatch: '+p)
with tarfile.open(arc) as t:
 mem={x.name.removeprefix('loading-recovery-review/'):x for x in t.getmembers() if x.isfile()};ck(set(mem)==set(m['files'])|{mp.name},'Archive inventory differs')
 for p,d in m['files'].items():ck(hashlib.sha256(t.extractfile(mem[p]).read()).hexdigest()==d['sha256'],'Archived hash mismatch: '+p)
 ck(t.extractfile(mem[mp.name]).read()==mp.read_bytes(),'Archived manifest differs')
ck(sha(root/m['priorPacket']['path'])==m['priorPacket']['sha256'],'Original browser packet changed')
rp=root/'phase-browser-adb0f10a/receipt.json';r=json.loads(rp.read_text());s=r['source'];ck(s['sourceCommit']==m['head'],'Browser source head differs');ck(not s['sourceStatus'],'Browser source was not clean');ck(r['status']==m['browserStatus'],'Browser status label differs');ck(r['sourceVerification']==m['sourceVerification'],'Source verification label differs');ck(sha(root/'capture-phase-repair.mjs')==r['runnerSha256'],'Runner linkage differs');fx=Path(r['command']['root']);ck(sha(fx/'main.tsx')==r['fixtureSha256'],'Fixture entry linkage differs');ck(json.loads((fx/'source.json').read_text())==s,'Fixture source differs')
canonical=git('ls-tree','-r','--name-only',m['head'],'--','app','public','package.json','package-lock.json','scripts/browser-game.mjs').decode().splitlines();ck(sorted(canonical)==sorted(s['files']),'Source canonical inventory differs')
mismatches=[p for p,h in s['files'].items() if sha(repo/p)!=h];ck(not mismatches,'Browser source hashes differ: '+repr(mismatches))
captures=[]
for c in r['captures']:
 p=rp.parent/c['name'];raw=p.read_bytes();w,h=struct.unpack('>II',raw[16:24]);v=c['viewport'];ck([w,h]==[round(v['width']*v['dpr']),round(v['height']*v['dpr'])],'Screenshot label dimensions differ: '+str(p));captures.append({'path':str(p),'sha256':sha(p),'dimensions':[w,h],'viewport':v})
ep=root/'phase-equivalence-adb0f10a.json';e=json.loads(ep.read_text());ck(e['status']==m['equivalenceStatus'],'Equivalence status differs');ck(len(e['cases'])==m['equivalenceCases']==18,'Equivalence case coverage label differs');ck(e['scriptSha256']==sha(root/'verify-phase-repair.mjs'),'Equivalence verifier hash differs')
for k,h in [('base',m['previousHead']),('head',m['head'])]:ck(e[k]==h,'Equivalence '+k+' source differs');ck(e['pageSha256'][k]==hashlib.sha256(git('show',h+':app/page.tsx')).hexdigest(),'Equivalence '+k+' page hash differs')
wrappers=json.loads((root/'broad-wrapper-qualification-42e9e2bc.json').read_text())
for w in wrappers['wrappers']:
 d=json.loads(Path(w['path']).read_text());ck(sha(w['path'])==w['sha256'],'Broad-wrapper receipt hash differs');ck(d['status']==w['status']=='failed','Broad-wrapper failure label differs');ck(d['stderr']==w['stderr'],'Broad-wrapper stderr label differs');ck(d['source']==d['sourceAfter'] and d['source']['headOid']==w['sourceHead'],'Broad-wrapper source label differs')
ck(git('rev-parse','HEAD').decode().strip()==m['head'] and not git('status','--porcelain').decode(),'Current source not clean expected repair')
out={'kind':'independent-phase-repair-packet-bookkeeping-audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'failed' if errors else 'passed','head':m['head'],'previousHead':m['previousHead'],'manifestSha256':sha(mp),'archiveSha256':sha(arc),'scriptSha256':sha(__file__),'packetFiles':len(m['files']),'sourceFiles':len(s['files']),'sourceMismatches':mismatches,'browserChecks':[{'name':c['name'],'status':c['status']} for c in r['checks']],'captures':captures,'equivalenceFile':str(ep),'equivalenceSha256':sha(ep),'equivalenceCases':len(e['cases']),'errors':errors,'limits':['Read-only artifact/input/coverage-label verification, no test/build/browser or verifier execution. Native/semantic/visual review remains reviewer-owned.','Four repaired-head browser groups end in a second intentional failure; no ready-activation claim.','Prior2789test executions remain at42e9e2bc with separately reviewed mechanical equivalence, not relabeled repaired-head executions.','All3broad wrapper failures and their unvisited branches remain retained.']};Path('/tmp/loading-validation-audit/phase-packet-audit-adb0f10a.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','packetFiles','sourceFiles','equivalenceCases','errors']},indent=2))
