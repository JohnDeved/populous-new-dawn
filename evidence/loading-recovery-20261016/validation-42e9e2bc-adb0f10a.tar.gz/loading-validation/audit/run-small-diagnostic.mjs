import {createServer} from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/postcss'
import {spawn} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {resolve} from 'node:path'
const repo='/tmp/populous-selector-scene-457',root='/tmp/loading-recovery457/home-fixture',port=4183
const source=JSON.parse(readFileSync(resolve(root,'source.json')))
if(source.sourceStatus)throw Error('Fixture prepared with dirty source')
const names=['small-viewport-diagnostic1']
const output=`work/orchestration/loading-recovery457/${source.sourceCommit.slice(0,8)}`
let server
const run=(command,args)=>new Promise((resolve,reject)=>{
 const child=spawn(command,args,{cwd:repo,env:{...process.env,POPULOUS_URL:`http://127.0.0.1:${port}`},stdio:'inherit'})
 child.on('error',reject);child.on('exit',(code,signal)=>resolve({code,signal}))
})
const results=[]
try{
 server=await createServer({configFile:false,root,publicDir:resolve(repo,'public'),cacheDir:resolve(root,'.vite'),plugins:[react()],css:{postcss:{plugins:[tailwindcss({base:root})]}},server:{host:'127.0.0.1',port,strictPort:true,fs:{allow:[root,repo]}},logLevel:'warn'})
 await server.listen()
 for(const name of names){
  if(name!=='small-viewport-diagnostic1')throw Error('Unknown diagnostic')
  const args=['scripts/orchestration/command-receipt.mjs','--output',`${output}/browser-${name}.json`,'--input',import.meta.filename,'--input',resolve(root,'source.json'),'--input',resolve(root,'main.tsx'),'--input','node_modules/.package-lock.json','--input',process.env.POPULOUS_BROWSER,'--input','/tmp/loading-recovery457/small-viewport-diagnostic.mjs','--input','/tmp/loading-recovery457/small-diagnostic-source.json','--','node','/tmp/loading-recovery457/small-viewport-diagnostic.mjs']
  const result=await run('node',args);results.push({name,...result});if(result.code!==0)process.exitCode=1
 }
}finally{
 await server?.close()
 writeFileSync('/tmp/loading-recovery457/small-viewport-diagnostic-summary.json',JSON.stringify({source,results},null,2)+'\n')
}
