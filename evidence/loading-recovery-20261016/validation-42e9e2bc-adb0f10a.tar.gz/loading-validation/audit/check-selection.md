# Loading/recovery check selection

Source: 42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a.
Canonical base: 4687490198313ccf0f55d85c1cbcbd680d720cea.
Plan: plan-42e9e2bc.txt, generated with npm run orchestration:plan -- --base <canonical base>.

## Explicit treatment of unmapped paths

- app/original-loading-screen.tsx: four focused component/asset tests, complete repository test inventory, TypeScript, quality checks, and independent production Home browser scenarios.
- public/original/loading-label.{png,json} and scripts/import-loading-label.py: original-input hashes, deterministic regeneration, independent PSFB/PNG reconstruction of every pixel, three corrupt-input rejection checks, generated ownership registry, focused output identity test, native geometry and missing-asset browser checks.
- scripts/check-browser-loading-{art,screen,small-viewport}.mjs: full source review of selector/launch migrations; all three executed against the same source-bound production Home fixture. Their terminal failures are retained individually. They are not marked passed by substituting narrower independent scenarios.
- references/loading-recovery-ui.md and evidence/loading-recovery-20261016/native-presentation.tar.gz: structural/ownership checks, independent source-window/input hashing, source review and archive manifests. Documentation itself makes no runtime completion claim.

The page diff changes only an import and the two loading JSX branches. Home request methods, readiness/cancellation effect, store/scene implementation, saved-state logic, pause/time/RNG rules and existing input guards are untouched. The generated plan's broader native/campaign selections arise from shared page/research ownership, not changes to those underlying mechanics. No original executable execution is authorized in this slice. Broad campaign/native execution is not attempted or claimed for this presentation-only change; full portable test inventory remains required.

## Required gates and limits

- The standard check constituents are run separately and source-bound: TypeScript, every tracked tests/*.test.mjs file in the canonical 433-file inventory (44 sequential batches), parity:check and orchestration:check. This resource-bounded decomposition is not reported as a literal successful monolithic npm run check.
- The canonical Cloudflare Workers build on the exact pushed commit provides the production-build result. The known failing local full Vinext/RSC startup/build is not retried, and remote TLS warnings are not bypassed.
- Maintained TypeScript quality gates retain full raw results and compare against the proven source-equivalent canonical baseline. Intrinsic PNG img warnings are explicit new/removed diagnostics; no global suppression or baseline-only claim.
- Independent actual Home browser evidence excludes only framework serving/hydration; real Home, store, scene, lifecycle and assets remain in use. Injected network failures, delayed real IDB-open notification and missing-image requests are labeled. Software rendering does not establish hardware performance or a native full-frame match.
- The independent cumulative two-retry activation crash and all three broader-wrapper failures remain failures. Separate presentation, repeat-failure and fresh successful retry episodes establish only their stated bounded outcomes. Existing checkpoint/restart/Continue/stale-atlas browser assertions that were never reached remain unexecuted in this attempt.

## Broad-wrapper review disposition

The independent reviewer retains bounded presentation ACCEPT with the three broad-wrapper failures disclosed. Two `.world-viewport canvas` matches are the normal battlefield and hidden tooltip; the small-viewport failure selected the battlefield, so selector ambiguity is not established. That wrapper had already detached the loading overlay and clicked Continue anyway before the visibility timeout. No assertion, visibility requirement or timeout was relaxed. A read-only diagnostic adapter was prepared but **not run**, because no concrete merge-blocking presentation risk remained after the independent actual-readiness and recovery evidence. The prepared scripts in this bundle are not execution evidence.

## Interrupted inventory recovery

Executor transport was lost while original batch 24 was prepared. The original session then became unknown; its prepared receipt and raw logs remained stable and are retained as unknown, not failed or passed. Host-wide orphan visibility was unavailable. With this uncertainty recorded, a separate source-read-only recovery attempt reuses the 23 completed batches, writes `inventory-24-recovery1.json` for the exact missing batch, and continues the remaining untouched inventory. The recovery mapping and immutable original/recovery runner hashes are retained. Only terminal selected receipts count toward completed coverage.
