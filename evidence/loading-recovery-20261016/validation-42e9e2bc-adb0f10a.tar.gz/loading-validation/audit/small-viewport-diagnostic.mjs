import {writeFileSync} from 'node:fs'
let diagnosticPage
async function diagnostic(stage) {
 if(!diagnosticPage || diagnosticPage.isClosed()) return
 try {
  const state=await diagnosticPage.evaluate(()=>{
   const main=document.querySelector('main'),rect=e=>JSON.parse(JSON.stringify(e.getBoundingClientRect())),view=e=>({tag:e.tagName,class:e.className,rect:rect(e),style:{display:getComputedStyle(e).display,visibility:getComputedStyle(e).visibility,opacity:getComputedStyle(e).opacity},width:e.width,height:e.height,connected:e.isConnected})
   const scenes=[];let fiber=main?.[Object.keys(main).find(k=>k.startsWith('__reactFiber'))]
   for(;fiber;fiber=fiber.return)for(let h=fiber.memoizedState;h;h=h.next){const s=h.memoizedState?.current;if(s?.renderer?.domElement)scenes.push({started:s.started,disposed:s.disposed,frame:s.frame,previous:s.previous,canvas:view(s.renderer.domElement),world:{level:s.world?.outcome.level,time:s.world?.time,paused:s.world?.paused,inputMask:s.world?.inputMask}})}
   return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},hidden:document.hidden,focus:document.hasFocus(),active:document.activeElement?.outerHTML?.slice(0,500),shell:main&&view(main),viewports:[...document.querySelectorAll('.world-viewport')].map(view),canvases:[...document.querySelectorAll('.world-viewport canvas')].map(view),scenes,body:document.body.innerText.slice(0,4000)}
  })
  writeFileSync('/tmp/loading-recovery457/small-diagnostic-'+stage+'.json',JSON.stringify(state,null,2)+'\n')
  await diagnosticPage.screenshot({path:'/tmp/loading-recovery457/small-diagnostic-'+stage+'.png'})
 }catch(error){writeFileSync('/tmp/loading-recovery457/small-diagnostic-'+stage+'-error.txt',String(error))}
}
import { showAllMissions } from 'file:///tmp/populous-selector-scene-457/scripts/browser-game.mjs'
import assert from 'node:assert/strict'
import { chromium } from '@playwright/test'
import { launchOptions } from 'file:///tmp/populous-selector-scene-457/scripts/local-render/harness.mjs'
import { bindGame } from 'file:///tmp/populous-selector-scene-457/scripts/browser-game.mjs'

const url = process.env.POPULOUS_URL ?? 'http://localhost:3000'
const browser = await chromium.launch({ ...launchOptions(process.env.POPULOUS_BROWSER), headless: !process.argv.includes('--headed') })
try {
  const context = await browser.newContext({ viewport: { width: 800, height: 700 } })
  const page = await context.newPage()
  diagnosticPage = page
  const pageErrors = []
  page.on('pageerror', error => pageErrors.push(error.stack ?? error.message))
  page.on('console', message => {
    if (message.type() === 'error' && !message.text().includes('Failed to load resource'))
      pageErrors.push(message.text())
  })
  let failLandscape = true
  await page.route('**/original/landscape.bin', async route => {
    if (failLandscape) {
      failLandscape = false
      await route.abort('failed')
      return
    }
    await route.continue()
  })
  await page.goto(url, { waitUntil: 'networkidle' })
  await showAllMissions(page)
  const mission = page.getByRole('button', { name: 'Mission 1', exact: true })
  await mission.waitFor()
  await mission.focus()
  await page.keyboard.press('Enter')
  await page.getByRole('heading', { name: 'Loading failed' }).waitFor()

  const retry = page.getByRole('button', { name: 'Try again' })
  const layer = await retry.evaluate(button => {
    const loading = button.closest('.loading-world'),
      desktop = document.querySelector('.desktop-recommendation'),
      rect = button.getBoundingClientRect(),
      top = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2)
    return {
      loadingZ: Number(getComputedStyle(loading).zIndex),
      desktopZ: Number(getComputedStyle(desktop).zIndex),
      retryIsTopTarget: top === button || button.contains(top),
    }
  })
  assert.ok(layer.loadingZ > layer.desktopZ, layer)
  assert.equal(layer.retryIsTopTarget, true, layer)
  await retry.click()
  await page.locator('.loading-world').waitFor({ state: 'detached' })

  const continueAnyway = page.getByRole('button', { name: /Continue anyway/ })
  await continueAnyway.waitFor()
  const desktopTarget = await continueAnyway.evaluate(button => {
    const rect = button.getBoundingClientRect(),
      top = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2)
    return top === button || button.contains(top)
  })
  assert.equal(desktopTarget, true)
  await continueAnyway.click()
  await diagnostic('before-bind')
  await bindGame(page)
  await diagnostic('after-bind')
  assert.equal(await page.evaluate(() => globalThis.testStore.getWorld().outcome.level), 1)
  assert.deepEqual(pageErrors, [])
  await context.close()
  console.log('PASS: <=900px load failure keeps Try again above the desktop recommendation; retry succeeds and Continue anyway becomes pointer-reachable afterward')
} catch (error) {
  await diagnostic('failed')
  throw error
} finally {
  await browser.close()
}
