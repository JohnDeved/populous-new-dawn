import {execFileSync} from 'node:child_process'
import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-selector-scene-457'
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim()
const head=git('rev-parse','HEAD')
if(head!=='adb0f10a1142cb9135192da63af756b43dbc035e'||git('status','--porcelain'))throw Error('Expected clean mechanical repair')
for(const [name,command] of Object.entries({focused:['node','--test','tests/original-loading-screen.test.mjs'],formatChanged:['node_modules/.bin/oxfmt','--check','app/page.tsx','app/original-loading-screen.tsx']})){
 const receipt=runCommandReceipt(root,{output:`work/orchestration/loading-recovery457/${head.slice(0,8)}/${name}.json`,command,inputs:[import.meta.filename,'/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 console.log(`${name}: ${receipt.status}, exit ${receipt.exitCode}`)
 if(receipt.status!=='passed')process.exitCode=1
}
