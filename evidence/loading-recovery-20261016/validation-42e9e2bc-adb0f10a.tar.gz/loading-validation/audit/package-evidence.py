from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
repo=Path('/tmp/populous-selector-scene-457');work=Path('/tmp/loading-recovery457');review=Path('/tmp/loading-recovery-review');audit=Path('/tmp/loading-validation-audit')
git=lambda *a:subprocess.check_output(['/tmp/selector-scene457/git-bin/git',*a],cwd=repo,text=True).strip()
head=git('rev-parse','HEAD');assert head=='adb0f10a1142cb9135192da63af756b43dbc035e'
allowed={'references/loading-recovery-ui.md','decomp/research/loading-art.md'}
assert all(n in allowed or n.startswith('evidence/loading-recovery-20261016/') for n in git('diff','--name-only',head).splitlines())
assert not git('diff',head,'--','app','public','tests','scripts','engineering','package.json','package-lock.json')
output=repo/'evidence/loading-recovery-20261016';files={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),path
 assert name not in files,name
 files[name]=path
for p in (repo/'work/orchestration/loading-recovery457').rglob('*'):
 if p.is_file():add(p,'command-receipts/'+str(p.relative_to(repo/'work/orchestration/loading-recovery457')))
for p in sorted(work.iterdir()):
 if p.is_file() and p.suffix in {'.mjs','.py','.json','.log','.txt','.md'} and not p.name.startswith('pr-') and p.name!='validation-manifest.json':
  add(p,'audit/'+p.name)
audit_manifest=json.loads((audit/'final-audit-manifest.json').read_text())
for name, expected in audit_manifest['files'].items():
 p=audit/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'];add(p,'independent-audit/'+name)
add(audit/'final-audit-manifest.json','independent-audit/final-audit-manifest.json')
for name in ['format','eslint','oxlint','health','dupes','unused']:
 base=repo/'work/orchestration/game-options457/774af5cd';p=base/(name+'.json');add(p,'quality-baseline/'+p.name)
 for p in (base/(name+'.json.artifacts')).rglob('*'):
  if p.is_file():add(p,'quality-baseline/'+str(p.relative_to(base)))
add(Path('/tmp/selector-scene457/git-bin/git'),'provenance/git-wrapper.py')
for n in ['package.json','package-lock.json','wrangler.cloudflare.jsonc','docs/cloudflare-deployment.md']:
 add(repo/n,'provenance/'+n)
manifest={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for name,p in sorted(files.items())}
mp=work/'validation-manifest.json';mp.write_text(json.dumps({'head':head,'files':manifest},indent=2)+'\n')
with tarfile.open(output/'validation-42e9e2bc-adb0f10a.tar.gz','w:gz',compresslevel=9) as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname='loading-validation/'+name,recursive=False)
 tf.add(mp,arcname='loading-validation/manifest.json')
shutil.copy2(review/'loading-recovery-browser-evidence-42e9e2bc.tar.gz',output/'actual-home-browser-42e9e2bc.tar.gz')
shutil.copy2(review/'README.md',output/'independent-browser-review.md')
shutil.copy2(review/'broad-wrapper-qualification-42e9e2bc.json',output/'broad-wrapper-qualification-42e9e2bc.json')
shutil.copy2(review/'loading-phase-repair-adb0f10a.tar.gz',output/'phase-repair-adb0f10a.tar.gz')
shutil.copy2(review/'phase-review-adb0f10a.md',output/'phase-repair-review.md')
shutil.copy2(review/'final-qualified-review-adb0f10a.json',output/'independent-final-review.json')
shutil.copy2(audit/'FINAL-AUDIT.md',output/'independent-validation-audit.md')
for source,name in [('baseline/restore-640x480.png','before-restore-640x480.png'),('baseline/error-640x480.png','before-error-640x480.png'),('final-core-42e9e2bc/restore-640x480.png','restore-640x480.png'),('final-core-42e9e2bc/loading-640x480.png','loading-640x480.png'),('final-core-42e9e2bc/loading-641x481.png','loading-641x481.png'),('final-core-42e9e2bc/error-640x480.png','error-640x480.png'),('final-core-42e9e2bc/error-expanded-640x300.png','error-expanded-640x300.png')]:shutil.copy2(review/source,output/name)
shutil.copy2(work/'cloudflare-42e9e2bc-checkrollup.json',output/'canonical-build-42e9e2bc.json')
shutil.copy2(work/'cloudflare-adb0f10a-checkrollup-0234.json',output/'canonical-build-adb0f10a.json')
identity={'base':'4687490198313ccf0f55d85c1cbcbd680d720cea','applicationHead':head,'fullInventoryHead':'42e9e2bc6b3300685fb3133aebe0e932bb5a9b7a','carryForward':'Only a scalar phase-expression extraction differs. Exact finite-equivalence review and affected tests/browser/gates bind to applicationHead; full inventory remains bound to fullInventoryHead.','trees':{p:git('rev-parse',head+':'+p)for p in ['app','public','tests','scripts','engineering']},'installedDependencyLockSha256':hashlib.sha256((repo/'node_modules/.package-lock.json').read_bytes()).hexdigest(),'reviewSource':json.loads((review/'phase-browser-adb0f10a/receipt.json').read_text())['sourceVerification'],'artifacts':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in output.iterdir()if p.is_file() and p.name not in {'tested-source.json','SHA256SUMS'}}}
(output/'tested-source.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'head':head,'validationFiles':len(files),'output':str(output)},indent=2))
