from pathlib import Path
import hashlib,json
repo=Path('/tmp/populous-selector-scene-457');source=repo/'scripts/check-browser-loading-small-viewport.mjs';raw=source.read_text();out=Path('/tmp/loading-recovery457/small-viewport-diagnostic.mjs')
prefix='''import {writeFileSync} from 'node:fs'
let diagnosticPage
async function diagnostic(stage) {
 if(!diagnosticPage || diagnosticPage.isClosed()) return
 try {
  const state=await diagnosticPage.evaluate(()=>{
   const main=document.querySelector('main'),rect=e=>JSON.parse(JSON.stringify(e.getBoundingClientRect())),view=e=>({tag:e.tagName,class:e.className,rect:rect(e),style:{display:getComputedStyle(e).display,visibility:getComputedStyle(e).visibility,opacity:getComputedStyle(e).opacity},width:e.width,height:e.height,connected:e.isConnected})
   const scenes=[];let fiber=main?.[Object.keys(main).find(k=>k.startsWith('__reactFiber'))]
   for(;fiber;fiber=fiber.return)for(let h=fiber.memoizedState;h;h=h.next){const s=h.memoizedState?.current;if(s?.renderer?.domElement)scenes.push({started:s.started,disposed:s.disposed,frame:s.frame,previous:s.previous,canvas:view(s.renderer.domElement),world:{level:s.world?.outcome.level,time:s.world?.time,paused:s.world?.paused,inputMask:s.world?.inputMask}})}
   return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},hidden:document.hidden,focus:document.hasFocus(),active:document.activeElement?.outerHTML?.slice(0,500),shell:main&&view(main),viewports:[...document.querySelectorAll('.world-viewport')].map(view),canvases:[...document.querySelectorAll('.world-viewport canvas')].map(view),scenes,body:document.body.innerText.slice(0,4000)}
  })
  writeFileSync('/tmp/loading-recovery457/small-diagnostic-'+stage+'.json',JSON.stringify(state,null,2)+'\\n')
  await diagnosticPage.screenshot({path:'/tmp/loading-recovery457/small-diagnostic-'+stage+'.png'})
 }catch(error){writeFileSync('/tmp/loading-recovery457/small-diagnostic-'+stage+'-error.txt',String(error))}
}
'''
adapter=raw.replace("from './browser-game.mjs'",f"from '{(repo/'scripts/browser-game.mjs').as_uri()}'").replace("from './local-render/harness.mjs'",f"from '{(repo/'scripts/local-render/harness.mjs').as_uri()}'")
adapter=adapter.replace('  const page = await context.newPage()','  const page = await context.newPage()\n  diagnosticPage = page')
adapter=adapter.replace('  await bindGame(page)',"  await diagnostic('before-bind')\n  await bindGame(page)\n  await diagnostic('after-bind')")
adapter=adapter.replace('} finally {',"} catch (error) {\n  await diagnostic('failed')\n  throw error\n} finally {")
out.write_text(prefix+adapter)
Path('/tmp/loading-recovery457/small-diagnostic-source.json').write_text(json.dumps({'source':str(source),'sourceSha256':hashlib.sha256(raw.encode()).hexdigest(),'adapter':str(out),'adapterSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changes':['Absolute import paths only.','Read-only DOM/current-scene diagnostics and screenshots immediately before and after existing bindGame, and on failure.','All original assertions/control actions/timeouts unchanged.','Run with bounded Node heap512 as in successful independent Home harness; this does not prove earlier failure cause.']},indent=2)+'\n')
