import {runCommandReceipt} from '/tmp/populous-selector-scene-457/scripts/orchestration/command-receipt.mjs'
const repo='/tmp/populous-selector-scene-457'
for(const [name,command] of [
 ['format',['node_modules/.bin/oxfmt','--check','app/original-options.tsx']],
 ['eslint',['node_modules/.bin/eslint','app/original-options.tsx']],
 ['oxlint',['node_modules/.bin/oxlint','app/original-options.tsx']],
 ['audio-pause',['npm','run','test:focus','--','tests/audio-pause.test.mjs']],
 ['fallow-audit',['node_modules/.bin/fallow','--no-cache','--threads','1','--base','7ab389ce07177c4fcd2a45724d651675c429f29a','--format','json','audit','--gate','all']],
]){
 const result=runCommandReceipt(repo,{output:`work/orchestration/graphics-options/${name}-b675952c.json`,command,inputs:['/workspace/scratch/69fd8163d94e/graphics-options-prep/run-quality.mjs','/tmp/selector-scene457/git-bin/git','node_modules/.package-lock.json']})
 console.log(`${name}: ${result.status}; exit ${result.exitCode}`)
}
