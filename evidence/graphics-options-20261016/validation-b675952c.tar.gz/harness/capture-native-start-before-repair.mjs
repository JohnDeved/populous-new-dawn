import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'
import {pathToFileURL} from 'node:url'
export default async function({page,context,output,root,receipt}) {
 const baseline=process.env.PND_GRAPHICS_BASELINE==='1', mode=process.env.PND_GRAPHICS_MODE??'all', observations=[]
 receipt.observations=observations
 const stage=name=>{receipt.stage=name;writeFileSync(resolve(output,'stage.json'),JSON.stringify({name,at:new Date().toISOString(),observations},null,2)+'\n')}
 const button=name=>page.getByRole('button',{name,exact:true})
 const options=()=>page.locator('[data-original-options]')
 const categoryLabel=category=>category==='Direct3D'&&!baseline?'Direct3D Options':category
 const expected={Graphics:[['Screen Resolution',139],['Sky',169],['Footsteps',199],['Landscape Detail',229],['Quick Defaults',259]],Direct3D:[['Device Selection',139],['Filtering',169]]}
 const initialUrl=page.url(),initialHistory=await page.evaluate(()=>history.length)
 async function settle(){await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))}
 async function inspect(skin,category){
  stage(`${skin}-${category}`);await button(categoryLabel(category)).focus();await page.keyboard.press('Enter');await settle()
  assert.equal(await options().getAttribute('data-category'),category)
  assert.equal(await options().getAttribute('data-skin'),skin)
  const rows=await options().getByRole('note').evaluateAll(elements=>elements.map(el=>({text:el.getAttribute('aria-label'),y:Number.parseFloat(el.style.top),tabIndex:el.tabIndex,tag:el.tagName,interactive:el.querySelector('button,input,select,textarea,a,[tabindex]')!==null,opacity:getComputedStyle(el.querySelector('span')).opacity,font:el.querySelector('i')?.style.backgroundImage,box:el.querySelector('span').getBoundingClientRect().toJSON()})))
  if(!baseline){
   assert.deepEqual(rows.map(row=>[row.text,row.y]),expected[category].map(([name,y])=>[`${name} : <Unavailable>`,y]))
   for(const row of rows){assert.equal(row.tag,'DIV');assert.equal(row.tabIndex,-1);assert.equal(row.interactive,false);assert.equal(Number(row.opacity),skin==='ingame'?.666667:1);assert.match(row.font,skin==='ingame'?/pause-font/:/feft33we/)}
   assert.equal(await options().getByRole('heading',{name:categoryLabel(category),exact:true}).evaluate(el=>el===document.activeElement),true)
   const selected=await options().getByRole('heading',{name:categoryLabel(category),exact:true}).evaluate(el=>({opacity:getComputedStyle(el.querySelector('span')).opacity,font:el.querySelector('i').style.backgroundImage}))
   assert.equal(Number(selected.opacity),1);assert.match(selected.font,skin==='ingame'?/pause-font/:/felo33we/)
   const notice=await options().locator('p').boundingBox();assert.ok(rows.at(-1).box.bottom<=notice.y,'Last row must not overlap compatibility notice')
  }else assert.equal(rows.length,0)
  assert.equal(await options().locator('[aria-label*="Gamma"],[aria-label*="Turns Per Second"],[aria-label*="Reduce Screen"],[aria-label*="Colour Palette"],[aria-label*="Sky Detail"],[aria-label*="Anti-Aliasing"]').count(),0)
  observations.push({skin,category,viewport:page.viewportSize(),dpr:await page.evaluate(()=>devicePixelRatio),rows})
 }
 async function verifyLayout(skin){
  for(const viewport of [{width:640,height:480},{width:1920,height:1080},{width:900,height:360}]){
   await page.setViewportSize(viewport);await settle()
   const boxes=await options().locator('button,[aria-current="page"],[role="note"] > span').evaluateAll(els=>els.map(el=>({label:el.getAttribute('aria-label')??el.parentElement.getAttribute('aria-label'),box:el.getBoundingClientRect().toJSON()})))
   for(const {label,box} of boxes){assert.ok(box.x>=-1&&box.y>=-1&&box.right<=viewport.width+1&&box.bottom<=viewport.height+1,`${skin} clipped ${label}: ${JSON.stringify(box)}`)}
   observations.push({skin,category:await options().getAttribute('data-category'),viewport,boxes})
  }
  await page.setViewportSize({width:1280,height:960});await settle()
 }
 async function exercise(skin){
  await options().and(page.locator('[data-art-ready="true"]')).waitFor()
  await inspect(skin,'Graphics')
  if(skin==='frontend'){await page.mouse.move(-5,-5);await page.screenshot({path:resolve(output,'frontend-graphics-1280x960.png')})}
  if(!baseline)await verifyLayout(skin)
  await inspect(skin,'Direct3D')
  if(skin==='ingame'){await page.mouse.move(-5,-5);await page.screenshot({path:resolve(output,'ingame-direct3d-1280x960.png')})}
  if(!baseline){
   await verifyLayout(skin)
   const cdp=await context.newCDPSession(page)
   await cdp.send('Emulation.setDeviceMetricsOverride',{width:1280,height:960,deviceScaleFactor:2,mobile:false});await settle()
   assert.equal(await page.evaluate(()=>devicePixelRatio),2)
   observations.push({skin,category:'Direct3D',dpr:2,selected:await options().getByRole('heading',{name:'Direct3D Options',exact:true}).boundingBox()})
   await cdp.send('Emulation.clearDeviceMetricsOverride');await cdp.detach()
   await button('Graphics').focus();await page.keyboard.press('Enter');await settle()
   const target=button('Direct3D Options'), box=await target.boundingBox(),span=await target.locator('span').boundingBox()
   assert.ok(box.width>=span.width&&box.x<=span.x&&box.x+box.width>=span.x+span.width)
   await page.mouse.click(box.x+box.width-3,box.y+box.height/2)
   assert.equal(await options().getAttribute('data-category'),'Direct3D')
   assert.equal(await options().getByRole('heading',{name:'Direct3D Options',exact:true}).evaluate(el=>el===document.activeElement),true)
   const tabLabels=[]
   for(let index=0;index<7;index++){await page.keyboard.press('Tab');tabLabels.push(await page.evaluate(()=>document.activeElement.getAttribute('aria-label')??document.activeElement.textContent))}
   assert.equal(tabLabels.some(label=>label?.includes('Unavailable')),false)
   await button('Sound').click();assert.equal(await options().locator('[data-option-key="Direct3D"]').count(),0)
   await button('Game').click();assert.equal(await options().locator('[data-option-key="Direct3D"]').count(),0)
   await button('Graphics').click();await button('Direct3D Options').focus();await page.keyboard.press('Space')
   await button('Browser compatibility and help').click();await page.keyboard.press('Escape')
   assert.equal(await options().getAttribute('data-category'),'Direct3D')
   assert.equal(await button('Browser compatibility and help').evaluate(el=>el===document.activeElement),true)
   observations.push({skin,hitAreaContains245GlyphPixels:true,edgeClickSelected:true,tabLabels,helpEscapePreservedCategory:true})
  }
 }
 await page.setViewportSize({width:1280,height:960})
 if(mode!=='ingame'){
  await button('Options').click();await exercise('frontend')
  await button('Back').click();assert.equal(await button('Options').evaluate(el=>el===document.activeElement),true)
  await button('Options').click();assert.equal(await options().getAttribute('data-category'),'Game');await page.keyboard.press('Escape')
  assert.equal(await button('Options').evaluate(el=>el===document.activeElement),true)
 }
 if(mode==='frontend'){
  await page.route(/\/original\/frontend\/(feft33we|fehi33we|felo33we)\.png$/,route=>route.fulfill({status:200,contentType:'image/png',body:'Deliberately invalid artwork for fallback acceptance'}))
  await page.reload({waitUntil:'domcontentloaded'});await button('Options').click();await button('Graphics').click()
  assert.equal(await options().getAttribute('data-art-ready'),'false')
  for(const [name]of expected.Graphics)assert.equal(await options().getByRole('note',{name:`${name} : <Unavailable>`,exact:true}).innerText(),`${name} : <Unavailable>`)
  await button('Direct3D Options').focus();await page.keyboard.press('Enter')
  assert.equal(await options().getByRole('heading',{name:'Direct3D Options',exact:true}).evaluate(el=>el===document.activeElement),true)
  for(const [name]of expected.Direct3D)assert.equal(await options().getByRole('note',{name:`${name} : <Unavailable>`,exact:true}).innerText(),`${name} : <Unavailable>`)
  await verifyLayout('frontend-fallback');await page.keyboard.press('Escape')
  assert.equal(await button('Options').evaluate(el=>el===document.activeElement),true)
  observations.push({failedArtFallback:true,rowsVisible:true,keyboardNavigation:true})
  assert.deepEqual(receipt.errors,[])
  return {baseline,mode,observations,limits:['Production Home through plain React/Vite, excluding Vinext/Cloudflare/RSC hosting.','Failed-art response injection is confined to this browser test.']}
 }
 const {bindGame}=await import(pathToFileURL(resolve(root,'scripts/browser-game.mjs')).href)
 stage('ordinary-mission1-start-native-size');await page.setViewportSize({width:640,height:480});await button('New Game').click();await button('Start Mission 1').click();await bindGame(page)
 await page.waitForFunction(()=>window.testSceneRef.current.world.flyby.flags&1||!window.testSceneRef.current.world.inputMask)
 stage('mission1-introduction');const skip=page.locator('.skip-introduction');if(await skip.isVisible())await skip.click()
 const guard=page.getByRole('button',{name:/^Continue anyway/});if(await guard.isVisible())await guard.click()
 if(await button('Resume game').isVisible())await button('Resume game').click()
 await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask,null,{timeout:60000})
 receipt.renderer=await page.evaluate(()=>{const gl=window.testSceneRef.current.renderer.getContext(),d=gl.getExtension('WEBGL_debug_renderer_info');return d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER)})
 const wasPaused=await page.evaluate(()=>window.testSceneRef.current.world.paused)
 stage('open-game-settings-keyboard');await button('Game settings').focus();await page.keyboard.press('Enter');await button('Options').click();await page.setViewportSize({width:1280,height:960});await settle()
 await page.evaluate(()=>{
  const main=document.querySelector('main');let fiber=main[Object.keys(main).find(key=>key.startsWith('__reactFiber'))]
  for(;fiber;fiber=fiber.return)for(let hook=fiber.memoizedState;hook;hook=hook.next){const value=hook.memoizedState?.current;if(value&&typeof value.setMusicVolume==='function'&&typeof value.setPaused==='function')window.graphicsAudio=value}
  if(!window.graphicsAudio)throw Error('Production audio ref not found')
  window.graphicsSnapshot=async()=>{const s=window.testSceneRef.current,a=window.graphicsAudio;return {worldHash:[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(s.world))))].map(value=>value.toString(16).padStart(2,'0')).join(''),rng:s.world.randomState,cosmeticRng:s.world.cosmeticRandom.randomState,turn:s.world.turn,time:s.world.time,paused:s.world.paused,modal:s.modalSuspended,camera:JSON.stringify(s.cameraPosition),input:{keys:[...s.keys],pointerButtons:s.pointerButtons,pointerGesture:s.pointerGesture,inputMask:s.world.inputMask},audio:{enabled:a.enabled,paused:a.paused,volume:a.volume,musicVolume:a.musicVolume,randomState:a.randomState,contextState:a.context?.state??null,stored:localStorage.getItem('populous-audio-preferences')}}}
  window.graphicsScene=window.testSceneRef.current;window.graphicsWorld=window.graphicsScene.world
 })
 const frozen=await page.evaluate(()=>window.graphicsSnapshot())
 assert.equal(frozen.paused,true);assert.equal(frozen.modal,true)
 await exercise('ingame')
 const after=await page.evaluate(async()=>{const s=window.testSceneRef.current;return {sameScene:s===window.graphicsScene,sameWorld:s.world===window.graphicsWorld,state:await window.graphicsSnapshot()}})
 assert.equal(after.sameScene,true);assert.equal(after.sameWorld,true);assert.deepEqual(after.state,frozen)
 await page.keyboard.press('Escape');assert.equal(await button('Options').evaluate(el=>el===document.activeElement),true)
 await button('Continue Game').click();await page.locator('dialog[open]').waitFor({state:'hidden'})
 assert.equal(await page.evaluate(()=>window.testSceneRef.current.world.paused),wasPaused)
 assert.equal(await page.evaluate(()=>window.testSceneRef.current.modalSuspended),false)
 await page.waitForFunction(paused=>window.graphicsAudio.paused===paused,wasPaused)
 const closed=await page.evaluate(()=>window.graphicsSnapshot())
 assert.deepEqual(closed.input,frozen.input)
 for(const key of ['enabled','volume','musicVolume','stored'])assert.equal(closed.audio[key],frozen.audio[key])
 assert.equal(closed.audio.paused,wasPaused)
 observations.push({continued:{input:closed.input,audio:closed.audio},audioPauseRestored:true})
 stage('complete-live-mission1-options')
 assert.equal(page.url(),initialUrl);assert.equal(await page.evaluate(()=>history.length),initialHistory)
 assert.deepEqual(receipt.errors,[])
 return {baseline,observations,mission1:{wasPaused,frozen,after,pauseRestored:true},limits:['Actual production Home and GameScene through plain React/Vite serving, excluding Vinext/Cloudflare/RSC hosting.','Sandboxed headless software rendering, no hardware performance or native full-frame pixel-parity claim.']}
}
