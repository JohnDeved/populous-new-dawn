import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'
export default async function({page,browser,url,root,output,receipt}) {
 const { frontendBackground } = await import(pathToFileURL(resolve(root,'app/frontend-composition.ts')).href)
 const bytes=new Uint8Array(readFileSync(resolve(root,'public/original/frontend/composition.bin')))
 const expected=visible=>createHash('sha256').update(frontendBackground(bytes,{x:320,y:240},true,0,[],640,visible)).digest('hex')
 const readyHash=expected(true), fallbackHash=expected(false), checks=[]
 async function matches(p,hash) {
  await p.waitForFunction(async expected=>{
   const c=document.querySelector('dialog canvas');if(!c)return false
   const pixels=c.getContext('2d').getImageData(0,0,c.width,c.height).data
   const digest=await crypto.subtle.digest('SHA-256',pixels)
   return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('')===expected
  },hash,{timeout:20000})
 }
 async function controls(p){
  await p.getByRole('button',{name:'Quit',exact:true}).click()
  const panel=p.locator('[data-original-quit-menu]')
  await panel.getByRole('button',{name:'Back',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Missing Back focus')})
  await p.keyboard.press('Escape')
  await p.getByRole('button',{name:'Quit',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Quit focus not restored')})
 }
 await page.emulateMedia({reducedMotion:'reduce'});await page.reload({waitUntil:'domcontentloaded'})
 await matches(page,readyHash);assert.equal(await page.locator('h1 > span').textContent(),'')
 await page.screenshot({path:resolve(output,'logo-ready.png')});checks.push('all-ready-canvas-matches-native-reference')
 assert.deepEqual(receipt.errors,[])
 await page.close()
 for(const [name,file,delayed]of [['logo-failed','felgspen',false],['font-failed','feft33we',false],['logo-delayed','felgspen',true]]){
  const c=await browser.newContext({viewport:{width:640,height:480},deviceScaleFactor:1,reducedMotion:'reduce'})
  let release;const pending=new Promise(r=>release=r);let intercepted=0
  try{
   await c.route('**/original/frontend/'+file+'.png',async route=>{intercepted++;if(delayed){await pending;await route.continue()}else await route.abort('failed')})
   const p=await c.newPage();p.setDefaultTimeout(20000);const errors=[];p.on('pageerror',e=>errors.push(String(e)))
   await p.goto(url,{waitUntil:'domcontentloaded'});await matches(p,fallbackHash)
   assert.equal(await p.locator('h1 > span').textContent(),'Populous: The Beginning');assert.ok(intercepted>0)
   await p.screenshot({path:resolve(output,name+'.png')})
   if(delayed){release();await matches(p,readyHash);assert.equal(await p.locator('h1 > span').textContent(),'');await p.screenshot({path:resolve(output,'logo-delayed-ready.png')})}
   await controls(p);assert.deepEqual(errors,[]);checks.push(name+(delayed?'-reduced-motion-transition':'-native-shadow-absent'))
  }finally{release();await c.close()}
 }
 return{checks,canvasHashes:{ready:readyHash,fallback:fallbackHash},limits:['Component-only; no actual Home/world load','Main/options glyph-shadow fallback remains outside this logo-only change']}
}
