import { createRoot } from 'react-dom/client'
import { useState } from 'react'
import { OriginalMainMenu } from '/tmp/logo-shadow-readiness-next/app/original-main-menu.tsx'
import '/tmp/logo-shadow-readiness-next/app/globals.css'
function Fixture() {
  const [destination, setDestination] = useState<string | null>(null)
  const [counts, setCounts] = useState({ tutorial: 0, campaign: 0 })
  function route(name: 'tutorial' | 'campaign') {
    setCounts(previous => ({ ...previous, [name]: previous[name] + 1 }))
    setDestination(name)
  }
  return <>
    <output id="callback-state">{JSON.stringify({ destination, counts })}</output>
    {destination
      ? <button onClick={() => setDestination(null)}>Return to fixture menu</button>
      : <OriginalMainMenu hasCheckpoint={false} onNewGame={() => route('campaign')}
          onTutorial={() => route('tutorial')} onLoad={() => { throw Error('Unexpected Load') }}
          renderOptions={() => null} />}
  </>
}
createRoot(document.getElementById('root')!).render(<Fixture />)
