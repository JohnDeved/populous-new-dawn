import { createRoot } from 'react-dom/client'
import { useState } from 'react'
import { OriginalMainMenu } from '/tmp/main-options-shadow/app/original-main-menu.tsx'
import { OriginalOptions } from '/tmp/main-options-shadow/app/original-options.tsx'
import '/tmp/main-options-shadow/app/globals.css'
function Fixture() {
  const [volume, setVolume] = useState(0.7)
  const [music, setMusic] = useState(0.5)
  const [preferences, setPreferences] = useState({rotation:'cursor' as 'cursor'|'control-cursor',flipRotation:false})
  return <OriginalMainMenu hasCheckpoint={false} onNewGame={()=>{}} onTutorial={()=>{}} onLoad={()=>{}}
    renderOptions={(onBack,onTextRowsChange)=><OriginalOptions skin="frontend" onBack={onBack} onTextRowsChange={onTextRowsChange}
      volume={volume} musicVolume={music} onVolume={setVolume} onMusicVolume={setMusic} storageNotice=""
      gamePreferences={preferences} onGamePreferences={setPreferences} gameStorageNotice="" />}/>
}
createRoot(document.getElementById('root')!).render(<Fixture />)
