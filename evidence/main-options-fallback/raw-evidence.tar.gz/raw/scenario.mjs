import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
export default async function({page,browser,url,root,output,receipt}) {
 const {frontendBackground}=await import(pathToFileURL(resolve(root,'app/frontend-composition.ts')))
 const bytes=new Uint8Array(readFileSync(resolve(root,'public/original/frontend/composition.bin')))
 const gameRows=[...['Game','Sound','Graphics'].map((text,i)=>({text,x:170+150*i,y:420})),{text:'Back',x:320,y:454},
 ...['Tooltips : <Unavailable>','Rotation : <Cursor>','Flip Rotation : <No>','Stay Selected : <Unavailable>','Autocast Spell : <Unavailable>'].map((text,i)=>({text,x:320,y:139+30*i}))]
 const hash=(menu,logo,rows=[],width=640)=>createHash('sha256').update(frontendBackground(bytes,{x:320,y:240},menu,0,rows,width,logo,logo)).digest('hex')
 async function matches(p,expected){await p.waitForFunction(async expected=>{const c=document.querySelector('dialog canvas');if(!c)return false;const b=c.getContext('2d').getImageData(0,0,c.width,c.height).data;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('')===expected},expected,{timeout:15000})}
 const click=async(p,name)=>p.getByRole('button',{name,exact:true}).evaluate(el=>el.click())
 const shot=async(p,name)=>p.screenshot({path:resolve(output,name+'.png')})
 const checks=[]
 await page.emulateMedia({reducedMotion:'reduce'});await page.reload({waitUntil:'domcontentloaded'})
 await matches(page,hash(true,true));await shot(page,'main-ready')
 await click(page,'Options');await matches(page,hash(false,true,gameRows));await shot(page,'options-ready')
 await click(page,'Back');await page.getByRole('button',{name:'Options',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Options focus missing')})
 assert.deepEqual(receipt.errors,[]);await page.close()
 for(const [name,file,delayed,logo]of [['main-font-failed','frontend/feft33we',false,false],['options-image-failed','options/frontend-0',false,true],['logo-failed-options-ready','frontend/felgspen',false,false],['options-image-delayed','options/frontend-0',true,true]]){
  const c=await browser.newContext({viewport:{width:640,height:480},deviceScaleFactor:1,reducedMotion:'reduce'})
  let release;const gate=new Promise(r=>release=r);let hits=0
  try{
   await c.route('**/original/'+file+'.png',async route=>{hits++;if(delayed){await gate;await route.continue()}else await route.abort('failed')})
   const p=await c.newPage(),errors=[];p.on('pageerror',e=>errors.push(String(e)));p.setDefaultTimeout(15000)
   await p.goto(url,{waitUntil:'domcontentloaded'});await matches(p,hash(true,logo))
   if(name==='main-font-failed'){await shot(p,name);await p.setViewportSize({width:1280,height:720});await shot(p,'main-font-failed-wide');await p.setViewportSize({width:640,height:480})}
   await click(p,'Options')
   const optionsReady=name==='logo-failed-options-ready'
   await p.locator('[aria-label="Options"][data-art-ready]').waitFor()
   await p.waitForFunction(ready=>document.querySelector('[aria-label="Options"][data-art-ready]').dataset.artReady===String(ready),optionsReady)
   await matches(p,hash(false,logo,optionsReady?gameRows:[]));assert.ok(hits>0);await shot(p,name+'-options')
   if(delayed){release();await matches(p,hash(false,true,gameRows));await shot(p,'options-delayed-ready')}
   await click(p,'Sound');assert.equal(await p.getByRole('slider',{name:'Master volume',exact:true}).count(),1)
   await click(p,'Graphics');await click(p,'Direct3D Options');await click(p,'Browser compatibility and help')
   await p.getByRole('heading',{name:'Browser compatibility and help',exact:true}).waitFor();await matches(p,hash(false,logo))
   await click(p,'Back to Options');await p.keyboard.press('Escape')
   await p.getByRole('button',{name:'Options',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Options focus missing after Escape')})
   await click(p,'Options');await matches(p,hash(false,logo,(optionsReady||delayed)?gameRows:[]));await click(p,'Back')
   assert.deepEqual(errors,[]);checks.push({name,intercepted:hits,optionsReady,delayedRecovery:delayed,compatibilityAndReentry:true})
  }finally{release();await c.close()}
 }
 return {checks,limits:'Actual OriginalMainMenu and OriginalOptions components with controlled preference callbacks; no Home or gameplay scene. Native 640 and wide fallback screenshots; software headless browser.'}
}
