import math,struct,json,pathlib
f=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
cs=lambda x:f(math.cos(int(x*16)*.001090830781875))
sn=lambda x:f(math.sin(int(x*16)*.001090830781875))
def mul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
a,c=90,0; A=[[1,0,0],[0,cs(a),-sn(a)],[0,sn(a),cs(a)]]; C=[[cs(c),0,sn(c)],[0,1,0],[-sn(c),0,cs(c)]]
F=[0,-1/math.sqrt(10),3/math.sqrt(10)]; r=8; Z=math.sqrt(200**2+(200/3)**2); rows=[]
for b in [0,1.5,90,180,358.5]:
 B=[[cs(b),-sn(b),0],[sn(b),cs(b),0],[0,0,1]]; M=mul(C,mul(A,B)); d=sum(r*M[i][2]*F[i] for i in range(3)); simple=r*(-sn(90)*F[1]+cs(90)*F[2]); assert abs(d-simple)<1e-12
 rows.append({'b':b,'d':d,'zBase':(Z-d)/16384,'zDelta':d/16384})
print(json.dumps({'kind':'source-data algebra, not native execution','sin90':sn(90),'cos90':cs(90),'rows':rows},indent=2))
