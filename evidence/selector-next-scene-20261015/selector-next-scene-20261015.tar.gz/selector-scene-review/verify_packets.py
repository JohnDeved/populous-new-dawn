import pathlib,struct,re,json,hashlib
p=pathlib.Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe'); b=p.read_bytes(); pe=struct.unpack_from('<I',b,60)[0]; n=struct.unpack_from('<H',b,pe+6)[0]; opt=struct.unpack_from('<H',b,pe+20)[0]; base=struct.unpack_from('<I',b,pe+52)[0]; ss=[]
for i in range(n):
 o=pe+24+opt+40*i; size,va,rs,raw=struct.unpack_from('<4I',b,o+8); ss.append((base+va,max(size,rs),rs,raw))
def at(a,n):
 for va,sz,rs,raw in ss:
  if va<=a and a+n<=va+sz:
   off=a-va; return (b[raw+off:raw+min(off+n,rs)] if off<rs else b'')+bytes(max(0,off+n-rs) if off<rs else n)
 raise ValueError(hex(a))
out={'exe_sha256':hashlib.sha256(b).hexdigest(),'asm':{},'assets':{},'constants':{}}
for name in ['camera','sun','backdrop']:
 lines=0; errors=[]
 for p in pathlib.Path('/tmp/selector-'+name).glob('*.asm'):
  for line in p.read_text().splitlines():
   m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}(?:\s+|$))+)',line)
   if m:
    a=int(m[1],16); raw=bytes.fromhex(m[2]); lines+=1
    if at(a,len(raw))!=raw: errors.append([str(p),hex(a)])
 out['asm'][name]={'lines_compared':lines,'mismatches':errors}
for name in ['camera','sun']:
 data=json.loads(pathlib.Path('/tmp/selector-'+name+'/constants.json').read_text()); checked=0; errors=[]
 for addr,entry in data.items():
  if addr.startswith('0x') and isinstance(entry,dict) and ('hex' in entry or 'initial_bytes' in entry):
   raw=bytes.fromhex(entry.get('hex',entry.get('initial_bytes'))); checked+=1
   if at(int(addr,16),len(raw))!=raw: errors.append(addr)
 out['constants'][name]={'checked':checked,'mismatches':errors}
for name in ['Sun.png','pls.png','ring.png']:
 p=pathlib.Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/data/d3d')/name
 out['assets'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
print(json.dumps(out,indent=2))
extra={}
for addr in [0x58f3e0,0x58f370,0x58f410,0x58f7dc,0x58f7e0,0x58f810,0x58f814,0x58f804,0x58f808]: extra[hex(addr)]={'hex':at(addr,4).hex(),'float32':struct.unpack('<f',at(addr,4))[0]}
for addr in [0x58f3d8,0x58f3b8,0x58f3e8]: extra[hex(addr)]={'hex':at(addr,8).hex(),'float64':struct.unpack('<d',at(addr,8))[0]}
pathlib.Path('/tmp/selector-scene-review/depth-constants.json').write_text(json.dumps(extra,indent=2))
