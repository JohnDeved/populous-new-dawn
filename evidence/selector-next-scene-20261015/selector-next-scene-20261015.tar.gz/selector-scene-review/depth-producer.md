# Narrow type5 depth-producer supplement

Static translation of retained assembly only; original EXE was neither run nor emulated. All cited instruction bytes were compared against the hash-checked PE (verification.json). This closes a missing implementation detail in the earlier summary packets.

## Fields and order

00456b80 constructs type5: radius at +0x5c, angles (a,b,c) at +0x44,+0x48,+0x4c initialized (90,0,0), increments at +0x50,+0x54,+0x58 initialized (0,1.5,0). 00455956–00455978 adds increments once per active object dispatch BEFORE matrix construction; no dt. The angle copies are wrapped into [0,360) for lookup without writing those wrapped copies back into the object. Each lookup is trunc(angle*16), into the shared float32 sin/cos tables. This angle accumulator is separate from orbital angles and ordinary Uoffset.

Avoid colloquial pitch/yaw labels: the actual row-major matrices are:
A(a) = [[1,0,0],[0,cos(a),-sin(a)],[0,sin(a),cos(a)]] at stack+0x1b0.
B(b) = [[cos(b),-sin(b),0],[sin(b),cos(b),0],[0,0,1]] at stack+0x21c.
C(c) = [[cos(c),0,sin(c)],[0,1,0],[-sin(c),0,cos(c)]] reuses stack+0x1b0.
00456a90 is conventional row-major matrix multiplication. Call00455b0c produces A*B at stack+0x240. Call00455be1 produces M=C*(A*B) at stack+0x1d4. 00455be6–00455ca0 multiplies EACH element by body radius r, storing S=r*M at stack+0x18c.

The world-to-camera transform projects columns of S against camera R/U/F. In particular stack+0x164 = d = S[0,2]*F.x + S[1,2]*F.y + S[2,2]*F.z (00455ede–00455f0c). Translation stack+0xac = Z=dot(F,bodyPosition-eye). Source multiplication/addition order and float32 stores remain observable rounding boundaries.

## Arguments to the body leaf

0045699d–004569d8 computes zFrontRaw = Z-d; stores zFront = zFrontRaw when >10, otherwise -1.
Object+0x38 stores zCentre = Z when Z>10, otherwise -1 (004568c2–00456913).
004569fd–00456a41 passes to 00429350:
(bodyIndex, screenX, screenY, screenRadius, zFront/16384, (zCentre-zFront)/16384, Uoffset, Voffset).
00429350 reorders into 004e3bc0(device,screenX,screenY,screenRadius,zBase,zDelta,quality=1.2000000476837158).
Thus for valid depths: zBase=(Z-d)/16384, zDelta=d/16384; mesh ring depth is zBase+zDelta*sin(theta), and halo depth is zBase.

The screen radius remains 400*r/Z; it is obtained by projecting the centre's camera-Y plus r (0045691a–00456999). This is independent of the object rotation. Invalid-centre screen coordinates can remain stale, so rejecting Z<=10 in a modern renderer is an explicit safety/clipping adaptation, not an exact recovered native cull.

## Useful simplification, bounded to constructed bodies

B rotates around the local Z axis and leaves the third column of A*B unchanged. With a=90,c=0 as constructed, d = r*(-sinLookup(90)*F.y + cosLookup(90)*F.z). Hence the per-draw b+=1.5 does NOT alter this depth coefficient for these bodies; my preliminary message that highlighted it should not be read as a required visible depth wobble. Do not replace sin/cosLookup with exact 1/0 if claiming the exact source-table calculation. For the approximate Mission1 settled camera F=(0,-1/sqrt(10),3/sqrt(10)), radius8, d≈2.52982 and Z≈210.81851: zBase≈0.0127130, zDelta≈0.000154408. The halo, where present, uses the same front depth, not centre depth or a depthless overlay.

No generic sphere depth, flat centre depth, or Z-r shortcut reproduces this producer. A portable implementation can translate these small matrices directly, or use the bounded third-column simplification with tests establishing its preconditions. Source-data algebra checks are in depth-math-check.json; they are not a native execution parity test.
