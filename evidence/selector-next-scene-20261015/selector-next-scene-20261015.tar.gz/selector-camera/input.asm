
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004112c0 <.text+0x102c0>:
  4112c0:	83 7c 24 08 00       	cmp    DWORD PTR [esp+0x8],0x0
  4112c5:	56                   	push   esi
  4112c6:	75 07                	jne    0x4112cf
  4112c8:	b8 01 00 00 00       	mov    eax,0x1
  4112cd:	5e                   	pop    esi
  4112ce:	c3                   	ret
  4112cf:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  4112d3:	48                   	dec    eax
  4112d4:	3d cc 00 00 00       	cmp    eax,0xcc
  4112d9:	77 56                	ja     0x411331
  4112db:	33 c9                	xor    ecx,ecx
  4112dd:	8a 88 2c 14 41 00    	mov    cl,BYTE PTR [eax+0x41142c]
  4112e3:	ff 24 8d 14 14 41 00 	jmp    DWORD PTR [ecx*4+0x411414]
  4112ea:	f6 05 f4 c9 5f 00 04 	test   BYTE PTR ds:0x5fc9f4,0x4
  4112f1:	75 05                	jne    0x4112f8
  4112f3:	e8 e8 ba 01 00       	call   0x42cde0
  4112f8:	b8 01 00 00 00       	mov    eax,0x1
  4112fd:	5e                   	pop    esi
  4112fe:	c3                   	ret
  4112ff:	e8 fc d1 06 00       	call   0x47e500
  411304:	b8 01 00 00 00       	mov    eax,0x1
  411309:	5e                   	pop    esi
  41130a:	c3                   	ret
  41130b:	6a 38                	push   0x38
  41130d:	e8 fe 56 11 00       	call   0x526a10
  411312:	83 c4 04             	add    esp,0x4
  411315:	85 c0                	test   eax,eax
  411317:	75 11                	jne    0x41132a
  411319:	68 b8 00 00 00       	push   0xb8
  41131e:	e8 ed 56 11 00       	call   0x526a10
  411323:	83 c4 04             	add    esp,0x4
  411326:	85 c0                	test   eax,eax
  411328:	74 07                	je     0x411331
  41132a:	80 0d f2 c6 89 00 01 	or     BYTE PTR ds:0x89c6f2,0x1
  411331:	b8 01 00 00 00       	mov    eax,0x1
  411336:	5e                   	pop    esi
  411337:	c3                   	ret
  411338:	8b 0d b0 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13b0
  41133e:	a1 bc 13 5f 00       	mov    eax,ds:0x5f13bc
  411343:	8d 14 49             	lea    edx,[ecx+ecx*2]
  411346:	8d 0c 91             	lea    ecx,[ecx+edx*4]
  411349:	8b 74 88 28          	mov    esi,DWORD PTR [eax+ecx*4+0x28]
  41134d:	4e                   	dec    esi
  41134e:	83 fe 01             	cmp    esi,0x1
  411351:	7d 05                	jge    0x411358
  411353:	be 19 00 00 00       	mov    esi,0x19
  411358:	56                   	push   esi
  411359:	e8 c2 d9 06 00       	call   0x47ed20
  41135e:	83 c4 04             	add    esp,0x4
  411361:	85 c0                	test   eax,eax
  411363:	74 e8                	je     0x41134d
  411365:	33 c0                	xor    eax,eax
  411367:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  41136d:	7e 19                	jle    0x411388
  41136f:	8b 0d bc 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13bc
  411375:	83 c1 28             	add    ecx,0x28
  411378:	39 31                	cmp    DWORD PTR [ecx],esi
  41137a:	74 1d                	je     0x411399
  41137c:	83 c1 34             	add    ecx,0x34
  41137f:	40                   	inc    eax
  411380:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  411386:	7f f0                	jg     0x411378
  411388:	b8 01 00 00 00       	mov    eax,0x1
  41138d:	5e                   	pop    esi
  41138e:	c7 05 b0 13 5f 00 00 	mov    DWORD PTR ds:0x5f13b0,0x0
  411395:	00 00 00 
  411398:	c3                   	ret
  411399:	5e                   	pop    esi
  41139a:	a3 b0 13 5f 00       	mov    ds:0x5f13b0,eax
  41139f:	b8 01 00 00 00       	mov    eax,0x1
  4113a4:	c3                   	ret
  4113a5:	8b 0d b0 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13b0
  4113ab:	a1 bc 13 5f 00       	mov    eax,ds:0x5f13bc
  4113b0:	8d 14 49             	lea    edx,[ecx+ecx*2]
  4113b3:	8d 0c 91             	lea    ecx,[ecx+edx*4]
  4113b6:	8b 74 88 28          	mov    esi,DWORD PTR [eax+ecx*4+0x28]
  4113ba:	46                   	inc    esi
  4113bb:	83 fe 19             	cmp    esi,0x19
  4113be:	7e 05                	jle    0x4113c5
  4113c0:	be 01 00 00 00       	mov    esi,0x1
  4113c5:	56                   	push   esi
  4113c6:	e8 55 d9 06 00       	call   0x47ed20
  4113cb:	83 c4 04             	add    esp,0x4
  4113ce:	85 c0                	test   eax,eax
  4113d0:	74 e8                	je     0x4113ba
  4113d2:	33 c0                	xor    eax,eax
  4113d4:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  4113da:	7e 19                	jle    0x4113f5
  4113dc:	8b 0d bc 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13bc
  4113e2:	83 c1 28             	add    ecx,0x28
  4113e5:	39 31                	cmp    DWORD PTR [ecx],esi
  4113e7:	74 1d                	je     0x411406
  4113e9:	83 c1 34             	add    ecx,0x34
  4113ec:	40                   	inc    eax
  4113ed:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  4113f3:	7f f0                	jg     0x4113e5
  4113f5:	b8 01 00 00 00       	mov    eax,0x1
  4113fa:	5e                   	pop    esi
  4113fb:	c7 05 b0 13 5f 00 00 	mov    DWORD PTR ds:0x5f13b0,0x0
  411402:	00 00 00 
  411405:	c3                   	ret
  411406:	5e                   	pop    esi
  411407:	a3 b0 13 5f 00       	mov    ds:0x5f13b0,eax
  41140c:	b8 01 00 00 00       	mov    eax,0x1
  411411:	c3                   	ret
  411412:	8b ff                	mov    edi,edi
  411414:	ea 12 41 00 ff 12 41 	jmp    0x4112:0xff004112
  41141b:	00 0b                	add    BYTE PTR [ebx],cl
  41141d:	13 41 00             	adc    eax,DWORD PTR [ecx+0x0]
  411420:	38 13                	cmp    BYTE PTR [ebx],dl
  411422:	41                   	inc    ecx
  411423:	00 a5 13 41 00 31    	add    BYTE PTR [ebp+0x31004113],ah
  411429:	13 41 00             	adc    eax,DWORD PTR [ecx+0x0]
  41142c:	00 05 05 05 05 05    	add    BYTE PTR ds:0x5050505,al
  411432:	05 05 05 05 05       	add    eax,0x5050505
  411437:	05 05 05 05 05       	add    eax,0x5050505
  41143c:	05 05 05 05 05       	add    eax,0x5050505
  411441:	05 05 05 05 05       	add    eax,0x5050505
  411446:	05 01 05 05 05       	add    eax,0x5050501
  41144b:	05 05 05 05 05       	add    eax,0x5050505
  411450:	05 05 05 05 05       	add    eax,0x5050505
  411455:	05 05 05 05 05       	add    eax,0x5050505
  41145a:	05 05 05 05 05       	add    eax,0x5050505
  41145f:	05 05 05 05 05       	add    eax,0x5050505
  411464:	05 05 05 05 05       	add    eax,0x5050505
  411469:	02 05 05 05 05 05    	add    al,BYTE PTR ds:0x5050505
  41146f:	05 05 05 05 05       	add    eax,0x5050505
  411474:	05 05 05 05 05       	add    eax,0x5050505
  411479:	05 05 05 05 05       	add    eax,0x5050505
  41147e:	05 05 05 05 05       	add    eax,0x5050505
  411483:	05 05 05 05 05       	add    eax,0x5050505
  411488:	05 05 05 05 05       	add    eax,0x5050505
  41148d:	05 05 05 05 05       	add    eax,0x5050505
  411492:	05 05 05 05 05       	add    eax,0x5050505
  411497:	05 05 05 05 05       	add    eax,0x5050505
  41149c:	05 05 05 05 05       	add    eax,0x5050505
  4114a1:	05 05 05 05 05       	add    eax,0x5050505
  4114a6:	05 05 05 05 05       	add    eax,0x5050505
  4114ab:	05 05 05 05 05       	add    eax,0x5050505
  4114b0:	05 05 05 05 05       	add    eax,0x5050505
  4114b5:	05 05 05 05 05       	add    eax,0x5050505
  4114ba:	05 05 05 05 05       	add    eax,0x5050505
  4114bf:	05 05 05 05 05       	add    eax,0x5050505
  4114c4:	05 05 05 05 05       	add    eax,0x5050505
  4114c9:	05 05 05 05 05       	add    eax,0x5050505
  4114ce:	05 05 05 05 05       	add    eax,0x5050505
  4114d3:	05 05 05 05 05       	add    eax,0x5050505
  4114d8:	05 05 05 05 05       	add    eax,0x5050505
  4114dd:	05 05 05 05 05       	add    eax,0x5050505
  4114e2:	05 05 05 05 05       	add    eax,0x5050505
  4114e7:	05 05 05 05 05       	add    eax,0x5050505
  4114ec:	05 05 05 05 05       	add    eax,0x5050505
  4114f1:	05 05 05 05 05       	add    eax,0x5050505
  4114f6:	03 05 04 cc cc cc    	add    eax,DWORD PTR ds:0xcccccc04
  4114fc:	cc                   	int3
  4114fd:	cc                   	int3
  4114fe:	cc                   	int3
  4114ff:	cc                   	int3
  411500:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  411504:	3d f0 00 00 00       	cmp    eax,0xf0
  411509:	74 14                	je     0x41151f
  41150b:	3d f1 00 00 00       	cmp    eax,0xf1
  411510:	74 2e                	je     0x411540
  411512:	3d f2 00 00 00       	cmp    eax,0xf2
  411517:	74 4e                	je     0x411567
  411519:	b8 01 00 00 00       	mov    eax,0x1
  41151e:	c3                   	ret
  41151f:	83 7c 24 08 00       	cmp    DWORD PTR [esp+0x8],0x0
  411524:	74 0d                	je     0x411533
  411526:	83 0d f4 c9 5f 00 20 	or     DWORD PTR ds:0x5fc9f4,0x20
  41152d:	b8 01 00 00 00       	mov    eax,0x1
  411532:	c3                   	ret
  411533:	83 25 f4 c9 5f 00 df 	and    DWORD PTR ds:0x5fc9f4,0xffffffdf
  41153a:	b8 01 00 00 00       	mov    eax,0x1
  41153f:	c3                   	ret
  411540:	83 7c 24 08 00       	cmp    DWORD PTR [esp+0x8],0x0
  411545:	74 10                	je     0x411557
  411547:	81 0d f4 c9 5f 00 80 	or     DWORD PTR ds:0x5fc9f4,0x80
  41154e:	00 00 00 
  411551:	b8 01 00 00 00       	mov    eax,0x1
  411556:	c3                   	ret
  411557:	81 25 f4 c9 5f 00 7f 	and    DWORD PTR ds:0x5fc9f4,0xffffff7f
  41155e:	ff ff ff 
  411561:	b8 01 00 00 00       	mov    eax,0x1
  411566:	c3                   	ret
  411567:	83 7c 24 08 00       	cmp    DWORD PTR [esp+0x8],0x0
  41156c:	74 0d                	je     0x41157b
  41156e:	83 0d f4 c9 5f 00 40 	or     DWORD PTR ds:0x5fc9f4,0x40
  411575:	b8 01 00 00 00       	mov    eax,0x1
  41157a:	c3                   	ret
  41157b:	83 25 f4 c9 5f 00 bf 	and    DWORD PTR ds:0x5fc9f4,0xffffffbf
  411582:	b8 01 00 00 00       	mov    eax,0x1
  411587:	c3                   	ret
  411588:	cc                   	int3
  411589:	cc                   	int3
  41158a:	cc                   	int3
  41158b:	cc                   	int3
  41158c:	cc                   	int3
  41158d:	cc                   	int3
  41158e:	cc                   	int3
  41158f:	cc                   	int3
  411590:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  411596:	55                   	push   ebp
  411597:	c7 05 cc 13 5f 00 c0 	mov    DWORD PTR ds:0x5f13cc,0x58f0c0
  41159e:	f0 58 00 
  4115a1:	8b ec                	mov    ebp,esp
  4115a3:	6a ff                	push   0xffffffff
  4115a5:	68 0b 16 41 00       	push   0x41160b
  4115aa:	50                   	push   eax
  4115ab:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4115b2:	33 c0                	xor    eax,eax
  4115b4:	a3 d0 13 5f 00       	mov    ds:0x5f13d0,eax
  4115b9:	a3 d4 13 5f 00       	mov    ds:0x5f13d4,eax
  4115be:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  4115c1:	a3 d0 13 5f 00       	mov    ds:0x5f13d0,eax
  4115c6:	a3 d8 13 5f 00       	mov    ds:0x5f13d8,eax
  4115cb:	68 40 17 41 00       	push   0x411740
  4115d0:	a3 e0 13 5f 00       	mov    ds:0x5f13e0,eax
  4115d5:	c7 05 cc 13 5f 00 b0 	mov    DWORD PTR ds:0x5f13cc,0x58f0b0
  4115dc:	f0 58 00 
  4115df:	a3 dc 13 5f 00       	mov    ds:0x5f13dc,eax
  4115e4:	b8 ff ff ff ff       	mov    eax,0xffffffff
  4115e9:	89 45 fc             	mov    DWORD PTR [ebp-0x4],eax
  4115ec:	e8 cf a5 14 00       	call   0x55bbc0
  4115f1:	83 c4 04             	add    esp,0x4
  4115f4:	8b 45 f4             	mov    eax,DWORD PTR [ebp-0xc]
  4115f7:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  4115fd:	8b e5                	mov    esp,ebp
  4115ff:	5d                   	pop    ebp
  411600:	c3                   	ret
  411601:	b9 cc 13 5f 00       	mov    ecx,0x5f13cc
  411606:	e9 15 00 00 00       	jmp    0x411620
  41160b:	b8 c8 4d 59 00       	mov    eax,0x594dc8
  411610:	e9 db a1 14 00       	jmp    0x55b7f0
  411615:	b9 cc 13 5f 00       	mov    ecx,0x5f13cc
  41161a:	e9 41 00 00 00       	jmp    0x411660
  41161f:	cc                   	int3
  411620:	c7 01 c0 f0 58 00    	mov    DWORD PTR [ecx],0x58f0c0
  411626:	e9 f5 5c 11 00       	jmp    0x527320
  41162b:	cc                   	int3
  41162c:	cc                   	int3
  41162d:	cc                   	int3
  41162e:	cc                   	int3
  41162f:	cc                   	int3
  411630:	56                   	push   esi
  411631:	c7 01 c0 f0 58 00    	mov    DWORD PTR [ecx],0x58f0c0
  411637:	8b f1                	mov    esi,ecx
  411639:	e8 e2 5c 11 00       	call   0x527320
  41163e:	f6 44 24 08 01       	test   BYTE PTR [esp+0x8],0x1
  411643:	74 09                	je     0x41164e
  411645:	56                   	push   esi
  411646:	e8 05 97 14 00       	call   0x55ad50
  41164b:	83 c4 04             	add    esp,0x4
  41164e:	8b c6                	mov    eax,esi
  411650:	5e                   	pop    esi
  411651:	c2 04 00             	ret    0x4
  411654:	cc                   	int3
  411655:	cc                   	int3
  411656:	cc                   	int3
  411657:	cc                   	int3
  411658:	cc                   	int3
  411659:	cc                   	int3
  41165a:	cc                   	int3
  41165b:	cc                   	int3
  41165c:	cc                   	int3
  41165d:	cc                   	int3
  41165e:	cc                   	int3
  41165f:	cc                   	int3
  411660:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  411666:	55                   	push   ebp
  411667:	8b ec                	mov    ebp,esp
  411669:	6a ff                	push   0xffffffff
  41166b:	68 a9 16 41 00       	push   0x4116a9
  411670:	c7 01 b0 f0 58 00    	mov    DWORD PTR [ecx],0x58f0b0
  411676:	50                   	push   eax
  411677:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  41167e:	83 ec 04             	sub    esp,0x4
  411681:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  411688:	89 4d f0             	mov    DWORD PTR [ebp-0x10],ecx
  41168b:	e8 70 5e 11 00       	call   0x527500
  411690:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  411697:	e8 17 00 00 00       	call   0x4116b3
  41169c:	8b 45 f4             	mov    eax,DWORD PTR [ebp-0xc]
  41169f:	8b e5                	mov    esp,ebp
  4116a1:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  4116a7:	5d                   	pop    ebp
  4116a8:	c3                   	ret
  4116a9:	b8 f8 4d 59 00       	mov    eax,0x594df8
  4116ae:	e9 3d a1 14 00       	jmp    0x55b7f0
  4116b3:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4116b6:	e9 65 ff ff ff       	jmp    0x411620
  4116bb:	cc                   	int3
  4116bc:	cc                   	int3
  4116bd:	cc                   	int3
  4116be:	cc                   	int3
  4116bf:	cc                   	int3
  4116c0:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  4116c6:	55                   	push   ebp
  4116c7:	8b ec                	mov    ebp,esp
  4116c9:	6a ff                	push   0xffffffff
  4116cb:	68 21 17 41 00       	push   0x411721
  4116d0:	c7 01 b0 f0 58 00    	mov    DWORD PTR [ecx],0x58f0b0
  4116d6:	50                   	push   eax
  4116d7:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4116de:	83 ec 04             	sub    esp,0x4
  4116e1:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4116e8:	89 4d f0             	mov    DWORD PTR [ebp-0x10],ecx
  4116eb:	e8 10 5e 11 00       	call   0x527500
  4116f0:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4116f7:	e8 2f 00 00 00       	call   0x41172b
  4116fc:	f6 45 08 01          	test   BYTE PTR [ebp+0x8],0x1
  411700:	74 0c                	je     0x41170e
  411702:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  411705:	50                   	push   eax
  411706:	e8 45 96 14 00       	call   0x55ad50
  41170b:	83 c4 04             	add    esp,0x4
  41170e:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  411711:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  411714:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  41171b:	8b e5                	mov    esp,ebp
  41171d:	5d                   	pop    ebp
  41171e:	c2 04 00             	ret    0x4
  411721:	b8 20 4e 59 00       	mov    eax,0x594e20
  411726:	e9 c5 a0 14 00       	jmp    0x55b7f0
  41172b:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  41172e:	e9 ed fe ff ff       	jmp    0x411620
  411733:	cc                   	int3
  411734:	cc                   	int3
  411735:	cc                   	int3
  411736:	cc                   	int3
  411737:	cc                   	int3
  411738:	cc                   	int3
  411739:	cc                   	int3
  41173a:	cc                   	int3
  41173b:	cc                   	int3
  41173c:	cc                   	int3
  41173d:	cc                   	int3
  41173e:	cc                   	int3
  41173f:	cc                   	int3
  411740:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  411746:	55                   	push   ebp
  411747:	8b ec                	mov    ebp,esp
  411749:	6a ff                	push   0xffffffff
  41174b:	68 71 17 41 00       	push   0x411771
  411750:	50                   	push   eax
  411751:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  411758:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  41175f:	e8 17 00 00 00       	call   0x41177b
  411764:	8b 45 f4             	mov    eax,DWORD PTR [ebp-0xc]
  411767:	8b e5                	mov    esp,ebp
  411769:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  41176f:	5d                   	pop    ebp
  411770:	c3                   	ret
  411771:	b8 48 4e 59 00       	mov    eax,0x594e48
  411776:	e9 75 a0 14 00       	jmp    0x55b7f0
  41177b:	b9 cc 13 5f 00       	mov    ecx,0x5f13cc
  411780:	e9 db fe ff ff       	jmp    0x411660
  411785:	cc                   	int3
  411786:	cc                   	int3
  411787:	cc                   	int3
  411788:	cc                   	int3
  411789:	cc                   	int3
  41178a:	cc                   	int3
  41178b:	cc                   	int3
  41178c:	cc                   	int3
  41178d:	cc                   	int3
  41178e:	cc                   	int3
  41178f:	cc                   	int3
