# Selector camera and body layout: bounded static handoff

2026-10-15. Research only for #17/#457; do not add this scope to PR464 during validation. Read AGENTS.md, engineering skill, native-research.md, GOAL.md, engineering/README.md, previous selector-static packets and current UI/importer. No repository writes, checkout changes, builds, tests, browser, executable execution or emulation. Only GNU objdump 2.44 and Python struct/file reads. Input SHA256 is verified in input-sha256.txt and matches the pinned 3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f.

## Useful result

The next live slice can replace the schematic map plus fixed-size preview with a single perspective scene whose eye follows the selected mission. Camera target, zoom offset, initial state, body motion and selection transition equations are source-bound below. Crucially, orbital and camera motion use elapsed seconds, not an assumed render frequency. No native drag-to-rotate camera was found in the traced input path. The selected ordinary globe is one of the shared orbital bodies, not a separately positioned large preview.

This does not complete whole-screen parity: sun/wobble/glow, space sprites, exact orbit-line raster appearance, device depth/clipping and UV spin cadence remain separate. Do not invent a fullscreen plsbackg draw.

## Exact live chain and units

entry.asm 00410fd0 → 00455180 camera initialization → 00411790 authored bodies/scene objects → panel setup → 00412780 startup asset load. loop.asm 00410f1b initializes graphics then jumps to 004110e0 before the first scene display. Each normal loop calls 004110e0 → 00412230 body positions and desired camera → 004284d0 graphics setup → 00455410 camera smoothing/basis/scene projection. The latter calls 00455460 twice, 00455610, 004572f0 and 00455810. Panel overlays and frame presentation follow (0041fb80/00428570).

004111b9–004111f6 calls IAT 00d0c784, identified by PE import as GetTickCount (timer-import.txt; objdump displays RVA0090c784). dt = float32(min(unsigned(now-last),1000)*0.001). last=now. The timer is initially assigned before resource loading, so the first update's dt is load-dependent, capped at one second. There is no single fixed first displayed pose independent of timing. Treat initialized camera, zero-time authored pose, first updated pose and settled pose as distinct fixtures.

## Body layout and motion

Body record stride52: radius+12, original angle+16, mutable angle+20, angular velocity+24, world position+28..36, mission+40, scene object+44. Initialization copies authored start angle into both angle fields (00411966–0041196e). Root index005f13a8 is the body whose authored parent is-1, here sun body0. Orbit records group equal(parent,orbitRadius), stride24: parent+0, member count+4, members+8, radius+12, scene orbit+16.

004125a0 recursively visits root then children. At the start of each visit it computes that body's position from its CURRENT angle and its parent's already-computed position:
  lookup index = trunc(angle*16)
  x = parent.x + orbitRadius*cosTable[index]
  y = parent.y
  z = parent.z + orbitRadius*sinTable[index]
The root uses parent=(0,0,0); its radius is0. Tables have5760 entries; entry j is float32(cos/sin(j*0.001090830781875)), generated at00411075–004110a2. This is approximately a1/16-degree lookup, not continuous trig. After writing scene translation, advance angle += angularVelocity*dt*10 and wrap into[0,360), then recurse. Thus current frame positions precede their own angular advancement. Body20 speed0.8 means8degrees/second; Mission1 speed1.3 means13degrees/second, not1.3.

004122b1–004123cf produces orbit vertex circles in the same XZ plane, centred on parent position. 00456bf0 allocates100 vertices and100 closed segments. The lookup step is float32((360/100)*16), accumulated; project these vertices with the SAME camera if drawing orbit guides. Exact native line shade/depth raster is outside this handoff; don't claim a generic SVG stroke is pixel-identical.

## Desired focus and zoom

004123cf–0041259c. Let O=root world position, S=selected body's world position, zoomCounter=DWORD005f13b4 (initialized30), q=zoomCounter+10. Ordinary selection:
  targetDesired T=S
  basisDistance b=150
  N=normalize(O-T)
  eyeDesired = T - N*(b*q*float32(1/30)) + (0,b*q/90,0)
The y lift uses double1/3 and double1/30; the radial multiplier uses float32 0.03333333507180214. With zoomCounter30, the ordinary radial offset is about200 and lift66.6667. There is no authored per-body camera-size normalization: all ordinary selections use b150.

Root/sun selected is special: advance angle00599a40 +=dt*5; if>=360 set0. T=(O.x+800*cosLookup(angle),200,O.z+800*sinLookup(angle)); b=500. Then use the same N and eye formula. This is automatic motion while the root is selected, not input-driven rotation. Its initial angle in the image is0; this function does not reset it on every selector entry.

Frozen authored-angle example (mathematical reference, not an original screenshot): Mission1 body24 at approximately(0,0,-1250), desired eye approximately(0,66.6667,-1450), target(0,0,-1250). Mission2 target z=-1290/eye z=-1490; Mission3 target z=-1330/eye z=-1530. When the camera has reached a frozen target, each selected radius8 body projects at centre(320,240), nominal radius about15.179 pixels. This is very different from a large independent preview. Do not present this frozen settled pose as the actual moving first frame.

## Initialization and transition state

00455180 sets focal400; eyeCurrent=eyeDesired=(0,2500,200), targetCurrent=targetDesired=(0,0,0). The earlier write z=-200 at0073955c is immediately overwritten by00455610 copying eyeCurrent with z=+200. Initial selected body comes from005f13ac (fresh path searches mission1);0041220d copies it to005f13b0. Initialization sets zoomCounter30.

Each smoother state is40 bytes, at00739588 for eye and007395b0 for target:
  +0 lastSelectedBody; +4 current vec3; +16 desired vec3; +28 speed; +32 acceleration; +36 mode.
File-backed/zero-fill initial values are all zero (constants.json). Camera init writes vectors but does not explicitly reset these other fields on re-entry. Preserve that distinction; a browser choosing a fresh state on each reopen is an explicit compatibility/lifecycle choice.

00455460(state,30,1,.5) for eye; (state,60,1,.5) for target. Only first numeric argument is read in this routine. For each call:
- If lastSelected differs from selected body, mode=1 and store selected body. Speed/acceleration are NOT reset here.
- If mode!=1, copy desired to current immediately and return. Thus after convergence it follows the moving desired point directly until selection changes.
- Otherwise D=desired-current, distance=length(D). If vectors equal, snap below. Else timeToTarget = distance/speed, or100000000 if speed is zero. If timeToTarget<dt, snap below.
- Otherwise acceleration += (30 or60)*dt; speed += acceleration*dt; current += normalize(D)*speed*dt*.9.
- Snap: current=desired; mode=2; acceleration=0; speed*=.8.
This is an elapsed-time, discrete numerical integrator, NOT exponential easing or a fixed duration. It can differ with step size. A fixed internal step with interpolated uncapped presentation, or another documented compatibility correction, needs schedule regressions; do not label any invented fixed frame rate native.

## Selection, input and launch boundary

004112c0 routes key codes203/205 to previous/next eligible mission (wrap1..25,0047ed20), then resolves and stores selected body index. input.asm retains exact byte dispatch. Panel0047e5e3 calls00412930(mission), which only resolves the body; caller writes005f13b0. Neither path relocates a separate globe, resets orbital angles or writes camera Euler angles.00411500 merely toggles pointer-button flags. No drag-rotation or user zoom operation is established by these callbacks and the active update path.

Launch bit4 starts a separate legacy zoom: after200ms from first launch update, zoomCounter decrements once per update until0, then sets transition bit8. The timestamp is not renewed for each decrement. Therefore that launch countdown is update-count-dependent after its initial delay. Keep launch animation outside the bounded camera-selection slice; don't infer a30fps/60fps duration.

Selected assets: direct-call scan finds00412780 only from startup004110cd. Panel/arrow selection changes selected index; traced per-body D3D textures are independently prepared as previous globe research established. This supports shared-body ownership; it does not prove no indirect/legacy preview consumer exists elsewhere. Existing selected-mission palette UI adaptation must not be silently expanded into a native reload claim.

## Projection and bounded acceptance

Reuse scene-findings.md basis: F=normalize(targetCurrent-eyeCurrent), R=normalize((F.z,0,-F.x)), U=normalize(F cross R). For B-eyeCurrent compute X=dot(R,...),Y=dot(U,...),Z=dot(F,...). At Z>10: screen=(320+400X/Z,240-400Y/Z), radius=400*bodyRadius/Z. Source markers for invalid depth are not a complete clipping policy. Keep one proportional640x480 coordinate transform including panel; don't stretch axes independently.

Proposed next PR after464: one live scene for the existing bounded Mission1–3 selection, using their native positions, camera initialization/focus transitions and the accepted globe mesh. Remove the invented duplicate preview ownership. All ordinary neighboring bodies visible in that composition need their own textures: current importer explicitly emits only Missions1–3. The existing per-body import recipe already supports extending this as a scoped prerequisite, without more native research. Do not silently put Mission1 texture on the parent. Sun and other excluded decoration must remain explicit fidelity boundaries.

Acceptance: source-bound tests for authored pose and table quantization, dt units/angular speeds, desired camera for Missions1–3, exact per-step smoother branches and preserved speed on reselection; separate initial/settled fixtures; live panel/arrow selection must focus the corresponding shared body without replacing the paused game. Verify resize/high-DPI uniform projection, 30/60/120/144Hz and irregular elapsed schedules under the documented integration choice, no unreachable controls, existing launch/back/direct-access persistence. Retain no-background/full-frame-parity disclaimer. Camera math is implementable now; full composition requires the named texture/rendering scope, not broad engine decompilation.

## Reproduction/evidence

New input.asm: objdump -d -Mintel --start-address=0x4112c0 --stop-address=0x411790 EXE. New selection.asm:0x412930..0x412a00. Other source slices copied verbatim from /tmp/selector-static for portable review; hashes retained. state-xrefs.txt and preview-xrefs.txt are scoped grep results from full static disassembly, not exhaustive indirect-reference proofs. read_constants.py parses PE sections and reads literal constants/zero-fill only; python execution returned0. No native probe/browser/test/build was run or claimed. Stop condition reached: implementation-ready selected-body camera/layout slice with explicit initialization/timing/decoration boundaries.
