
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00412930 <.text+0x11930>:
  412930:	33 c0                	xor    eax,eax
  412932:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  412938:	7e 1d                	jle    0x412957
  41293a:	8b 15 bc 13 5f 00    	mov    edx,DWORD PTR ds:0x5f13bc
  412940:	8b 4c 24 04          	mov    ecx,DWORD PTR [esp+0x4]
  412944:	83 c2 28             	add    edx,0x28
  412947:	39 0a                	cmp    DWORD PTR [edx],ecx
  412949:	74 0e                	je     0x412959
  41294b:	83 c2 34             	add    edx,0x34
  41294e:	40                   	inc    eax
  41294f:	39 05 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,eax
  412955:	7f f0                	jg     0x412947
  412957:	33 c0                	xor    eax,eax
  412959:	c3                   	ret
  41295a:	cc                   	int3
  41295b:	cc                   	int3
  41295c:	cc                   	int3
  41295d:	cc                   	int3
  41295e:	cc                   	int3
  41295f:	cc                   	int3
  412960:	83 ec 08             	sub    esp,0x8
  412963:	f6 05 64 c6 89 00 02 	test   BYTE PTR ds:0x89c664,0x2
  41296a:	53                   	push   ebx
  41296b:	56                   	push   esi
  41296c:	57                   	push   edi
  41296d:	55                   	push   ebp
  41296e:	0f 84 6c 03 00 00    	je     0x412ce0
  412974:	8b 0d b0 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13b0
  41297a:	a1 bc 13 5f 00       	mov    eax,ds:0x5f13bc
  41297f:	8d 14 49             	lea    edx,[ecx+ecx*2]
  412982:	8d 0c 91             	lea    ecx,[ecx+edx*4]
  412985:	8b 7c 88 28          	mov    edi,DWORD PTR [eax+ecx*4+0x28]
  412989:	83 ff 18             	cmp    edi,0x18
  41298c:	74 26                	je     0x4129b4
  41298e:	83 ff 19             	cmp    edi,0x19
  412991:	74 3e                	je     0x4129d1
  412993:	33 f6                	xor    esi,esi
  412995:	8d 47 ff             	lea    eax,[edi-0x1]
  412998:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  41299c:	83 f8 18             	cmp    eax,0x18
  41299f:	0f 87 25 03 00 00    	ja     0x412cca
  4129a5:	33 c9                	xor    ecx,ecx
  4129a7:	8a 88 2c 2e 41 00    	mov    cl,BYTE PTR [eax+0x412e2c]
  4129ad:	ff 24 8d 14 2e 41 00 	jmp    DWORD PTR [ecx*4+0x412e14]
  4129b4:	33 c0                	xor    eax,eax
  4129b6:	a0 b5 5d 89 00       	mov    al,ds:0x895db5
  4129bb:	50                   	push   eax
  4129bc:	6a 00                	push   0x0
  4129be:	6a 00                	push   0x0
  4129c0:	6a 01                	push   0x1
  4129c2:	68 b4 9b 59 00       	push   0x599bb4
  4129c7:	e8 b4 a2 08 00       	call   0x49cc80
  4129cc:	83 c4 14             	add    esp,0x14
  4129cf:	eb c2                	jmp    0x412993
  4129d1:	c7 05 f4 c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9f4,0x0
  4129d8:	00 00 00 
  4129db:	81 0d 65 c6 89 00 00 	or     DWORD PTR ds:0x89c665,0x80000
  4129e2:	00 08 00 
  4129e5:	6a 0c                	push   0xc
  4129e7:	e8 74 00 03 00       	call   0x442a60
  4129ec:	83 c4 04             	add    esp,0x4
  4129ef:	5d                   	pop    ebp
  4129f0:	5f                   	pop    edi
  4129f1:	5e                   	pop    esi
  4129f2:	5b                   	pop    ebx
  4129f3:	83 c4 08             	add    esp,0x8
  4129f6:	c3                   	ret
  4129f7:	33 ed                	xor    ebp,ebp
  4129f9:	8d 5f 01             	lea    ebx,[edi+0x1]
  4129fc:	83 fb 10             	cmp    ebx,0x10
  4129ff:	7f                   	.byte 0x7f
