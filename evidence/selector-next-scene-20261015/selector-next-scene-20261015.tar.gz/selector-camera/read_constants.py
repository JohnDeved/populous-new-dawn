import struct,json,pathlib
p=pathlib.Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe'); b=p.read_bytes()
pe=struct.unpack_from('<I',b,60)[0]; n=struct.unpack_from('<H',b,pe+6)[0]; opt=struct.unpack_from('<H',b,pe+20)[0]; base=struct.unpack_from('<I',b,pe+24+28)[0]; sections=[]
for i in range(n):
 o=pe+24+opt+40*i; size,va,rawsize,raw=struct.unpack_from('<4I',b,o+8); sections.append((base+va,max(size,rawsize),raw,rawsize))
def at(a,n):
 for va,sz,raw,rs in sections:
  if va<=a<va+sz:
   d=a-va
   return b[raw+d:raw+d+n] if d+n<=rs else bytes(n)
 raise ValueError(hex(a))
out={}
for a,t in [(0x58f020,'d'),(0x58f028,'d'),(0x58f040,'d'),(0x58f048,'d'),(0x58f064,'f'),(0x58f070,'d'),(0x58f078,'d'),(0x58f088,'d'),(0x58f090,'f'),(0x58f098,'d'),(0x58f0a0,'d'),(0x58f0a8,'f'),(0x58f3c8,'d'),(0x58f3d0,'d'),(0x599a40,'f')]:
 raw=at(a,struct.calcsize(t));out[hex(a)]={'type':t,'hex':raw.hex(),'value':struct.unpack('<'+t,raw)[0]}
for start in [0x739588,0x7395b0]:
 out[hex(start)]={'initial_bytes':at(start,40).hex(),'i10':struct.unpack('<10I',at(start,40))}
out['keyboard_dispatch']={str(i+1): struct.unpack('<I',at(0x411414+4*v,4))[0] for i,v in enumerate(at(0x41142c,205)) if v!=5}
print(json.dumps(out,indent=2))
