
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00509820 <.text+0x108820>:
  509820:	56                   	push   esi
  509821:	8b 41 40             	mov    eax,DWORD PTR [ecx+0x40]
  509824:	8b f1                	mov    esi,ecx
  509826:	50                   	push   eax
  509827:	6a 01                	push   0x1
  509829:	8b 0d 08 6c 5d 00    	mov    ecx,DWORD PTR ds:0x5d6c08
  50982f:	51                   	push   ecx
  509830:	8b 01                	mov    eax,DWORD PTR [ecx]
  509832:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  509835:	85 c0                	test   eax,eax
  509837:	75 21                	jne    0x50985a
  509839:	8b 46 48             	mov    eax,DWORD PTR [esi+0x48]
  50983c:	8b 0d 08 6c 5d 00    	mov    ecx,DWORD PTR ds:0x5d6c08
  509842:	50                   	push   eax
  509843:	6a 01                	push   0x1
  509845:	51                   	push   ecx
  509846:	8b 01                	mov    eax,DWORD PTR [ecx]
  509848:	ff 50 64             	call   DWORD PTR [eax+0x64]
  50984b:	83 f8 01             	cmp    eax,0x1
  50984e:	8b c8                	mov    ecx,eax
  509850:	b8 00 00 00 00       	mov    eax,0x0
  509855:	83 d0 ff             	adc    eax,0xffffffff
  509858:	23 c1                	and    eax,ecx
  50985a:	5e                   	pop    esi
  50985b:	c3                   	ret
  50985c:	cc                   	int3
  50985d:	cc                   	int3
  50985e:	cc                   	int3
  50985f:	cc                   	int3
