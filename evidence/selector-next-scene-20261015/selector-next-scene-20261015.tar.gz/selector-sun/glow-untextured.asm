
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004e3a40 <.text+0xe2a40>:
  4e3a40:	83 3d 8c 46 a1 00 00 	cmp    DWORD PTR ds:0xa1468c,0x0
  4e3a47:	0f 85 68 01 00 00    	jne    0x4e3bb5
  4e3a4d:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  4e3a52:	6a 05                	push   0x5
  4e3a54:	6a 13                	push   0x13
  4e3a56:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  4e3a5c:	50                   	push   eax
  4e3a5d:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3a5f:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3a62:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3a68:	6a 06                	push   0x6
  4e3a6a:	6a 14                	push   0x14
  4e3a6c:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4e3a72:	50                   	push   eax
  4e3a73:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3a75:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3a78:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3a7e:	6a 00                	push   0x0
  4e3a80:	6a 01                	push   0x1
  4e3a82:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4e3a88:	50                   	push   eax
  4e3a89:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3a8b:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3a8e:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3a94:	6a 01                	push   0x1
  4e3a96:	6a 1b                	push   0x1b
  4e3a98:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4e3a9e:	50                   	push   eax
  4e3a9f:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3aa1:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3aa4:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3aaa:	6a 00                	push   0x0
  4e3aac:	6a 29                	push   0x29
  4e3aae:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4e3ab4:	50                   	push   eax
  4e3ab5:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3ab7:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3aba:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3ac0:	6a 00                	push   0x0
  4e3ac2:	6a 0f                	push   0xf
  4e3ac4:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4e3aca:	50                   	push   eax
  4e3acb:	8b 00                	mov    eax,DWORD PTR [eax]
  4e3acd:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4e3ad0:	6a 00                	push   0x0
  4e3ad2:	8b 0d 88 46 a1 00    	mov    ecx,DWORD PTR ds:0xa14688
  4e3ad8:	d9 05 7c 46 a1 00    	fld    DWORD PTR ds:0xa1467c
  4e3ade:	d8 05 80 46 a1 00    	fadd   DWORD PTR ds:0xa14680
  4e3ae4:	51                   	push   ecx
  4e3ae5:	8b 15 84 46 a1 00    	mov    edx,DWORD PTR ds:0xa14684
  4e3aeb:	52                   	push   edx
  4e3aec:	8b c2                	mov    eax,edx
  4e3aee:	0d 00 00 00 ff       	or     eax,0xff000000
  4e3af3:	50                   	push   eax
  4e3af4:	83 ec 04             	sub    esp,0x4
  4e3af7:	8b 0d 78 46 a1 00    	mov    ecx,DWORD PTR ds:0xa14678
  4e3afd:	83 ec 04             	sub    esp,0x4
  4e3b00:	d9 5c 24 04          	fstp   DWORD PTR [esp+0x4]
  4e3b04:	d9 05 80 46 a1 00    	fld    DWORD PTR ds:0xa14680
  4e3b0a:	d8 0d 08 f8 58 00    	fmul   DWORD PTR ds:0x58f808
  4e3b10:	d8 05 7c 46 a1 00    	fadd   DWORD PTR ds:0xa1467c
  4e3b16:	d9 1c 24             	fstp   DWORD PTR [esp]
  4e3b19:	51                   	push   ecx
  4e3b1a:	8b 15 74 46 a1 00    	mov    edx,DWORD PTR ds:0xa14674
  4e3b20:	a1 70 46 a1 00       	mov    eax,ds:0xa14670
  4e3b25:	52                   	push   edx
  4e3b26:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3b2c:	50                   	push   eax
  4e3b2d:	8b 91 48 06 00 00    	mov    edx,DWORD PTR [ecx+0x648]
  4e3b33:	52                   	push   edx
  4e3b34:	e8 77 07 00 00       	call   0x4e42b0
  4e3b39:	83 c4 28             	add    esp,0x28
  4e3b3c:	8b 0d 88 46 a1 00    	mov    ecx,DWORD PTR ds:0xa14688
  4e3b42:	a1 84 46 a1 00       	mov    eax,ds:0xa14684
  4e3b47:	6a 00                	push   0x0
  4e3b49:	d9 05 80 46 a1 00    	fld    DWORD PTR ds:0xa14680
  4e3b4f:	d8 0d 08 f8 58 00    	fmul   DWORD PTR ds:0x58f808
  4e3b55:	51                   	push   ecx
  4e3b56:	0d 00 00 00 ff       	or     eax,0xff000000
  4e3b5b:	50                   	push   eax
  4e3b5c:	a1 84 46 a1 00       	mov    eax,ds:0xa14684
  4e3b61:	d8 05 7c 46 a1 00    	fadd   DWORD PTR ds:0xa1467c
  4e3b67:	50                   	push   eax
  4e3b68:	8b 0d 78 46 a1 00    	mov    ecx,DWORD PTR ds:0xa14678
  4e3b6e:	83 ec 04             	sub    esp,0x4
  4e3b71:	8b 15 74 46 a1 00    	mov    edx,DWORD PTR ds:0xa14674
  4e3b77:	83 ec 04             	sub    esp,0x4
  4e3b7a:	a1 70 46 a1 00       	mov    eax,ds:0xa14670
  4e3b7f:	d9 5c 24 04          	fstp   DWORD PTR [esp+0x4]
  4e3b83:	d9 05 7c 46 a1 00    	fld    DWORD PTR ds:0xa1467c
  4e3b89:	d8 25 80 46 a1 00    	fsub   DWORD PTR ds:0xa14680
  4e3b8f:	51                   	push   ecx
  4e3b90:	52                   	push   edx
  4e3b91:	50                   	push   eax
  4e3b92:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e3b98:	d9 5c 24 0c          	fstp   DWORD PTR [esp+0xc]
  4e3b9c:	8b 91 48 06 00 00    	mov    edx,DWORD PTR [ecx+0x648]
  4e3ba2:	52                   	push   edx
  4e3ba3:	e8 08 07 00 00       	call   0x4e42b0
  4e3ba8:	c7 05 8c 46 a1 00 01 	mov    DWORD PTR ds:0xa1468c,0x1
  4e3baf:	00 00 00 
  4e3bb2:	83 c4 28             	add    esp,0x28
  4e3bb5:	c3                   	ret
  4e3bb6:	cc                   	int3
  4e3bb7:	cc                   	int3
  4e3bb8:	cc                   	int3
  4e3bb9:	cc                   	int3
  4e3bba:	cc                   	int3
  4e3bbb:	cc                   	int3
  4e3bbc:	cc                   	int3
  4e3bbd:	cc                   	int3
  4e3bbe:	cc                   	int3
  4e3bbf:	cc                   	int3
