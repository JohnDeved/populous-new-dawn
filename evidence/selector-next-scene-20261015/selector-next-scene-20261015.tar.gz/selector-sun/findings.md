# Selector body0 sun: bounded static handoff

2026-10-15, #17/#457. No repository writes, original execution/emulation, browser, builds, tests or Ghidra exports. Read AGENTS.md, engineering skill, native-research.md, GOAL/README, prior /tmp/selector-static and /tmp/selector-camera findings. Original EXE SHA256 verified against 3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f. GNU objdump 2.44, Python file/struct reads and Pillow image decoding only. Repository status could not be established with default Git: rev-parse printed 265444c6dc5ce58ec7e6427b123374a0de7dc44d, status returned fatal: bad object HEAD. Parent confirmed task-local object storage; no Git settings changed. Research is source-EXE-bound, not a checkout cleanliness claim.

## Implementable result

Body0 is the ordinary adaptive screen-ring mesh and existing screen-relative vertex shade, with its own opaque 128x128 RGB sun texture, UV scale .5 and persistent per-vertex cosine distortion. Immediately after its textured globe draw comes a red annular halo, using source-alpha / inverse-source-alpha blending, not additive bloom. The preferred hardware branch uses untextured Gouraud alpha; the fallback uses pls.png as an alpha ramp. This suffices for a bounded modern sun component using Gouraud alpha plus documented elapsed-time adaptation. Exact legacy frame timing and original hardware pixels are not claimed.

## Resource identity and construction

004288b0 graphics setup calls 004b5f40("data\\d3d\\sun.png",0,0,ui+0x1da0,&textureObject006792d8) at00428925–0042893a. Literal at0059c3a0 was read directly from the verified PE. Body0 branch00429405–00429426 binds that SAME object using00509820; nonzero bodies use the separate112-byte object array. This independently binds the resource to the live consumer rather than trusting its name. Setup similarly loads data\\d3d\\pls.png into0065c9c8 using format ui+0x1da8, independently bound by the halo fallback at004e41de. ring.png is another object and is not the body's surface or halo resource here.

004b5f40 →004309b0 loads an image surface (third palette output arg is0). It downsamples only by its supplied x/y shift arguments, both0 here, creates a same-size device surface, copies with004306a0 and attaches with00509860. No selected mission plspl palette, four-tile assembly or4x4 average is used for this sun. Format quantization is device-dependent. PNG decoder internals, PNG ancillary gamma handling and target device quantization are not fully reconstructed; decoded source RGB is the bounded portable adaptation.

Actual input data/d3d/Sun.png:128x128, RGB8, no palette/tRNS/alpha; file SHA25667d20335b39471fa5c0be3799b8ae36e41ba857d77b5b804201c79c9d905a657. Source extrema R255, G70..230, B1..2. RGBA decoding adds alpha255. Actual pls.png:64x64 RGBA8, RGB all255, alpha0..255, SHA2561777184a477e9c0cb0e8c681e28b41aeb54489ca09d1445f36f226ff6f1251bb. Its x0 alpha rises0→255 over rows0..31; rows32..63 are0. This texture-edge detail matters for legacy bilinear sampling at v=.5. assets.json records decoded pixel hashes. Exact-file-hash scan of readable public/original/**/*.png found no existing copies; no filename-based import equivalence is asserted.

## Wobble and lifecycle (004e3500,004e36c0)

00429350 calls004e3500(1) for body0; offsets are forced0,0 and scale.5 via004e3590. Debug/wireframe flag is forced0 with004e35b0(0). Same seven-argument004e3bc0(device,cx,cy,R,zBase,zDelta,quality=1.2000000476837158) and same shade/mesh as the ordinary body packet. No emissive shading override: sun vertices still receive ordinary grayscale diffuse/specular.

Once per process-global initialization, the FIRST004e3500 call (even with flag0) fills2048 U and V speed entries in interleaved rand-call order:
 speedU[i]=float32((rand()%127)*float32(.00033333332976326346)+float32(.05000000074505806))
 speedV[i]=same expression using next rand().
The ready flag005d48bc is then1. Speed arrays are00a18690 and00a0d298. Phase arrays00a16690 and00a14690 are initially zero-filled and not reset by this initializer. CRT rand0055d520 (see rand.asm): state=state*214013+2531011 mod2^32, result=(state>>16)&32767. Shared RNG state at first use is not established, so no unique initial wobble realization is claimed.

For each emitted sun vertex index i, before UV output:
- If speedU[i] is exactly positive or negative0, replace with float32((rand()%127)*float32(.0007812500116415322)); same conditional separately for V. This is normally unreachable after positive-speed initialization but must not be silently changed.
- phaseU[i]=float32(phaseU[i]+speedU[i]); phaseV similarly.
- u = -.5*theta*cosPhi + float32(.029999999329447746)*cos(phaseU[i])
- v = -.5*theta*sinPhi + float32(.029999999329447746)*cos(phaseV[i]).
The phases persist by vertex INDEX as the adaptive ring count changes. Ordinary-body draws do not advance them. No dt is read here. This is per-emitted-sun-vertex/render-call behavior, not a recovered seconds rate. The body scene field U still increments.02 per draw, but body0 overwrites its supplied offsets, so that ordinary spin does not control the sun. Never invent30/60fps as native cadence. A deterministic seeded cosmetic RNG and elapsed-seconds frequency are modern compatibility decisions requiring explicit regression/documentation.

## Exact halo geometry and branches

After globe triangles004e411d, set render states19=5 (SRCALPHA),20=6 (INVSRCALPHA),27=1 (alpha blend),41=0 (color key off),15=0 (alpha test off). Only wobble flag nonzero enters halo. Width w=float32(.2*R); peak radius p=R+float32(-.2*w), approximately.96R. Outer radius R+w≈1.2R; inner radius R-w≈.8R. Segment count N=trunc(fullSegments), where fullSegments=2*pi/interpolatedSubdivisionAngle from the ordinary mesh initializer, NOT its smaller ring-count quantity.

ui+0x6e4 !=0: unbind texture (render state1=0). Store centre/depth/R/w/N and colour0x00800000, reset halo latch00a1468c=0, then004e3a40. Device initialization00520cd0 derives this capability from shadeCaps&0x4000 and explicitly disables it when ui+0x640==2; retained log literal identifies Gouraud alpha support.
004e3a40 checks latch and draws two strips via004e42b0:
1. radii(p,R+w), colours(0xff800000,0x00800000), mode0.
2. radii(R-w,p), colours(0x00800000,0xff800000), mode0.
Then latch=1. Both strips use same zBase and rhw=1/(zBase+.05). Thus halo is a triangular opacity profile centred around.96R, RGB(128,0,0), transparent at.8R/1.2R, alpha255 at peak, piecewise interpolated at vertices. It overlays part of the globe rim, not just outside its edge.

ui+0x6e4 ==0: bind0065c9c8 (pls.png), then direct004e42b0 calls:
1. radii(p,R+w), colours(ff800000,ff800000), mode0.
2. radii(R-w,p), colours(ff800000,ff800000), mode1.
No synthetic alpha ramp should replace this texture if claiming that fallback. Decoder/device texture format and bilinear edge quantization remain distinct limits.

004e42b0 signature is(device,cx,cy,z,radiusA,radiusB,colourA,colourB,N,mode). Start vectors(radiusA,0),(radiusB,0); rotate each by +2*pi/N BEFORE emitting each pair, for i=0..N inclusive. Coordinates are(cx+x,cy+y), with screen y down. Emit2*(N+1) vertices. Each i<N emits triangles(2i,2i+1,2i+2),(2i+1,2i+3,2i+2). Every vertex has specular0,u0; mode0 sets vA=.5,vB=0, mode!=0 sets vA=0,vB=.5. Native float32 recurrence preserves a duplicated seam; independent trig evaluation is an approximation at rounding edges. Call draw indexed triangle list, TL vertex type3, flags8. Shared mesh buffers are reset by each annulus call.

## State and draw order

00429350 sets texture addressing3=1 (wrap), legacy wrap flags5/6=0, alpha blend27=0, cull22=1 (none), unbinds prior texture then binds the chosen body.004e3bc0 sets address3=1, texture mag/min17/18=2 (linear), specular29=1 before globe indexed triangles. After its optional halo, states27 and29 are disabled. It does not locally disable depth writes for the halo. Scene setup004284d0 enables Z and Z write (states7/14=1). Do not invent a depthless always-on-top glow or additive pass.

Active loop:004110e0 →004284d0 →00455410 →00455810 →type5 →00429350.00455810 walks512 scene slots ascending from0072cd48 with stride100, skips inactive+0x60; no depth sort in this dispatch loop.00456b80 appends bodies and sets body index=slot-1. Setup constructs bodies in authored order before its orbit objects, so sun/body0 is the first body; sun globe and its two halo strips submit together before later body slots, with depth behavior retained. Panel overlays occur after scene work as prior packet establishes. No evidence here makes plsbackg.dat an active fullscreen draw.

## Acceptance and remaining boundary

Implement source-bound opaque sun image, same projection/mesh/shade, separate persistent wobble state and two-annulus Gouraud-alpha halo. Tests should cover body0 texture-object binding, no mission-palette averaging, UV offset override, non-sun draws not advancing phases, per-index persistence when tessellation changes, zero-speed branch, exact annulus radii/colours/indices and both native capability branches. Document chosen elapsed-time cosmetic animation frequency without labeling it native; test30/60/120/144Hz and irregular schedules. Source PNG copies need scoped importer/provenance ownership, no broad regeneration.

Stop condition reached: bounded sun component recipe; no broad renderer decompilation needed. Exact PNG decoder/device colour mapping, historical shared RNG seed, original render frequency, original GPU raster/filter/depth pixels, broader space sprites and full-screen parity remain unclaimed. Every new objdump/read/decode command succeeded; expected absent-file searches and default Git status failure are stated above. No native probe or browser comparison was run. Retain this report plus raw slices as durable evidence in a later writer-owned change, separately from PR464's current scope.
