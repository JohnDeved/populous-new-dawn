
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

0055d500 <.text+0x15c500>:
  55d500:	06                   	push   es
  55d501:	eb 0b                	jmp    0x55d50e
  55d503:	56                   	push   esi
  55d504:	e8 47 0f 00 00       	call   0x55e450
  55d509:	83 c4 04             	add    esp,0x4
  55d50c:	8b d8                	mov    ebx,eax
  55d50e:	56                   	push   esi
  55d50f:	e8 fc 0b 00 00       	call   0x55e110
  55d514:	83 c4 04             	add    esp,0x4
  55d517:	8b c3                	mov    eax,ebx
  55d519:	5e                   	pop    esi
  55d51a:	5b                   	pop    ebx
  55d51b:	c3                   	ret
  55d51c:	cc                   	int3
  55d51d:	cc                   	int3
  55d51e:	cc                   	int3
  55d51f:	cc                   	int3
  55d520:	e8 9b 53 00 00       	call   0x5628c0
  55d525:	8b 48 14             	mov    ecx,DWORD PTR [eax+0x14]
  55d528:	8b d1                	mov    edx,ecx
  55d52a:	8d 0c 89             	lea    ecx,[ecx+ecx*4]
  55d52d:	8d 0c 89             	lea    ecx,[ecx+ecx*4]
  55d530:	03 ca                	add    ecx,edx
  55d532:	8d 0c ca             	lea    ecx,[edx+ecx*8]
  55d535:	c1 e1 08             	shl    ecx,0x8
  55d538:	2b ca                	sub    ecx,edx
  55d53a:	8d 8c 8a c3 9e 26 00 	lea    ecx,[edx+ecx*4+0x269ec3]
  55d541:	89 48 14             	mov    DWORD PTR [eax+0x14],ecx
  55d544:	8b c1                	mov    eax,ecx
  55d546:	25 00 00 ff 7f       	and    eax,0x7fff0000
  55d54b:	c1 e8 10             	shr    eax,0x10
  55d54e:	c3                   	ret
  55d54f:	cc                   	int3
