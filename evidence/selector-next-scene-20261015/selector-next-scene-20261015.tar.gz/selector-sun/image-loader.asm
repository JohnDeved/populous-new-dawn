
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004309b0 <.text+0x2f9b0>:
  4309b0:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  4309b6:	55                   	push   ebp
  4309b7:	8b ec                	mov    ebp,esp
  4309b9:	6a ff                	push   0xffffffff
  4309bb:	68 c8 0a 43 00       	push   0x430ac8
  4309c0:	50                   	push   eax
  4309c1:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4309c8:	81 ec 38 04 00 00    	sub    esp,0x438
  4309ce:	8d 8d c0 fb ff ff    	lea    ecx,[ebp-0x440]
  4309d4:	56                   	push   esi
  4309d5:	57                   	push   edi
  4309d6:	e8 25 8a 0f 00       	call   0x529400
  4309db:	c7 85 bc fb ff ff f8 	mov    DWORD PTR [ebp-0x444],0x58f0f8
  4309e2:	f0 58 00 
  4309e5:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4309ec:	c7 45 ec 00 00 00 00 	mov    DWORD PTR [ebp-0x14],0x0
  4309f3:	c6 45 fc 01          	mov    BYTE PTR [ebp-0x4],0x1
  4309f7:	c7 85 bc fb ff ff e8 	mov    DWORD PTR [ebp-0x444],0x58f0e8
  4309fe:	f0 58 00 
  430a01:	c7 45 f0 00 00 00 00 	mov    DWORD PTR [ebp-0x10],0x0
  430a08:	c7 45 fc 02 00 00 00 	mov    DWORD PTR [ebp-0x4],0x2
  430a0f:	e8 0c 33 07 00       	call   0x4a3d20
  430a14:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
  430a17:	50                   	push   eax
  430a18:	68 23 cd 89 00       	push   0x89cd23
  430a1d:	e8 8e f7 0c 00       	call   0x5001b0
  430a22:	83 c4 08             	add    esp,0x8
  430a25:	8b 75 0c             	mov    esi,DWORD PTR [ebp+0xc]
  430a28:	8d 8d bc fb ff ff    	lea    ecx,[ebp-0x444]
  430a2e:	56                   	push   esi
  430a2f:	6a 00                	push   0x0
  430a31:	68 23 cd 89 00       	push   0x89cd23
  430a36:	e8 c5 82 0f 00       	call   0x528d00
  430a3b:	83 f8 ff             	cmp    eax,0xffffffff
  430a3e:	75 21                	jne    0x430a61
  430a40:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  430a47:	e8 86 00 00 00       	call   0x430ad2
  430a4c:	b8 ff ff ff ff       	mov    eax,0xffffffff
  430a51:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  430a54:	5f                   	pop    edi
  430a55:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  430a5c:	5e                   	pop    esi
  430a5d:	8b e5                	mov    esp,ebp
  430a5f:	5d                   	pop    ebp
  430a60:	c3                   	ret
  430a61:	8b ce                	mov    ecx,esi
  430a63:	e8 18 8a 0f 00       	call   0x529480
  430a68:	6a 00                	push   0x0
  430a6a:	8d 8d bc fb ff ff    	lea    ecx,[ebp-0x444]
  430a70:	6a 00                	push   0x0
  430a72:	68 23 cd 89 00       	push   0x89cd23
  430a77:	56                   	push   esi
  430a78:	e8 d3 83 0f 00       	call   0x528e50
  430a7d:	83 f8 ff             	cmp    eax,0xffffffff
  430a80:	75 09                	jne    0x430a8b
  430a82:	8b ce                	mov    ecx,esi
  430a84:	e8 37 8a 0f 00       	call   0x5294c0
  430a89:	eb b5                	jmp    0x430a40
  430a8b:	83 7d e8 00          	cmp    DWORD PTR [ebp-0x18],0x0
  430a8f:	74 14                	je     0x430aa5
  430a91:	8b 7d 10             	mov    edi,DWORD PTR [ebp+0x10]
  430a94:	85 ff                	test   edi,edi
  430a96:	74 0d                	je     0x430aa5
  430a98:	8d b5 e8 fb ff ff    	lea    esi,[ebp-0x418]
  430a9e:	b9 00 01 00 00       	mov    ecx,0x100
  430aa3:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  430aa5:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  430aac:	e8 21 00 00 00       	call   0x430ad2
  430ab1:	33 c0                	xor    eax,eax
  430ab3:	eb 9c                	jmp    0x430a51
  430ab5:	8d 4d ec             	lea    ecx,[ebp-0x14]
  430ab8:	e9 23 f1 fe ff       	jmp    0x41fbe0
  430abd:	8d 8d bc fb ff ff    	lea    ecx,[ebp-0x444]
  430ac3:	e9 e8 f0 fe ff       	jmp    0x41fbb0
  430ac8:	b8 70 51 59 00       	mov    eax,0x595170
  430acd:	e9 1e ad 12 00       	jmp    0x55b7f0
  430ad2:	8d 8d bc fb ff ff    	lea    ecx,[ebp-0x444]
  430ad8:	e9 93 f1 fe ff       	jmp    0x41fc70
  430add:	cc                   	int3
  430ade:	cc                   	int3
  430adf:	cc                   	int3
