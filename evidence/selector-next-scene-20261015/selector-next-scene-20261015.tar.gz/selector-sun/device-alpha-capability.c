    FUN_005218d0();
    uVar2 = (*(uint *)(iVar5 + 0x90) & 4) >> 2;
    *(uint *)(local_14 + 0x6d4) = uVar2;
    if (uVar2 != 0) {
      debug_log(s_Device_can_clamp_005dd88c);
    }
    *(uint *)(local_14 + 0x6dc) = (*(uint *)(iVar5 + 0x80) & 0x200) >> 9;
    if (*(int *)(local_14 + 0x640) == 1) {
      *(undefined4 *)(local_14 + 0x6dc) = 0;
    }
    if (*(int *)(local_14 + 0x6dc) != 0) {
      debug_log(s_Device_can_gouraud_shade_specula_005dd868);
    }
    uVar2 = (*(uint *)(iVar5 + 0x80) & 8) >> 3;
    *(uint *)(local_14 + 0x6e0) = uVar2;
    if (uVar2 != 0) {
      debug_log(s_Device_can_gouraud_shade_colour_005dd844);
    }
    *(uint *)(local_14 + 0x6e4) = (*(uint *)(iVar5 + 0x80) & 0x4000) >> 0xe;
    if (*(int *)(local_14 + 0x640) == 2) {
      *(undefined4 *)(local_14 + 0x6e4) = 0;
    }
    if (*(int *)(local_14 + 0x6e4) != 0) {
      debug_log(s_Device_can_gouraud_shade_alpha_005dd824);
    }
    if ((*(byte *)(iVar5 + 0x6e) & 2) != 0) {
      debug_log(s_Device_can_do_anisotropic_filter_005dd7fc);
    }
    if ((*(byte *)(iVar5 + 0x6d) & 4) != 0) {
      debug_log(s_Device_can_antialias_tris__sort_d_005dd7d0);
    }
