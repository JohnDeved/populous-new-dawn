
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00429350 <.text+0x28350>:
  429350:	83 ec 04             	sub    esp,0x4
  429353:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  429358:	56                   	push   esi
  429359:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  42935f:	c7 44 24 04 00 00 80 	mov    DWORD PTR [esp+0x4],0x3e800000
  429366:	3e 
  429367:	6a 01                	push   0x1
  429369:	8b 30                	mov    esi,DWORD PTR [eax]
  42936b:	6a 03                	push   0x3
  42936d:	50                   	push   eax
  42936e:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  429371:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429377:	6a 00                	push   0x0
  429379:	6a 05                	push   0x5
  42937b:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429381:	50                   	push   eax
  429382:	8b 30                	mov    esi,DWORD PTR [eax]
  429384:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  429387:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  42938d:	6a 00                	push   0x0
  42938f:	6a 06                	push   0x6
  429391:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429397:	50                   	push   eax
  429398:	8b 30                	mov    esi,DWORD PTR [eax]
  42939a:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  42939d:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293a3:	6a 00                	push   0x0
  4293a5:	6a 1b                	push   0x1b
  4293a7:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293ad:	50                   	push   eax
  4293ae:	8b 30                	mov    esi,DWORD PTR [eax]
  4293b0:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293b3:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293b9:	6a 01                	push   0x1
  4293bb:	6a 16                	push   0x16
  4293bd:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293c3:	50                   	push   eax
  4293c4:	8b 30                	mov    esi,DWORD PTR [eax]
  4293c6:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293c9:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293cf:	6a 00                	push   0x0
  4293d1:	6a 01                	push   0x1
  4293d3:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293d9:	50                   	push   eax
  4293da:	8b 30                	mov    esi,DWORD PTR [eax]
  4293dc:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293df:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
  4293e3:	85 f6                	test   esi,esi
  4293e5:	74 1e                	je     0x429405
  4293e7:	6a 00                	push   0x0
  4293e9:	e8 12 a1 0b 00       	call   0x4e3500
  4293ee:	83 c4 04             	add    esp,0x4
  4293f1:	8d 0c f5 00 00 00 00 	lea    ecx,[esi*8+0x0]
  4293f8:	2b ce                	sub    ecx,esi
  4293fa:	c1 e1 04             	shl    ecx,0x4
  4293fd:	03 0d fc c1 59 00    	add    ecx,DWORD PTR ds:0x59c1fc
  429403:	eb 21                	jmp    0x429426
  429405:	6a 01                	push   0x1
  429407:	e8 f4 a0 0b 00       	call   0x4e3500
  42940c:	83 c4 04             	add    esp,0x4
  42940f:	33 c0                	xor    eax,eax
  429411:	b9 d8 92 67 00       	mov    ecx,0x6792d8
  429416:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  42941a:	c7 44 24 04 00 00 00 	mov    DWORD PTR [esp+0x4],0x3f000000
  429421:	3f 
  429422:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  429426:	e8 f5 03 0e 00       	call   0x509820
  42942b:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  42942f:	8b 4c 24 28          	mov    ecx,DWORD PTR [esp+0x28]
  429433:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  429437:	50                   	push   eax
  429438:	51                   	push   ecx
  429439:	52                   	push   edx
  42943a:	e8 51 a1 0b 00       	call   0x4e3590
  42943f:	83 c4 0c             	add    esp,0xc
  429442:	6a 00                	push   0x0
  429444:	e8 67 a1 0b 00       	call   0x4e35b0
  429449:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  42944d:	8b 54 24 20          	mov    edx,DWORD PTR [esp+0x20]
  429451:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  429455:	83 c4 04             	add    esp,0x4
  429458:	68 9a 99 99 3f       	push   0x3f99999a
  42945d:	51                   	push   ecx
  42945e:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  429462:	52                   	push   edx
  429463:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  429467:	50                   	push   eax
  429468:	51                   	push   ecx
  429469:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  42946e:	52                   	push   edx
  42946f:	8b 88 48 06 00 00    	mov    ecx,DWORD PTR [eax+0x648]
  429475:	51                   	push   ecx
  429476:	e8 45 a7 0b 00       	call   0x4e3bc0
  42947b:	83 c4 1c             	add    esp,0x1c
  42947e:	5e                   	pop    esi
  42947f:	83 c4 04             	add    esp,0x4
  429482:	c3                   	ret
  429483:	cc                   	int3
  429484:	cc                   	int3
  429485:	cc                   	int3
  429486:	cc                   	int3
  429487:	cc                   	int3
  429488:	cc                   	int3
  429489:	cc                   	int3
  42948a:	cc                   	int3
  42948b:	cc                   	int3
  42948c:	cc                   	int3
  42948d:	cc                   	int3
  42948e:	cc                   	int3
  42948f:	cc                   	int3
