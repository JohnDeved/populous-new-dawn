
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004e42b0 <.text+0xe32b0>:
  4e42b0:	d9 44 24 10          	fld    DWORD PTR [esp+0x10]
  4e42b4:	d8 05 e0 f7 58 00    	fadd   DWORD PTR ds:0x58f7e0
  4e42ba:	83 ec 2c             	sub    esp,0x2c
  4e42bd:	33 c9                	xor    ecx,ecx
  4e42bf:	89 0d 88 48 5d 00    	mov    DWORD PTR ds:0x5d4888,ecx
  4e42c5:	53                   	push   ebx
  4e42c6:	d8 3d e4 f7 58 00    	fdivr  DWORD PTR ds:0x58f7e4
  4e42cc:	89 0d 90 48 5d 00    	mov    DWORD PTR ds:0x5d4890,ecx
  4e42d2:	89 0d 8c 48 5d 00    	mov    DWORD PTR ds:0x5d488c,ecx
  4e42d8:	56                   	push   esi
  4e42d9:	57                   	push   edi
  4e42da:	55                   	push   ebp
  4e42db:	8b 5c 24 60          	mov    ebx,DWORD PTR [esp+0x60]
  4e42df:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  4e42e3:	89 4c 24 20          	mov    DWORD PTR [esp+0x20],ecx
  4e42e7:	8b 54 24 54          	mov    edx,DWORD PTR [esp+0x54]
  4e42eb:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  4e42ef:	89 4c 24 28          	mov    DWORD PTR [esp+0x28],ecx
  4e42f3:	89 54 24 24          	mov    DWORD PTR [esp+0x24],edx
  4e42f7:	d9 5c 24 38          	fstp   DWORD PTR [esp+0x38]
  4e42fb:	d9 05 b0 f7 58 00    	fld    DWORD PTR ds:0x58f7b0
  4e4301:	da 74 24 60          	fidiv  DWORD PTR [esp+0x60]
  4e4305:	33 d2                	xor    edx,edx
  4e4307:	85 db                	test   ebx,ebx
  4e4309:	d8 0d 18 f8 58 00    	fmul   DWORD PTR ds:0x58f818
  4e430f:	d9 c0                	fld    st(0)
  4e4311:	d9 ff                	fcos
  4e4313:	d9 5c 24 18          	fstp   DWORD PTR [esp+0x18]
  4e4317:	d9 fe                	fsin
  4e4319:	d9 5c 24 14          	fstp   DWORD PTR [esp+0x14]
  4e431d:	0f 8c c6 01 00 00    	jl     0x4e44e9
  4e4323:	d9 44 24 48          	fld    DWORD PTR [esp+0x48]
  4e4327:	8b 6c 24 58          	mov    ebp,DWORD PTR [esp+0x58]
  4e432b:	d9 44 24 18          	fld    DWORD PTR [esp+0x18]
  4e432f:	d8 4c 24 1c          	fmul   DWORD PTR [esp+0x1c]
  4e4333:	d9 44 24 14          	fld    DWORD PTR [esp+0x14]
  4e4337:	d8 4c 24 20          	fmul   DWORD PTR [esp+0x20]
  4e433b:	3b da                	cmp    ebx,edx
  4e433d:	de e9                	fsubp  st(1),st
  4e433f:	d9 5c 24 10          	fstp   DWORD PTR [esp+0x10]
  4e4343:	d9 44 24 14          	fld    DWORD PTR [esp+0x14]
  4e4347:	d8 4c 24 1c          	fmul   DWORD PTR [esp+0x1c]
  4e434b:	d9 44 24 18          	fld    DWORD PTR [esp+0x18]
  4e434f:	d8 4c 24 20          	fmul   DWORD PTR [esp+0x20]
  4e4353:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4e4357:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  4e435b:	de c1                	faddp  st(1),st
  4e435d:	d9 5c 24 2c          	fstp   DWORD PTR [esp+0x2c]
  4e4361:	d9 44 24 18          	fld    DWORD PTR [esp+0x18]
  4e4365:	d8 4c 24 24          	fmul   DWORD PTR [esp+0x24]
  4e4369:	d9 44 24 14          	fld    DWORD PTR [esp+0x14]
  4e436d:	d8 4c 24 28          	fmul   DWORD PTR [esp+0x28]
  4e4371:	8b 74 24 2c          	mov    esi,DWORD PTR [esp+0x2c]
  4e4375:	89 74 24 20          	mov    DWORD PTR [esp+0x20],esi
  4e4379:	de e9                	fsubp  st(1),st
  4e437b:	d9 5c 24 30          	fstp   DWORD PTR [esp+0x30]
  4e437f:	d9 44 24 14          	fld    DWORD PTR [esp+0x14]
  4e4383:	d8 4c 24 24          	fmul   DWORD PTR [esp+0x24]
  4e4387:	d9 44 24 18          	fld    DWORD PTR [esp+0x18]
  4e438b:	d8 4c 24 28          	fmul   DWORD PTR [esp+0x28]
  4e438f:	8b 7c 24 30          	mov    edi,DWORD PTR [esp+0x30]
  4e4393:	89 7c 24 24          	mov    DWORD PTR [esp+0x24],edi
  4e4397:	de c1                	faddp  st(1),st
  4e4399:	d9 5c 24 34          	fstp   DWORD PTR [esp+0x34]
  4e439d:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  4e43a1:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  4e43a5:	7e 69                	jle    0x4e4410
  4e43a7:	8d 34 55 01 00 00 00 	lea    esi,[edx*2+0x1]
  4e43ae:	a1 90 48 5d 00       	mov    eax,ds:0x5d4890
  4e43b3:	03 c0                	add    eax,eax
  4e43b5:	8d 3c 55 00 00 00 00 	lea    edi,[edx*2+0x0]
  4e43bc:	66 89 b8 a8 32 a1 00 	mov    WORD PTR [eax+0xa132a8],di
  4e43c3:	83 05 90 48 5d 00 03 	add    DWORD PTR ds:0x5d4890,0x3
  4e43ca:	66 89 b0 aa 32 a1 00 	mov    WORD PTR [eax+0xa132aa],si
  4e43d1:	8d 34 55 02 00 00 00 	lea    esi,[edx*2+0x2]
  4e43d8:	66 89 b0 ac 32 a1 00 	mov    WORD PTR [eax+0xa132ac],si
  4e43df:	a1 90 48 5d 00       	mov    eax,ds:0x5d4890
  4e43e4:	03 c0                	add    eax,eax
  4e43e6:	8d 77 01             	lea    esi,[edi+0x1]
  4e43e9:	66 83 c7 03          	add    di,0x3
  4e43ed:	83 05 90 48 5d 00 03 	add    DWORD PTR ds:0x5d4890,0x3
  4e43f4:	66 89 b0 a8 32 a1 00 	mov    WORD PTR [eax+0xa132a8],si
  4e43fb:	8d 34 55 02 00 00 00 	lea    esi,[edx*2+0x2]
  4e4402:	66 89 b8 aa 32 a1 00 	mov    WORD PTR [eax+0xa132aa],di
  4e4409:	66 89 b0 ac 32 a1 00 	mov    WORD PTR [eax+0xa132ac],si
  4e4410:	d9 44 24 44          	fld    DWORD PTR [esp+0x44]
  4e4414:	d8 44 24 10          	fadd   DWORD PTR [esp+0x10]
  4e4418:	8b 35 88 48 5d 00    	mov    esi,DWORD PTR ds:0x5d4888
  4e441e:	8b 44 24 4c          	mov    eax,DWORD PTR [esp+0x4c]
  4e4422:	c1 e6 05             	shl    esi,0x5
  4e4425:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  4e4429:	39 4c 24 64          	cmp    DWORD PTR [esp+0x64],ecx
  4e442d:	d9 9e a8 35 a1 00    	fstp   DWORD PTR [esi+0xa135a8]
  4e4433:	d9 44 24 2c          	fld    DWORD PTR [esp+0x2c]
  4e4437:	d8 c1                	fadd   st,st(1)
  4e4439:	d9 9e ac 35 a1 00    	fstp   DWORD PTR [esi+0xa135ac]
  4e443f:	89 86 b0 35 a1 00    	mov    DWORD PTR [esi+0xa135b0],eax
  4e4445:	89 be b4 35 a1 00    	mov    DWORD PTR [esi+0xa135b4],edi
  4e444b:	89 8e c0 35 a1 00    	mov    DWORD PTR [esi+0xa135c0],ecx
  4e4451:	89 8e c4 35 a1 00    	mov    DWORD PTR [esi+0xa135c4],ecx
  4e4457:	75 0a                	jne    0x4e4463
  4e4459:	c7 86 c4 35 a1 00 00 	mov    DWORD PTR [esi+0xa135c4],0x3f000000
  4e4460:	00 00 3f 
  4e4463:	d9 44 24 44          	fld    DWORD PTR [esp+0x44]
  4e4467:	d8 44 24 30          	fadd   DWORD PTR [esp+0x30]
  4e446b:	8b 44 24 4c          	mov    eax,DWORD PTR [esp+0x4c]
  4e446f:	8b 7c 24 38          	mov    edi,DWORD PTR [esp+0x38]
  4e4473:	89 ae b8 35 a1 00    	mov    DWORD PTR [esi+0xa135b8],ebp
  4e4479:	ff 05 88 48 5d 00    	inc    DWORD PTR ds:0x5d4888
  4e447f:	89 8e bc 35 a1 00    	mov    DWORD PTR [esi+0xa135bc],ecx
  4e4485:	8b 35 88 48 5d 00    	mov    esi,DWORD PTR ds:0x5d4888
  4e448b:	c1 e6 05             	shl    esi,0x5
  4e448e:	39 4c 24 64          	cmp    DWORD PTR [esp+0x64],ecx
  4e4492:	d9 9e a8 35 a1 00    	fstp   DWORD PTR [esi+0xa135a8]
  4e4498:	d9 44 24 34          	fld    DWORD PTR [esp+0x34]
  4e449c:	d8 c1                	fadd   st,st(1)
  4e449e:	d9 9e ac 35 a1 00    	fstp   DWORD PTR [esi+0xa135ac]
  4e44a4:	89 86 b0 35 a1 00    	mov    DWORD PTR [esi+0xa135b0],eax
  4e44aa:	89 be b4 35 a1 00    	mov    DWORD PTR [esi+0xa135b4],edi
  4e44b0:	89 8e c0 35 a1 00    	mov    DWORD PTR [esi+0xa135c0],ecx
  4e44b6:	c7 86 c4 35 a1 00 00 	mov    DWORD PTR [esi+0xa135c4],0x3f000000
  4e44bd:	00 00 3f 
  4e44c0:	75 06                	jne    0x4e44c8
  4e44c2:	89 8e c4 35 a1 00    	mov    DWORD PTR [esi+0xa135c4],ecx
  4e44c8:	8b 44 24 5c          	mov    eax,DWORD PTR [esp+0x5c]
  4e44cc:	42                   	inc    edx
  4e44cd:	89 86 b8 35 a1 00    	mov    DWORD PTR [esi+0xa135b8],eax
  4e44d3:	ff 05 88 48 5d 00    	inc    DWORD PTR ds:0x5d4888
  4e44d9:	89 8e bc 35 a1 00    	mov    DWORD PTR [esi+0xa135bc],ecx
  4e44df:	3b da                	cmp    ebx,edx
  4e44e1:	0f 8d 44 fe ff ff    	jge    0x4e432b
  4e44e7:	dd d8                	fstp   st(0)
  4e44e9:	83 3d 90 48 5d 00 00 	cmp    DWORD PTR ds:0x5d4890,0x0
  4e44f0:	74 30                	je     0x4e4522
  4e44f2:	83 3d 88 48 5d 00 00 	cmp    DWORD PTR ds:0x5d4888,0x0
  4e44f9:	74 27                	je     0x4e4522
  4e44fb:	6a 08                	push   0x8
  4e44fd:	a1 90 48 5d 00       	mov    eax,ds:0x5d4890
  4e4502:	50                   	push   eax
  4e4503:	8b 0d 88 48 5d 00    	mov    ecx,DWORD PTR ds:0x5d4888
  4e4509:	8b 44 24 48          	mov    eax,DWORD PTR [esp+0x48]
  4e450d:	68 a8 32 a1 00       	push   0xa132a8
  4e4512:	51                   	push   ecx
  4e4513:	68 a8 35 a1 00       	push   0xa135a8
  4e4518:	6a 03                	push   0x3
  4e451a:	8b 18                	mov    ebx,DWORD PTR [eax]
  4e451c:	6a 04                	push   0x4
  4e451e:	50                   	push   eax
  4e451f:	ff 53 78             	call   DWORD PTR [ebx+0x78]
  4e4522:	33 c0                	xor    eax,eax
  4e4524:	5d                   	pop    ebp
  4e4525:	5f                   	pop    edi
  4e4526:	5e                   	pop    esi
  4e4527:	5b                   	pop    ebx
  4e4528:	83 c4 2c             	add    esp,0x2c
  4e452b:	c3                   	ret
  4e452c:	cc                   	int3
  4e452d:	cc                   	int3
  4e452e:	cc                   	int3
  4e452f:	cc                   	int3
  4e4530:	56                   	push   esi
  4e4531:	57                   	push   edi
  4e4532:	bf 20 3b a4 00       	mov    edi,0xa43b20
  4e4537:	be ff 01 00 00       	mov    esi,0x1ff
  4e453c:	8b cf                	mov    ecx,edi
  4e453e:	83 c7 64             	add    edi,0x64
  4e4541:	e8 0a 00 00 00       	call   0x4e4550
  4e4546:	4e                   	dec    esi
  4e4547:	79 f3                	jns    0x4e453c
  4e4549:	5f                   	pop    edi
  4e454a:	5e                   	pop    esi
  4e454b:	c3                   	ret
  4e454c:	cc                   	int3
  4e454d:	cc                   	int3
  4e454e:	cc                   	int3
  4e454f:	cc                   	int3
  4e4550:	56                   	push   esi
  4e4551:	c7 01 90 f1 58 00    	mov    DWORD PTR [ecx],0x58f190
  4e4557:	8b f1                	mov    esi,ecx
  4e4559:	e8 e2 4e 02 00       	call   0x509440
  4e455e:	8b c6                	mov    eax,esi
  4e4560:	c7 06 60 f8 58 00    	mov    DWORD PTR [esi],0x58f860
  4e4566:	5e                   	pop    esi
  4e4567:	c3                   	ret
  4e4568:	cc                   	int3
  4e4569:	cc                   	int3
  4e456a:	cc                   	int3
  4e456b:	cc                   	int3
  4e456c:	cc                   	int3
  4e456d:	cc                   	int3
  4e456e:	cc                   	int3
  4e456f:	cc                   	int3
  4e4570:	c3                   	ret
  4e4571:	cc                   	int3
  4e4572:	cc                   	int3
  4e4573:	cc                   	int3
  4e4574:	cc                   	int3
  4e4575:	cc                   	int3
  4e4576:	cc                   	int3
  4e4577:	cc                   	int3
  4e4578:	cc                   	int3
  4e4579:	cc                   	int3
  4e457a:	cc                   	int3
  4e457b:	cc                   	int3
  4e457c:	cc                   	int3
  4e457d:	cc                   	int3
  4e457e:	cc                   	int3
  4e457f:	cc                   	int3
  4e4580:	a1 fc 52 5d 00       	mov    eax,ds:0x5d52fc
  4e4585:	a3 c0 4b a6 00       	mov    ds:0xa64bc0,eax
  4e458a:	c3                   	ret
  4e458b:	cc                   	int3
  4e458c:	cc                   	int3
  4e458d:	cc                   	int3
  4e458e:	cc                   	int3
  4e458f:	cc                   	int3
  4e4590:	56                   	push   esi
  4e4591:	57                   	push   edi
  4e4592:	bf 48 4c a6 00       	mov    edi,0xa64c48
  4e4597:	be 05 00 00 00       	mov    esi,0x5
  4e459c:	8b cf                	mov    ecx,edi
  4e459e:	83 c7 60             	add    edi,0x60
  4e45a1:	e8 2a 3e f4 ff       	call   0x4283d0
  4e45a6:	4e                   	dec    esi
  4e45a7:	79 f3                	jns    0x4e459c
  4e45a9:	5f                   	pop    edi
  4e45aa:	5e                   	pop    esi
  4e45ab:	c3                   	ret
  4e45ac:	cc                   	int3
  4e45ad:	cc                   	int3
  4e45ae:	cc                   	int3
  4e45af:	cc                   	int3
  4e45b0:	56                   	push   esi
  4e45b1:	57                   	push   edi
  4e45b2:	bf 20 3f a3 00       	mov    edi,0xa33f20
  4e45b7:	be 7f 01 00 00       	mov    esi,0x17f
  4e45bc:	8b cf                	mov    ecx,edi
  4e45be:	83 c7 64             	add    edi,0x64
  4e45c1:	e8 8a ff ff ff       	call   0x4e4550
  4e45c6:	4e                   	dec    esi
  4e45c7:	79 f3                	jns    0x4e45bc
  4e45c9:	5f                   	pop    edi
  4e45ca:	5e                   	pop    esi
  4e45cb:	c3                   	ret
  4e45cc:	cc                   	int3
  4e45cd:	cc                   	int3
  4e45ce:	cc                   	int3
  4e45cf:	cc                   	int3
  4e45d0:	83 ec 78             	sub    esp,0x78
  4e45d3:	53                   	push   ebx
  4e45d4:	56                   	push   esi
  4e45d5:	57                   	push   edi
  4e45d6:	55                   	push   ebp
  4e45d7:	68 c4 53 5d 00       	push   0x5d53c4
  4e45dc:	e8 ef 2e f7 ff       	call   0x4574d0
  4e45e1:	83 c4 04             	add    esp,0x4
  4e45e4:	83 3d f8 52 5d 00 00 	cmp    DWORD PTR ds:0x5d52f8,0x0
  4e45eb:	0f 85 79 03 00 00    	jne    0x4e496a
  4e45f1:	f6 05 a7 5d 89 00 80 	test   BYTE PTR ds:0x895da7,0x80
  4e45f8:	b8 20 00 00 00       	mov    eax,0x20
  4e45fd:	75 05                	jne    0x4e4604
  4e45ff:	b8 10 00 00 00       	mov    eax,0x10
  4e4604:	a3 fc 52 5d 00       	mov    ds:0x5d52fc,eax
  4e4609:	a3 c0 4b a6 00       	mov    ds:0xa64bc0,eax
  4e460e:	8d 44 24 4c          	lea    eax,[esp+0x4c]
  4e4612:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4e4618:	50                   	push   eax
  4e4619:	8b 91 a0 1d 00 00    	mov    edx,DWORD PTR [ecx+0x1da0]
  4e461f:	52                   	push   edx
