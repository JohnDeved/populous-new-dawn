
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004b5f40 <.text+0xb4f40>:
  4b5f40:	81 ec 8c 00 00 00    	sub    esp,0x8c
  4b5f46:	8d 4c 24 14          	lea    ecx,[esp+0x14]
  4b5f4a:	53                   	push   ebx
  4b5f4b:	56                   	push   esi
  4b5f4c:	e8 af 34 07 00       	call   0x529400
  4b5f51:	8d 44 24 1c          	lea    eax,[esp+0x1c]
  4b5f55:	6a 00                	push   0x0
  4b5f57:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [esp+0x9c]
  4b5f5e:	50                   	push   eax
  4b5f5f:	51                   	push   ecx
  4b5f60:	e8 4b aa f7 ff       	call   0x4309b0
  4b5f65:	83 c4 0c             	add    esp,0xc
  4b5f68:	85 c0                	test   eax,eax
  4b5f6a:	0f 85 4a 01 00 00    	jne    0x4b60ba
  4b5f70:	83 7c 24 3c 18       	cmp    DWORD PTR [esp+0x3c],0x18
  4b5f75:	75 1c                	jne    0x4b5f93
  4b5f77:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [esp+0xa0]
  4b5f7e:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [esp+0x9c]
  4b5f85:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  4b5f89:	50                   	push   eax
  4b5f8a:	51                   	push   ecx
  4b5f8b:	52                   	push   edx
  4b5f8c:	e8 3f a7 f7 ff       	call   0x4306d0
  4b5f91:	eb 21                	jmp    0x4b5fb4
  4b5f93:	83 7c 24 3c 20       	cmp    DWORD PTR [esp+0x3c],0x20
  4b5f98:	75 1d                	jne    0x4b5fb7
  4b5f9a:	8b 84 24 a0 00 00 00 	mov    eax,DWORD PTR [esp+0xa0]
  4b5fa1:	8b 8c 24 9c 00 00 00 	mov    ecx,DWORD PTR [esp+0x9c]
  4b5fa8:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  4b5fac:	50                   	push   eax
  4b5fad:	51                   	push   ecx
  4b5fae:	52                   	push   edx
  4b5faf:	e8 6c a8 f7 ff       	call   0x430820
  4b5fb4:	83 c4 0c             	add    esp,0xc
  4b5fb7:	33 f6                	xor    esi,esi
  4b5fb9:	8a 9c 24 9c 00 00 00 	mov    bl,BYTE PTR [esp+0x9c]
  4b5fc0:	8d 44 24 08          	lea    eax,[esp+0x8]
  4b5fc4:	8b 8c 24 a4 00 00 00 	mov    ecx,DWORD PTR [esp+0xa4]
  4b5fcb:	89 74 24 08          	mov    DWORD PTR [esp+0x8],esi
  4b5fcf:	50                   	push   eax
  4b5fd0:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  4b5fd4:	68 00 18 00 00       	push   0x1800
  4b5fd9:	51                   	push   ecx
  4b5fda:	56                   	push   esi
  4b5fdb:	8a 8c 24 b0 00 00 00 	mov    cl,BYTE PTR [esp+0xb0]
  4b5fe2:	d3 e8                	shr    eax,cl
  4b5fe4:	50                   	push   eax
  4b5fe5:	8a cb                	mov    cl,bl
  4b5fe7:	8b 44 24 34          	mov    eax,DWORD PTR [esp+0x34]
  4b5feb:	d3 e8                	shr    eax,cl
  4b5fed:	50                   	push   eax
  4b5fee:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b5ff4:	8b 51 04             	mov    edx,DWORD PTR [ecx+0x4]
  4b5ff7:	52                   	push   edx
  4b5ff8:	e8 f3 94 f7 ff       	call   0x42f4f0
  4b5ffd:	8d 4c 24 60          	lea    ecx,[esp+0x60]
  4b6001:	83 c4 1c             	add    esp,0x1c
  4b6004:	e8 f7 33 07 00       	call   0x529400
  4b6009:	8d 4c 24 44          	lea    ecx,[esp+0x44]
  4b600d:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  4b6011:	51                   	push   ecx
  4b6012:	52                   	push   edx
  4b6013:	e8 c8 aa f7 ff       	call   0x430ae0
  4b6018:	8d 4c 24 74          	lea    ecx,[esp+0x74]
  4b601c:	83 c4 08             	add    esp,0x8
  4b601f:	e8 dc 33 07 00       	call   0x529400
  4b6024:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  4b6028:	8a cb                	mov    cl,bl
  4b602a:	89 74 24 0c          	mov    DWORD PTR [esp+0xc],esi
  4b602e:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  4b6032:	d3 e8                	shr    eax,cl
  4b6034:	8a 8c 24 a0 00 00 00 	mov    cl,BYTE PTR [esp+0xa0]
  4b603b:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  4b603f:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  4b6043:	8d 54 24 6c          	lea    edx,[esp+0x6c]
  4b6047:	d3 e8                	shr    eax,cl
  4b6049:	8d 4c 24 0c          	lea    ecx,[esp+0xc]
  4b604d:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  4b6051:	51                   	push   ecx
  4b6052:	52                   	push   edx
  4b6053:	8d 4c 24 24          	lea    ecx,[esp+0x24]
  4b6057:	e8 e4 34 07 00       	call   0x529540
  4b605c:	8d 4c 24 44          	lea    ecx,[esp+0x44]
  4b6060:	56                   	push   esi
  4b6061:	8d 54 24 70          	lea    edx,[esp+0x70]
  4b6065:	51                   	push   ecx
  4b6066:	52                   	push   edx
  4b6067:	e8 34 a6 f7 ff       	call   0x4306a0
  4b606c:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  4b6070:	83 c4 0c             	add    esp,0xc
  4b6073:	51                   	push   ecx
  4b6074:	e8 17 ab f7 ff       	call   0x430b90
  4b6079:	83 c4 04             	add    esp,0x4
  4b607c:	56                   	push   esi
  4b607d:	56                   	push   esi
  4b607e:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  4b6082:	51                   	push   ecx
  4b6083:	8b 8c 24 b4 00 00 00 	mov    ecx,DWORD PTR [esp+0xb4]
  4b608a:	e8 d1 37 05 00       	call   0x509860
  4b608f:	39 74 24 08          	cmp    DWORD PTR [esp+0x8],esi
  4b6093:	74 0e                	je     0x4b60a3
  4b6095:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  4b6099:	50                   	push   eax
  4b609a:	8b 18                	mov    ebx,DWORD PTR [eax]
  4b609c:	ff 53 08             	call   DWORD PTR [ebx+0x8]
  4b609f:	89 74 24 08          	mov    DWORD PTR [esp+0x8],esi
  4b60a3:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  4b60a7:	e8 14 34 07 00       	call   0x5294c0
  4b60ac:	b8 01 00 00 00       	mov    eax,0x1
  4b60b1:	5e                   	pop    esi
  4b60b2:	5b                   	pop    ebx
  4b60b3:	81 c4 8c 00 00 00    	add    esp,0x8c
  4b60b9:	c3                   	ret
  4b60ba:	33 c0                	xor    eax,eax
  4b60bc:	5e                   	pop    esi
  4b60bd:	5b                   	pop    ebx
  4b60be:	81 c4 8c 00 00 00    	add    esp,0x8c
  4b60c4:	c3                   	ret
  4b60c5:	cc                   	int3
  4b60c6:	cc                   	int3
  4b60c7:	cc                   	int3
  4b60c8:	cc                   	int3
  4b60c9:	cc                   	int3
  4b60ca:	cc                   	int3
  4b60cb:	cc                   	int3
  4b60cc:	cc                   	int3
  4b60cd:	cc                   	int3
  4b60ce:	cc                   	int3
  4b60cf:	cc                   	int3
  4b60d0:	81 ec 84 00 00 00    	sub    esp,0x84
  4b60d6:	53                   	push   ebx
  4b60d7:	56                   	push   esi
  4b60d8:	57                   	push   edi
  4b60d9:	55                   	push   ebp
  4b60da:	68 44 43 5d 00       	push   0x5d4344
  4b60df:	e8 ec 13 fa ff       	call   0x4574d0
  4b60e4:	83 c4 04             	add    esp,0x4
  4b60e7:	83 3d e4 e0 5c 00 00 	cmp    DWORD PTR ds:0x5ce0e4,0x0
  4b60ee:	0f 85 07 02 00 00    	jne    0x4b62fb
  4b60f4:	68 f8 c7 9b 00       	push   0x9bc7f8
  4b60f9:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  4b60fe:	8b 88 a0 1d 00 00    	mov    ecx,DWORD PTR [eax+0x1da0]
  4b6104:	51                   	push   ecx
  4b6105:	6a 03                	push   0x3
  4b6107:	6a 03                	push   0x3
  4b6109:	68 e0 15 99 00       	push   0x9915e0
  4b610e:	e8 2d fe ff ff       	call   0x4b5f40
  4b6113:	83 c4 14             	add    esp,0x14
  4b6116:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b611c:	83 b9 14 0d 00 00 00 	cmp    DWORD PTR [ecx+0xd14],0x0
  4b6123:	74 6c                	je     0x4b6191
  4b6125:	85 c0                	test   eax,eax
  4b6127:	74 68                	je     0x4b6191
  4b6129:	8b b1 a8 1d 00 00    	mov    esi,DWORD PTR [ecx+0x1da8]
  4b612f:	68 18 c7 9b 00       	push   0x9bc718
  4b6134:	c7 05 d0 54 5d 00 00 	mov    DWORD PTR ds:0x5d54d0,0x0
  4b613b:	00 00 00 
  4b613e:	56                   	push   esi
  4b613f:	6a 02                	push   0x2
  4b6141:	6a 02                	push   0x2
  4b6143:	68 08 15 99 00       	push   0x991508
  4b6148:	e8 f3 fd ff ff       	call   0x4b5f40
  4b614d:	83 c4 14             	add    esp,0x14
  4b6150:	85 c0                	test   eax,eax
  4b6152:	0f 84 99 01 00 00    	je     0x4b62f1
  4b6158:	68 88 c7 9b 00       	push   0x9bc788
  4b615d:	56                   	push   esi
  4b615e:	6a 02                	push   0x2
  4b6160:	6a 02                	push   0x2
  4b6162:	68 a0 15 99 00       	push   0x9915a0
  4b6167:	e8 d4 fd ff ff       	call   0x4b5f40
  4b616c:	83 c4 14             	add    esp,0x14
  4b616f:	85 c0                	test   eax,eax
  4b6171:	75 0f                	jne    0x4b6182
  4b6173:	b9 18 c7 9b 00       	mov    ecx,0x9bc718
  4b6178:	e8 c3 38 05 00       	call   0x509a40
  4b617d:	e9 6f 01 00 00       	jmp    0x4b62f1
  4b6182:	c7 05 d0 54 5d 00 02 	mov    DWORD PTR ds:0x5d54d0,0x2
  4b6189:	00 00 00 
  4b618c:	e9 60 01 00 00       	jmp    0x4b62f1
  4b6191:	c7 05 d0 54 5d 00 01 	mov    DWORD PTR ds:0x5d54d0,0x1
  4b6198:	00 00 00 
  4b619b:	66 8b b4 24 9c 00 00 	mov    si,WORD PTR [esp+0x9c]
  4b61a2:	00 
  4b61a3:	6a 00                	push   0x0
  4b61a5:	66 8b 9c 24 a4 00 00 	mov    bx,WORD PTR [esp+0xa4]
  4b61ac:	00 
  4b61ad:	8b 84 24 9c 00 00 00 	mov    eax,DWORD PTR [esp+0x9c]
  4b61b4:	0f b7 fe             	movzx  edi,si
  4b61b7:	0f b7 eb             	movzx  ebp,bx
  4b61ba:	89 7c 24 48          	mov    DWORD PTR [esp+0x48],edi
  4b61be:	50                   	push   eax
  4b61bf:	89 6c 24 50          	mov    DWORD PTR [esp+0x50],ebp
  4b61c3:	68 80 5b d0 00       	push   0xd05b80
  4b61c8:	8b 54 24 50          	mov    edx,DWORD PTR [esp+0x50]
  4b61cc:	8b 4c 24 54          	mov    ecx,DWORD PTR [esp+0x54]
  4b61d0:	51                   	push   ecx
  4b61d1:	52                   	push   edx
  4b61d2:	8d 4c 24 58          	lea    ecx,[esp+0x58]
  4b61d6:	e8 45 32 07 00       	call   0x529420
  4b61db:	89 6c 24 18          	mov    DWORD PTR [esp+0x18],ebp
  4b61df:	6a 00                	push   0x0
  4b61e1:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  4b61e5:	6a 00                	push   0x0
  4b61e7:	68 50 5b d0 00       	push   0xd05b50
  4b61ec:	51                   	push   ecx
  4b61ed:	8d 4c 24 2c          	lea    ecx,[esp+0x2c]
  4b61f1:	57                   	push   edi
  4b61f2:	e8 29 32 07 00       	call   0x529420
  4b61f7:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  4b61fb:	e8 80 32 07 00       	call   0x529480
  4b6200:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  4b6204:	8b 7c 24 1c          	mov    edi,DWORD PTR [esp+0x1c]
  4b6208:	0f af 54 24 28       	imul   edx,DWORD PTR [esp+0x28]
  4b620d:	33 c0                	xor    eax,eax
  4b620f:	8b ca                	mov    ecx,edx
  4b6211:	c1 e9 02             	shr    ecx,0x2
  4b6214:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  4b6216:	8b ca                	mov    ecx,edx
  4b6218:	83 e1 03             	and    ecx,0x3
  4b621b:	f3 aa                	rep stos BYTE PTR es:[edi],al
  4b621d:	a1 f8 ef 87 00       	mov    eax,ds:0x87eff8
  4b6222:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  4b6226:	8d 54 24 44          	lea    edx,[esp+0x44]
  4b622a:	50                   	push   eax
  4b622b:	51                   	push   ecx
  4b622c:	52                   	push   edx
  4b622d:	e8 6e a4 f7 ff       	call   0x4306a0
  4b6232:	8d 4c 24 28          	lea    ecx,[esp+0x28]
  4b6236:	83 c4 0c             	add    esp,0xc
  4b6239:	6a 02                	push   0x2
  4b623b:	6a 02                	push   0x2
  4b623d:	51                   	push   ecx
  4b623e:	e8 8d a4 f7 ff       	call   0x4306d0
  4b6243:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  4b6247:	8b 15 f4 c2 af 00    	mov    edx,DWORD PTR ds:0xafc2f4
  4b624d:	c7 44 24 1c 00 00 00 	mov    DWORD PTR [esp+0x1c],0x0
  4b6254:	00 
  4b6255:	83 c4 0c             	add    esp,0xc
  4b6258:	8b 82 a0 1d 00 00    	mov    eax,DWORD PTR [edx+0x1da0]
  4b625e:	51                   	push   ecx
  4b625f:	68 00 18 00 00       	push   0x1800
  4b6264:	50                   	push   eax
  4b6265:	66 c1 eb 02          	shr    bx,0x2
  4b6269:	6a 00                	push   0x0
  4b626b:	66 c1 ee 02          	shr    si,0x2
  4b626f:	53                   	push   ebx
  4b6270:	56                   	push   esi
  4b6271:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  4b6274:	50                   	push   eax
  4b6275:	e8 76 92 f7 ff       	call   0x42f4f0
  4b627a:	8d 8c 24 88 00 00 00 	lea    ecx,[esp+0x88]
  4b6281:	83 c4 1c             	add    esp,0x1c
  4b6284:	e8 77 31 07 00       	call   0x529400
  4b6289:	8d 4c 24 6c          	lea    ecx,[esp+0x6c]
  4b628d:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  4b6291:	51                   	push   ecx
  4b6292:	52                   	push   edx
  4b6293:	e8 48 a8 f7 ff       	call   0x430ae0
  4b6298:	8d 4c 24 74          	lea    ecx,[esp+0x74]
  4b629c:	8d 54 24 24          	lea    edx,[esp+0x24]
  4b62a0:	83 c4 08             	add    esp,0x8
  4b62a3:	6a 00                	push   0x0
  4b62a5:	51                   	push   ecx
  4b62a6:	52                   	push   edx
  4b62a7:	e8 f4 a3 f7 ff       	call   0x4306a0
  4b62ac:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  4b62b0:	83 c4 0c             	add    esp,0xc
  4b62b3:	51                   	push   ecx
  4b62b4:	e8 d7 a8 f7 ff       	call   0x430b90
  4b62b9:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  4b62bd:	83 c4 04             	add    esp,0x4
  4b62c0:	6a 00                	push   0x0
  4b62c2:	6a 00                	push   0x0
  4b62c4:	51                   	push   ecx
  4b62c5:	b9 18 c7 9b 00       	mov    ecx,0x9bc718
  4b62ca:	e8 91 35 05 00       	call   0x509860
  4b62cf:	83 7c 24 10 00       	cmp    DWORD PTR [esp+0x10],0x0
  4b62d4:	74 12                	je     0x4b62e8
  4b62d6:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4b62da:	50                   	push   eax
  4b62db:	8b 18                	mov    ebx,DWORD PTR [eax]
  4b62dd:	ff 53 08             	call   DWORD PTR [ebx+0x8]
  4b62e0:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  4b62e7:	00 
  4b62e8:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  4b62ec:	e8 cf 31 07 00       	call   0x5294c0
  4b62f1:	c7 05 e4 e0 5c 00 01 	mov    DWORD PTR ds:0x5ce0e4,0x1
  4b62f8:	00 00 00 
  4b62fb:	68 2c 43 5d 00       	push   0x5d432c
