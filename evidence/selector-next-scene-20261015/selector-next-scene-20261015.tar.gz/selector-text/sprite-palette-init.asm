  428e70:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  428e76:	55                   	push   ebp
  428e77:	8b ec                	mov    ebp,esp
  428e79:	6a ff                	push   0xffffffff
  428e7b:	68 4c 90 42 00       	push   0x42904c
  428e80:	50                   	push   eax
  428e81:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  428e88:	83 ec 38             	sub    esp,0x38
  428e8b:	53                   	push   ebx
  428e8c:	56                   	push   esi
  428e8d:	57                   	push   edi
  428e8e:	e8 ed e8 0e 00       	call   0x517780
  428e93:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  428e98:	6a 0c                	push   0xc
  428e9a:	8b b0 a8 1d 00 00    	mov    esi,DWORD PTR [eax+0x1da8]
  428ea0:	e8 fb 1d 13 00       	call   0x55aca0
  428ea5:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  428ea8:	83 c4 04             	add    esp,0x4
  428eab:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  428eb2:	8b f8                	mov    edi,eax
  428eb4:	b8 00 00 00 00       	mov    eax,0x0
  428eb9:	85 ff                	test   edi,edi
  428ebb:	74 4b                	je     0x428f08
  428ebd:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
  428ec0:	89 45 e0             	mov    DWORD PTR [ebp-0x20],eax
  428ec3:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
  428ec6:	89 4d e4             	mov    DWORD PTR [ebp-0x1c],ecx
  428ec9:	8b 56 18             	mov    edx,DWORD PTR [esi+0x18]
  428ecc:	89 55 e8             	mov    DWORD PTR [ebp-0x18],edx
  428ecf:	8b 46 1c             	mov    eax,DWORD PTR [esi+0x1c]
  428ed2:	89 45 ec             	mov    DWORD PTR [ebp-0x14],eax
  428ed5:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  428ed8:	89 4d d0             	mov    DWORD PTR [ebp-0x30],ecx
  428edb:	8b 56 14             	mov    edx,DWORD PTR [esi+0x14]
  428ede:	89 55 d4             	mov    DWORD PTR [ebp-0x2c],edx
  428ee1:	8d 55 e0             	lea    edx,[ebp-0x20]
  428ee4:	8b 46 18             	mov    eax,DWORD PTR [esi+0x18]
  428ee7:	52                   	push   edx
  428ee8:	89 45 d8             	mov    DWORD PTR [ebp-0x28],eax
  428eeb:	8d 45 d0             	lea    eax,[ebp-0x30]
  428eee:	8b 4e 1c             	mov    ecx,DWORD PTR [esi+0x1c]
  428ef1:	50                   	push   eax
  428ef2:	68 00 f0 87 00       	push   0x87f000
  428ef7:	89 4d dc             	mov    DWORD PTR [ebp-0x24],ecx
  428efa:	8b 0d f8 ef 87 00    	mov    ecx,DWORD PTR ds:0x87eff8
  428f00:	51                   	push   ecx
  428f01:	8b cf                	mov    ecx,edi
  428f03:	e8 68 d6 04 00       	call   0x476570
  428f08:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  428f0f:	68 f8 c3 59 00       	push   0x59c3f8
  428f14:	a3 00 c2 59 00       	mov    ds:0x59c200,eax
  428f19:	a3 cc cb 87 00       	mov    ds:0x87cbcc,eax
  428f1e:	e8 ad e5 02 00       	call   0x4574d0
  428f23:	83 c4 04             	add    esp,0x4
  428f26:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  428f2b:	6a 00                	push   0x0
  428f2d:	8b 48 04             	mov    ecx,DWORD PTR [eax+0x4]
  428f30:	56                   	push   esi
  428f31:	51                   	push   ecx
  428f32:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  428f37:	e8 f4 75 03 00       	call   0x460530
  428f3c:	8b f8                	mov    edi,eax
  428f3e:	85 ff                	test   edi,edi
  428f40:	7d 21                	jge    0x428f63
  428f42:	57                   	push   edi
  428f43:	68 44 c3 59 00       	push   0x59c344
  428f48:	e8 83 e5 02 00       	call   0x4574d0
  428f4d:	83 c4 08             	add    esp,0x8
  428f50:	8b c7                	mov    eax,edi
  428f52:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  428f55:	5f                   	pop    edi
  428f56:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  428f5d:	5e                   	pop    esi
  428f5e:	5b                   	pop    ebx
  428f5f:	8b e5                	mov    esp,ebp
  428f61:	5d                   	pop    ebp
  428f62:	c3                   	ret
  428f63:	68 38 c3 59 00       	push   0x59c338
  428f68:	bb 50 ea 66 00       	mov    ebx,0x66ea50
  428f6d:	bf 48 a3 67 00       	mov    edi,0x67a348
  428f72:	e8 59 e5 02 00       	call   0x4574d0
  428f77:	83 c4 04             	add    esp,0x4
  428f7a:	68 e4 c3 59 00       	push   0x59c3e4
  428f7f:	e8 4c e5 02 00       	call   0x4574d0
  428f84:	83 c4 04             	add    esp,0x4
  428f87:	8b cf                	mov    ecx,edi
  428f89:	68 38 ca 65 00       	push   0x65ca38
  428f8e:	6a 00                	push   0x0
  428f90:	56                   	push   esi
  428f91:	68 80 00 00 00       	push   0x80
  428f96:	68 80 00 00 00       	push   0x80
  428f9b:	e8 e0 d4 04 00       	call   0x476480
  428fa0:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  428fa3:	85 c0                	test   eax,eax
  428fa5:	7c 78                	jl     0x42901f
  428fa7:	68 38 c3 59 00       	push   0x59c338
  428fac:	e8 1f e5 02 00       	call   0x4574d0
  428fb1:	83 c4 04             	add    esp,0x4
  428fb4:	8b 47 38             	mov    eax,DWORD PTR [edi+0x38]
  428fb7:	8b 4f 40             	mov    ecx,DWORD PTR [edi+0x40]
  428fba:	8b 57 48             	mov    edx,DWORD PTR [edi+0x48]
  428fbd:	89 45 bc             	mov    DWORD PTR [ebp-0x44],eax
  428fc0:	8d 45 bc             	lea    eax,[ebp-0x44]
  428fc3:	50                   	push   eax
  428fc4:	89 4d c0             	mov    DWORD PTR [ebp-0x40],ecx
  428fc7:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  428fcc:	89 55 c4             	mov    DWORD PTR [ebp-0x3c],edx
  428fcf:	89 7d c8             	mov    DWORD PTR [ebp-0x38],edi
  428fd2:	e8 a9 76 03 00       	call   0x460680
  428fd7:	89 5f 58             	mov    DWORD PTR [edi+0x58],ebx
  428fda:	83 c7 60             	add    edi,0x60
  428fdd:	83 c3 24             	add    ebx,0x24
  428fe0:	81 ff c8 a4 67 00    	cmp    edi,0x67a4c8
  428fe6:	72 92                	jb     0x428f7a
  428fe8:	c7 05 24 c3 59 00 38 	mov    DWORD PTR ds:0x59c324,0x65ca38
  428fef:	ca 65 00 
  428ff2:	68 c8 c3 59 00       	push   0x59c3c8
  428ff7:	e8 d4 e4 02 00       	call   0x4574d0
  428ffc:	83 c4 04             	add    esp,0x4
  428fff:	e8 4c 5d 05 00       	call   0x47ed50
  429004:	8b f0                	mov    esi,eax
  429006:	85 f6                	test   esi,esi
  429008:	7d 2e                	jge    0x429038
  42900a:	56                   	push   esi
  42900b:	68 44 c3 59 00       	push   0x59c344
  429010:	e8 bb e4 02 00       	call   0x4574d0
  429015:	83 c4 08             	add    esp,0x8
  429018:	8b c6                	mov    eax,esi
  42901a:	e9 33 ff ff ff       	jmp    0x428f52
  42901f:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  429022:	50                   	push   eax
  429023:	68 44 c3 59 00       	push   0x59c344
  429028:	e8 a3 e4 02 00       	call   0x4574d0
  42902d:	83 c4 08             	add    esp,0x8
  429030:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  429033:	e9 1a ff ff ff       	jmp    0x428f52
  429038:	68 38 c3 59 00       	push   0x59c338
  42903d:	e8 8e e4 02 00       	call   0x4574d0
