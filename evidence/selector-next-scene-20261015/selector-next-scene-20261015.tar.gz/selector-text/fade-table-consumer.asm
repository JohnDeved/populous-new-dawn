  4bf506:	8b d6                	mov    edx,esi
  4bf508:	8b 1d b8 45 5d 00    	mov    ebx,DWORD PTR ds:0x5d45b8
  4bf50e:	c1 fa 10             	sar    edx,0x10
  4bf511:	0f be 29             	movsx  ebp,BYTE PTR [ecx]
  4bf514:	0f bf 14 53          	movsx  edx,WORD PTR [ebx+edx*2]
  4bf518:	0f af d5             	imul   edx,ebp
  4bf51b:	c1 fd 02             	sar    ebp,0x2
  4bf51e:	81 e2 03 fc ff ff    	and    edx,0xfffffc03
  4bf524:	c1 fa 02             	sar    edx,0x2
  4bf527:	8b de                	mov    ebx,esi
  4bf529:	81 e3 ff 00 ff ff    	and    ebx,0xffff00ff
  4bf52f:	03 74 24 38          	add    esi,DWORD PTR [esp+0x38]
  4bf533:	c1 fb 08             	sar    ebx,0x8
  4bf536:	03 da                	add    ebx,edx
  4bf538:	8b d0                	mov    edx,eax
  4bf53a:	c1 fa 10             	sar    edx,0x10
  4bf53d:	03 d5                	add    edx,ebp
  4bf53f:	84 f6                	test   dh,dh
  4bf541:	74 15                	je     0x4bf558
  4bf543:	85 d2                	test   edx,edx
  4bf545:	7d 04                	jge    0x4bf54b
  4bf547:	33 d2                	xor    edx,edx
  4bf549:	eb 0d                	jmp    0x4bf558
  4bf54b:	81 fa ff 00 00 00    	cmp    edx,0xff
  4bf551:	7e 05                	jle    0x4bf558
  4bf553:	ba ff 00 00 00       	mov    edx,0xff
  4bf558:	03 da                	add    ebx,edx
  4bf55a:	03 44 24 34          	add    eax,DWORD PTR [esp+0x34]
  4bf55e:	8b 2d c8 45 5d 00    	mov    ebp,DWORD PTR ds:0x5d45c8
  4bf564:	33 d2                	xor    edx,edx
  4bf566:	8a 14 2b             	mov    dl,BYTE PTR [ebx+ebp*1]
  4bf569:	8b 5c 24 64          	mov    ebx,DWORD PTR [esp+0x64]
  4bf56d:	c1 fb 12             	sar    ebx,0x12
  4bf570:	8b 2d cc 45 5d 00    	mov    ebp,DWORD PTR ds:0x5d45cc
  4bf576:	c1 e3 07             	shl    ebx,0x7
  4bf579:	03 d3                	add    edx,ebx
  4bf57b:	33 db                	xor    ebx,ebx
  4bf57d:	47                   	inc    edi
  4bf57e:	83 c1 04             	add    ecx,0x4
  4bf581:	8a 1c 2a             	mov    bl,BYTE PTR [edx+ebp*1]
  4bf584:	8b 54 24 68          	mov    edx,DWORD PTR [esp+0x68]
  4bf588:	81 e2 ff 00 ff ff    	and    edx,0xffff00ff
  4bf58e:	c1 fa 08             	sar    edx,0x8
  4bf591:	8a 94 13 e0 ea 96 00 	mov    dl,BYTE PTR [ebx+edx*1+0x96eae0]
  4bf598:	8b 5c 24 3c          	mov    ebx,DWORD PTR [esp+0x3c]
  4bf59c:	88 57 ff             	mov    BYTE PTR [edi-0x1],dl
  4bf59f:	01 5c 24 64          	add    DWORD PTR [esp+0x64],ebx
  4bf5a3:	8b 54 24 40          	mov    edx,DWORD PTR [esp+0x40]
  4bf5a7:	01 54 24 68          	add    DWORD PTR [esp+0x68],edx
  4bf5ab:	ff 4c 24 44          	dec    DWORD PTR [esp+0x44]
  4bf5af:	0f 85 51 ff ff ff    	jne    0x4bf506
  4bf5b5:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
