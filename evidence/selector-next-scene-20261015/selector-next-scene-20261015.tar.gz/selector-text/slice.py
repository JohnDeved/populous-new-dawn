import sys,re
from pathlib import Path
a,b=map(lambda x:int(x,16),sys.argv[1:3]); s=Path('/tmp/selector-text/full.asm').read_text().splitlines()
print('\n'.join(l for l in s if (m:=re.match(r'\s*([0-9a-f]+):',l)) and a<=int(m[1],16)<b))
