from pathlib import Path
import struct
p=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe').read_bytes()
def data(a,n):
 for va,off,size in [(0x401000,0x400,0x184a24),(0x58f000,0x18d800,0x8578),(0x598000,0x195e00,0x58600)]:
  if va<=a<va+size:return p[off+a-va:off+a-va+n]
def u(a):return struct.unpack('<I',data(a,4))[0]
for a in [0x5d4784,0x599970,0x59c328]:print(hex(a),data(a,40))
for i in range(12):
 a=0x5d5b08+i*48; v=struct.unpack('<12I',data(a,48)); print(i,[hex(x) for x in v], [data(x,50) for x in v[:3]])
q=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/language/lang00.dat').read_bytes();print('lang',q[:80])
