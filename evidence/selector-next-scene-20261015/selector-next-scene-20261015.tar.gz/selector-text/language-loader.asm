  492e60:	81 ec 28 02 00 00    	sub    esp,0x228
  492e66:	8d 84 24 18 01 00 00 	lea    eax,[esp+0x118]
  492e6d:	56                   	push   esi
  492e6e:	57                   	push   edi
  492e6f:	6a 00                	push   0x0
  492e71:	68 b4 a2 5c 00       	push   0x5ca2b4
  492e76:	50                   	push   eax
  492e77:	e8 64 d1 06 00       	call   0x4fffe0
  492e7c:	8b b4 24 40 02 00 00 	mov    esi,DWORD PTR [esp+0x240]
  492e83:	8d 84 24 2c 01 00 00 	lea    eax,[esp+0x12c]
  492e8a:	8d 4c 24 1c          	lea    ecx,[esp+0x1c]
  492e8e:	83 c4 0c             	add    esp,0xc
  492e91:	56                   	push   esi
  492e92:	50                   	push   eax
  492e93:	68 34 9b 59 00       	push   0x599b34
  492e98:	51                   	push   ecx
  492e99:	e8 b2 85 0c 00       	call   0x55b450
  492e9e:	83 c4 10             	add    esp,0x10
  492ea1:	e8 5a 03 01 00       	call   0x4a3200
  492ea6:	e8 75 0e 01 00       	call   0x4a3d20
  492eab:	8d 4c 24 10          	lea    ecx,[esp+0x10]
  492eaf:	51                   	push   ecx
  492eb0:	68 23 cd 89 00       	push   0x89cd23
  492eb5:	e8 f6 d2 06 00       	call   0x5001b0
  492eba:	8d 4c 24 10          	lea    ecx,[esp+0x10]
  492ebe:	83 c4 08             	add    esp,0x8
  492ec1:	68 01 00 00 80       	push   0x80000001
  492ec6:	68 23 cd 89 00       	push   0x89cd23
  492ecb:	51                   	push   ecx
  492ecc:	e8 af 33 09 00       	call   0x526280
  492ed1:	83 c4 0c             	add    esp,0xc
  492ed4:	85 c0                	test   eax,eax
  492ed6:	74 55                	je     0x492f2d
  492ed8:	8d 44 24 10          	lea    eax,[esp+0x10]
  492edc:	56                   	push   esi
  492edd:	68 a8 a2 5c 00       	push   0x5ca2a8
  492ee2:	50                   	push   eax
  492ee3:	e8 68 85 0c 00       	call   0x55b450
  492ee8:	83 c4 0c             	add    esp,0xc
  492eeb:	e8 10 03 01 00       	call   0x4a3200
  492ef0:	e8 2b 0e 01 00       	call   0x4a3d20
  492ef5:	8d 44 24 10          	lea    eax,[esp+0x10]
  492ef9:	50                   	push   eax
  492efa:	68 23 cd 89 00       	push   0x89cd23
  492eff:	e8 ac d2 06 00       	call   0x5001b0
  492f04:	8d 44 24 10          	lea    eax,[esp+0x10]
  492f08:	83 c4 08             	add    esp,0x8
  492f0b:	68 01 00 00 80       	push   0x80000001
  492f10:	68 23 cd 89 00       	push   0x89cd23
  492f15:	50                   	push   eax
  492f16:	e8 65 33 09 00       	call   0x526280
  492f1b:	83 c4 0c             	add    esp,0xc
  492f1e:	85 c0                	test   eax,eax
  492f20:	74 0b                	je     0x492f2d
  492f22:	33 c0                	xor    eax,eax
  492f24:	5f                   	pop    edi
  492f25:	5e                   	pop    esi
  492f26:	81 c4 28 02 00 00    	add    esp,0x228
  492f2c:	c3                   	ret
  492f2d:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  492f31:	50                   	push   eax
  492f32:	e8 d9 34 09 00       	call   0x526410
  492f37:	83 c4 04             	add    esp,0x4
  492f3a:	8b f8                	mov    edi,eax
  492f3c:	57                   	push   edi
  492f3d:	e8 ee 36 09 00       	call   0x526630
  492f42:	83 c4 04             	add    esp,0x4
  492f45:	8b f0                	mov    esi,eax
  492f47:	85 f6                	test   esi,esi
  492f49:	74 65                	je     0x492fb0
  492f4b:	e8 d0 0d 01 00       	call   0x4a3d20
  492f50:	8d 44 24 0c          	lea    eax,[esp+0xc]
  492f54:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  492f58:	50                   	push   eax
  492f59:	57                   	push   edi
  492f5a:	56                   	push   esi
  492f5b:	51                   	push   ecx
  492f5c:	e8 1f 36 09 00       	call   0x526580
  492f61:	83 c4 10             	add    esp,0x10
  492f64:	3b 7c 24 0c          	cmp    edi,DWORD PTR [esp+0xc]
  492f68:	75 53                	jne    0x492fbd
  492f6a:	8d 04 7e             	lea    eax,[esi+edi*2]
  492f6d:	b9 26 05 00 00       	mov    ecx,0x526
  492f72:	ba a8 2b 97 00       	mov    edx,0x972ba8
  492f77:	89 35 62 bc 89 00    	mov    DWORD PTR ds:0x89bc62,esi
  492f7d:	a3 66 bc 89 00       	mov    ds:0x89bc66,eax
  492f82:	89 32                	mov    DWORD PTR [edx],esi
  492f84:	83 c2 04             	add    edx,0x4
  492f87:	8b c6                	mov    eax,esi
  492f89:	83 c6 02             	add    esi,0x2
  492f8c:	66 83 38 00          	cmp    WORD PTR [eax],0x0
  492f90:	75 f5                	jne    0x492f87
  492f92:	49                   	dec    ecx
  492f93:	75 ed                	jne    0x492f82
  492f95:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  492f99:	50                   	push   eax
  492f9a:	e8 d1 33 09 00       	call   0x526370
  492f9f:	83 c4 04             	add    esp,0x4
  492fa2:	b8 01 00 00 00       	mov    eax,0x1
  492fa7:	5f                   	pop    edi
  492fa8:	5e                   	pop    esi
  492fa9:	81 c4 28 02 00 00    	add    esp,0x228
  492faf:	c3                   	ret
  492fb0:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  492fb4:	50                   	push   eax
  492fb5:	e8 b6 33 09 00       	call   0x526370
  492fba:	83 c4 04             	add    esp,0x4
  492fbd:	33 c0                	xor    eax,eax
  492fbf:	5f                   	pop    edi
  492fc0:	5e                   	pop    esi
  492fc1:	81 c4 28 02 00 00    	add    esp,0x228
  492fc7:	c3                   	ret
  492fc8:	cc                   	int3
  492fc9:	cc                   	int3
  492fca:	cc                   	int3
  492fcb:	cc                   	int3
  492fcc:	cc                   	int3
  492fcd:	cc                   	int3
  492fce:	cc                   	int3
  492fcf:	cc                   	int3
  492fd0:	83 3d 62 bc 89 00 00 	cmp    DWORD PTR ds:0x89bc62,0x0
  492fd7:	74 0e                	je     0x492fe7
  492fd9:	a1 62 bc 89 00       	mov    eax,ds:0x89bc62
  492fde:	50                   	push   eax
  492fdf:	e8 6c 36 09 00       	call   0x526650
  492fe4:	83 c4 04             	add    esp,0x4
  492fe7:	c3                   	ret
  492fe8:	cc                   	int3
  492fe9:	cc                   	int3
  492fea:	cc                   	int3
  492feb:	cc                   	int3
  492fec:	cc                   	int3
  492fed:	cc                   	int3
  492fee:	cc                   	int3
  492fef:	cc                   	int3
  492ff0:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  492ff6:	55                   	push   ebp
  492ff7:	8b ec                	mov    ebp,esp
  492ff9:	6a ff                	push   0xffffffff
  492ffb:	68 a6 31 49 00       	push   0x4931a6
  493000:	50                   	push   eax
  493001:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  493008:	83 ec 1c             	sub    esp,0x1c
  49300b:	c6 45 f3 00          	mov    BYTE PTR [ebp-0xd],0x0
  49300f:	56                   	push   esi
  493010:	8d 4d ec             	lea    ecx,[ebp-0x14]
  493013:	e8 68 74 09 00       	call   0x52a480
  493018:	6a 00                	push   0x0
  49301a:	8d 4d ec             	lea    ecx,[ebp-0x14]
  49301d:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  493024:	a1 54 d9 5c 00       	mov    eax,ds:0x5cd954
  493029:	50                   	push   eax
  49302a:	e8 51 6e 09 00       	call   0x529e80
  49302f:	85 c0                	test   eax,eax
  493031:	0f 85 ad 00 00 00    	jne    0x4930e4
  493037:	8d 45 e8             	lea    eax,[ebp-0x18]
  49303a:	8d 4d ec             	lea    ecx,[ebp-0x14]
  49303d:	50                   	push   eax
  49303e:	68 d0 a2 5c 00       	push   0x5ca2d0
  493043:	e8 48 73 09 00       	call   0x52a390
  493048:	85 c0                	test   eax,eax
  49304a:	0f 85 81 00 00 00    	jne    0x4930d1
  493050:	66 8b 4d e8          	mov    cx,WORD PTR [ebp-0x18]
  493054:	33 c0                	xor    eax,eax
  493056:	66 8b d1             	mov    dx,cx
  493059:	66 c1 ea 0a          	shr    dx,0xa
  49305d:	66 8b c1             	mov    ax,cx
  493060:	25 ff 03 00 00       	and    eax,0x3ff
  493065:	83 e8 04             	sub    eax,0x4
  493068:	83 f8 19             	cmp    eax,0x19
  49306b:	77 64                	ja     0x4930d1
  49306d:	33 c9                	xor    ecx,ecx
  49306f:	8a 88 e8 31 49 00    	mov    cl,BYTE PTR [eax+0x4931e8]
  493075:	ff 24 8d b8 31 49 00 	jmp    DWORD PTR [ecx*4+0x4931b8]
  49307c:	66 83 fa 02          	cmp    dx,0x2
  493080:	be 09 00 00 00       	mov    esi,0x9
  493085:	75 4d                	jne    0x4930d4
  493087:	be 0a 00 00 00       	mov    esi,0xa
  49308c:	eb 46                	jmp    0x4930d4
  49308e:	be 02 00 00 00       	mov    esi,0x2
  493093:	eb 3f                	jmp    0x4930d4
  493095:	33 f6                	xor    esi,esi
  493097:	eb 3b                	jmp    0x4930d4
  493099:	be 04 00 00 00       	mov    esi,0x4
  49309e:	eb 34                	jmp    0x4930d4
  4930a0:	be 01 00 00 00       	mov    esi,0x1
  4930a5:	eb 2d                	jmp    0x4930d4
  4930a7:	be 03 00 00 00       	mov    esi,0x3
  4930ac:	eb 26                	jmp    0x4930d4
  4930ae:	be 0b 00 00 00       	mov    esi,0xb
  4930b3:	eb 1f                	jmp    0x4930d4
  4930b5:	be 06 00 00 00       	mov    esi,0x6
  4930ba:	eb 18                	jmp    0x4930d4
  4930bc:	be 07 00 00 00       	mov    esi,0x7
  4930c1:	eb 11                	jmp    0x4930d4
  4930c3:	be 08 00 00 00       	mov    esi,0x8
  4930c8:	eb 0a                	jmp    0x4930d4
  4930ca:	be 05 00 00 00       	mov    esi,0x5
  4930cf:	eb 03                	jmp    0x4930d4
  4930d1:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
  4930d4:	8d 4d ec             	lea    ecx,[ebp-0x14]
  4930d7:	89 35 6a bc 89 00    	mov    DWORD PTR ds:0x89bc6a,esi
  4930dd:	e8 de 6e 09 00       	call   0x529fc0
  4930e2:	eb 03                	jmp    0x4930e7
  4930e4:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
  4930e7:	83 3d 62 bc 89 00 00 	cmp    DWORD PTR ds:0x89bc62,0x0
  4930ee:	74 0e                	je     0x4930fe
  4930f0:	a1 62 bc 89 00       	mov    eax,ds:0x89bc62
  4930f5:	50                   	push   eax
  4930f6:	e8 55 35 09 00       	call   0x526650
  4930fb:	83 c4 04             	add    esp,0x4
  4930fe:	56                   	push   esi
  4930ff:	8d 45 d8             	lea    eax,[ebp-0x28]
  493102:	68 c0 a2 5c 00       	push   0x5ca2c0
  493107:	50                   	push   eax
  493108:	e8 43 83 0c 00       	call   0x55b450
  49310d:	83 c4 0c             	add    esp,0xc
  493110:	8d 45 d8             	lea    eax,[ebp-0x28]
  493113:	50                   	push   eax
  493114:	e8 47 fd ff ff       	call   0x492e60
  493119:	83 c4 04             	add    esp,0x4
  49311c:	85 c0                	test   eax,eax
  49311e:	74 4d                	je     0x49316d
  493120:	39 35 94 e8 5a 00    	cmp    DWORD PTR ds:0x5ae894,esi
  493126:	74 30                	je     0x493158
  493128:	e8 83 0b fc ff       	call   0x453cb0
  49312d:	e8 fe 09 fc ff       	call   0x453b30
  493132:	e8 89 a9 06 00       	call   0x4fdac0
  493137:	e8 84 a6 06 00       	call   0x4fd7c0
  49313c:	e8 2f 7b f9 ff       	call   0x42ac70
  493141:	83 3d 94 e8 5a 00 ff 	cmp    DWORD PTR ds:0x5ae894,0xffffffff
  493148:	74 0e                	je     0x493158
  49314a:	e8 91 6b fc ff       	call   0x459ce0
  49314f:	56                   	push   esi
  493150:	e8 1b 6a fc ff       	call   0x459b70
  493155:	83 c4 04             	add    esp,0x4
  493158:	e8 a3 7f fb ff       	call   0x44b100
  49315d:	83 3d 94 e8 5a 00 ff 	cmp    DWORD PTR ds:0x5ae894,0xffffffff
  493164:	74 0b                	je     0x493171
  493166:	e8 d5 87 f9 ff       	call   0x42b940
  49316b:	eb 04                	jmp    0x493171
  49316d:	c6 45 f3 01          	mov    BYTE PTR [ebp-0xd],0x1
  493171:	c7 05 34 d9 5c 00 01 	mov    DWORD PTR ds:0x5cd934,0x1
  493178:	00 00 00 
  49317b:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  493182:	89 35 94 e8 5a 00    	mov    DWORD PTR ds:0x5ae894,esi
  493188:	e8 23 00 00 00       	call   0x4931b0
  49318d:	80 7d f3 01          	cmp    BYTE PTR [ebp-0xd],0x1
  493191:	1a c9                	sbb    cl,cl
  493193:	5e                   	pop    esi
  493194:	f6 d9                	neg    cl
  493196:	8a c1                	mov    al,cl
  493198:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  49319b:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4931a2:	8b e5                	mov    esp,ebp
  4931a4:	5d                   	pop    ebp
  4931a5:	c3                   	ret
  4931a6:	b8 80 54 59 00       	mov    eax,0x595480
  4931ab:	e9 40 86 0c 00       	jmp    0x55b7f0
  4931b0:	8d 4d ec             	lea    ecx,[ebp-0x14]
  4931b3:	e9 f8 6d 09 00       	jmp    0x529fb0
  4931b8:	7c 30                	jl     0x4931ea
  4931ba:	49                   	dec    ecx
  4931bb:	00 8e 30 49 00 95    	add    BYTE PTR [esi-0x6affb6d0],cl
  4931c1:	30 49 00             	xor    BYTE PTR [ecx+0x0],cl
  4931c4:	99                   	cdq
  4931c5:	30 49 00             	xor    BYTE PTR [ecx+0x0],cl
  4931c8:	a0 30 49 00 a7       	mov    al,ds:0xa7004930
  4931cd:	30 49 00             	xor    BYTE PTR [ecx+0x0],cl
  4931d0:	ae                   	scas   al,BYTE PTR es:[edi]
  4931d1:	30 49 00             	xor    BYTE PTR [ecx+0x0],cl
  4931d4:	b5 30                	mov    ch,0x30
  4931d6:	49                   	dec    ecx
  4931d7:	00 bc 30 49 00 c3 30 	add    BYTE PTR [eax+esi*1+0x30c30049],bh
  4931de:	49                   	dec    ecx
  4931df:	00 ca                	add    dl,cl
  4931e1:	30 49 00             	xor    BYTE PTR [ecx+0x0],cl
  4931e4:	d1 30                	shl    DWORD PTR [eax],1
  4931e6:	49                   	dec    ecx
  4931e7:	00 00                	add    BYTE PTR [eax],al
  4931e9:	0b 0b                	or     ecx,DWORD PTR [ebx]
  4931eb:	01 0b                	add    DWORD PTR [ebx],ecx
  4931ed:	02 03                	add    al,BYTE PTR [ebx]
  4931ef:	0b 04 0b             	or     eax,DWORD PTR [ebx+ecx*1]
  4931f2:	0b 0b                	or     ecx,DWORD PTR [ebx]
  4931f4:	05 06 0b 07 0b       	add    eax,0xb070b06
  4931f9:	08 0b                	or     BYTE PTR [ebx],cl
  4931fb:	0b 0b                	or     ecx,DWORD PTR [ebx]
  4931fd:	09 0b                	or     DWORD PTR [ebx],ecx
  4931ff:	0b 0b                	or     ecx,DWORD PTR [ebx]
  493201:	0a cc                	or     cl,ah
  493203:	cc                   	int3
  493204:	cc                   	int3
  493205:	cc                   	int3
  493206:	cc                   	int3
  493207:	cc                   	int3
  493208:	cc                   	int3
  493209:	cc                   	int3
  49320a:	cc                   	int3
  49320b:	cc                   	int3
  49320c:	cc                   	int3
  49320d:	cc                   	int3
  49320e:	cc                   	int3
  49320f:	cc                   	int3
  493210:	a1 6a bc 89 00       	mov    eax,ds:0x89bc6a
  493215:	83 f8 09             	cmp    eax,0x9
  493218:	7c 05                	jl     0x49321f
  49321a:	83 f8 0b             	cmp    eax,0xb
  49321d:	7e 03                	jle    0x493222
  49321f:	33 c0                	xor    eax,eax
  493221:	c3                   	ret
  493222:	b8 01 00 00 00       	mov    eax,0x1
  493227:	c3                   	ret
