  527960:	53                   	push   ebx
  527961:	56                   	push   esi
  527962:	8b 5c 24 10          	mov    ebx,DWORD PTR [esp+0x10]
  527966:	57                   	push   edi
  527967:	8b 7c 24 18          	mov    edi,DWORD PTR [esp+0x18]
  52796b:	55                   	push   ebp
  52796c:	66 83 3f 00          	cmp    WORD PTR [edi],0x0
  527970:	8b 6c 24 14          	mov    ebp,DWORD PTR [esp+0x14]
  527974:	8b f5                	mov    esi,ebp
  527976:	74 49                	je     0x5279c1
  527978:	66 8b 07             	mov    ax,WORD PTR [edi]
  52797b:	66 3d 0a 00          	cmp    ax,0xa
  52797f:	75 13                	jne    0x527994
  527981:	6a 20                	push   0x20
  527983:	8b f5                	mov    esi,ebp
  527985:	83 c7 02             	add    edi,0x2
  527988:	e8 b3 01 00 00       	call   0x527b40
  52798d:	83 c4 04             	add    esp,0x4
  527990:	03 d8                	add    ebx,eax
  527992:	eb 27                	jmp    0x5279bb
  527994:	83 c7 02             	add    edi,0x2
  527997:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  52799b:	8b 54 24 20          	mov    edx,DWORD PTR [esp+0x20]
  52799f:	51                   	push   ecx
  5279a0:	52                   	push   edx
  5279a1:	33 c9                	xor    ecx,ecx
  5279a3:	8a c8                	mov    cl,al
  5279a5:	a1 04 09 5e 00       	mov    eax,ds:0x5e0904
  5279aa:	51                   	push   ecx
  5279ab:	53                   	push   ebx
  5279ac:	56                   	push   esi
  5279ad:	50                   	push   eax
  5279ae:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  5279b3:	ff 50 0c             	call   DWORD PTR [eax+0xc]
  5279b6:	83 c4 18             	add    esp,0x18
  5279b9:	03 f0                	add    esi,eax
  5279bb:	66 83 3f 00          	cmp    WORD PTR [edi],0x0
  5279bf:	75 b7                	jne    0x527978
  5279c1:	5d                   	pop    ebp
  5279c2:	5f                   	pop    edi
  5279c3:	5e                   	pop    esi
  5279c4:	5b                   	pop    ebx
  5279c5:	c3                   	ret
  5279c6:	cc                   	int3
  5279c7:	cc                   	int3
  5279c8:	cc                   	int3
  5279c9:	cc                   	int3
  5279ca:	cc                   	int3
  5279cb:	cc                   	int3
  5279cc:	cc                   	int3
  5279cd:	cc                   	int3
  5279ce:	cc                   	int3
  5279cf:	cc                   	int3
  5279d0:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  5279d4:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  5279d8:	8d 14 c8             	lea    edx,[eax+ecx*8]
  5279db:	33 c0                	xor    eax,eax
  5279dd:	66 8b 82 04 ff ff ff 	mov    ax,WORD PTR [edx-0xfc]
  5279e4:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  5279e8:	89 01                	mov    DWORD PTR [ecx],eax
  5279ea:	33 c0                	xor    eax,eax
  5279ec:	66 8b 82 06 ff ff ff 	mov    ax,WORD PTR [edx-0xfa]
  5279f3:	89 41 04             	mov    DWORD PTR [ecx+0x4],eax
  5279f6:	c3                   	ret
  5279f7:	cc                   	int3
  5279f8:	cc                   	int3
  5279f9:	cc                   	int3
  5279fa:	cc                   	int3
  5279fb:	cc                   	int3
  5279fc:	cc                   	int3
  5279fd:	cc                   	int3
  5279fe:	cc                   	int3
  5279ff:	cc                   	int3
  527a00:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a04:	56                   	push   esi
  527a05:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  527a09:	8d b4 c8 00 ff ff ff 	lea    esi,[eax+ecx*8-0x100]
  527a10:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a14:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  527a18:	56                   	push   esi
  527a19:	51                   	push   ecx
  527a1a:	50                   	push   eax
  527a1b:	e8 c0 2d 00 00       	call   0x52a7e0
  527a20:	83 c4 0c             	add    esp,0xc
  527a23:	33 c0                	xor    eax,eax
  527a25:	66 8b 46 04          	mov    ax,WORD PTR [esi+0x4]
  527a29:	5e                   	pop    esi
  527a2a:	c3                   	ret
  527a2b:	cc                   	int3
  527a2c:	cc                   	int3
  527a2d:	cc                   	int3
  527a2e:	cc                   	int3
  527a2f:	cc                   	int3
  527a30:	8b 4c 24 0c          	mov    ecx,DWORD PTR [esp+0xc]
  527a34:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  527a38:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  527a3c:	8d 0c c8             	lea    ecx,[eax+ecx*8]
  527a3f:	33 c0                	xor    eax,eax
  527a41:	66 8b 81 04 ff ff ff 	mov    ax,WORD PTR [ecx-0xfc]
  527a48:	89 02                	mov    DWORD PTR [edx],eax
  527a4a:	33 c0                	xor    eax,eax
  527a4c:	66 8b 81 06 ff ff ff 	mov    ax,WORD PTR [ecx-0xfa]
  527a53:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  527a56:	c3                   	ret
  527a57:	cc                   	int3
  527a58:	cc                   	int3
  527a59:	cc                   	int3
  527a5a:	cc                   	int3
  527a5b:	cc                   	int3
  527a5c:	cc                   	int3
  527a5d:	cc                   	int3
  527a5e:	cc                   	int3
  527a5f:	cc                   	int3
  527a60:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a64:	56                   	push   esi
  527a65:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  527a69:	8b 54 24 10          	mov    edx,DWORD PTR [esp+0x10]
  527a6d:	8d b4 c8 00 ff ff ff 	lea    esi,[eax+ecx*8-0x100]
  527a74:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  527a78:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  527a7c:	51                   	push   ecx
  527a7d:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  527a81:	50                   	push   eax
  527a82:	56                   	push   esi
  527a83:	52                   	push   edx
  527a84:	51                   	push   ecx
  527a85:	e8 76 48 00 00       	call   0x52c300
  527a8a:	83 c4 14             	add    esp,0x14
  527a8d:	33 c0                	xor    eax,eax
  527a8f:	66 8b 46 04          	mov    ax,WORD PTR [esi+0x4]
  527a93:	5e                   	pop    esi
  527a94:	c3                   	ret
  527a95:	cc                   	int3
  527a96:	cc                   	int3
  527a97:	cc                   	int3
  527a98:	cc                   	int3
  527a99:	cc                   	int3
  527a9a:	cc                   	int3
  527a9b:	cc                   	int3
  527a9c:	cc                   	int3
  527a9d:	cc                   	int3
  527a9e:	cc                   	int3
  527a9f:	cc                   	int3
  527aa0:	83 3d 00 09 5e 00 00 	cmp    DWORD PTR ds:0x5e0900,0x0
  527aa7:	56                   	push   esi
  527aa8:	57                   	push   edi
  527aa9:	74 24                	je     0x527acf
  527aab:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  527ab0:	8b 40 04             	mov    eax,DWORD PTR [eax+0x4]
  527ab3:	85 c0                	test   eax,eax
  527ab5:	74 18                	je     0x527acf
  527ab7:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  527abb:	8b 7c 24 0c          	mov    edi,DWORD PTR [esp+0xc]
  527abf:	56                   	push   esi
  527ac0:	8b 0d 04 09 5e 00    	mov    ecx,DWORD PTR ds:0x5e0904
  527ac6:	57                   	push   edi
  527ac7:	51                   	push   ecx
  527ac8:	ff d0                	call   eax
  527aca:	83 c4 0c             	add    esp,0xc
  527acd:	eb 08                	jmp    0x527ad7
  527acf:	8b 7c 24 0c          	mov    edi,DWORD PTR [esp+0xc]
  527ad3:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  527ad7:	89 3d 00 09 5e 00    	mov    DWORD PTR ds:0x5e0900,edi
  527add:	8b 07                	mov    eax,DWORD PTR [edi]
  527adf:	85 c0                	test   eax,eax
  527ae1:	74 21                	je     0x527b04
  527ae3:	56                   	push   esi
  527ae4:	68 04 09 5e 00       	push   0x5e0904
  527ae9:	ff d0                	call   eax
  527aeb:	83 c4 08             	add    esp,0x8
  527aee:	85 c0                	test   eax,eax
  527af0:	74 18                	je     0x527b0a
  527af2:	b8 ff ff ff ff       	mov    eax,0xffffffff
  527af7:	5f                   	pop    edi
  527af8:	c7 05 00 09 5e 00 00 	mov    DWORD PTR ds:0x5e0900,0x0
  527aff:	00 00 00 
  527b02:	5e                   	pop    esi
  527b03:	c3                   	ret
  527b04:	89 35 04 09 5e 00    	mov    DWORD PTR ds:0x5e0904,esi
  527b0a:	33 c0                	xor    eax,eax
  527b0c:	5f                   	pop    edi
  527b0d:	5e                   	pop    esi
  527b0e:	c3                   	ret
  527b0f:	cc                   	int3
  527b10:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  527b14:	83 ec 08             	sub    esp,0x8
  527b17:	8b 15 04 09 5e 00    	mov    edx,DWORD PTR ds:0x5e0904
  527b1d:	50                   	push   eax
  527b1e:	8d 4c 24 04          	lea    ecx,[esp+0x4]
  527b22:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  527b27:	51                   	push   ecx
  527b28:	52                   	push   edx
  527b29:	ff 50 08             	call   DWORD PTR [eax+0x8]
  527b2c:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  527b30:	83 c4 0c             	add    esp,0xc
  527b33:	83 c4 08             	add    esp,0x8
  527b36:	c3                   	ret
  527b37:	cc                   	int3
  527b38:	cc                   	int3
  527b39:	cc                   	int3
  527b3a:	cc                   	int3
  527b3b:	cc                   	int3
  527b3c:	cc                   	int3
  527b3d:	cc                   	int3
  527b3e:	cc                   	int3
  527b3f:	cc                   	int3
  527b40:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  527b44:	83 ec 08             	sub    esp,0x8
  527b47:	8b 15 04 09 5e 00    	mov    edx,DWORD PTR ds:0x5e0904
  527b4d:	50                   	push   eax
  527b4e:	8d 4c 24 04          	lea    ecx,[esp+0x4]
  527b52:	a1 00 09 5e 00       	mov    eax,ds:0x5e0900
  527b57:	51                   	push   ecx
  527b58:	52                   	push   edx
  527b59:	ff 50 08             	call   DWORD PTR [eax+0x8]
  527b5c:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  527b60:	83 c4 0c             	add    esp,0xc
  527b63:	83 c4 08             	add    esp,0x8
  527b66:	c3                   	ret
