from pathlib import Path
import ast,struct,zlib,json,hashlib
root=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app');out=Path('/tmp/selector-text')
tree=ast.parse(Path('/tmp/populous-raid447-fallback-0229/scripts/import-original.py').read_text());ns={'struct':struct,'zlib':zlib};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['sprites','png']],type_ignores=[]),'existing source decoder','exec'),ns)
files={str(p.relative_to(root)).lower():p for p in root.rglob('*') if p.is_file()};pal=files['data/plspl0-c.dat'].read_bytes();meta={};lang=files['language/lang00.dat'].read_bytes().decode('utf-16le').split('\0')
for key,fn,texts in [('title','data/fenew/felo20we.spr',[f'{i:02} : '+lang[l] for i,l in [(1,610),(2,640),(3,647)]]),('tooltip','data/fenew/fettwe.spr',[lang[i] for i in [978,979,980]]),('cursor','data/plspanel.spr',[])]:
 raw=files[fn].read_bytes();frames=ns['sprites'](raw,pal);meta[key]={'source':str(files[fn]),'sha256':hashlib.sha256(raw).hexdigest(),'frames':len(frames),'header':raw[:8].hex(),'texts':[]}
 if key=='cursor':
  w,h,p=frames[12];ns['png'](out/'cursor-frame12-c.png',w,h,p);meta[key].update(width=w,height=h,rgba_sha256=hashlib.sha256(p).hexdigest());continue
 for j,text in enumerate(texts):
  ff=[frames[ord(c)-32] for c in text];w=sum(a[0] for a in ff);h=max(a[1] for a in ff);p=bytearray(w*h*4);x=0
  for fw,fh,fp in ff:
   for y in range(fh):p[(y*w+x)*4:(y*w+x+fw)*4]=fp[y*fw*4:(y+1)*fw*4]
   x+=fw
  ns['png'](out/f'{key}-{j+1}-c.png',w,h,p);meta[key]['texts'].append({'text':text,'width':w,'height':h,'rgba_sha256':hashlib.sha256(p).hexdigest()})
 meta[key]['glyph_metrics']=[{'code':i+32,'w':w,'h':h} for i,(w,h,p) in enumerate(frames)]
meta['palette_sha256']=hashlib.sha256(pal).hexdigest();meta['language_sha256']=hashlib.sha256(files['language/lang00.dat'].read_bytes()).hexdigest();(out/'text-data.json').write_text(json.dumps(meta,indent=2));print({k:{a:b for a,b in v.items() if a!='glyph_metrics'} if isinstance(v,dict) else v for k,v in meta.items()})
