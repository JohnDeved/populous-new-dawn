  4fca00:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  4fca06:	55                   	push   ebp
  4fca07:	8b ec                	mov    ebp,esp
  4fca09:	6a ff                	push   0xffffffff
  4fca0b:	68 7b cc 4f 00       	push   0x4fcc7b
  4fca10:	50                   	push   eax
  4fca11:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4fca18:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  4fca1b:	83 ec 14             	sub    esp,0x14
  4fca1e:	39 0d d0 8f a6 00    	cmp    DWORD PTR ds:0xa68fd0,ecx
  4fca24:	56                   	push   esi
  4fca25:	0f 84 37 02 00 00    	je     0x4fcc62
  4fca2b:	83 3d d8 54 5d 00 00 	cmp    DWORD PTR ds:0x5d54d8,0x0
  4fca32:	75 42                	jne    0x4fca76
  4fca34:	83 3d 34 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5734,0x0
  4fca3b:	75 33                	jne    0x4fca70
  4fca3d:	6a 00                	push   0x0
  4fca3f:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fca42:	68 78 8f a6 00       	push   0xa68f78
  4fca47:	e8 54 f3 02 00       	call   0x52bda0
  4fca4c:	6a 01                	push   0x1
  4fca4e:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fca51:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4fca58:	e8 73 f3 02 00       	call   0x52bdd0
  4fca5d:	c7 45 f0 01 00 00 00 	mov    DWORD PTR [ebp-0x10],0x1
  4fca64:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fca6b:	e8 c8 00 00 00       	call   0x4fcb38
  4fca70:	ff 05 34 57 5d 00    	inc    DWORD PTR ds:0x5d5734
  4fca76:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  4fca79:	89 0d d0 8f a6 00    	mov    DWORD PTR ds:0xa68fd0,ecx
  4fca7f:	83 7d 08 00          	cmp    DWORD PTR [ebp+0x8],0x0
  4fca83:	0f 84 31 01 00 00    	je     0x4fcbba
  4fca89:	33 c0                	xor    eax,eax
  4fca8b:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  4fca8e:	66 8b 41 04          	mov    ax,WORD PTR [ecx+0x4]
  4fca92:	6a 00                	push   0x0
  4fca94:	83 ec 08             	sub    esp,0x8
  4fca97:	a3 40 90 a6 00       	mov    ds:0xa69040,eax
  4fca9c:	33 c0                	xor    eax,eax
  4fca9e:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  4fcaa1:	66 8b 41 06          	mov    ax,WORD PTR [ecx+0x6]
  4fcaa5:	89 65 e0             	mov    DWORD PTR [ebp-0x20],esp
  4fcaa8:	6a 00                	push   0x0
  4fcaaa:	8b 4d e0             	mov    ecx,DWORD PTR [ebp-0x20]
  4fcaad:	a3 28 90 a6 00       	mov    ds:0xa69028,eax
  4fcab2:	e8 19 5b f5 ff       	call   0x4525d0
  4fcab7:	6a 00                	push   0x0
  4fcab9:	68 80 8f a6 00       	push   0xa68f80
  4fcabe:	e8 7d ce 02 00       	call   0x529940
  4fcac3:	83 c4 0c             	add    esp,0xc
  4fcac6:	89 65 f0             	mov    DWORD PTR [ebp-0x10],esp
  4fcac9:	6a 00                	push   0x0
  4fcacb:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4fcace:	e8 fd 5a f5 ff       	call   0x4525d0
  4fcad3:	68 80 8f a6 00       	push   0xa68f80
  4fcad8:	e8 b3 01 00 00       	call   0x4fcc90
  4fcadd:	83 c4 0c             	add    esp,0xc
  4fcae0:	6a 00                	push   0x0
  4fcae2:	68 80 8f a6 00       	push   0xa68f80
  4fcae7:	e8 e4 d2 02 00       	call   0x529dd0
  4fcaec:	83 c4 08             	add    esp,0x8
  4fcaef:	85 c0                	test   eax,eax
  4fcaf1:	74 55                	je     0x4fcb48
  4fcaf3:	83 3d d8 54 5d 00 00 	cmp    DWORD PTR ds:0x5d54d8,0x0
  4fcafa:	75 32                	jne    0x4fcb2e
  4fcafc:	ff 0d 34 57 5d 00    	dec    DWORD PTR ds:0x5d5734
  4fcb02:	75 2a                	jne    0x4fcb2e
  4fcb04:	6a 01                	push   0x1
  4fcb06:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcb09:	68 78 8f a6 00       	push   0xa68f78
  4fcb0e:	e8 8d f2 02 00       	call   0x52bda0
  4fcb13:	c7 45 fc 01 00 00 00 	mov    DWORD PTR [ebp-0x4],0x1
  4fcb1a:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcb1d:	e8 fe f2 02 00       	call   0x52be20
  4fcb22:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fcb29:	e8 12 00 00 00       	call   0x4fcb40
  4fcb2e:	b8 ff ff ff ff       	mov    eax,0xffffffff
  4fcb33:	e9 2c 01 00 00       	jmp    0x4fcc64
  4fcb38:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcb3b:	e9 80 f2 02 00       	jmp    0x52bdc0
  4fcb40:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcb43:	e9 78 f2 02 00       	jmp    0x52bdc0
  4fcb48:	8b 35 08 5b d0 00    	mov    esi,DWORD PTR ds:0xd05b08
  4fcb4e:	68 80 8f a6 00       	push   0xa68f80
  4fcb53:	e8 68 b6 02 00       	call   0x5281c0
  4fcb58:	83 c4 04             	add    esp,0x4
  4fcb5b:	8b 4d 08             	mov    ecx,DWORD PTR [ebp+0x8]
  4fcb5e:	51                   	push   ecx
  4fcb5f:	6a 00                	push   0x0
  4fcb61:	6a 00                	push   0x0
  4fcb63:	e8 78 dc 02 00       	call   0x52a7e0
  4fcb68:	83 c4 0c             	add    esp,0xc
  4fcb6b:	68 80 8f a6 00       	push   0xa68f80
  4fcb70:	e8 eb d2 02 00       	call   0x529e60
  4fcb75:	83 c4 04             	add    esp,0x4
  4fcb78:	83 3d 38 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5738,0x0
  4fcb7f:	75 09                	jne    0x4fcb8a
  4fcb81:	56                   	push   esi
  4fcb82:	e8 69 b5 02 00       	call   0x5280f0
  4fcb87:	83 c4 04             	add    esp,0x4
  4fcb8a:	c7 05 38 57 5d 00 00 	mov    DWORD PTR ds:0x5d5738,0x0
  4fcb91:	00 00 00 
  4fcb94:	83 3d 24 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5724,0x0
  4fcb9b:	0f 85 86 00 00 00    	jne    0x4fcc27
  4fcba1:	83 3d d8 54 5d 00 00 	cmp    DWORD PTR ds:0x5d54d8,0x0
  4fcba8:	0f 85 b4 00 00 00    	jne    0x4fcc62
  4fcbae:	c7 05 24 57 5d 00 01 	mov    DWORD PTR ds:0x5d5724,0x1
  4fcbb5:	00 00 00 
  4fcbb8:	eb 6d                	jmp    0x4fcc27
  4fcbba:	33 f6                	xor    esi,esi
  4fcbbc:	e8 9f 5a fb ff       	call   0x4b2660
  4fcbc1:	39 35 28 57 5d 00    	cmp    DWORD PTR ds:0x5d5728,esi
  4fcbc7:	74 4b                	je     0x4fcc14
  4fcbc9:	89 75 e4             	mov    DWORD PTR [ebp-0x1c],esi
  4fcbcc:	8b 0d 38 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69038
  4fcbd2:	56                   	push   esi
  4fcbd3:	2b 0d 30 90 a6 00    	sub    ecx,DWORD PTR ds:0xa69030
  4fcbd9:	8d 55 e4             	lea    edx,[ebp-0x1c]
  4fcbdc:	52                   	push   edx
  4fcbdd:	89 4d ec             	mov    DWORD PTR [ebp-0x14],ecx
  4fcbe0:	68 d8 8f a6 00       	push   0xa68fd8
  4fcbe5:	89 75 e8             	mov    DWORD PTR [ebp-0x18],esi
  4fcbe8:	8b 0d 3c 90 a6 00    	mov    ecx,DWORD PTR ds:0xa6903c
  4fcbee:	2b 0d 34 90 a6 00    	sub    ecx,DWORD PTR ds:0xa69034
  4fcbf4:	89 4d f0             	mov    DWORD PTR [ebp-0x10],ecx
  4fcbf7:	8b 0d 34 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69034
  4fcbfd:	51                   	push   ecx
  4fcbfe:	8b 15 30 90 a6 00    	mov    edx,DWORD PTR ds:0xa69030
  4fcc04:	52                   	push   edx
  4fcc05:	50                   	push   eax
  4fcc06:	e8 65 d0 02 00       	call   0x529c70
  4fcc0b:	83 c4 18             	add    esp,0x18
  4fcc0e:	89 35 28 57 5d 00    	mov    DWORD PTR ds:0x5d5728,esi
  4fcc14:	83 3d 24 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5724,0x0
  4fcc1b:	74 0a                	je     0x4fcc27
  4fcc1d:	c7 05 24 57 5d 00 00 	mov    DWORD PTR ds:0x5d5724,0x0
  4fcc24:	00 00 00 
  4fcc27:	83 3d d8 54 5d 00 00 	cmp    DWORD PTR ds:0x5d54d8,0x0
  4fcc2e:	75 32                	jne    0x4fcc62
  4fcc30:	ff 0d 34 57 5d 00    	dec    DWORD PTR ds:0x5d5734
  4fcc36:	75 2a                	jne    0x4fcc62
  4fcc38:	6a 01                	push   0x1
  4fcc3a:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcc3d:	68 78 8f a6 00       	push   0xa68f78
  4fcc42:	e8 59 f1 02 00       	call   0x52bda0
  4fcc47:	c7 45 fc 02 00 00 00 	mov    DWORD PTR [ebp-0x4],0x2
  4fcc4e:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcc51:	e8 ca f1 02 00       	call   0x52be20
  4fcc56:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fcc5d:	e8 11 00 00 00       	call   0x4fcc73
  4fcc62:	33 c0                	xor    eax,eax
  4fcc64:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4fcc67:	5e                   	pop    esi
  4fcc68:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  4fcc6f:	8b e5                	mov    esp,ebp
  4fcc71:	5d                   	pop    ebp
  4fcc72:	c3                   	ret
  4fcc73:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fcc76:	e9 45 f1 02 00       	jmp    0x52bdc0
  4fcc7b:	b8 d8 58 59 00       	mov    eax,0x5958d8
