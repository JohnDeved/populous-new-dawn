  415f70:	8a 44 24 04          	mov    al,BYTE PTR [esp+0x4]
  415f74:	33 d2                	xor    edx,edx
  415f76:	8a d0                	mov    dl,al
  415f78:	88 41 04             	mov    BYTE PTR [ecx+0x4],al
  415f7b:	8d 04 95 00 00 00 00 	lea    eax,[edx*4+0x0]
  415f82:	8a 14 95 28 55 d0 00 	mov    dl,BYTE PTR [edx*4+0xd05528]
  415f89:	88 51 02             	mov    BYTE PTR [ecx+0x2],dl
  415f8c:	8a 90 29 55 d0 00    	mov    dl,BYTE PTR [eax+0xd05529]
  415f92:	88 51 01             	mov    BYTE PTR [ecx+0x1],dl
  415f95:	8a 80 2a 55 d0 00    	mov    al,BYTE PTR [eax+0xd0552a]
  415f9b:	c6 41 03 ff          	mov    BYTE PTR [ecx+0x3],0xff
  415f9f:	88 01                	mov    BYTE PTR [ecx],al
  415fa1:	8b c1                	mov    eax,ecx
  415fa3:	c2 04 00             	ret    0x4
