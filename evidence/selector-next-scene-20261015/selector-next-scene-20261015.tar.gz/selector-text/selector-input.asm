  410e20:	33 c0                	xor    eax,eax
  410e22:	a0 02 f0 88 00       	mov    al,ds:0x88f002
  410e27:	83 f8 01             	cmp    eax,0x1
  410e2a:	74 44                	je     0x410e70
  410e2c:	83 f8 04             	cmp    eax,0x4
  410e2f:	0f 84 08 01 00 00    	je     0x410f3d
  410e35:	83 f8 05             	cmp    eax,0x5
  410e38:	0f 84 f5 00 00 00    	je     0x410f33
  410e3e:	e8 9d 02 00 00       	call   0x4110e0
  410e43:	80 3d 02 f0 88 00 05 	cmp    BYTE PTR ds:0x88f002,0x5
  410e4a:	0f 84 3a 01 00 00    	je     0x410f8a
  410e50:	80 3d 02 f0 88 00 04 	cmp    BYTE PTR ds:0x88f002,0x4
  410e57:	0f 84 2d 01 00 00    	je     0x410f8a
  410e5d:	80 3d e0 de 59 00 00 	cmp    BYTE PTR ds:0x59dee0,0x0
  410e64:	75 05                	jne    0x410e6b
  410e66:	e8 15 ed 00 00       	call   0x41fb80
  410e6b:	e9 00 77 01 00       	jmp    0x428570
  410e70:	81 25 61 c6 89 00 ff 	and    DWORD PTR ds:0x89c661,0xff7fffff
  410e77:	ff 7f ff 
  410e7a:	6a 00                	push   0x0
  410e7c:	e8 3f 23 11 00       	call   0x5231c0
  410e81:	83 c4 04             	add    esp,0x4
  410e84:	66 81 3d cf c6 89 00 	cmp    WORD PTR ds:0x89c6cf,0x280
  410e8b:	80 02 
  410e8d:	75 1a                	jne    0x410ea9
  410e8f:	66 81 3d d1 c6 89 00 	cmp    WORD PTR ds:0x89c6d1,0x1e0
  410e96:	e0 01 
  410e98:	75 0f                	jne    0x410ea9
  410e9a:	66 83 3d d3 c6 89 00 	cmp    WORD PTR ds:0x89c6d3,0x10
  410ea1:	10 
  410ea2:	b8 00 00 00 00       	mov    eax,0x0
  410ea7:	74 05                	je     0x410eae
  410ea9:	b8 01 00 00 00       	mov    eax,0x1
  410eae:	83 3d 1c d1 59 00 00 	cmp    DWORD PTR ds:0x59d11c,0x0
  410eb5:	75 1c                	jne    0x410ed3
  410eb7:	68 b4 9a 59 00       	push   0x599ab4
  410ebc:	e8 0f 66 04 00       	call   0x4574d0
  410ec1:	83 c4 04             	add    esp,0x4
  410ec4:	e8 27 16 0a 00       	call   0x4b24f0
  410ec9:	b8 01 00 00 00       	mov    eax,0x1
  410ece:	a3 1c d1 59 00       	mov    ds:0x59d11c,eax
  410ed3:	85 c0                	test   eax,eax
  410ed5:	74 21                	je     0x410ef8
  410ed7:	68 80 9a 59 00       	push   0x599a80
  410edc:	e8 ef 65 04 00       	call   0x4574d0
  410ee1:	83 c4 04             	add    esp,0x4
  410ee4:	6a 10                	push   0x10
  410ee6:	68 e0 01 00 00       	push   0x1e0
  410eeb:	68 80 02 00 00       	push   0x280
  410ef0:	e8 8b f6 0e 00       	call   0x500580
  410ef5:	83 c4 0c             	add    esp,0xc
  410ef8:	6a 01                	push   0x1
  410efa:	e8 c1 22 11 00       	call   0x5231c0
  410eff:	83 c4 04             	add    esp,0x4
  410f02:	e8 c9 00 00 00       	call   0x410fd0
  410f07:	6a 01                	push   0x1
  410f09:	e8 42 a5 07 00       	call   0x48b450
  410f0e:	83 c4 04             	add    esp,0x4
  410f11:	6a 03                	push   0x3
  410f13:	e8 c8 1b 03 00       	call   0x442ae0
  410f18:	83 c4 04             	add    esp,0x4
  410f1b:	e8 90 79 01 00       	call   0x4288b0
  410f20:	85 c0                	test   eax,eax
  410f22:	0f 85 16 ff ff ff    	jne    0x410e3e
  410f28:	81 0d 61 c6 89 00 00 	or     DWORD PTR ds:0x89c661,0x800000
  410f2f:	00 80 00 
  410f32:	c3                   	ret
  410f33:	6a 04                	push   0x4
  410f35:	e8 a6 1b 03 00       	call   0x442ae0
  410f3a:	83 c4 04             	add    esp,0x4
  410f3d:	e8 6e 1b 03 00       	call   0x442ab0
  410f42:	e8 79 7b 01 00       	call   0x428ac0
  410f47:	80 3d 00 f0 88 00 07 	cmp    BYTE PTR ds:0x88f000,0x7
  410f4e:	75 4a                	jne    0x410f9a
  410f50:	83 3d 1c d1 59 00 00 	cmp    DWORD PTR ds:0x59d11c,0x0
  410f57:	74 75                	je     0x410fce
  410f59:	e8 e2 15 0a 00       	call   0x4b2540
  410f5e:	c7 05 1c d1 59 00 00 	mov    DWORD PTR ds:0x59d11c,0x0
  410f65:	00 00 00 
  410f68:	68 44 9a 59 00       	push   0x599a44
  410f6d:	e8 5e 65 04 00       	call   0x4574d0
  410f72:	83 c4 04             	add    esp,0x4
  410f75:	6a 08                	push   0x8
  410f77:	68 e0 01 00 00       	push   0x1e0
  410f7c:	68 80 02 00 00       	push   0x280
  410f81:	e8 fa f5 0e 00       	call   0x500580
  410f86:	83 c4 0c             	add    esp,0xc
  410f89:	c3                   	ret
  410f8a:	e8 e1 75 01 00       	call   0x428570
  410f8f:	6a 01                	push   0x1
  410f91:	e8 2a 22 11 00       	call   0x5231c0
  410f96:	83 c4 04             	add    esp,0x4
  410f99:	c3                   	ret
  410f9a:	a0 f0 9c 74 00       	mov    al,ds:0x749cf0
  410f9f:	38 05 90 45 98 00    	cmp    BYTE PTR ds:0x984590,al
  410fa5:	74 27                	je     0x410fce
  410fa7:	33 c9                	xor    ecx,ecx
  410fa9:	8a c8                	mov    cl,al
  410fab:	8d 0c 49             	lea    ecx,[ecx+ecx*2]
  410fae:	c1 e1 02             	shl    ecx,0x2
  410fb1:	8b 81 24 cf 89 00    	mov    eax,DWORD PTR [ecx+0x89cf24]
  410fb7:	8b 91 20 cf 89 00    	mov    edx,DWORD PTR [ecx+0x89cf20]
  410fbd:	50                   	push   eax
  410fbe:	8b 89 1c cf 89 00    	mov    ecx,DWORD PTR [ecx+0x89cf1c]
  410fc4:	52                   	push   edx
  410fc5:	51                   	push   ecx
  410fc6:	e8 b5 f5 0e 00       	call   0x500580
  410fcb:	83 c4 0c             	add    esp,0xc
  410fce:	c3                   	ret
  410fcf:	cc                   	int3
  410fd0:	83 ec 04             	sub    esp,0x4
  410fd3:	33 c0                	xor    eax,eax
  410fd5:	39 05 34 9a 59 00    	cmp    DWORD PTR ds:0x599a34,eax
  410fdb:	56                   	push   esi
  410fdc:	74 15                	je     0x410ff3
  410fde:	a3 34 9a 59 00       	mov    ds:0x599a34,eax
  410fe3:	a3 f4 c9 5f 00       	mov    ds:0x5fc9f4,eax
  410fe8:	ff 15 84 c7 d0 00    	call   DWORD PTR ds:0xd0c784
  410fee:	a3 f8 c9 5f 00       	mov    ds:0x5fc9f8,eax
  410ff3:	83 25 f4 c9 5f 00 fd 	and    DWORD PTR ds:0x5fc9f4,0xfffffffd
  410ffa:	83 25 f4 c9 5f 00 fb 	and    DWORD PTR ds:0x5fc9f4,0xfffffffb
  411001:	83 25 f4 c9 5f 00 f7 	and    DWORD PTR ds:0x5fc9f4,0xfffffff7
  411008:	c7 05 cc c9 5f 00 c0 	mov    DWORD PTR ds:0x5fc9cc,0x4112c0
  41100f:	12 41 00 
  411012:	c7 05 d0 c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9d0,0x411500
  411019:	15 41 00 
  41101c:	c7 05 b0 c9 5f 00 80 	mov    DWORD PTR ds:0x5fc9b0,0x280
  411023:	02 00 00 
  411026:	c7 05 b4 c9 5f 00 e0 	mov    DWORD PTR ds:0x5fc9b4,0x1e0
  41102d:	01 00 00 
  411030:	c7 05 b8 c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9b8,0x43a00000
  411037:	00 a0 43 
  41103a:	c7 05 bc c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9bc,0x43700000
  411041:	00 70 43 
  411044:	c7 05 c0 c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9c0,0x441fc000
  41104b:	c0 1f 44 
  41104e:	c7 05 c4 c9 5f 00 00 	mov    DWORD PTR ds:0x5fc9c4,0x43ef8000
  411055:	80 ef 43 
  411058:	33 f6                	xor    esi,esi
  41105a:	89 35 f0 c9 5f 00    	mov    DWORD PTR ds:0x5fc9f0,esi
  411060:	e8 bb ea 00 00       	call   0x41fb20
  411065:	39 35 38 9a 59 00    	cmp    DWORD PTR ds:0x599a38,esi
  41106b:	74 3b                	je     0x4110a8
  41106d:	33 c0                	xor    eax,eax
  41106f:	89 35 38 9a 59 00    	mov    DWORD PTR ds:0x599a38,esi
  411075:	eb 06                	jmp    0x41107d
  411077:	d9 98 a4 15 5f 00    	fstp   DWORD PTR [eax+0x5f15a4]
  41107d:	83 c0 04             	add    eax,0x4
  411080:	89 74 24 04          	mov    DWORD PTR [esp+0x4],esi
  411084:	db 44 24 04          	fild   DWORD PTR [esp+0x4]
  411088:	46                   	inc    esi
  411089:	3d 00 5a 00 00       	cmp    eax,0x5a00
  41108e:	dc 0d 20 f0 58 00    	fmul   QWORD PTR ds:0x58f020
  411094:	d9 c0                	fld    st(0)
  411096:	d9 fe                	fsin
  411098:	d9 98 a4 6f 5f 00    	fstp   DWORD PTR [eax+0x5f6fa4]
  41109e:	d9 ff                	fcos
  4110a0:	7c d5                	jl     0x411077
  4110a2:	d9 98 a4 15 5f 00    	fstp   DWORD PTR [eax+0x5f15a4]
  4110a8:	e8 d3 40 04 00       	call   0x455180
  4110ad:	e8 de 06 00 00       	call   0x411790
  4110b2:	e8 29 d3 06 00       	call   0x47e3e0
  4110b7:	8b 0d ac 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13ac
  4110bd:	a1 bc 13 5f 00       	mov    eax,ds:0x5f13bc
  4110c2:	8d 14 49             	lea    edx,[ecx+ecx*2]
  4110c5:	8d 0c 91             	lea    ecx,[ecx+edx*4]
  4110c8:	8b 54 88 28          	mov    edx,DWORD PTR [eax+ecx*4+0x28]
  4110cc:	52                   	push   edx
  4110cd:	e8 ae 16 00 00       	call   0x412780
  4110d2:	83 c4 04             	add    esp,0x4
  4110d5:	b8 01 00 00 00       	mov    eax,0x1
  4110da:	5e                   	pop    esi
  4110db:	83 c4 04             	add    esp,0x4
  4110de:	c3                   	ret
  4110df:	cc                   	int3
  4110e0:	83 ec 08             	sub    esp,0x8
  4110e3:	f6 05 f4 c9 5f 00 08 	test   BYTE PTR ds:0x5fc9f4,0x8
  4110ea:	74 2f                	je     0x41111b
  4110ec:	8b 0d b0 13 5f 00    	mov    ecx,DWORD PTR ds:0x5f13b0
  4110f2:	a1 bc 13 5f 00       	mov    eax,ds:0x5f13bc
  4110f7:	8d 14 49             	lea    edx,[ecx+ecx*2]
  4110fa:	8d 0c 91             	lea    ecx,[ecx+edx*4]
  4110fd:	8b 54 88 28          	mov    edx,DWORD PTR [eax+ecx*4+0x28]
  411101:	52                   	push   edx
  411102:	e8 e9 47 07 00       	call   0x4858f0
  411107:	83 c4 04             	add    esp,0x4
  41110a:	6a 02                	push   0x2
  41110c:	e8 4f 19 03 00       	call   0x442a60
  411111:	83 25 f4 c9 5f 00 f7 	and    DWORD PTR ds:0x5fc9f4,0xfffffff7
  411118:	83 c4 04             	add    esp,0x4
  41111b:	f6 05 f4 c9 5f 00 02 	test   BYTE PTR ds:0x5fc9f4,0x2
  411122:	74 5e                	je     0x411182
  411124:	a1 f8 ef 87 00       	mov    eax,ds:0x87eff8
  411129:	50                   	push   eax
  41112a:	e8 f1 22 09 00       	call   0x4a3420
  41112f:	83 c4 04             	add    esp,0x4
  411132:	e8 f9 23 09 00       	call   0x4a3530
  411137:	68 f4 c6 89 00       	push   0x89c6f4
  41113c:	a1 f8 ef 87 00       	mov    eax,ds:0x87eff8
  411141:	50                   	push   eax
  411142:	e8 79 9c 01 00       	call   0x42adc0
  411147:	83 c4 08             	add    esp,0x8
  41114a:	33 c9                	xor    ecx,ecx
  41114c:	a1 f8 ef 87 00       	mov    eax,ds:0x87eff8
  411151:	33 d2                	xor    edx,edx
  411153:	83 25 f4 c9 5f 00 fd 	and    DWORD PTR ds:0x5fc9f4,0xfffffffd
  41115a:	89 0d f0 c9 5f 00    	mov    DWORD PTR ds:0x5fc9f0,ecx
  411160:	38 10                	cmp    BYTE PTR [eax],dl
  411162:	75 0a                	jne    0x41116e
  411164:	38 50 01             	cmp    BYTE PTR [eax+0x1],dl
  411167:	75 05                	jne    0x41116e
  411169:	38 50 02             	cmp    BYTE PTR [eax+0x2],dl
  41116c:	74 0e                	je     0x41117c
  41116e:	41                   	inc    ecx
  41116f:	83 c0 04             	add    eax,0x4
  411172:	81 f9 00 01 00 00    	cmp    ecx,0x100
  411178:	7c e6                	jl     0x411160
  41117a:	eb 06                	jmp    0x411182
  41117c:	89 0d f0 c9 5f 00    	mov    DWORD PTR ds:0x5fc9f0,ecx
  411182:	f6 05 f5 c9 5f 00 01 	test   BYTE PTR ds:0x5fc9f5,0x1
  411189:	74 07                	je     0x411192
  41118b:	e8 10 bd 01 00       	call   0x42cea0
  411190:	eb 27                	jmp    0x4111b9
  411192:	6a 00                	push   0x0
  411194:	6a 00                	push   0x0
  411196:	68 cc c9 5f 00       	push   0x5fc9cc
  41119b:	e8 e0 58 11 00       	call   0x526a80
  4111a0:	83 c4 0c             	add    esp,0xc
  4111a3:	e8 28 5c 11 00       	call   0x526dd0
  4111a8:	8b 08                	mov    ecx,DWORD PTR [eax]
  4111aa:	8b 50 04             	mov    edx,DWORD PTR [eax+0x4]
  4111ad:	89 0d e0 c9 5f 00    	mov    DWORD PTR ds:0x5fc9e0,ecx
  4111b3:	89 15 e4 c9 5f 00    	mov    DWORD PTR ds:0x5fc9e4,edx
  4111b9:	ff 15 84 c7 d0 00    	call   DWORD PTR ds:0xd0c784
  4111bf:	8b c8                	mov    ecx,eax
  4111c1:	2b 0d f8 c9 5f 00    	sub    ecx,DWORD PTR ds:0x5fc9f8
  4111c7:	81 f9 e8 03 00 00    	cmp    ecx,0x3e8
  4111cd:	76 05                	jbe    0x4111d4
  4111cf:	b9 e8 03 00 00       	mov    ecx,0x3e8
  4111d4:	89 4c 24 00          	mov    DWORD PTR [esp+0x0],ecx
  4111d8:	a3 f8 c9 5f 00       	mov    ds:0x5fc9f8,eax
  4111dd:	c7 44 24 04 00 00 00 	mov    DWORD PTR [esp+0x4],0x0
  4111e4:	00 
  4111e5:	df 6c 24 00          	fild   QWORD PTR [esp+0x0]
  4111e9:	f6 05 f5 c9 5f 00 01 	test   BYTE PTR ds:0x5fc9f5,0x1
  4111f0:	dc 0d 28 f0 58 00    	fmul   QWORD PTR ds:0x58f028
  4111f6:	d9 1d fc c9 5f 00    	fstp   DWORD PTR ds:0x5fc9fc
  4111fc:	75 05                	jne    0x411203
  4111fe:	e8 2d d3 06 00       	call   0x47e530
  411203:	e8 28 10 00 00       	call   0x412230
  411208:	e8 c3 72 01 00       	call   0x4284d0
  41120d:	e8 fe 41 04 00       	call   0x455410
  411212:	e8 59 85 07 00       	call   0x489770
  411217:	e8 e4 96 07 00       	call   0x48a900
  41121c:	83 c4 08             	add    esp,0x8
  41121f:	c3                   	ret
