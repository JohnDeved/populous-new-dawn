  429160:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429165:	e9 06 78 03 00       	jmp    0x460970
  42916a:	cc                   	int3
  42916b:	cc                   	int3
  42916c:	cc                   	int3
  42916d:	cc                   	int3
  42916e:	cc                   	int3
  42916f:	cc                   	int3
  429170:	83 ec 08             	sub    esp,0x8
  429173:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  429178:	53                   	push   ebx
  429179:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  42917f:	56                   	push   esi
  429180:	57                   	push   edi
  429181:	6a 01                	push   0x1
  429183:	8b 18                	mov    ebx,DWORD PTR [eax]
  429185:	6a 1b                	push   0x1b
  429187:	50                   	push   eax
  429188:	ff 53 5c             	call   DWORD PTR [ebx+0x5c]
  42918b:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429191:	6a 01                	push   0x1
  429193:	6a 09                	push   0x9
  429195:	33 f6                	xor    esi,esi
  429197:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  42919d:	50                   	push   eax
  42919e:	8b 18                	mov    ebx,DWORD PTR [eax]
  4291a0:	ff 53 5c             	call   DWORD PTR [ebx+0x5c]
  4291a3:	33 db                	xor    ebx,ebx
  4291a5:	39 1d 94 c2 59 00    	cmp    DWORD PTR ds:0x59c294,ebx
  4291ab:	0f 8e 93 01 00 00    	jle    0x429344
  4291b1:	bf c8 b5 65 00       	mov    edi,0x65b5c8
  4291b6:	8b 47 0c             	mov    eax,DWORD PTR [edi+0xc]
  4291b9:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  4291be:	50                   	push   eax
  4291bf:	e8 3c 83 03 00       	call   0x461500
  4291c4:	85 c0                	test   eax,eax
  4291c6:	0f 84 68 01 00 00    	je     0x429334
  4291cc:	db 07                	fild   DWORD PTR [edi]
  4291ce:	d9 15 f8 c2 59 00    	fst    DWORD PTR ds:0x59c2f8
  4291d4:	d9 1d 98 c2 59 00    	fstp   DWORD PTR ds:0x59c298
  4291da:	8b 50 1c             	mov    edx,DWORD PTR [eax+0x1c]
  4291dd:	03 17                	add    edx,DWORD PTR [edi]
  4291df:	89 54 24 0c          	mov    DWORD PTR [esp+0xc],edx
  4291e3:	89 5c 24 10          	mov    DWORD PTR [esp+0x10],ebx
  4291e7:	df 6c 24 0c          	fild   QWORD PTR [esp+0xc]
  4291eb:	d9 15 d8 c2 59 00    	fst    DWORD PTR ds:0x59c2d8
  4291f1:	d9 1d b8 c2 59 00    	fstp   DWORD PTR ds:0x59c2b8
  4291f7:	db 47 04             	fild   DWORD PTR [edi+0x4]
  4291fa:	d9 15 bc c2 59 00    	fst    DWORD PTR ds:0x59c2bc
  429200:	d9 1d 9c c2 59 00    	fstp   DWORD PTR ds:0x59c29c
  429206:	8b 50 20             	mov    edx,DWORD PTR [eax+0x20]
  429209:	03 57 04             	add    edx,DWORD PTR [edi+0x4]
  42920c:	89 54 24 0c          	mov    DWORD PTR [esp+0xc],edx
  429210:	8b 57 10             	mov    edx,DWORD PTR [edi+0x10]
  429213:	89 5c 24 10          	mov    DWORD PTR [esp+0x10],ebx
  429217:	89 15 08 c3 59 00    	mov    DWORD PTR ds:0x59c308,edx
  42921d:	df 6c 24 0c          	fild   QWORD PTR [esp+0xc]
  429221:	89 15 e8 c2 59 00    	mov    DWORD PTR ds:0x59c2e8,edx
  429227:	89 15 c8 c2 59 00    	mov    DWORD PTR ds:0x59c2c8,edx
  42922d:	89 15 a8 c2 59 00    	mov    DWORD PTR ds:0x59c2a8,edx
  429233:	8b 15 f4 c2 af 00    	mov    edx,DWORD PTR ds:0xafc2f4
  429239:	d9 15 fc c2 59 00    	fst    DWORD PTR ds:0x59c2fc
  42923f:	d9 1d dc c2 59 00    	fstp   DWORD PTR ds:0x59c2dc
  429245:	d9 47 08             	fld    DWORD PTR [edi+0x8]
  429248:	d9 15 00 c3 59 00    	fst    DWORD PTR ds:0x59c300
  42924e:	d9 1d e0 c2 59 00    	fstp   DWORD PTR ds:0x59c2e0
  429254:	8b 0d 00 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c300
  42925a:	89 0d c0 c2 59 00    	mov    DWORD PTR ds:0x59c2c0,ecx
  429260:	89 0d a0 c2 59 00    	mov    DWORD PTR ds:0x59c2a0,ecx
  429266:	8b 08                	mov    ecx,DWORD PTR [eax]
  429268:	83 c1 10             	add    ecx,0x10
  42926b:	d9 01                	fld    DWORD PTR [ecx]
  42926d:	d8 0d 28 d3 5d 00    	fmul   DWORD PTR ds:0x5dd328
  429273:	d9 01                	fld    DWORD PTR [ecx]
  429275:	d8 0d 30 d3 5d 00    	fmul   DWORD PTR ds:0x5dd330
  42927b:	d9 40 08             	fld    DWORD PTR [eax+0x8]
  42927e:	d8 c2                	fadd   st,st(2)
  429280:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  429283:	d8 40 04             	fadd   DWORD PTR [eax+0x4]
  429286:	d8 c2                	fadd   st,st(2)
  429288:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  42928b:	d8 40 08             	fadd   DWORD PTR [eax+0x8]
  42928e:	d8 c3                	fadd   st,st(3)
  429290:	d9 cc                	fxch   st(4)
  429292:	d8 40 04             	fadd   DWORD PTR [eax+0x4]
  429295:	d9 15 10 c3 59 00    	fst    DWORD PTR ds:0x59c310
  42929b:	d9 1d b0 c2 59 00    	fstp   DWORD PTR ds:0x59c2b0
  4292a1:	d9 15 f0 c2 59 00    	fst    DWORD PTR ds:0x59c2f0
  4292a7:	d9 1d d0 c2 59 00    	fstp   DWORD PTR ds:0x59c2d0
  4292ad:	d9 15 d4 c2 59 00    	fst    DWORD PTR ds:0x59c2d4
  4292b3:	d9 1d b4 c2 59 00    	fstp   DWORD PTR ds:0x59c2b4
  4292b9:	d9 c1                	fld    st(1)
  4292bb:	d9 1d 14 c3 59 00    	fstp   DWORD PTR ds:0x59c314
  4292c1:	d9 c9                	fxch   st(1)
  4292c3:	d9 1d f4 c2 59 00    	fstp   DWORD PTR ds:0x59c2f4
  4292c9:	dd d8                	fstp   st(0)
  4292cb:	8b 8a 48 06 00 00    	mov    ecx,DWORD PTR [edx+0x648]
  4292d1:	8b 00                	mov    eax,DWORD PTR [eax]
  4292d3:	8b 50 0c             	mov    edx,DWORD PTR [eax+0xc]
  4292d6:	8b 42 40             	mov    eax,DWORD PTR [edx+0x40]
  4292d9:	50                   	push   eax
  4292da:	6a 01                	push   0x1
  4292dc:	51                   	push   ecx
  4292dd:	8b 01                	mov    eax,DWORD PTR [ecx]
  4292df:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4292e2:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4292e8:	6a 01                	push   0x1
  4292ea:	6a 11                	push   0x11
  4292ec:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4292f2:	50                   	push   eax
  4292f3:	8b 00                	mov    eax,DWORD PTR [eax]
  4292f5:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4292f8:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4292fe:	6a 01                	push   0x1
  429300:	6a 12                	push   0x12
  429302:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429308:	50                   	push   eax
  429309:	8b 00                	mov    eax,DWORD PTR [eax]
  42930b:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  42930e:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429314:	6a 08                	push   0x8
  429316:	6a 06                	push   0x6
  429318:	68 18 c3 59 00       	push   0x59c318
  42931d:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429323:	6a 04                	push   0x4
  429325:	68 98 c2 59 00       	push   0x59c298
  42932a:	6a 03                	push   0x3
  42932c:	6a 04                	push   0x4
  42932e:	50                   	push   eax
  42932f:	8b 00                	mov    eax,DWORD PTR [eax]
  429331:	ff 50 78             	call   DWORD PTR [eax+0x78]
  429334:	83 c7 14             	add    edi,0x14
  429337:	46                   	inc    esi
  429338:	3b 35 94 c2 59 00    	cmp    esi,DWORD PTR ds:0x59c294
  42933e:	0f 8c 72 fe ff ff    	jl     0x4291b6
  429344:	5f                   	pop    edi
  429345:	5e                   	pop    esi
  429346:	5b                   	pop    ebx
  429347:	83 c4 08             	add    esp,0x8
  42934a:	c3                   	ret
  42934b:	cc                   	int3
  42934c:	cc                   	int3
  42934d:	cc                   	int3
  42934e:	cc                   	int3
  42934f:	cc                   	int3
  429350:	83 ec 04             	sub    esp,0x4
  429353:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  429358:	56                   	push   esi
  429359:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  42935f:	c7 44 24 04 00 00 80 	mov    DWORD PTR [esp+0x4],0x3e800000
  429366:	3e 
  429367:	6a 01                	push   0x1
  429369:	8b 30                	mov    esi,DWORD PTR [eax]
  42936b:	6a 03                	push   0x3
  42936d:	50                   	push   eax
  42936e:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  429371:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429377:	6a 00                	push   0x0
  429379:	6a 05                	push   0x5
  42937b:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429381:	50                   	push   eax
  429382:	8b 30                	mov    esi,DWORD PTR [eax]
  429384:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  429387:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  42938d:	6a 00                	push   0x0
  42938f:	6a 06                	push   0x6
  429391:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429397:	50                   	push   eax
  429398:	8b 30                	mov    esi,DWORD PTR [eax]
  42939a:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  42939d:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293a3:	6a 00                	push   0x0
  4293a5:	6a 1b                	push   0x1b
  4293a7:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293ad:	50                   	push   eax
  4293ae:	8b 30                	mov    esi,DWORD PTR [eax]
  4293b0:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293b3:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293b9:	6a 01                	push   0x1
  4293bb:	6a 16                	push   0x16
  4293bd:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293c3:	50                   	push   eax
  4293c4:	8b 30                	mov    esi,DWORD PTR [eax]
  4293c6:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293c9:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4293cf:	6a 00                	push   0x0
  4293d1:	6a 01                	push   0x1
  4293d3:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4293d9:	50                   	push   eax
  4293da:	8b 30                	mov    esi,DWORD PTR [eax]
  4293dc:	ff 56 5c             	call   DWORD PTR [esi+0x5c]
  4293df:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
  4293e3:	85 f6                	test   esi,esi
  4293e5:	74 1e                	je     0x429405
  4293e7:	6a 00                	push   0x0
  4293e9:	e8 12 a1 0b 00       	call   0x4e3500
  4293ee:	83 c4 04             	add    esp,0x4
  4293f1:	8d 0c f5 00 00 00 00 	lea    ecx,[esi*8+0x0]
  4293f8:	2b ce                	sub    ecx,esi
  4293fa:	c1 e1 04             	shl    ecx,0x4
  4293fd:	03 0d fc c1 59 00    	add    ecx,DWORD PTR ds:0x59c1fc
  429403:	eb 21                	jmp    0x429426
  429405:	6a 01                	push   0x1
  429407:	e8 f4 a0 0b 00       	call   0x4e3500
  42940c:	83 c4 04             	add    esp,0x4
  42940f:	33 c0                	xor    eax,eax
  429411:	b9 d8 92 67 00       	mov    ecx,0x6792d8
  429416:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  42941a:	c7 44 24 04 00 00 00 	mov    DWORD PTR [esp+0x4],0x3f000000
  429421:	3f 
  429422:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  429426:	e8 f5 03 0e 00       	call   0x509820
  42942b:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  42942f:	8b 4c 24 28          	mov    ecx,DWORD PTR [esp+0x28]
  429433:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  429437:	50                   	push   eax
  429438:	51                   	push   ecx
  429439:	52                   	push   edx
  42943a:	e8 51 a1 0b 00       	call   0x4e3590
  42943f:	83 c4 0c             	add    esp,0xc
  429442:	6a 00                	push   0x0
  429444:	e8 67 a1 0b 00       	call   0x4e35b0
  429449:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  42944d:	8b 54 24 20          	mov    edx,DWORD PTR [esp+0x20]
  429451:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  429455:	83 c4 04             	add    esp,0x4
  429458:	68 9a 99 99 3f       	push   0x3f99999a
  42945d:	51                   	push   ecx
  42945e:	8b 4c 24 1c          	mov    ecx,DWORD PTR [esp+0x1c]
  429462:	52                   	push   edx
  429463:	8b 54 24 1c          	mov    edx,DWORD PTR [esp+0x1c]
  429467:	50                   	push   eax
  429468:	51                   	push   ecx
  429469:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  42946e:	52                   	push   edx
  42946f:	8b 88 48 06 00 00    	mov    ecx,DWORD PTR [eax+0x648]
  429475:	51                   	push   ecx
  429476:	e8 45 a7 0b 00       	call   0x4e3bc0
  42947b:	83 c4 1c             	add    esp,0x1c
  42947e:	5e                   	pop    esi
  42947f:	83 c4 04             	add    esp,0x4
  429482:	c3                   	ret
  429483:	cc                   	int3
  429484:	cc                   	int3
  429485:	cc                   	int3
  429486:	cc                   	int3
  429487:	cc                   	int3
  429488:	cc                   	int3
  429489:	cc                   	int3
  42948a:	cc                   	int3
  42948b:	cc                   	int3
  42948c:	cc                   	int3
  42948d:	cc                   	int3
  42948e:	cc                   	int3
  42948f:	cc                   	int3