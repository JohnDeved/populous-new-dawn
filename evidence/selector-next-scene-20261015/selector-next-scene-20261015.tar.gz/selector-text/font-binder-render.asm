  429490:	83 ec 2c             	sub    esp,0x2c
  429493:	53                   	push   ebx
  429494:	56                   	push   esi
  429495:	83 39 00             	cmp    DWORD PTR [ecx],0x0
  429498:	57                   	push   edi
  429499:	55                   	push   ebp
  42949a:	8b d9                	mov    ebx,ecx
  42949c:	0f 85 0f 01 00 00    	jne    0x4295b1
  4294a2:	8b 74 24 40          	mov    esi,DWORD PTR [esp+0x40]
  4294a6:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
  4294a9:	c1 e0 02             	shl    eax,0x2
  4294ac:	50                   	push   eax
  4294ad:	e8 ee 17 13 00       	call   0x55aca0
  4294b2:	83 c4 04             	add    esp,0x4
  4294b5:	8b f8                	mov    edi,eax
  4294b7:	89 03                	mov    DWORD PTR [ebx],eax
  4294b9:	33 c0                	xor    eax,eax
  4294bb:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  4294be:	c1 e1 02             	shl    ecx,0x2
  4294c1:	c1 e9 02             	shr    ecx,0x2
  4294c4:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  4294c6:	8b 46 10             	mov    eax,DWORD PTR [esi+0x10]
  4294c9:	c1 e0 02             	shl    eax,0x2
  4294cc:	50                   	push   eax
  4294cd:	e8 ce 17 13 00       	call   0x55aca0
  4294d2:	83 c4 04             	add    esp,0x4
  4294d5:	8b f8                	mov    edi,eax
  4294d7:	89 43 04             	mov    DWORD PTR [ebx+0x4],eax
  4294da:	33 c0                	xor    eax,eax
  4294dc:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  4294df:	c1 e1 02             	shl    ecx,0x2
  4294e2:	c1 e9 02             	shr    ecx,0x2
  4294e5:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  4294e7:	39 44 24 44          	cmp    DWORD PTR [esp+0x44],eax
  4294eb:	74 0b                	je     0x4294f8
  4294ed:	8b 0d 24 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c324
  4294f3:	e8 98 73 03 00       	call   0x460890
  4294f8:	c7 44 24 14 00 00 00 	mov    DWORD PTR [esp+0x14],0x0
  4294ff:	00 
  429500:	83 7e 10 00          	cmp    DWORD PTR [esi+0x10],0x0
  429504:	0f 86 91 00 00 00    	jbe    0x42959b
  42950a:	33 ff                	xor    edi,edi
  42950c:	89 7c 24 10          	mov    DWORD PTR [esp+0x10],edi
  429510:	8b 6e 0c             	mov    ebp,DWORD PTR [esi+0xc]
  429513:	8b 4b 04             	mov    ecx,DWORD PTR [ebx+0x4]
  429516:	03 6c 24 10          	add    ebp,DWORD PTR [esp+0x10]
  42951a:	83 7c 24 44 00       	cmp    DWORD PTR [esp+0x44],0x0
  42951f:	89 2c 39             	mov    DWORD PTR [ecx+edi*1],ebp
  429522:	74 5e                	je     0x429582
  429524:	8b 0d 24 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c324
  42952a:	e8 51 73 03 00       	call   0x460880
  42952f:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  429531:	89 04 39             	mov    DWORD PTR [ecx+edi*1],eax
  429534:	33 c0                	xor    eax,eax
  429536:	8d 4c 24 18          	lea    ecx,[esp+0x18]
  42953a:	8b 13                	mov    edx,DWORD PTR [ebx]
  42953c:	c7 44 24 18 a0 f1 58 	mov    DWORD PTR [esp+0x18],0x58f1a0
  429543:	00 
  429544:	66 8b 45 04          	mov    ax,WORD PTR [ebp+0x4]
  429548:	51                   	push   ecx
  429549:	8b 0d 24 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c324
  42954f:	89 44 24 20          	mov    DWORD PTR [esp+0x20],eax
  429553:	33 c0                	xor    eax,eax
  429555:	66 8b 45 06          	mov    ax,WORD PTR [ebp+0x6]
  429559:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  42955d:	89 6c 24 34          	mov    DWORD PTR [esp+0x34],ebp
  429561:	c7 44 24 38 00 00 00 	mov    DWORD PTR [esp+0x38],0x0
  429568:	00 
  429569:	c7 44 24 3c 00 00 00 	mov    DWORD PTR [esp+0x3c],0x0
  429570:	00 
  429571:	c7 44 24 30 00 00 00 	mov    DWORD PTR [esp+0x30],0x0
  429578:	00 
  429579:	8b 04 3a             	mov    eax,DWORD PTR [edx+edi*1]
  42957c:	50                   	push   eax
  42957d:	e8 1e 73 03 00       	call   0x4608a0
  429582:	83 c7 04             	add    edi,0x4
  429585:	ff 44 24 14          	inc    DWORD PTR [esp+0x14]
  429589:	83 44 24 10 08       	add    DWORD PTR [esp+0x10],0x8
  42958e:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  429592:	39 46 10             	cmp    DWORD PTR [esi+0x10],eax
  429595:	0f 87 75 ff ff ff    	ja     0x429510
  42959b:	83 7c 24 44 00       	cmp    DWORD PTR [esp+0x44],0x0
  4295a0:	74 0f                	je     0x4295b1
  4295a2:	8b 0d 24 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c324
  4295a8:	e8 c3 73 03 00       	call   0x460970
  4295ad:	85 c0                	test   eax,eax
  4295af:	75 02                	jne    0x4295b3
  4295b1:	33 c0                	xor    eax,eax
  4295b3:	5d                   	pop    ebp
  4295b4:	5f                   	pop    edi
  4295b5:	5e                   	pop    esi
  4295b6:	5b                   	pop    ebx
  4295b7:	83 c4 2c             	add    esp,0x2c
  4295ba:	c2 08 00             	ret    0x8
  4295bd:	cc                   	int3
  4295be:	cc                   	int3
  4295bf:	cc                   	int3
  4295c0:	83 ec 24             	sub    esp,0x24
  4295c3:	53                   	push   ebx
  4295c4:	56                   	push   esi
  4295c5:	8b 01                	mov    eax,DWORD PTR [ecx]
  4295c7:	57                   	push   edi
  4295c8:	8b f1                	mov    esi,ecx
  4295ca:	8b 7c 24 3c          	mov    edi,DWORD PTR [esp+0x3c]
  4295ce:	8d 1c b8             	lea    ebx,[eax+edi*4]
  4295d1:	83 3b 00             	cmp    DWORD PTR [ebx],0x0
  4295d4:	75 0c                	jne    0x4295e2
  4295d6:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  4295db:	e8 a0 72 03 00       	call   0x460880
  4295e0:	89 03                	mov    DWORD PTR [ebx],eax
  4295e2:	8b 06                	mov    eax,DWORD PTR [esi]
  4295e4:	8b 5e 04             	mov    ebx,DWORD PTR [esi+0x4]
  4295e7:	8b 0c b8             	mov    ecx,DWORD PTR [eax+edi*4]
  4295ea:	8b 14 bb             	mov    edx,DWORD PTR [ebx+edi*4]
  4295ed:	a1 94 c2 59 00       	mov    eax,ds:0x59c294
  4295f2:	8b 5c 24 34          	mov    ebx,DWORD PTR [esp+0x34]
  4295f6:	c1 e0 02             	shl    eax,0x2
  4295f9:	8b 3d c0 ad 65 00    	mov    edi,DWORD PTR ds:0x65adc0
  4295ff:	89 9c 80 c8 b5 65 00 	mov    DWORD PTR [eax+eax*4+0x65b5c8],ebx
  429606:	8d 34 80             	lea    esi,[eax+eax*4]
  429609:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  42960d:	89 86 cc b5 65 00    	mov    DWORD PTR [esi+0x65b5cc],eax
  429613:	89 be d0 b5 65 00    	mov    DWORD PTR [esi+0x65b5d0],edi
  429619:	89 8e d4 b5 65 00    	mov    DWORD PTR [esi+0x65b5d4],ecx
  42961f:	c7 86 d8 b5 65 00 ff 	mov    DWORD PTR [esi+0x65b5d8],0xffffffff
  429626:	ff ff ff 
  429629:	33 f6                	xor    esi,esi
  42962b:	85 d2                	test   edx,edx
  42962d:	74 3c                	je     0x42966b
  42962f:	c7 44 24 0c a0 f1 58 	mov    DWORD PTR [esp+0xc],0x58f1a0
  429636:	00 
  429637:	33 c0                	xor    eax,eax
  429639:	66 8b 42 04          	mov    ax,WORD PTR [edx+0x4]
  42963d:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  429641:	33 c0                	xor    eax,eax
  429643:	66 8b 42 06          	mov    ax,WORD PTR [edx+0x6]
  429647:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  42964b:	89 74 24 28          	mov    DWORD PTR [esp+0x28],esi
  42964f:	89 74 24 2c          	mov    DWORD PTR [esp+0x2c],esi
  429653:	89 74 24 20          	mov    DWORD PTR [esp+0x20],esi
  429657:	89 54 24 24          	mov    DWORD PTR [esp+0x24],edx
  42965b:	8d 54 24 0c          	lea    edx,[esp+0xc]
  42965f:	52                   	push   edx
  429660:	51                   	push   ecx
  429661:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429666:	e8 35 72 03 00       	call   0x4608a0
  42966b:	5f                   	pop    edi
  42966c:	ff 05 94 c2 59 00    	inc    DWORD PTR ds:0x59c294
  429672:	5e                   	pop    esi
  429673:	5b                   	pop    ebx
  429674:	83 c4 24             	add    esp,0x24
  429677:	c2 0c 00             	ret    0xc
  42967a:	cc                   	int3
  42967b:	cc                   	int3
  42967c:	cc                   	int3
  42967d:	cc                   	int3
  42967e:	cc                   	int3
  42967f:	cc                   	int3
  429680:	56                   	push   esi
  429681:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
  429684:	8b f1                	mov    esi,ecx
  429686:	50                   	push   eax
  429687:	e8 c4 16 13 00       	call   0x55ad50
  42968c:	83 c4 04             	add    esp,0x4
  42968f:	8b 06                	mov    eax,DWORD PTR [esi]
  429691:	c7 46 04 00 00 00 00 	mov    DWORD PTR [esi+0x4],0x0
  429698:	50                   	push   eax
  429699:	e8 b2 16 13 00       	call   0x55ad50
  42969e:	83 c4 04             	add    esp,0x4
  4296a1:	c7 06 00 00 00 00    	mov    DWORD PTR [esi],0x0
  4296a7:	5e                   	pop    esi
  4296a8:	c3                   	ret
  4296a9:	cc                   	int3
  4296aa:	cc                   	int3
  4296ab:	cc                   	int3
  4296ac:	cc                   	int3
  4296ad:	cc                   	int3
  4296ae:	cc                   	int3
  4296af:	cc                   	int3
  4296b0:	8b 54 24 04          	mov    edx,DWORD PTR [esp+0x4]
  4296b4:	56                   	push   esi
  4296b5:	57                   	push   edi
  4296b6:	33 c9                	xor    ecx,ecx
  4296b8:	8b 7c 24 14          	mov    edi,DWORD PTR [esp+0x14]
  4296bc:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  4296bf:	8b 74 b8 80          	mov    esi,DWORD PTR [eax+edi*4-0x80]
  4296c3:	66 8b 4e 04          	mov    cx,WORD PTR [esi+0x4]
  4296c7:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
  4296cb:	83 ef 20             	sub    edi,0x20
  4296ce:	89 0e                	mov    DWORD PTR [esi],ecx
  4296d0:	33 c9                	xor    ecx,ecx
  4296d2:	8b 42 04             	mov    eax,DWORD PTR [edx+0x4]
  4296d5:	8b 14 b8             	mov    edx,DWORD PTR [eax+edi*4]
  4296d8:	5f                   	pop    edi
  4296d9:	66 8b 4a 06          	mov    cx,WORD PTR [edx+0x6]
  4296dd:	89 4e 04             	mov    DWORD PTR [esi+0x4],ecx
  4296e0:	5e                   	pop    esi
  4296e1:	c3                   	ret
  4296e2:	cc                   	int3
  4296e3:	cc                   	int3
  4296e4:	cc                   	int3
  4296e5:	cc                   	int3
  4296e6:	cc                   	int3
  4296e7:	cc                   	int3
  4296e8:	cc                   	int3
  4296e9:	cc                   	int3
  4296ea:	cc                   	int3
  4296eb:	cc                   	int3
  4296ec:	cc                   	int3
  4296ed:	cc                   	int3
  4296ee:	cc                   	int3
  4296ef:	cc                   	int3
  4296f0:	83 ec 24             	sub    esp,0x24
  4296f3:	53                   	push   ebx
  4296f4:	56                   	push   esi
  4296f5:	8b 74 24 3c          	mov    esi,DWORD PTR [esp+0x3c]
  4296f9:	57                   	push   edi
  4296fa:	83 ee 20             	sub    esi,0x20
  4296fd:	8b 7c 24 34          	mov    edi,DWORD PTR [esp+0x34]
  429701:	8b 07                	mov    eax,DWORD PTR [edi]
  429703:	8d 1c b0             	lea    ebx,[eax+esi*4]
  429706:	83 3b 00             	cmp    DWORD PTR [ebx],0x0
  429709:	75 0c                	jne    0x429717
  42970b:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429710:	e8 6b 71 03 00       	call   0x460880
  429715:	89 03                	mov    DWORD PTR [ebx],eax
  429717:	8b 07                	mov    eax,DWORD PTR [edi]
  429719:	8b 5f 04             	mov    ebx,DWORD PTR [edi+0x4]
  42971c:	8b 0c b0             	mov    ecx,DWORD PTR [eax+esi*4]
  42971f:	8b 14 b3             	mov    edx,DWORD PTR [ebx+esi*4]
  429722:	a1 94 c2 59 00       	mov    eax,ds:0x59c294
  429727:	c1 e0 02             	shl    eax,0x2
  42972a:	8d 1c 80             	lea    ebx,[eax+eax*4]
  42972d:	8b 44 24 38          	mov    eax,DWORD PTR [esp+0x38]
  429731:	89 83 c8 b5 65 00    	mov    DWORD PTR [ebx+0x65b5c8],eax
  429737:	8b 44 24 3c          	mov    eax,DWORD PTR [esp+0x3c]
  42973b:	89 83 cc b5 65 00    	mov    DWORD PTR [ebx+0x65b5cc],eax
  429741:	a1 c0 ad 65 00       	mov    eax,ds:0x65adc0
  429746:	89 83 d0 b5 65 00    	mov    DWORD PTR [ebx+0x65b5d0],eax
  42974c:	89 8b d4 b5 65 00    	mov    DWORD PTR [ebx+0x65b5d4],ecx
  429752:	c7 83 d8 b5 65 00 ff 	mov    DWORD PTR [ebx+0x65b5d8],0xffffffff
  429759:	ff ff ff 
  42975c:	33 db                	xor    ebx,ebx
  42975e:	85 d2                	test   edx,edx
  429760:	74 3c                	je     0x42979e
  429762:	c7 44 24 0c a0 f1 58 	mov    DWORD PTR [esp+0xc],0x58f1a0
  429769:	00 
  42976a:	33 c0                	xor    eax,eax
  42976c:	66 8b 42 04          	mov    ax,WORD PTR [edx+0x4]
  429770:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  429774:	33 c0                	xor    eax,eax
  429776:	66 8b 42 06          	mov    ax,WORD PTR [edx+0x6]
  42977a:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  42977e:	89 5c 24 28          	mov    DWORD PTR [esp+0x28],ebx
  429782:	89 5c 24 2c          	mov    DWORD PTR [esp+0x2c],ebx
  429786:	89 5c 24 20          	mov    DWORD PTR [esp+0x20],ebx
  42978a:	89 54 24 24          	mov    DWORD PTR [esp+0x24],edx
  42978e:	8d 54 24 0c          	lea    edx,[esp+0xc]
  429792:	52                   	push   edx
  429793:	51                   	push   ecx
  429794:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429799:	e8 02 71 03 00       	call   0x4608a0
  42979e:	ff 05 94 c2 59 00    	inc    DWORD PTR ds:0x59c294
  4297a4:	8b 47 04             	mov    eax,DWORD PTR [edi+0x4]
  4297a7:	5f                   	pop    edi
  4297a8:	8b 0c b0             	mov    ecx,DWORD PTR [eax+esi*4]
  4297ab:	33 c0                	xor    eax,eax
  4297ad:	66 8b 41 04          	mov    ax,WORD PTR [ecx+0x4]
  4297b1:	5e                   	pop    esi
  4297b2:	5b                   	pop    ebx
  4297b3:	83 c4 24             	add    esp,0x24
  4297b6:	c3                   	ret
  4297b7:	cc                   	int3
  4297b8:	cc                   	int3
  4297b9:	cc                   	int3
  4297ba:	cc                   	int3
  4297bb:	cc                   	int3
  4297bc:	cc                   	int3
  4297bd:	cc                   	int3
  4297be:	cc                   	int3
  4297bf:	cc                   	int3
  4297c0:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  4297c4:	85 c0                	test   eax,eax
  4297c6:	75 03                	jne    0x4297cb
  4297c8:	33 c0                	xor    eax,eax
  4297ca:	c3                   	ret
  4297cb:	50                   	push   eax
  4297cc:	68 28 c3 59 00       	push   0x59c328
  4297d1:	e8 ca e2 0f 00       	call   0x527aa0
  4297d6:	83 c4 08             	add    esp,0x8
  4297d9:	c3                   	ret
