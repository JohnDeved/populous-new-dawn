  4297c0:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  4297c4:	85 c0                	test   eax,eax
  4297c6:	75 03                	jne    0x4297cb
  4297c8:	33 c0                	xor    eax,eax
  4297ca:	c3                   	ret
  4297cb:	50                   	push   eax
  4297cc:	68 28 c3 59 00       	push   0x59c328
  4297d1:	e8 ca e2 0f 00       	call   0x527aa0
  4297d6:	83 c4 08             	add    esp,0x8
  4297d9:	c3                   	ret
  4297da:	cc                   	int3
  4297db:	cc                   	int3
  4297dc:	cc                   	int3
  4297dd:	cc                   	int3
  4297de:	cc                   	int3
  4297df:	cc                   	int3
  4297e0:	c7 05 18 ac 67 00 90 	mov    DWORD PTR ds:0x67ac18,0x58f190
  4297e7:	f1 58 00 
  4297ea:	b9 18 ac 67 00       	mov    ecx,0x67ac18
  4297ef:	e8 4c fc 0d 00       	call   0x509440
  4297f4:	c7 05 18 ac 67 00 88 	mov    DWORD PTR ds:0x67ac18,0x58f188
  4297fb:	f1 58 00 
  4297fe:	b9 18 ac 67 00       	mov    ecx,0x67ac18
  429803:	e9 f8 02 0e 00       	jmp    0x509b00
  429808:	cc                   	int3
  429809:	cc                   	int3
  42980a:	cc                   	int3
  42980b:	cc                   	int3
  42980c:	cc                   	int3
  42980d:	cc                   	int3
  42980e:	cc                   	int3
  42980f:	cc                   	int3
  429810:	83 ec 7c             	sub    esp,0x7c
  429813:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  429818:	53                   	push   ebx
  429819:	8b 88 ac 1d 00 00    	mov    ecx,DWORD PTR [eax+0x1dac]
  42981f:	56                   	push   esi
  429820:	57                   	push   edi
  429821:	55                   	push   ebp
  429822:	68 60 c7 59 00       	push   0x59c760
  429827:	68 00 18 00 00       	push   0x1800
  42982c:	8b 50 04             	mov    edx,DWORD PTR [eax+0x4]
  42982f:	51                   	push   ecx
  429830:	6a 00                	push   0x0
  429832:	6a 40                	push   0x40
  429834:	6a 40                	push   0x40
  429836:	52                   	push   edx
  429837:	e8 b4 5c 00 00       	call   0x42f4f0
  42983c:	83 c4 1c             	add    esp,0x1c
  42983f:	85 c0                	test   eax,eax
  429841:	0f 85 74 01 00 00    	jne    0x4299bb
  429847:	8d 7c 24 20          	lea    edi,[esp+0x20]
  42984b:	33 c0                	xor    eax,eax
  42984d:	b9 1b 00 00 00       	mov    ecx,0x1b
  429852:	50                   	push   eax
  429853:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  429855:	8d 44 24 24          	lea    eax,[esp+0x24]
  429859:	68 21 08 00 00       	push   0x821
  42985e:	50                   	push   eax
  42985f:	8b 0d 60 c7 59 00    	mov    ecx,DWORD PTR ds:0x59c760
  429865:	c7 44 24 2c 6c 00 00 	mov    DWORD PTR [esp+0x2c],0x6c
  42986c:	00 
  42986d:	6a 00                	push   0x0
  42986f:	8b 01                	mov    eax,DWORD PTR [ecx]
  429871:	51                   	push   ecx
  429872:	ff 50 64             	call   DWORD PTR [eax+0x64]
  429875:	85 c0                	test   eax,eax
  429877:	0f 85 3e 01 00 00    	jne    0x4299bb
  42987d:	33 ff                	xor    edi,edi
  42987f:	be c8 a4 67 00       	mov    esi,0x67a4c8
  429884:	b9 18 c4 59 00       	mov    ecx,0x59c418
  429889:	89 7c 24 10          	mov    DWORD PTR [esp+0x10],edi
  42988d:	33 d2                	xor    edx,edx
  42988f:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  429893:	8a 51 06             	mov    dl,BYTE PTR [ecx+0x6]
  429896:	89 7c 24 14          	mov    DWORD PTR [esp+0x14],edi
  42989a:	db 44 24 14          	fild   DWORD PTR [esp+0x14]
  42989e:	8d 1c 17             	lea    ebx,[edi+edx*1]