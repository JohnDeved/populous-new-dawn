  4b25d0:	83 ec 08             	sub    esp,0x8
  4b25d3:	33 c9                	xor    ecx,ecx
  4b25d5:	39 0d 94 df 5c 00    	cmp    DWORD PTR ds:0x5cdf94,ecx
  4b25db:	74 3c                	je     0x4b2619
  4b25dd:	39 0d 44 dc 5c 00    	cmp    DWORD PTR ds:0x5cdc44,ecx
  4b25e3:	75 34                	jne    0x4b2619
  4b25e5:	8d 44 24 00          	lea    eax,[esp+0x0]
  4b25e9:	89 4c 24 00          	mov    DWORD PTR [esp+0x0],ecx
  4b25ed:	89 4c 24 04          	mov    DWORD PTR [esp+0x4],ecx
  4b25f1:	50                   	push   eax
  4b25f2:	8b 0d 4c dc 5c 00    	mov    ecx,DWORD PTR ds:0x5cdc4c
  4b25f8:	51                   	push   ecx
  4b25f9:	ff 15 98 c8 d0 00    	call   DWORD PTR ds:0xd0c898
  4b25ff:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  4b2603:	05 f0 00 00 00       	add    eax,0xf0
  4b2608:	50                   	push   eax
  4b2609:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  4b260d:	05 40 01 00 00       	add    eax,0x140
  4b2612:	50                   	push   eax
  4b2613:	ff 15 78 c8 d0 00    	call   DWORD PTR ds:0xd0c878
  4b2619:	e8 52 ad 04 00       	call   0x4fd370
  4b261e:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b2624:	e8 b7 e4 ff ff       	call   0x4b0ae0
  4b2629:	e8 e2 ae 04 00       	call   0x4fd510
  4b262e:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b2634:	e8 d7 e5 ff ff       	call   0x4b0c10
  4b2639:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4b263f:	e8 ec eb ff ff       	call   0x4b1230
  4b2644:	33 c0                	xor    eax,eax
  4b2646:	83 c4 08             	add    esp,0x8
  4b2649:	c3                   	ret
  4b264a:	cc                   	int3
  4b264b:	cc                   	int3
  4b264c:	cc                   	int3
  4b264d:	cc                   	int3
  4b264e:	cc                   	int3
  4b264f:	cc                   	int3
  4b2650:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  4b2655:	83 c0 0c             	add    eax,0xc
  4b2658:	c3                   	ret
  4b2659:	cc                   	int3
  4b265a:	cc                   	int3
  4b265b:	cc                   	int3
  4b265c:	cc                   	int3
  4b265d:	cc                   	int3
  4b265e:	cc                   	int3
  4b265f:	cc                   	int3
  4b2660:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  4b2665:	83 c0 5c             	add    eax,0x5c
  4b2668:	c3                   	ret
  4b2669:	cc                   	int3
  4b266a:	cc                   	int3
  4b266b:	cc                   	int3
  4b266c:	cc                   	int3
  4b266d:	cc                   	int3
  4b266e:	cc                   	int3
  4b266f:	cc                   	int3
  4b2670:	83 3d f4 c2 af 00 00 	cmp    DWORD PTR ds:0xafc2f4,0x0
  4b2677:	75 03                	jne    0x4b267c
  4b2679:	33 c0                	xor    eax,eax
  4b267b:	c3                   	ret
  4b267c:	a1 40 dc 5c 00       	mov    eax,ds:0x5cdc40
