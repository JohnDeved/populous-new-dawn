  476570:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  476576:	55                   	push   ebp
  476577:	8b ec                	mov    ebp,esp
  476579:	6a ff                	push   0xffffffff
  47657b:	68 23 69 47 00       	push   0x476923
  476580:	50                   	push   eax
  476581:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  476588:	81 ec c8 04 00 00    	sub    esp,0x4c8
  47658e:	8d 85 2c fb ff ff    	lea    eax,[ebp-0x4d4]
  476594:	ba ff 00 00 00       	mov    edx,0xff
  476599:	53                   	push   ebx
  47659a:	89 4d ec             	mov    DWORD PTR [ebp-0x14],ecx
  47659d:	56                   	push   esi
  47659e:	33 db                	xor    ebx,ebx
  4765a0:	57                   	push   edi
  4765a1:	88 50 02             	mov    BYTE PTR [eax+0x2],dl
  4765a4:	83 c0 04             	add    eax,0x4
  4765a7:	8d 8d 2c ff ff ff    	lea    ecx,[ebp-0xd4]
  4765ad:	88 50 fd             	mov    BYTE PTR [eax-0x3],dl
  4765b0:	88 50 fc             	mov    BYTE PTR [eax-0x4],dl
  4765b3:	3b c1                	cmp    eax,ecx
  4765b5:	88 58 ff             	mov    BYTE PTR [eax-0x1],bl
  4765b8:	72 e7                	jb     0x4765a1
  4765ba:	68 00 04 00 00       	push   0x400
  4765bf:	e8 dc 46 0e 00       	call   0x55aca0
  4765c4:	83 c4 04             	add    esp,0x4
  4765c7:	89 45 e8             	mov    DWORD PTR [ebp-0x18],eax
  4765ca:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4765d1:	83 7d e8 00          	cmp    DWORD PTR [ebp-0x18],0x0
  4765d5:	0f 84 ec 00 00 00    	je     0x4766c7
  4765db:	8b 45 10             	mov    eax,DWORD PTR [ebp+0x10]
  4765de:	8d 8d 2c ff ff ff    	lea    ecx,[ebp-0xd4]
  4765e4:	50                   	push   eax
  4765e5:	e8 56 03 00 00       	call   0x476940
  4765ea:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  4765ed:	8b 75 08             	mov    esi,DWORD PTR [ebp+0x8]
  4765f0:	c7 45 a8 00 01 00 00 	mov    DWORD PTR [ebp-0x58],0x100
  4765f7:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  4765fa:	33 db                	xor    ebx,ebx
  4765fc:	33 c0                	xor    eax,eax
  4765fe:	8a 1e                	mov    bl,BYTE PTR [esi]
  476600:	8a 46 01             	mov    al,BYTE PTR [esi+0x1]
  476603:	c1 e0 08             	shl    eax,0x8
  476606:	81 cb 00 ff ff ff    	or     ebx,0xffffff00
  47660c:	c1 e3 10             	shl    ebx,0x10
  47660f:	ba 01 00 00 00       	mov    edx,0x1
  476614:	0b d8                	or     ebx,eax
  476616:	8a 8d 40 ff ff ff    	mov    cl,BYTE PTR [ebp-0xc0]
  47661c:	33 c0                	xor    eax,eax
  47661e:	6a 03                	push   0x3
  476620:	d3 e2                	shl    edx,cl
  476622:	8a 46 02             	mov    al,BYTE PTR [esi+0x2]
  476625:	4a                   	dec    edx
  476626:	0b d8                	or     ebx,eax
  476628:	b9 ff 00 00 00       	mov    ecx,0xff
  47662d:	33 c0                	xor    eax,eax
  47662f:	8a c7                	mov    al,bh
  476631:	0f af c2             	imul   eax,edx
  476634:	83 c0 7f             	add    eax,0x7f
  476637:	99                   	cdq
  476638:	f7 f9                	idiv   ecx
  47663a:	8b f8                	mov    edi,eax
  47663c:	8a 8d 30 ff ff ff    	mov    cl,BYTE PTR [ebp-0xd0]
  476642:	8b c3                	mov    eax,ebx
  476644:	ba 01 00 00 00       	mov    edx,0x1
  476649:	d3 e7                	shl    edi,cl
  47664b:	25 00 00 ff 00       	and    eax,0xff0000
  476650:	8a 8d 3c ff ff ff    	mov    cl,BYTE PTR [ebp-0xc4]
  476656:	d3 e2                	shl    edx,cl
  476658:	c1 e8 10             	shr    eax,0x10
  47665b:	4a                   	dec    edx
  47665c:	0f af c2             	imul   eax,edx
  47665f:	b9 ff 00 00 00       	mov    ecx,0xff
  476664:	83 c0 7f             	add    eax,0x7f
  476667:	99                   	cdq
  476668:	f7 f9                	idiv   ecx
  47666a:	8a 8d 2c ff ff ff    	mov    cl,BYTE PTR [ebp-0xd4]
  476670:	d3 e0                	shl    eax,cl
  476672:	03 f8                	add    edi,eax
  476674:	8d 8d 2c ff ff ff    	lea    ecx,[ebp-0xd4]
  47667a:	8b c3                	mov    eax,ebx
  47667c:	81 e3 ff 00 00 00    	and    ebx,0xff
  476682:	c1 e8 18             	shr    eax,0x18
  476685:	50                   	push   eax
  476686:	e8 35 03 00 00       	call   0x4769c0
  47668b:	8a 8d 38 ff ff ff    	mov    cl,BYTE PTR [ebp-0xc8]
  476691:	6a 02                	push   0x2
  476693:	d3 e0                	shl    eax,cl
  476695:	03 f8                	add    edi,eax
  476697:	53                   	push   ebx
  476698:	8d 8d 2c ff ff ff    	lea    ecx,[ebp-0xd4]
  47669e:	e8 1d 03 00 00       	call   0x4769c0
  4766a3:	8a 8d 34 ff ff ff    	mov    cl,BYTE PTR [ebp-0xcc]
  4766a9:	d3 e0                	shl    eax,cl
  4766ab:	03 f8                	add    edi,eax
  4766ad:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4766b0:	83 45 f0 04          	add    DWORD PTR [ebp-0x10],0x4
  4766b4:	89 39                	mov    DWORD PTR [ecx],edi
  4766b6:	83 c6 04             	add    esi,0x4
  4766b9:	ff 4d a8             	dec    DWORD PTR [ebp-0x58]
  4766bc:	0f 85 38 ff ff ff    	jne    0x4765fa
  4766c2:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  4766c5:	eb 02                	jmp    0x4766c9
  4766c7:	33 c0                	xor    eax,eax
  4766c9:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4766cc:	68 00 04 00 00       	push   0x400
  4766d1:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4766d8:	89 01                	mov    DWORD PTR [ecx],eax
  4766da:	e8 c1 45 0e 00       	call   0x55aca0
  4766df:	83 c4 04             	add    esp,0x4
  4766e2:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  4766e5:	c7 45 fc 01 00 00 00 	mov    DWORD PTR [ebp-0x4],0x1
  4766ec:	85 c0                	test   eax,eax
  4766ee:	0f 84 dd 00 00 00    	je     0x4767d1
  4766f4:	8b 45 14             	mov    eax,DWORD PTR [ebp+0x14]
  4766f7:	8d 4d ac             	lea    ecx,[ebp-0x54]
  4766fa:	50                   	push   eax
  4766fb:	33 f6                	xor    esi,esi
  4766fd:	e8 3e 02 00 00       	call   0x476940
  476702:	8b d6                	mov    edx,esi
  476704:	33 c9                	xor    ecx,ecx
  476706:	83 ca 0f             	or     edx,0xf
  476709:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
  47670c:	c1 e2 08             	shl    edx,0x8
  47670f:	6a 03                	push   0x3
  476711:	8a 0c 02             	mov    cl,BYTE PTR [edx+eax*1]
  476714:	8b 55 08             	mov    edx,DWORD PTR [ebp+0x8]
  476717:	8b c6                	mov    eax,esi
  476719:	8d 3c 8a             	lea    edi,[edx+ecx*4]
  47671c:	83 e0 0f             	and    eax,0xf
  47671f:	2b d2                	sub    edx,edx
  476721:	8b c8                	mov    ecx,eax
  476723:	c1 e0 08             	shl    eax,0x8
  476726:	2b c1                	sub    eax,ecx
  476728:	b9 0f 00 00 00       	mov    ecx,0xf
  47672d:	f7 f1                	div    ecx
  47672f:	c1 e0 10             	shl    eax,0x10
  476732:	33 c9                	xor    ecx,ecx
  476734:	8a 4f 01             	mov    cl,BYTE PTR [edi+0x1]
  476737:	ba 01 00 00 00       	mov    edx,0x1
  47673c:	0b c1                	or     eax,ecx
  47673e:	33 c9                	xor    ecx,ecx
  476740:	c1 e0 08             	shl    eax,0x8
  476743:	8a 4f 02             	mov    cl,BYTE PTR [edi+0x2]
  476746:	0b c1                	or     eax,ecx
  476748:	33 c9                	xor    ecx,ecx
  47674a:	8a 0f                	mov    cl,BYTE PTR [edi]
  47674c:	c1 e1 10             	shl    ecx,0x10
  47674f:	0b c1                	or     eax,ecx
  476751:	8a 4d bc             	mov    cl,BYTE PTR [ebp-0x44]
  476754:	d3 e2                	shl    edx,cl
  476756:	8b d8                	mov    ebx,eax
  476758:	4a                   	dec    edx
  476759:	25 00 00 ff 00       	and    eax,0xff0000
  47675e:	b9 ff 00 00 00       	mov    ecx,0xff
  476763:	c1 e8 10             	shr    eax,0x10
  476766:	0f af c2             	imul   eax,edx
  476769:	83 c0 7f             	add    eax,0x7f
  47676c:	99                   	cdq
  47676d:	f7 f9                	idiv   ecx
  47676f:	8b f8                	mov    edi,eax
  476771:	8a 4d ac             	mov    cl,BYTE PTR [ebp-0x54]
  476774:	d3 e7                	shl    edi,cl
  476776:	8b c3                	mov    eax,ebx
  476778:	8d 4d ac             	lea    ecx,[ebp-0x54]
  47677b:	c1 e8 18             	shr    eax,0x18
  47677e:	50                   	push   eax
  47677f:	e8 3c 02 00 00       	call   0x4769c0
  476784:	8a 4d b8             	mov    cl,BYTE PTR [ebp-0x48]
  476787:	6a 01                	push   0x1
  476789:	d3 e0                	shl    eax,cl
  47678b:	03 f8                	add    edi,eax
  47678d:	8d 4d ac             	lea    ecx,[ebp-0x54]
  476790:	33 c0                	xor    eax,eax
  476792:	8a c7                	mov    al,bh
  476794:	50                   	push   eax
  476795:	e8 26 02 00 00       	call   0x4769c0
  47679a:	8a 4d b0             	mov    cl,BYTE PTR [ebp-0x50]
  47679d:	d3 e0                	shl    eax,cl
  47679f:	03 f8                	add    edi,eax
  4767a1:	6a 02                	push   0x2
  4767a3:	81 e3 ff 00 00 00    	and    ebx,0xff
  4767a9:	53                   	push   ebx
  4767aa:	8d 4d ac             	lea    ecx,[ebp-0x54]
  4767ad:	46                   	inc    esi
  4767ae:	e8 0d 02 00 00       	call   0x4769c0
  4767b3:	8a 4d b4             	mov    cl,BYTE PTR [ebp-0x4c]
  4767b6:	d3 e0                	shl    eax,cl
  4767b8:	03 f8                	add    edi,eax
  4767ba:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4767bd:	81 fe 00 01 00 00    	cmp    esi,0x100
  4767c3:	89 7c b1 fc          	mov    DWORD PTR [ecx+esi*4-0x4],edi
  4767c7:	0f 82 35 ff ff ff    	jb     0x476702
  4767cd:	8b c1                	mov    eax,ecx
  4767cf:	eb 02                	jmp    0x4767d3
  4767d1:	33 c0                	xor    eax,eax
  4767d3:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4767d6:	68 00 04 00 00       	push   0x400
  4767db:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4767e2:	89 41 04             	mov    DWORD PTR [ecx+0x4],eax
  4767e5:	e8 b6 44 0e 00       	call   0x55aca0
  4767ea:	83 c4 04             	add    esp,0x4
  4767ed:	89 45 e8             	mov    DWORD PTR [ebp-0x18],eax
  4767f0:	c7 45 fc 02 00 00 00 	mov    DWORD PTR [ebp-0x4],0x2
  4767f7:	83 7d e8 00          	cmp    DWORD PTR [ebp-0x18],0x0
  4767fb:	0f 84 e4 00 00 00    	je     0x4768e5
  476801:	8b 45 10             	mov    eax,DWORD PTR [ebp+0x10]
  476804:	8d 8d 6c ff ff ff    	lea    ecx,[ebp-0x94]
  47680a:	50                   	push   eax
  47680b:	8d b5 2c fb ff ff    	lea    esi,[ebp-0x4d4]
  476811:	e8 2a 01 00 00       	call   0x476940
  476816:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  476819:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  47681c:	33 db                	xor    ebx,ebx
  47681e:	33 c0                	xor    eax,eax
  476820:	8a 1e                	mov    bl,BYTE PTR [esi]
  476822:	8a 46 01             	mov    al,BYTE PTR [esi+0x1]
  476825:	c1 e0 08             	shl    eax,0x8
  476828:	81 cb 00 ff ff ff    	or     ebx,0xffffff00
  47682e:	c1 e3 10             	shl    ebx,0x10
  476831:	ba 01 00 00 00       	mov    edx,0x1
  476836:	0b d8                	or     ebx,eax
  476838:	8a 8d 7c ff ff ff    	mov    cl,BYTE PTR [ebp-0x84]
  47683e:	33 c0                	xor    eax,eax
  476840:	6a 03                	push   0x3
  476842:	8a 46 02             	mov    al,BYTE PTR [esi+0x2]
  476845:	83 c6 04             	add    esi,0x4
  476848:	d3 e2                	shl    edx,cl
  47684a:	0b d8                	or     ebx,eax
  47684c:	4a                   	dec    edx
  47684d:	8b c3                	mov    eax,ebx
  47684f:	b9 ff 00 00 00       	mov    ecx,0xff
  476854:	25 00 00 ff 00       	and    eax,0xff0000
  476859:	c1 e8 10             	shr    eax,0x10
  47685c:	0f af c2             	imul   eax,edx
  47685f:	83 c0 7f             	add    eax,0x7f
  476862:	99                   	cdq
  476863:	f7 f9                	idiv   ecx
  476865:	8b f8                	mov    edi,eax
  476867:	8a 8d 6c ff ff ff    	mov    cl,BYTE PTR [ebp-0x94]
  47686d:	d3 e7                	shl    edi,cl
  47686f:	8b c3                	mov    eax,ebx
  476871:	8d 8d 6c ff ff ff    	lea    ecx,[ebp-0x94]
  476877:	c1 e8 18             	shr    eax,0x18
  47687a:	50                   	push   eax
  47687b:	e8 40 01 00 00       	call   0x4769c0
  476880:	8a 8d 78 ff ff ff    	mov    cl,BYTE PTR [ebp-0x88]
  476886:	6a 02                	push   0x2
  476888:	d3 e0                	shl    eax,cl
  47688a:	03 f8                	add    edi,eax
  47688c:	8d 8d 6c ff ff ff    	lea    ecx,[ebp-0x94]
  476892:	8b c3                	mov    eax,ebx
  476894:	8a df                	mov    bl,bh
  476896:	25 ff 00 00 00       	and    eax,0xff
  47689b:	81 e3 ff 00 00 00    	and    ebx,0xff
  4768a1:	50                   	push   eax
  4768a2:	e8 19 01 00 00       	call   0x4769c0
  4768a7:	8a 8d 74 ff ff ff    	mov    cl,BYTE PTR [ebp-0x8c]
  4768ad:	6a 01                	push   0x1
  4768af:	d3 e0                	shl    eax,cl
  4768b1:	03 f8                	add    edi,eax
  4768b3:	53                   	push   ebx
  4768b4:	8d 8d 6c ff ff ff    	lea    ecx,[ebp-0x94]
  4768ba:	e8 01 01 00 00       	call   0x4769c0
  4768bf:	8a 8d 70 ff ff ff    	mov    cl,BYTE PTR [ebp-0x90]
  4768c5:	d3 e0                	shl    eax,cl
  4768c7:	03 f8                	add    edi,eax
  4768c9:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4768cc:	83 45 f0 04          	add    DWORD PTR [ebp-0x10],0x4
  4768d0:	8d 85 2c ff ff ff    	lea    eax,[ebp-0xd4]
  4768d6:	89 39                	mov    DWORD PTR [ecx],edi
  4768d8:	3b f0                	cmp    esi,eax
  4768da:	0f 82 3c ff ff ff    	jb     0x47681c
  4768e0:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  4768e3:	eb 02                	jmp    0x4768e7
  4768e5:	33 c0                	xor    eax,eax
  4768e7:	8b 4d ec             	mov    ecx,DWORD PTR [ebp-0x14]
  4768ea:	5f                   	pop    edi
  4768eb:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4768f2:	5e                   	pop    esi
  4768f3:	89 41 08             	mov    DWORD PTR [ecx+0x8],eax
  4768f6:	8b c1                	mov    eax,ecx
  4768f8:	5b                   	pop    ebx
  4768f9:	8b 4d f4             	mov    ecx,DWORD PTR [ebp-0xc]
  4768fc:	8b e5                	mov    esp,ebp
  4768fe:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  476905:	5d                   	pop    ebp
  476906:	c2 10 00             	ret    0x10
  476909:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
  47690c:	50                   	push   eax
  47690d:	e8 3e 44 0e 00       	call   0x55ad50
  476912:	83 c4 04             	add    esp,0x4
  476915:	c3                   	ret
  476916:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  476919:	50                   	push   eax
  47691a:	e8 31 44 0e 00       	call   0x55ad50
  47691f:	83 c4 04             	add    esp,0x4
  476922:	c3                   	ret
  476923:	b8 b0 52 59 00       	mov    eax,0x5952b0
  476928:	e9 c3 4e 0e 00       	jmp    0x55b7f0
  47692d:	8b 45 e8             	mov    eax,DWORD PTR [ebp-0x18]
