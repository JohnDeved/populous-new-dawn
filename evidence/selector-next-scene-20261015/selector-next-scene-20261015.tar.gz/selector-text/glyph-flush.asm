  429070:	c7 05 94 c2 59 00 00 	mov    DWORD PTR ds:0x59c294,0x0
  429077:	00 00 00 
  42907a:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  42907f:	e9 0c 78 03 00       	jmp    0x460890
  429084:	cc                   	int3
  429085:	cc                   	int3
  429086:	cc                   	int3
  429087:	cc                   	int3
  429088:	cc                   	int3
  429089:	cc                   	int3
  42908a:	cc                   	int3
  42908b:	cc                   	int3
  42908c:	cc                   	int3
  42908d:	cc                   	int3
  42908e:	cc                   	int3
  42908f:	cc                   	int3
  429090:	a1 50 f1 58 00       	mov    eax,ds:0x58f150
  429095:	a3 c0 ad 65 00       	mov    ds:0x65adc0,eax
  42909a:	c3                   	ret
  42909b:	cc                   	int3
  42909c:	cc                   	int3
  42909d:	cc                   	int3
  42909e:	cc                   	int3
  42909f:	cc                   	int3
  4290a0:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  4290a4:	a3 c0 ad 65 00       	mov    ds:0x65adc0,eax
  4290a9:	c3                   	ret
  4290aa:	cc                   	int3
  4290ab:	cc                   	int3
  4290ac:	cc                   	int3
  4290ad:	cc                   	int3
  4290ae:	cc                   	int3
  4290af:	cc                   	int3
  4290b0:	8b 54 24 04          	mov    edx,DWORD PTR [esp+0x4]
  4290b4:	83 ec 24             	sub    esp,0x24
  4290b7:	a1 94 c2 59 00       	mov    eax,ds:0x59c294
  4290bc:	56                   	push   esi
  4290bd:	c1 e0 02             	shl    eax,0x2
  4290c0:	8b 35 c0 ad 65 00    	mov    esi,DWORD PTR ds:0x65adc0
  4290c6:	89 94 80 c8 b5 65 00 	mov    DWORD PTR [eax+eax*4+0x65b5c8],edx
  4290cd:	8d 0c 80             	lea    ecx,[eax+eax*4]
  4290d0:	8b 44 24 30          	mov    eax,DWORD PTR [esp+0x30]
  4290d4:	89 81 cc b5 65 00    	mov    DWORD PTR [ecx+0x65b5cc],eax
  4290da:	8b 44 24 3c          	mov    eax,DWORD PTR [esp+0x3c]
  4290de:	33 d2                	xor    edx,edx
  4290e0:	89 b1 d0 b5 65 00    	mov    DWORD PTR [ecx+0x65b5d0],esi
  4290e6:	8b 74 24 38          	mov    esi,DWORD PTR [esp+0x38]
  4290ea:	89 b1 d4 b5 65 00    	mov    DWORD PTR [ecx+0x65b5d4],esi
  4290f0:	89 81 d8 b5 65 00    	mov    DWORD PTR [ecx+0x65b5d8],eax
  4290f6:	8b 4c 24 34          	mov    ecx,DWORD PTR [esp+0x34]
  4290fa:	85 c9                	test   ecx,ecx
  4290fc:	74 3c                	je     0x42913a
  4290fe:	c7 44 24 04 a0 f1 58 	mov    DWORD PTR [esp+0x4],0x58f1a0
  429105:	00 
  429106:	33 c0                	xor    eax,eax
  429108:	89 54 24 20          	mov    DWORD PTR [esp+0x20],edx
  42910c:	66 8b 41 04          	mov    ax,WORD PTR [ecx+0x4]
  429110:	89 54 24 24          	mov    DWORD PTR [esp+0x24],edx
  429114:	89 44 24 08          	mov    DWORD PTR [esp+0x8],eax
  429118:	89 54 24 18          	mov    DWORD PTR [esp+0x18],edx
  42911c:	33 c0                	xor    eax,eax
  42911e:	89 4c 24 1c          	mov    DWORD PTR [esp+0x1c],ecx
  429122:	66 8b 41 06          	mov    ax,WORD PTR [ecx+0x6]
  429126:	8d 4c 24 04          	lea    ecx,[esp+0x4]
  42912a:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  42912e:	51                   	push   ecx
  42912f:	56                   	push   esi
  429130:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429135:	e8 66 77 03 00       	call   0x4608a0
  42913a:	5e                   	pop    esi
  42913b:	ff 05 94 c2 59 00    	inc    DWORD PTR ds:0x59c294
  429141:	83 c4 24             	add    esp,0x24
  429144:	c3                   	ret
  429145:	cc                   	int3
  429146:	cc                   	int3
  429147:	cc                   	int3
  429148:	cc                   	int3
  429149:	cc                   	int3
  42914a:	cc                   	int3
  42914b:	cc                   	int3
  42914c:	cc                   	int3
  42914d:	cc                   	int3
  42914e:	cc                   	int3
  42914f:	cc                   	int3
  429150:	b8 24 00 00 00       	mov    eax,0x24
  429155:	c3                   	ret
  429156:	cc                   	int3
  429157:	cc                   	int3
  429158:	cc                   	int3
  429159:	cc                   	int3
  42915a:	cc                   	int3
  42915b:	cc                   	int3
  42915c:	cc                   	int3
  42915d:	cc                   	int3
  42915e:	cc                   	int3
  42915f:	cc                   	int3
  429160:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  429165:	e9 06 78 03 00       	jmp    0x460970
  42916a:	cc                   	int3
  42916b:	cc                   	int3
  42916c:	cc                   	int3
  42916d:	cc                   	int3
  42916e:	cc                   	int3
  42916f:	cc                   	int3
  429170:	83 ec 08             	sub    esp,0x8
  429173:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  429178:	53                   	push   ebx
  429179:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  42917f:	56                   	push   esi
  429180:	57                   	push   edi
  429181:	6a 01                	push   0x1
  429183:	8b 18                	mov    ebx,DWORD PTR [eax]
  429185:	6a 1b                	push   0x1b
  429187:	50                   	push   eax
  429188:	ff 53 5c             	call   DWORD PTR [ebx+0x5c]
  42918b:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429191:	6a 01                	push   0x1
  429193:	6a 09                	push   0x9
  429195:	33 f6                	xor    esi,esi
  429197:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  42919d:	50                   	push   eax
  42919e:	8b 18                	mov    ebx,DWORD PTR [eax]
  4291a0:	ff 53 5c             	call   DWORD PTR [ebx+0x5c]
  4291a3:	33 db                	xor    ebx,ebx
  4291a5:	39 1d 94 c2 59 00    	cmp    DWORD PTR ds:0x59c294,ebx
  4291ab:	0f 8e 93 01 00 00    	jle    0x429344
  4291b1:	bf c8 b5 65 00       	mov    edi,0x65b5c8
  4291b6:	8b 47 0c             	mov    eax,DWORD PTR [edi+0xc]
  4291b9:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  4291be:	50                   	push   eax
  4291bf:	e8 3c 83 03 00       	call   0x461500
  4291c4:	85 c0                	test   eax,eax
  4291c6:	0f 84 68 01 00 00    	je     0x429334
  4291cc:	db 07                	fild   DWORD PTR [edi]
  4291ce:	d9 15 f8 c2 59 00    	fst    DWORD PTR ds:0x59c2f8
  4291d4:	d9 1d 98 c2 59 00    	fstp   DWORD PTR ds:0x59c298
  4291da:	8b 50 1c             	mov    edx,DWORD PTR [eax+0x1c]
  4291dd:	03 17                	add    edx,DWORD PTR [edi]
  4291df:	89 54 24 0c          	mov    DWORD PTR [esp+0xc],edx
  4291e3:	89 5c 24 10          	mov    DWORD PTR [esp+0x10],ebx
  4291e7:	df 6c 24 0c          	fild   QWORD PTR [esp+0xc]
  4291eb:	d9 15 d8 c2 59 00    	fst    DWORD PTR ds:0x59c2d8
  4291f1:	d9 1d b8 c2 59 00    	fstp   DWORD PTR ds:0x59c2b8
  4291f7:	db 47 04             	fild   DWORD PTR [edi+0x4]
  4291fa:	d9 15 bc c2 59 00    	fst    DWORD PTR ds:0x59c2bc
  429200:	d9 1d 9c c2 59 00    	fstp   DWORD PTR ds:0x59c29c
  429206:	8b 50 20             	mov    edx,DWORD PTR [eax+0x20]
  429209:	03 57 04             	add    edx,DWORD PTR [edi+0x4]
  42920c:	89 54 24 0c          	mov    DWORD PTR [esp+0xc],edx
  429210:	8b 57 10             	mov    edx,DWORD PTR [edi+0x10]
  429213:	89 5c 24 10          	mov    DWORD PTR [esp+0x10],ebx
  429217:	89 15 08 c3 59 00    	mov    DWORD PTR ds:0x59c308,edx
  42921d:	df 6c 24 0c          	fild   QWORD PTR [esp+0xc]
  429221:	89 15 e8 c2 59 00    	mov    DWORD PTR ds:0x59c2e8,edx
  429227:	89 15 c8 c2 59 00    	mov    DWORD PTR ds:0x59c2c8,edx
  42922d:	89 15 a8 c2 59 00    	mov    DWORD PTR ds:0x59c2a8,edx
  429233:	8b 15 f4 c2 af 00    	mov    edx,DWORD PTR ds:0xafc2f4
  429239:	d9 15 fc c2 59 00    	fst    DWORD PTR ds:0x59c2fc
  42923f:	d9 1d dc c2 59 00    	fstp   DWORD PTR ds:0x59c2dc
  429245:	d9 47 08             	fld    DWORD PTR [edi+0x8]
  429248:	d9 15 00 c3 59 00    	fst    DWORD PTR ds:0x59c300
  42924e:	d9 1d e0 c2 59 00    	fstp   DWORD PTR ds:0x59c2e0
  429254:	8b 0d 00 c3 59 00    	mov    ecx,DWORD PTR ds:0x59c300
  42925a:	89 0d c0 c2 59 00    	mov    DWORD PTR ds:0x59c2c0,ecx
  429260:	89 0d a0 c2 59 00    	mov    DWORD PTR ds:0x59c2a0,ecx
  429266:	8b 08                	mov    ecx,DWORD PTR [eax]
  429268:	83 c1 10             	add    ecx,0x10
  42926b:	d9 01                	fld    DWORD PTR [ecx]
  42926d:	d8 0d 28 d3 5d 00    	fmul   DWORD PTR ds:0x5dd328
  429273:	d9 01                	fld    DWORD PTR [ecx]
  429275:	d8 0d 30 d3 5d 00    	fmul   DWORD PTR ds:0x5dd330
  42927b:	d9 40 08             	fld    DWORD PTR [eax+0x8]
  42927e:	d8 c2                	fadd   st,st(2)
  429280:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  429283:	d8 40 04             	fadd   DWORD PTR [eax+0x4]
  429286:	d8 c2                	fadd   st,st(2)
  429288:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  42928b:	d8 40 08             	fadd   DWORD PTR [eax+0x8]
  42928e:	d8 c3                	fadd   st,st(3)
  429290:	d9 cc                	fxch   st(4)
  429292:	d8 40 04             	fadd   DWORD PTR [eax+0x4]
  429295:	d9 15 10 c3 59 00    	fst    DWORD PTR ds:0x59c310
  42929b:	d9 1d b0 c2 59 00    	fstp   DWORD PTR ds:0x59c2b0
  4292a1:	d9 15 f0 c2 59 00    	fst    DWORD PTR ds:0x59c2f0
  4292a7:	d9 1d d0 c2 59 00    	fstp   DWORD PTR ds:0x59c2d0
  4292ad:	d9 15 d4 c2 59 00    	fst    DWORD PTR ds:0x59c2d4
  4292b3:	d9 1d b4 c2 59 00    	fstp   DWORD PTR ds:0x59c2b4
  4292b9:	d9 c1                	fld    st(1)
  4292bb:	d9 1d 14 c3 59 00    	fstp   DWORD PTR ds:0x59c314
  4292c1:	d9 c9                	fxch   st(1)
  4292c3:	d9 1d f4 c2 59 00    	fstp   DWORD PTR ds:0x59c2f4
  4292c9:	dd d8                	fstp   st(0)
  4292cb:	8b 8a 48 06 00 00    	mov    ecx,DWORD PTR [edx+0x648]
  4292d1:	8b 00                	mov    eax,DWORD PTR [eax]
  4292d3:	8b 50 0c             	mov    edx,DWORD PTR [eax+0xc]
  4292d6:	8b 42 40             	mov    eax,DWORD PTR [edx+0x40]
  4292d9:	50                   	push   eax
  4292da:	6a 01                	push   0x1
  4292dc:	51                   	push   ecx
  4292dd:	8b 01                	mov    eax,DWORD PTR [ecx]
  4292df:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4292e2:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4292e8:	6a 01                	push   0x1
  4292ea:	6a 11                	push   0x11
  4292ec:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  4292f2:	50                   	push   eax
  4292f3:	8b 00                	mov    eax,DWORD PTR [eax]
  4292f5:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4292f8:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  4292fe:	6a 01                	push   0x1
  429300:	6a 12                	push   0x12
  429302:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429308:	50                   	push   eax
  429309:	8b 00                	mov    eax,DWORD PTR [eax]
  42930b:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  42930e:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  429314:	6a 08                	push   0x8
  429316:	6a 06                	push   0x6
  429318:	68 18 c3 59 00       	push   0x59c318
  42931d:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  429323:	6a 04                	push   0x4
  429325:	68 98 c2 59 00       	push   0x59c298
  42932a:	6a 03                	push   0x3
  42932c:	6a 04                	push   0x4
  42932e:	50                   	push   eax
  42932f:	8b 00                	mov    eax,DWORD PTR [eax]
  429331:	ff 50 78             	call   DWORD PTR [eax+0x78]
  429334:	83 c7 14             	add    edi,0x14
  429337:	46                   	inc    esi
  429338:	3b 35 94 c2 59 00    	cmp    esi,DWORD PTR ds:0x59c294
  42933e:	0f 8c 72 fe ff ff    	jl     0x4291b6
  429344:	5f                   	pop    edi
  429345:	5e                   	pop    esi
  429346:	5b                   	pop    ebx
  429347:	83 c4 08             	add    esp,0x8
  42934a:	c3                   	ret
