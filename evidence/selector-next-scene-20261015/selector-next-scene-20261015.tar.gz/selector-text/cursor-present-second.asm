  4fd590:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  4fd596:	55                   	push   ebp
  4fd597:	8b ec                	mov    ebp,esp
  4fd599:	6a ff                	push   0xffffffff
  4fd59b:	68 93 d7 4f 00       	push   0x4fd793
  4fd5a0:	50                   	push   eax
  4fd5a1:	64 89 25 00 00 00 00 	mov    DWORD PTR fs:0x0,esp
  4fd5a8:	83 ec 28             	sub    esp,0x28
  4fd5ab:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fd5ae:	53                   	push   ebx
  4fd5af:	56                   	push   esi
  4fd5b0:	57                   	push   edi
  4fd5b1:	6a 00                	push   0x0
  4fd5b3:	68 78 8f a6 00       	push   0xa68f78
  4fd5b8:	e8 e3 e7 02 00       	call   0x52bda0
  4fd5bd:	6a 01                	push   0x1
  4fd5bf:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fd5c2:	c7 45 fc 00 00 00 00 	mov    DWORD PTR [ebp-0x4],0x0
  4fd5c9:	e8 02 e8 02 00       	call   0x52bdd0
  4fd5ce:	c7 45 f0 01 00 00 00 	mov    DWORD PTR [ebp-0x10],0x1
  4fd5d5:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fd5dc:	e8 bc 01 00 00       	call   0x4fd79d
  4fd5e1:	83 3d 24 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5724,0x0
  4fd5e8:	0f 84 61 01 00 00    	je     0x4fd74f
  4fd5ee:	e8 6d 50 fb ff       	call   0x4b2660
  4fd5f3:	83 3d 28 57 5d 00 00 	cmp    DWORD PTR ds:0x5d5728,0x0
  4fd5fa:	74 58                	je     0x4fd654
  4fd5fc:	c7 45 e4 00 00 00 00 	mov    DWORD PTR [ebp-0x1c],0x0
  4fd603:	8b 0d 38 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69038
  4fd609:	6a 00                	push   0x0
  4fd60b:	2b 0d 30 90 a6 00    	sub    ecx,DWORD PTR ds:0xa69030
  4fd611:	8d 55 e4             	lea    edx,[ebp-0x1c]
  4fd614:	52                   	push   edx
  4fd615:	89 4d ec             	mov    DWORD PTR [ebp-0x14],ecx
  4fd618:	8b 0d 3c 90 a6 00    	mov    ecx,DWORD PTR ds:0xa6903c
  4fd61e:	68 d8 8f a6 00       	push   0xa68fd8
  4fd623:	2b 0d 34 90 a6 00    	sub    ecx,DWORD PTR ds:0xa69034
  4fd629:	8b 1d 34 90 a6 00    	mov    ebx,DWORD PTR ds:0xa69034
  4fd62f:	c7 45 e8 00 00 00 00 	mov    DWORD PTR [ebp-0x18],0x0
  4fd636:	53                   	push   ebx
  4fd637:	89 4d f0             	mov    DWORD PTR [ebp-0x10],ecx
  4fd63a:	8b 0d 30 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69030
  4fd640:	51                   	push   ecx
  4fd641:	50                   	push   eax
  4fd642:	e8 29 c6 02 00       	call   0x529c70
  4fd647:	c7 05 28 57 5d 00 00 	mov    DWORD PTR ds:0x5d5728,0x0
  4fd64e:	00 00 00 
  4fd651:	83 c4 18             	add    esp,0x18
  4fd654:	e8 77 97 02 00       	call   0x526dd0
  4fd659:	8b 08                	mov    ecx,DWORD PTR [eax]
  4fd65b:	8b 50 04             	mov    edx,DWORD PTR [eax+0x4]
  4fd65e:	89 4d cc             	mov    DWORD PTR [ebp-0x34],ecx
  4fd661:	89 55 d0             	mov    DWORD PTR [ebp-0x30],edx
  4fd664:	e8 f7 4f fb ff       	call   0x4b2660
  4fd669:	89 45 f0             	mov    DWORD PTR [ebp-0x10],eax
  4fd66c:	8b 1d 28 90 a6 00    	mov    ebx,DWORD PTR ds:0xa69028
  4fd672:	8b 48 1c             	mov    ecx,DWORD PTR [eax+0x1c]
  4fd675:	8b 50 20             	mov    edx,DWORD PTR [eax+0x20]
  4fd678:	83 c0 1c             	add    eax,0x1c
  4fd67b:	8b 75 cc             	mov    esi,DWORD PTR [ebp-0x34]
  4fd67e:	8b 7d d0             	mov    edi,DWORD PTR [ebp-0x30]
  4fd681:	89 4d dc             	mov    DWORD PTR [ebp-0x24],ecx
  4fd684:	89 55 e0             	mov    DWORD PTR [ebp-0x20],edx
  4fd687:	8b 15 40 90 a6 00    	mov    edx,DWORD PTR ds:0xa69040
  4fd68d:	8b 4d dc             	mov    ecx,DWORD PTR [ebp-0x24]
  4fd690:	8d 04 16             	lea    eax,[esi+edx*1]
  4fd693:	3b c1                	cmp    eax,ecx
  4fd695:	8b 45 e0             	mov    eax,DWORD PTR [ebp-0x20]
  4fd698:	7e 04                	jle    0x4fd69e
  4fd69a:	2b ce                	sub    ecx,esi
  4fd69c:	8b d1                	mov    edx,ecx
  4fd69e:	8b 0d 28 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69028
  4fd6a4:	03 cf                	add    ecx,edi
  4fd6a6:	3b c8                	cmp    ecx,eax
  4fd6a8:	7e 04                	jle    0x4fd6ae
  4fd6aa:	2b c7                	sub    eax,edi
  4fd6ac:	8b d8                	mov    ebx,eax
  4fd6ae:	03 df                	add    ebx,edi
  4fd6b0:	03 d6                	add    edx,esi
  4fd6b2:	53                   	push   ebx
  4fd6b3:	52                   	push   edx
  4fd6b4:	57                   	push   edi
  4fd6b5:	56                   	push   esi
  4fd6b6:	68 30 90 a6 00       	push   0xa69030
  4fd6bb:	e8 20 eb 02 00       	call   0x52c1e0
  4fd6c0:	83 c4 14             	add    esp,0x14
  4fd6c3:	8b 45 f0             	mov    eax,DWORD PTR [ebp-0x10]
  4fd6c6:	6a 00                	push   0x0
  4fd6c8:	68 30 90 a6 00       	push   0xa69030
  4fd6cd:	50                   	push   eax
  4fd6ce:	6a 00                	push   0x0
  4fd6d0:	6a 00                	push   0x0
  4fd6d2:	68 d8 8f a6 00       	push   0xa68fd8
  4fd6d7:	e8 94 c5 02 00       	call   0x529c70
  4fd6dc:	83 c4 18             	add    esp,0x18
  4fd6df:	85 c0                	test   eax,eax
  4fd6e1:	75 0a                	jne    0x4fd6ed
  4fd6e3:	c7 05 28 57 5d 00 01 	mov    DWORD PTR ds:0x5d5728,0x1
  4fd6ea:	00 00 00 
  4fd6ed:	e8 6e 4f fb ff       	call   0x4b2660
  4fd6f2:	8b 58 20             	mov    ebx,DWORD PTR [eax+0x20]
  4fd6f5:	8d 48 1c             	lea    ecx,[eax+0x1c]
  4fd6f8:	8b 11                	mov    edx,DWORD PTR [ecx]
  4fd6fa:	8b 0d 28 90 a6 00    	mov    ecx,DWORD PTR ds:0xa69028
  4fd700:	89 55 ec             	mov    DWORD PTR [ebp-0x14],edx
  4fd703:	8b 15 40 90 a6 00    	mov    edx,DWORD PTR ds:0xa69040
  4fd709:	89 5d f0             	mov    DWORD PTR [ebp-0x10],ebx
  4fd70c:	8d 1c 16             	lea    ebx,[esi+edx*1]
  4fd70f:	3b 5d ec             	cmp    ebx,DWORD PTR [ebp-0x14]
  4fd712:	7e 05                	jle    0x4fd719
  4fd714:	8b 55 ec             	mov    edx,DWORD PTR [ebp-0x14]
  4fd717:	2b d6                	sub    edx,esi
  4fd719:	8b 1d 28 90 a6 00    	mov    ebx,DWORD PTR ds:0xa69028
  4fd71f:	03 df                	add    ebx,edi
  4fd721:	3b 5d f0             	cmp    ebx,DWORD PTR [ebp-0x10]
  4fd724:	7e 05                	jle    0x4fd72b
  4fd726:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  4fd729:	2b cf                	sub    ecx,edi
  4fd72b:	33 db                	xor    ebx,ebx
  4fd72d:	6a 01                	push   0x1
  4fd72f:	89 5d d4             	mov    DWORD PTR [ebp-0x2c],ebx
  4fd732:	89 55 dc             	mov    DWORD PTR [ebp-0x24],edx
  4fd735:	89 5d d8             	mov    DWORD PTR [ebp-0x28],ebx
  4fd738:	89 4d e0             	mov    DWORD PTR [ebp-0x20],ecx
  4fd73b:	8d 4d d4             	lea    ecx,[ebp-0x2c]
  4fd73e:	51                   	push   ecx
  4fd73f:	68 80 8f a6 00       	push   0xa68f80
  4fd744:	57                   	push   edi
  4fd745:	56                   	push   esi
  4fd746:	50                   	push   eax
  4fd747:	e8 24 c5 02 00       	call   0x529c70
  4fd74c:	83 c4 18             	add    esp,0x18
  4fd74f:	6a 01                	push   0x1
  4fd751:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fd754:	68 78 8f a6 00       	push   0xa68f78
  4fd759:	e8 42 e6 02 00       	call   0x52bda0
  4fd75e:	c7 45 fc 01 00 00 00 	mov    DWORD PTR [ebp-0x4],0x1
  4fd765:	8d 4d e8             	lea    ecx,[ebp-0x18]
  4fd768:	e8 b3 e6 02 00       	call   0x52be20
  4fd76d:	c7 45 fc ff ff ff ff 	mov    DWORD PTR [ebp-0x4],0xffffffff
  4fd774:	e8 12 00 00 00       	call   0x4fd78b
  4fd779:	8b 45 f4             	mov    eax,DWORD PTR [ebp-0xc]
  4fd77c:	5f                   	pop    edi
  4fd77d:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  4fd783:	5e                   	pop    esi
  4fd784:	5b                   	pop    ebx
  4fd785:	8b e5                	mov    esp,ebp
  4fd787:	5d                   	pop    ebp
  4fd788:	c2 0c 00             	ret    0xc
