
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00455f13 <.text+0x54f13>:
  455f13:	d9 43 3c             	fld    DWORD PTR [ebx+0x3c]
  455f16:	d8 05 b8 c9 5f 00    	fadd   DWORD PTR ds:0x5fc9b8
  455f1c:	d9 9c 24 9c 00 00 00 	fstp   DWORD PTR [esp+0x9c]
  455f23:	d9 43 40             	fld    DWORD PTR [ebx+0x40]
  455f26:	d8 05 bc c9 5f 00    	fadd   DWORD PTR ds:0x5fc9bc
  455f2c:	d9 9c 24 a0 00 00 00 	fstp   DWORD PTR [esp+0xa0]
  455f33:	8b 03                	mov    eax,DWORD PTR [ebx]
  455f35:	48                   	dec    eax
  455f36:	83 f8 04             	cmp    eax,0x4
  455f39:	0f 87 0a 0b 00 00    	ja     0x456a49
  455f3f:	ff 24 85 74 6a 45 00 	jmp    DWORD PTR [eax*4+0x456a74]
  455f46:	8b 73 08             	mov    esi,DWORD PTR [ebx+0x8]
  455f49:	8b 7b 10             	mov    edi,DWORD PTR [ebx+0x10]
  455f4c:	c7 44 24 58 00 00 00 	mov    DWORD PTR [esp+0x58],0x0
  455f53:	00 
  455f54:	83 7b 04 00          	cmp    DWORD PTR [ebx+0x4],0x0
  455f58:	0f 8e eb 0a 00 00    	jle    0x456a49
  455f5e:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455f61:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  455f68:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455f6b:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  455f72:	de c1                	faddp  st(1),st
  455f74:	d9 06                	fld    DWORD PTR [esi]
  455f76:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  455f7d:	de c1                	faddp  st(1),st
  455f7f:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  455f86:	d9 9c 24 e0 00 00 00 	fstp   DWORD PTR [esp+0xe0]
  455f8d:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455f90:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  455f97:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455f9a:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  455fa1:	de c1                	faddp  st(1),st
  455fa3:	d9 06                	fld    DWORD PTR [esi]
  455fa5:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  455fac:	de c1                	faddp  st(1),st
  455fae:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  455fb5:	d9 9c 24 e4 00 00 00 	fstp   DWORD PTR [esp+0xe4]
  455fbc:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455fbf:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  455fc6:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455fc9:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  455fd0:	de c1                	faddp  st(1),st
  455fd2:	d9 06                	fld    DWORD PTR [esi]
  455fd4:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  455fdb:	de c1                	faddp  st(1),st
  455fdd:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  455fe4:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  455fea:	d9 9c 24 e8 00 00 00 	fstp   DWORD PTR [esp+0xe8]
  455ff1:	df e0                	fnstsw ax
  455ff3:	f6 c4 41             	test   ah,0x41
  455ff6:	75 3c                	jne    0x456034
  455ff8:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  455ffe:	d8 b4 24 e8 00 00 00 	fdiv   DWORD PTR [esp+0xe8]
  456005:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  45600c:	d9 84 24 e0 00 00 00 	fld    DWORD PTR [esp+0xe0]
  456013:	d8 c9                	fmul   st,st(1)
  456015:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  45601c:	d9 1f                	fstp   DWORD PTR [edi]
  45601e:	d8 8c 24 e4 00 00 00 	fmul   DWORD PTR [esp+0xe4]
  456025:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  45602c:	d9 5f 04             	fstp   DWORD PTR [edi+0x4]
  45602f:	89 47 08             	mov    DWORD PTR [edi+0x8],eax
  456032:	eb 07                	jmp    0x45603b
  456034:	c7 47 08 00 00 80 bf 	mov    DWORD PTR [edi+0x8],0xbf800000
  45603b:	8d 8c 24 b0 00 00 00 	lea    ecx,[esp+0xb0]
  456042:	8b 07                	mov    eax,DWORD PTR [edi]
  456044:	8b 57 04             	mov    edx,DWORD PTR [edi+0x4]
  456047:	8b 6f 08             	mov    ebp,DWORD PTR [edi+0x8]
  45604a:	89 01                	mov    DWORD PTR [ecx],eax
  45604c:	89 51 04             	mov    DWORD PTR [ecx+0x4],edx
  45604f:	89 69 08             	mov    DWORD PTR [ecx+0x8],ebp
  456052:	83 bc 24 b8 00 00 00 	cmp    DWORD PTR [esp+0xb8],0x0
  456059:	00 
  45605a:	0f 8e e8 00 00 00    	jle    0x456148
  456060:	b8 00 00 00 80       	mov    eax,0x80000000
  456065:	39 84 24 b0 00 00 00 	cmp    DWORD PTR [esp+0xb0],eax
  45606c:	0f 87 d6 00 00 00    	ja     0x456148
  456072:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [esp+0xb0]
  456079:	39 0d c0 c9 5f 00    	cmp    DWORD PTR ds:0x5fc9c0,ecx
  45607f:	0f 82 c3 00 00 00    	jb     0x456148
  456085:	39 84 24 b4 00 00 00 	cmp    DWORD PTR [esp+0xb4],eax
  45608c:	0f 87 b6 00 00 00    	ja     0x456148
  456092:	8b 84 24 b4 00 00 00 	mov    eax,DWORD PTR [esp+0xb4]
  456099:	39 05 c4 c9 5f 00    	cmp    DWORD PTR ds:0x5fc9c4,eax
  45609f:	0f 82 a3 00 00 00    	jb     0x456148
  4560a5:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [esp+0xb8]
  4560ac:	89 84 24 90 00 00 00 	mov    DWORD PTR [esp+0x90],eax
  4560b3:	d9 84 24 90 00 00 00 	fld    DWORD PTR [esp+0x90]
  4560ba:	db 5c 24 10          	fistp  DWORD PTR [esp+0x10]
  4560be:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4560c2:	c1 f8 06             	sar    eax,0x6
  4560c5:	83 e8 53             	sub    eax,0x53
  4560c8:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  4560cc:	79 08                	jns    0x4560d6
  4560ce:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  4560d5:	00 
  4560d6:	83 7c 24 10 3f       	cmp    DWORD PTR [esp+0x10],0x3f
  4560db:	7e 08                	jle    0x4560e5
  4560dd:	c7 44 24 10 3f 00 00 	mov    DWORD PTR [esp+0x10],0x3f
  4560e4:	00 
  4560e5:	b8 3f 00 00 00       	mov    eax,0x3f
  4560ea:	2b 44 24 10          	sub    eax,DWORD PTR [esp+0x10]
  4560ee:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  4560f2:	c1 64 24 10 01       	shl    DWORD PTR [esp+0x10],0x1
  4560f7:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4560fb:	8b e8                	mov    ebp,eax
  4560fd:	8b c8                	mov    ecx,eax
  4560ff:	c1 e1 10             	shl    ecx,0x10
  456102:	81 cd 00 00 ff ff    	or     ebp,0xffff0000
  456108:	c1 e5 08             	shl    ebp,0x8
  45610b:	0b e9                	or     ebp,ecx
  45610d:	0b e8                	or     ebp,eax
  45610f:	e8 cc 25 fd ff       	call   0x4286e0
  456114:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [esp+0xb0]
  45611b:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [esp+0xb4]
  456122:	89 08                	mov    DWORD PTR [eax],ecx
  456124:	33 c9                	xor    ecx,ecx
  456126:	89 50 04             	mov    DWORD PTR [eax+0x4],edx
  456129:	c7 40 08 00 00 00 3f 	mov    DWORD PTR [eax+0x8],0x3f000000
  456130:	c7 40 0c 00 00 00 40 	mov    DWORD PTR [eax+0xc],0x40000000
  456137:	89 48 18             	mov    DWORD PTR [eax+0x18],ecx
  45613a:	89 48 1c             	mov    DWORD PTR [eax+0x1c],ecx
  45613d:	89 68 10             	mov    DWORD PTR [eax+0x10],ebp
  456140:	89 48 14             	mov    DWORD PTR [eax+0x14],ecx
  456143:	e8 b8 25 fd ff       	call   0x428700
  456148:	83 c6 0c             	add    esi,0xc
  45614b:	83 c7 0c             	add    edi,0xc
  45614e:	ff 44 24 58          	inc    DWORD PTR [esp+0x58]
  456152:	8b 44 24 58          	mov    eax,DWORD PTR [esp+0x58]
  456156:	39 43 04             	cmp    DWORD PTR [ebx+0x4],eax
  456159:	0f 8f ff fd ff ff    	jg     0x455f5e
  45615f:	e9 e5 08 00 00       	jmp    0x456a49
  456164:	c7 44 24 24 00 00 02 	mov    DWORD PTR [esp+0x24],0x3f020000
  45616b:	3f 
  45616c:	8b 43 18             	mov    eax,DWORD PTR [ebx+0x18]
  45616f:	85 c0                	test   eax,eax
  456171:	74 07                	je     0x45617a
  456173:	83 f8 01             	cmp    eax,0x1
  456176:	74 0c                	je     0x456184
  456178:	eb 12                	jmp    0x45618c
  45617a:	c7 44 24 24 00 00 00 	mov    DWORD PTR [esp+0x24],0x3c000000
  456181:	3c 
  456182:	eb 08                	jmp    0x45618c
  456184:	c7 44 24 24 00 00 84 	mov    DWORD PTR [esp+0x24],0x3e840000
  45618b:	3e 
  45618c:	8b 43 08             	mov    eax,DWORD PTR [ebx+0x8]
  45618f:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  456192:	d8 20                	fsub   DWORD PTR [eax]
  456194:	d9 e1                	fabs
  456196:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  456199:	d8 60 08             	fsub   DWORD PTR [eax+0x8]
  45619c:	d9 e1                	fabs
  45619e:	d8 d9                	fcomp  st(1)
  4561a0:	df e0                	fnstsw ax
  4561a2:	d9 44 24 24          	fld    DWORD PTR [esp+0x24]
  4561a6:	d8 05 04 f4 58 00    	fadd   DWORD PTR ds:0x58f404
  4561ac:	d9 44 24 24          	fld    DWORD PTR [esp+0x24]
  4561b0:	d8 05 08 f4 58 00    	fadd   DWORD PTR ds:0x58f408
  4561b6:	9e                   	sahf
  4561b7:	8b 43 10             	mov    eax,DWORD PTR [ebx+0x10]
  4561ba:	d9 5c 24 24          	fstp   DWORD PTR [esp+0x24]
  4561be:	d8 25 08 f4 58 00    	fsub   DWORD PTR ds:0x58f408
  4561c4:	8d 0c 45 02 00 00 00 	lea    ecx,[eax*2+0x2]
  4561cb:	51                   	push   ecx
  4561cc:	d9 5c 24 54          	fstp   DWORD PTR [esp+0x54]
  4561d0:	dd d8                	fstp   st(0)
  4561d2:	e8 89 25 fd ff       	call   0x428760
  4561d7:	8b 4b 10             	mov    ecx,DWORD PTR [ebx+0x10]
  4561da:	89 84 24 90 00 00 00 	mov    DWORD PTR [esp+0x90],eax
  4561e1:	83 c4 04             	add    esp,0x4
  4561e4:	8d 04 49             	lea    eax,[ecx+ecx*2]
  4561e7:	03 c0                	add    eax,eax
  4561e9:	33 ff                	xor    edi,edi
  4561eb:	50                   	push   eax
  4561ec:	e8 7f 25 fd ff       	call   0x428770
  4561f1:	89 44 24 50          	mov    DWORD PTR [esp+0x50],eax
  4561f5:	83 c4 04             	add    esp,0x4
  4561f8:	8b 53 08             	mov    edx,DWORD PTR [ebx+0x8]
  4561fb:	8b 73 0c             	mov    esi,DWORD PTR [ebx+0xc]
  4561fe:	39 7b 04             	cmp    DWORD PTR [ebx+0x4],edi
  456201:	0f 8e ee 00 00 00    	jle    0x4562f5
  456207:	b9 00 00 80 bf       	mov    ecx,0xbf800000
  45620c:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45620f:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  456216:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456219:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  456220:	de c1                	faddp  st(1),st
  456222:	d9 02                	fld    DWORD PTR [edx]
  456224:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  45622b:	de c1                	faddp  st(1),st
  45622d:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  456234:	d9 9c 24 d4 00 00 00 	fstp   DWORD PTR [esp+0xd4]
  45623b:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45623e:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  456245:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456248:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  45624f:	de c1                	faddp  st(1),st
  456251:	d9 02                	fld    DWORD PTR [edx]
  456253:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  45625a:	de c1                	faddp  st(1),st
  45625c:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  456263:	d9 9c 24 d8 00 00 00 	fstp   DWORD PTR [esp+0xd8]
  45626a:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45626d:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  456274:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456277:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  45627e:	de c1                	faddp  st(1),st
  456280:	d9 02                	fld    DWORD PTR [edx]
  456282:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  456289:	de c1                	faddp  st(1),st
  45628b:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  456292:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  456298:	d9 9c 24 dc 00 00 00 	fstp   DWORD PTR [esp+0xdc]
  45629f:	df e0                	fnstsw ax
  4562a1:	f6 c4 41             	test   ah,0x41
  4562a4:	75 3c                	jne    0x4562e2
  4562a6:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  4562ac:	d8 b4 24 dc 00 00 00 	fdiv   DWORD PTR [esp+0xdc]
  4562b3:	8b 84 24 dc 00 00 00 	mov    eax,DWORD PTR [esp+0xdc]
  4562ba:	d9 84 24 d4 00 00 00 	fld    DWORD PTR [esp+0xd4]
  4562c1:	d8 c9                	fmul   st,st(1)
  4562c3:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  4562ca:	d9 1e                	fstp   DWORD PTR [esi]
  4562cc:	d8 8c 24 d8 00 00 00 	fmul   DWORD PTR [esp+0xd8]
  4562d3:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  4562da:	d9 5e 04             	fstp   DWORD PTR [esi+0x4]
  4562dd:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  4562e0:	eb 03                	jmp    0x4562e5
  4562e2:	89 4e 08             	mov    DWORD PTR [esi+0x8],ecx
  4562e5:	47                   	inc    edi
  4562e6:	83 c2 0c             	add    edx,0xc
  4562e9:	83 c6 0c             	add    esi,0xc
  4562ec:	39 7b 04             	cmp    DWORD PTR [ebx+0x4],edi
  4562ef:	0f 8f 17 ff ff ff    	jg     0x45620c
  4562f5:	81 bc 24 ac 00 00 00 	cmp    DWORD PTR [esp+0xac],0x41200000
  4562fc:	00 00 20 41 
  456300:	7e 3d                	jle    0x45633f
  456302:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  456308:	d8 b4 24 ac 00 00 00 	fdiv   DWORD PTR [esp+0xac]
  45630f:	d9 84 24 a4 00 00 00 	fld    DWORD PTR [esp+0xa4]
  456316:	d8 c9                	fmul   st,st(1)
  456318:	8b 84 24 ac 00 00 00 	mov    eax,DWORD PTR [esp+0xac]
  45631f:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  456326:	d9 5b 30             	fstp   DWORD PTR [ebx+0x30]
  456329:	d8 8c 24 a8 00 00 00 	fmul   DWORD PTR [esp+0xa8]
  456330:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  456337:	d9 5b 34             	fstp   DWORD PTR [ebx+0x34]
  45633a:	89 43 38             	mov    DWORD PTR [ebx+0x38],eax
  45633d:	eb 07                	jmp    0x456346
  45633f:	c7 43 38 00 00 80 bf 	mov    DWORD PTR [ebx+0x38],0xbf800000
  456346:	c7 44 24 2c 00 00 00 	mov    DWORD PTR [esp+0x2c],0x0
  45634d:	00 
  45634e:	83 7b 10 00          	cmp    DWORD PTR [ebx+0x10],0x0
  456352:	8b 44 24 4c          	mov    eax,DWORD PTR [esp+0x4c]
  456356:	89 44 24 1c          	mov    DWORD PTR [esp+0x1c],eax
  45635a:	0f 8c 9e 02 00 00    	jl     0x4565fe
  456360:	8b 73 10             	mov    esi,DWORD PTR [ebx+0x10]
  456363:	ba 00 00 00 00       	mov    edx,0x0
  456368:	39 74 24 2c          	cmp    DWORD PTR [esp+0x2c],esi
  45636c:	7d 04                	jge    0x456372
  45636e:	8b 54 24 2c          	mov    edx,DWORD PTR [esp+0x2c]
  456372:	8b 4b 0c             	mov    ecx,DWORD PTR [ebx+0xc]
  456375:	8d 04 52             	lea    eax,[edx+edx*2]
  456378:	8d 2c 81             	lea    ebp,[ecx+eax*4]
  45637b:	8d 42 01             	lea    eax,[edx+0x1]
  45637e:	89 6c 24 20          	mov    DWORD PTR [esp+0x20],ebp
  456382:	3b c6                	cmp    eax,esi
  456384:	7c 02                	jl     0x456388
  456386:	33 c0                	xor    eax,eax
  456388:	4a                   	dec    edx
  456389:	79 03                	jns    0x45638e
  45638b:	8d 56 ff             	lea    edx,[esi-0x1]
  45638e:	8d 04 40             	lea    eax,[eax+eax*2]
  456391:	8d 14 52             	lea    edx,[edx+edx*2]
  456394:	d9 44 81 04          	fld    DWORD PTR [ecx+eax*4+0x4]
  456398:	8d 34 81             	lea    esi,[ecx+eax*4]
  45639b:	8d 04 91             	lea    eax,[ecx+edx*4]
  45639e:	89 74 24 3c          	mov    DWORD PTR [esp+0x3c],esi
  4563a2:	d8 60 04             	fsub   DWORD PTR [eax+0x4]
  4563a5:	d9 9c 24 94 00 00 00 	fstp   DWORD PTR [esp+0x94]
  4563ac:	d9 06                	fld    DWORD PTR [esi]
  4563ae:	d8 20                	fsub   DWORD PTR [eax]
  4563b0:	d9 e0                	fchs
  4563b2:	d9 9c 24 98 00 00 00 	fstp   DWORD PTR [esp+0x98]
  4563b9:	d9 84 24 94 00 00 00 	fld    DWORD PTR [esp+0x94]
  4563c0:	d9 e1                	fabs
  4563c2:	d9 5c 24 48          	fstp   DWORD PTR [esp+0x48]
  4563c6:	d9 84 24 98 00 00 00 	fld    DWORD PTR [esp+0x98]
  4563cd:	d9 e1                	fabs
  4563cf:	d8 54 24 48          	fcom   DWORD PTR [esp+0x48]
  4563d3:	d9 5c 24 54          	fstp   DWORD PTR [esp+0x54]
  4563d7:	df e0                	fnstsw ax
  4563d9:	f6 c4 01             	test   ah,0x1
  4563dc:	74 10                	je     0x4563ee
  4563de:	d9 44 24 54          	fld    DWORD PTR [esp+0x54]
  4563e2:	d8 0d a8 f3 58 00    	fmul   DWORD PTR ds:0x58f3a8
  4563e8:	d8 44 24 48          	fadd   DWORD PTR [esp+0x48]
  4563ec:	eb 0e                	jmp    0x4563fc
  4563ee:	d9 44 24 48          	fld    DWORD PTR [esp+0x48]
  4563f2:	d8 0d a8 f3 58 00    	fmul   DWORD PTR ds:0x58f3a8
  4563f8:	d8 44 24 54          	fadd   DWORD PTR [esp+0x54]
  4563fc:	d9 5c 24 44          	fstp   DWORD PTR [esp+0x44]
  456400:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  456404:	f7 40 08 ff ff ff 7f 	test   DWORD PTR [eax+0x8],0x7fffffff
  45640b:	74 0f                	je     0x45641c
  45640d:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  456413:	d8 70 08             	fdiv   DWORD PTR [eax+0x8]
  456416:	d9 5c 24 40          	fstp   DWORD PTR [esp+0x40]
  45641a:	eb 08                	jmp    0x456424
  45641c:	c7 44 24 40 00 00 00 	mov    DWORD PTR [esp+0x40],0x0
  456423:	00 
  456424:	f7 44 24 44 ff ff ff 	test   DWORD PTR [esp+0x44],0x7fffffff
  45642b:	7f 
  45642c:	74 28                	je     0x456456
  45642e:	d9 44 24 40          	fld    DWORD PTR [esp+0x40]
  456432:	d8 74 24 44          	fdiv   DWORD PTR [esp+0x44]
  456436:	d9 84 24 94 00 00 00 	fld    DWORD PTR [esp+0x94]
  45643d:	d8 c9                	fmul   st,st(1)
  45643f:	d9 9c 24 94 00 00 00 	fstp   DWORD PTR [esp+0x94]
  456446:	d8 8c 24 98 00 00 00 	fmul   DWORD PTR [esp+0x98]
  45644d:	d9 9c 24 98 00 00 00 	fstp   DWORD PTR [esp+0x98]
  456454:	eb 10                	jmp    0x456466
  456456:	33 c0                	xor    eax,eax
  456458:	89 84 24 98 00 00 00 	mov    DWORD PTR [esp+0x98],eax
  45645f:	89 84 24 94 00 00 00 	mov    DWORD PTR [esp+0x94],eax
  456466:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  45646a:	8b ac 24 8c 00 00 00 	mov    ebp,DWORD PTR [esp+0x8c]
  456471:	03 c0                	add    eax,eax
  456473:	8b c8                	mov    ecx,eax
  456475:	89 44 24 38          	mov    DWORD PTR [esp+0x38],eax
  456479:	c1 e1 05             	shl    ecx,0x5
  45647c:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  456480:	03 e9                	add    ebp,ecx
  456482:	8b 50 08             	mov    edx,DWORD PTR [eax+0x8]
  456485:	89 94 24 88 00 00 00 	mov    DWORD PTR [esp+0x88],edx
  45648c:	8d 4d 20             	lea    ecx,[ebp+0x20]
  45648f:	89 4c 24 14          	mov    DWORD PTR [esp+0x14],ecx
  456493:	d9 84 24 88 00 00 00 	fld    DWORD PTR [esp+0x88]
  45649a:	db 5c 24 18          	fistp  DWORD PTR [esp+0x18]
  45649e:	83 7c 24 18 00       	cmp    DWORD PTR [esp+0x18],0x0
  4564a3:	7d 08                	jge    0x4564ad
  4564a5:	c7 44 24 18 00 00 00 	mov    DWORD PTR [esp+0x18],0x0
  4564ac:	00 
  4564ad:	b8 cf 07 00 00       	mov    eax,0x7cf
  4564b2:	39 44 24 18          	cmp    DWORD PTR [esp+0x18],eax
  4564b6:	7e 04                	jle    0x4564bc
  4564b8:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  4564bc:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  4564c0:	b9 d0 07 00 00       	mov    ecx,0x7d0
  4564c5:	c1 e0 08             	shl    eax,0x8
  4564c8:	8b 7c 24 14          	mov    edi,DWORD PTR [esp+0x14]
  4564cc:	99                   	cdq
  4564cd:	f7 f9                	idiv   ecx
  4564cf:	8b 4c 24 20          	mov    ecx,DWORD PTR [esp+0x20]
  4564d3:	8b f5                	mov    esi,ebp
  4564d5:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  4564d9:	b8 ff 00 00 00       	mov    eax,0xff
  4564de:	2b 44 24 18          	sub    eax,DWORD PTR [esp+0x18]
  4564e2:	89 44 24 18          	mov    DWORD PTR [esp+0x18],eax
  4564e6:	8b 11                	mov    edx,DWORD PTR [ecx]
  4564e8:	89 55 00             	mov    DWORD PTR [ebp+0x0],edx
  4564eb:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
  4564ee:	89 45 04             	mov    DWORD PTR [ebp+0x4],eax
  4564f1:	d9 41 08             	fld    DWORD PTR [ecx+0x8]
  4564f4:	d8 0d 70 f3 58 00    	fmul   DWORD PTR ds:0x58f370
  4564fa:	d9 5d 08             	fstp   DWORD PTR [ebp+0x8]
  4564fd:	c7 45 0c 00 00 00 40 	mov    DWORD PTR [ebp+0xc],0x40000000
  456504:	8b 44 24 18          	mov    eax,DWORD PTR [esp+0x18]
  456508:	8b c8                	mov    ecx,eax
  45650a:	8b d0                	mov    edx,eax
  45650c:	c1 e2 10             	shl    edx,0x10
  45650f:	81 c9 00 00 ff ff    	or     ecx,0xffff0000
  456515:	c1 e1 08             	shl    ecx,0x8
  456518:	0b ca                	or     ecx,edx
  45651a:	0b c8                	or     ecx,eax
  45651c:	89 4d 10             	mov    DWORD PTR [ebp+0x10],ecx
  45651f:	b9 08 00 00 00       	mov    ecx,0x8
  456524:	c7 45 14 00 00 00 00 	mov    DWORD PTR [ebp+0x14],0x0
  45652b:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
  45652d:	b8 9a 99 99 3e       	mov    eax,0x3e99999a
  456532:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  456536:	81 7c 24 40 00 00 80 	cmp    DWORD PTR [esp+0x40],0x3f800000
  45653d:	3f 
  45653e:	89 41 18             	mov    DWORD PTR [ecx+0x18],eax
  456541:	89 45 18             	mov    DWORD PTR [ebp+0x18],eax
  456544:	7e 10                	jle    0x456556
  456546:	8b 54 24 24          	mov    edx,DWORD PTR [esp+0x24]
  45654a:	8b 44 24 50          	mov    eax,DWORD PTR [esp+0x50]
  45654e:	89 55 1c             	mov    DWORD PTR [ebp+0x1c],edx
  456551:	89 41 1c             	mov    DWORD PTR [ecx+0x1c],eax
  456554:	eb 14                	jmp    0x45656a
  456556:	d9 44 24 24          	fld    DWORD PTR [esp+0x24]
  45655a:	d8 44 24 50          	fadd   DWORD PTR [esp+0x50]
  45655e:	d8 0d a8 f3 58 00    	fmul   DWORD PTR ds:0x58f3a8
  456564:	d9 51 1c             	fst    DWORD PTR [ecx+0x1c]
  456567:	d9 5d 1c             	fstp   DWORD PTR [ebp+0x1c]
  45656a:	8b 4c 24 14          	mov    ecx,DWORD PTR [esp+0x14]
  45656e:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  456572:	d9 01                	fld    DWORD PTR [ecx]
  456574:	d8 84 24 94 00 00 00 	fadd   DWORD PTR [esp+0x94]
  45657b:	d9 19                	fstp   DWORD PTR [ecx]
  45657d:	d9 41 04             	fld    DWORD PTR [ecx+0x4]
  456580:	d8 84 24 98 00 00 00 	fadd   DWORD PTR [esp+0x98]
  456587:	d9 59 04             	fstp   DWORD PTR [ecx+0x4]
  45658a:	d9 45 00             	fld    DWORD PTR [ebp+0x0]
  45658d:	d8 a4 24 94 00 00 00 	fsub   DWORD PTR [esp+0x94]
  456594:	d9 5d 00             	fstp   DWORD PTR [ebp+0x0]
  456597:	d9 45 04             	fld    DWORD PTR [ebp+0x4]
  45659a:	d8 a4 24 98 00 00 00 	fsub   DWORD PTR [esp+0x98]
  4565a1:	d9 5d 04             	fstp   DWORD PTR [ebp+0x4]
  4565a4:	83 78 08 00          	cmp    DWORD PTR [eax+0x8],0x0
  4565a8:	7e 43                	jle    0x4565ed
  4565aa:	8b 74 24 3c          	mov    esi,DWORD PTR [esp+0x3c]
  4565ae:	83 7e 08 00          	cmp    DWORD PTR [esi+0x8],0x0
  4565b2:	7e 39                	jle    0x4565ed
  4565b4:	8b 54 24 38          	mov    edx,DWORD PTR [esp+0x38]
  4565b8:	8b 4c 24 2c          	mov    ecx,DWORD PTR [esp+0x2c]
  4565bc:	83 c2 02             	add    edx,0x2
  4565bf:	39 4b 10             	cmp    DWORD PTR [ebx+0x10],ecx
  4565c2:	7e 29                	jle    0x4565ed
  4565c4:	66 8b 4c 24 38       	mov    cx,WORD PTR [esp+0x38]
  4565c9:	8b 44 24 1c          	mov    eax,DWORD PTR [esp+0x1c]
  4565cd:	66 89 08             	mov    WORD PTR [eax],cx
  4565d0:	83 44 24 1c 0c       	add    DWORD PTR [esp+0x1c],0xc
  4565d5:	66 41                	inc    cx
  4565d7:	66 89 50 02          	mov    WORD PTR [eax+0x2],dx
  4565db:	66 89 48 04          	mov    WORD PTR [eax+0x4],cx
  4565df:	66 89 50 06          	mov    WORD PTR [eax+0x6],dx
  4565e3:	66 42                	inc    dx
  4565e5:	66 89 50 08          	mov    WORD PTR [eax+0x8],dx
  4565e9:	66 89 48 0a          	mov    WORD PTR [eax+0xa],cx
  4565ed:	ff 44 24 2c          	inc    DWORD PTR [esp+0x2c]
  4565f1:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  4565f5:	39 43 10             	cmp    DWORD PTR [ebx+0x10],eax
  4565f8:	0f 8d 62 fd ff ff    	jge    0x456360
  4565fe:	6a 01                	push   0x1
  456600:	6a 03                	push   0x3
  456602:	e8 b9 21 fd ff       	call   0x4287c0
  456607:	83 c4 08             	add    esp,0x8
  45660a:	6a 01                	push   0x1
  45660c:	6a 1b                	push   0x1b
  45660e:	e8 ad 21 fd ff       	call   0x4287c0
  456613:	83 c4 08             	add    esp,0x8
  456616:	a1 90 ad 65 00       	mov    eax,ds:0x65ad90
  45661b:	50                   	push   eax
  45661c:	6a 01                	push   0x1
  45661e:	e8 9d 21 fd ff       	call   0x4287c0
  456623:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  456627:	2b 44 24 54          	sub    eax,DWORD PTR [esp+0x54]
  45662b:	83 c4 08             	add    esp,0x8
  45662e:	c1 f8 01             	sar    eax,0x1
  456631:	50                   	push   eax
  456632:	e8 49 21 fd ff       	call   0x428780
  456637:	83 c4 04             	add    esp,0x4
  45663a:	e9 0a 04 00 00       	jmp    0x456a49
  45663f:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  456642:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  456649:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  45664c:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  456653:	8d 4b 10             	lea    ecx,[ebx+0x10]
  456656:	de c1                	faddp  st(1),st
  456658:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  45665b:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  456662:	de c1                	faddp  st(1),st
  456664:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  45666b:	d9 9c 24 c8 00 00 00 	fstp   DWORD PTR [esp+0xc8]
  456672:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  456675:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  45667c:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  45667f:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  456686:	de c1                	faddp  st(1),st
  456688:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  45668b:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  456692:	de c1                	faddp  st(1),st
  456694:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  45669b:	d9 9c 24 cc 00 00 00 	fstp   DWORD PTR [esp+0xcc]
  4566a2:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  4566a5:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  4566ac:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  4566af:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  4566b6:	de c1                	faddp  st(1),st
  4566b8:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  4566bb:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  4566c2:	de c1                	faddp  st(1),st
  4566c4:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  4566cb:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  4566d1:	d9 9c 24 d0 00 00 00 	fstp   DWORD PTR [esp+0xd0]
  4566d8:	df e0                	fnstsw ax
  4566da:	f6 c4 41             	test   ah,0x41
  4566dd:	75 3c                	jne    0x45671b
  4566df:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  4566e5:	d8 b4 24 d0 00 00 00 	fdiv   DWORD PTR [esp+0xd0]
  4566ec:	d9 84 24 c8 00 00 00 	fld    DWORD PTR [esp+0xc8]
  4566f3:	d8 c9                	fmul   st,st(1)
  4566f5:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [esp+0xd0]
  4566fc:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  456703:	d9 19                	fstp   DWORD PTR [ecx]
  456705:	d8 8c 24 cc 00 00 00 	fmul   DWORD PTR [esp+0xcc]
  45670c:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  456713:	d9 59 04             	fstp   DWORD PTR [ecx+0x4]
  456716:	89 41 08             	mov    DWORD PTR [ecx+0x8],eax
  456719:	eb 07                	jmp    0x456722
  45671b:	c7 41 08 00 00 80 bf 	mov    DWORD PTR [ecx+0x8],0xbf800000
  456722:	d9 01                	fld    DWORD PTR [ecx]
  456724:	8b 43 1c             	mov    eax,DWORD PTR [ebx+0x1c]
  456727:	66 8b 40 04          	mov    ax,WORD PTR [eax+0x4]
  45672b:	66 c1 e8 01          	shr    ax,0x1
  45672f:	0f b7 d0             	movzx  edx,ax
  456732:	89 94 24 84 00 00 00 	mov    DWORD PTR [esp+0x84],edx
  456739:	8d 51 04             	lea    edx,[ecx+0x4]
  45673c:	da a4 24 84 00 00 00 	fisub  DWORD PTR [esp+0x84]
  456743:	d9 19                	fstp   DWORD PTR [ecx]
  456745:	d9 02                	fld    DWORD PTR [edx]
  456747:	8b 43 1c             	mov    eax,DWORD PTR [ebx+0x1c]
  45674a:	66 8b 40 06          	mov    ax,WORD PTR [eax+0x6]
  45674e:	66 c1 e8 01          	shr    ax,0x1
  456752:	0f b7 e8             	movzx  ebp,ax
  456755:	89 ac 24 80 00 00 00 	mov    DWORD PTR [esp+0x80],ebp
  45675c:	da a4 24 80 00 00 00 	fisub  DWORD PTR [esp+0x80]
  456763:	d9 1a                	fstp   DWORD PTR [edx]
  456765:	8d 94 24 ec 00 00 00 	lea    edx,[esp+0xec]
  45676c:	8b 01                	mov    eax,DWORD PTR [ecx]
  45676e:	8b 69 04             	mov    ebp,DWORD PTR [ecx+0x4]
  456771:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  456774:	89 02                	mov    DWORD PTR [edx],eax
  456776:	89 6a 04             	mov    DWORD PTR [edx+0x4],ebp
  456779:	89 4a 08             	mov    DWORD PTR [edx+0x8],ecx
  45677c:	83 bc 24 f4 00 00 00 	cmp    DWORD PTR [esp+0xf4],0x0
  456783:	00 
  456784:	0f 8e bf 02 00 00    	jle    0x456a49
  45678a:	8b 4b 1c             	mov    ecx,DWORD PTR [ebx+0x1c]
  45678d:	33 c0                	xor    eax,eax
  45678f:	66 8b 41 04          	mov    ax,WORD PTR [ecx+0x4]
  456793:	f7 d8                	neg    eax
  456795:	89 44 24 7c          	mov    DWORD PTR [esp+0x7c],eax
  456799:	db 44 24 7c          	fild   DWORD PTR [esp+0x7c]
  45679d:	d8 9c 24 ec 00 00 00 	fcomp  DWORD PTR [esp+0xec]
  4567a4:	df e0                	fnstsw ax
  4567a6:	f6 c4 41             	test   ah,0x41
  4567a9:	0f 84 9a 02 00 00    	je     0x456a49
  4567af:	d9 05 c0 c9 5f 00    	fld    DWORD PTR ds:0x5fc9c0
  4567b5:	d8 9c 24 ec 00 00 00 	fcomp  DWORD PTR [esp+0xec]
  4567bc:	df e0                	fnstsw ax
  4567be:	f6 c4 01             	test   ah,0x1
  4567c1:	0f 85 82 02 00 00    	jne    0x456a49
  4567c7:	33 c0                	xor    eax,eax
  4567c9:	66 8b 41 06          	mov    ax,WORD PTR [ecx+0x6]
  4567cd:	f7 d8                	neg    eax
  4567cf:	89 44 24 78          	mov    DWORD PTR [esp+0x78],eax
  4567d3:	db 44 24 78          	fild   DWORD PTR [esp+0x78]
  4567d7:	d8 9c 24 f0 00 00 00 	fcomp  DWORD PTR [esp+0xf0]
  4567de:	df e0                	fnstsw ax
  4567e0:	f6 c4 41             	test   ah,0x41
  4567e3:	0f 84 60 02 00 00    	je     0x456a49
  4567e9:	d9 05 c4 c9 5f 00    	fld    DWORD PTR ds:0x5fc9c4
  4567ef:	d8 9c 24 f0 00 00 00 	fcomp  DWORD PTR [esp+0xf0]
  4567f6:	df e0                	fnstsw ax
  4567f8:	9e                   	sahf
  4567f9:	e9 4b 02 00 00       	jmp    0x456a49
