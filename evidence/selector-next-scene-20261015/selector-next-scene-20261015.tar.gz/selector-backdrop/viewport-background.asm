
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00522100 <.text+0x121100>:
  522100:	8b 54 24 04          	mov    edx,DWORD PTR [esp+0x4]
  522104:	83 ec 58             	sub    esp,0x58
  522107:	39 15 e4 d3 5d 00    	cmp    DWORD PTR ds:0x5dd3e4,edx
  52210d:	56                   	push   esi
  52210e:	57                   	push   edi
  52210f:	8b f1                	mov    esi,ecx
  522111:	75 0a                	jne    0x52211d
  522113:	33 c0                	xor    eax,eax
  522115:	5f                   	pop    edi
  522116:	5e                   	pop    esi
  522117:	83 c4 58             	add    esp,0x58
  52211a:	c2 04 00             	ret    0x4
  52211d:	8d 7c 24 10          	lea    edi,[esp+0x10]
  522121:	33 c0                	xor    eax,eax
  522123:	b9 14 00 00 00       	mov    ecx,0x14
  522128:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  52212a:	c7 44 24 10 50 00 00 	mov    DWORD PTR [esp+0x10],0x50
  522131:	00 
  522132:	8b c2                	mov    eax,edx
  522134:	25 00 00 ff 00       	and    eax,0xff0000
  522139:	c1 e8 10             	shr    eax,0x10
  52213c:	33 c9                	xor    ecx,ecx
  52213e:	8a ce                	mov    cl,dh
  522140:	89 44 24 08          	mov    DWORD PTR [esp+0x8],eax
  522144:	33 c0                	xor    eax,eax
  522146:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  52214a:	df 6c 24 08          	fild   QWORD PTR [esp+0x8]
  52214e:	89 4c 24 08          	mov    DWORD PTR [esp+0x8],ecx
  522152:	81 e2 ff 00 00 00    	and    edx,0xff
  522158:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  52215c:	d8 0d 50 fc 58 00    	fmul   DWORD PTR ds:0x58fc50
  522162:	d9 5c 24 14          	fstp   DWORD PTR [esp+0x14]
  522166:	df 6c 24 08          	fild   QWORD PTR [esp+0x8]
  52216a:	89 54 24 08          	mov    DWORD PTR [esp+0x8],edx
  52216e:	c7 44 24 20 00 00 80 	mov    DWORD PTR [esp+0x20],0x3f800000
  522175:	3f 
  522176:	d8 0d 50 fc 58 00    	fmul   DWORD PTR ds:0x58fc50
  52217c:	89 44 24 0c          	mov    DWORD PTR [esp+0xc],eax
  522180:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  522184:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  522188:	89 44 24 2c          	mov    DWORD PTR [esp+0x2c],eax
  52218c:	c7 44 24 5c 01 00 00 	mov    DWORD PTR [esp+0x5c],0x1
  522193:	00 
  522194:	d9 5c 24 18          	fstp   DWORD PTR [esp+0x18]
  522198:	df 6c 24 08          	fild   QWORD PTR [esp+0x8]
  52219c:	8d 4c 24 10          	lea    ecx,[esp+0x10]
  5221a0:	89 44 24 58          	mov    DWORD PTR [esp+0x58],eax
  5221a4:	8b 86 20 0d 00 00    	mov    eax,DWORD PTR [esi+0xd20]
  5221aa:	51                   	push   ecx
  5221ab:	d8 0d 50 fc 58 00    	fmul   DWORD PTR ds:0x58fc50
  5221b1:	d9 5c 24 20          	fstp   DWORD PTR [esp+0x20]
  5221b5:	8b 30                	mov    esi,DWORD PTR [eax]
  5221b7:	50                   	push   eax
  5221b8:	ff 56 0c             	call   DWORD PTR [esi+0xc]
  5221bb:	83 f8 01             	cmp    eax,0x1
  5221be:	8b c8                	mov    ecx,eax
  5221c0:	b8 00 00 00 00       	mov    eax,0x0
  5221c5:	5f                   	pop    edi
  5221c6:	83 d0 ff             	adc    eax,0xffffffff
  5221c9:	5e                   	pop    esi
  5221ca:	23 c1                	and    eax,ecx
  5221cc:	83 c4 58             	add    esp,0x58
  5221cf:	c2 04 00             	ret    0x4
  5221d2:	cc                   	int3
  5221d3:	cc                   	int3
  5221d4:	cc                   	int3
  5221d5:	cc                   	int3
  5221d6:	cc                   	int3
  5221d7:	cc                   	int3
  5221d8:	cc                   	int3
  5221d9:	cc                   	int3
  5221da:	cc                   	int3
  5221db:	cc                   	int3
  5221dc:	cc                   	int3
  5221dd:	cc                   	int3
  5221de:	cc                   	int3
  5221df:	cc                   	int3
  5221e0:	56                   	push   esi
  5221e1:	6a 01                	push   0x1
  5221e3:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  5221e9:	8b f1                	mov    esi,ecx
  5221eb:	6a 07                	push   0x7
  5221ed:	50                   	push   eax
  5221ee:	8b 00                	mov    eax,DWORD PTR [eax]
  5221f0:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  5221f3:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  5221f9:	6a 00                	push   0x0
  5221fb:	6a 1d                	push   0x1d
  5221fd:	50                   	push   eax
  5221fe:	8b 00                	mov    eax,DWORD PTR [eax]
  522200:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522203:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522209:	6a 01                	push   0x1
  52220b:	6a 1a                	push   0x1a
  52220d:	50                   	push   eax
  52220e:	8b 00                	mov    eax,DWORD PTR [eax]
  522210:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522213:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522219:	6a 01                	push   0x1
  52221b:	6a 20                	push   0x20
  52221d:	50                   	push   eax
  52221e:	8b 00                	mov    eax,DWORD PTR [eax]
  522220:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522223:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522229:	6a 01                	push   0x1
  52222b:	6a 1f                	push   0x1f
  52222d:	50                   	push   eax
  52222e:	8b 00                	mov    eax,DWORD PTR [eax]
  522230:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522233:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522239:	6a 01                	push   0x1
  52223b:	6a 16                	push   0x16
  52223d:	50                   	push   eax
  52223e:	8b 00                	mov    eax,DWORD PTR [eax]
  522240:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522243:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522249:	6a 02                	push   0x2
  52224b:	6a 09                	push   0x9
  52224d:	50                   	push   eax
  52224e:	8b 00                	mov    eax,DWORD PTR [eax]
  522250:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522253:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522259:	6a 00                	push   0x0
  52225b:	6a 05                	push   0x5
  52225d:	50                   	push   eax
  52225e:	8b 00                	mov    eax,DWORD PTR [eax]
  522260:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522263:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  522269:	6a 00                	push   0x0
  52226b:	6a 06                	push   0x6
  52226d:	50                   	push   eax
  52226e:	8b 00                	mov    eax,DWORD PTR [eax]
  522270:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  522273:	83 be d4 06 00 00 00 	cmp    DWORD PTR [esi+0x6d4],0x0
  52227a:	74 10                	je     0x52228c
  52227c:	8b                   	.byte 0x8b
  52227d:	86 48 06             	xchg   BYTE PTR [eax+0x6],cl
