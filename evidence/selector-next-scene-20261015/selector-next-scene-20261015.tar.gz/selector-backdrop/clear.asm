
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

005206c0 <.text+0x11f6c0>:
  5206c0:	83 ec 10             	sub    esp,0x10
  5206c3:	83 b9 ec 00 00 00 00 	cmp    DWORD PTR [ecx+0xec],0x0
  5206ca:	56                   	push   esi
  5206cb:	57                   	push   edi
  5206cc:	8b 7c 24 1c          	mov    edi,DWORD PTR [esp+0x1c]
  5206d0:	75 03                	jne    0x5206d5
  5206d2:	83 e7 fd             	and    edi,0xfffffffd
  5206d5:	8b 81 b8 00 00 00    	mov    eax,DWORD PTR [ecx+0xb8]
  5206db:	8b 91 bc 00 00 00    	mov    edx,DWORD PTR [ecx+0xbc]
  5206e1:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  5206e5:	89 54 24 14          	mov    DWORD PTR [esp+0x14],edx
  5206e9:	c7 44 24 08 00 00 00 	mov    DWORD PTR [esp+0x8],0x0
  5206f0:	00 
  5206f1:	c7 44 24 0c 00 00 00 	mov    DWORD PTR [esp+0xc],0x0
  5206f8:	00 
  5206f9:	f7 c7 02 00 00 00    	test   edi,0x2
  5206ff:	8b 54 24 20          	mov    edx,DWORD PTR [esp+0x20]
  520703:	74 08                	je     0x52070d
  520705:	85 d2                	test   edx,edx
  520707:	75 04                	jne    0x52070d
  520709:	8d 54 24 08          	lea    edx,[esp+0x8]
  52070d:	8b 81 4c 06 00 00    	mov    eax,DWORD PTR [ecx+0x64c]
  520713:	57                   	push   edi
  520714:	52                   	push   edx
  520715:	6a 01                	push   0x1
  520717:	50                   	push   eax
  520718:	8b 30                	mov    esi,DWORD PTR [eax]
  52071a:	ff 56 30             	call   DWORD PTR [esi+0x30]
  52071d:	83 f8 01             	cmp    eax,0x1
  520720:	8b c8                	mov    ecx,eax
  520722:	b8 00 00 00 00       	mov    eax,0x0
  520727:	5f                   	pop    edi
  520728:	83 d0 ff             	adc    eax,0xffffffff
  52072b:	5e                   	pop    esi
  52072c:	23 c1                	and    eax,ecx
  52072e:	83 c4 10             	add    esp,0x10
  520731:	c2 08 00             	ret    0x8
  520734:	cc                   	int3
  520735:	cc                   	int3
  520736:	cc                   	int3
  520737:	cc                   	int3
  520738:	cc                   	int3
  520739:	cc                   	int3
  52073a:	cc                   	int3
  52073b:	cc                   	int3
  52073c:	cc                   	int3
  52073d:	cc                   	int3
  52073e:	cc                   	int3
  52073f:	cc                   	int3
  520740:	c7 81 18 0d 00 00 01 	mov    DWORD PTR [ecx+0xd18],0x1
  520747:	00 00 00 
  52074a:	33 c0                	xor    eax,eax
  52074c:	89 81 1c 12 00 00    	mov    DWORD PTR [ecx+0x121c],eax
  520752:	89 81 44 06 00 00    	mov    DWORD PTR [ecx+0x644],eax
  520758:	89 81 48 06 00 00    	mov    DWORD PTR [ecx+0x648],eax
  52075e:	89 81 4c 06 00 00    	mov    DWORD PTR [ecx+0x64c],eax
  520764:	89 81 20 0d 00 00    	mov    DWORD PTR [ecx+0xd20],eax
  52076a:	89 81 ec 00 00 00    	mov    DWORD PTR [ecx+0xec],eax
  520770:	89 81 1c 0d 00 00    	mov    DWORD PTR [ecx+0xd1c],eax
  520776:	89 81 18 12 00 00    	mov    DWORD PTR [ecx+0x1218],eax
  52077c:	89 81 c0 06 00 00    	mov    DWORD PTR [ecx+0x6c0],eax
  520782:	89 81 cc 06 00 00    	mov    DWORD PTR [ecx+0x6cc],eax
  520788:	89 81 d0 06 00 00    	mov    DWORD PTR [ecx+0x6d0],eax
  52078e:	89 81 d4 06 00 00    	mov    DWORD PTR [ecx+0x6d4],eax
  520794:	89 81 d8 06 00 00    	mov    DWORD PTR [ecx+0x6d8],eax
  52079a:	89 81 f0 06 00 00    	mov    DWORD PTR [ecx+0x6f0],eax
  5207a0:	c7 81 c4 06 00 00 7f 	mov    DWORD PTR [ecx+0x6c4],0x7f
  5207a7:	00 00 00 
  5207aa:	89 81 f4 06 00 00    	mov    DWORD PTR [ecx+0x6f4],eax
  5207b0:	c3                   	ret
  5207b1:	cc                   	int3
  5207b2:	cc                   	int3
  5207b3:	cc                   	int3
  5207b4:	cc                   	int3
  5207b5:	cc                   	int3
  5207b6:	cc                   	int3
  5207b7:	cc                   	int3
  5207b8:	cc                   	int3
  5207b9:	cc                   	int3
  5207ba:	cc                   	int3
  5207bb:	cc                   	int3
  5207bc:	cc                   	int3
  5207bd:	cc                   	int3
  5207be:	cc                   	int3
  5207bf:	cc                   	int3
  5207c0:	81 ec 08 01 00 00    	sub    esp,0x108
  5207c6:	53                   	push   ebx
  5207c7:	56                   	push   esi
  5207c8:	83 b9 34 06 00 00 00 	cmp    DWORD PTR [ecx+0x634],0x0
  5207cf:	8b f1                	mov    esi,ecx
  5207d1:	7e 20                	jle    0x5207f3
  5207d3:	d9 86 34 06 00 00    	fld    DWORD PTR [esi+0x634]
  5207d9:	8d 44 24 10          	lea    eax,[esp+0x10]
  5207dd:	83 ec 08             	sub    esp,0x8
  5207e0:	dd 1c 24             	fstp   QWORD PTR [esp]
  5207e3:	68 58 d4 5d 00       	push   0x5dd458
  5207e8:	50                   	push   eax
  5207e9:	e8 62 ac 03 00       	call   0x55b450
  5207ee:	83 c4 10             	add    esp,0x10
  5207f1:	eb 05                	jmp    0x5207f8
  5207f3:	c6 44 24 10 00       	mov    BYTE PTR [esp+0x10],0x0
  5207f8:	8b 06                	mov    eax,DWORD PTR [esi]
  5207fa:	8b ce                	mov    ecx,esi
  5207fc:	33 db                	xor    ebx,ebx
  5207fe:	ff 50 30             	call   DWORD PTR [eax+0x30]
  520801:	89 44 24 08          	mov    DWORD PTR [esp+0x8],eax
  520805:	83 ec 08             	sub    esp,0x8
  520808:	8b 8e f4 00 00 00    	mov    ecx,DWORD PTR [esi+0xf4]
  52080e:	8d 44 24 18          	lea    eax,[esp+0x18]
  520812:	89 5c 24 14          	mov    DWORD PTR [esp+0x14],ebx
  520816:	50                   	push   eax
  520817:	df 6c 24 14          	fild   QWORD PTR [esp+0x14]
  52081b:	8d 14 49             	lea    edx,[ecx+ecx*2]
  52081e:	d8 0d 48 fc 58 00    	fmul   DWORD PTR ds:0x58fc48
  520824:	8d 0c 95 30 ea 98 00 	lea    ecx,[edx*4+0x98ea30]
  52082b:	dd 5c 24 04          	fstp   QWORD PTR [esp+0x4]
  52082f:	e8 0c f9 f8 ff       	call   0x4b0140
  520834:	8d 8c 24 9c 00 00 00 	lea    ecx,[esp+0x9c]
  52083b:	50                   	push   eax
  52083c:	68 44 d4 5d 00       	push   0x5dd444
  520841:	51                   	push   ecx
  520842:	e8 09 ac 03 00       	call   0x55b450
  520847:	88 5c 24 22          	mov    BYTE PTR [esp+0x22],bl
  52084b:	83 c4 18             	add    esp,0x18
  52084e:	88                   	.byte 0x88
  52084f:	5c                   	pop    esp
