
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00428760 <.text+0x27760>:
  428760:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  428764:	a3 8c c2 59 00       	mov    ds:0x59c28c,eax
  428769:	b8 d8 12 67 00       	mov    eax,0x6712d8
  42876e:	c3                   	ret
  42876f:	cc                   	int3
  428770:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  428774:	a3 90 c2 59 00       	mov    ds:0x59c290,eax
  428779:	b8 c8 ad 65 00       	mov    eax,0x65adc8
  42877e:	c3                   	ret
  42877f:	cc                   	int3
  428780:	83 3d 8c c2 59 00 00 	cmp    DWORD PTR ds:0x59c28c,0x0
  428787:	74 31                	je     0x4287ba
  428789:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  42878d:	85 c0                	test   eax,eax
  42878f:	74 29                	je     0x4287ba
  428791:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  428797:	6a 08                	push   0x8
  428799:	50                   	push   eax
  42879a:	68 c8 ad 65 00       	push   0x65adc8
  42879f:	8b 89 48 06 00 00    	mov    ecx,DWORD PTR [ecx+0x648]
  4287a5:	a1 8c c2 59 00       	mov    eax,ds:0x59c28c
  4287aa:	50                   	push   eax
  4287ab:	68 d8 12 67 00       	push   0x6712d8
  4287b0:	6a 03                	push   0x3
  4287b2:	8b 01                	mov    eax,DWORD PTR [ecx]
  4287b4:	6a 04                	push   0x4
  4287b6:	51                   	push   ecx
  4287b7:	ff 50 78             	call   DWORD PTR [eax+0x78]
  4287ba:	c3                   	ret
  4287bb:	cc                   	int3
  4287bc:	cc                   	int3
  4287bd:	cc                   	int3
  4287be:	cc                   	int3
  4287bf:	cc                   	int3
  4287c0:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  4287c5:	8b 54 24 08          	mov    edx,DWORD PTR [esp+0x8]
  4287c9:	52                   	push   edx
  4287ca:	8b 88 48 06 00 00    	mov    ecx,DWORD PTR [eax+0x648]
  4287d0:	8b 44 24 08          	mov    eax,DWORD PTR [esp+0x8]
  4287d4:	50                   	push   eax
  4287d5:	51                   	push   ecx
  4287d6:	8b 01                	mov    eax,DWORD PTR [ecx]
  4287d8:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  4287db:	c3                   	ret
  4287dc:	cc                   	int3
  4287dd:	cc                   	int3
  4287de:	cc                   	int3
  4287df:	cc                   	int3
  4287e0:	83 3d f4 c1 59 00 00 	cmp    DWORD PTR ds:0x59c1f4,0x0
  4287e7:	56                   	push   esi
  4287e8:	57                   	push   edi
  4287e9:	0f 84 b3 00 00 00    	je     0x4288a2
  4287ef:	e8 1c aa 06 00       	call   0x493210
  4287f4:	85 c0                	test   eax,eax
  4287f6:	74 05                	je     0x4287fd
  4287f8:	e8 43 c7 02 00       	call   0x454f40
  4287fd:	be 68 a4 67 00       	mov    esi,0x67a468
  428802:	e8 d9 65 05 00       	call   0x47ede0
  428807:	8b ce                	mov    ecx,esi
  428809:	83 ee 60             	sub    esi,0x60
  42880c:	e8 ef dc 04 00       	call   0x476500
  428811:	81 fe 48 a3 67 00    	cmp    esi,0x67a348
  428817:	73 ee                	jae    0x428807
  428819:	b9 38 ca 65 00       	mov    ecx,0x65ca38
  42881e:	e8 ad 7d 03 00       	call   0x4605d0
  428823:	8b 35 00 c2 59 00    	mov    esi,DWORD PTR ds:0x59c200
  428829:	85 f6                	test   esi,esi
  42882b:	74 10                	je     0x42883d
  42882d:	8b ce                	mov    ecx,esi
  42882f:	e8 bc e1 04 00       	call   0x4769f0
  428834:	56                   	push   esi
  428835:	e8 16 25 13 00       	call   0x55ad50
  42883a:	83 c4 04             	add    esp,0x4
  42883d:	33 f6                	xor    esi,esi
  42883f:	33 ff                	xor    edi,edi
  428841:	89 35 00 c2 59 00    	mov    DWORD PTR ds:0x59c200,esi
  428847:	39 35 b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,esi
  42884d:	7e 19                	jle    0x428868
  42884f:	8b 0d fc c1 59 00    	mov    ecx,DWORD PTR ds:0x59c1fc
  428855:	47                   	inc    edi
  428856:	03 ce                	add    ecx,esi
  428858:	83 c6 70             	add    esi,0x70
  42885b:	8b 01                	mov    eax,DWORD PTR [ecx]
  42885d:	ff 50 04             	call   DWORD PTR [eax+0x4]
  428860:	39 3d b8 13 5f 00    	cmp    DWORD PTR ds:0x5f13b8,edi
  428866:	7f e7                	jg     0x42884f
  428868:	a1 fc c1 59 00       	mov    eax,ds:0x59c1fc
  42886d:	33 f6                	xor    esi,esi
  42886f:	50                   	push   eax
  428870:	e8 db 24 13 00       	call   0x55ad50
  428875:	83 c4 04             	add    esp,0x4
  428878:	b9 c8 c9 65 00       	mov    ecx,0x65c9c8
  42887d:	89 35 fc c1 59 00    	mov    DWORD PTR ds:0x59c1fc,esi
  428883:	e8 b8 11 0e 00       	call   0x509a40
  428888:	b9 d8 92 67 00       	mov    ecx,0x6792d8
  42888d:	e8 ae 11 0e 00       	call   0x509a40
  428892:	b9 50 ad 65 00       	mov    ecx,0x65ad50
  428897:	e8 a4 11 0e 00       	call   0x509a40
  42889c:	89 35 f4 c1 59 00    	mov    DWORD PTR ds:0x59c1f4,esi
  4288a2:	e8 09 00 00 00       	call   0x4288b0
  4288a7:	5f                   	pop    edi
  4288a8:	5e                   	pop    esi
  4288a9:	c3                   	ret
  4288aa:	cc                   	int3
  4288ab:	cc                   	int3
  4288ac:	cc                   	int3
  4288ad:	cc                   	int3
  4288ae:	cc                   	int3
  4288af:	cc                   	int3
