
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

004286e0 <.text+0x276e0>:
  4286e0:	a1 88 c2 59 00       	mov    eax,ds:0x59c288
  4286e5:	8b c8                	mov    ecx,eax
  4286e7:	40                   	inc    eax
  4286e8:	c1 e1 05             	shl    ecx,0x5
  4286eb:	a3 88 c2 59 00       	mov    ds:0x59c288,eax
  4286f0:	8d 81 48 93 67 00    	lea    eax,[ecx+0x679348]
  4286f6:	c3                   	ret
  4286f7:	cc                   	int3
  4286f8:	cc                   	int3
  4286f9:	cc                   	int3
  4286fa:	cc                   	int3
  4286fb:	cc                   	int3
  4286fc:	cc                   	int3
  4286fd:	cc                   	int3
  4286fe:	cc                   	int3
  4286ff:	cc                   	int3
  428700:	81 3d 88 c2 59 00 80 	cmp    DWORD PTR ds:0x59c288,0x80
  428707:	00 00 00 
  42870a:	75 4c                	jne    0x428758
  42870c:	83 3d 88 c2 59 00 00 	cmp    DWORD PTR ds:0x59c288,0x0
  428713:	74 39                	je     0x42874e
  428715:	a1 f4 c2 af 00       	mov    eax,ds:0xafc2f4
  42871a:	6a 00                	push   0x0
  42871c:	6a 01                	push   0x1
  42871e:	8b 80 48 06 00 00    	mov    eax,DWORD PTR [eax+0x648]
  428724:	50                   	push   eax
  428725:	8b 00                	mov    eax,DWORD PTR [eax]
  428727:	ff 50 5c             	call   DWORD PTR [eax+0x5c]
  42872a:	8b 0d f4 c2 af 00    	mov    ecx,DWORD PTR ds:0xafc2f4
  428730:	6a 08                	push   0x8
  428732:	8b 15 88 c2 59 00    	mov    edx,DWORD PTR ds:0x59c288
  428738:	8b 81 48 06 00 00    	mov    eax,DWORD PTR [ecx+0x648]
  42873e:	52                   	push   edx
  42873f:	68 48 93 67 00       	push   0x679348
  428744:	6a 03                	push   0x3
  428746:	6a 01                	push   0x1
  428748:	50                   	push   eax
  428749:	8b 00                	mov    eax,DWORD PTR [eax]
  42874b:	ff 50 74             	call   DWORD PTR [eax+0x74]
  42874e:	c7 05 88 c2 59 00 00 	mov    DWORD PTR ds:0x59c288,0x0
  428755:	00 00 00 
  428758:	c3                   	ret
  428759:	cc                   	int3
  42875a:	cc                   	int3
  42875b:	cc                   	int3
  42875c:	cc                   	int3
  42875d:	cc                   	int3
  42875e:	cc                   	int3
  42875f:	cc                   	int3
