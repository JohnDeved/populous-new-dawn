
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00521ef0 <.text+0x120ef0>:
  521ef0:	83 ec 34             	sub    esp,0x34
  521ef3:	53                   	push   ebx
  521ef4:	56                   	push   esi
  521ef5:	8b 81 bc 00 00 00    	mov    eax,DWORD PTR [ecx+0xbc]
  521efb:	57                   	push   edi
  521efc:	8b f1                	mov    esi,ecx
  521efe:	50                   	push   eax
  521eff:	8b 8e b8 00 00 00    	mov    ecx,DWORD PTR [esi+0xb8]
  521f05:	8d 9e 4c 06 00 00    	lea    ebx,[esi+0x64c]
  521f0b:	51                   	push   ecx
  521f0c:	68 50 dc 5d 00       	push   0x5ddc50
  521f11:	e8 ba 55 f3 ff       	call   0x4574d0
  521f16:	83 c4 0c             	add    esp,0xc
  521f19:	8b 86 44 06 00 00    	mov    eax,DWORD PTR [esi+0x644]
  521f1f:	6a 00                	push   0x0
  521f21:	8b 38                	mov    edi,DWORD PTR [eax]
  521f23:	53                   	push   ebx
  521f24:	50                   	push   eax
  521f25:	ff 57 18             	call   DWORD PTR [edi+0x18]
  521f28:	85 c0                	test   eax,eax
  521f2a:	0f 85 ca 00 00 00    	jne    0x521ffa
  521f30:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  521f36:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  521f38:	8b 38                	mov    edi,DWORD PTR [eax]
  521f3a:	51                   	push   ecx
  521f3b:	50                   	push   eax
  521f3c:	ff 57 18             	call   DWORD PTR [edi+0x18]
  521f3f:	85 c0                	test   eax,eax
  521f41:	0f 85 b3 00 00 00    	jne    0x521ffa
  521f47:	8d 7c 24 14          	lea    edi,[esp+0x14]
  521f4b:	33 c0                	xor    eax,eax
  521f4d:	b9 0b 00 00 00       	mov    ecx,0xb
  521f52:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  521f54:	c7 44 24 14 2c 00 00 	mov    DWORD PTR [esp+0x14],0x2c
  521f5b:	00 
  521f5c:	33 ff                	xor    edi,edi
  521f5e:	8b 8e b8 00 00 00    	mov    ecx,DWORD PTR [esi+0xb8]
  521f64:	8b 86 bc 00 00 00    	mov    eax,DWORD PTR [esi+0xbc]
  521f6a:	89 7c 24 18          	mov    DWORD PTR [esp+0x18],edi
  521f6e:	89 7c 24 1c          	mov    DWORD PTR [esp+0x1c],edi
  521f72:	89 4c 24 20          	mov    DWORD PTR [esp+0x20],ecx
  521f76:	db 44 24 20          	fild   DWORD PTR [esp+0x20]
  521f7a:	89 44 24 24          	mov    DWORD PTR [esp+0x24],eax
  521f7e:	89 7c 24 28          	mov    DWORD PTR [esp+0x28],edi
  521f82:	8b 03                	mov    eax,DWORD PTR [ebx]
  521f84:	89 7c 24 2c          	mov    DWORD PTR [esp+0x2c],edi
  521f88:	8d 4c 24 14          	lea    ecx,[esp+0x14]
  521f8c:	89 7c 24 38          	mov    DWORD PTR [esp+0x38],edi
  521f90:	d9 5c 24 30          	fstp   DWORD PTR [esp+0x30]
  521f94:	db 44 24 24          	fild   DWORD PTR [esp+0x24]
  521f98:	c7 44 24 3c 00 00 80 	mov    DWORD PTR [esp+0x3c],0x3f800000
  521f9f:	3f 
  521fa0:	51                   	push   ecx
  521fa1:	50                   	push   eax
  521fa2:	d9 5c 24 3c          	fstp   DWORD PTR [esp+0x3c]
  521fa6:	8b 00                	mov    eax,DWORD PTR [eax]
  521fa8:	ff 50 44             	call   DWORD PTR [eax+0x44]
  521fab:	85 c0                	test   eax,eax
  521fad:	75 4b                	jne    0x521ffa
  521faf:	8b 86 48 06 00 00    	mov    eax,DWORD PTR [esi+0x648]
  521fb5:	8b 0b                	mov    ecx,DWORD PTR [ebx]
  521fb7:	8b 38                	mov    edi,DWORD PTR [eax]
  521fb9:	51                   	push   ecx
  521fba:	50                   	push   eax
  521fbb:	ff 57 34             	call   DWORD PTR [edi+0x34]
  521fbe:	85 c0                	test   eax,eax
  521fc0:	75 38                	jne    0x521ffa
  521fc2:	8b 8e 20 0d 00 00    	mov    ecx,DWORD PTR [esi+0xd20]
  521fc8:	8d 44 24 10          	lea    eax,[esp+0x10]
  521fcc:	50                   	push   eax
  521fcd:	8b 96 48 06 00 00    	mov    edx,DWORD PTR [esi+0x648]
  521fd3:	52                   	push   edx
  521fd4:	8b 31                	mov    esi,DWORD PTR [ecx]
  521fd6:	51                   	push   ecx
  521fd7:	ff 56 14             	call   DWORD PTR [esi+0x14]
  521fda:	85 c0                	test   eax,eax
  521fdc:	75 1c                	jne    0x521ffa
  521fde:	8b 03                	mov    eax,DWORD PTR [ebx]
  521fe0:	8b 4c 24 10          	mov    ecx,DWORD PTR [esp+0x10]
  521fe4:	8b 18                	mov    ebx,DWORD PTR [eax]
  521fe6:	51                   	push   ecx
  521fe7:	50                   	push   eax
  521fe8:	ff 53 20             	call   DWORD PTR [ebx+0x20]
  521feb:	83 f8 01             	cmp    eax,0x1
  521fee:	8b c8                	mov    ecx,eax
  521ff0:	b8 00 00 00 00       	mov    eax,0x0
  521ff5:	83 d0 ff             	adc    eax,0xffffffff
  521ff8:	23 c1                	and    eax,ecx
  521ffa:	5f                   	pop    edi
  521ffb:	5e                   	pop    esi
  521ffc:	5b                   	pop    ebx
  521ffd:	83 c4 34             	add    esp,0x34
  522000:	c3                   	ret
  522001:	cc                   	int3
  522002:	cc                   	int3
  522003:	cc                   	int3
  522004:	cc                   	int3
  522005:	cc                   	int3
  522006:	cc                   	int3
  522007:	cc                   	int3
  522008:	cc                   	int3
  522009:	cc                   	int3
  52200a:	cc                   	int3
  52200b:	cc                   	int3
  52200c:	cc                   	int3
  52200d:	cc                   	int3
  52200e:	cc                   	int3
  52200f:	cc                   	int3
  522010:	83 ec 34             	sub    esp,0x34
  522013:	53                   	push   ebx
  522014:	56                   	push   esi
  522015:	8b 74 24 40          	mov    esi,DWORD PTR [esp+0x40]
  522019:	57                   	push   edi
  52201a:	55                   	push   ebp
  52201b:	8b 81 b8 00 00 00    	mov    eax,DWORD PTR [ecx+0xb8]
  522021:	8b e9                	mov    ebp,ecx
  522023:	3b c6                	cmp    eax,esi
  522025:	77 03                	ja     0x52202a
  522027:	8d 70 ff             	lea    esi,[eax-0x1]
  52202a:	8b 8d bc 00 00 00    	mov    ecx,DWORD PTR [ebp+0xbc]
  522030:	8b 5c 24 4c          	mov    ebx,DWORD PTR [esp+0x4c]
  522034:	3b cb                	cmp    ecx,ebx
  522036:	77 03                	ja     0x52203b
  522038:	8d 59 ff             	lea    ebx,[ecx-0x1]
  52203b:	8b 54 24 50          	mov    edx,DWORD PTR [esp+0x50]
  52203f:	8d 3c 16             	lea    edi,[esi+edx*1]
  522042:	3b f8                	cmp    edi,eax
  522044:	76 04                	jbe    0x52204a
  522046:	8b d0                	mov    edx,eax
  522048:	2b d6                	sub    edx,esi
  52204a:	8b 44 24 54          	mov    eax,DWORD PTR [esp+0x54]
  52204e:	03 c3                	add    eax,ebx
  522050:	3b c1                	cmp    eax,ecx
  522052:	76 06                	jbe    0x52205a
  522054:	2b cb                	sub    ecx,ebx
  522056:	89 4c 24 54          	mov    DWORD PTR [esp+0x54],ecx
  52205a:	8d 7c 24 18          	lea    edi,[esp+0x18]
  52205e:	33 c0                	xor    eax,eax
  522060:	b9 0b 00 00 00       	mov    ecx,0xb
  522065:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  522067:	8b 44 24 54          	mov    eax,DWORD PTR [esp+0x54]
  52206b:	89 74 24 1c          	mov    DWORD PTR [esp+0x1c],esi
  52206f:	89 5c 24 20          	mov    DWORD PTR [esp+0x20],ebx
  522073:	89 54 24 24          	mov    DWORD PTR [esp+0x24],edx
  522077:	33 c9                	xor    ecx,ecx
  522079:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  52207d:	c7 44 24 18 2c 00 00 	mov    DWORD PTR [esp+0x18],0x2c
  522084:	00 
  522085:	89 74 24 10          	mov    DWORD PTR [esp+0x10],esi
  522089:	89 4c 24 14          	mov    DWORD PTR [esp+0x14],ecx
  52208d:	df 6c 24 10          	fild   QWORD PTR [esp+0x10]
  522091:	89 5c 24 10          	mov    DWORD PTR [esp+0x10],ebx
  522095:	89 4c 24 14          	mov    DWORD PTR [esp+0x14],ecx
  522099:	d9 5c 24 2c          	fstp   DWORD PTR [esp+0x2c]
  52209d:	df 6c 24 10          	fild   QWORD PTR [esp+0x10]
  5220a1:	89 54 24 10          	mov    DWORD PTR [esp+0x10],edx
  5220a5:	89 4c 24 14          	mov    DWORD PTR [esp+0x14],ecx
  5220a9:	d9 5c 24 30          	fstp   DWORD PTR [esp+0x30]
  5220ad:	df 6c 24 10          	fild   QWORD PTR [esp+0x10]
  5220b1:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  5220b5:	89 4c 24 3c          	mov    DWORD PTR [esp+0x3c],ecx
  5220b9:	8b 85 4c 06 00 00    	mov    eax,DWORD PTR [ebp+0x64c]
  5220bf:	89 4c 24 14          	mov    DWORD PTR [esp+0x14],ecx
  5220c3:	c7 44 24 40 00 00 80 	mov    DWORD PTR [esp+0x40],0x3f800000
  5220ca:	3f 
  5220cb:	d9 5c 24 34          	fstp   DWORD PTR [esp+0x34]
  5220cf:	df 6c 24 10          	fild   QWORD PTR [esp+0x10]
  5220d3:	8d 4c 24 18          	lea    ecx,[esp+0x18]
  5220d7:	d9 5c 24 38          	fstp   DWORD PTR [esp+0x38]
  5220db:	8b 38                	mov    edi,DWORD PTR [eax]
  5220dd:	51                   	push   ecx
  5220de:	50                   	push   eax
  5220df:	ff 57 44             	call   DWORD PTR [edi+0x44]
  5220e2:	89 b5 e8 06 00 00    	mov    DWORD PTR [ebp+0x6e8],esi
  5220e8:	89 9d ec 06 00 00    	mov    DWORD PTR [ebp+0x6ec],ebx
  5220ee:	5d                   	pop    ebp
  5220ef:	5f                   	pop    edi
  5220f0:	5e                   	pop    esi
  5220f1:	5b                   	pop    ebx
  5220f2:	83 c4 34             	add    esp,0x34
  5220f5:	c2 10 00             	ret    0x10
  5220f8:	cc                   	int3
  5220f9:	cc                   	int3
  5220fa:	cc                   	int3
  5220fb:	cc                   	int3
  5220fc:	cc                   	int3
  5220fd:	cc                   	int3
  5220fe:	cc                   	int3
  5220ff:	cc                   	int3
