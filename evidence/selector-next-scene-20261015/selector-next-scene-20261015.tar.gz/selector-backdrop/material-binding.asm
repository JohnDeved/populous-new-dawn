
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

0052120e <.text+0x12020e>:
  52120e:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  521211:	8b 81 44 06 00 00    	mov    eax,DWORD PTR [ecx+0x644]
  521217:	8d 99 20 0d 00 00    	lea    ebx,[ecx+0xd20]
  52121d:	6a 00                	push   0x0
  52121f:	53                   	push   ebx
  521220:	50                   	push   eax
  521221:	8b 00                	mov    eax,DWORD PTR [eax]
  521223:	ff 50 14             	call   DWORD PTR [eax+0x14]
  521226:	85 c0                	test   eax,eax
  521228:	0f 85 91 06 00 00    	jne    0x5218bf
  52122e:	83 3d e4 d3 5d 00 00 	cmp    DWORD PTR ds:0x5dd3e4,0x0
  521235:	b9 00 00 00 00       	mov    ecx,0x0
  52123a:	74 4f                	je     0x52128b
  52123c:	8d 7d 98             	lea    edi,[ebp-0x68]
  52123f:	33 c0                	xor    eax,eax
  521241:	b9 14 00 00 00       	mov    ecx,0x14
  521246:	f3 ab                	rep stos DWORD PTR es:[edi],eax
  521248:	c7 45 98 50 00 00 00 	mov    DWORD PTR [ebp-0x68],0x50
  52124f:	89 45 9c             	mov    DWORD PTR [ebp-0x64],eax
  521252:	89 45 a0             	mov    DWORD PTR [ebp-0x60],eax
  521255:	89 45 a4             	mov    DWORD PTR [ebp-0x5c],eax
  521258:	c7 45 a8 00 00 80 3f 	mov    DWORD PTR [ebp-0x58],0x3f800000
  52125f:	8d 4d 98             	lea    ecx,[ebp-0x68]
  521262:	89 45 ac             	mov    DWORD PTR [ebp-0x54],eax
  521265:	51                   	push   ecx
  521266:	89 45 b0             	mov    DWORD PTR [ebp-0x50],eax
  521269:	89 45 b4             	mov    DWORD PTR [ebp-0x4c],eax
  52126c:	89 45 e0             	mov    DWORD PTR [ebp-0x20],eax
  52126f:	c7 45 e4 01 00 00 00 	mov    DWORD PTR [ebp-0x1c],0x1
  521276:	8b 03                	mov    eax,DWORD PTR [ebx]
  521278:	50                   	push   eax
  521279:	8b 18                	mov    ebx,DWORD PTR [eax]
  52127b:	ff 53 0c             	call   DWORD PTR [ebx+0xc]
  52127e:	b9 00 00 00 00       	mov    ecx,0x0
  521283:	83 f8 01             	cmp    eax,0x1
  521286:	83 d1 ff             	adc    ecx,0xffffffff
  521289:	23 c8                	and    ecx,eax
  52128b:	b8 00 00 00 00       	mov    eax,0x0
  521290:	83 f9 01             	cmp    ecx,0x1
  521293:	83 d0 ff             	adc    eax,0xffffffff
  521296:	23 c1                	and    eax,ecx
  521298:	85 c0                	test   eax,eax
  52129a:	0f 85 1f 06 00 00    	jne    0x5218bf
  5212a0:	68 bc d8 5d 00       	push   0x5dd8bc
  5212a5:	e8 26 62 f3 ff       	call   0x4574d0
  5212aa:	83 c4 04             	add    esp,0x4
  5212ad:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  5212b0:	e8 3b 0c 00 00       	call   0x521ef0
  5212b5:	8b f8                	mov    edi,eax
  5212b7:	85 ff                	test   edi,edi
  5212b9:	7d 15                	jge    0x5212d0
  5212bb:	57                   	push   edi
  5212bc:	68 44 c3 59 00       	push   0x59c344
  5212c1:	e8 0a 62 f3 ff       	call   0x4574d0
  5212c6:	83 c4 08             	add    esp,0x8
  5212c9:	8b c7                	mov    eax,edi
  5212cb:	e9 ef 05 00 00       	jmp    0x5218bf
  5212d0:	68 38 c3 59 00       	push   0x59c338
  5212d5:	e8 f6 61 f3 ff       	call   0x4574d0
  5212da:	83 c4 04             	add    esp,0x4
  5212dd:	68 a0 d8 5d 00       	push   0x5dd8a0
  5212e2:	e8 e9 61 f3 ff       	call   0x4574d0
  5212e7:	83 c4 04             	add    esp,0x4
  5212ea:	8b 45 ec             	mov    eax,DWORD PTR [ebp-0x14]
  5212ed:	8b 4d f0             	mov    ecx,DWORD PTR [ebp-0x10]
  5212f0:	8b 10                	mov    edx,DWORD PTR [eax]
  5212f2:	8b 81 4c 06 00 00    	mov    eax,DWORD PTR [ecx+0x64c]
  5212f8:	8b 1a                	mov    ebx,DWORD PTR [edx]
  5212fa:	50                   	push   eax
  5212fb:	52                   	push   edx
  5212fc:	ff 53 34             	call   DWORD PTR [ebx+0x34]
  5212ff:	8b f8                	mov    edi,eax
  521301:	85 ff                	test   edi,edi
  521303:	7d 15                	jge    0x52131a
  521305:	57                   	push   edi
  521306:	68 44 c3 59 00       	push   0x59c344
  52130b:	e8 c0 61 f3 ff       	call   0x4574d0
