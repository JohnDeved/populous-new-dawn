# Selector orbit ribbons, point stars, and inactive space sprites

2026-10-15. Bounded static research for #17/#457, separate from PR464. Read repository AGENTS.md, GOAL.md, engineering/README.md, local populous-engineering skill and native-research.md. Reused /tmp/selector-static/{findings,scene-findings,globe-findings}.md, /tmp/selector-camera/findings.md, /tmp/selector-sun/findings.md and retained raw slices. No repository edits, Git settings changes, original execution/emulation, browser, builds, tests or Ghidra access. This packet is bound to original EXE SHA256 3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f, verified in input-sha256.txt. GNU objdump2.44, Python struct reads and existing sprite decoder/Pillow only.

## Useful result

Implementable components: black viewport clear, all orbit guides as textured screen-space ribbons using ring.png, and a separate 1,000-point grayscale star field. Do not render plsspace.spr nebula/star sprites in a reconstruction of this EXE's traced D3D selector: its active type4 dispatch projects/clips but has NO draw submission. This is positive control-flow evidence, not merely an absent literal cross-reference. Do not add plsbackg.dat as a fullscreen image. It is loaded but still lacks a proved draw consumer; black clear has its own positive live binding.

These recipes reconstruct source behavior. No historical full-frame pixel parity, original-runtime screenshot, exact old-device texture conversion, or unique historical random scene is claimed.

## Positive black-clear chain

004288b0 calls00522100(0) at004288d9–004288e1. 00522100 creates an80-byte material with RGB channels from that integer and alpha1; material object is ui+0xd20. Cached comparison005dd3e4 is initially ffffffff, so the initial zero call does not skip. Device setup0052120e creates this material. 00521ef0 obtains its device handle and calls viewport+0x20 (SetBackground) with it at00521fc2–00521fe8. This is the same viewport ui+0x64c that004284d0 →005206c0(3,NULL) clears each frame through viewport+0x30 (Clear); flags3 cover target and depth, with depth bit removed if unavailable. Thus black backdrop is bound by material+viewport, independently of the legacy307200-byte plsbackg load. Device failures are not modeled by this source-path claim.

## Scene ownership and draw sequence

00455180 initializes slot0 as type3; jump table00456a74 maps type3 directly to next-slot00456a49. 00411790 appends all25 type5 bodies, then one type2 orbit object per authored(parent,orbitRadius) group, then one type1 object containing1000 points, then112 type4 sprite objects. All these constructors set object+0x60=1. 00455810 walks512 slots ascending and skips inactive entries, without depth sorting.

Consequently bodies/globes including sun halo submit first, each orbit ribbon submits next, then point stars submit in128-point batches. The remaining point batch is flushed by00428570 AFTER panel overlay0041fb80. Do not simplify this source order into a claim that all stars were drawn in one first pass. All primitives retain their supplied depth and active device state. Type4 objects submit nothing. The optional texture-debug grid in00428570 is gated by0059c1f8 (initial0), so it is not the normal backdrop.

## Orbit membership, state and visibility

00411b8e constructs each orbit using00456bf0: type2,100 world vertices,100 segment records, final segment closes99→0. Init fields: translation/rotation/screen offsets0, scale1, active1. 00412230 updates EVERY group: parent centre is body[max(parent,0)].position; local vertex array itself receives parent-centred world XZ circle positions. Scene translation remains0. Reuse camera packet's float32 step/trig-table construction; no extra parent translation should be added at render time.

State at object+0x18 is recomputed each update, but is NOT a comparison with current camera-selected index005f13b0. It uses005f13ac (startup/progression body state). Iterate member indices in stored order: start state0; first member equal to005f13ac→state2 and stop; first member greater than005f13ac→state1 and stop; if all members smaller→state0. Do not replace this with 'selected orbit cyan, others red'. Panel/arrow handlers update005f13b0;005f13ac has separate setters/progression consumers (scoped-xrefs.txt/progression.asm). Its complete campaign progression semantics are outside this packet. Fresh Mission1 initialization sets005f13ac to body24 and copies it into005f13b0; all lower-index groups get state0, Mission1's group state2.

There is NO selected-only orbit visibility gate. All active orbit groups reach type2 dispatch00456164. Each segment emits triangles only if BOTH endpoints have projected Z>0; projection produces actual Z only when camera-space Z>10, else marker-1. No geometric near-plane intersection is generated; crossing segments are omitted. No CPU screen-rectangle cull is applied to ribbons, leaving viewport clipping to the device. Far points fade to black by vertex diffuse but still submit.

## Orbit mesh, width, UV, colour, depth

Source00456164–00456637; indexed submission00428780. Project each circle point with the exact existing camera basis, focal400 and centre320,240. For point i let screen position P_i and depth Z_i; cyclic neighbors prev/next. Screen normal n=(P_next.y-P_prev.y, -(P_next.x-P_prev.x)). Approximate norm L=max(abs(n.x),abs(n.y))+.5*min(abs(n.x),abs(n.y)). Let s=400/Z_i (0 only for exact zero depth); offset=n*s/L, or(0,0) if L==0. Pair vertices are P_i-offset and P_i+offset. Thus width is depth-dependent, roughly2*(400/Z), not a constant1px SVG stroke, and the normalization is deliberately not sqrt. Loop emits i=0..100 inclusive, duplicating point0 at the seam:202 vertices. Triangle indices for each valid i<100: (2i,2i+2,2i+1),(2i+2,2i+3,2i+1), max600 indices.

Every pair has z=Z_i/16384, rhw=2, specular0, diffuse ARGB ffgggggg where g=255-floor(clamp(x87_FISTP(Z_i),0,1999)*256/2000). FISTP uses current x87 rounding mode; do not silently substitute floor(Z) or JavaScript trunc. Treat normal/FISTP behavior adjacent to invalid-Z stale projected coordinates as a legacy clipping edge, not evidence for a clean near-plane tessellator.

Texture ring.png is bound by00456616 reading0065ad90, the handle+0x40 of object0065ad50. Setup004288f3–00428917 loads the literal data\\d3d\\ring.png into that object via004b5f40, zero downsample shifts, alpha-capable format ui+0x1da8. Actual source64×64 RGBA8, SHA2566814e461c75a21d904132087a37eea8045d5d9d69a09f230e0b0ae6b1340245c; asset metadata retains RGBA hash and representative column. It is not plsspace.spr or mission-palette art.

u=.30000001192092896 for every vertex. Base v is state0=.0078125, state1=.2578125, state2/default=.5078125. For s>1, minus-offset vertex v=base+.0625 and plus-offset vertex v=base+.171875. For s<=1 BOTH v values become the mean base+.1171875. These select three horizontal bands: red, blue, pale cyan respectively. Texture RGB and alpha vary across the band; preserve the source image rather than invent solid RGB lines. For state0 the two v coordinates correspond4.5/64 and11.5/64; state1 adds16/64, state2 adds32/64. Last16 rows transparent/unused here.

Before submission set state3=1(texture wrap),27=1(alpha blend),1=ring handle. Previous ordinary globe path supplies cull-none/linear filtering and prior globe epilogue sets source-alpha/inverse-source-alpha. Scene setup enables depth test/write. Orbit leaf does not disable depth writes. Submission is indexed triangle list(type4), TL vertex type3, flags8. Pixel sampling, texture-stage interpolation and device-specific precision remain historical raster boundaries.

## Actual star field: points, not sprites

00411e84 calls00456cc0(1000). This creates type1, stores1000 vec3s and a separate byte per point initialized0x72. That byte array is NOT used by the active type1 draw; do not translate0x72 through the palette for star colour.

Each XYZ is generated sequentially from the shared32-bit random state0089bc72:
  state=ror32((state*9377+9439) mod2^32,13)
  coordinate=float32((unsigned(state)%10000)-5000)
All three coordinates independently lie[-5000,4999], with no radius rejection or spherical normalization for this point field. Constructor translation/rotations/screen offsets0, scale1, active1. It is a fixed world-space cube with camera parallax, not a camera-locked texture. State is process-global (initial file/zero-fill0) and earlier consumers may advance it; historical first-use seed is unproved. A deterministic chosen seed is an explicit modern fixture/compatibility choice.

Type1 dispatch00455f46 projects with the same camera/focal. Require Z>10; screen x/y must lie inclusively in[0,639]×[0,479]. Let q=clamp((x87_FISTP(Z)>>6)-83,0,63), g=2*(63-q). Output diffuse=0xffgggggg (brightness0..126), specular0, u=v=0, TL z=.5,rhw=2. Note world Z controls intensity, but submitted depth is fixed. No sprite size, twinkle, per-star animation or palette lookup occurs in this branch.

004286e0 appends32-byte TL vertices to00679348.00428700 flushes exactly at128, unbinds texture with renderstate1=0, then DrawPrimitive POINTLIST(type1), TL vertex type3, flags8. It resets count.00428570 flushes the tail the same way and resets count before EndScene. Neither point flush explicitly turns depth testing/writes off; do not force all points to overlay bodies. At reference640×480 these are device point primitives; a browser representation should document its resolution/high-DPI point-size adaptation.

## plsspace.spr: loaded/positioned but no active raster

Verified filename literal00599b08, setup00411ea0–00411ec0 loads descriptor005f13cc, frame pointer005f13d8. Fourteen PSFB frames are inventoried in assets.json. Source art inspection (space-contact-sheet.png using explicitly illustrative Mission1 palette, NOT a game frame):0/1 round star-cluster glows94×92,2 irregular nebula110×153,3..5 glow patches64×62,6..8 small stars17×18,9..13 tiny stars8×8. Descriptive meanings are visual classifications, not recovered names.

12 type4 objects cycle frames0..5 twice. Their coordinates each use same RNG modulo1000000 minus500000, rejecting vector length<100000. Then100 type4 objects select frames6+(random&7); coordinates modulo100000 minus50000, rejecting length<1000. No spherical normalization.00456e70 stores XYZ and a pointer to the chosen8-byte sprite descriptor, initializes identity transform and active1.

Jump table maps type4 to0045663f. It projects the world centre using the common camera, subtracts floor(spriteWidth/2),floor(spriteHeight/2), checks Z>0 and rectangle overlap. Crucially the last comparison004567e9–004567f8 is followed by E9 4B 02 00 00 at004567f9: an unconditional jump to00456a49, the next-slot loop. There are no calls, batch writes, callback dispatches or draw-list insertions anywhere in this type4 branch. No sprite pixels or palette are consumed there. Type3 likewise routes directly to next slot. Therefore drawing nebula sprites would add a layer absent from this traced D3D dispatcher, despite the resources and positions existing.

PSFB skip-vs-literal transparency can be decoded as prior panel report describes, but no ACTIVE native sprite palette/transparency binding exists in this branch because it never rasterizes. Contact-sheet colours are illustrative only; do not promote selected palette or a guessed colour key into original visible behavior. This finite negative result says nothing universal about another EXE/software renderer.

## Scope/acceptance and remaining boundaries

Next live-scene work can combine the accepted globe mesh, complete per-body textures, camera/orbits, sun, source ring texture, black clear and point stars. Tests should cover all-group dispatch vs selection, ac/b0 independence, band UV thresholds, depth fade/width,202-vertex seam and conditional indices, near-plane segment drop, source PNG hashes, exact RNG transition, star projection/brightness/batch boundaries, and inactive type3/type4 routes. Keep original panel/progression ownership unchanged. Durable integration belongs in a writer-owned later change, not PR464.

Open finite boundaries: campaign meaning/writes of005f13ac beyond the exact numeric rule; historical shared RNG state; current x87 control-word rounding at FISTP if bit-exact depth thresholds are required; device-specific PNG conversion/filter/blend/point and near-plane edge pixels. plsbackg remains loaded without a proved consumer, not proven globally unused. No intercepted probe or original screenshot exists in this packet. Source-bound reconstruction can proceed without claiming those dimensions.

## Reproduction

Retained input-sha256.txt/tool.txt, assets.json/inspect_assets.py, and raw objdump files. New ranges:455f13–4567fe dispatch;4286e0–428760 point submission;428760–4288b0 ribbon submission;4128c0–412a00 state setter/lookup;5206c0–520850 viewport clear;522100–522280 background material;52120e–521310 material creation;521ef0–522100 viewport binding. Prior retained ranges copied verbatim for portable review. inspect_assets.py reuses ONLY existing sprite/png function definitions, never importer main; it reads PE sections/literals and source images. All new generation commands exited0. No heavy checks performed; not applicable to static-only claim. SHA256 list retained for report/raw artifacts.
