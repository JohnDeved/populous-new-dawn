from pathlib import Path
import struct,hashlib,json,ast,zlib
from PIL import Image,ImageDraw
root=Path('/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app');exe=(root/'D3DPopTB.exe').read_bytes()
pe=struct.unpack_from('<I',exe,0x3c)[0]; n=struct.unpack_from('<H',exe,pe+6)[0];sz=struct.unpack_from('<H',exe,pe+20)[0];base=struct.unpack_from('<I',exe,pe+24+28)[0];sec=[]
for i in range(n):
 o=pe+24+sz+i*40;vsz,va,raw,off=struct.unpack_from('<4I',exe,o+8);sec.append((base+va,vsz,raw,off))
def read(a,n):
 for va,vs,rs,off in sec:
  if va<=a<va+max(vs,rs):return (exe[off+a-va:off+min(a-va+n,rs)]+b'\0'*n)[:n]
 raise ValueError(hex(a))
meta={'constants':{hex(a):struct.unpack('<f',read(a,4))[0] for a in [0x58f404,0x58f408,0x58f3a8,0x58f370]},'strings':{hex(a):read(a,70).split(b'\0')[0].decode() for a in [0x599b08,0x59c3b4]},'dispatch':[hex(x) for x in struct.unpack('<5I',read(0x456a74,20))],'file_initials':{hex(a):read(a,4).hex() for a in [0x59c1f8,0x89bc72]}}
source=ast.parse(Path('/tmp/populous-raid447-fallback-0229/scripts/import-original.py').read_text());ns={'struct':struct,'zlib':zlib};exec(compile(ast.Module(body=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in ['sprites','png']],type_ignores=[]),'<existing decoder>','exec'),ns)
spr=(root/'data/plsspace.spr').read_bytes();pal=(root/'data/plspl0-c.dat').read_bytes();frames=ns['sprites'](spr,pal)
meta['space_sprite']={'sha256':hashlib.sha256(spr).hexdigest(),'illustrative_palette':'plspl0-c.dat; no active raster palette proved','frames':[{'index':i,'width':w,'height':h,'opaque':sum(p[j]>0 for j in range(3,len(p),4))} for i,(w,h,p) in enumerate(frames)]}
sheet=Image.new('RGBA',(700,900),(30,30,30,255));draw=ImageDraw.Draw(sheet)
for i,(w,h,p) in enumerate(frames):
 im=Image.frombytes('RGBA',(w,h),p);im.thumbnail((160,180));x=(i%4)*175;y=(i//4)*225;sheet.alpha_composite(im,(x,y+25));draw.text((x,y),str((i,w,h)),fill='white')
sheet.save('/tmp/selector-backdrop/space-contact-sheet.png')
p=root/'data/d3d/ring.png'; im=Image.open(p).convert('RGBA');meta['ring']={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'width':im.width,'height':im.height,'rgba_sha256':hashlib.sha256(im.tobytes()).hexdigest(),'column19_rgba':[im.getpixel((19,y)) for y in range(im.height)]}
Path('/tmp/selector-backdrop/assets.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:v for k,v in meta.items() if k!='ring'},indent=2))
