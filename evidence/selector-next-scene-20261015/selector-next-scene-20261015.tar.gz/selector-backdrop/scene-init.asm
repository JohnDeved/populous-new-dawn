
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00455180 <.text+0x54180>:
  455180:	83 ec 04             	sub    esp,0x4
  455183:	b8 00 40 1c 45       	mov    eax,0x451c4000
  455188:	a3 58 95 73 00       	mov    ds:0x739558,eax
  45518d:	56                   	push   esi
  45518e:	c7 05 5c 95 73 00 00 	mov    DWORD PTR ds:0x73955c,0xc3480000
  455195:	00 48 c3 
  455198:	33 f6                	xor    esi,esi
  45519a:	89 35 48 95 73 00    	mov    DWORD PTR ds:0x739548,esi
  4551a0:	89 35 4c 95 73 00    	mov    DWORD PTR ds:0x73954c,esi
  4551a6:	b9 00 00 80 3f       	mov    ecx,0x3f800000
  4551ab:	89 35 50 95 73 00    	mov    DWORD PTR ds:0x739550,esi
  4551b1:	89 35 54 95 73 00    	mov    DWORD PTR ds:0x739554,esi
  4551b7:	89 35 60 95 73 00    	mov    DWORD PTR ds:0x739560,esi
  4551bd:	89 35 64 95 73 00    	mov    DWORD PTR ds:0x739564,esi
  4551c3:	89 0d 68 95 73 00    	mov    DWORD PTR ds:0x739568,ecx
  4551c9:	89 35 6c 95 73 00    	mov    DWORD PTR ds:0x73956c,esi
  4551cf:	89 0d 70 95 73 00    	mov    DWORD PTR ds:0x739570,ecx
  4551d5:	89 35 74 95 73 00    	mov    DWORD PTR ds:0x739574,esi
  4551db:	89 0d 78 95 73 00    	mov    DWORD PTR ds:0x739578,ecx
  4551e1:	89 35 7c 95 73 00    	mov    DWORD PTR ds:0x73957c,esi
  4551e7:	89 35 80 95 73 00    	mov    DWORD PTR ds:0x739580,esi
  4551ed:	b9 98 95 73 00       	mov    ecx,0x739598
  4551f2:	89 35 98 95 73 00    	mov    DWORD PTR ds:0x739598,esi
  4551f8:	ba 8c 95 73 00       	mov    edx,0x73958c
  4551fd:	a3 9c 95 73 00       	mov    ds:0x73959c,eax
  455202:	c7 05 84 95 73 00 00 	mov    DWORD PTR ds:0x739584,0x43c80000
  455209:	00 c8 43 
  45520c:	c7 05 a0 95 73 00 00 	mov    DWORD PTR ds:0x7395a0,0x43480000
  455213:	00 48 43 
  455216:	8b 01                	mov    eax,DWORD PTR [ecx]
  455218:	89 35 c0 95 73 00    	mov    DWORD PTR ds:0x7395c0,esi
  45521e:	89 02                	mov    DWORD PTR [edx],eax
  455220:	89 35 c4 95 73 00    	mov    DWORD PTR ds:0x7395c4,esi
  455226:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
  455229:	89 35 c8 95 73 00    	mov    DWORD PTR ds:0x7395c8,esi
  45522f:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  455232:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  455235:	89 4a 08             	mov    DWORD PTR [edx+0x8],ecx
  455238:	a1 c0 95 73 00       	mov    eax,ds:0x7395c0
  45523d:	a3 b4 95 73 00       	mov    ds:0x7395b4,eax
  455242:	b9 c0 95 73 00       	mov    ecx,0x7395c0
  455247:	ba b4 95 73 00       	mov    edx,0x7395b4
  45524c:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
  45524f:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  455252:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  455255:	89 4a 08             	mov    DWORD PTR [edx+0x8],ecx
  455258:	e8 b3 03 00 00       	call   0x455610
  45525d:	39 35 78 cf 59 00    	cmp    DWORD PTR ds:0x59cf78,esi
  455263:	74 68                	je     0x4552cd
  455265:	b9 48 cd 72 00       	mov    ecx,0x72cd48
  45526a:	b8 00 02 00 00       	mov    eax,0x200
  45526f:	89 35 78 cf 59 00    	mov    DWORD PTR ds:0x59cf78,esi
  455275:	89 71 60             	mov    DWORD PTR [ecx+0x60],esi
  455278:	83 c1 64             	add    ecx,0x64
  45527b:	48                   	dec    eax
  45527c:	75 f7                	jne    0x455275
  45527e:	68 48 cd 72 00       	push   0x72cd48
  455283:	e8 68 1c 00 00       	call   0x456ef0
  455288:	c7 05 a8 cd 72 00 01 	mov    DWORD PTR ds:0x72cda8,0x1
  45528f:	00 00 00 
  455292:	83 c4 04             	add    esp,0x4
  455295:	e8 66 df 04 00       	call   0x4a3200
  45529a:	e8 81 ea 04 00       	call   0x4a3d20
  45529f:	68 90 cf 59 00       	push   0x59cf90
  4552a4:	68 23 cd 89 00       	push   0x89cd23
  4552a9:	e8 02 af 0a 00       	call   0x5001b0
  4552ae:	8d 44 24 0c          	lea    eax,[esp+0xc]
  4552b2:	83 c4 08             	add    esp,0x8
  4552b5:	50                   	push   eax
  4552b6:	68 00 20 00 00       	push   0x2000
  4552bb:	68 40 9d 6a 00       	push   0x6a9d40
  4552c0:	68 23 cd 89 00       	push   0x89cd23
  4552c5:	e8 b6 0c 0d 00       	call   0x525f80
  4552ca:	83 c4 10             	add    esp,0x10
  4552cd:	b9 d8 95 73 00       	mov    ecx,0x7395d8
  4552d2:	e8 f9 7c fd ff       	call   0x42cfd0
  4552d7:	dd 05 90 f3 58 00    	fld    QWORD PTR ds:0x58f390
  4552dd:	d9 fa                	fsqrt
  4552df:	c7 05 e0 96 73 00 02 	mov    DWORD PTR ds:0x7396e0,0x2
  4552e6:	00 00 00 
  4552e9:	c7 05 f0 96 73 00 cd 	mov    DWORD PTR ds:0x7396f0,0x3e4ccccd
  4552f0:	cc 4c 3e 
  4552f3:	c7 05 f4 96 73 00 33 	mov    DWORD PTR ds:0x7396f4,0xbf733333
  4552fa:	33 73 bf 
  4552fd:	5e                   	pop    esi
  4552fe:	83 c4 04             	add    esp,0x4
  455301:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  455307:	d9 15 e4 96 73 00    	fst    DWORD PTR ds:0x7396e4
  45530d:	d9 c0                	fld    st(0)
  45530f:	d9 e0                	fchs
  455311:	d9 1d e8 96 73 00    	fstp   DWORD PTR ds:0x7396e8
  455317:	d9 1d ec 96 73 00    	fstp   DWORD PTR ds:0x7396ec
  45531d:	c3                   	ret
  45531e:	cc                   	int3
  45531f:	cc                   	int3
  455320:	53                   	push   ebx
  455321:	56                   	push   esi
  455322:	57                   	push   edi
  455323:	be 00 02 00 00       	mov    esi,0x200
  455328:	bf 48 cd 72 00       	mov    edi,0x72cd48
  45532d:	33 db                	xor    ebx,ebx
  45532f:	39 5f 60             	cmp    DWORD PTR [edi+0x60],ebx
  455332:	0f 84 c5 00 00 00    	je     0x4553fd
  455338:	8b 07                	mov    eax,DWORD PTR [edi]
  45533a:	83 f8 01             	cmp    eax,0x1
  45533d:	74 0f                	je     0x45534e
  45533f:	83 f8 02             	cmp    eax,0x2
  455342:	74 45                	je     0x455389
  455344:	83 f8 03             	cmp    eax,0x3
  455347:	74 69                	je     0x4553b2
  455349:	e9 af 00 00 00       	jmp    0x4553fd
  45534e:	8b 47 08             	mov    eax,DWORD PTR [edi+0x8]
  455351:	85 c0                	test   eax,eax
  455353:	74 09                	je     0x45535e
  455355:	50                   	push   eax
  455356:	e8 f5 12 0d 00       	call   0x526650
  45535b:	83 c4 04             	add    esp,0x4
  45535e:	8b 47 0c             	mov    eax,DWORD PTR [edi+0xc]
  455361:	85 c0                	test   eax,eax
  455363:	74 09                	je     0x45536e
  455365:	50                   	push   eax
  455366:	e8 e5 12 0d 00       	call   0x526650
  45536b:	83 c4 04             	add    esp,0x4
  45536e:	8b 47 10             	mov    eax,DWORD PTR [edi+0x10]
  455371:	85 c0                	test   eax,eax
  455373:	74 09                	je     0x45537e
  455375:	50                   	push   eax
  455376:	e8 d5 12 0d 00       	call   0x526650
  45537b:	83 c4 04             	add    esp,0x4
  45537e:	89 5f 08             	mov    DWORD PTR [edi+0x8],ebx
  455381:	89 5f 0c             	mov    DWORD PTR [edi+0xc],ebx
  455384:	89 5f 10             	mov    DWORD PTR [edi+0x10],ebx
  455387:	eb 74                	jmp    0x4553fd
  455389:	8b 47 08             	mov    eax,DWORD PTR [edi+0x8]
  45538c:	85 c0                	test   eax,eax
  45538e:	74 09                	je     0x455399
  455390:	50                   	push   eax
  455391:	e8 ba 12 0d 00       	call   0x526650
  455396:	83 c4 04             	add    esp,0x4
  455399:	8b 47 0c             	mov    eax,DWORD PTR [edi+0xc]
  45539c:	85 c0                	test   eax,eax
  45539e:	74 09                	je     0x4553a9
  4553a0:	50                   	push   eax
  4553a1:	e8 aa 12 0d 00       	call   0x526650
  4553a6:	83 c4 04             	add    esp,0x4
  4553a9:	8b 47 14             	mov    eax,DWORD PTR [edi+0x14]
  4553ac:	85 c0                	test   eax,eax
  4553ae:	74 44                	je     0x4553f4
  4553b0:	eb 39                	jmp    0x4553eb
  4553b2:	f6 47 20 01          	test   BYTE PTR [edi+0x20],0x1
  4553b6:	74 10                	je     0x4553c8
  4553b8:	8b 47 08             	mov    eax,DWORD PTR [edi+0x8]
  4553bb:	85 c0                	test   eax,eax
  4553bd:	74 09                	je     0x4553c8
  4553bf:	50                   	push   eax
  4553c0:	e8 8b 12 0d 00       	call   0x526650
  4553c5:	83 c4 04             	add    esp,0x4
  4553c8:	f6 47 20 02          	test   BYTE PTR [edi+0x20],0x2
  4553cc:	74 10                	je     0x4553de
  4553ce:	8b 47 0c             	mov    eax,DWORD PTR [edi+0xc]
  4553d1:	85 c0                	test   eax,eax
  4553d3:	74 09                	je     0x4553de
  4553d5:	50                   	push   eax
  4553d6:	e8 75 12 0d 00       	call   0x526650
  4553db:	83 c4 04             	add    esp,0x4
  4553de:	f6 47 20 04          	test   BYTE PTR [edi+0x20],0x4
  4553e2:	74 10                	je     0x4553f4
  4553e4:	8b 47 14             	mov    eax,DWORD PTR [edi+0x14]
  4553e7:	85 c0                	test   eax,eax
  4553e9:	74 09                	je     0x4553f4
  4553eb:	50                   	push   eax
  4553ec:	e8 5f 12 0d 00       	call   0x526650
  4553f1:	83 c4 04             	add    esp,0x4
  4553f4:	89 5f 08             	mov    DWORD PTR [edi+0x8],ebx
  4553f7:	89 5f 0c             	mov    DWORD PTR [edi+0xc],ebx
  4553fa:	89 5f 14             	mov    DWORD PTR [edi+0x14],ebx
  4553fd:	83 c7 64             	add    edi,0x64
  455400:	4e                   	dec    esi
  455401:	0f 85 28 ff ff ff    	jne    0x45532f
  455407:	5f                   	pop    edi
  455408:	5e                   	pop    esi
  455409:	5b                   	pop    ebx
  45540a:	c3                   	ret
  45540b:	cc                   	int3
  45540c:	cc                   	int3
  45540d:	cc                   	int3
  45540e:	cc                   	int3
  45540f:	cc                   	int3
