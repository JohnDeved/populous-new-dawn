
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00456a80 <.text+0x55a80>:
  456a80:	3f                   	aas
  456a81:	66 45                	inc    bp
  456a83:	00 fe                	add    dh,bh
  456a85:	67 45                	addr16 inc ebp
  456a87:	00 cc                	add    ah,cl
  456a89:	cc                   	int3
  456a8a:	cc                   	int3
  456a8b:	cc                   	int3
  456a8c:	cc                   	int3
  456a8d:	cc                   	int3
  456a8e:	cc                   	int3
  456a8f:	cc                   	int3
  456a90:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
  456a94:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  456a98:	d9 40 04             	fld    DWORD PTR [eax+0x4]
  456a9b:	d8 49 0c             	fmul   DWORD PTR [ecx+0xc]
  456a9e:	d9 40 08             	fld    DWORD PTR [eax+0x8]
  456aa1:	d8 49 18             	fmul   DWORD PTR [ecx+0x18]
  456aa4:	8b 54 24 0c          	mov    edx,DWORD PTR [esp+0xc]
  456aa8:	de c1                	faddp  st(1),st
  456aaa:	d9 01                	fld    DWORD PTR [ecx]
  456aac:	d8 08                	fmul   DWORD PTR [eax]
  456aae:	de c1                	faddp  st(1),st
  456ab0:	d9 1a                	fstp   DWORD PTR [edx]
  456ab2:	d9 40 08             	fld    DWORD PTR [eax+0x8]
  456ab5:	d8 49 1c             	fmul   DWORD PTR [ecx+0x1c]
  456ab8:	d9 40 04             	fld    DWORD PTR [eax+0x4]
  456abb:	d8 49 10             	fmul   DWORD PTR [ecx+0x10]
  456abe:	de c1                	faddp  st(1),st
  456ac0:	d9 41 04             	fld    DWORD PTR [ecx+0x4]
  456ac3:	d8 08                	fmul   DWORD PTR [eax]
  456ac5:	de c1                	faddp  st(1),st
  456ac7:	d9 5a 04             	fstp   DWORD PTR [edx+0x4]
  456aca:	d9 40 04             	fld    DWORD PTR [eax+0x4]
  456acd:	d8 49 14             	fmul   DWORD PTR [ecx+0x14]
  456ad0:	d9 40 08             	fld    DWORD PTR [eax+0x8]
  456ad3:	d8 49 20             	fmul   DWORD PTR [ecx+0x20]
  456ad6:	de c1                	faddp  st(1),st
  456ad8:	d9 41 08             	fld    DWORD PTR [ecx+0x8]
  456adb:	d8 08                	fmul   DWORD PTR [eax]
  456add:	de c1                	faddp  st(1),st
  456adf:	d9 5a 08             	fstp   DWORD PTR [edx+0x8]
  456ae2:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  456ae5:	d8 49 18             	fmul   DWORD PTR [ecx+0x18]
  456ae8:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  456aeb:	d8 49 0c             	fmul   DWORD PTR [ecx+0xc]
  456aee:	de c1                	faddp  st(1),st
  456af0:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  456af3:	d8 09                	fmul   DWORD PTR [ecx]
  456af5:	de c1                	faddp  st(1),st
  456af7:	d9 5a 0c             	fstp   DWORD PTR [edx+0xc]
  456afa:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  456afd:	d8 49 04             	fmul   DWORD PTR [ecx+0x4]
  456b00:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  456b03:	d8 49 1c             	fmul   DWORD PTR [ecx+0x1c]
  456b06:	de c1                	faddp  st(1),st
  456b08:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  456b0b:	d8 49 10             	fmul   DWORD PTR [ecx+0x10]
  456b0e:	de c1                	faddp  st(1),st
  456b10:	d9 5a 10             	fstp   DWORD PTR [edx+0x10]
  456b13:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  456b16:	d8 49 20             	fmul   DWORD PTR [ecx+0x20]
  456b19:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  456b1c:	d8 49 14             	fmul   DWORD PTR [ecx+0x14]
  456b1f:	de c1                	faddp  st(1),st
  456b21:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  456b24:	d8 49 08             	fmul   DWORD PTR [ecx+0x8]
  456b27:	de c1                	faddp  st(1),st
  456b29:	d9 5a 14             	fstp   DWORD PTR [edx+0x14]
  456b2c:	d9 40 20             	fld    DWORD PTR [eax+0x20]
  456b2f:	d8 49 18             	fmul   DWORD PTR [ecx+0x18]
  456b32:	d9 40 1c             	fld    DWORD PTR [eax+0x1c]
  456b35:	d8 49 0c             	fmul   DWORD PTR [ecx+0xc]
  456b38:	de c1                	faddp  st(1),st
  456b3a:	d9 40 18             	fld    DWORD PTR [eax+0x18]
  456b3d:	d8 09                	fmul   DWORD PTR [ecx]
  456b3f:	de c1                	faddp  st(1),st
  456b41:	d9 5a 18             	fstp   DWORD PTR [edx+0x18]
  456b44:	d9 40 18             	fld    DWORD PTR [eax+0x18]
  456b47:	d8 49 04             	fmul   DWORD PTR [ecx+0x4]
  456b4a:	d9 40 20             	fld    DWORD PTR [eax+0x20]
  456b4d:	d8 49 1c             	fmul   DWORD PTR [ecx+0x1c]
  456b50:	de c1                	faddp  st(1),st
  456b52:	d9 40 1c             	fld    DWORD PTR [eax+0x1c]
  456b55:	d8 49 10             	fmul   DWORD PTR [ecx+0x10]
  456b58:	de c1                	faddp  st(1),st
  456b5a:	d9 5a 1c             	fstp   DWORD PTR [edx+0x1c]
  456b5d:	d9 40 1c             	fld    DWORD PTR [eax+0x1c]
  456b60:	d8 49 14             	fmul   DWORD PTR [ecx+0x14]
  456b63:	d9 40 18             	fld    DWORD PTR [eax+0x18]
  456b66:	d8 49 08             	fmul   DWORD PTR [ecx+0x8]
  456b69:	de c1                	faddp  st(1),st
  456b6b:	d9 40 20             	fld    DWORD PTR [eax+0x20]
  456b6e:	d8 49 20             	fmul   DWORD PTR [ecx+0x20]
  456b71:	de c1                	faddp  st(1),st
  456b73:	d9 5a 20             	fstp   DWORD PTR [edx+0x20]
  456b76:	c3                   	ret
  456b77:	cc                   	int3
  456b78:	cc                   	int3
  456b79:	cc                   	int3
  456b7a:	cc                   	int3
  456b7b:	cc                   	int3
  456b7c:	cc                   	int3
  456b7d:	cc                   	int3
  456b7e:	cc                   	int3
  456b7f:	cc                   	int3
  456b80:	a1 74 cf 59 00       	mov    eax,ds:0x59cf74
  456b85:	c1 e0 02             	shl    eax,0x2
  456b88:	ff 05 74 cf 59 00    	inc    DWORD PTR ds:0x59cf74
  456b8e:	8d 0c 80             	lea    ecx,[eax+eax*4]
  456b91:	8d 84 89 48 cd 72 00 	lea    eax,[ecx+ecx*4+0x72cd48]
  456b98:	c7 00 05 00 00 00    	mov    DWORD PTR [eax],0x5
  456b9e:	8b 0d 74 cf 59 00    	mov    ecx,DWORD PTR ds:0x59cf74
  456ba4:	83 e9 02             	sub    ecx,0x2
  456ba7:	89 48 04             	mov    DWORD PTR [eax+0x4],ecx
  456baa:	33 c9                	xor    ecx,ecx
  456bac:	89 48 08             	mov    DWORD PTR [eax+0x8],ecx
  456baf:	89 48 0c             	mov    DWORD PTR [eax+0xc],ecx
  456bb2:	89 48 24             	mov    DWORD PTR [eax+0x24],ecx
  456bb5:	89 48 28             	mov    DWORD PTR [eax+0x28],ecx
  456bb8:	89 48 2c             	mov    DWORD PTR [eax+0x2c],ecx
  456bbb:	89 48 3c             	mov    DWORD PTR [eax+0x3c],ecx
  456bbe:	89 48 40             	mov    DWORD PTR [eax+0x40],ecx
  456bc1:	8b 54 24 04          	mov    edx,DWORD PTR [esp+0x4]
  456bc5:	c7 40 44 00 00 b4 42 	mov    DWORD PTR [eax+0x44],0x42b40000
  456bcc:	89 48 48             	mov    DWORD PTR [eax+0x48],ecx
  456bcf:	89 48 4c             	mov    DWORD PTR [eax+0x4c],ecx
  456bd2:	89 48 50             	mov    DWORD PTR [eax+0x50],ecx
  456bd5:	c7 40 54 00 00 c0 3f 	mov    DWORD PTR [eax+0x54],0x3fc00000
  456bdc:	89 48 58             	mov    DWORD PTR [eax+0x58],ecx
  456bdf:	89 50 5c             	mov    DWORD PTR [eax+0x5c],edx
  456be2:	c7 40 60 01 00 00 00 	mov    DWORD PTR [eax+0x60],0x1
  456be9:	c3                   	ret
  456bea:	cc                   	int3
  456beb:	cc                   	int3
  456bec:	cc                   	int3
  456bed:	cc                   	int3
  456bee:	cc                   	int3
  456bef:	cc                   	int3
  456bf0:	56                   	push   esi
  456bf1:	a1 74 cf 59 00       	mov    eax,ds:0x59cf74
  456bf6:	c1 e0 02             	shl    eax,0x2
  456bf9:	68 b0 04 00 00       	push   0x4b0
  456bfe:	ff 05 74 cf 59 00    	inc    DWORD PTR ds:0x59cf74
  456c04:	8d 0c 80             	lea    ecx,[eax+eax*4]
  456c07:	8d b4 89 48 cd 72 00 	lea    esi,[ecx+ecx*4+0x72cd48]
  456c0e:	c7 06 02 00 00 00    	mov    DWORD PTR [esi],0x2
  456c14:	c7 46 04 64 00 00 00 	mov    DWORD PTR [esi+0x4],0x64
  456c1b:	e8 10 fa 0c 00       	call   0x526630
  456c20:	83 c4 04             	add    esp,0x4
  456c23:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  456c26:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
  456c29:	8d 04 49             	lea    eax,[ecx+ecx*2]
  456c2c:	c1 e0 02             	shl    eax,0x2
  456c2f:	50                   	push   eax
  456c30:	e8 fb f9 0c 00       	call   0x526630
  456c35:	83 c4 04             	add    esp,0x4
  456c38:	89 46 0c             	mov    DWORD PTR [esi+0xc],eax
  456c3b:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
  456c3e:	89 46 10             	mov    DWORD PTR [esi+0x10],eax
  456c41:	c1 e0 02             	shl    eax,0x2
  456c44:	50                   	push   eax
  456c45:	e8 e6 f9 0c 00       	call   0x526630
  456c4a:	83 c4 04             	add    esp,0x4
  456c4d:	33 d2                	xor    edx,edx
  456c4f:	89 46 14             	mov    DWORD PTR [esi+0x14],eax
  456c52:	39 56 10             	cmp    DWORD PTR [esi+0x10],edx
  456c55:	7e 18                	jle    0x456c6f
  456c57:	8b 46 14             	mov    eax,DWORD PTR [esi+0x14]
  456c5a:	66 89 14 90          	mov    WORD PTR [eax+edx*4],dx
  456c5e:	8d 42 01             	lea    eax,[edx+0x1]
  456c61:	8b 4e 14             	mov    ecx,DWORD PTR [esi+0x14]
  456c64:	42                   	inc    edx
  456c65:	66 89 44 91 fe       	mov    WORD PTR [ecx+edx*4-0x2],ax
  456c6a:	39 56 10             	cmp    DWORD PTR [esi+0x10],edx
  456c6d:	7f e8                	jg     0x456c57
  456c6f:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  456c72:	8b 56 14             	mov    edx,DWORD PTR [esi+0x14]
  456c75:	33 c0                	xor    eax,eax
  456c77:	66 89 44 8a fe       	mov    WORD PTR [edx+ecx*4-0x2],ax
  456c7c:	89 46 18             	mov    DWORD PTR [esi+0x18],eax
  456c7f:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  456c82:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  456c85:	89 46 2c             	mov    DWORD PTR [esi+0x2c],eax
  456c88:	89 46 3c             	mov    DWORD PTR [esi+0x3c],eax
  456c8b:	89 46 40             	mov    DWORD PTR [esi+0x40],eax
  456c8e:	89 46 44             	mov    DWORD PTR [esi+0x44],eax
  456c91:	89 46 48             	mov    DWORD PTR [esi+0x48],eax
  456c94:	89 46 4c             	mov    DWORD PTR [esi+0x4c],eax
  456c97:	89 46 50             	mov    DWORD PTR [esi+0x50],eax
  456c9a:	89 46 54             	mov    DWORD PTR [esi+0x54],eax
  456c9d:	89 46 58             	mov    DWORD PTR [esi+0x58],eax
  456ca0:	8b c6                	mov    eax,esi
  456ca2:	c7 46 5c 00 00 80 3f 	mov    DWORD PTR [esi+0x5c],0x3f800000
  456ca9:	c7 46 60 01 00 00 00 	mov    DWORD PTR [esi+0x60],0x1
  456cb0:	5e                   	pop    esi
  456cb1:	c3                   	ret
  456cb2:	cc                   	int3
  456cb3:	cc                   	int3
  456cb4:	cc                   	int3
  456cb5:	cc                   	int3
  456cb6:	cc                   	int3
  456cb7:	cc                   	int3
  456cb8:	cc                   	int3
  456cb9:	cc                   	int3
  456cba:	cc                   	int3
  456cbb:	cc                   	int3
  456cbc:	cc                   	int3
  456cbd:	cc                   	int3
  456cbe:	cc                   	int3
  456cbf:	cc                   	int3
  456cc0:	83 ec 18             	sub    esp,0x18
  456cc3:	a1 74 cf 59 00       	mov    eax,ds:0x59cf74
  456cc8:	c1 e0 02             	shl    eax,0x2
  456ccb:	ff 05 74 cf 59 00    	inc    DWORD PTR ds:0x59cf74
  456cd1:	53                   	push   ebx
  456cd2:	56                   	push   esi
  456cd3:	57                   	push   edi
  456cd4:	8d 0c 80             	lea    ecx,[eax+eax*4]
  456cd7:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  456cdb:	8d b4 89 48 cd 72 00 	lea    esi,[ecx+ecx*4+0x72cd48]
  456ce2:	c7 06 01 00 00 00    	mov    DWORD PTR [esi],0x1
  456ce8:	89 46 04             	mov    DWORD PTR [esi+0x4],eax
  456ceb:	8d 04 40             	lea    eax,[eax+eax*2]
  456cee:	c1 e0 02             	shl    eax,0x2
  456cf1:	50                   	push   eax
  456cf2:	e8 39 f9 0c 00       	call   0x526630
  456cf7:	83 c4 04             	add    esp,0x4
  456cfa:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  456cfd:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
  456d00:	51                   	push   ecx
  456d01:	e8 2a f9 0c 00       	call   0x526630
  456d06:	83 c4 04             	add    esp,0x4
  456d09:	89 46 0c             	mov    DWORD PTR [esi+0xc],eax
  456d0c:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
  456d0f:	33 ff                	xor    edi,edi
  456d11:	8d 04 49             	lea    eax,[ecx+ecx*2]
  456d14:	c1 e0 02             	shl    eax,0x2
  456d17:	50                   	push   eax
  456d18:	e8 13 f9 0c 00       	call   0x526630
  456d1d:	83 c4 04             	add    esp,0x4
  456d20:	89 46 10             	mov    DWORD PTR [esi+0x10],eax
  456d23:	39 7e 04             	cmp    DWORD PTR [esi+0x4],edi
  456d26:	0f 8e 09 01 00 00    	jle    0x456e35
  456d2c:	33 c9                	xor    ecx,ecx
  456d2e:	a1 72 bc 89 00       	mov    eax,ds:0x89bc72
  456d33:	8b d0                	mov    edx,eax
  456d35:	8d 1c c0             	lea    ebx,[eax+eax*8]
  456d38:	8d 04 da             	lea    eax,[edx+ebx*8]
  456d3b:	8d 04 82             	lea    eax,[edx+eax*4]
  456d3e:	c1 e0 02             	shl    eax,0x2
  456d41:	8d 04 c2             	lea    eax,[edx+eax*8]
  456d44:	05 df 24 00 00       	add    eax,0x24df
  456d49:	a3 72 bc 89 00       	mov    ds:0x89bc72,eax
  456d4e:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  456d52:	c1 4c 24 14 0d       	ror    DWORD PTR [esp+0x14],0xd
  456d57:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
  456d5b:	bb 10 27 00 00       	mov    ebx,0x2710
  456d60:	2b d2                	sub    edx,edx
  456d62:	a3 72 bc 89 00       	mov    ds:0x89bc72,eax
  456d67:	f7 f3                	div    ebx
  456d69:	81 ea 88 13 00 00    	sub    edx,0x1388
  456d6f:	8b 46 08             	mov    eax,DWORD PTR [esi+0x8]
  456d72:	89 54 24 20          	mov    DWORD PTR [esp+0x20],edx
  456d76:	db 44 24 20          	fild   DWORD PTR [esp+0x20]
  456d7a:	d9 1c 08             	fstp   DWORD PTR [eax+ecx*1]
  456d7d:	a1 72 bc 89 00       	mov    eax,ds:0x89bc72
  456d82:	8b d0                	mov    edx,eax
  456d84:	8d 1c c0             	lea    ebx,[eax+eax*8]
  456d87:	8d 04 da             	lea    eax,[edx+ebx*8]
  456d8a:	8d 04 82             	lea    eax,[edx+eax*4]
  456d8d:	c1 e0 02             	shl    eax,0x2
  456d90:	8d 04 c2             	lea    eax,[edx+eax*8]
  456d93:	05 df 24 00 00       	add    eax,0x24df
  456d98:	a3 72 bc 89 00       	mov    ds:0x89bc72,eax
  456d9d:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  456da1:	c1 4c 24 10 0d       	ror    DWORD PTR [esp+0x10],0xd
  456da6:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  456daa:	bb 10 27 00 00       	mov    ebx,0x2710
  456daf:	2b d2                	sub    edx,edx
  456db1:	a3 72 bc 89 00       	mov    ds:0x89bc72,eax
  456db6:	f7 f3                	div    ebx
  456db8:	81 ea 88 13 00 00    	sub    edx,0x1388
  456dbe:	8b 46 08             	mov    eax,DWORD PTR [esi+0x8]
  456dc1:	89 54 24 1c          	mov    DWORD PTR [esp+0x1c],edx
  456dc5:	db 44 24 1c          	fild   DWORD PTR [esp+0x1c]
  456dc9:	d9 5c 08 04          	fstp   DWORD PTR [eax+ecx*1+0x4]
  456dcd:	8b 15 72 bc 89 00    	mov    edx,DWORD PTR ds:0x89bc72
  456dd3:	8b c2                	mov    eax,edx
  456dd5:	8d 1c d2             	lea    ebx,[edx+edx*8]
  456dd8:	8d 14 d8             	lea    edx,[eax+ebx*8]
  456ddb:	8d 14 90             	lea    edx,[eax+edx*4]
  456dde:	c1 e2 02             	shl    edx,0x2
  456de1:	8d 14 d0             	lea    edx,[eax+edx*8]
  456de4:	81 c2 df 24 00 00    	add    edx,0x24df
  456dea:	89 15 72 bc 89 00    	mov    DWORD PTR ds:0x89bc72,edx
  456df0:	89 54 24 0c          	mov    DWORD PTR [esp+0xc],edx
  456df4:	c1 4c 24 0c 0d       	ror    DWORD PTR [esp+0xc],0xd
  456df9:	8b 44 24 0c          	mov    eax,DWORD PTR [esp+0xc]
  456dfd:	bb 10 27 00 00       	mov    ebx,0x2710
  456e02:	2b d2                	sub    edx,edx
  456e04:	83 c1 0c             	add    ecx,0xc
  456e07:	47                   	inc    edi
  456e08:	a3 72 bc 89 00       	mov    ds:0x89bc72,eax
  456e0d:	f7 f3                	div    ebx
  456e0f:	81 ea 88 13 00 00    	sub    edx,0x1388
  456e15:	8b 46 08             	mov    eax,DWORD PTR [esi+0x8]
  456e18:	89 54 24 18          	mov    DWORD PTR [esp+0x18],edx
  456e1c:	db 44 24 18          	fild   DWORD PTR [esp+0x18]
  456e20:	d9 5c 08 fc          	fstp   DWORD PTR [eax+ecx*1-0x4]
  456e24:	8b 5e 0c             	mov    ebx,DWORD PTR [esi+0xc]
  456e27:	c6 44 3b ff 72       	mov    BYTE PTR [ebx+edi*1-0x1],0x72
  456e2c:	39 7e 04             	cmp    DWORD PTR [esi+0x4],edi
  456e2f:	0f 8f f9 fe ff ff    	jg     0x456d2e
  456e35:	33 c0                	xor    eax,eax
  456e37:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  456e3a:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  456e3d:	89 46 2c             	mov    DWORD PTR [esi+0x2c],eax
  456e40:	89 46 3c             	mov    DWORD PTR [esi+0x3c],eax
  456e43:	89 46 40             	mov    DWORD PTR [esi+0x40],eax
  456e46:	89 46 44             	mov    DWORD PTR [esi+0x44],eax
  456e49:	89 46 48             	mov    DWORD PTR [esi+0x48],eax
  456e4c:	89 46 4c             	mov    DWORD PTR [esi+0x4c],eax
  456e4f:	5f                   	pop    edi
  456e50:	89 46 50             	mov    DWORD PTR [esi+0x50],eax
  456e53:	89 46 54             	mov    DWORD PTR [esi+0x54],eax
  456e56:	89 46 58             	mov    DWORD PTR [esi+0x58],eax
  456e59:	8b c6                	mov    eax,esi
  456e5b:	c7 46 5c 00 00 80 3f 	mov    DWORD PTR [esi+0x5c],0x3f800000
  456e62:	c7 46 60 01 00 00 00 	mov    DWORD PTR [esi+0x60],0x1
  456e69:	5e                   	pop    esi
  456e6a:	5b                   	pop    ebx
  456e6b:	83 c4 18             	add    esp,0x18
  456e6e:	c3                   	ret
  456e6f:	cc                   	int3
  456e70:	56                   	push   esi
  456e71:	a1 74 cf 59 00       	mov    eax,ds:0x59cf74
  456e76:	c1 e0 02             	shl    eax,0x2
  456e79:	8d 54 24 08          	lea    edx,[esp+0x8]
  456e7d:	ff 05 74 cf 59 00    	inc    DWORD PTR ds:0x59cf74
  456e83:	8d 0c 80             	lea    ecx,[eax+eax*4]
  456e86:	8d b4 89 4c cd 72 00 	lea    esi,[ecx+ecx*4+0x72cd4c]
  456e8d:	8d 84 89 48 cd 72 00 	lea    eax,[ecx+ecx*4+0x72cd48]
  456e94:	8b 0a                	mov    ecx,DWORD PTR [edx]
  456e96:	c7 00 04 00 00 00    	mov    DWORD PTR [eax],0x4
  456e9c:	89 0e                	mov    DWORD PTR [esi],ecx
  456e9e:	8b 4a 04             	mov    ecx,DWORD PTR [edx+0x4]
  456ea1:	8b 52 08             	mov    edx,DWORD PTR [edx+0x8]
  456ea4:	89 4e 04             	mov    DWORD PTR [esi+0x4],ecx
  456ea7:	33 c9                	xor    ecx,ecx
  456ea9:	89 56 08             	mov    DWORD PTR [esi+0x8],edx
  456eac:	8b 74 24 14          	mov    esi,DWORD PTR [esp+0x14]
  456eb0:	89 70 1c             	mov    DWORD PTR [eax+0x1c],esi
  456eb3:	89 48 24             	mov    DWORD PTR [eax+0x24],ecx
  456eb6:	89 48 28             	mov    DWORD PTR [eax+0x28],ecx
  456eb9:	89 48 2c             	mov    DWORD PTR [eax+0x2c],ecx
  456ebc:	89 48 3c             	mov    DWORD PTR [eax+0x3c],ecx
  456ebf:	89 48 40             	mov    DWORD PTR [eax+0x40],ecx
  456ec2:	89 48 44             	mov    DWORD PTR [eax+0x44],ecx
  456ec5:	89 48 48             	mov    DWORD PTR [eax+0x48],ecx
  456ec8:	5e                   	pop    esi
  456ec9:	89 48 4c             	mov    DWORD PTR [eax+0x4c],ecx
  456ecc:	89 48 50             	mov    DWORD PTR [eax+0x50],ecx
  456ecf:	89 48 54             	mov    DWORD PTR [eax+0x54],ecx
  456ed2:	89 48 58             	mov    DWORD PTR [eax+0x58],ecx
  456ed5:	c7 40 5c 00 00 80 3f 	mov    DWORD PTR [eax+0x5c],0x3f800000
  456edc:	c7 40 60 01 00 00 00 	mov    DWORD PTR [eax+0x60],0x1
  456ee3:	c3                   	ret
  456ee4:	cc                   	int3
  456ee5:	cc                   	int3
  456ee6:	cc                   	int3
  456ee7:	cc                   	int3
  456ee8:	cc                   	int3
  456ee9:	cc                   	int3
  456eea:	cc                   	int3
  456eeb:	cc                   	int3
  456eec:	cc                   	int3
  456eed:	cc                   	int3
  456eee:	cc                   	int3
  456eef:	cc                   	int3
  456ef0:	81 ec 58 03 00 00    	sub    esp,0x358
  456ef6:	53                   	push   ebx
  456ef7:	56                   	push   esi
  456ef8:	8b b4 24 64 03 00 00 	mov    esi,DWORD PTR [esp+0x364]
  456eff:	57                   	push   edi
  456f00:	55                   	push   ebp
  456f01:	c7 06 03 00 00 00    	mov    DWORD PTR [esi],0x3
  456f07:	c7 46 20 00 00 00 00 	mov    DWORD PTR [esi+0x20],0x0
  456f0e:	e8 0d ce 04 00       	call   0x4a3d20
  456f13:	8d 84 24 48 01 00 00 	lea    eax,[esp+0x148]
  456f1a:	6a 00                	push   0x0
  456f1c:	68 48 9b 59 00       	push   0x599b48
  456f21:	50                   	push   eax
  456f22:	e8 19 91 0a 00       	call   0x500040
  456f27:	8d 84 24 54 01 00 00 	lea    eax,[esp+0x154]
  456f2e:	8d 8c 24 64 02 00 00 	lea    ecx,[esp+0x264]
  456f35:	83 c4 0c             	add    esp,0xc
  456f38:	68 1c d0 59 00       	push   0x59d01c
  456f3d:	50                   	push   eax
  456f3e:	68 34 9b 59 00       	push   0x599b34
  456f43:	51                   	push   ecx
  456f44:	e8 07 45 10 00       	call   0x55b450
  456f49:	83 c4 10             	add    esp,0x10
  456f4c:	8b 1d 0c df 59 00    	mov    ebx,DWORD PTR ds:0x59df0c
  456f52:	e8 a9 c2 04 00       	call   0x4a3200
  456f57:	e8 c4 cd 04 00       	call   0x4a3d20
  456f5c:	8d 8c 24 58 02 00 00 	lea    ecx,[esp+0x258]
  456f63:	51                   	push   ecx
  456f64:	68 23 cd 89 00       	push   0x89cd23
  456f69:	e8 42 92 0a 00       	call   0x5001b0
  456f6e:	8d 44 24 20          	lea    eax,[esp+0x20]
  456f72:	83 c4 08             	add    esp,0x8
  456f75:	50                   	push   eax
  456f76:	68 ff ff ff 0f       	push   0xfffffff
  456f7b:	53                   	push   ebx
  456f7c:	68 23 cd 89 00       	push   0x89cd23
  456f81:	e8 fa ef 0c 00       	call   0x525f80
  456f86:	8b 44 24 28          	mov    eax,DWORD PTR [esp+0x28]
  456f8a:	83 c4 10             	add    esp,0x10
  456f8d:	6a 00                	push   0x0
  456f8f:	50                   	push   eax
  456f90:	53                   	push   ebx
  456f91:	e8 aa 5f 04 00       	call   0x49cf40
  456f96:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
  456f9a:	83 c4 0c             	add    esp,0xc
  456f9d:	8b cb                	mov    ecx,ebx
  456f9f:	03 c3                	add    eax,ebx
  456fa1:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
  456fa5:	3b d8                	cmp    ebx,eax
  456fa7:	73 0f                	jae    0x456fb8
  456fa9:	80 39 0a             	cmp    BYTE PTR [ecx],0xa
  456fac:	75 03                	jne    0x456fb1
  456fae:	c6 01 00             	mov    BYTE PTR [ecx],0x0
  456fb1:	41                   	inc    ecx
  456fb2:	3b 4c 24 14          	cmp    ecx,DWORD PTR [esp+0x14]
  456fb6:	72 f1                	jb     0x456fa9
  456fb8:	80 3b 00             	cmp    BYTE PTR [ebx],0x0
  456fbb:	74 06                	je     0x456fc3
  456fbd:	43                   	inc    ebx
  456fbe:	80 3b 00             	cmp    BYTE PTR [ebx],0x0
  456fc1:	75 fa                	jne    0x456fbd
  456fc3:	43                   	inc    ebx
  456fc4:	3b 5c 24 14          	cmp    ebx,DWORD PTR [esp+0x14]
  456fc8:	0f 83 d4 02 00 00    	jae    0x4572a2
  456fce:	33 ed                	xor    ebp,ebp
  456fd0:	89 6c 24 10          	mov    DWORD PTR [esp+0x10],ebp
  456fd4:	8d 44 24 48          	lea    eax,[esp+0x48]
  456fd8:	50                   	push   eax
  456fd9:	68 18 d0 59 00       	push   0x59d018
  456fde:	53                   	push   ebx
  456fdf:	e8 0c 45 10 00       	call   0x55b4f0
  456fe4:	8d 7c 24 54          	lea    edi,[esp+0x54]
  456fe8:	83 c4 0c             	add    esp,0xc
  456feb:	b9 ff ff ff ff       	mov    ecx,0xffffffff
  456ff0:	2b c0                	sub    eax,eax
  456ff2:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
  456ff4:	f7 d1                	not    ecx
  456ff6:	8d 54 24 48          	lea    edx,[esp+0x48]
  456ffa:	8d 5c 19 ff          	lea    ebx,[ecx+ebx*1-0x1]
  456ffe:	b9 0c d0 59 00       	mov    ecx,0x59d00c
  457003:	8a 02                	mov    al,BYTE PTR [edx]
  457005:	3a 01                	cmp    al,BYTE PTR [ecx]
  457007:	75 1a                	jne    0x457023
  457009:	0a c0                	or     al,al
  45700b:	74 12                	je     0x45701f
  45700d:	8a 42 01             	mov    al,BYTE PTR [edx+0x1]
  457010:	3a 41 01             	cmp    al,BYTE PTR [ecx+0x1]
  457013:	75 0e                	jne    0x457023
  457015:	83 c2 02             	add    edx,0x2
  457018:	83 c1 02             	add    ecx,0x2
  45701b:	0a c0                	or     al,al
  45701d:	75 e4                	jne    0x457003
  45701f:	33 c0                	xor    eax,eax
  457021:	eb 05                	jmp    0x457028
  457023:	1b c0                	sbb    eax,eax
  457025:	83 d8 ff             	sbb    eax,0xffffffff
  457028:	85 c0                	test   eax,eax
  45702a:	75 64                	jne    0x457090
  45702c:	8d 7e 04             	lea    edi,[esi+0x4]
  45702f:	8d 46 10             	lea    eax,[esi+0x10]
  457032:	50                   	push   eax
  457033:	57                   	push   edi
  457034:	68 fc cf 59 00       	push   0x59cffc
  457039:	53                   	push   ebx
  45703a:	e8 b1 44 10 00       	call   0x55b4f0
  45703f:	83 c4 10             	add    esp,0x10
  457042:	8b 0f                	mov    ecx,DWORD PTR [edi]
  457044:	8b c1                	mov    eax,ecx
  457046:	c1 e1 03             	shl    ecx,0x3
  457049:	2b c8                	sub    ecx,eax
  45704b:	c1 e1 02             	shl    ecx,0x2
  45704e:	51                   	push   ecx
  45704f:	e8 dc f5 0c 00       	call   0x526630
  457054:	83 c4 04             	add    esp,0x4
  457057:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  45705a:	83 4e 20 01          	or     DWORD PTR [esi+0x20],0x1
  45705e:	8b 07                	mov    eax,DWORD PTR [edi]
  457060:	c1 e0 05             	shl    eax,0x5
  457063:	50                   	push   eax
  457064:	e8 c7 f5 0c 00       	call   0x526630
  457069:	83 c4 04             	add    esp,0x4
  45706c:	8b 4e 10             	mov    ecx,DWORD PTR [esi+0x10]
  45706f:	83 4e 20 02          	or     DWORD PTR [esi+0x20],0x2
  457073:	89 46 0c             	mov    DWORD PTR [esi+0xc],eax
  457076:	8d 04 49             	lea    eax,[ecx+ecx*2]
  457079:	03 c0                	add    eax,eax
  45707b:	50                   	push   eax
  45707c:	e8 af f5 0c 00       	call   0x526630
  457081:	83 c4 04             	add    esp,0x4
  457084:	89 46 14             	mov    DWORD PTR [esi+0x14],eax
  457087:	83 4e 20 04          	or     DWORD PTR [esi+0x20],0x4
  45708b:	e9 fc 01 00 00       	jmp    0x45728c
  457090:	8d 4c 24 48          	lea    ecx,[esp+0x48]
  457094:	ba f4 cf 59 00       	mov    edx,0x59cff4
  457099:	8a 01                	mov    al,BYTE PTR [ecx]
  45709b:	3a 02                	cmp    al,BYTE PTR [edx]
  45709d:	75 1a                	jne    0x4570b9
  45709f:	0a c0                	or     al,al
  4570a1:	74 12                	je     0x4570b5
  4570a3:	8a 41 01             	mov    al,BYTE PTR [ecx+0x1]
  4570a6:	3a 42 01             	cmp    al,BYTE PTR [edx+0x1]
  4570a9:	75 0e                	jne    0x4570b9
  4570ab:	83 c1 02             	add    ecx,0x2
  4570ae:	83 c2 02             	add    edx,0x2
  4570b1:	0a c0                	or     al,al
  4570b3:	75 e4                	jne    0x457099
  4570b5:	33 c0                	xor    eax,eax
  4570b7:	eb 05                	jmp    0x4570be
  4570b9:	1b c0                	sbb    eax,eax
  4570bb:	83 d8 ff             	sbb    eax,0xffffffff
  4570be:	85 c0                	test   eax,eax
  4570c0:	0f 85 ee 00 00 00    	jne    0x4571b4
  4570c6:	8d 44 24 48          	lea    eax,[esp+0x48]
  4570ca:	50                   	push   eax
  4570cb:	68 18 d0 59 00       	push   0x59d018
  4570d0:	53                   	push   ebx
  4570d1:	e8 1a 44 10 00       	call   0x55b4f0
  4570d6:	8d 4c 24 54          	lea    ecx,[esp+0x54]
  4570da:	83 c4 0c             	add    esp,0xc
  4570dd:	ba ec cf 59 00       	mov    edx,0x59cfec
  4570e2:	8a 01                	mov    al,BYTE PTR [ecx]
  4570e4:	3a 02                	cmp    al,BYTE PTR [edx]
  4570e6:	75 1a                	jne    0x457102
  4570e8:	0a c0                	or     al,al
  4570ea:	74 12                	je     0x4570fe
  4570ec:	8a 41 01             	mov    al,BYTE PTR [ecx+0x1]
  4570ef:	3a 42 01             	cmp    al,BYTE PTR [edx+0x1]
  4570f2:	75 0e                	jne    0x457102
  4570f4:	83 c1 02             	add    ecx,0x2
  4570f7:	83 c2 02             	add    edx,0x2
  4570fa:	0a c0                	or     al,al
  4570fc:	75 e4                	jne    0x4570e2
  4570fe:	33 c0                	xor    eax,eax
  457100:	eb 05                	jmp    0x457107
  457102:	1b c0                	sbb    eax,eax
  457104:	83 d8 ff             	sbb    eax,0xffffffff
  457107:	85 c0                	test   eax,eax
  457109:	0f 84 7d 01 00 00    	je     0x45728c
  45710f:	8d 44 24 24          	lea    eax,[esp+0x24]
  457113:	8d 4c 24 20          	lea    ecx,[esp+0x20]
  457117:	8d 54 24 1c          	lea    edx,[esp+0x1c]
  45711b:	50                   	push   eax
  45711c:	8d 44 24 48          	lea    eax,[esp+0x48]
  457120:	51                   	push   ecx
  457121:	52                   	push   edx
  457122:	50                   	push   eax
  457123:	68 d4 cf 59 00       	push   0x59cfd4
  457128:	53                   	push   ebx
  457129:	e8 c2 43 10 00       	call   0x55b4f0
  45712e:	8b 56 08             	mov    edx,DWORD PTR [esi+0x8]
  457131:	8b 4c 24 34          	mov    ecx,DWORD PTR [esp+0x34]
  457135:	83 c4 18             	add    esp,0x18
  457138:	89 0c 2a             	mov    DWORD PTR [edx+ebp*1],ecx
  45713b:	8b 56 08             	mov    edx,DWORD PTR [esi+0x8]
  45713e:	8b 44 24 20          	mov    eax,DWORD PTR [esp+0x20]
  457142:	89 44 2a 04          	mov    DWORD PTR [edx+ebp*1+0x4],eax
  457146:	8b 56 08             	mov    edx,DWORD PTR [esi+0x8]
  457149:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
  45714d:	89 4c 2a 08          	mov    DWORD PTR [edx+ebp*1+0x8],ecx
  457151:	8b 56 08             	mov    edx,DWORD PTR [esi+0x8]
  457154:	03 d5                	add    edx,ebp
  457156:	8d 4a 0c             	lea    ecx,[edx+0xc]
  457159:	8b 02                	mov    eax,DWORD PTR [edx]
  45715b:	89 01                	mov    DWORD PTR [ecx],eax
  45715d:	8b 7a 04             	mov    edi,DWORD PTR [edx+0x4]
  457160:	89 79 04             	mov    DWORD PTR [ecx+0x4],edi
  457163:	8b 52 08             	mov    edx,DWORD PTR [edx+0x8]
  457166:	89 51 08             	mov    DWORD PTR [ecx+0x8],edx
  457169:	8b 46 08             	mov    eax,DWORD PTR [esi+0x8]
  45716c:	03 c5                	add    eax,ebp
  45716e:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  457171:	d8 48 14             	fmul   DWORD PTR [eax+0x14]
  457174:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  457177:	d8 48 0c             	fmul   DWORD PTR [eax+0xc]
  45717a:	de c1                	faddp  st(1),st
  45717c:	d9 40 10             	fld    DWORD PTR [eax+0x10]
  45717f:	d8 48 10             	fmul   DWORD PTR [eax+0x10]
  457182:	de c1                	faddp  st(1),st
  457184:	d9 fa                	fsqrt
  457186:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  45718c:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  45718f:	d8 c9                	fmul   st,st(1)
  457191:	d9 58 0c             	fstp   DWORD PTR [eax+0xc]
  457194:	8b 4e 08             	mov    ecx,DWORD PTR [esi+0x8]
  457197:	8d 44 29 10          	lea    eax,[ecx+ebp*1+0x10]
  45719b:	d9 00                	fld    DWORD PTR [eax]
  45719d:	d8 c9                	fmul   st,st(1)
  45719f:	d9 18                	fstp   DWORD PTR [eax]
  4571a1:	8b 4e 08             	mov    ecx,DWORD PTR [esi+0x8]
  4571a4:	83 c5 1c             	add    ebp,0x1c
  4571a7:	8d 44 29 f8          	lea    eax,[ecx+ebp*1-0x8]
  4571ab:	d8 08                	fmul   DWORD PTR [eax]
  4571ad:	d9 18                	fstp   DWORD PTR [eax]
  4571af:	e9 d8 00 00 00       	jmp    0x45728c
  4571b4:	8d 4c 24 48          	lea    ecx,[esp+0x48]
  4571b8:	ba cc cf 59 00       	mov    edx,0x59cfcc
  4571bd:	8a 01                	mov    al,BYTE PTR [ecx]
  4571bf:	3a 02                	cmp    al,BYTE PTR [edx]
  4571c1:	75 1a                	jne    0x4571dd
  4571c3:	0a c0                	or     al,al
  4571c5:	74 12                	je     0x4571d9
  4571c7:	8a 41 01             	mov    al,BYTE PTR [ecx+0x1]
  4571ca:	3a 42 01             	cmp    al,BYTE PTR [edx+0x1]
  4571cd:	75 0e                	jne    0x4571dd
  4571cf:	83 c1 02             	add    ecx,0x2
  4571d2:	83 c2 02             	add    edx,0x2
  4571d5:	0a c0                	or     al,al
  4571d7:	75 e4                	jne    0x4571bd
  4571d9:	33 c0                	xor    eax,eax
  4571db:	eb 05                	jmp    0x4571e2
  4571dd:	1b c0                	sbb    eax,eax
  4571df:	83 d8 ff             	sbb    eax,0xffffffff
  4571e2:	85 c0                	test   eax,eax
  4571e4:	0f 85 a2 00 00 00    	jne    0x45728c
  4571ea:	8d 44 24 48          	lea    eax,[esp+0x48]
  4571ee:	50                   	push   eax
  4571ef:	68 18 d0 59 00       	push   0x59d018
  4571f4:	53                   	push   ebx
  4571f5:	e8 f6 42 10 00       	call   0x55b4f0
  4571fa:	8d 4c 24 54          	lea    ecx,[esp+0x54]
  4571fe:	83 c4 0c             	add    esp,0xc
  457201:	ba ec cf 59 00       	mov    edx,0x59cfec
  457206:	8a 01                	mov    al,BYTE PTR [ecx]
  457208:	3a 02                	cmp    al,BYTE PTR [edx]
  45720a:	75 1a                	jne    0x457226
  45720c:	0a c0                	or     al,al
  45720e:	74 12                	je     0x457222
  457210:	8a 41 01             	mov    al,BYTE PTR [ecx+0x1]
  457213:	3a 42 01             	cmp    al,BYTE PTR [edx+0x1]
  457216:	75 0e                	jne    0x457226
  457218:	83 c1 02             	add    ecx,0x2
  45721b:	83 c2 02             	add    edx,0x2
  45721e:	0a c0                	or     al,al
  457220:	75 e4                	jne    0x457206
  457222:	33 c0                	xor    eax,eax
  457224:	eb 05                	jmp    0x45722b
  457226:	1b c0                	sbb    eax,eax
  457228:	83 d8 ff             	sbb    eax,0xffffffff
  45722b:	85 c0                	test   eax,eax
  45722d:	74 5d                	je     0x45728c
  45722f:	8d 44 24 40          	lea    eax,[esp+0x40]
  457233:	8d 4c 24 3c          	lea    ecx,[esp+0x3c]
  457237:	8d 54 24 38          	lea    edx,[esp+0x38]
  45723b:	50                   	push   eax
  45723c:	8d 44 24 30          	lea    eax,[esp+0x30]
  457240:	51                   	push   ecx
  457241:	8d 4c 24 38          	lea    ecx,[esp+0x38]
  457245:	52                   	push   edx
  457246:	8d 54 24 34          	lea    edx,[esp+0x34]
  45724a:	50                   	push   eax
  45724b:	8d 44 24 44          	lea    eax,[esp+0x44]
  45724f:	51                   	push   ecx
  457250:	52                   	push   edx
  457251:	50                   	push   eax
  457252:	68 a4 cf 59 00       	push   0x59cfa4
  457257:	53                   	push   ebx
  457258:	e8 93 42 10 00       	call   0x55b4f0
  45725d:	8b 7c 24 4c          	mov    edi,DWORD PTR [esp+0x4c]
  457261:	8b 4c 24 34          	mov    ecx,DWORD PTR [esp+0x34]
  457265:	83 c4 24             	add    esp,0x24
  457268:	8b 56 14             	mov    edx,DWORD PTR [esi+0x14]
  45726b:	66 89 3c 0a          	mov    WORD PTR [edx+ecx*1],di
  45726f:	8b 56 14             	mov    edx,DWORD PTR [esi+0x14]
  457272:	8b 44 24 2c          	mov    eax,DWORD PTR [esp+0x2c]
  457276:	83 44 24 10 06       	add    DWORD PTR [esp+0x10],0x6
  45727b:	66 89 44 0a 02       	mov    WORD PTR [edx+ecx*1+0x2],ax
  457280:	8b 44 24 30          	mov    eax,DWORD PTR [esp+0x30]
  457284:	8b 56 14             	mov    edx,DWORD PTR [esi+0x14]
  457287:	66 89 44 0a 04       	mov    WORD PTR [edx+ecx*1+0x4],ax
  45728c:	80 3b 00             	cmp    BYTE PTR [ebx],0x0
  45728f:	74 06                	je     0x457297
  457291:	43                   	inc    ebx
  457292:	80 3b 00             	cmp    BYTE PTR [ebx],0x0
  457295:	75 fa                	jne    0x457291
  457297:	43                   	inc    ebx
  457298:	3b 5c 24 14          	cmp    ebx,DWORD PTR [esp+0x14]
  45729c:	0f 82 32 fd ff ff    	jb     0x456fd4
  4572a2:	33 c0                	xor    eax,eax
  4572a4:	89 46 24             	mov    DWORD PTR [esi+0x24],eax
  4572a7:	89 46 28             	mov    DWORD PTR [esi+0x28],eax
  4572aa:	89 46 2c             	mov    DWORD PTR [esi+0x2c],eax
  4572ad:	89 46 3c             	mov    DWORD PTR [esi+0x3c],eax
  4572b0:	89 46 40             	mov    DWORD PTR [esi+0x40],eax
  4572b3:	89 46 44             	mov    DWORD PTR [esi+0x44],eax
  4572b6:	89 46 48             	mov    DWORD PTR [esi+0x48],eax
  4572b9:	89 46 4c             	mov    DWORD PTR [esi+0x4c],eax
  4572bc:	c7 46 54 00 00 00 3f 	mov    DWORD PTR [esi+0x54],0x3f000000
  4572c3:	5d                   	pop    ebp
  4572c4:	89 46 50             	mov    DWORD PTR [esi+0x50],eax
  4572c7:	c7 46 58 cd cc cc 3d 	mov    DWORD PTR [esi+0x58],0x3dcccccd
  4572ce:	c7 46 5c 00 00 80 3f 	mov    DWORD PTR [esi+0x5c],0x3f800000
  4572d5:	c7 46 60 01 00 00 00 	mov    DWORD PTR [esi+0x60],0x1
  4572dc:	5f                   	pop    edi
  4572dd:	5e                   	pop    esi
  4572de:	5b                   	pop    ebx
  4572df:	81 c4 58 03 00 00    	add    esp,0x358
  4572e5:	c3                   	ret
  4572e6:	cc                   	int3
  4572e7:	cc                   	int3
  4572e8:	cc                   	int3
  4572e9:	cc                   	int3
  4572ea:	cc                   	int3
  4572eb:	cc                   	int3
  4572ec:	cc                   	int3
  4572ed:	cc                   	int3
  4572ee:	cc                   	int3
  4572ef:	cc                   	int3
