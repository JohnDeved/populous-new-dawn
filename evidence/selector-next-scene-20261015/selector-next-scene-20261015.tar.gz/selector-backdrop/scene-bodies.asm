
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

0045663f <.text+0x5563f>:
  45663f:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  456642:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  456649:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  45664c:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  456653:	8d 4b 10             	lea    ecx,[ebx+0x10]
  456656:	de c1                	faddp  st(1),st
  456658:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  45665b:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  456662:	de c1                	faddp  st(1),st
  456664:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  45666b:	d9 9c 24 c8 00 00 00 	fstp   DWORD PTR [esp+0xc8]
  456672:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  456675:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  45667c:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  45667f:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  456686:	de c1                	faddp  st(1),st
  456688:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  45668b:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  456692:	de c1                	faddp  st(1),st
  456694:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  45669b:	d9 9c 24 cc 00 00 00 	fstp   DWORD PTR [esp+0xcc]
  4566a2:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  4566a5:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  4566ac:	d9 43 0c             	fld    DWORD PTR [ebx+0xc]
  4566af:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  4566b6:	de c1                	faddp  st(1),st
  4566b8:	d9 43 04             	fld    DWORD PTR [ebx+0x4]
  4566bb:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  4566c2:	de c1                	faddp  st(1),st
  4566c4:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  4566cb:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  4566d1:	d9 9c 24 d0 00 00 00 	fstp   DWORD PTR [esp+0xd0]
  4566d8:	df e0                	fnstsw ax
  4566da:	f6 c4 41             	test   ah,0x41
  4566dd:	75 3c                	jne    0x45671b
  4566df:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  4566e5:	d8 b4 24 d0 00 00 00 	fdiv   DWORD PTR [esp+0xd0]
  4566ec:	d9 84 24 c8 00 00 00 	fld    DWORD PTR [esp+0xc8]
  4566f3:	d8 c9                	fmul   st,st(1)
  4566f5:	8b 84 24 d0 00 00 00 	mov    eax,DWORD PTR [esp+0xd0]
  4566fc:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  456703:	d9 19                	fstp   DWORD PTR [ecx]
  456705:	d8 8c 24 cc 00 00 00 	fmul   DWORD PTR [esp+0xcc]
  45670c:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  456713:	d9 59 04             	fstp   DWORD PTR [ecx+0x4]
  456716:	89 41 08             	mov    DWORD PTR [ecx+0x8],eax
  456719:	eb 07                	jmp    0x456722
  45671b:	c7 41 08 00 00 80 bf 	mov    DWORD PTR [ecx+0x8],0xbf800000
  456722:	d9 01                	fld    DWORD PTR [ecx]
  456724:	8b 43 1c             	mov    eax,DWORD PTR [ebx+0x1c]
  456727:	66 8b 40 04          	mov    ax,WORD PTR [eax+0x4]
  45672b:	66 c1 e8 01          	shr    ax,0x1
  45672f:	0f b7 d0             	movzx  edx,ax
  456732:	89 94 24 84 00 00 00 	mov    DWORD PTR [esp+0x84],edx
  456739:	8d 51 04             	lea    edx,[ecx+0x4]
  45673c:	da a4 24 84 00 00 00 	fisub  DWORD PTR [esp+0x84]
  456743:	d9 19                	fstp   DWORD PTR [ecx]
  456745:	d9 02                	fld    DWORD PTR [edx]
  456747:	8b 43 1c             	mov    eax,DWORD PTR [ebx+0x1c]
  45674a:	66 8b 40 06          	mov    ax,WORD PTR [eax+0x6]
  45674e:	66 c1 e8 01          	shr    ax,0x1
  456752:	0f b7 e8             	movzx  ebp,ax
  456755:	89 ac 24 80 00 00 00 	mov    DWORD PTR [esp+0x80],ebp
  45675c:	da a4 24 80 00 00 00 	fisub  DWORD PTR [esp+0x80]
  456763:	d9 1a                	fstp   DWORD PTR [edx]
  456765:	8d 94 24 ec 00 00 00 	lea    edx,[esp+0xec]
  45676c:	8b 01                	mov    eax,DWORD PTR [ecx]
  45676e:	8b 69 04             	mov    ebp,DWORD PTR [ecx+0x4]
  456771:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  456774:	89 02                	mov    DWORD PTR [edx],eax
  456776:	89 6a 04             	mov    DWORD PTR [edx+0x4],ebp
  456779:	89 4a 08             	mov    DWORD PTR [edx+0x8],ecx
  45677c:	83 bc 24 f4 00 00 00 	cmp    DWORD PTR [esp+0xf4],0x0
  456783:	00 
  456784:	0f 8e bf 02 00 00    	jle    0x456a49
  45678a:	8b 4b 1c             	mov    ecx,DWORD PTR [ebx+0x1c]
  45678d:	33 c0                	xor    eax,eax
  45678f:	66 8b 41 04          	mov    ax,WORD PTR [ecx+0x4]
  456793:	f7 d8                	neg    eax
  456795:	89 44 24 7c          	mov    DWORD PTR [esp+0x7c],eax
  456799:	db 44 24 7c          	fild   DWORD PTR [esp+0x7c]
  45679d:	d8 9c 24 ec 00 00 00 	fcomp  DWORD PTR [esp+0xec]
  4567a4:	df e0                	fnstsw ax
  4567a6:	f6 c4 41             	test   ah,0x41
  4567a9:	0f 84 9a 02 00 00    	je     0x456a49
  4567af:	d9 05 c0 c9 5f 00    	fld    DWORD PTR ds:0x5fc9c0
  4567b5:	d8 9c 24 ec 00 00 00 	fcomp  DWORD PTR [esp+0xec]
  4567bc:	df e0                	fnstsw ax
  4567be:	f6 c4 01             	test   ah,0x1
  4567c1:	0f 85 82 02 00 00    	jne    0x456a49
  4567c7:	33 c0                	xor    eax,eax
  4567c9:	66 8b 41 06          	mov    ax,WORD PTR [ecx+0x6]
  4567cd:	f7 d8                	neg    eax
  4567cf:	89 44 24 78          	mov    DWORD PTR [esp+0x78],eax
  4567d3:	db 44 24 78          	fild   DWORD PTR [esp+0x78]
  4567d7:	d8 9c 24 f0 00 00 00 	fcomp  DWORD PTR [esp+0xf0]
  4567de:	df e0                	fnstsw ax
  4567e0:	f6 c4 41             	test   ah,0x41
  4567e3:	0f 84 60 02 00 00    	je     0x456a49
  4567e9:	d9 05 c4 c9 5f 00    	fld    DWORD PTR ds:0x5fc9c4
  4567ef:	d8 9c 24 f0 00 00 00 	fcomp  DWORD PTR [esp+0xf0]
  4567f6:	df e0                	fnstsw ax
  4567f8:	9e                   	sahf
  4567f9:	e9 4b 02 00 00       	jmp    0x456a49
  4567fe:	33 c0                	xor    eax,eax
  456800:	89 84 24 28 01 00 00 	mov    DWORD PTR [esp+0x128],eax
  456807:	89 84 24 2c 01 00 00 	mov    DWORD PTR [esp+0x12c],eax
  45680e:	d9 84 24 2c 01 00 00 	fld    DWORD PTR [esp+0x12c]
  456815:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  45681c:	89 84 24 30 01 00 00 	mov    DWORD PTR [esp+0x130],eax
  456823:	d9 84 24 30 01 00 00 	fld    DWORD PTR [esp+0x130]
  45682a:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  456831:	de c1                	faddp  st(1),st
  456833:	d9 84 24 28 01 00 00 	fld    DWORD PTR [esp+0x128]
  45683a:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  456841:	de c1                	faddp  st(1),st
  456843:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  45684a:	d9 9c 24 bc 00 00 00 	fstp   DWORD PTR [esp+0xbc]
  456851:	d9 84 24 2c 01 00 00 	fld    DWORD PTR [esp+0x12c]
  456858:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  45685f:	d9 84 24 30 01 00 00 	fld    DWORD PTR [esp+0x130]
  456866:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  45686d:	de c1                	faddp  st(1),st
  45686f:	d9 84 24 28 01 00 00 	fld    DWORD PTR [esp+0x128]
  456876:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  45687d:	de c1                	faddp  st(1),st
  45687f:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  456886:	d9 9c 24 c0 00 00 00 	fstp   DWORD PTR [esp+0xc0]
  45688d:	d9 84 24 2c 01 00 00 	fld    DWORD PTR [esp+0x12c]
  456894:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  45689b:	d9 84 24 30 01 00 00 	fld    DWORD PTR [esp+0x130]
  4568a2:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  4568a9:	de c1                	faddp  st(1),st
  4568ab:	d9 84 24 28 01 00 00 	fld    DWORD PTR [esp+0x128]
  4568b2:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  4568b9:	de c1                	faddp  st(1),st
  4568bb:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  4568c2:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  4568c8:	d9 9c 24 c4 00 00 00 	fstp   DWORD PTR [esp+0xc4]
  4568cf:	df e0                	fnstsw ax
  4568d1:	f6 c4 41             	test   ah,0x41
  4568d4:	75 3d                	jne    0x456913
  4568d6:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  4568dc:	d8 b4 24 c4 00 00 00 	fdiv   DWORD PTR [esp+0xc4]
  4568e3:	d9 84 24 bc 00 00 00 	fld    DWORD PTR [esp+0xbc]
  4568ea:	d8 c9                	fmul   st,st(1)
  4568ec:	8b 84 24 c4 00 00 00 	mov    eax,DWORD PTR [esp+0xc4]
  4568f3:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  4568fa:	d9 5b 30             	fstp   DWORD PTR [ebx+0x30]
  4568fd:	d8 8c 24 c0 00 00 00 	fmul   DWORD PTR [esp+0xc0]
  456904:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  45690b:	d9 5b 34             	fstp   DWORD PTR [ebx+0x34]
  45690e:	89 43 38             	mov    DWORD PTR [ebx+0x38],eax
  456911:	eb 07                	jmp    0x45691a
  456913:	c7 43 38 00 00 80 bf 	mov    DWORD PTR [ebx+0x38],0xbf800000
  45691a:	d9 84 24 2c 01 00 00 	fld    DWORD PTR [esp+0x12c]
  456921:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  456928:	d9 84 24 30 01 00 00 	fld    DWORD PTR [esp+0x130]
  45692f:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  456936:	de c1                	faddp  st(1),st
  456938:	d9 84 24 28 01 00 00 	fld    DWORD PTR [esp+0x128]
  45693f:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  456946:	de c1                	faddp  st(1),st
  456948:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  45694f:	d8 43 5c             	fadd   DWORD PTR [ebx+0x5c]
  456952:	d9 84 24 2c 01 00 00 	fld    DWORD PTR [esp+0x12c]
  456959:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  456960:	d9 84 24 30 01 00 00 	fld    DWORD PTR [esp+0x130]
  456967:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  45696e:	de c1                	faddp  st(1),st
  456970:	d9 84 24 28 01 00 00 	fld    DWORD PTR [esp+0x128]
  456977:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  45697e:	de c1                	faddp  st(1),st
  456980:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  456987:	d8 3d 84 95 73 00    	fdivr  DWORD PTR ds:0x739584
  45698d:	de c9                	fmulp  st(1),st
  45698f:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  456996:	d8 6b 34             	fsubr  DWORD PTR [ebx+0x34]
  456999:	d9 5c 24 74          	fstp   DWORD PTR [esp+0x74]
  45699d:	d9 84 24 64 01 00 00 	fld    DWORD PTR [esp+0x164]
  4569a4:	d9 e0                	fchs
  4569a6:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  4569ad:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  4569b3:	d9 9c 24 24 01 00 00 	fstp   DWORD PTR [esp+0x124]
  4569ba:	df e0                	fnstsw ax
  4569bc:	f6 c4 41             	test   ah,0x41
  4569bf:	75 10                	jne    0x4569d1
  4569c1:	8b 84 24 24 01 00 00 	mov    eax,DWORD PTR [esp+0x124]
  4569c8:	89 84 24 0c 01 00 00 	mov    DWORD PTR [esp+0x10c],eax
  4569cf:	eb 0b                	jmp    0x4569dc
  4569d1:	c7 84 24 0c 01 00 00 	mov    DWORD PTR [esp+0x10c],0xbf800000
  4569d8:	00 00 80 bf 
  4569dc:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  4569df:	d8 05 10 f4 58 00    	fadd   DWORD PTR ds:0x58f410
  4569e5:	d9 5b 08             	fstp   DWORD PTR [ebx+0x8]
  4569e8:	81 7b 08 00 00 80 3f 	cmp    DWORD PTR [ebx+0x8],0x3f800000
  4569ef:	7e 0c                	jle    0x4569fd
  4569f1:	d9 43 08             	fld    DWORD PTR [ebx+0x8]
  4569f4:	d8 25 80 f3 58 00    	fsub   DWORD PTR ds:0x58f380
  4569fa:	d9 5b 08             	fstp   DWORD PTR [ebx+0x8]
  4569fd:	d9 43 38             	fld    DWORD PTR [ebx+0x38]
  456a00:	d8 a4 24 0c 01 00 00 	fsub   DWORD PTR [esp+0x10c]
  456a07:	8b 43 0c             	mov    eax,DWORD PTR [ebx+0xc]
  456a0a:	8b 4b 08             	mov    ecx,DWORD PTR [ebx+0x8]
  456a0d:	50                   	push   eax
  456a0e:	51                   	push   ecx
  456a0f:	d8 0d 70 f3 58 00    	fmul   DWORD PTR ds:0x58f370
  456a15:	8b 54 24 7c          	mov    edx,DWORD PTR [esp+0x7c]
  456a19:	83 ec 04             	sub    esp,0x4
  456a1c:	83 ec 04             	sub    esp,0x4
  456a1f:	8b 43 34             	mov    eax,DWORD PTR [ebx+0x34]
  456a22:	8b 4b 30             	mov    ecx,DWORD PTR [ebx+0x30]
  456a25:	52                   	push   edx
  456a26:	d9 5c 24 08          	fstp   DWORD PTR [esp+0x8]
  456a2a:	d9 05 70 f3 58 00    	fld    DWORD PTR ds:0x58f370
  456a30:	d8 8c 24 20 01 00 00 	fmul   DWORD PTR [esp+0x120]
  456a37:	50                   	push   eax
  456a38:	8b 53 04             	mov    edx,DWORD PTR [ebx+0x4]
  456a3b:	51                   	push   ecx
  456a3c:	52                   	push   edx
  456a3d:	d9 5c 24 10          	fstp   DWORD PTR [esp+0x10]
  456a41:	e8 0a 29 fd ff       	call   0x429350
  456a46:	83 c4 20             	add    esp,0x20
  456a49:	83 c3 64             	add    ebx,0x64
  456a4c:	ff 4c 24 70          	dec    DWORD PTR [esp+0x70]
  456a50:	0f 85 f6 ee ff ff    	jne    0x45594c
  456a56:	68 ff ff 0f 00       	push   0xfffff
  456a5b:	68 1f 00 09 00       	push   0x9001f
  456a60:	e8 0b 5d 10 00       	call   0x55c770
  456a65:	83 c4 08             	add    esp,0x8
  456a68:	5d                   	pop    ebp
  456a69:	5f                   	pop    edi
  456a6a:	5e                   	pop    esi
  456a6b:	5b                   	pop    ebx
  456a6c:	81 c4 54 02 00 00    	add    esp,0x254
  456a72:	c3                   	ret
  456a73:	90                   	nop
  456a74:	46                   	inc    esi
  456a75:	5f                   	pop    edi
  456a76:	45                   	inc    ebp
  456a77:	00 64 61 45          	add    BYTE PTR [ecx+eiz*2+0x45],ah
  456a7b:	00 49 6a             	add    BYTE PTR [ecx+0x6a],cl
  456a7e:	45                   	inc    ebp
  456a7f:	00 3f                	add    BYTE PTR [edi],bh
  456a81:	66 45                	inc    bp
  456a83:	00 fe                	add    dh,bh
  456a85:	67 45                	addr16 inc ebp
  456a87:	00 cc                	add    ah,cl
  456a89:	cc                   	int3
  456a8a:	cc                   	int3
  456a8b:	cc                   	int3
  456a8c:	cc                   	int3
  456a8d:	cc                   	int3
  456a8e:	cc                   	int3
  456a8f:	cc                   	int3
