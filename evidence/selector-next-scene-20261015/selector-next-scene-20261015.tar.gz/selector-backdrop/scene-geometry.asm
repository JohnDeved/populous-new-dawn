
/workspace/scratch/69fd8163d94e/populous-research-inputs/game/app/D3DPopTB.exe:     file format pei-i386


Disassembly of section .text:

00455610 <.text+0x54610>:
  455610:	a1 8c 95 73 00       	mov    eax,ds:0x73958c
  455615:	b9 8c 95 73 00       	mov    ecx,0x73958c
  45561a:	d9 05 b4 95 73 00    	fld    DWORD PTR ds:0x7395b4
  455620:	d8 25 8c 95 73 00    	fsub   DWORD PTR ds:0x73958c
  455626:	a3 54 95 73 00       	mov    ds:0x739554,eax
  45562b:	ba 54 95 73 00       	mov    edx,0x739554
  455630:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
  455633:	8b 49 08             	mov    ecx,DWORD PTR [ecx+0x8]
  455636:	89 42 04             	mov    DWORD PTR [edx+0x4],eax
  455639:	d9 1d 60 95 73 00    	fstp   DWORD PTR ds:0x739560
  45563f:	d9 05 b8 95 73 00    	fld    DWORD PTR ds:0x7395b8
  455645:	d8 25 90 95 73 00    	fsub   DWORD PTR ds:0x739590
  45564b:	89 4a 08             	mov    DWORD PTR [edx+0x8],ecx
  45564e:	d9 1d 64 95 73 00    	fstp   DWORD PTR ds:0x739564
  455654:	d9 05 bc 95 73 00    	fld    DWORD PTR ds:0x7395bc
  45565a:	d8 25 94 95 73 00    	fsub   DWORD PTR ds:0x739594
  455660:	d9 1d 68 95 73 00    	fstp   DWORD PTR ds:0x739568
  455666:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  45566c:	d8 0d 60 95 73 00    	fmul   DWORD PTR ds:0x739560
  455672:	d9 05 64 95 73 00    	fld    DWORD PTR ds:0x739564
  455678:	d8 0d 64 95 73 00    	fmul   DWORD PTR ds:0x739564
  45567e:	de c1                	faddp  st(1),st
  455680:	d9 05 68 95 73 00    	fld    DWORD PTR ds:0x739568
  455686:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  45568c:	de c1                	faddp  st(1),st
  45568e:	d9 fa                	fsqrt
  455690:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  455696:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  45569c:	d8 c9                	fmul   st,st(1)
  45569e:	d9 1d 60 95 73 00    	fstp   DWORD PTR ds:0x739560
  4556a4:	d9 05 64 95 73 00    	fld    DWORD PTR ds:0x739564
  4556aa:	d8 c9                	fmul   st,st(1)
  4556ac:	d9 1d 64 95 73 00    	fstp   DWORD PTR ds:0x739564
  4556b2:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  4556b8:	d9 1d 68 95 73 00    	fstp   DWORD PTR ds:0x739568
  4556be:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  4556c4:	d8 0d 60 95 73 00    	fmul   DWORD PTR ds:0x739560
  4556ca:	d9 05 64 95 73 00    	fld    DWORD PTR ds:0x739564
  4556d0:	d8 0d 64 95 73 00    	fmul   DWORD PTR ds:0x739564
  4556d6:	de c1                	faddp  st(1),st
  4556d8:	d9 05 68 95 73 00    	fld    DWORD PTR ds:0x739568
  4556de:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  4556e4:	de c1                	faddp  st(1),st
  4556e6:	d9 fa                	fsqrt
  4556e8:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  4556ee:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  4556f4:	d8 c9                	fmul   st,st(1)
  4556f6:	d9 1d 60 95 73 00    	fstp   DWORD PTR ds:0x739560
  4556fc:	d9 05 64 95 73 00    	fld    DWORD PTR ds:0x739564
  455702:	d8 c9                	fmul   st,st(1)
  455704:	d9 1d 64 95 73 00    	fstp   DWORD PTR ds:0x739564
  45570a:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  455710:	d9 1d 68 95 73 00    	fstp   DWORD PTR ds:0x739568
  455716:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  45571c:	d9 e0                	fchs
  45571e:	d9 1d 80 95 73 00    	fstp   DWORD PTR ds:0x739580
  455724:	d9 05 68 95 73 00    	fld    DWORD PTR ds:0x739568
  45572a:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  455730:	d9 05 80 95 73 00    	fld    DWORD PTR ds:0x739580
  455736:	d8 0d 80 95 73 00    	fmul   DWORD PTR ds:0x739580
  45573c:	c7 05 7c 95 73 00 00 	mov    DWORD PTR ds:0x73957c,0x0
  455743:	00 00 00 
  455746:	de c1                	faddp  st(1),st
  455748:	d9 fa                	fsqrt
  45574a:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  455750:	d9 05 68 95 73 00    	fld    DWORD PTR ds:0x739568
  455756:	d8 c9                	fmul   st,st(1)
  455758:	d9 1d 78 95 73 00    	fstp   DWORD PTR ds:0x739578
  45575e:	d8 0d 80 95 73 00    	fmul   DWORD PTR ds:0x739580
  455764:	d9 15 80 95 73 00    	fst    DWORD PTR ds:0x739580
  45576a:	d8 0d 64 95 73 00    	fmul   DWORD PTR ds:0x739564
  455770:	d9 1d 6c 95 73 00    	fstp   DWORD PTR ds:0x73956c
  455776:	d9 05 78 95 73 00    	fld    DWORD PTR ds:0x739578
  45577c:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  455782:	d9 05 80 95 73 00    	fld    DWORD PTR ds:0x739580
  455788:	d8 0d 60 95 73 00    	fmul   DWORD PTR ds:0x739560
  45578e:	de e9                	fsubp  st(1),st
  455790:	d9 1d 70 95 73 00    	fstp   DWORD PTR ds:0x739570
  455796:	d9 05 78 95 73 00    	fld    DWORD PTR ds:0x739578
  45579c:	d8 0d 64 95 73 00    	fmul   DWORD PTR ds:0x739564
  4557a2:	d9 e0                	fchs
  4557a4:	d9 1d 74 95 73 00    	fstp   DWORD PTR ds:0x739574
  4557aa:	d9 05 70 95 73 00    	fld    DWORD PTR ds:0x739570
  4557b0:	d8 0d 70 95 73 00    	fmul   DWORD PTR ds:0x739570
  4557b6:	d9 05 74 95 73 00    	fld    DWORD PTR ds:0x739574
  4557bc:	d8 0d 74 95 73 00    	fmul   DWORD PTR ds:0x739574
  4557c2:	de c1                	faddp  st(1),st
  4557c4:	d9 05 6c 95 73 00    	fld    DWORD PTR ds:0x73956c
  4557ca:	d8 0d 6c 95 73 00    	fmul   DWORD PTR ds:0x73956c
  4557d0:	de c1                	faddp  st(1),st
  4557d2:	d9 fa                	fsqrt
  4557d4:	dc 3d 98 f3 58 00    	fdivr  QWORD PTR ds:0x58f398
  4557da:	d9 05 6c 95 73 00    	fld    DWORD PTR ds:0x73956c
  4557e0:	d8 c9                	fmul   st,st(1)
  4557e2:	d9 1d 6c 95 73 00    	fstp   DWORD PTR ds:0x73956c
  4557e8:	d9 05 70 95 73 00    	fld    DWORD PTR ds:0x739570
  4557ee:	d8 c9                	fmul   st,st(1)
  4557f0:	d9 1d 70 95 73 00    	fstp   DWORD PTR ds:0x739570
  4557f6:	d8 0d 74 95 73 00    	fmul   DWORD PTR ds:0x739574
  4557fc:	d9 1d 74 95 73 00    	fstp   DWORD PTR ds:0x739574
  455802:	c3                   	ret
  455803:	cc                   	int3
  455804:	cc                   	int3
  455805:	cc                   	int3
  455806:	cc                   	int3
  455807:	cc                   	int3
  455808:	cc                   	int3
  455809:	cc                   	int3
  45580a:	cc                   	int3
  45580b:	cc                   	int3
  45580c:	cc                   	int3
  45580d:	cc                   	int3
  45580e:	cc                   	int3
  45580f:	cc                   	int3
  455810:	81 ec 54 02 00 00    	sub    esp,0x254
  455816:	53                   	push   ebx
  455817:	56                   	push   esi
  455818:	57                   	push   edi
  455819:	55                   	push   ebp
  45581a:	68 00 00 03 00       	push   0x30000
  45581f:	68 00 00 02 00       	push   0x20000
  455824:	e8 47 6f 10 00       	call   0x55c770
  455829:	83 c4 08             	add    esp,0x8
  45582c:	a1 78 95 73 00       	mov    eax,ds:0x739578
  455831:	8b 0d 7c 95 73 00    	mov    ecx,DWORD PTR ds:0x73957c
  455837:	8b 15 80 95 73 00    	mov    edx,DWORD PTR ds:0x739580
  45583d:	89 84 24 68 01 00 00 	mov    DWORD PTR [esp+0x168],eax
  455844:	89 8c 24 6c 01 00 00 	mov    DWORD PTR [esp+0x16c],ecx
  45584b:	a1 6c 95 73 00       	mov    eax,ds:0x73956c
  455850:	8b 0d 70 95 73 00    	mov    ecx,DWORD PTR ds:0x739570
  455856:	89 94 24 70 01 00 00 	mov    DWORD PTR [esp+0x170],edx
  45585d:	89 84 24 74 01 00 00 	mov    DWORD PTR [esp+0x174],eax
  455864:	8b 15 74 95 73 00    	mov    edx,DWORD PTR ds:0x739574
  45586a:	a1 60 95 73 00       	mov    eax,ds:0x739560
  45586f:	89 8c 24 78 01 00 00 	mov    DWORD PTR [esp+0x178],ecx
  455876:	89 94 24 7c 01 00 00 	mov    DWORD PTR [esp+0x17c],edx
  45587d:	8b 0d 64 95 73 00    	mov    ecx,DWORD PTR ds:0x739564
  455883:	8b 15 68 95 73 00    	mov    edx,DWORD PTR ds:0x739568
  455889:	89 84 24 80 01 00 00 	mov    DWORD PTR [esp+0x180],eax
  455890:	89 8c 24 84 01 00 00 	mov    DWORD PTR [esp+0x184],ecx
  455897:	d9 05 80 95 73 00    	fld    DWORD PTR ds:0x739580
  45589d:	d8 0d 5c 95 73 00    	fmul   DWORD PTR ds:0x73955c
  4558a3:	d9 05 7c 95 73 00    	fld    DWORD PTR ds:0x73957c
  4558a9:	d8 0d 58 95 73 00    	fmul   DWORD PTR ds:0x739558
  4558af:	c7 05 44 cd 72 00 30 	mov    DWORD PTR ds:0x72cd44,0x30
  4558b6:	00 00 00 
  4558b9:	c7 05 40 cd 72 00 00 	mov    DWORD PTR ds:0x72cd40,0x1000
  4558c0:	10 00 00 
  4558c3:	de c1                	faddp  st(1),st
  4558c5:	d9 05 54 95 73 00    	fld    DWORD PTR ds:0x739554
  4558cb:	d8 0d 78 95 73 00    	fmul   DWORD PTR ds:0x739578
  4558d1:	89 94 24 88 01 00 00 	mov    DWORD PTR [esp+0x188],edx
  4558d8:	de c1                	faddp  st(1),st
  4558da:	d9 9c 24 f8 00 00 00 	fstp   DWORD PTR [esp+0xf8]
  4558e1:	d9 05 74 95 73 00    	fld    DWORD PTR ds:0x739574
  4558e7:	d8 0d 5c 95 73 00    	fmul   DWORD PTR ds:0x73955c
  4558ed:	d9 05 58 95 73 00    	fld    DWORD PTR ds:0x739558
  4558f3:	d8 0d 70 95 73 00    	fmul   DWORD PTR ds:0x739570
  4558f9:	de c1                	faddp  st(1),st
  4558fb:	d9 05 6c 95 73 00    	fld    DWORD PTR ds:0x73956c
  455901:	d8 0d 54 95 73 00    	fmul   DWORD PTR ds:0x739554
  455907:	de c1                	faddp  st(1),st
  455909:	d9 9c 24 fc 00 00 00 	fstp   DWORD PTR [esp+0xfc]
  455910:	d9 05 58 95 73 00    	fld    DWORD PTR ds:0x739558
  455916:	d8 0d 64 95 73 00    	fmul   DWORD PTR ds:0x739564
  45591c:	d9 05 5c 95 73 00    	fld    DWORD PTR ds:0x73955c
  455922:	d8 0d 68 95 73 00    	fmul   DWORD PTR ds:0x739568
  455928:	c7 44 24 70 00 02 00 	mov    DWORD PTR [esp+0x70],0x200
  45592f:	00 
  455930:	bb 48 cd 72 00       	mov    ebx,0x72cd48
  455935:	de c1                	faddp  st(1),st
  455937:	d9 05 60 95 73 00    	fld    DWORD PTR ds:0x739560
  45593d:	d8 0d 54 95 73 00    	fmul   DWORD PTR ds:0x739554
  455943:	de c1                	faddp  st(1),st
  455945:	d9 9c 24 00 01 00 00 	fstp   DWORD PTR [esp+0x100]
  45594c:	83 7b 60 00          	cmp    DWORD PTR [ebx+0x60],0x0
  455950:	0f 84 f3 10 00 00    	je     0x456a49
  455956:	d9 43 50             	fld    DWORD PTR [ebx+0x50]
  455959:	d8 43 44             	fadd   DWORD PTR [ebx+0x44]
  45595c:	8b 43 5c             	mov    eax,DWORD PTR [ebx+0x5c]
  45595f:	89 84 24 18 02 00 00 	mov    DWORD PTR [esp+0x218],eax
  455966:	d9 5b 44             	fstp   DWORD PTR [ebx+0x44]
  455969:	d9 43 54             	fld    DWORD PTR [ebx+0x54]
  45596c:	d8 43 48             	fadd   DWORD PTR [ebx+0x48]
  45596f:	d9 5b 48             	fstp   DWORD PTR [ebx+0x48]
  455972:	d9 43 58             	fld    DWORD PTR [ebx+0x58]
  455975:	d8 43 4c             	fadd   DWORD PTR [ebx+0x4c]
  455978:	d9 5b 4c             	fstp   DWORD PTR [ebx+0x4c]
  45597b:	8b 4b 4c             	mov    ecx,DWORD PTR [ebx+0x4c]
  45597e:	8b 53 48             	mov    edx,DWORD PTR [ebx+0x48]
  455981:	8b 43 44             	mov    eax,DWORD PTR [ebx+0x44]
  455984:	89 4c 24 60          	mov    DWORD PTR [esp+0x60],ecx
  455988:	89 54 24 68          	mov    DWORD PTR [esp+0x68],edx
  45598c:	89 44 24 28          	mov    DWORD PTR [esp+0x28],eax
  455990:	3d 00 00 00 80       	cmp    eax,0x80000000
  455995:	76 1b                	jbe    0x4559b2
  455997:	d9 44 24 28          	fld    DWORD PTR [esp+0x28]
  45599b:	dc 05 d8 f3 58 00    	fadd   QWORD PTR ds:0x58f3d8
  4559a1:	dc 15 b8 f3 58 00    	fcom   QWORD PTR ds:0x58f3b8
  4559a7:	d9 5c 24 28          	fstp   DWORD PTR [esp+0x28]
  4559ab:	df e0                	fnstsw ax
  4559ad:	f6 c4 01             	test   ah,0x1
  4559b0:	75 e5                	jne    0x455997
  4559b2:	81 7c 24 28 00 00 b4 	cmp    DWORD PTR [esp+0x28],0x43b40000
  4559b9:	43 
  4559ba:	7c 1b                	jl     0x4559d7
  4559bc:	d9 44 24 28          	fld    DWORD PTR [esp+0x28]
  4559c0:	dc 25 d8 f3 58 00    	fsub   QWORD PTR ds:0x58f3d8
  4559c6:	dc 15 d8 f3 58 00    	fcom   QWORD PTR ds:0x58f3d8
  4559cc:	d9 5c 24 28          	fstp   DWORD PTR [esp+0x28]
  4559d0:	df e0                	fnstsw ax
  4559d2:	f6 c4 01             	test   ah,0x1
  4559d5:	74 e5                	je     0x4559bc
  4559d7:	d9 44 24 28          	fld    DWORD PTR [esp+0x28]
  4559db:	d8 0d e0 f3 58 00    	fmul   DWORD PTR ds:0x58f3e0
  4559e1:	e8 6e 62 10 00       	call   0x55bc54
  4559e6:	c7 84 24 b0 01 00 00 	mov    DWORD PTR [esp+0x1b0],0x3f800000
  4559ed:	00 00 80 3f 
  4559f1:	c1 e0 02             	shl    eax,0x2
  4559f4:	d9 80 a8 6f 5f 00    	fld    DWORD PTR [eax+0x5f6fa8]
  4559fa:	8b 88 a8 15 5f 00    	mov    ecx,DWORD PTR [eax+0x5f15a8]
  455a00:	33 c0                	xor    eax,eax
  455a02:	d9 c0                	fld    st(0)
  455a04:	89 84 24 c8 01 00 00 	mov    DWORD PTR [esp+0x1c8],eax
  455a0b:	89 84 24 bc 01 00 00 	mov    DWORD PTR [esp+0x1bc],eax
  455a12:	d9 e0                	fchs
  455a14:	89 84 24 b8 01 00 00 	mov    DWORD PTR [esp+0x1b8],eax
  455a1b:	89 84 24 b4 01 00 00 	mov    DWORD PTR [esp+0x1b4],eax
  455a22:	d9 9c 24 c4 01 00 00 	fstp   DWORD PTR [esp+0x1c4]
  455a29:	d9 9c 24 cc 01 00 00 	fstp   DWORD PTR [esp+0x1cc]
  455a30:	8b 44 24 68          	mov    eax,DWORD PTR [esp+0x68]
  455a34:	89 8c 24 c0 01 00 00 	mov    DWORD PTR [esp+0x1c0],ecx
  455a3b:	89 8c 24 d0 01 00 00 	mov    DWORD PTR [esp+0x1d0],ecx
  455a42:	89 44 24 34          	mov    DWORD PTR [esp+0x34],eax
  455a46:	3d 00 00 00 80       	cmp    eax,0x80000000
  455a4b:	76 1b                	jbe    0x455a68
  455a4d:	d9 44 24 34          	fld    DWORD PTR [esp+0x34]
  455a51:	dc 05 d8 f3 58 00    	fadd   QWORD PTR ds:0x58f3d8
  455a57:	dc 15 b8 f3 58 00    	fcom   QWORD PTR ds:0x58f3b8
  455a5d:	d9 5c 24 34          	fstp   DWORD PTR [esp+0x34]
  455a61:	df e0                	fnstsw ax
  455a63:	f6 c4 01             	test   ah,0x1
  455a66:	75 e5                	jne    0x455a4d
  455a68:	81 7c 24 34 00 00 b4 	cmp    DWORD PTR [esp+0x34],0x43b40000
  455a6f:	43 
  455a70:	7c 1b                	jl     0x455a8d
  455a72:	d9 44 24 34          	fld    DWORD PTR [esp+0x34]
  455a76:	dc 25 d8 f3 58 00    	fsub   QWORD PTR ds:0x58f3d8
  455a7c:	dc 15 d8 f3 58 00    	fcom   QWORD PTR ds:0x58f3d8
  455a82:	d9 5c 24 34          	fstp   DWORD PTR [esp+0x34]
  455a86:	df e0                	fnstsw ax
  455a88:	f6 c4 01             	test   ah,0x1
  455a8b:	74 e5                	je     0x455a72
  455a8d:	d9 44 24 34          	fld    DWORD PTR [esp+0x34]
  455a91:	d8 0d e0 f3 58 00    	fmul   DWORD PTR ds:0x58f3e0
  455a97:	e8 b8 61 10 00       	call   0x55bc54
  455a9c:	c7 84 24 3c 02 00 00 	mov    DWORD PTR [esp+0x23c],0x3f800000
  455aa3:	00 00 80 3f 
  455aa7:	c1 e0 02             	shl    eax,0x2
  455aaa:	d9 80 a8 6f 5f 00    	fld    DWORD PTR [eax+0x5f6fa8]
  455ab0:	8b 88 a8 15 5f 00    	mov    ecx,DWORD PTR [eax+0x5f15a8]
  455ab6:	33 c0                	xor    eax,eax
  455ab8:	d9 c0                	fld    st(0)
  455aba:	89 84 24 38 02 00 00 	mov    DWORD PTR [esp+0x238],eax
  455ac1:	89 84 24 34 02 00 00 	mov    DWORD PTR [esp+0x234],eax
  455ac8:	d9 e0                	fchs
  455aca:	89 84 24 30 02 00 00 	mov    DWORD PTR [esp+0x230],eax
  455ad1:	89 84 24 24 02 00 00 	mov    DWORD PTR [esp+0x224],eax
  455ad8:	d9 9c 24 20 02 00 00 	fstp   DWORD PTR [esp+0x220]
  455adf:	d9 9c 24 28 02 00 00 	fstp   DWORD PTR [esp+0x228]
  455ae6:	8d 84 24 40 02 00 00 	lea    eax,[esp+0x240]
  455aed:	8d 94 24 1c 02 00 00 	lea    edx,[esp+0x21c]
  455af4:	89 8c 24 1c 02 00 00 	mov    DWORD PTR [esp+0x21c],ecx
  455afb:	50                   	push   eax
  455afc:	89 8c 24 30 02 00 00 	mov    DWORD PTR [esp+0x230],ecx
  455b03:	52                   	push   edx
  455b04:	8d 8c 24 b8 01 00 00 	lea    ecx,[esp+0x1b8]
  455b0b:	51                   	push   ecx
  455b0c:	e8 7f 0f 00 00       	call   0x456a90
  455b11:	8b 4c 24 6c          	mov    ecx,DWORD PTR [esp+0x6c]
  455b15:	83 c4 0c             	add    esp,0xc
  455b18:	81 f9 00 00 00 80    	cmp    ecx,0x80000000
  455b1e:	89 4c 24 30          	mov    DWORD PTR [esp+0x30],ecx
  455b22:	76 1b                	jbe    0x455b3f
  455b24:	d9 44 24 30          	fld    DWORD PTR [esp+0x30]
  455b28:	dc 05 d8 f3 58 00    	fadd   QWORD PTR ds:0x58f3d8
  455b2e:	dc 15 b8 f3 58 00    	fcom   QWORD PTR ds:0x58f3b8
  455b34:	d9 5c 24 30          	fstp   DWORD PTR [esp+0x30]
  455b38:	df e0                	fnstsw ax
  455b3a:	f6 c4 01             	test   ah,0x1
  455b3d:	75 e5                	jne    0x455b24
  455b3f:	81 7c 24 30 00 00 b4 	cmp    DWORD PTR [esp+0x30],0x43b40000
  455b46:	43 
  455b47:	7c 1b                	jl     0x455b64
  455b49:	d9 44 24 30          	fld    DWORD PTR [esp+0x30]
  455b4d:	dc 25 d8 f3 58 00    	fsub   QWORD PTR ds:0x58f3d8
  455b53:	dc 15 d8 f3 58 00    	fcom   QWORD PTR ds:0x58f3d8
  455b59:	d9 5c 24 30          	fstp   DWORD PTR [esp+0x30]
  455b5d:	df e0                	fnstsw ax
  455b5f:	f6 c4 01             	test   ah,0x1
  455b62:	74 e5                	je     0x455b49
  455b64:	d9 44 24 30          	fld    DWORD PTR [esp+0x30]
  455b68:	d8 0d e0 f3 58 00    	fmul   DWORD PTR ds:0x58f3e0
  455b6e:	e8 e1 60 10 00       	call   0x55bc54
  455b73:	c7 84 24 c0 01 00 00 	mov    DWORD PTR [esp+0x1c0],0x3f800000
  455b7a:	00 00 80 3f 
  455b7e:	c1 e0 02             	shl    eax,0x2
  455b81:	d9 80 a8 6f 5f 00    	fld    DWORD PTR [eax+0x5f6fa8]
  455b87:	8b 88 a8 15 5f 00    	mov    ecx,DWORD PTR [eax+0x5f15a8]
  455b8d:	33 c0                	xor    eax,eax
  455b8f:	d9 94 24 b8 01 00 00 	fst    DWORD PTR [esp+0x1b8]
  455b96:	89 84 24 cc 01 00 00 	mov    DWORD PTR [esp+0x1cc],eax
  455b9d:	89 84 24 c4 01 00 00 	mov    DWORD PTR [esp+0x1c4],eax
  455ba4:	d9 e0                	fchs
  455ba6:	89 84 24 bc 01 00 00 	mov    DWORD PTR [esp+0x1bc],eax
  455bad:	89 84 24 b4 01 00 00 	mov    DWORD PTR [esp+0x1b4],eax
  455bb4:	d9 9c 24 c8 01 00 00 	fstp   DWORD PTR [esp+0x1c8]
  455bbb:	8d 84 24 d4 01 00 00 	lea    eax,[esp+0x1d4]
  455bc2:	8d 94 24 40 02 00 00 	lea    edx,[esp+0x240]
  455bc9:	89 8c 24 b0 01 00 00 	mov    DWORD PTR [esp+0x1b0],ecx
  455bd0:	50                   	push   eax
  455bd1:	89 8c 24 d4 01 00 00 	mov    DWORD PTR [esp+0x1d4],ecx
  455bd8:	52                   	push   edx
  455bd9:	8d 8c 24 b8 01 00 00 	lea    ecx,[esp+0x1b8]
  455be0:	51                   	push   ecx
  455be1:	e8 aa 0e 00 00       	call   0x456a90
  455be6:	d9 84 24 24 02 00 00 	fld    DWORD PTR [esp+0x224]
  455bed:	d8 8c 24 e0 01 00 00 	fmul   DWORD PTR [esp+0x1e0]
  455bf4:	83 c4 0c             	add    esp,0xc
  455bf7:	d9 9c 24 8c 01 00 00 	fstp   DWORD PTR [esp+0x18c]
  455bfe:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c05:	d8 8c 24 d8 01 00 00 	fmul   DWORD PTR [esp+0x1d8]
  455c0c:	d9 9c 24 90 01 00 00 	fstp   DWORD PTR [esp+0x190]
  455c13:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c1a:	d8 8c 24 dc 01 00 00 	fmul   DWORD PTR [esp+0x1dc]
  455c21:	d9 9c 24 94 01 00 00 	fstp   DWORD PTR [esp+0x194]
  455c28:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c2f:	d8 8c 24 e0 01 00 00 	fmul   DWORD PTR [esp+0x1e0]
  455c36:	d9 9c 24 98 01 00 00 	fstp   DWORD PTR [esp+0x198]
  455c3d:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c44:	d8 8c 24 e4 01 00 00 	fmul   DWORD PTR [esp+0x1e4]
  455c4b:	d9 9c 24 9c 01 00 00 	fstp   DWORD PTR [esp+0x19c]
  455c52:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c59:	d8 8c 24 e8 01 00 00 	fmul   DWORD PTR [esp+0x1e8]
  455c60:	d9 9c 24 a0 01 00 00 	fstp   DWORD PTR [esp+0x1a0]
  455c67:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c6e:	d8 8c 24 ec 01 00 00 	fmul   DWORD PTR [esp+0x1ec]
  455c75:	d9 9c 24 a4 01 00 00 	fstp   DWORD PTR [esp+0x1a4]
  455c7c:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c83:	d8 8c 24 f0 01 00 00 	fmul   DWORD PTR [esp+0x1f0]
  455c8a:	d9 9c 24 a8 01 00 00 	fstp   DWORD PTR [esp+0x1a8]
  455c91:	d9 84 24 18 02 00 00 	fld    DWORD PTR [esp+0x218]
  455c98:	d8 8c 24 f4 01 00 00 	fmul   DWORD PTR [esp+0x1f4]
  455c9f:	d9 9c 24 ac 01 00 00 	fstp   DWORD PTR [esp+0x1ac]
  455ca6:	d9 43 2c             	fld    DWORD PTR [ebx+0x2c]
  455ca9:	d8 8c 24 70 01 00 00 	fmul   DWORD PTR [esp+0x170]
  455cb0:	d9 43 24             	fld    DWORD PTR [ebx+0x24]
  455cb3:	d8 8c 24 68 01 00 00 	fmul   DWORD PTR [esp+0x168]
  455cba:	de c1                	faddp  st(1),st
  455cbc:	d9 43 28             	fld    DWORD PTR [ebx+0x28]
  455cbf:	d8 8c 24 6c 01 00 00 	fmul   DWORD PTR [esp+0x16c]
  455cc6:	de c1                	faddp  st(1),st
  455cc8:	d8 a4 24 f8 00 00 00 	fsub   DWORD PTR [esp+0xf8]
  455ccf:	d9 9c 24 a4 00 00 00 	fstp   DWORD PTR [esp+0xa4]
  455cd6:	d9 43 2c             	fld    DWORD PTR [ebx+0x2c]
  455cd9:	d8 8c 24 7c 01 00 00 	fmul   DWORD PTR [esp+0x17c]
  455ce0:	d9 43 24             	fld    DWORD PTR [ebx+0x24]
  455ce3:	d8 8c 24 74 01 00 00 	fmul   DWORD PTR [esp+0x174]
  455cea:	de c1                	faddp  st(1),st
  455cec:	d9 43 28             	fld    DWORD PTR [ebx+0x28]
  455cef:	d8 8c 24 78 01 00 00 	fmul   DWORD PTR [esp+0x178]
  455cf6:	de c1                	faddp  st(1),st
  455cf8:	d8 a4 24 fc 00 00 00 	fsub   DWORD PTR [esp+0xfc]
  455cff:	d9 9c 24 a8 00 00 00 	fstp   DWORD PTR [esp+0xa8]
  455d06:	d9 43 2c             	fld    DWORD PTR [ebx+0x2c]
  455d09:	d8 8c 24 88 01 00 00 	fmul   DWORD PTR [esp+0x188]
  455d10:	d9 43 24             	fld    DWORD PTR [ebx+0x24]
  455d13:	d8 8c 24 80 01 00 00 	fmul   DWORD PTR [esp+0x180]
  455d1a:	de c1                	faddp  st(1),st
  455d1c:	d9 43 28             	fld    DWORD PTR [ebx+0x28]
  455d1f:	d8 8c 24 84 01 00 00 	fmul   DWORD PTR [esp+0x184]
  455d26:	de c1                	faddp  st(1),st
  455d28:	d8 a4 24 00 01 00 00 	fsub   DWORD PTR [esp+0x100]
  455d2f:	d9 9c 24 ac 00 00 00 	fstp   DWORD PTR [esp+0xac]
  455d36:	d9 84 24 a4 01 00 00 	fld    DWORD PTR [esp+0x1a4]
  455d3d:	d8 8c 24 70 01 00 00 	fmul   DWORD PTR [esp+0x170]
  455d44:	d9 84 24 98 01 00 00 	fld    DWORD PTR [esp+0x198]
  455d4b:	d8 8c 24 6c 01 00 00 	fmul   DWORD PTR [esp+0x16c]
  455d52:	de c1                	faddp  st(1),st
  455d54:	d9 84 24 8c 01 00 00 	fld    DWORD PTR [esp+0x18c]
  455d5b:	d8 8c 24 68 01 00 00 	fmul   DWORD PTR [esp+0x168]
  455d62:	de c1                	faddp  st(1),st
  455d64:	d9 9c 24 44 01 00 00 	fstp   DWORD PTR [esp+0x144]
  455d6b:	d9 84 24 a8 01 00 00 	fld    DWORD PTR [esp+0x1a8]
  455d72:	d8 8c 24 70 01 00 00 	fmul   DWORD PTR [esp+0x170]
  455d79:	d9 84 24 9c 01 00 00 	fld    DWORD PTR [esp+0x19c]
  455d80:	d8 8c 24 6c 01 00 00 	fmul   DWORD PTR [esp+0x16c]
  455d87:	de c1                	faddp  st(1),st
  455d89:	d9 84 24 90 01 00 00 	fld    DWORD PTR [esp+0x190]
  455d90:	d8 8c 24 68 01 00 00 	fmul   DWORD PTR [esp+0x168]
  455d97:	de c1                	faddp  st(1),st
  455d99:	d9 9c 24 48 01 00 00 	fstp   DWORD PTR [esp+0x148]
  455da0:	d9 84 24 a0 01 00 00 	fld    DWORD PTR [esp+0x1a0]
  455da7:	d8 8c 24 6c 01 00 00 	fmul   DWORD PTR [esp+0x16c]
  455dae:	d9 84 24 ac 01 00 00 	fld    DWORD PTR [esp+0x1ac]
  455db5:	d8 8c 24 70 01 00 00 	fmul   DWORD PTR [esp+0x170]
  455dbc:	de c1                	faddp  st(1),st
  455dbe:	d9 84 24 94 01 00 00 	fld    DWORD PTR [esp+0x194]
  455dc5:	d8 8c 24 68 01 00 00 	fmul   DWORD PTR [esp+0x168]
  455dcc:	de c1                	faddp  st(1),st
  455dce:	d9 9c 24 4c 01 00 00 	fstp   DWORD PTR [esp+0x14c]
  455dd5:	d9 84 24 a4 01 00 00 	fld    DWORD PTR [esp+0x1a4]
  455ddc:	d8 8c 24 7c 01 00 00 	fmul   DWORD PTR [esp+0x17c]
  455de3:	d9 84 24 98 01 00 00 	fld    DWORD PTR [esp+0x198]
  455dea:	d8 8c 24 78 01 00 00 	fmul   DWORD PTR [esp+0x178]
  455df1:	de c1                	faddp  st(1),st
  455df3:	d9 84 24 8c 01 00 00 	fld    DWORD PTR [esp+0x18c]
  455dfa:	d8 8c 24 74 01 00 00 	fmul   DWORD PTR [esp+0x174]
  455e01:	de c1                	faddp  st(1),st
  455e03:	d9 9c 24 50 01 00 00 	fstp   DWORD PTR [esp+0x150]
  455e0a:	d9 84 24 a8 01 00 00 	fld    DWORD PTR [esp+0x1a8]
  455e11:	d8 8c 24 7c 01 00 00 	fmul   DWORD PTR [esp+0x17c]
  455e18:	d9 84 24 90 01 00 00 	fld    DWORD PTR [esp+0x190]
  455e1f:	d8 8c 24 74 01 00 00 	fmul   DWORD PTR [esp+0x174]
  455e26:	de c1                	faddp  st(1),st
  455e28:	d9 84 24 9c 01 00 00 	fld    DWORD PTR [esp+0x19c]
  455e2f:	d8 8c 24 78 01 00 00 	fmul   DWORD PTR [esp+0x178]
  455e36:	de c1                	faddp  st(1),st
  455e38:	d9 9c 24 54 01 00 00 	fstp   DWORD PTR [esp+0x154]
  455e3f:	d9 84 24 ac 01 00 00 	fld    DWORD PTR [esp+0x1ac]
  455e46:	d8 8c 24 7c 01 00 00 	fmul   DWORD PTR [esp+0x17c]
  455e4d:	d9 84 24 94 01 00 00 	fld    DWORD PTR [esp+0x194]
  455e54:	d8 8c 24 74 01 00 00 	fmul   DWORD PTR [esp+0x174]
  455e5b:	de c1                	faddp  st(1),st
  455e5d:	d9 84 24 a0 01 00 00 	fld    DWORD PTR [esp+0x1a0]
  455e64:	d8 8c 24 78 01 00 00 	fmul   DWORD PTR [esp+0x178]
  455e6b:	de c1                	faddp  st(1),st
  455e6d:	d9 9c 24 58 01 00 00 	fstp   DWORD PTR [esp+0x158]
  455e74:	d9 84 24 a4 01 00 00 	fld    DWORD PTR [esp+0x1a4]
  455e7b:	d8 8c 24 88 01 00 00 	fmul   DWORD PTR [esp+0x188]
  455e82:	d9 84 24 98 01 00 00 	fld    DWORD PTR [esp+0x198]
  455e89:	d8 8c 24 84 01 00 00 	fmul   DWORD PTR [esp+0x184]
  455e90:	de c1                	faddp  st(1),st
  455e92:	d9 84 24 8c 01 00 00 	fld    DWORD PTR [esp+0x18c]
  455e99:	d8 8c 24 80 01 00 00 	fmul   DWORD PTR [esp+0x180]
  455ea0:	de c1                	faddp  st(1),st
  455ea2:	d9 9c 24 5c 01 00 00 	fstp   DWORD PTR [esp+0x15c]
  455ea9:	d9 84 24 90 01 00 00 	fld    DWORD PTR [esp+0x190]
  455eb0:	d8 8c 24 80 01 00 00 	fmul   DWORD PTR [esp+0x180]
  455eb7:	d9 84 24 a8 01 00 00 	fld    DWORD PTR [esp+0x1a8]
  455ebe:	d8 8c 24 88 01 00 00 	fmul   DWORD PTR [esp+0x188]
  455ec5:	de c1                	faddp  st(1),st
  455ec7:	d9 84 24 9c 01 00 00 	fld    DWORD PTR [esp+0x19c]
  455ece:	d8 8c 24 84 01 00 00 	fmul   DWORD PTR [esp+0x184]
  455ed5:	de c1                	faddp  st(1),st
  455ed7:	d9 9c 24 60 01 00 00 	fstp   DWORD PTR [esp+0x160]
  455ede:	d9 84 24 94 01 00 00 	fld    DWORD PTR [esp+0x194]
  455ee5:	d8 8c 24 80 01 00 00 	fmul   DWORD PTR [esp+0x180]
  455eec:	d9 84 24 a0 01 00 00 	fld    DWORD PTR [esp+0x1a0]
  455ef3:	d8 8c 24 84 01 00 00 	fmul   DWORD PTR [esp+0x184]
  455efa:	de c1                	faddp  st(1),st
  455efc:	d9 84 24 ac 01 00 00 	fld    DWORD PTR [esp+0x1ac]
  455f03:	d8 8c 24 88 01 00 00 	fmul   DWORD PTR [esp+0x188]
  455f0a:	de c1                	faddp  st(1),st
  455f0c:	d9 9c 24 64 01 00 00 	fstp   DWORD PTR [esp+0x164]
  455f13:	d9 43 3c             	fld    DWORD PTR [ebx+0x3c]
  455f16:	d8 05 b8 c9 5f 00    	fadd   DWORD PTR ds:0x5fc9b8
  455f1c:	d9 9c 24 9c 00 00 00 	fstp   DWORD PTR [esp+0x9c]
  455f23:	d9 43 40             	fld    DWORD PTR [ebx+0x40]
  455f26:	d8 05 bc c9 5f 00    	fadd   DWORD PTR ds:0x5fc9bc
  455f2c:	d9 9c 24 a0 00 00 00 	fstp   DWORD PTR [esp+0xa0]
  455f33:	8b 03                	mov    eax,DWORD PTR [ebx]
  455f35:	48                   	dec    eax
  455f36:	83 f8 04             	cmp    eax,0x4
  455f39:	0f 87 0a 0b 00 00    	ja     0x456a49
  455f3f:	ff 24 85 74 6a 45 00 	jmp    DWORD PTR [eax*4+0x456a74]
  455f46:	8b 73 08             	mov    esi,DWORD PTR [ebx+0x8]
  455f49:	8b 7b 10             	mov    edi,DWORD PTR [ebx+0x10]
  455f4c:	c7 44 24 58 00 00 00 	mov    DWORD PTR [esp+0x58],0x0
  455f53:	00 
  455f54:	83 7b 04 00          	cmp    DWORD PTR [ebx+0x4],0x0
  455f58:	0f 8e eb 0a 00 00    	jle    0x456a49
  455f5e:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455f61:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  455f68:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455f6b:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  455f72:	de c1                	faddp  st(1),st
  455f74:	d9 06                	fld    DWORD PTR [esi]
  455f76:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  455f7d:	de c1                	faddp  st(1),st
  455f7f:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  455f86:	d9 9c 24 e0 00 00 00 	fstp   DWORD PTR [esp+0xe0]
  455f8d:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455f90:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  455f97:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455f9a:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  455fa1:	de c1                	faddp  st(1),st
  455fa3:	d9 06                	fld    DWORD PTR [esi]
  455fa5:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  455fac:	de c1                	faddp  st(1),st
  455fae:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  455fb5:	d9 9c 24 e4 00 00 00 	fstp   DWORD PTR [esp+0xe4]
  455fbc:	d9 46 08             	fld    DWORD PTR [esi+0x8]
  455fbf:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  455fc6:	d9 46 04             	fld    DWORD PTR [esi+0x4]
  455fc9:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  455fd0:	de c1                	faddp  st(1),st
  455fd2:	d9 06                	fld    DWORD PTR [esi]
  455fd4:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  455fdb:	de c1                	faddp  st(1),st
  455fdd:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  455fe4:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  455fea:	d9 9c 24 e8 00 00 00 	fstp   DWORD PTR [esp+0xe8]
  455ff1:	df e0                	fnstsw ax
  455ff3:	f6 c4 41             	test   ah,0x41
  455ff6:	75 3c                	jne    0x456034
  455ff8:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  455ffe:	d8 b4 24 e8 00 00 00 	fdiv   DWORD PTR [esp+0xe8]
  456005:	8b 84 24 e8 00 00 00 	mov    eax,DWORD PTR [esp+0xe8]
  45600c:	d9 84 24 e0 00 00 00 	fld    DWORD PTR [esp+0xe0]
  456013:	d8 c9                	fmul   st,st(1)
  456015:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  45601c:	d9 1f                	fstp   DWORD PTR [edi]
  45601e:	d8 8c 24 e4 00 00 00 	fmul   DWORD PTR [esp+0xe4]
  456025:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  45602c:	d9 5f 04             	fstp   DWORD PTR [edi+0x4]
  45602f:	89 47 08             	mov    DWORD PTR [edi+0x8],eax
  456032:	eb 07                	jmp    0x45603b
  456034:	c7 47 08 00 00 80 bf 	mov    DWORD PTR [edi+0x8],0xbf800000
  45603b:	8d 8c 24 b0 00 00 00 	lea    ecx,[esp+0xb0]
  456042:	8b 07                	mov    eax,DWORD PTR [edi]
  456044:	8b 57 04             	mov    edx,DWORD PTR [edi+0x4]
  456047:	8b 6f 08             	mov    ebp,DWORD PTR [edi+0x8]
  45604a:	89 01                	mov    DWORD PTR [ecx],eax
  45604c:	89 51 04             	mov    DWORD PTR [ecx+0x4],edx
  45604f:	89 69 08             	mov    DWORD PTR [ecx+0x8],ebp
  456052:	83 bc 24 b8 00 00 00 	cmp    DWORD PTR [esp+0xb8],0x0
  456059:	00 
  45605a:	0f 8e e8 00 00 00    	jle    0x456148
  456060:	b8 00 00 00 80       	mov    eax,0x80000000
  456065:	39 84 24 b0 00 00 00 	cmp    DWORD PTR [esp+0xb0],eax
  45606c:	0f 87 d6 00 00 00    	ja     0x456148
  456072:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [esp+0xb0]
  456079:	39 0d c0 c9 5f 00    	cmp    DWORD PTR ds:0x5fc9c0,ecx
  45607f:	0f 82 c3 00 00 00    	jb     0x456148
  456085:	39 84 24 b4 00 00 00 	cmp    DWORD PTR [esp+0xb4],eax
  45608c:	0f 87 b6 00 00 00    	ja     0x456148
  456092:	8b 84 24 b4 00 00 00 	mov    eax,DWORD PTR [esp+0xb4]
  456099:	39 05 c4 c9 5f 00    	cmp    DWORD PTR ds:0x5fc9c4,eax
  45609f:	0f 82 a3 00 00 00    	jb     0x456148
  4560a5:	8b 84 24 b8 00 00 00 	mov    eax,DWORD PTR [esp+0xb8]
  4560ac:	89 84 24 90 00 00 00 	mov    DWORD PTR [esp+0x90],eax
  4560b3:	d9 84 24 90 00 00 00 	fld    DWORD PTR [esp+0x90]
  4560ba:	db 5c 24 10          	fistp  DWORD PTR [esp+0x10]
  4560be:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4560c2:	c1 f8 06             	sar    eax,0x6
  4560c5:	83 e8 53             	sub    eax,0x53
  4560c8:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  4560cc:	79 08                	jns    0x4560d6
  4560ce:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  4560d5:	00 
  4560d6:	83 7c 24 10 3f       	cmp    DWORD PTR [esp+0x10],0x3f
  4560db:	7e 08                	jle    0x4560e5
  4560dd:	c7 44 24 10 3f 00 00 	mov    DWORD PTR [esp+0x10],0x3f
  4560e4:	00 
  4560e5:	b8 3f 00 00 00       	mov    eax,0x3f
  4560ea:	2b 44 24 10          	sub    eax,DWORD PTR [esp+0x10]
  4560ee:	89 44 24 10          	mov    DWORD PTR [esp+0x10],eax
  4560f2:	c1 64 24 10 01       	shl    DWORD PTR [esp+0x10],0x1
  4560f7:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
  4560fb:	8b e8                	mov    ebp,eax
  4560fd:	8b c8                	mov    ecx,eax
  4560ff:	c1 e1 10             	shl    ecx,0x10
  456102:	81 cd 00 00 ff ff    	or     ebp,0xffff0000
  456108:	c1 e5 08             	shl    ebp,0x8
  45610b:	0b e9                	or     ebp,ecx
  45610d:	0b e8                	or     ebp,eax
  45610f:	e8 cc 25 fd ff       	call   0x4286e0
  456114:	8b 8c 24 b0 00 00 00 	mov    ecx,DWORD PTR [esp+0xb0]
  45611b:	8b 94 24 b4 00 00 00 	mov    edx,DWORD PTR [esp+0xb4]
  456122:	89 08                	mov    DWORD PTR [eax],ecx
  456124:	33 c9                	xor    ecx,ecx
  456126:	89 50 04             	mov    DWORD PTR [eax+0x4],edx
  456129:	c7 40 08 00 00 00 3f 	mov    DWORD PTR [eax+0x8],0x3f000000
  456130:	c7 40 0c 00 00 00 40 	mov    DWORD PTR [eax+0xc],0x40000000
  456137:	89 48 18             	mov    DWORD PTR [eax+0x18],ecx
  45613a:	89 48 1c             	mov    DWORD PTR [eax+0x1c],ecx
  45613d:	89 68 10             	mov    DWORD PTR [eax+0x10],ebp
  456140:	89 48 14             	mov    DWORD PTR [eax+0x14],ecx
  456143:	e8 b8 25 fd ff       	call   0x428700
  456148:	83 c6 0c             	add    esi,0xc
  45614b:	83 c7 0c             	add    edi,0xc
  45614e:	ff 44 24 58          	inc    DWORD PTR [esp+0x58]
  456152:	8b 44 24 58          	mov    eax,DWORD PTR [esp+0x58]
  456156:	39 43 04             	cmp    DWORD PTR [ebx+0x4],eax
  456159:	0f 8f ff fd ff ff    	jg     0x455f5e
  45615f:	e9 e5 08 00 00       	jmp    0x456a49
  456164:	c7 44 24 24 00 00 02 	mov    DWORD PTR [esp+0x24],0x3f020000
  45616b:	3f 
  45616c:	8b 43 18             	mov    eax,DWORD PTR [ebx+0x18]
  45616f:	85 c0                	test   eax,eax
  456171:	74 07                	je     0x45617a
  456173:	83 f8 01             	cmp    eax,0x1
  456176:	74 0c                	je     0x456184
  456178:	eb 12                	jmp    0x45618c
  45617a:	c7 44 24 24 00 00 00 	mov    DWORD PTR [esp+0x24],0x3c000000
  456181:	3c 
  456182:	eb 08                	jmp    0x45618c
  456184:	c7 44 24 24 00 00 84 	mov    DWORD PTR [esp+0x24],0x3e840000
  45618b:	3e 
  45618c:	8b 43 08             	mov    eax,DWORD PTR [ebx+0x8]
  45618f:	d9 40 0c             	fld    DWORD PTR [eax+0xc]
  456192:	d8 20                	fsub   DWORD PTR [eax]
  456194:	d9 e1                	fabs
  456196:	d9 40 14             	fld    DWORD PTR [eax+0x14]
  456199:	d8 60 08             	fsub   DWORD PTR [eax+0x8]
  45619c:	d9 e1                	fabs
  45619e:	d8 d9                	fcomp  st(1)
  4561a0:	df e0                	fnstsw ax
  4561a2:	d9 44 24 24          	fld    DWORD PTR [esp+0x24]
  4561a6:	d8 05 04 f4 58 00    	fadd   DWORD PTR ds:0x58f404
  4561ac:	d9 44 24 24          	fld    DWORD PTR [esp+0x24]
  4561b0:	d8 05 08 f4 58 00    	fadd   DWORD PTR ds:0x58f408
  4561b6:	9e                   	sahf
  4561b7:	8b 43 10             	mov    eax,DWORD PTR [ebx+0x10]
  4561ba:	d9 5c 24 24          	fstp   DWORD PTR [esp+0x24]
  4561be:	d8 25 08 f4 58 00    	fsub   DWORD PTR ds:0x58f408
  4561c4:	8d 0c 45 02 00 00 00 	lea    ecx,[eax*2+0x2]
  4561cb:	51                   	push   ecx
  4561cc:	d9 5c 24 54          	fstp   DWORD PTR [esp+0x54]
  4561d0:	dd d8                	fstp   st(0)
  4561d2:	e8 89 25 fd ff       	call   0x428760
  4561d7:	8b 4b 10             	mov    ecx,DWORD PTR [ebx+0x10]
  4561da:	89 84 24 90 00 00 00 	mov    DWORD PTR [esp+0x90],eax
  4561e1:	83 c4 04             	add    esp,0x4
  4561e4:	8d 04 49             	lea    eax,[ecx+ecx*2]
  4561e7:	03 c0                	add    eax,eax
  4561e9:	33 ff                	xor    edi,edi
  4561eb:	50                   	push   eax
  4561ec:	e8 7f 25 fd ff       	call   0x428770
  4561f1:	89 44 24 50          	mov    DWORD PTR [esp+0x50],eax
  4561f5:	83 c4 04             	add    esp,0x4
  4561f8:	8b 53 08             	mov    edx,DWORD PTR [ebx+0x8]
  4561fb:	8b 73 0c             	mov    esi,DWORD PTR [ebx+0xc]
  4561fe:	39 7b 04             	cmp    DWORD PTR [ebx+0x4],edi
  456201:	0f 8e ee 00 00 00    	jle    0x4562f5
  456207:	b9 00 00 80 bf       	mov    ecx,0xbf800000
  45620c:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45620f:	d8 8c 24 48 01 00 00 	fmul   DWORD PTR [esp+0x148]
  456216:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456219:	d8 8c 24 4c 01 00 00 	fmul   DWORD PTR [esp+0x14c]
  456220:	de c1                	faddp  st(1),st
  456222:	d9 02                	fld    DWORD PTR [edx]
  456224:	d8 8c 24 44 01 00 00 	fmul   DWORD PTR [esp+0x144]
  45622b:	de c1                	faddp  st(1),st
  45622d:	d8 84 24 a4 00 00 00 	fadd   DWORD PTR [esp+0xa4]
  456234:	d9 9c 24 d4 00 00 00 	fstp   DWORD PTR [esp+0xd4]
  45623b:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45623e:	d8 8c 24 54 01 00 00 	fmul   DWORD PTR [esp+0x154]
  456245:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456248:	d8 8c 24 58 01 00 00 	fmul   DWORD PTR [esp+0x158]
  45624f:	de c1                	faddp  st(1),st
  456251:	d9 02                	fld    DWORD PTR [edx]
  456253:	d8 8c 24 50 01 00 00 	fmul   DWORD PTR [esp+0x150]
  45625a:	de c1                	faddp  st(1),st
  45625c:	d8 84 24 a8 00 00 00 	fadd   DWORD PTR [esp+0xa8]
  456263:	d9 9c 24 d8 00 00 00 	fstp   DWORD PTR [esp+0xd8]
  45626a:	d9 42 04             	fld    DWORD PTR [edx+0x4]
  45626d:	d8 8c 24 60 01 00 00 	fmul   DWORD PTR [esp+0x160]
  456274:	d9 42 08             	fld    DWORD PTR [edx+0x8]
  456277:	d8 8c 24 64 01 00 00 	fmul   DWORD PTR [esp+0x164]
  45627e:	de c1                	faddp  st(1),st
  456280:	d9 02                	fld    DWORD PTR [edx]
  456282:	d8 8c 24 5c 01 00 00 	fmul   DWORD PTR [esp+0x15c]
  456289:	de c1                	faddp  st(1),st
  45628b:	d8 84 24 ac 00 00 00 	fadd   DWORD PTR [esp+0xac]
  456292:	dc 15 e8 f3 58 00    	fcom   QWORD PTR ds:0x58f3e8
  456298:	d9 9c 24 dc 00 00 00 	fstp   DWORD PTR [esp+0xdc]
  45629f:	df e0                	fnstsw ax
  4562a1:	f6 c4 41             	test   ah,0x41
  4562a4:	75 3c                	jne    0x4562e2
  4562a6:	d9 05 84 95 73 00    	fld    DWORD PTR ds:0x739584
  4562ac:	d8 b4 24 dc 00 00 00 	fdiv   DWORD PTR [esp+0xdc]
  4562b3:	8b 84 24 dc 00 00 00 	mov    eax,DWORD PTR [esp+0xdc]
  4562ba:	d9 84 24 d4 00 00 00 	fld    DWORD PTR [esp+0xd4]
  4562c1:	d8 c9                	fmul   st,st(1)
  4562c3:	d8 84 24 9c 00 00 00 	fadd   DWORD PTR [esp+0x9c]
  4562ca:	d9 1e                	fstp   DWORD PTR [esi]
  4562cc:	d8 8c 24 d8 00 00 00 	fmul   DWORD PTR [esp+0xd8]
  4562d3:	d8 ac 24 a0 00 00 00 	fsubr  DWORD PTR [esp+0xa0]
  4562da:	d9 5e 04             	fstp   DWORD PTR [esi+0x4]
  4562dd:	89 46 08             	mov    DWORD PTR [esi+0x8],eax
  4562e0:	eb 03                	jmp    0x4562e5
  4562e2:	89 4e 08             	mov    DWORD PTR [esi+0x8],ecx
  4562e5:	47                   	inc    edi
  4562e6:	83 c2 0c             	add    edx,0xc
  4562e9:	83 c6 0c             	add    esi,0xc
  4562ec:	39 7b 04             	cmp    DWORD PTR [ebx+0x4],edi
  4562ef:	0f 8f 17 ff ff ff    	jg     0x45620c
  4562f5:	81 bc 24 ac 00 00 00 	cmp    DWORD PTR [esp+0xac],0x41200000
  4562fc:	00 00 20 41 
