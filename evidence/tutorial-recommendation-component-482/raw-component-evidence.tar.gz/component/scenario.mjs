import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { writeFileSync } from 'node:fs'
export default async function ({ page, browser, url, output }) {
  const checks = [], key = 'populous-tutorial-recommendation-v1'
  const passed = name => { checks.push(name); writeFileSync(resolve(output, 'progress.json'), JSON.stringify(checks, null, 2) + '\n') }
  const button = (p, name) => p.getByRole('button', { name, exact: true })
  const prompt = p => p.locator('[data-original-tutorial-recommendation]')
  const state = async p => JSON.parse(await p.locator('#callback-state').textContent())
  const open = async p => { await button(p, 'New Game').click(); await prompt(p).waitFor() }
  const stored = p => p.evaluate(key => localStorage.getItem(key), key)
  await button(page, 'New Game').waitFor()
  assert.equal(await prompt(page).count(), 0)
  assert.equal(await stored(page), null)
  for (const [width, height] of [[640, 480], [1920, 1080], [900, 360]]) {
    await page.setViewportSize({ width, height }); await open(page)
    assert.equal(await button(page, 'Back').evaluate(el => el === document.activeElement), true)
    const boxes = await prompt(page).locator('h2 > span > span, button').evaluateAll(nodes => nodes.map(el => {
      const b = el.getBoundingClientRect(); return { left: b.left, right: b.right, top: b.top, bottom: b.bottom }
    }))
    for (const b of boxes) assert.ok(b.left >= -1 && b.top >= -1 && b.right <= width + 1 && b.bottom <= height + 1, JSON.stringify(b))
    await page.screenshot({ path: resolve(output, `component-${width}x${height}.png`) })
    await page.keyboard.press('Escape'); await page.keyboard.press('Escape')
    await button(page, 'New Game').waitFor()
    assert.equal(await button(page, 'New Game').evaluate(el => el === document.activeElement), true)
    assert.equal(await stored(page), null)
    await open(page); await button(page, 'Back').click(); await button(page, 'New Game').waitFor()
    assert.equal(await stored(page), null)
    assert.deepEqual((await state(page)).counts, { tutorial: 0, campaign: 0 })
  }
  passed('component-native-wide-short-paragraph-and-button-bounds-cancel-focus')
  await open(page); await button(page, 'No').click(); await button(page, 'Return to fixture menu').waitFor()
  assert.deepEqual((await state(page)).counts, { tutorial: 0, campaign: 1 }); assert.equal(await stored(page), 'answered')
  await page.reload({ waitUntil: 'domcontentloaded' }); await button(page, 'New Game').click()
  await button(page, 'Return to fixture menu').waitFor(); assert.equal(await prompt(page).count(), 0)
  passed('component-no-callback-and-reload-persistence')
  const fresh = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 })
  try {
    const p = await fresh.newPage(); await p.goto(url, { waitUntil: 'domcontentloaded' }); await open(p)
    await button(p, 'Yes').click(); await button(p, 'Return to fixture menu').waitFor()
    assert.deepEqual((await state(p)).counts, { tutorial: 1, campaign: 0 }); assert.equal(await stored(p), 'answered')
    passed('component-yes-callback-only-not-tutorial-loading')
  } finally { await fresh.close() }
  const blocked = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 })
  try {
    await blocked.addInitScript(() => Object.defineProperty(window, 'localStorage', { get() { throw new DOMException('Blocked', 'SecurityError') } }))
    const p = await blocked.newPage(); const errors = []; p.on('pageerror', e => errors.push(String(e)))
    await p.goto(url, { waitUntil: 'domcontentloaded' }); await open(p); await button(p, 'No').click()
    await button(p, 'Return to fixture menu').click(); await button(p, 'New Game').click()
    await button(p, 'Return to fixture menu').waitFor(); assert.equal(await prompt(p).count(), 0)
    await p.reload({ waitUntil: 'domcontentloaded' }); await open(p); assert.deepEqual(errors, [])
    passed('component-blocked-storage-remount-and-reload')
  } finally { await blocked.close() }
  const fallback = await browser.newContext({ viewport: { width: 640, height: 480 }, deviceScaleFactor: 1 })
  try {
    let blockedFonts = 0
    await fallback.route('**/original/frontend/felo33we.png', route => { blockedFonts++; return route.abort('failed') })
    const p = await fallback.newPage(); await p.goto(url, { waitUntil: 'domcontentloaded' }); await open(p)
    await prompt(p).locator('h2').getByText('As this is your first time playing', { exact: true }).waitFor()
    assert.ok(blockedFonts > 0)
    await p.screenshot({ path: resolve(output, 'component-low-font-fallback.png') })
    await button(p, 'Back').click(); assert.equal(await stored(p), null)
    passed('component-low-font-fallback-and-back')
  } finally { await fallback.close() }
  return { checks, limits: ['Supplemental component rendering/callback evidence only; no actual Home, Tutorial loading, campaign scene or gameplay validation'] }
}
