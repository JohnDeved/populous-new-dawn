import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'

export default async function({context,browser,url,output,receipt}) {
  // Fresh reduced-motion context removes unrelated interval draws from timings.
  await context.close()
  const child=await browser.newContext({viewport:{width:640,height:480},reducedMotion:'reduce'})
  try {
    const page=await child.newPage();page.setDefaultTimeout(25000)
    page.on('pageerror',error=>receipt.errors.push(String(error)))
    const main=page.getByRole('dialog',{name:'Main menu',exact:true})
    await page.goto(url,{waitUntil:'networkidle'});await main.waitFor()
    await page.waitForFunction(()=>document.querySelector('[data-original-main-menu] nav button i'))
    const settle=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))))
    await settle()
    await page.evaluate(()=>{
      const q=globalThis.__menuResizeQa={resizes:[],clicks:[],keys:[],optionEntries:0,longTasks:[]}
      addEventListener('resize',()=>q.resizes.push({at:performance.now(),width:innerWidth,height:innerHeight}))
      addEventListener('click',e=>q.clicks.push({label:e.target.closest('button')?.getAttribute('aria-label'),at:performance.now(),eventTimestamp:e.timeStamp}),true)
      addEventListener('keydown',e=>q.keys.push({key:e.key,at:performance.now(),eventTimestamp:e.timeStamp}),true)
      let options=false
      q.mutations=new MutationObserver(()=>{
        const next=!!document.querySelector('[data-original-main-menu] [data-original-options]')
        if(next&&!options)q.optionEntries++
        options=next
      })
      q.mutations.observe(document.querySelector('[data-original-main-menu]'),{childList:true,subtree:true})
      if(PerformanceObserver.supportedEntryTypes.includes('longtask')){
        q.observer=new PerformanceObserver(list=>{for(const e of list.getEntries())q.longTasks.push({startTime:e.startTime,duration:e.duration})})
        q.observer.observe({type:'longtask',buffered:false})
      }
    })
    const widths=[901,1025,1187,1365,1537]
    const start=await page.evaluate(()=>performance.now())
    // No application settle between real viewport changes. Native resize events
    // can coalesce; every intermediate backing width is not required to paint.
    for(const width of widths)await page.setViewportSize({width,height:480})
    const clickRequested=await page.evaluate(()=>performance.now())
    await page.mouse.click(1537/2,273.5)
    await main.getByRole('region',{name:'Options',exact:true}).waitFor()
    await settle()
    const opened=await page.evaluate(()=>performance.now())
    await page.waitForFunction(()=>document.querySelector('[data-original-main-menu] canvas')?.width===1538)
    const finalLayout=await main.evaluate(el=>{
      const c=el.querySelector('canvas'),f=c.parentElement,b=f.getBoundingClientRect()
      return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},frame:{x:b.x,y:b.y,width:b.width,height:b.height},canvas:{width:c.width,height:c.height},optionsRegions:el.querySelectorAll('[data-original-options]').length}
    })
    assert.deepEqual(finalLayout.viewport,{width:1537,height:480,dpr:1})
    assert.deepEqual(finalLayout.canvas,{width:1538,height:480});assert.equal(finalLayout.optionsRegions,1)
    await page.keyboard.press('Escape');await main.getByRole('button',{name:'Options',exact:true}).waitFor()
    assert.equal(await page.evaluate(()=>document.activeElement?.getAttribute('aria-label')),'Options')
    await page.waitForTimeout(250);await settle()
    const events=await page.evaluate(()=>{const q=globalThis.__menuResizeQa;q.mutations.disconnect();q.observer?.disconnect();return {resizes:q.resizes,clicks:q.clicks,keys:q.keys,optionEntries:q.optionEntries,longTasks:q.longTasks}})
    assert.equal(events.clicks.length,1);assert.equal(events.clicks[0].label,'Options');assert.equal(events.optionEntries,1)
    assert.deepEqual(events.keys.map(e=>e.key),['Escape'])
    assert.equal(await main.getByRole('region',{name:'Options',exact:true}).count(),0)
    assert.equal(await main.locator('nav button').count(),9)
    const burst={widths,height:480,start,clickRequested,opened,elapsedBurstToOptionsMs:opened-start,clickRequestToOptionsMs:opened-clickRequested,finalLayout,events,latePanelOrDuplicateClick:false}
    writeFileSync(resolve(output,'burst.json'),JSON.stringify(burst,null,2)+'\n')
    const cdp=await child.newCDPSession(page)
    await cdp.send('Performance.enable')
    const metrics=async()=>Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map(m=>[m.name,m.value]))
    const draws=[]
    for(let i=0;i<6;i++){
      const before=await metrics(),start=await page.evaluate(()=>performance.now())
      await page.mouse.move(1537/2-128+i*32,90)
      await settle()
      const end=await page.evaluate(()=>performance.now()),after=await metrics()
      const data=await main.locator('canvas').evaluate(c=>({width:c.width,height:c.height,url:c.toDataURL()}))
      assert.equal(data.width,1538);assert.equal(data.height,480)
      draws.push({pointer:{x:1537/2-128+i*32,y:90},elapsedTwoAnimationFramesMs:end-start,scriptDurationMs:(after.ScriptDuration-before.ScriptDuration)*1000,taskDurationMs:(after.TaskDuration-before.TaskDuration)*1000,canvasSha256:createHash('sha256').update(data.url).digest('hex')})
    }
    assert.equal(new Set(draws.map(d=>d.canvasSha256)).size,draws.length,'real pointer changes must redraw native shadows')
    await cdp.detach()
    const median=key=>draws.map(d=>d[key]).sort((a,b)=>a-b).slice(2,4).reduce((a,b)=>a+b)/2
    const cachedDraw={logicalWidth:1538,samples:draws,medianScriptDurationMs:median('scriptDurationMs'),medianTaskDurationMs:median('taskDurationMs'),medianElapsedTwoAnimationFramesMs:median('elapsedTwoAnimationFramesMs'),limit:'CDP renderer ScriptDuration/TaskDuration deltas include real pointer dispatch, React work and observation. They are not isolated compositor-only timings. Wall time also includes IPC and two animation-frame boundaries.'}
    writeFileSync(resolve(output,'cached-draw.json'),JSON.stringify(cachedDraw,null,2)+'\n')
    assert.deepEqual(receipt.errors,[])
    return {burst,cachedDraw,baseline:{status:'omitted',sourceCommit:'d5768f9dd957a65c76c12a568a92d32ff164cac5',reason:'Retained baseline fixture imports current checkout. Its app/frontend-composition.ts, app/original-main-menu.tsx and package.json no longer match the baseline source manifest; baseline cannot be rerun without a separate verified source snapshot.'},limits:['Actual Home in a fresh reduced-motion context; no app callbacks or scene state replaced.','Event and mutation observers are read-only telemetry. Viewport resize events can coalesce.','Single physical Options click, one observed Options-region entry, Escape return focus, and no late entry/duplicate click after250ms.','Headless software renderer measurements; no hardware latency or native runtime parity claim.']}
  }finally{await child.close()}
}
