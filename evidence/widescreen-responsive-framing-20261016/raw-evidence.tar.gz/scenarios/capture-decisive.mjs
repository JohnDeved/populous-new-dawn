import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'

// Load with the existing actual-Home runner. This observes production DOM and
// canvas pixels only; it never substitutes app code, scene state or callbacks.
export default async function({page,output,receipt}) {
  const main=page.getByRole('dialog',{name:'Main menu',exact:true})
  await main.waitFor()
  await page.emulateMedia({reducedMotion:'reduce'})
  await page.waitForFunction(()=>document.querySelector('[data-original-main-menu] nav button i'))
  const captures=[]
  for (const [width,height] of [[640,480],[641,480],[660,480],[720,480],[800,480],[1920,1080],[3440,1440],[3840,1080]]) {
    await page.setViewportSize({width,height})
    await page.mouse.move(-5,-5)
    await main.getByRole('button',{name:'New Game',exact:true}).focus()
    await page.keyboard.press('Home')
    await page.waitForTimeout(200)
    const state=await main.evaluate(el=>{
      const canvas=el.querySelector('canvas'),frame=canvas.parentElement,b=frame.getBoundingClientRect(),scale=b.width/640
      const bounds=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,logicalX:(r.x-b.x)/scale,logicalY:(r.y-b.y)/scale}}
      return {
        viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},
        frame:bounds(frame),canvas:{bounds:bounds(canvas),width:canvas.width,height:canvas.height},
        title:bounds(el.querySelector('h1 span')),
        buttons:[...el.querySelectorAll('nav button')].map(e=>{
          const r=e.getBoundingClientRect(),at=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)
          return {label:e.getAttribute('aria-label'),ariaDisabled:e.getAttribute('aria-disabled'),reachable:at===e||e.contains(at),...bounds(e)}
        }),
        active:document.activeElement?.getAttribute('aria-label'),canvasURL:canvas.toDataURL(),
        document:{scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight}
      }
    })
    assert.equal(state.active,'New Game')
    assert.equal(state.viewport.dpr,1)
    assert.equal(state.buttons.length,9)
    for(const b of state.buttons) {
      assert.ok(b.x>=-.01&&b.y>=-.01&&b.x+b.width<=width+.01&&b.y+b.height<=height+.01,`${b.label} outside ${width}x${height}`)
      assert.equal(b.reachable,true,`${b.label} unreachable at ${width}x${height}`)
    }
    state.canvasSha256=createHash('sha256').update(state.canvasURL).digest('hex')
    delete state.canvasURL
    await page.evaluate(()=>document.activeElement?.blur())
    await page.waitForTimeout(80)
    const image=`main-unfocused-${width}x${height}.png`
    await page.screenshot({path:resolve(output,image)})
    captures.push({...state,image})
    writeFileSync(resolve(output,'captures.json'),JSON.stringify(captures,null,2)+'\n')
  }
  assert.deepEqual(receipt.errors,[])
  return {checks:captures,limits:[
    'Actual production Home via plain React/Vite; no Vinext/Cloudflare/RSC serving or hydration claim.',
    'Paired unfocused filenames and keyboard-static preparation match retained baseline convention.',
    'The reduced-motion setting is applied after initial page load; separate fresh-context validation must prove reduced-motion behavior.',
    'This cheap matrix is a visual rejection gate only, not the complete behavior, fallback, DPR or standard check/build suite.',
    'Headless software rendering does not certify hardware performance or native full-frame parity.'
  ]}
}
