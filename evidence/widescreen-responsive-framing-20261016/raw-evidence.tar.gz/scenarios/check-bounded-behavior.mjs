import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'

export default async function({page,browser,url,output,receipt}) {
  const results=[]
  const record=(name,details)=>{results.push({name,details});writeFileSync(resolve(output,'behavior.json'),JSON.stringify(results,null,2)+'\n')}
  const main=p=>p.getByRole('dialog',{name:'Main menu',exact:true})
  const button=(p,name)=>main(p).getByRole('button',{name,exact:true})
  const active=p=>p.evaluate(()=>document.activeElement?.getAttribute('aria-label'))
  const settle=p=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))))
  const ready=async p=>{await main(p).waitFor();await p.waitForFunction(()=>document.querySelector('[data-original-main-menu] nav button i'));await settle(p)}
  const layout=p=>main(p).evaluate(el=>{
    const canvas=el.querySelector('canvas'),frame=canvas.parentElement,b=frame.getBoundingClientRect(),scale=b.width/640
    const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}}
    return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},scale,frame:rect(frame),
      canvas:{bounds:rect(canvas),width:canvas.width,height:canvas.height},title:rect(el.querySelector('h1 span')),
      buttons:[...el.querySelectorAll('nav button')].map(e=>{const r=e.getBoundingClientRect(),at=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return {label:e.getAttribute('aria-label'),reachable:at===e||e.contains(at),...rect(e)}}),
      document:{width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight}}
  })
  const assertLayout=l=>{
    assert.equal(l.buttons.length,9)
    assert.equal(l.canvas.width,Math.max(640,2*Math.ceil(l.viewport.width/(2*l.scale))))
    assert.equal(l.canvas.height,480)
    for(const b of l.buttons){assert.ok(b.x>=-.01&&b.y>=-.01&&b.x+b.width<=l.viewport.width+.01&&b.y+b.height<=l.viewport.height+.01,`${b.label} clipped`);assert.equal(b.reachable,true,`${b.label} unreachable`)}
    assert.ok(l.document.width<=l.viewport.width&&l.document.height<=l.viewport.height,'document overflow')
  }
  const returnFrom=async(p,label,method)=>{
    await button(p,label).focus();await p.keyboard.press('Enter')
    if(label==='Options')await main(p).getByRole('region',{name:'Options',exact:true}).waitFor()
    else await p.locator('[data-original-quit-menu]').waitFor()
    if(method==='Escape')await p.keyboard.press('Escape')
    else if(method==='keyboard No'){await button(p,'No').focus();await p.keyboard.press('Space')}
    else await button(p,method).click()
    await button(p,label).waitFor();assert.equal(await active(p),label)
  }
  await ready(page)
  // Observation only: browser timestamps include viewport IPC, React resize,
  // composition and two animation-frame boundaries, not a hardware frame SLA.
  await page.evaluate(()=>{
    globalThis.__menuQaLongTasks=[]
    if(PerformanceObserver.supportedEntryTypes.includes('longtask')){
      globalThis.__menuQaObserver=new PerformanceObserver(list=>{for(const e of list.getEntries())globalThis.__menuQaLongTasks.push({startTime:e.startTime,duration:e.duration})})
      globalThis.__menuQaObserver.observe({type:'longtask',buffered:false})
    }
  })
  const resize=[]
  for(const [width,height] of [[1920,1080],[3440,1440],[3840,1080]]){
    const before=await page.evaluate(()=>performance.now())
    await page.setViewportSize({width,height})
    await page.waitForFunction(([w,h])=>{const c=document.querySelector('[data-original-main-menu] canvas');return innerWidth===w&&innerHeight===h&&c?.width===Math.max(640,2*Math.ceil(w/(2*Math.min(w/640,h/480))))},[width,height])
    await settle(page)
    const after=await page.evaluate(()=>performance.now()),l=await layout(page);assertLayout(l)
    const longTasks=await page.evaluate(([from,to])=>globalThis.__menuQaLongTasks.filter(e=>e.startTime>=from&&e.startTime<=to),[before,after])
    resize.push({viewport:{width,height},logicalWidth:l.canvas.width,elapsedToTwoAnimationFramesMs:after-before,longTasks})
  }
  await page.evaluate(()=>globalThis.__menuQaObserver?.disconnect())
  record('observed cold browser resize',resize)
  const odd=[]
  for(const [width,height] of [[639,480],[640,480],[641,480],[641,481],[1023,767],[1280,480],[768,1024]]){
    await page.setViewportSize({width,height});await page.mouse.move(-5,-5)
    await button(page,'New Game').focus();await page.keyboard.press('Home');await settle(page)
    const l=await layout(page);assertLayout(l);odd.push(l)
  }
  record('odd-size portrait and short control bounds',odd)
  const routes=[]
  for(const [width,height] of [[641,480],[1280,480],[3840,1080]]){
    await page.setViewportSize({width,height});await page.mouse.move(-5,-5)
    await button(page,'New Game').focus();await page.keyboard.press('Home')
    for(const [key,expected]of [['ArrowUp','Quit'],['ArrowDown','New Game'],['End','Quit'],['Home','New Game'],['Tab','Tutorial'],['Shift+Tab','New Game']]){await page.keyboard.press(key);assert.equal(await active(page),expected)}
    await button(page,'Options').hover();await settle(page)
    assert.match(await button(page,'Options').locator('i').first().evaluate(e=>e.style.backgroundImage),/fehi33we/)
    assert.equal(await active(page),'New Game','hover must not steal keyboard focus')
    assertLayout(await layout(page))
    if(width===1280)await page.screenshot({path:resolve(output,'main-hover-options-1280x480.png')})
    for(const [label,method]of [['Options','Back'],['Options','Escape'],['Options','Back'],['Quit','No'],['Quit','Back'],['Quit','keyboard No'],['Quit','Escape'],['Quit','Back']]){
      await returnFrom(page,label,method);routes.push({viewport:{width,height},label,method,returnedFocus:await active(page)})
    }
    for(const label of ['Load Game','Multiplayer','Rolling Demo','Credits','Coming Soon']){
      assert.equal(await button(page,label).getAttribute('aria-disabled'),'true')
      await button(page,label).click();assert.equal(await main(page).locator('nav button').count(),9)
    }
  }
  record('keyboard wrap hover alignment unavailable rows and repeated panel return',routes)
  let context
  const dpr=[]
  try{
    context=await browser.newContext({viewport:{width:641,height:480},deviceScaleFactor:2,reducedMotion:'reduce'})
    const p=await context.newPage();p.on('pageerror',error=>receipt.errors.push(String(error)))
    await p.goto(url,{waitUntil:'networkidle'});await ready(p)
    assert.equal(await p.evaluate(()=>devicePixelRatio),2)
    assert.equal(await p.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),true)
    for(const [width,height]of [[641,480],[641,481],[1920,1080]]){
      await p.setViewportSize({width,height});await settle(p)
      const l=await layout(p);assertLayout(l);assert.equal(l.viewport.dpr,2)
      dpr.push(l)
      if(width===641&&height===480){
        await button(p,'New Game').focus();await p.keyboard.press('Home');await settle(p)
        const png=await p.screenshot({path:resolve(output,'main-focused-641x480-dpr2.png')})
        assert.equal(png.readUInt32BE(16),1282);assert.equal(png.readUInt32BE(20),960)
        l.screenshot={width:1282,height:960}
      }
    }
    // Real pointer input, with reduced motion selected before the app mounted.
    await p.mouse.move(959,520);await settle(p)
    const before=await main(p).locator('canvas').evaluate(c=>c.toDataURL())
    await p.waitForTimeout(350)
    assert.equal(await main(p).locator('canvas').evaluate(c=>c.toDataURL()),before)
    for(const l of dpr){
      const base=odd.find(x=>x.viewport.width===l.viewport.width&&x.viewport.height===l.viewport.height)
      if(base){assert.deepEqual(l.canvas,base.canvas);assert.deepEqual(l.buttons,base.buttons)}
    }
    record('DPR2 backing independent from display density and reduced motion', {layouts:dpr,canvasStableForMs:350,canvasSha256:createHash('sha256').update(before).digest('hex')})
  }finally{await context?.close();context=undefined}
  try{
    context=await browser.newContext({viewport:{width:1920,height:1080},reducedMotion:'reduce'})
    const p=await context.newPage(),aborted=[],errors=[]
    p.on('pageerror',error=>receipt.errors.push(String(error)))
    p.on('console',message=>{if(message.type()==='error')errors.push({text:message.text(),url:message.location().url})})
    await p.route('**/original/frontend/composition.bin',route=>{aborted.push(route.request().url());return route.abort('failed')})
    await p.goto(url,{waitUntil:'networkidle'});await ready(p)
    assert.ok(aborted.length>0)
    assert.deepEqual(errors.filter(e=>!e.url.endsWith('/original/frontend/composition.bin')),[])
    assert.equal(await main(p).locator('canvas').evaluate(c=>c.getContext('2d').getImageData(0,0,1,1).data[3]),0)
    await button(p,'New Game').focus();await p.keyboard.press('Home');await settle(p)
    await p.screenshot({path:resolve(output,'main-fallback-composition-bin-1920x1080.png')})
    const layouts=[]
    for(const [width,height]of [[1920,1080],[641,480],[768,1024]]){
      await p.setViewportSize({width,height});await settle(p)
      const l=await layout(p);assertLayout(l);layouts.push(l)
      await returnFrom(p,'Options','Back');await returnFrom(p,'Quit','No');await returnFrom(p,'Quit','Escape')
    }
    record('real composition fetch failure keeps controls and static fallback',{aborted,expectedConsoleErrors:errors,layouts,limit:'composition.bin failure falls back to centered static 4:3 art with plain surrounding margins; the wide fill is unavailable.'})
  }finally{await context?.close()}
  assert.deepEqual(receipt.errors,[])
  return {checks:results,limits:[
    'Actual unchanged Home/store/GameScene via plain React/Vite; excludes Vinext/Cloudflare/RSC serving and hydration.',
    'Missing composition data preserves static centered 4:3 artwork and reachable controls; wide fill is not available in that fallback.',
    'Real browser controls and asset request abort; no injected scene, callbacks or model state.',
    'Resize timing includes viewport IPC, React resize, composition and two animation frames; software browser observation, not hardware performance certification.',
    'No game start, settings changes or checkpoint writes. Standard full check/build gates remain separate.'
  ]}
}
