import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {frontendWideIndexedBackground as original} from '/tmp/populous-selector-scene-457/app/frontend-wide-background.ts';
import {frontendWideIndexedBackground as candidate} from './frontend-wide-background-scalar.ts';
import assert from 'node:assert/strict';
const source=new Uint8Array(readFileSync('/tmp/populous-selector-scene-457/public/original/frontend/composition.bin'));
const sha=x=>createHash('sha256').update(x).digest('hex');const results=[];
for(const width of [642,660,720,800,854,1148,1280,1708]){
 const times={original:[],candidate:[]};let a,b;
 for(let i=0;i<3;i++){
  let fresh=source.slice(),start=performance.now();a=original(fresh,width);times.original.push(performance.now()-start);
  fresh=source.slice();start=performance.now();b=candidate(fresh,width);times.candidate.push(performance.now()-start);
  assert.deepEqual(a,b);
 }
 results.push({width,sha256:sha(a),exact:true,times});
}
writeFileSync('/tmp/widescreen460/scalar-optimization-comparison.json',JSON.stringify({scope:'Scratch-only scalar optimization; no repository edit.',results},null,2)+'\n');
console.log(JSON.stringify(results.map(x=>({width:x.width,originalMedian:[...x.times.original].sort((a,b)=>a-b)[1],candidateMedian:[...x.times.candidate].sort((a,b)=>a-b)[1],exact:x.exact})),null,2));
