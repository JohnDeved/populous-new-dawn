import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {frontendBackground as before} from './frontend-composition-69d450d7.ts';
import {frontendBackground as after} from '/tmp/populous-selector-scene-457/app/frontend-composition.ts';
const root='/tmp/populous-selector-scene-457';const source=new Uint8Array(readFileSync(root+'/public/original/frontend/composition.bin'));
const sha=x=>createHash('sha256').update(x).digest('hex');
const cases=[{pointer:{x:320,y:240},menu:true,glow:null,rows:[]},{pointer:{x:0,y:0},menu:true,glow:0,rows:[]},{pointer:{x:639,y:479},menu:true,glow:7,rows:[]},{pointer:{x:320,y:240},menu:false,glow:null,rows:[{text:'Quit?',x:320,y:159},{text:'Yes',x:320,y:189},{text:'No',x:320,y:219},{text:'Back',x:320,y:454}]},{pointer:{x:500,y:60},menu:false,glow:3,rows:[{text:'Options',x:320,y:139},{text:'Back',x:320,y:454}]}];
const results=[];
for(const width of [640,642,660,720,800,854,1148,1280,1708])for(const [caseIndex,c]of cases.entries()){
 const a=before(source,c.pointer,c.menu,c.glow,c.rows,width),b=after(source,c.pointer,c.menu,c.glow,c.rows,width);assert.deepEqual(a,b);results.push({width,caseIndex,sha256:sha(a),bytes:a.length,exact:true});
}
writeFileSync('/tmp/widescreen460/optimized-rgba-equivalence.json',JSON.stringify({beforeHead:'69d450d7184c003ec1f6729e08eedea12796d190',beforeFileSha256:sha(readFileSync('/tmp/widescreen460/frontend-wide-background-69d450d7.ts')),afterFileSha256:sha(readFileSync(root+'/app/frontend-wide-background.ts')),sourceSha256:sha(source),cases,results},null,2)+'\n');
console.log(`Passed ${results.length} complete RGBA comparisons against visually accepted 69d450d7`);
