import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {frontendBackground} from '/tmp/populous-selector-scene-457/app/frontend-composition.ts';
const root='/tmp/populous-selector-scene-457';
const source=new Uint8Array(readFileSync(root+'/public/original/frontend/composition.bin'));
const sha=x=>createHash('sha256').update(x).digest('hex');
const summary=values=>{const sorted=[...values].sort((a,b)=>a-b);return {ms:values,min:sorted[0],median:sorted[Math.floor(sorted.length/2)],p95:sorted[Math.ceil(sorted.length*.95)-1],max:sorted.at(-1)}};
const report={sourceHead:'69d450d7184c003ec1f6729e08eedea12796d190',node:process.version,scope:'Isolated Node CPU microbenchmark; not browser hardware FPS or display rendering performance.',sourceSha256:sha(source),files:Object.fromEntries(['app/frontend-composition.ts','app/frontend-wide-background.ts','app/original-main-menu.tsx'].map(p=>[p,sha(readFileSync(root+'/'+p))])),results:[]};
for(const width of [640,642,854,1148,1708]){
 const cold=[];let pixels;
 for(let i=0;i<3;i++){const fresh=source.slice();const start=performance.now();pixels=frontendBackground(fresh,{x:320,y:240},true,null,[],width);cold.push(performance.now()-start)}
 frontendBackground(source,{x:320,y:240},true,null,[],width);
 const warm=[];
 for(let i=0;i<30;i++){const start=performance.now();pixels=frontendBackground(source,{x:300+i,y:240},true,i%16,[],width);warm.push(performance.now()-start)}
 report.results.push({width,height:480,rgbaBytes:width*480*4,indexedCacheBytes:width*480,cold:summary(cold),cached:summary(warm),outputSha256:sha(pixels)});
}
writeFileSync('/tmp/widescreen460/compositor-performance-69d450d7.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report.results.map(({width,cold,cached})=>({width,coldMedianMs:cold.median,coldMaxMs:cold.max,cachedMedianMs:cached.median,cachedP95Ms:cached.p95})),null,2));
