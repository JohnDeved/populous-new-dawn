import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
import {showAllMissions,bindGame} from '/tmp/populous-selector-scene-457/scripts/browser-game.mjs'
import {SPELLS} from '/tmp/populous-selector-scene-457/app/model.ts'
import native from '/tmp/populous-selector-scene-457/app/original-hud.json' with {type:'json'}
import {sha256,reviewedSpellHudFrames,checkServedSpellHud,readSpellHudSprite} from '/tmp/populous-selector-scene-457/scripts/spell-hud-checker-contract.mjs'
export default async function({page,output,root,receipt}) {
const assetReportBytes=readFileSync('/tmp/spell480-validation/reencoded-preservation.json'),assetReport=JSON.parse(assetReportBytes)
const frames=reviewedSpellHudFrames(assetReport,native)
const currentAtlas={width:native.width,height:native.height,
  pngSHA:sha256(readFileSync(root+'/public/original/hud.png')),
  metadataSHA:sha256(readFileSync(root+'/app/original-hud.json'))}
const report={provenanceLabel:'Reencoded historical asset reconstruction; original PNG byte replay FAILED',startedAt:new Date().toISOString(),harness:'plain-Home supplemental adapter',mission:16,states:[],errors:[],
  assets:{reencodedHistoricalAppend:{reportSHA:sha256(assetReportBytes),status:assetReport.status,base:assetReport.base,outputs:assetReport.outputs,
    oldDimensions:assetReport.oldDimensions,newDimensions:assetReport.newDimensions},currentAtlas},
  limits:['Seven served asset crops and the current PNG identity are verified; rendered controls cover Shield states and fresh Bloodlust discovery, not earned Bloodlust casting.',
    'Historical append output hashes are provenance, not a reproduction or whole-atlas preservation proof for later appends.',
    'Simulation is frozen after entering the real mission; no availability, stock, gifts or unlock flags are injected.',
    'Shield inactive artwork uses real pause-charging; mode-2 Bloodlust is an undiscovered reward and cannot charge in normal campaign.',
    'No gameplay/renderer/native-cadence or hardware FPS acceptance is implied.']}
receipt.spellHudEvidence=report
const save=()=>writeFileSync(join(output,'evidence.json'),JSON.stringify(report,null,2)+'\n')

  report.limits.push('The original historical PNG failed byte reproduction with this encoder. This supplemental proof verifies unchanged full decoded pixels and exact historical metadata, then consumes a separate reencoded replay receipt; it is not original historical byte reproduction or unchanged standalone checker execution.')
  const historical=JSON.parse(readFileSync('/tmp/spell480-validation/historical-source.json','utf8'))
  const diagnostic=JSON.parse(readFileSync('/tmp/spell480-validation/replay-byte-diagnostic.json','utf8'))
  assert.equal(diagnostic.sameMetadataBytes,true);assert.equal(diagnostic.sameDecodedPixels,true)
  assert.equal(diagnostic.originalPngSHA,historical.files['public/original/hud.png'])
  assert.equal(assetReport.outputs['public/original/hud.png'],diagnostic.reproducedPngSHA)
  report.encodingProof=await page.evaluate(async()=>{
    const hash=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(x=>x.toString(16).padStart(2,'0')).join('')
    const values=[]
    for(const prefix of ['historical','reencoded']) {
      const response=await fetch('/'+prefix+'-hud.png');if(!response.ok)throw Error('Historical PNG fetch failed')
      const bytes=await response.arrayBuffer(),objectURL=URL.createObjectURL(new Blob([bytes],{type:'image/png'})),im=new Image()
      try {im.src=objectURL;await im.decode();const c=document.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;const ctx=c.getContext('2d');ctx.drawImage(im,0,0)
        const metadataResponse=await fetch('/'+prefix+'-hud.json');if(!metadataResponse.ok)throw Error('Historical metadata fetch failed')
        values.push({kind:prefix,pngSHA:await hash(bytes),rgbaSHA:await hash(ctx.getImageData(0,0,c.width,c.height).data),metadataSHA:await hash(await metadataResponse.arrayBuffer()),dimensions:[c.width,c.height]})
      } finally {URL.revokeObjectURL(objectURL)}
    }
    return values
  })
  const [original,reencoded]=report.encodingProof
  assert.equal(original.pngSHA,diagnostic.originalPngSHA);assert.equal(reencoded.pngSHA,diagnostic.reproducedPngSHA)
  assert.equal(original.metadataSHA,historical.files['app/original-hud.json']);assert.equal(reencoded.metadataSHA,original.metadataSHA)
  assert.equal(original.rgbaSHA,reencoded.rgbaSHA);assert.deepEqual(original.dimensions,[1024,460]);assert.deepEqual(reencoded.dimensions,original.dimensions)
  await page.setViewportSize({width:640,height:480})
  page.on('pageerror',error=>report.errors.push(String(error)))
  await showAllMissions(page)
  await page.getByRole('button',{name:'Mission 16',exact:true}).press('Enter')
  await bindGame(page)
  await page.evaluate(()=>document.querySelector('.skip-introduction')?.click())
  await bindGame(page)
  await page.waitForFunction(()=>window.testScene.world.outcome.level===16&&!window.testScene.world.inputMask)
  report.initial=await page.evaluate(()=>{
    const s=window.testScene,w=s.world
    // Freeze only time/render scheduling. The mission/availability/stock state is
    // whatever the normal authored load produced; controls below use real input.
    w.paused=true;w.speed=0;cancelAnimationFrame(s.frame)
    const gl=s.renderer.getContext(),ext=gl.getExtension('WEBGL_debug_renderer_info')
    return{level:w.outcome.level,available:w.manaWorld.spells[0].available,disabled:w.manaWorld.spells[0].disabled,
      shield:w.shots.shield,bloodlust:w.shots.bloodlust,gifts:{shield:w.giftCounts.shield,bloodlust:w.giftCounts.bloodlust},
      random:w.randomState,cosmetic:w.cosmeticRandom,renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
      viewport:[innerWidth,innerHeight],dpr:devicePixelRatio,turn:w.turn}
  })
  assert.ok(report.initial.available&(1<<19),'Shield remains permanently available')
  assert.equal(report.initial.available&(1<<20),0,'Normal startup clears mode-2 Bloodlust availability')
  assert.equal(report.initial.shield,0);assert.equal(report.initial.bloodlust,0)
  // Historical append crops remain the references; the served atlas may have
  // later appends. Bind all crops to the same bytes as the current checked-out PNG.
  report.servedAtlas=await page.evaluate(async frames=>{
    const response=await fetch('/original/hud.png');if(!response.ok)throw Error('HUD fetch failed: '+response.status)
    const bytes=await response.arrayBuffer(),digest=async data=>
      Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data))).map(n=>n.toString(16).padStart(2,'0')).join('')
    const image=new Image(),objectURL=URL.createObjectURL(new Blob([bytes],{type:'image/png'}))
    try{
      image.src=objectURL;await image.decode()
      const result=[]
      for(const {id,rect}of frames){
        const canvas=document.createElement('canvas');canvas.width=rect.w;canvas.height=rect.h
        const c=canvas.getContext('2d');c.drawImage(image,rect.x,rect.y,rect.w,rect.h,0,0,rect.w,rect.h)
        result.push({id,rgbaSHA:await digest(c.getImageData(0,0,rect.w,rect.h).data)})
      }
      return{pngSHA:await digest(bytes),width:image.naturalWidth,height:image.naturalHeight,frames:result}
    }finally{URL.revokeObjectURL(objectURL)}
  },frames)
  checkServedSpellHud(report.servedAtlas,currentAtlas,frames)
  const blank=async()=>{await page.mouse.move(5,5);await page.evaluate(()=>document.activeElement?.blur())}
  async function capture(card,id,state,spell){
    const rect=native.rects[id]
    const data=await card.evaluate(readSpellHudSprite,{id,rect})
    assert.equal(data.text,'');assert.ok(data.image.includes('/original/hud.png'))
    assert.equal(data.logicalWidth,rect.w);assert.equal(data.logicalHeight,rect.h)
    assert.ok(data.box.width>0&&data.box.height>0)
    assert.equal(data.buttonDisabled,false)
    if(state==='selected')assert.equal(data.selected,'true')
    report.states.push({spell,state,...data})
    await card.screenshot({path:join(output,`${spell}-${state}.png`)})
    await page.screenshot({path:join(output,`${spell}-${state}-full.png`)})
    save()
  }
  for(const [spell,model,frames]of [['shield',19,[408,409,410]]]){
    const name=SPELLS.find(s=>s.id===spell).name
    const card=page.getByRole('button',{name:new RegExp('^'+name+', \\d+ shots$')})
    await card.waitFor({state:'visible'});await card.scrollIntoViewIfNeeded()
    await blank();await capture(card,frames[0],'ready',spell)
    await card.hover();await capture(card,frames[2],'hover',spell)
    await card.click();await blank();await capture(card,frames[0],'selected',spell)
    assert.equal(await page.evaluate(()=>window.testScene.world.mode),spell)
    await card.click();await blank()
    // Shield is an authored permanent slot. Right-click toggles only its existing
    // charge-pause flag; no test-side world flag mutation or artificial stock.
    await card.click({button:'right'});await blank()
    assert.ok(await page.evaluate(model=>!!(window.testScene.world.manaWorld.spells[0].disabled&(1<<(model-1))),model))
    await capture(card,frames[1],'inactive',spell)
    await card.hover();await capture(card,frames[2],'inactive-hover',spell)
    await card.click({button:'right'});await blank();await capture(card,frames[0],'resumed',spell)
  }
  const bloodlustSlot=await page.evaluate(async()=>{
    const {spellHudRoster}=await import('/app/spell-visibility.ts'),
      {spellOrder}=await import('/app/spell-button.ts')
    return spellHudRoster(window.testScene.world)
      .toSorted((a,b)=>spellOrder.indexOf(a.spell.model)-spellOrder.indexOf(b.spell.model))
      .findIndex(entry=>entry.spell.id==='bloodlust'&&entry.visibility==='undiscovered')
  })
  assert.ok(bloodlustSlot>=0,'Authored Bloodlust head must produce a discovery control')
  assert.equal(await page.getByRole('button',{name:/^Bloodlust,/}).count(),0)
  const question=page.locator('.spell-list .spell-card').nth(bloodlustSlot)
  assert.equal(await question.getAttribute('aria-label'),'Undiscovered spell')
  assert.equal(await question.getAttribute('aria-disabled'),'true')
  assert.equal(await question.evaluate(button=>button.disabled),false)
  // Exercise trusted pointer events despite Playwright's aria-disabled actionability guard.
  await question.click({force:true});await question.click({button:'right',force:true});await blank()
  await capture(question,1056,'undiscovered','bloodlust')
  report.final=await page.evaluate(()=>{
    const w=window.testScene.world
    return{available:w.manaWorld.spells[0].available,disabled:w.manaWorld.spells[0].disabled,
      shield:w.shots.shield,bloodlust:w.shots.bloodlust,gifts:{shield:w.giftCounts.shield,bloodlust:w.giftCounts.bloodlust},
      random:w.randomState,cosmetic:w.cosmeticRandom,mode:w.mode,turn:w.turn}
  })
  for(const key of ['available','disabled','shield','bloodlust','gifts','random','cosmetic','turn'])
    assert.deepEqual(report.final[key],report.initial[key],`Preserved ${key}`)
  assert.equal(report.final.mode,null)
  assert.deepEqual(new Set(report.states.map(s=>s.id)),new Set([408,409,410,1056]))
  assert.deepEqual(report.errors,[]);assert.equal(report.expired,undefined)
  report.status='PASS_SEVEN_ASSETS_SHIELD_CONTROLS_BLOODLUST_DISCOVERY'

  report.status='PASS_SUPPLEMENTAL_SPELL_HUD_ADAPTER_WITH_REENCODED_PROVENANCE'
  report.finishedAt=new Date().toISOString();save();return report
}
