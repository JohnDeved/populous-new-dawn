import assert from 'node:assert/strict'
import test from 'node:test'
import { median, stats, summarize, qualify, compare } from './scripts/perf/pilot/analyze.mjs'
const config={ratioGuard:1.05,improvementScreen:.9,tailGuard:1.1}
const summary=(medianNs=100,p95Ns=120,stable=true)=>({medianNs,p95Ns,stable})
const qualification=()=>Array.from({length:4},()=>summary())
const rows=(warm=128,measured=256)=>[
 ...Array.from({length:warm},(_,index)=>({type:'warmup',index,ns:100})),
 ...Array.from({length:measured},(_,index)=>({type:'sample',index,ns:100})),
]
test('exact descriptive statistics retain maxima and all samples',()=>{
 assert.equal(median([5,1,3,9]),4)
 assert.deepEqual(stats([1,2,3,100]),{count:4,medianNs:2.5,p95Ns:100,p99Ns:100,maxNs:100,totalNs:106})
})
test('stable windows pass and all three 5% within-run guards detect failure',()=>{
 assert.equal(summarize(rows(),config).stable,true)
 for(const which of ['late','earlyWarm','allWarm']){
  const r=rows()
  for(const x of r)if((which==='late'&&x.type==='sample'&&x.index>=192)||(which==='earlyWarm'&&x.type==='warmup'&&x.index<64)||(which==='allWarm'&&x.type==='warmup'))x.ns=106
  assert.equal(summarize(r,config).stable,false,which)
 }
})
test('malformed sample counts, indices and values fail closed',()=>{
 assert.throws(()=>summarize(rows(127),config))
 assert.throws(()=>summarize(rows(128,255),config))
 for(const bad of [0,-1,NaN,Infinity]){const r=rows();r[150].ns=bad;assert.throws(()=>summarize(r,config))}
 const r=rows();r[128].index=4;assert.throws(()=>summarize(r,config))
})
test('qualification accepts inclusive 5% and skips beyond either spread or any unstable run',()=>{
 const q=qualification();q[3]=summary(105,126);assert.equal(qualify(q,config).pass,true)
 for(const changed of [summary(105.001,120),summary(100,126.001),summary(100,120,false)]){
  const q=qualification();q[3]=changed;const decision=qualify(q,config)
  assert.equal(decision.pass,false)
  const plannedCandidateProcesses=decision.pass?2:0
  assert.equal(plannedCandidateProcesses,0)
 }
})
test('positive screen requires both medians at least 10% lower and both p95 within 10%',()=>{
 const q=qualification(),a=summary(),b=summary(90,132)
 assert.equal(compare(q,[a,b,b,a],config).status,'positive screening only')
 assert.equal(compare(q,[a,summary(90.001,132),b,a],config).status,'inconclusive')
 assert.equal(compare(q,[a,b,summary(90,132.001),a],config).status,'inconclusive')
 assert.equal(compare(q,[a,b,summary(90,132,false),a],config).status,'inconclusive')
})
test('post-qualification baseline drift invalidates screening',()=>{
 for(const drift of [summary(105.001,120),summary(100,126.001)]){
  const result=compare(qualification(),[summary(),summary(80,100),summary(80,100),drift],config)
  assert.equal(result.stable,false);assert.equal(result.status,'inconclusive')
 }
})
test('slower and mixed outcomes are retained without performance acceptance',()=>{
 const q=qualification(),a=summary()
 assert.equal(compare(q,[a,summary(101),summary(102),a],config).status,'negative evidence, no acceptance')
 assert.equal(compare(q,[a,summary(89),summary(101),a],config).status,'inconclusive')
 assert.equal(compare(q,[a,summary(95),summary(96),a],config).status,'inconclusive')
})
