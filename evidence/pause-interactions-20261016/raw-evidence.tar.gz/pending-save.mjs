import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {setup,assertPaused} from './common.mjs'
export default async function(args) {
  const {page,output,receipt}=args
  receipt.stage='save-failure-startup'
  const {button,modal}=await setup(args)
  await button('Pause game').click()
  await button('Game settings').focus();await page.keyboard.press('Enter')
  await modal.waitFor();await assertPaused(page)
  await modal.getByRole('button',{name:'Save Game',exact:true}).click()
  await page.evaluate(()=>{
    const store=window.testStore,save=store.saveCheckpoint,put=IDBObjectStore.prototype.put
    const state={store,save,put,world:store.getWorld(),calls:0,failures:0,release:null}
    window.pauseSaveTest=state
    IDBObjectStore.prototype.put=function(...args){
      if(this.name==='checkpoints'&&args[1]==='latest'){
        state.failures++;throw new DOMException('Controlled test storage failure','QuotaExceededError')
      }
      return put.apply(this,args)
    }
    store.saveCheckpoint=async(...args)=>{
      state.calls++;const result=await save.apply(store,args)
      await new Promise(resolve=>{state.release=resolve})
      return result
    }
  })
  try {
    receipt.stage='save-failure-pending'
    await button('Save checkpoint').click()
    await page.waitForFunction(()=>typeof window.pauseSaveTest.release==='function')
    assert.equal(await button('Saving…').isDisabled(),true)
    await page.keyboard.press('Escape')
    assert.equal(await modal.getAttribute('data-panel'),'root');await assertPaused(page)
    await modal.getByRole('button',{name:'Save Game',exact:true}).click()
    assert.equal(await button('Saving…').isDisabled(),true)
    assert.deepEqual(await page.evaluate(()=>({calls:window.pauseSaveTest.calls,failures:window.pauseSaveTest.failures,sameWorld:window.testStore.getWorld()===window.pauseSaveTest.world,checkpoint:window.testStore.hasCheckpoint()})),{calls:1,failures:1,sameWorld:true,checkpoint:true})
    await page.evaluate(()=>window.pauseSaveTest.release())
    const notice=modal.getByRole('status')
    await notice.waitFor()
    assert.equal(await notice.textContent(),'Checkpoint saved for this session only; browser storage is unavailable.')
    assert.equal(await button('Save checkpoint').isEnabled(),true);await assertPaused(page)
    await page.screenshot({path:resolve(output,'session-only-checkpoint.png')})
    await modal.getByRole('button',{name:'Back',exact:true}).click()
    await modal.getByRole('button',{name:'Load Game',exact:true}).click()
    assert.equal(await button('Load checkpoint').isEnabled(),true)
    await modal.getByRole('button',{name:'Back',exact:true}).click()
    await modal.getByRole('button',{name:'Continue Game',exact:true}).click()
    await modal.waitFor({state:'detached'});await assertPaused(page,false)
    assert.equal(await page.evaluate(()=>window.testStore.getWorld()===window.pauseSaveTest.world),true)
    receipt.stage='save-failure-complete'
    return {checks:['real latest checkpoint IDB write failure','pending Save remains single-flight across Escape and reopening','truthful session-only notice and load availability','original paused world retained after Continue'],limits:['Test-owned storage failure and delayed return; no session-only rendered load or new scene']}
  } finally {
    receipt.injectionCleanup=await page.evaluate(()=>{
      const s=window.pauseSaveTest;if(!s)return false
      s.release?.();s.store.saveCheckpoint=s.save;IDBObjectStore.prototype.put=s.put
      const restored=s.store.saveCheckpoint===s.save&&IDBObjectStore.prototype.put===s.put
      delete window.pauseSaveTest;return restored
    })
    assert.equal(receipt.injectionCleanup,true)
  }
}
