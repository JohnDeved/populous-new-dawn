import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
const contract=JSON.parse(readFileSync(new URL('./source-contract.json',import.meta.url)))
export async function setup({page,root,receipt}) {
  assert.deepEqual(page.viewportSize(),{width:640,height:480},'Set native viewport before the single navigation')
  assert.equal(await page.evaluate(()=>devicePixelRatio),1)
  for(const [name,hash] of Object.entries(contract.files))
    assert.equal(createHash('sha256').update(readFileSync(resolve(root,name))).digest('hex'),hash,`Immutable source mismatch: ${name}`)
  receipt.pauseSourceCommit=contract.sourceCommit
  const button=name=>page.getByRole('button',{name,exact:true})
  await page.getByRole('dialog',{name:'Main menu',exact:true}).waitFor()
  await button('New Game').click()
  const selector=page.getByRole('dialog',{name:'Start game',exact:true})
  await selector.waitFor()
  await selector.getByRole('button',{name:'Panel Mission 1',exact:true}).click()
  await selector.getByRole('button',{name:'Start Mission 1',exact:true}).click()
  // The notice can pause turn zero: dismiss it before waiting on flyby progress.
  const notice=page.getByRole('button',{name:/^Continue anyway/})
  await notice.waitFor({state:'visible'})
  await notice.click()
  const {bindGame}=await import(pathToFileURL(resolve(root,'scripts/browser-game.mjs')).href)
  await bindGame(page)
  await page.waitForFunction(()=>{
    const s=window.testSceneRef.current,b=document.querySelector('.skip-introduction')
    return (b&&b.getClientRects().length>0)||(!s.world.inputMask&&!(s.world.flyby.flags&1))
  })
  const skip=page.getByRole('button',{name:/^Skip introduction/})
  if(await skip.isVisible())await skip.click()
  await page.waitForFunction(()=>!window.testSceneRef.current.world.inputMask)
  assert.equal(await page.evaluate(()=>window.testStore.getWorld().paused),false)
  receipt.renderer=await page.evaluate(()=>{
    const gl=window.testSceneRef.current.renderer.getContext(),d=gl.getExtension('WEBGL_debug_renderer_info')
    return d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER)
  })
  return {button,modal:page.getByRole('dialog',{name:'Game menu',exact:true})}
}
export async function assertPaused(page,modal=true) {
  assert.deepEqual(await page.evaluate(()=>({paused:window.testStore.getWorld().paused,modal:window.testSceneRef.current.modalSuspended})),{paused:true,modal})
}
