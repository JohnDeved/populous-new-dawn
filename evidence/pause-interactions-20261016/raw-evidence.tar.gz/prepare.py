import pathlib,subprocess,json,hashlib,os
work=pathlib.Path('/tmp/pause-gap-673b89ad');root=pathlib.Path('/tmp/complete-frame-metrics/matched/base-source');repo='/tmp/populous-selector-scene-457';git='/tmp/selector-scene457/git-bin/git'
contract=json.loads((work/'source-contract.json').read_text());head=contract['sourceCommit']
def g(*args):return subprocess.check_output([git,'-C',repo,*args])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
changes=[]
for name,expected in contract['files'].items():
 p=root/name
 if p.is_symlink():raise RuntimeError('Unexpected source symlink '+name)
 if not p.exists() or sha(p)!=expected:
  data=g('show',head+':'+name)
  assert hashlib.sha256(data).hexdigest()==expected
  p.parent.mkdir(parents=True,exist_ok=True)
  temp=p.with_name(p.name+'.pause-prep');temp.write_bytes(data);os.replace(temp,p)
  changes.append(name)
assert all(sha(root/p)==h for p,h in contract['files'].items())
assert (root/'public').is_symlink() and (root/'public').resolve()==pathlib.Path(repo+'/public')
assert (root/'node_modules').is_symlink() and (root/'node_modules').resolve()==pathlib.Path('/tmp/populous-raid447-fallback-0229/node_modules')
files=dict(contract['files']);assets=0
for item in g('ls-tree','-r',head,'public').decode().splitlines():
 metadata,name=item.split('\t');mode,kind,oid=metadata.split();assert kind=='blob' and mode in ['100644','100755']
 p=root/name;assert p.is_file() and not p.is_symlink(),name
 data=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,name
 files[name]=hashlib.sha256(data).hexdigest();assets+=1
fixture=work/'fixture';fixture.mkdir(exist_ok=True)
(fixture/'index.html').write_text('<!doctype html><html><head><meta charset="UTF-8"></head><body><div id="root"></div><script type="module" src="/main.tsx"></script></body></html>\n')
(fixture/'main.tsx').write_text(f"import {{createRoot}} from 'react-dom/client';import Home from '{root}/app/page.tsx';import '{root}/app/globals.css';createRoot(document.getElementById('root')!).render(<Home />)\n")
(fixture/'package.json').write_text('{"private":true,"type":"module"}\n')
for base in [work,fixture]:
 p=base/'node_modules'
 if not p.exists():p.symlink_to(root/'node_modules',target_is_directory=True)
 assert p.resolve()==(root/'node_modules').resolve()
limits=['Production Home/GameScene and assets through plain React/Vite; excludes Vinext/Cloudflare/RSC hosting.','Native640 DPR1 software rendering; no hardware FPS or native-execution claim.','Pending-save scenario injects checkpoint-only storage failure and holds real save return; injections restored in finally.','Public assets are shared read-only inputs, all verified against exact Git source and rechecked after execution.']
(fixture/'source.json').write_text(json.dumps({'sourceCommit':head,'sourceStatus':'immutable app snapshot, verified shared assets','snapshotRoot':str(root),'files':files,'limits':limits},indent=2)+'\n')
runner=pathlib.Path('/workspace/scratch/69fd8163d94e/graphics-options-prep/run-home.mjs').read_text()
assert "viewport:{width:1440,height:1000}" in runner
runner=runner.replace('viewport:{width:1440,height:1000}','viewport:{width:640,height:480},deviceScaleFactor:1')
(work/'run-home-native.mjs').write_text(runner)
receipt={'sourceCommit':head,'snapshotRoot':str(root),'updatedFiles':changes,'sourceFilesVerified':len(contract['files']),'assetsVerified':assets,'publicSymlink':str((root/'public').resolve()),'dependencySymlink':str((root/'node_modules').resolve()),'runnerSha256':sha(work/'run-home-native.mjs'),'browserLaunched':False,'tmpAvailableBytes':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize}
(work/'preparation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
