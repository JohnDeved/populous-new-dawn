import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {setup,assertPaused} from './common.mjs'
export default async function(args) {
  const {page,output,receipt}=args
  receipt.stage='quit-level-startup'
  const {button,modal}=await setup(args)
  await button('Game settings').focus();await page.keyboard.press('Enter')
  await modal.waitFor();await assertPaused(page)
  await page.evaluate(()=>{window.pauseExitOld={world:window.testStore.getWorld(),scene:window.testSceneRef.current}})
  try {
    receipt.stage='quit-level-confirmation'
    await modal.getByRole('button',{name:'Quit Level',exact:true}).click()
    await modal.getByRole('heading',{name:'Quit Level?',exact:true}).waitFor()
    assert.equal(await modal.getByRole('button',{name:'No',exact:true}).evaluate(b=>b===document.activeElement),true)
    assert.match(await modal.innerText(),/Return to world selection\. Unsaved progress will be lost\./)
    await modal.getByRole('button',{name:'Yes',exact:true}).click()
    const selector=page.getByRole('dialog',{name:'Start game',exact:true})
    await selector.waitFor();await modal.waitFor({state:'detached'})
    assert.equal(await page.locator('.world-viewport canvas').count(),0)
    assert.equal(await page.evaluate(()=>window.pauseExitOld.scene.renderer.domElement.isConnected),false)
    const oldState=()=>page.evaluate(()=>{const w=window.pauseExitOld.world;return {turn:w.turn,time:w.time,paused:w.paused}})
    const before=await oldState();await page.waitForTimeout(250);assert.deepEqual(await oldState(),before)
    await page.screenshot({path:resolve(output,'quit-level-selector.png')})
    await selector.getByRole('button',{name:'Browser controls',exact:true}).click()
    await selector.getByRole('button',{name:'Back',exact:true}).click()
    await page.getByRole('dialog',{name:'Main menu',exact:true}).waitFor()
    assert.equal(await modal.count(),0);assert.equal(await page.locator('.world-viewport canvas').count(),0)
    receipt.stage='quit-level-complete'
    return {checks:['Quit Level Yes returns selector','old battlefield detached and world stopped','selector Back returns main menu without stale pause dialog'],limits:['One software-rendered scene; no second mission start or native execution']}
  } finally {await page.evaluate(()=>{delete window.pauseExitOld})}
}
