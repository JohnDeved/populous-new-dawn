0043abf0 83ec18               sub esp, 0x18
0043abf3 c744240c00000000     mov dword ptr [esp + 0xc], 0
0043abfb 53                   push ebx
0043abfc 56                   push esi
0043abfd 57                   push edi
0043abfe 55                   push ebp
0043abff 33ed                 xor ebp, ebp
0043ac01 8b7c242c             mov edi, dword ptr [esp + 0x2c]
0043ac05 f6471108             test byte ptr [edi + 0x11], 8
0043ac09 668b6f24             mov bp, word ptr [edi + 0x24]
0043ac0d 0f8599020000         jne 0x43aeac
0043ac13 668b473d             mov ax, word ptr [edi + 0x3d]
0043ac17 66c1e808             shr ax, 8
0043ac1b 24fe                 and al, 0xfe
0043ac1d 88442418             mov byte ptr [esp + 0x18], al
0043ac21 668b473f             mov ax, word ptr [edi + 0x3f]
0043ac25 66c1e808             shr ax, 8
0043ac29 24fe                 and al, 0xfe
0043ac2b 88442419             mov byte ptr [esp + 0x19], al
0043ac2f 8b442430             mov eax, dword ptr [esp + 0x30]
0043ac33 668b4c2418           mov cx, word ptr [esp + 0x18]
0043ac38 24fe                 and al, 0xfe
0043ac3a 66894c2414           mov word ptr [esp + 0x14], cx
0043ac3f 28442414             sub byte ptr [esp + 0x14], al
0043ac43 28442415             sub byte ptr [esp + 0x15], al
0043ac47 668b4c2414           mov cx, word ptr [esp + 0x14]
0043ac4c 8b442430             mov eax, dword ptr [esp + 0x30]
0043ac50 66894c2416           mov word ptr [esp + 0x16], cx
0043ac55 89442424             mov dword ptr [esp + 0x24], eax
0043ac59 85c0                 test eax, eax
0043ac5b 0f8434020000         je 0x43ae95
0043ac61 8b442430             mov eax, dword ptr [esp + 0x30]
0043ac65 89442420             mov dword ptr [esp + 0x20], eax
0043ac69 837c242000           cmp dword ptr [esp + 0x20], 0
0043ac6e 0f8405020000         je 0x43ae79
0043ac74 33c0                 xor eax, eax
0043ac76 33c9                 xor ecx, ecx
0043ac78 668b442416           mov ax, word ptr [esp + 0x16]
0043ac7d 668b4c2416           mov cx, word ptr [esp + 0x16]
0043ac82 25fe000000           and eax, 0xfe
0043ac87 03c0                 add eax, eax
0043ac89 81e100fe0000         and ecx, 0xfe00
0043ac8f 0bc1                 or eax, ecx
0043ac91 668b0485ea038a00     mov ax, word ptr [eax*4 + 0x8a03ea]
0043ac99 6685c0               test ax, ax
0043ac9c 0f84c9010000         je 0x43ae6b
0043aca2 0fbfc0               movsx eax, ax
0043aca5 8b348590038900       mov esi, dword ptr [eax*4 + 0x890390]
0043acac 85f6                 test esi, esi
0043acae 0f84b7010000         je 0x43ae6b
0043acb4 807e2a01             cmp byte ptr [esi + 0x2a], 1
0043acb8 0f8598010000         jne 0x43ae56
0043acbe 33c0                 xor eax, eax
0043acc0 8a462b               mov al, byte ptr [esi + 0x2b]
0043acc3 c744241800000000     mov dword ptr [esp + 0x18], 0
0043accb 8d0c80               lea ecx, [eax + eax*4]
0043acce 8d1489               lea edx, [ecx + ecx*4]
0043acd1 f6045590705a0020     test byte ptr [edx*2 + 0x5a7090], 0x20
0043acd9 0f84ef000000         je 0x43adce
0043acdf 8a572f               mov dl, byte ptr [edi + 0x2f]
0043ace2 8a4e2f               mov cl, byte ptr [esi + 0x2f]
0043ace5 3ad1                 cmp dl, cl
0043ace7 0f84e1000000         je 0x43adce
0043aced 33c0                 xor eax, eax
0043acef 8a462c               mov al, byte ptr [esi + 0x2c]
0043acf2 f68480796f5a0020     test byte ptr [eax + eax*4 + 0x5a6f79], 0x20
0043acfa 0f85ce000000         jne 0x43adce
0043ad00 80faff               cmp dl, 0xff
0043ad03 741a                 je 0x43ad1f
0043ad05 80f9ff               cmp cl, 0xff
0043ad08 7415                 je 0x43ad1f
0043ad0a 3ad1                 cmp dl, cl
0043ad0c 7411                 je 0x43ad1f
0043ad0e 0fbec2               movsx eax, dl
0043ad11 b301                 mov bl, 1
0043ad13 8a80b6089600         mov al, byte ptr [eax + 0x9608b6]
0043ad19 d2e3                 shl bl, cl
0043ad1b 22c3                 and al, bl
0043ad1d eb02                 jmp 0x43ad21
0043ad1f b001                 mov al, 1
0043ad21 84c0                 test al, al
0043ad23 0f85a5000000         jne 0x43adce
0043ad29 f6461608             test byte ptr [esi + 0x16], 8
0043ad2d 0f859b000000         jne 0x43adce
0043ad33 6683be9f00000000     cmp word ptr [esi + 0x9f], 0
0043ad3b 0f858d000000         jne 0x43adce
0043ad41 0fbec2               movsx eax, dl
0043ad44 50                   push eax
0043ad45 56                   push esi
0043ad46 e8653a0a00           call 0x4de7b0
0043ad4b 83c408               add esp, 8
0043ad4e 85c0                 test eax, eax
0043ad50 757c                 jne 0x43adce
0043ad52 f6460e10             test byte ptr [esi + 0xe], 0x10
0043ad56 7576                 jne 0x43adce
0043ad58 8a462c               mov al, byte ptr [esi + 0x2c]
0043ad5b 56                   push esi
0043ad5c 88467d               mov byte ptr [esi + 0x7d], al
0043ad5f e88c290b00           call 0x4ed6f0
0043ad64 83c404               add esp, 4
0043ad67 c6462c17             mov byte ptr [esi + 0x2c], 0x17
0043ad6b 56                   push esi
0043ad6c e8cf280b00           call 0x4ed640
0043ad71 83c404               add esp, 4
0043ad74 807e2f00             cmp byte ptr [esi + 0x2f], 0
0043ad78 7532                 jne 0x43adac
0043ad7a 810d05db890000000080 or dword ptr [0x89db05], 0x80000000
0043ad84 668b463d             mov ax, word ptr [esi + 0x3d]
0043ad88 66c1e808             shr ax, 8
0043ad8c 24fe                 and al, 0xfe
0043ad8e 88442412             mov byte ptr [esp + 0x12], al
0043ad92 668b463f             mov ax, word ptr [esi + 0x3f]
0043ad96 66c1e808             shr ax, 8
0043ad9a 24fe                 and al, 0xfe
0043ad9c 88442413             mov byte ptr [esp + 0x13], al
0043ada0 668b4c2412           mov cx, word ptr [esp + 0x12]
0043ada5 66890dccce9800       mov word ptr [0x98cecc], cx
0043adac 6a02                 push 2
0043adae 8a462f               mov al, byte ptr [esi + 0x2f]
0043adb1 50                   push eax
0043adb2 8a4f2f               mov cl, byte ptr [edi + 0x2f]
0043adb5 51                   push ecx
0043adb6 57                   push edi
0043adb7 e8e470ffff           call 0x431ea0
0043adbc c744242801000000     mov dword ptr [esp + 0x28], 1
0043adc4 6689ae89000000       mov word ptr [esi + 0x89], bp
0043adcb 83c410               add esp, 0x10
0043adce 837c241800           cmp dword ptr [esp + 0x18], 0
0043add3 7513                 jne 0x43ade8
0043add5 807e2c17             cmp byte ptr [esi + 0x2c], 0x17
0043add9 757b                 jne 0x43ae56
0043addb 33c0                 xor eax, eax
0043addd 668b8689000000       mov ax, word ptr [esi + 0x89]
0043ade4 3bc5                 cmp eax, ebp
0043ade6 756e                 jne 0x43ae56
0043ade8 837c241c00           cmp dword ptr [esp + 0x1c], 0
0043aded 7563                 jne 0x43ae52
0043adef 668b463d             mov ax, word ptr [esi + 0x3d]
0043adf3 662b473d             sub ax, word ptr [edi + 0x3d]
0043adf7 0fb7d0               movzx edx, ax
0043adfa 668b463f             mov ax, word ptr [esi + 0x3f]
0043adfe 8bca                 mov ecx, edx
0043ae00 662b473f             sub ax, word ptr [edi + 0x3f]
0043ae04 85d2                 test edx, edx
0043ae06 0fb7c0               movzx eax, ax
0043ae09 7d04                 jge 0x43ae0f
0043ae0b 8bca                 mov ecx, edx
0043ae0d f7d9                 neg ecx
0043ae0f 8bd8                 mov ebx, eax
0043ae11 85c0                 test eax, eax
0043ae13 7d04                 jge 0x43ae19
0043ae15 8bd8                 mov ebx, eax
0043ae17 f7db                 neg ebx
0043ae19 81f900800000         cmp ecx, 0x8000
0043ae1f 7c06                 jl 0x43ae27
0043ae21 8d910000ffff         lea edx, [ecx - 0x10000]
0043ae27 81fb00800000         cmp ebx, 0x8000
0043ae2d 7c06                 jl 0x43ae35
0043ae2f 8d830000ffff         lea eax, [ebx - 0x10000]
0043ae35 f7d8                 neg eax
0043ae37 50                   push eax
0043ae38 52                   push edx
0043ae39 e836b21400           call 0x586074
0043ae3e 83c408               add esp, 8
0043ae41 33c9                 xor ecx, ecx
0043ae43 668bc8               mov cx, ax
0043ae46 8b442434             mov eax, dword ptr [esp + 0x34]
0043ae4a 81e1ff070000         and ecx, 0x7ff
0043ae50 8908                 mov dword ptr [eax], ecx
0043ae52 ff44241c             inc dword ptr [esp + 0x1c]
0043ae56 33c0                 xor eax, eax
0043ae58 668b4620             mov ax, word ptr [esi + 0x20]
0043ae5c 8b348590038900       mov esi, dword ptr [eax*4 + 0x890390]
0043ae63 85f6                 test esi, esi
0043ae65 0f8549feffff         jne 0x43acb4
0043ae6b 8044241602           add byte ptr [esp + 0x16], 2
0043ae70 ff4c2420             dec dword ptr [esp + 0x20]
0043ae74 e9f0fdffff           jmp 0x43ac69
0043ae79 8a442414             mov al, byte ptr [esp + 0x14]
0043ae7d ff4c2424             dec dword ptr [esp + 0x24]
0043ae81 8044241702           add byte ptr [esp + 0x17], 2
0043ae86 837c242400           cmp dword ptr [esp + 0x24], 0
0043ae8b 88442416             mov byte ptr [esp + 0x16], al
0043ae8f 0f85ccfdffff         jne 0x43ac61
0043ae95 837c241c04           cmp dword ptr [esp + 0x1c], 4
0043ae9a 7f09                 jg 0x43aea5
0043ae9c 808fb200000002       or byte ptr [edi + 0xb2], 2
0043aea3 eb07                 jmp 0x43aeac
0043aea5 80a7b2000000fd       and byte ptr [edi + 0xb2], 0xfd
0043aeac 8b44241c             mov eax, dword ptr [esp + 0x1c]
0043aeb0 5d                   pop ebp
0043aeb1 5f                   pop edi
0043aeb2 5e                   pop esi
0043aeb3 5b                   pop ebx
0043aeb4 83c418               add esp, 0x18
0043aeb7 c3                   ret 
0043aeb8 cc                   int3 
0043aeb9 cc                   int3 
0043aeba cc                   int3 
0043aebb cc                   int3 
0043aebc cc                   int3 
0043aebd cc                   int3 
0043aebe cc                   int3 
0043aebf cc                   int3 
0043aec0 83ec08               sub esp, 8
0043aec3 53                   push ebx
0043aec4 56                   push esi
0043aec5 8b742414             mov esi, dword ptr [esp + 0x14]
0043aec9 57                   push edi
0043aeca 55                   push ebp
0043aecb f6461108             test byte ptr [esi + 0x11], 8
0043aecf 0f8530010000         jne 0x43b005
0043aed5 668b463d             mov ax, word ptr [esi + 0x3d]
0043aed9 66c1e808             shr ax, 8
0043aedd 24fe                 and al, 0xfe
0043aedf 88442414             mov byte ptr [esp + 0x14], al
0043aee3 668b463f             mov ax, word ptr [esi + 0x3f]
0043aee7 66c1e808             shr ax, 8
0043aeeb 24fe                 and al, 0xfe
0043aeed 88442415             mov byte ptr [esp + 0x15], al
0043aef1 8b442420             mov eax, dword ptr [esp + 0x20]
0043aef5 668b4c2414           mov cx, word ptr [esp + 0x14]
0043aefa 24fe                 and al, 0xfe
0043aefc 66894c2412           mov word ptr [esp + 0x12], cx
0043af01 28442412             sub byte ptr [esp + 0x12], al
0043af05 28442413             sub byte ptr [esp + 0x13], al
0043af09 8b442420             mov eax, dword ptr [esp + 0x20]
0043af0d 89442414             mov dword ptr [esp + 0x14], eax
0043af11 85c0                 test eax, eax
0043af13 0f84ec000000         je 0x43b005
0043af19 8b6c2420             mov ebp, dword ptr [esp + 0x20]
0043af1d 85ed                 test ebp, ebp
0043af1f 0f84d6000000         je 0x43affb
0043af25 33c0                 xor eax, eax
0043af27 33c9                 xor ecx, ecx
0043af29 668b442412           mov ax, word ptr [esp + 0x12]
0043af2e 668b4c2412           mov cx, word ptr [esp + 0x12]
0043af33 25fe000000           and eax, 0xfe
0043af38 03c0                 add eax, eax
0043af3a 81e100fe0000         and ecx, 0xfe00
0043af40 0bc1                 or eax, ecx
0043af42 668b0485ea038a00     mov ax, word ptr [eax*4 + 0x8a03ea]
0043af4a 6685c0               test ax, ax
0043af4d 0f84a2000000         je 0x43aff5
0043af53 0fbfc0               movsx eax, ax
0043af56 8b3c8590038900       mov edi, dword ptr [eax*4 + 0x890390]
0043af5d 85ff                 test edi, edi
0043af5f 0f8490000000         je 0x43aff5
0043af65 807f2a01             cmp byte ptr [edi + 0x2a], 1
0043af69 7575                 jne 0x43afe0
0043af6b 8a462f               mov al, byte ptr [esi + 0x2f]
0043af6e 38472f               cmp byte ptr [edi + 0x2f], al
0043af71 746d                 je 0x43afe0
0043af73 8a472b               mov al, byte ptr [edi + 0x2b]
0043af76 3c07                 cmp al, 7
0043af78 7466                 je 0x43afe0
0043af7a 3c04                 cmp al, 4
0043af7c 7462                 je 0x43afe0
0043af7e 807f2c17             cmp byte ptr [edi + 0x2c], 0x17
0043af82 755c                 jne 0x43afe0
0043af84 57                   push edi
0043af85 e8b6eb0a00           call 0x4e9b40
0043af8a 83c404               add esp, 4
0043af8d f6470e10             test byte ptr [edi + 0xe], 0x10
0043af91 754d                 jne 0x43afe0
0043af93 8a472c               mov al, byte ptr [edi + 0x2c]
0043af96 88477d               mov byte ptr [edi + 0x7d], al
0043af99 f6057cd1890002       test byte ptr [0x89d17c], 2
0043afa0 7417                 je 0x43afb9
0043afa2 8a472b               mov al, byte ptr [edi + 0x2b]
0043afa5 3c07                 cmp al, 7
0043afa7 7504                 jne 0x43afad
0043afa9 b327                 mov bl, 0x27
0043afab eb1e                 jmp 0x43afcb
0043afad 33c9                 xor ecx, ecx
0043afaf 8ac8                 mov cl, al
0043afb1 8d0489               lea eax, [ecx + ecx*4]
0043afb4 8d1480               lea edx, [eax + eax*4]
0043afb7 eb0b                 jmp 0x43afc4
0043afb9 33c0                 xor eax, eax
0043afbb 8a472b               mov al, byte ptr [edi + 0x2b]
0043afbe 8d0c80               lea ecx, [eax + eax*4]
0043afc1 8d1489               lea edx, [ecx + ecx*4]
0043afc4 8a1c5564705a00       mov bl, byte ptr [edx*2 + 0x5a7064]
0043afcb 57                   push edi
0043afcc e81f270b00           call 0x4ed6f0
0043afd1 83c404               add esp, 4
0043afd4 885f2c               mov byte ptr [edi + 0x2c], bl
0043afd7 57                   push edi
0043afd8 e863260b00           call 0x4ed640
0043afdd 83c404               add esp, 4
0043afe0 33c0                 xor eax, eax
0043afe2 668b4720             mov ax, word ptr [edi + 0x20]
0043afe6 8b3c8590038900       mov edi, dword ptr [eax*4 + 0x890390]
0043afed 85ff                 test edi, edi
0043afef 0f8570ffffff         jne 0x43af65
0043aff5 4d                   dec ebp
0043aff6 e922ffffff           jmp 0x43af1d
0043affb ff4c2414             dec dword ptr [esp + 0x14]
0043afff 0f8514ffffff         jne 0x43af19
0043b005 5d                   pop ebp
0043b006 5f                   pop edi
0043b007 5e                   pop esi
0043b008 5b                   pop ebx
0043b009 83c408               add esp, 8
0043b00c c3                   ret 
0043b00d cc                   int3 
0043b00e cc                   int3 
0043b00f cc                   int3 
0043b010 8b4c2404             mov ecx, dword ptr [esp + 4]
0043b014 83ec04               sub esp, 4
0043b017 53                   push ebx
0043b018 56                   push esi
0043b019 57                   push edi
0043b01a 33f6                 xor esi, esi
0043b01c 6639b19b000000       cmp word ptr [ecx + 0x9b], si
0043b023 0f85e3000000         jne 0x43b10c
0043b029 33d2                 xor edx, edx
0043b02b 8db98b000000         lea edi, [ecx + 0x8b]
0043b031 668b07               mov ax, word ptr [edi]
0043b034 6685c0               test ax, ax
0043b037 7417                 je 0x43b050
0043b039 0fb7c0               movzx eax, ax
0043b03c 8d1c80               lea ebx, [eax + eax*4]
0043b03f 8d045d30889300       lea eax, [ebx*2 + 0x938830]
0043b046 8a00                 mov al, byte ptr [eax]
0043b048 3c0b                 cmp al, 0xb
0043b04a 7413                 je 0x43b05f
0043b04c 3c19                 cmp al, 0x19
0043b04e 740f                 je 0x43b05f
0043b050 83c702               add edi, 2
0043b053 42                   inc edx
0043b054 83fa08               cmp edx, 8
0043b057 7cd8                 jl 0x43b031
0043b059 8b7c240c             mov edi, dword ptr [esp + 0xc]
0043b05d eb07                 jmp 0x43b066
0043b05f 8bfa                 mov edi, edx
0043b061 be01000000           mov esi, 1
0043b066 85f6                 test esi, esi
0043b068 0f849e000000         je 0x43b10c
