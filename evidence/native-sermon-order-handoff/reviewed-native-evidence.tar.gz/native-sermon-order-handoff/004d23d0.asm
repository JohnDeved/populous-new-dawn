004d23d0 sub esp, 0x10
004d23d3 push ebx
004d23d4 push esi
004d23d5 mov esi, dword ptr [esp + 0x1c]
004d23d9 push edi
004d23da movsx eax, byte ptr [esi + 0x2f]
004d23de or dword ptr [esi + 0x10], 0x100
004d23e5 mov ecx, eax
004d23e7 lea edx, [eax + eax*4]
004d23ea lea eax, [ecx + edx*2]
004d23ed or dword ptr [esi + 0x14], 0x40100
004d23f4 lea ebx, [eax + eax*8]
004d23f7 xor eax, eax
004d23f9 mov al, byte ptr [esi + 0x2b]
004d23fc lea edx, [ecx + ebx*8]
004d23ff dec eax
004d2400 lea edi, [ecx + edx*4 + 0x89d1c8]
004d2407 cmp eax, 7
004d240a ja 0x4d26d1
004d2410 jmp dword ptr [eax*4 + 0x4d2718]
004d2417 mov byte ptr [esi + 0x2f], 0xff
004d241b push esi
004d241c call 0x4d5920
004d2421 add esp, 4
004d2424 xor eax, eax
004d2426 mov al, byte ptr [esi + 0x2b]
004d2429 lea ecx, [eax + eax*4]
004d242c lea edx, [ecx + ecx*4]
004d242f xor ecx, ecx
004d2431 mov al, byte ptr [edx*2 + 0x5a7067]
004d2438 shr al, 1
004d243b mov cl, al
004d243d mov eax, dword ptr [0x89d178]
004d2442 mov edx, eax
004d2444 lea ebx, [eax + eax*8]
004d2447 lea eax, [edx + ebx*8]
004d244a lea eax, [edx + eax*4]
004d244d shl eax, 2
004d2450 lea eax, [edx + eax*8]
004d2453 add eax, 0x24df
004d2458 mov dword ptr [0x89d178], eax
004d245d mov dword ptr [esp + 0x18], eax
004d2461 ror dword ptr [esp + 0x18], 0xd
004d2466 mov eax, dword ptr [esp + 0x18]
004d246a sub edx, edx
004d246c mov dword ptr [0x89d178], eax
004d2471 div ecx
004d2473 add cl, dl
004d2475 xor eax, eax
004d2477 mov al, byte ptr [esi + 0x2b]
004d247a mov byte ptr [esi + 0x7b], cl
004d247d lea ecx, [eax + eax*4]
004d2480 lea edx, [ecx + ecx*4]
004d2483 xor ecx, ecx
004d2485 mov al, byte ptr [edx*2 + 0x5a7068]
004d248c mov edx, dword ptr [0x89d178]
004d2492 shr al, 1
004d2495 lea ebx, [edx + edx*8]
004d2498 mov cl, al
004d249a mov eax, edx
004d249c lea edx, [edx + ebx*8]
004d249f lea edx, [eax + edx*4]
004d24a2 shl edx, 2
004d24a5 lea edx, [eax + edx*8]
004d24a8 add edx, 0x24df
004d24ae mov dword ptr [0x89d178], edx
004d24b4 mov dword ptr [esp + 0x14], edx
004d24b8 ror dword ptr [esp + 0x14], 0xd
004d24bd mov eax, dword ptr [esp + 0x14]
004d24c1 sub edx, edx
004d24c3 mov dword ptr [0x89d178], eax
004d24c8 div ecx
004d24ca mov word ptr [esi + 0x87], 0
004d24d3 and dword ptr [esi + 0x10], 0xff7fffff
004d24da add cl, dl
004d24dc mov byte ptr [esi + 0x7c], cl
004d24df jmp 0x4d26d1
004d24e4 push esi
004d24e5 call 0x4d5920
004d24ea add esp, 4
004d24ed test byte ptr [0x89c668], 4
004d24f4 je 0x4d26d1
004d24fa cmp byte ptr [esi + 0x2f], 0
004d24fe jne 0x4d26d1
004d2504 xor eax, eax
004d2506 mov al, byte ptr [esi + 0x2b]
004d2509 lea ecx, [eax + eax*4]
004d250c lea ebx, [ecx + ecx*4]
004d250f mov ecx, dword ptr [ebx*2 + 0x5a7070]
004d2516 lea edx, [ebx*2]
004d251d add ecx, ecx
004d251f test byte ptr [edx + 0x5a7090], 8
004d2526 je 0x4d2584
004d2528 mov eax, dword ptr [0x89d178]
004d252d mov edx, eax
004d252f lea ebx, [eax + eax*8]
004d2532 lea eax, [edx + ebx*8]
004d2535 lea eax, [edx + eax*4]
004d2538 shl eax, 2
004d253b lea eax, [edx + eax*8]
004d253e add eax, 0x24df
004d2543 mov dword ptr [0x89d178], eax
004d2548 mov dword ptr [esp + 0x10], eax
004d254c ror dword ptr [esp + 0x10], 0xd
004d2551 mov eax, dword ptr [esp + 0x10]
004d2555 mov dword ptr [0x89d178], eax
004d255a mov eax, ecx
004d255c cdq 
004d255d and edx, 3
004d2560 add eax, edx
004d2562 sub edx, edx
004d2564 sar eax, 2
004d2567 mov ebx, eax
004d2569 mov eax, dword ptr [esp + 0x10]
004d256d div ebx
004d256f mov ebx, edx
004d2571 lea eax, [ecx + ecx*2]
004d2574 cdq 
004d2575 and edx, 3
004d2578 add eax, edx
004d257a sar eax, 2
004d257d lea ecx, [ebx + eax]
004d2580 mov word ptr [esi + 0x6c], cx
004d2584 mov word ptr [esi + 0x6e], cx
004d2588 jmp 0x4d26d1
004d258d push esi
004d258e call 0x4d5920
004d2593 add esp, 4
004d2596 jmp 0x4d26d1
004d259b push esi
004d259c call 0x4d5920
004d25a1 add esp, 4
004d25a4 jmp 0x4d26d1
004d25a9 push esi
004d25aa call 0x4d5920
004d25af add esp, 4
004d25b2 mov al, byte ptr [esi + 0x2f]
004d25b5 or dword ptr [esi + 0x10], 0x20
004d25b9 shl al, 6
004d25bc mov byte ptr [esi + 0xb2], al
004d25c2 jmp 0x4d26d1
004d25c7 push esi
004d25c8 call 0x4d5920
004d25cd add esp, 4
004d25d0 jmp 0x4d26d1
004d25d5 push esi
004d25d6 call 0x4d5920
004d25db movsx eax, byte ptr [esi + 0x2f]
004d25df lea edx, [eax + eax*4]
004d25e2 add esp, 4
004d25e5 mov ecx, eax
004d25e7 lea eax, [ecx + edx*2]
004d25ea lea ebx, [eax + eax*8]
004d25ed lea edx, [ecx + ebx*8]
004d25f0 mov dword ptr [ecx + edx*4 + 0x89da65], esi
004d25f7 jmp 0x4d26d1
004d25fc push esi
004d25fd call 0x4d5920
004d2602 add esp, 4
004d2605 push 0
004d2607 push 0xd8
004d260c push esi
004d260d call 0x48a050
004d2612 add esp, 0xc
004d2615 mov eax, dword ptr [esi + 0xc]
004d2618 or eax, 0x40000
004d261d mov dword ptr [esi + 0xc], eax
004d2620 or eax, 0x4000
004d2625 mov dword ptr [esi + 0xc], eax
004d2628 mov eax, dword ptr [esi + 0x10]
004d262b or eax, 0x80
004d2630 mov dword ptr [esi + 0x10], eax
004d2633 and eax, 0xff7fffff
004d2638 mov dword ptr [esi + 0x10], eax
004d263b mov eax, dword ptr [0x89d178]
004d2640 mov ecx, eax
004d2642 lea edx, [eax + eax*8]
004d2645 lea eax, [ecx + edx*8]
004d2648 lea eax, [ecx + eax*4]
004d264b shl eax, 2
004d264e lea eax, [ecx + eax*8]
004d2651 add eax, 0x24df
004d2656 mov dword ptr [0x89d178], eax
004d265b mov dword ptr [esp + 0xc], eax
004d265f ror dword ptr [esp + 0xc], 0xd
004d2664 mov eax, dword ptr [esp + 0xc]
004d2668 mov ecx, eax
004d266a mov dword ptr [0x89d178], eax
004d266f and ecx, 0x7ff
004d2675 mov eax, dword ptr [esi + 0xc]
004d2678 test al, 0x80
004d267a je 0x4d2680
004d267c mov word ptr [esi + 0x57], cx
004d2680 test ah, 0x80
004d2683 mov word ptr [esi + 0x5d], cx
004d2687 je 0x4d2693
004d2689 add cx, 0x400
004d268e and cx, 0x7ff
004d2693 mov word ptr [esi + 0x26], cx
004d2697 push 0
004d2699 push 0
004d269b lea eax, [esi + 0x33]
004d269e push eax
004d269f call 0x4ee700
004d26a4 mov ax, word ptr [esi + 0x35]
004d26a8 add esp, 0xc
004d26ab mov ecx, dword ptr [esi + 0xc]
004d26ae or ah, 1
004d26b1 mov word ptr [esi + 0x35], ax
004d26b5 or ecx, 0x10000000
004d26bb or al, 0x10
004d26bd mov dword ptr [esi + 0xc], ecx
004d26c0 mov word ptr [esi + 0x35], ax
004d26c4 or ecx, 0x40000000
004d26ca mov byte ptr [esi + 0x2d], 0
004d26ce mov dword ptr [esi + 0xc], ecx
004d26d1 xor eax, eax
004d26d3 mov al, byte ptr [esi + 0x2b]
004d26d6 cmp eax, 1
004d26d9 je 0x4d26f3
004d26db cmp eax, 8
004d26de je 0x4d26f3
004d26e0 xor eax, eax
004d26e2 inc dword ptr [edi + 0x91d]
004d26e8 mov al, byte ptr [esi + 0x2b]
004d26eb inc word ptr [edi + eax*2 + 0xa27]
004d26f3 mov ax, word ptr [esi + 0x3f]
004d26f7 mov cx, word ptr [esi + 0x3d]
004d26fb push eax
004d26fc push ecx
004d26fd call 0x44e940
004d2702 mov word ptr [esi + 0x41], ax
004d2706 add esp, 8
004d2709 and dword ptr [esi + 0x10], 0xfffffbff
004d2710 pop edi
004d2711 pop esi
004d2712 pop ebx
004d2713 add esp, 0x10
004d2716 ret 
004d2717 nop 
004d2718 pop ss
004d2719 and al, 0x4d
004d271b add ah, ah
004d271d and al, 0x4d
004d271f add byte ptr [ebp - 0x64ffb2db], cl
004d2725 and eax, 0x25a9004d
004d272a dec ebp
004d272b add bh, al
004d272d and eax, 0x25d5004d
004d2732 dec ebp
004d2733 add ah, bh
004d2735 and eax, 0xcccc004d
004d273a int3 
004d273b int3 
004d273c int3 
004d273d int3 
004d273e int3 
004d273f int3 
