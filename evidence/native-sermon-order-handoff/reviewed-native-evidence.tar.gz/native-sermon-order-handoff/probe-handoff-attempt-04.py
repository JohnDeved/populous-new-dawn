"""Finite native sermon -> manual order -> next listener consumer composition.
Synthetic flat world; native commands, listener acquisition, state initialization,
physics/routes and combat tails run. Only audio/UI/acknowledgement are intercepted.
No original campaign, save, wall clock, scheduler-world or tactical proof.
"""
import sys,json,struct,hashlib,traceback
from pathlib import Path
from collections import deque
exe,root=map(Path,sys.argv[1:3]);out=root/'work/orchestration/native-sermon-order-handoff'
baseline=root/'work/orchestration/native-guard-lifecycle-20261005/probe-guard-lifecycle.py'
code=baseline.read_text().split("report={'identity':identity",1)[0]
code=code.replace('cpu.hook_add(UC_HOOK_CODE,hook)','# replaced observer')
exec(compile(code,str(baseline),'exec'),globals())
# The baseline supplies only PE/constants/frames/helper functions; no native trials.
fields.update(tribe=(0x2f,'b'),workTarget=(0x89,'H'),timer=(0x70,'h'),life=(0x6e,'h'),
 health=(0x6c,'h'),route=(0x63,'h'),commandAux=(0xa9,'B'),statusFlags=(0xb2,'B'),
 lastState=(0x7d,'B'),cellNext=(0x20,'H'),cellPrev=(0x22,'H'))
listener1,listener2,head,trigger=0x2001000,0x2001100,0x2001200,0x2001300
actors=[p,listener1,listener2]
def person(ptr):
 d={k:read(ptr+off,fmt) for k,(off,fmt) in fields.items()}
 d['commands']=list(struct.unpack('<8H',cpu.mem_read(ptr+0x8b,16)))
 d['immediate']=read(ptr+0x9b,'H');return d
def snap():
 return {'people':[person(q) for q in actors], 'orders':[dict(zip(('model','flags','references','object','a','b'),struct.unpack('<BB4H',cpu.mem_read(pool+i*10,10)))) for i in range(12)],
  'headCounts':list(struct.unpack('<4h',cpu.mem_read(trigger+0x86,8))), 'randomState':read(0x89d178,'I')}
observed.update({0x444f60:'manual-packet',0x435780:'stage-packet',0x436ff0:'commit-orders',
 0x43a4d0:'sermon',0x43abf0:'acquire-listeners',0x43aec0:'release-scan',
 0x4d8300:'initialize-listener',0x4d83b0:'listener-update',0x4d32b0:'person-processor',
 0x4ed700:'person-dispatch',0x4d4690:'combat-tail',0x4d44e0:'engagement-eligibility',0x51ff60:'engagement-range',0x51e5e0:'melee-scan',0x51e7b0:'preacher-scan',0x51eab0:'melee-area-search',0x51f030:'preacher-area-search',0x520480:'auto-order-install',0x508f70:'worship-trigger-lookup',0x4d5120:'combat-decision',
 0x4d9bd0:'person-tail',0x4dba40:'combat-target-search',0x4d43a0:'health-tail',
 0x43bcc0:'worship',0x43c340:'worship-place',0x4fb270:'head-admission',0x4d4b50:'kill-person',
 0x4e9d80:'destination',0x4e6d00:'physics',0x4ee470:'cell-insert',0x4ea460:'release-route',0x4eadc0:'route-advance'})
leaves={0x47a550:'selection-ui',0x48a050:'audio',0x436330:'command-acknowledgement'}
watch={};events=[];recent=deque(maxlen=30)
class Boundary(Exception):pass
abort={0x4ed8a0:'allocation not initialized in this supplied world',0x401b40:'free pool not initialized'}
def observe(c,a,size,u):
 recent.append(f'{a:08x}');sp=c.reg_read(UC_X86_REG_ESP)
 if a in watch and watch[a] and sp==watch[a][-1][0]+4:
  _,name=watch[a].pop();events.append(dict(event='return',name=name,address=f'{a:08x}',returnLowByte=c.reg_read(UC_X86_REG_EAX)&255,snapshot=snap()))
 if a in abort:raise Boundary(f'{abort[a]} at {a:08x}; return {read(sp,"I"):08x}')
 if a not in observed and a not in leaves:return
 ret=read(sp,'I');name=observed.get(a,leaves.get(a));e=dict(event='enter',name=name,address=f'{a:08x}',callerReturn=f'{ret:08x}',arg0=f'{read(sp+4,"I"):08x}',snapshot=snap())
 if a in leaves:
  e['supplied']=True;c.reg_write(UC_X86_REG_EAX,0);c.reg_write(UC_X86_REG_EIP,ret);c.reg_write(UC_X86_REG_ESP,sp+4)
 else:watch.setdefault(ret,[]).append((sp,name))
 events.append(e)
cpu.hook_add(UC_HOOK_CODE,observe)
search=exe.parent/'data/mwsearch.dat';cpu.mem_write(0x8929cd,search.read_bytes());call(0x42c210);call(0x429ad0)
pristine=[(a,bytes(cpu.mem_read(a,b-a+1))) for a,b,_ in cpu.mem_regions()]
report={'identity':identity,'sourceHead':'3b899125cc8cedef938823718ad5d44f49957b66','python':sys.version,'unicorn':unicorn_version,'capstone':capstone_version,
 'suppliedLeaves':{f'{a:08x}':n for a,n in leaves.items()},'limits':__doc__,'cases':[],'inputs':{}}
for f in [exe,search,exe.parent/'levels/constant.dat',exe.parent/'data/vstart-0.ani',exe.parent/'data/vfra-0.ani',baseline,Path(__file__),root/'scripts/decomp.py',root/'app/original-rules.json',root/'app/original-constants.json']:
 report['inputs'][str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
def setup(n,model=4):
 for a,data in pristine:cpu.mem_write(a,data)
 fixture();cpu.mem_write(s,bytes(256));cpu.mem_write(listener1,bytes(0x400))
 write(tribe+0x89d,'I',0);write(tribe+0x881,'I',p);write(p+8,'I',0)
 write(tribe+2*0xc65+0x881,'I',listener1 if n else 0)
 write(0x890324,'I',p);write(0x890330,'I',0)
 cpu.mem_write(0x955c29,bytes(401*109));write(0x9557ae,'hhh',0,0,0)
 write(0x9557b6,'II',0,0);write(0x9557c0,'B',0);write(0x9557c8,'I',0)
 for q,ident,m,team,x,y in [(p,1,model,0,4224,4224),*( [(listener1,2,2,2,4480,4224)] if n else []),*([(listener2,3,2,2,4224,4480)] if n>1 else [])]:
  cpu.mem_write(q,bytes(256));write(q+0x24,'H',ident);write(q+0x2a,'BBB',1,m,19);write(q+0x2f,'b',team)
  write(q+0x30,'B',rules['personModels'][m]['physics']);write(q+0x3d,'HH',x,y)
  write(q+0x4f,'6H',x,y,x,y,x,y);write(q+0x68,'HH',x,y);write(q+0x6c,'hh',1000,1000)
  write(q+0x33,'HHhBB',48,0x100,1,3,18);write(0x890390+ident*4,'I',q)
  call(0x4ee470,q,q+0x3d)
 write(p+0x7a,'B',128);write(p+0x14,'I',0x40000)
 if n>1:write(listener1+8,'I',listener2)
 write(head+0x24,'H',100);write(head+0x2a,'BB',5,9);write(head+0x26,'H',0);write(head+0x3d,'HH',5632,4096);write(head+0xc,'I',0x20000)
 write(0x890390+100*4,'I',head)
 write(trigger+0x2a,'BB',6,6);write(trigger+0x2e,'B',4);write(trigger+0x3d,'HH',5632,4096)
 write(trigger+0x68,'BB',0,1);write(trigger+0x6d,'B',1);write(trigger+0x8e,'h',1);write(trigger+0x92,'H',100);write(trigger+0x9a,'i',100000)
 events.clear();watch.clear()
def stage(label,entry,*args):
 events.clear();watch.clear();before=snap();value=call(entry,*args)
 row=dict(label=label,entry=f'{entry:08x}',returnLowByte=value&255,before=before,after=snap(),events=list(events));report['cases'][-1]['stages'].append(row);return row
def packet_order(model,target):
 write(packet+4,'IIB',model|((target<<16) if model==27 else 0),(0 if model==27 else target)|0x20000,0x57);return stage(f'manual command {model}',0x444f60,tribe,packet)
for n,cmd in [(1,27),(2,27),(1,3),(2,3),(0,27)]:
 case={'label':f'listeners{n}-command{cmd}','stages':[]};report['cases'].append(case)
 try:
  setup(n)
  if n:
   packet_order(17,0x1010);stage('prepare sermon',0x4d42a0,p)
   for turn in range(1,81):
    write(p+0x2e,'B',turn&255);write(0x89d188,'I',turn)
    stage(f'sermon command visit {turn}',0x432590,p)
    if all(read(q+0x2c,'B')==23 and read(q+0x89,'H')==1 for q in actors[1:n+1]):break
   else:raise Boundary('no native acquisition within 80 command visits')
   case['acquisitionVisits']=turn
  write(p+0x7a,'B',128)
  packet_order(cmd,100 if cmd==27 else 0x1610)
  for q in actors[1:n+1]:
   stage(f'next listener full person id{read(q+0x24,"H")}',0x4ed700,q)
  stage('next preacher full person',0x4ed700,p)
  if n:
   for q in actors[1:n+1]:
    stage(f'following listener person id{read(q+0x24,"H")}',0x4ed700,q)
  case['status']='passed'
 except Exception as e:
  case.update(status='blocked',error=str(e),failure={'eip':f'{cpu.reg_read(UC_X86_REG_EIP):08x}','recent':list(recent),'snapshot':snap(),'events':list(events)},traceback=traceback.format_exc())
report['status']='passed' if all(c['status']=='passed' for c in report['cases']) else 'partial'
print(json.dumps(report,indent=2))
