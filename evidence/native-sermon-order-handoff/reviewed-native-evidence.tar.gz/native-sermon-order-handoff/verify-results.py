import json,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
read=lambda name:json.loads((out/name).read_text())
h=read('final-handoff.json');c=read('final-converted.json')['cases'][0];o=read('final-ordinary.json')['cases'][0];receipt=read('receipt.json')
assert h['identity']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
assert h['status']=='bounded-pass-with-encounter-boundary'
summary=[]
for case in h['cases']:
 n=int(case['label'][9]);cmd=int(case['label'].split('command')[1])
 if not n:assert case['status']=='passed';continue
 packet=next(s for s in case['stages'] if s['label']==f'manual command {cmd}')
 assert packet['after']['people'][0]['status']==cmd
 assert not any(e['name']=='release-scan' for e in packet['events'])
 for i in range(1,n+1):
  before=packet['before']['people'][i];after=packet['after']['people'][i]
  assert before==after and after['state']==23 and after['workTarget']==1 and after['flags4']&128 and after['flags2']&0x200000
  released=next(s for s in case['stages'] if s['label']==f'next listener full person id{i+1}')
  q=released['after']['people'][i]
  assert q['state']==10 and q['workTarget']==0 and not q['flags4']&128 and not q['flags2']&0x200000 and q['tribe']==2
  assert q['immediate'] and released['after']['orders'][q['immediate']]['model']==21
  names=[e['name'] for e in released['events'] if e['event']=='enter']
  assert names.index('listener-update')<names.index('initialize-person')<names.index('combat-tail')<names.index('melee-scan')
  assert any(e['name']=='engagement-eligibility' and e.get('returnLowByte')==1 for e in released['events'])
 f=case['failure'];assert f['eip']=='004ed8a0' and f['stackWords'][0]==0x51e180 and f['stackWords'][1:4]==[10,9,255]
 q=f['snapshot']['people'][1];assert q['target']==1 and q['workTarget']==1 and q['status']==21
 summary.append({'case':case['label'],'listenersReleaseOnOwnVisit':n,'immediateAttackAreaOrder':21,'followingListenerTarget':q['target'],'encounterAllocationBoundary':'004ed8a0 <- 0051e180, class10/model9/owner255'})
assert c['status']=='passed' and c['convertedAt']==1328 and c['admittedAt']==20
assert not c['unforcedInputs']['loadFlagsByte3']&4 and not c['unforcedInputs']['victimTribeFlags']&64
new=c['replacement'];admitted=c['admittedPerson']
assert new['class']==1 and new['model']==2 and new['tribe']==0 and new['id']==640
assert new['flags4']&0x40000 and new['flags3']&0x1000000
assert admitted['flags4']==new['flags4'] and admitted['flags3']==new['flags3']
assert c['afterWorshipPacket']['status']==27 and c['afterWorshipPacket']['target']==100
assert c['stages'][-1]['after']['headCounts']==[1,0,0,0]
conversion=next(s for s in c['stages'] if s['label']=='producer and listener visit 1328')
old=conversion['after']['people'][1];assert old['class']==0 and old['flags2']&1
assert any(e['name']=='allocate-object' and e.get('arg0')=='00000001' for e in conversion['events'])
assert any(e['name']=='construct-person' for e in conversion['events'])
assert o['status']=='passed' and o['admittedAt']==30 and o['stages'][-1]['after']['headCounts']==[1,0,0,0]
assert receipt['sourceStable'] and receipt['headBefore']=='3b899125cc8cedef938823718ad5d44f49957b66' and receipt['statusBefore']==''
for run in receipt['runs']:
 assert run['exitCode']==0 and run['durationSeconds']<60
 assert hashlib.sha256(Path(run['stdout']).read_bytes()).hexdigest()==run['stdoutSha256']
for path,expected in receipt['inputsAfter'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
result={'status':'passed','handoff':summary,'converted':{'nativeReplacementId':640,'conversionVisit':1328,'worshipArrivalVisits':20,'flags4':hex(new['flags4']),'flags3':hex(new['flags3']),'admittedCounts':[1,0,0,0]},'ordinaryWorshipArrivalVisits':30,'sourceStable':True,'limits':['Synthetic flat world and selected actor roster; no original M3 snapshot','Per-person/sermon schedule supplied, not uninterrupted full-world scheduler','444f60 simulation packet entry exercised; pre-packet frontend/C1 call chain unexecuted','No completed encounter, combat damage, kill, spell AI, campaign cause, or route/tactic safety claim','Conversion allocation and native roster rebuild executed; actors/saved game/world provenance remains synthetic']}
(out/'verified-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
