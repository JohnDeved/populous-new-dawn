004d83b0 83ec34               sub esp, 0x34
004d83b3 53                   push ebx
004d83b4 56                   push esi
004d83b5 8b742440             mov esi, dword ptr [esp + 0x40]
004d83b9 57                   push edi
004d83ba 0fbe462f             movsx eax, byte ptr [esi + 0x2f]
004d83be 55                   push ebp
004d83bf 8bc8                 mov ecx, eax
004d83c1 8d1480               lea edx, [eax + eax*4]
004d83c4 33ff                 xor edi, edi
004d83c6 8d0451               lea eax, [ecx + edx*2]
004d83c9 8d1cc0               lea ebx, [eax + eax*8]
004d83cc 668b8689000000       mov ax, word ptr [esi + 0x89]
004d83d3 8d14d9               lea edx, [ecx + ebx*8]
004d83d6 8d9c91c8d18900       lea ebx, [ecx + edx*4 + 0x89d1c8]
004d83dd 33c9                 xor ecx, ecx
004d83df 663bc1               cmp ax, cx
004d83e2 894c2424             mov dword ptr [esp + 0x24], ecx
004d83e6 7417                 je 0x4d83ff
004d83e8 0fb7c0               movzx eax, ax
004d83eb 8b048590038900       mov eax, dword ptr [eax*4 + 0x890390]
004d83f2 f6400c01             test byte ptr [eax + 0xc], 1
004d83f6 7507                 jne 0x4d83ff
004d83f8 38482a               cmp byte ptr [eax + 0x2a], cl
004d83fb 7402                 je 0x4d83ff
004d83fd 8bf8                 mov edi, eax
004d83ff 85ff                 test edi, edi
004d8401 0f84ce090000         je 0x4d8dd5
004d8407 f7460c04200000       test dword ptr [esi + 0xc], 0x2004
004d840e 0f8574090000         jne 0x4d8d88
004d8414 8a472c               mov al, byte ptr [edi + 0x2c]
004d8417 3c0a                 cmp al, 0xa
004d8419 7408                 je 0x4d8423
004d841b 3c21                 cmp al, 0x21
004d841d 0f8565090000         jne 0x4d8d88
004d8423 33d2                 xor edx, edx
004d8425 33c0                 xor eax, eax
004d8427 668b879b000000       mov ax, word ptr [edi + 0x9b]
004d842e 3bc2                 cmp eax, edx
004d8430 7405                 je 0x4d8437
004d8432 8d0480               lea eax, [eax + eax*4]
004d8435 eb1a                 jmp 0x4d8451
004d8437 33c0                 xor eax, eax
004d8439 33ed                 xor ebp, ebp
004d843b 8a87a6000000         mov al, byte ptr [edi + 0xa6]
004d8441 668bac478b000000     mov bp, word ptr [edi + eax*2 + 0x8b]
004d8449 85ed                 test ebp, ebp
004d844b 740b                 je 0x4d8458
004d844d 8d44ad00             lea eax, [ebp + ebp*4]
004d8451 8d144530889300       lea edx, [eax*2 + 0x938830]
004d8458 85d2                 test edx, edx
004d845a 0f8428090000         je 0x4d8d88
004d8460 f6420101             test byte ptr [edx + 1], 1
004d8464 0f851e090000         jne 0x4d8d88
004d846a 8a02                 mov al, byte ptr [edx]
004d846c 3c11                 cmp al, 0x11
004d846e 740c                 je 0x4d847c
004d8470 3c1f                 cmp al, 0x1f
004d8472 7408                 je 0x4d847c
004d8474 3c20                 cmp al, 0x20
004d8476 0f850c090000         jne 0x4d8d88
004d847c f7470c04200000       test dword ptr [edi + 0xc], 0x2004
004d8483 0f85ff080000         jne 0x4d8d88
004d8489 66837f5f00           cmp word ptr [edi + 0x5f], 0
004d848e 0f85f4080000         jne 0x4d8d88
004d8494 668b4670             mov ax, word ptr [esi + 0x70]
004d8498 6685c0               test ax, ax
004d849b 8d50ff               lea edx, [eax - 1]
004d849e 66895670             mov word ptr [esi + 0x70], dx
004d84a2 7c0d                 jl 0x4d84b1
004d84a4 f6834109000040       test byte ptr [ebx + 0x941], 0x40
004d84ab 0f84b6030000         je 0x4d8867
004d84b1 a178d18900           mov eax, dword ptr [0x89d178]
004d84b6 8bd0                 mov edx, eax
004d84b8 8d2cc0               lea ebp, [eax + eax*8]
004d84bb 8d04ea               lea eax, [edx + ebp*8]
004d84be 8d0482               lea eax, [edx + eax*4]
004d84c1 c1e002               shl eax, 2
004d84c4 8d04c2               lea eax, [edx + eax*8]
004d84c7 05df240000           add eax, 0x24df
004d84cc a378d18900           mov dword ptr [0x89d178], eax
004d84d1 89442430             mov dword ptr [esp + 0x30], eax
004d84d5 c14c24300d           ror dword ptr [esp + 0x30], 0xd
004d84da 8b442430             mov eax, dword ptr [esp + 0x30]
004d84de 2bd2                 sub edx, edx
004d84e0 a378d18900           mov dword ptr [0x89d178], eax
004d84e5 f73504a55a00         div dword ptr [0x5aa504]
004d84eb 83fa01               cmp edx, 1
004d84ee 7412                 je 0x4d8502
004d84f0 f60568c6890004       test byte ptr [0x89c668], 4
004d84f7 7509                 jne 0x4d8502
004d84f9 f6834109000040       test byte ptr [ebx + 0x941], 0x40
004d8500 7402                 je 0x4d8504
004d8502 b101                 mov cl, 1
004d8504 84c9                 test cl, cl
004d8506 0f84fe020000         je 0x4d880a
004d850c f6461108             test byte ptr [esi + 0x11], 8
004d8510 0f85d2020000         jne 0x4d87e8
004d8516 0fbe472f             movsx eax, byte ptr [edi + 0x2f]
004d851a 8bc8                 mov ecx, eax
004d851c 8d1480               lea edx, [eax + eax*4]
004d851f 8d0451               lea eax, [ecx + edx*2]
004d8522 8d2cc0               lea ebp, [eax + eax*8]
004d8525 8d14e9               lea edx, [ecx + ebp*8]
004d8528 81bc91e5da8900c8000000 cmp dword ptr [ecx + edx*4 + 0x89dae5], 0xc8
004d8533 7c0d                 jl 0x4d8542
004d8535 f6834109000040       test byte ptr [ebx + 0x941], 0x40
004d853c 0f84ae020000         je 0x4d87f0
004d8542 8b0d43248900         mov ecx, dword ptr [0x892443]
004d8548 0fbf463d             movsx eax, word ptr [esi + 0x3d]
004d854c 8901                 mov dword ptr [ecx], eax
004d854e 8b0d43248900         mov ecx, dword ptr [0x892443]
004d8554 0fbf563f             movsx edx, word ptr [esi + 0x3f]
004d8558 895104               mov dword ptr [ecx + 4], edx
004d855b 8b0d43248900         mov ecx, dword ptr [0x892443]
004d8561 0fbf465d             movsx eax, word ptr [esi + 0x5d]
004d8565 894108               mov dword ptr [ecx + 8], eax
004d8568 33c9                 xor ecx, ecx
004d856a 8b1543248900         mov edx, dword ptr [0x892443]
004d8570 8d463d               lea eax, [esi + 0x3d]
004d8573 50                   push eax
004d8574 894a0c               mov dword ptr [edx + 0xc], ecx
004d8577 8b1543248900         mov edx, dword ptr [0x892443]
004d857d 894a10               mov dword ptr [edx + 0x10], ecx
004d8580 83054324890014       add dword ptr [0x892443], 0x14
004d8587 c6053a24890001       mov byte ptr [0x89243a], 1
004d858e 8a4f2f               mov cl, byte ptr [edi + 0x2f]
004d8591 8a562b               mov dl, byte ptr [esi + 0x2b]
004d8594 51                   push ecx
004d8595 52                   push edx
004d8596 6a01                 push 1
004d8598 e803530100           call 0x4ed8a0
004d859d 83c410               add esp, 0x10
004d85a0 8bd8                 mov ebx, eax
004d85a2 0fbe462f             movsx eax, byte ptr [esi + 0x2f]
004d85a6 8bc8                 mov ecx, eax
004d85a8 8d1480               lea edx, [eax + eax*4]
004d85ab 8d0451               lea eax, [ecx + edx*2]
004d85ae 8d2cc0               lea ebp, [eax + eax*8]
004d85b1 8d14e9               lea edx, [ecx + ebp*8]
004d85b4 66ff8491e5db8900     inc word ptr [ecx + edx*4 + 0x89dbe5]
004d85bc a178d18900           mov eax, dword ptr [0x89d178]
004d85c1 8bc8                 mov ecx, eax
004d85c3 8d2cc0               lea ebp, [eax + eax*8]
004d85c6 8d14e9               lea edx, [ecx + ebp*8]
004d85c9 8d0491               lea eax, [ecx + edx*4]
004d85cc c1e002               shl eax, 2
004d85cf 8d04c1               lea eax, [ecx + eax*8]
004d85d2 05df240000           add eax, 0x24df
004d85d7 a378d18900           mov dword ptr [0x89d178], eax
004d85dc 8944242c             mov dword ptr [esp + 0x2c], eax
004d85e0 c14c242c0d           ror dword ptr [esp + 0x2c], 0xd
004d85e5 8b44242c             mov eax, dword ptr [esp + 0x2c]
004d85e9 8d542438             lea edx, [esp + 0x38]
004d85ed 8bc8                 mov ecx, eax
004d85ef a378d18900           mov dword ptr [0x89d178], eax
004d85f4 83e13f               and ecx, 0x3f
004d85f7 8d442434             lea eax, [esp + 0x34]
004d85fb 50                   push eax
004d85fc 52                   push edx
004d85fd 51                   push ecx
004d85fe 6a40                 push 0x40
004d8600 6800050000           push 0x500
004d8605 e81635fcff           call 0x49bb20
004d860a 668b473d             mov ax, word ptr [edi + 0x3d]
004d860e 83c414               add esp, 0x14
004d8611 6603442438           add ax, word ptr [esp + 0x38]
004d8616 6689442414           mov word ptr [esp + 0x14], ax
004d861b 668b473f             mov ax, word ptr [edi + 0x3f]
004d861f 6603442434           add ax, word ptr [esp + 0x34]
004d8624 85db                 test ebx, ebx
004d8626 6689442416           mov word ptr [esp + 0x16], ax
004d862b 0f84bf010000         je 0x4d87f0
004d8631 668b442414           mov ax, word ptr [esp + 0x14]
004d8636 668b4c2416           mov cx, word ptr [esp + 0x16]
004d863b 88642412             mov byte ptr [esp + 0x12], ah
004d863f 33c0                 xor eax, eax
004d8641 886c2413             mov byte ptr [esp + 0x13], ch
004d8645 668b442412           mov ax, word ptr [esp + 0x12]
004d864a 33c9                 xor ecx, ecx
004d864c 668b4c2412           mov cx, word ptr [esp + 0x12]
004d8651 25fe000000           and eax, 0xfe
004d8656 03c0                 add eax, eax
004d8658 81e100fe0000         and ecx, 0xfe00
004d865e 0bc1                 or eax, ecx
004d8660 8d0c85e4038a00       lea ecx, [eax*4 + 0x8a03e4]
004d8667 f6410102             test byte ptr [ecx + 1], 2
004d866b 7420                 je 0x4d868d
004d866d 8d442414             lea eax, [esp + 0x14]
004d8671 50                   push eax
004d8672 33c0                 xor eax, eax
004d8674 668b4108             mov ax, word ptr [ecx + 8]
004d8678 25ff030000           and eax, 0x3ff
004d867d 8b0c8590038900       mov ecx, dword ptr [eax*4 + 0x890390]
004d8684 51                   push ecx
004d8685 e826bef2ff           call 0x4044b0
004d868a 83c408               add esp, 8
004d868d 8d442414             lea eax, [esp + 0x14]
004d8691 50                   push eax
004d8692 53                   push ebx
004d8693 e8e8160100           call 0x4e9d80
004d8698 8b44241c             mov eax, dword ptr [esp + 0x1c]
004d869c 83c408               add esp, 8
004d869f 894368               mov dword ptr [ebx + 0x68], eax
004d86a2 662500fe             and ax, 0xfe00
004d86a6 66050001             add ax, 0x100
004d86aa 66894368             mov word ptr [ebx + 0x68], ax
004d86ae 668b436a             mov ax, word ptr [ebx + 0x6a]
004d86b2 662500fe             and ax, 0xfe00
004d86b6 66050001             add ax, 0x100
004d86ba 6689436a             mov word ptr [ebx + 0x6a], ax
004d86be 8a8382000000         mov al, byte ptr [ebx + 0x82]
004d86c4 24f0                 and al, 0xf0
004d86c6 888382000000         mov byte ptr [ebx + 0x82], al
004d86cc 240f                 and al, 0xf
004d86ce 888382000000         mov byte ptr [ebx + 0x82], al
004d86d4 33c0                 xor eax, eax
004d86d6 8a4330               mov al, byte ptr [ebx + 0x30]
004d86d9 8bc8                 mov ecx, eax
004d86db 8d1480               lea edx, [eax + eax*4]
004d86de 8d0492               lea eax, [edx + edx*4]
004d86e1 0fbf8c08947b5a00     movsx ecx, word ptr [eax + ecx + 0x5a7b94]
004d86e9 8be9                 mov ebp, ecx
004d86eb c1fd02               sar ebp, 2
004d86ee 85ed                 test ebp, ebp
004d86f0 7505                 jne 0x4d86f7
004d86f2 bd01000000           mov ebp, 1
004d86f7 a178d18900           mov eax, dword ptr [0x89d178]
004d86fc 8bd0                 mov edx, eax
004d86fe 8d04c0               lea eax, [eax + eax*8]
004d8701 8d04c2               lea eax, [edx + eax*8]
004d8704 8d0482               lea eax, [edx + eax*4]
004d8707 c1e002               shl eax, 2
004d870a 8d04c2               lea eax, [edx + eax*8]
004d870d 05df240000           add eax, 0x24df
004d8712 a378d18900           mov dword ptr [0x89d178], eax
004d8717 89442428             mov dword ptr [esp + 0x28], eax
004d871b c14c24280d           ror dword ptr [esp + 0x28], 0xd
004d8720 8b442428             mov eax, dword ptr [esp + 0x28]
004d8724 2bd2                 sub edx, edx
004d8726 a378d18900           mov dword ptr [0x89d178], eax
004d872b f7f5                 div ebp
004d872d 8d0411               lea eax, [ecx + edx]
004d8730 6689435f             mov word ptr [ebx + 0x5f], ax
004d8734 f6431608             test byte ptr [ebx + 0x16], 8
004d8738 7407                 je 0x4d8741
004d873a 6603c0               add ax, ax
004d873d 6689435f             mov word ptr [ebx + 0x5f], ax
004d8741 66837b7801           cmp word ptr [ebx + 0x78], 1
004d8746 1bc0                 sbb eax, eax
004d8748 83e0fc               and eax, 0xfffffffc
004d874b 83c005               add eax, 5
004d874e 50                   push eax
004d874f 53                   push ebx
004d8750 e89bb8ffff           call 0x4d3ff0
004d8755 814b1000000400       or dword ptr [ebx + 0x10], 0x40000
004d875c 83c408               add esp, 8
004d875f 814b1400000001       or dword ptr [ebx + 0x14], 0x1000000
004d8766 57                   push edi
004d8767 e8149d0100           call 0x4f2480
004d876c 83c404               add esp, 4
004d876f 85c0                 test eax, eax
004d8771 7445                 je 0x4d87b8
004d8773 0fbe472f             movsx eax, byte ptr [edi + 0x2f]
004d8777 8bc8                 mov ecx, eax
004d8779 8d1480               lea edx, [eax + eax*4]
004d877c 8d0451               lea eax, [ecx + edx*2]
004d877f 8d2cc0               lea ebp, [eax + eax*8]
004d8782 8d14e9               lea edx, [ecx + ebp*8]
004d8785 0fbe8491eadd8900     movsx eax, byte ptr [ecx + edx*4 + 0x89ddea]
004d878d c1e004               shl eax, 4
004d8790 80bc401308960000     cmp byte ptr [eax + eax*2 + 0x960813], 0
004d8798 741e                 je 0x4d87b8
004d879a 33c0                 xor eax, eax
004d879c 8a462b               mov al, byte ptr [esi + 0x2b]
004d879f 8d0c80               lea ecx, [eax + eax*4]
004d87a2 8d1489               lea edx, [ecx + ecx*4]
004d87a5 33c9                 xor ecx, ecx
004d87a7 8a0c557e705a00       mov cl, byte ptr [edx*2 + 0x5a707e]
004d87ae 51                   push ecx
004d87af 57                   push edi
004d87b0 e8ab9d0100           call 0x4f2560
004d87b5 83c408               add esp, 8
004d87b8 8d463d               lea eax, [esi + 0x3d]
004d87bb 50                   push eax
004d87bc 68ff000000           push 0xff
004d87c1 6a3a                 push 0x3a
004d87c3 6a07                 push 7
004d87c5 e8d6500100           call 0x4ed8a0
004d87ca 83c410               add esp, 0x10
004d87cd 8bf8                 mov edi, eax
004d87cf 85ff                 test edi, edi
004d87d1 7415                 je 0x4d87e8
004d87d3 6a00                 push 0
004d87d5 6a05                 push 5
004d87d7 56                   push esi
004d87d8 e87318fbff           call 0x48a050
004d87dd 668b4324             mov ax, word ptr [ebx + 0x24]
004d87e1 83c40c               add esp, 0xc
004d87e4 66894772             mov word ptr [edi + 0x72], ax
004d87e8 c744242401000000     mov dword ptr [esp + 0x24], 1
004d87f0 837c242400           cmp dword ptr [esp + 0x24], 0
004d87f5 7409                 je 0x4d8800
004d87f7 56                   push esi
004d87f8 e853c3ffff           call 0x4d4b50
004d87fd 83c404               add esp, 4
004d8800 32c0                 xor al, al
004d8802 5d                   pop ebp
004d8803 5f                   pop edi
004d8804 5e                   pop esi
004d8805 5b                   pop ebx
004d8806 83c434               add esp, 0x34
004d8809 c3                   ret 
004d880a 8b0d00a55a00         mov ecx, dword ptr [0x5aa500]
004d8810 a100a55a00           mov eax, dword ptr [0x5aa500]
004d8815 c1f903               sar ecx, 3
004d8818 66894670             mov word ptr [esi + 0x70], ax
004d881c 85c9                 test ecx, ecx
004d881e 7447                 je 0x4d8867
004d8820 a178d18900           mov eax, dword ptr [0x89d178]
004d8825 8bd0                 mov edx, eax
004d8827 8d1cc0               lea ebx, [eax + eax*8]
004d882a 8d04da               lea eax, [edx + ebx*8]
004d882d 8d0482               lea eax, [edx + eax*4]
004d8830 c1e002               shl eax, 2
004d8833 8d04c2               lea eax, [edx + eax*8]
004d8836 05df240000           add eax, 0x24df
004d883b a378d18900           mov dword ptr [0x89d178], eax
004d8840 89442420             mov dword ptr [esp + 0x20], eax
004d8844 c14c24200d           ror dword ptr [esp + 0x20], 0xd
004d8849 8b442420             mov eax, dword ptr [esp + 0x20]
004d884d 2bd2                 sub edx, edx
004d884f a378d18900           mov dword ptr [0x89d178], eax
004d8854 f7f1                 div ecx
004d8856 8bda                 mov ebx, edx
004d8858 8bc1                 mov eax, ecx
004d885a 99                   cdq 
004d885b 2bc2                 sub eax, edx
004d885d c1f801               sar eax, 1
004d8860 662bd8               sub bx, ax
004d8863 66015e70             add word ptr [esi + 0x70], bx
004d8867 8a4e2d               mov cl, byte ptr [esi + 0x2d]
004d886a 33c0                 xor eax, eax
004d886c 8ac1                 mov al, cl
004d886e 83f806               cmp eax, 6
004d8871 0f87bb000000         ja 0x4d8932
004d8877 ff2485248e4d00       jmp dword ptr [eax*4 + 0x4d8e24]
004d887e 33c9                 xor ecx, ecx
004d8880 33c0                 xor eax, eax
004d8882 668b4e3d             mov cx, word ptr [esi + 0x3d]
004d8886 668b473d             mov ax, word ptr [edi + 0x3d]
004d888a 2bc8                 sub ecx, eax
004d888c 8bc1                 mov eax, ecx
004d888e 7904                 jns 0x4d8894
004d8890 8bc1                 mov eax, ecx
004d8892 f7d8                 neg eax
004d8894 f6c480               test ah, 0x80
004d8897 7411                 je 0x4d88aa
004d8899 85c9                 test ecx, ecx
004d889b 8d880000ffff         lea ecx, [eax - 0x10000]
004d88a1 7f07                 jg 0x4d88aa
004d88a3 b900000100           mov ecx, 0x10000
004d88a8 2bc8                 sub ecx, eax
004d88aa 33d2                 xor edx, edx
004d88ac 33c0                 xor eax, eax
004d88ae 668b563f             mov dx, word ptr [esi + 0x3f]
004d88b2 894c2438             mov dword ptr [esp + 0x38], ecx
004d88b6 668b473f             mov ax, word ptr [edi + 0x3f]
004d88ba 2bd0                 sub edx, eax
004d88bc 8bc2                 mov eax, edx
004d88be 7904                 jns 0x4d88c4
004d88c0 8bc2                 mov eax, edx
004d88c2 f7d8                 neg eax
004d88c4 f6c480               test ah, 0x80
004d88c7 7411                 je 0x4d88da
004d88c9 85d2                 test edx, edx
004d88cb 8d900000ffff         lea edx, [eax - 0x10000]
004d88d1 7f07                 jg 0x4d88da
004d88d3 ba00000100           mov edx, 0x10000
004d88d8 2bd0                 sub edx, eax
004d88da 52                   push edx
004d88db 33c0                 xor eax, eax
004d88dd 668b8689000000       mov ax, word ptr [esi + 0x89]
004d88e4 51                   push ecx
004d88e5 8954243c             mov dword ptr [esp + 0x3c], edx
004d88e9 50                   push eax
004d88ea e87132fcff           call 0x49bb60
004d88ef 83c40c               add esp, 0xc
004d88f2 83f8ff               cmp eax, -1
004d88f5 7445                 je 0x4d893c
004d88f7 8886a8000000         mov byte ptr [esi + 0xa8], al
004d88fd c1e002               shl eax, 2
004d8900 668b88e82a9700       mov cx, word ptr [eax + 0x972ae8]
004d8907 668b80ea2a9700       mov ax, word ptr [eax + 0x972aea]
004d890e 66034f3d             add cx, word ptr [edi + 0x3d]
004d8912 66894c2414           mov word ptr [esp + 0x14], cx
004d8917 8d4c2414             lea ecx, [esp + 0x14]
004d891b 6603473f             add ax, word ptr [edi + 0x3f]
004d891f 51                   push ecx
004d8920 668944241a           mov word ptr [esp + 0x1a], ax
004d8925 56                   push esi
004d8926 e855140100           call 0x4e9d80
004d892b c6462d01             mov byte ptr [esi + 0x2d], 1
004d892f 83c408               add esp, 8
004d8932 32c0                 xor al, al
004d8934 5d                   pop ebp
004d8935 5f                   pop edi
004d8936 5e                   pop esi
004d8937 5b                   pop ebx
004d8938 83c434               add esp, 0x34
004d893b c3                   ret 
004d893c b900000000           mov ecx, 0
004d8941 8b460c               mov eax, dword ptr [esi + 0xc]
004d8944 c6462d02             mov byte ptr [esi + 0x2d], 2
004d8948 66c7465f0000         mov word ptr [esi + 0x5f], 0
004d894e 66837e7801           cmp word ptr [esi + 0x78], 1
004d8953 83d1ff               adc ecx, -1
004d8956 6683e104             and cx, 4
004d895a a900000800           test eax, 0x80000
004d895f 7416                 je 0x4d8977
004d8961 f6461104             test byte ptr [esi + 0x11], 4
004d8965 66b90c00             mov cx, 0xc
004d8969 750c                 jne 0x4d8977
004d896b 66b90200             mov cx, 2
004d896f 25ff7fffff           and eax, 0xffff7fff
004d8974 89460c               mov dword ptr [esi + 0xc], eax
004d8977 0fbfc1               movsx eax, cx
004d897a 33d2                 xor edx, edx
004d897c 8d0cc0               lea ecx, [eax + eax*8]
004d897f 8a562b               mov dl, byte ptr [esi + 0x2b]
004d8982 03d1                 add edx, ecx
004d8984 668b0455506d5a00     mov ax, word ptr [edx*2 + 0x5a6d50]
004d898c 50                   push eax
004d898d 56                   push esi
004d898e e8adb6ffff           call 0x4d4040
004d8993 83c408               add esp, 8
004d8996 32c0                 xor al, al
004d8998 5d                   pop ebp
004d8999 5f                   pop edi
004d899a 5e                   pop esi
004d899b 5b                   pop ebx
004d899c 83c434               add esp, 0x34
004d899f c3                   ret 
004d89a0 f6462e01             test byte ptr [esi + 0x2e], 1
004d89a4 758c                 jne 0x4d8932
004d89a6 0fbf464f             movsx eax, word ptr [esi + 0x4f]
004d89aa 0fbf4e3d             movsx ecx, word ptr [esi + 0x3d]
004d89ae 2bc1                 sub eax, ecx
004d89b0 99                   cdq 
004d89b1 33c2                 xor eax, edx
004d89b3 2bc2                 sub eax, edx
004d89b5 83f870               cmp eax, 0x70
004d89b8 7d16                 jge 0x4d89d0
004d89ba 0fbf4651             movsx eax, word ptr [esi + 0x51]
004d89be 0fbf4e3f             movsx ecx, word ptr [esi + 0x3f]
004d89c2 2bc1                 sub eax, ecx
004d89c4 99                   cdq 
004d89c5 33c2                 xor eax, edx
004d89c7 2bc2                 sub eax, edx
004d89c9 83f870               cmp eax, 0x70
004d89cc b001                 mov al, 1
004d89ce 7c02                 jl 0x4d89d2
004d89d0 32c0                 xor al, al
004d89d2 84c0                 test al, al
004d89d4 0f8458ffffff         je 0x4d8932
004d89da 33db                 xor ebx, ebx
004d89dc 33c0                 xor eax, eax
004d89de 668b8689000000       mov ax, word ptr [esi + 0x89]
004d89e5 8a9ea8000000         mov bl, byte ptr [esi + 0xa8]
004d89eb 53                   push ebx
004d89ec 50                   push eax
004d89ed e82e32fcff           call 0x49bc20
004d89f2 83c408               add esp, 8
004d89f5 85c0                 test eax, eax
004d89f7 0f84bd000000         je 0x4d8aba
004d89fd 668b0c9de82a9700     mov cx, word ptr [ebx*4 + 0x972ae8]
004d8a05 8d049d00000000       lea eax, [ebx*4]
004d8a0c 668b80ea2a9700       mov ax, word ptr [eax + 0x972aea]
004d8a13 66034f3d             add cx, word ptr [edi + 0x3d]
004d8a17 66894c243c           mov word ptr [esp + 0x3c], cx
004d8a1c 6603473f             add ax, word ptr [edi + 0x3f]
004d8a20 668944243e           mov word ptr [esp + 0x3e], ax
004d8a25 66894c2414           mov word ptr [esp + 0x14], cx
004d8a2a 8b4c2414             mov ecx, dword ptr [esp + 0x14]
004d8a2e 6689442416           mov word ptr [esp + 0x16], ax
004d8a33 8b442416             mov eax, dword ptr [esp + 0x16]
004d8a37 50                   push eax
004d8a38 51                   push ecx
004d8a39 e8025ff7ff           call 0x44e940
004d8a3e 6689442448           mov word ptr [esp + 0x48], ax
004d8a43 8d4c2444             lea ecx, [esp + 0x44]
004d8a47 83c408               add esp, 8
004d8a4a 51                   push ecx
004d8a4b 56                   push esi
004d8a4c e82f5b0100           call 0x4ee580
004d8a51 83c408               add esp, 8
004d8a54 b800000000           mov eax, 0
004d8a59 c6462d02             mov byte ptr [esi + 0x2d], 2
004d8a5d 66c7465f0000         mov word ptr [esi + 0x5f], 0
004d8a63 66837e7801           cmp word ptr [esi + 0x78], 1
004d8a68 83d0ff               adc eax, -1
004d8a6b 8b4e0c               mov ecx, dword ptr [esi + 0xc]
004d8a6e 66250400             and ax, 4
004d8a72 f7c100000800         test ecx, 0x80000
004d8a78 7417                 je 0x4d8a91
004d8a7a f6461104             test byte ptr [esi + 0x11], 4
004d8a7e 66b80c00             mov ax, 0xc
004d8a82 750d                 jne 0x4d8a91
004d8a84 66b80200             mov ax, 2
004d8a88 81e1ff7fffff         and ecx, 0xffff7fff
004d8a8e 894e0c               mov dword ptr [esi + 0xc], ecx
004d8a91 0fbfc0               movsx eax, ax
004d8a94 33c9                 xor ecx, ecx
004d8a96 8d14c0               lea edx, [eax + eax*8]
004d8a99 8a4e2b               mov cl, byte ptr [esi + 0x2b]
004d8a9c 03ca                 add ecx, edx
004d8a9e 668b044d506d5a00     mov ax, word ptr [ecx*2 + 0x5a6d50]
004d8aa6 50                   push eax
004d8aa7 56                   push esi
004d8aa8 e893b5ffff           call 0x4d4040
004d8aad 83c408               add esp, 8
004d8ab0 32c0                 xor al, al
004d8ab2 5d                   pop ebp
004d8ab3 5f                   pop edi
004d8ab4 5e                   pop esi
004d8ab5 5b                   pop ebx
004d8ab6 83c434               add esp, 0x34
004d8ab9 c3                   ret 
004d8aba 32c0                 xor al, al
004d8abc 5d                   pop ebp
004d8abd c6462d00             mov byte ptr [esi + 0x2d], 0
004d8ac1 5f                   pop edi
004d8ac2 5e                   pop esi
004d8ac3 5b                   pop ebx
004d8ac4 83c434               add esp, 0x34
004d8ac7 c3                   ret 
004d8ac8 fec1                 inc cl
004d8aca 884e2d               mov byte ptr [esi + 0x2d], cl
004d8acd 81660cffffdfff       and dword ptr [esi + 0xc], 0xffdfffff
004d8ad4 668b473d             mov ax, word ptr [edi + 0x3d]
004d8ad8 662b463d             sub ax, word ptr [esi + 0x3d]
004d8adc 0fb7d8               movzx ebx, ax
004d8adf 668b473f             mov ax, word ptr [edi + 0x3f]
004d8ae3 8bcb                 mov ecx, ebx
004d8ae5 662b463f             sub ax, word ptr [esi + 0x3f]
004d8ae9 85db                 test ebx, ebx
004d8aeb 0fb7c0               movzx eax, ax
004d8aee 7d04                 jge 0x4d8af4
004d8af0 8bcb                 mov ecx, ebx
004d8af2 f7d9                 neg ecx
004d8af4 8bd0                 mov edx, eax
004d8af6 85c0                 test eax, eax
004d8af8 7d04                 jge 0x4d8afe
004d8afa 8bd0                 mov edx, eax
004d8afc f7da                 neg edx
004d8afe 81f900800000         cmp ecx, 0x8000
004d8b04 7c06                 jl 0x4d8b0c
004d8b06 8d990000ffff         lea ebx, [ecx - 0x10000]
004d8b0c 81fa00800000         cmp edx, 0x8000
004d8b12 7c06                 jl 0x4d8b1a
004d8b14 8d820000ffff         lea eax, [edx - 0x10000]
004d8b1a f7d8                 neg eax
004d8b1c 50                   push eax
004d8b1d 53                   push ebx
004d8b1e e851d50a00           call 0x586074
004d8b23 668bf8               mov di, ax
004d8b26 83c408               add esp, 8
004d8b29 6681e7ff07           and di, 0x7ff
004d8b2e 56                   push esi
004d8b2f e82c190100           call 0x4ea460
004d8b34 66897e57             mov word ptr [esi + 0x57], di
004d8b38 83c404               add esp, 4
004d8b3b 8b460c               mov eax, dword ptr [esi + 0xc]
004d8b3e 5d                   pop ebp
004d8b3f 0d80000000           or eax, 0x80
004d8b44 5f                   pop edi
004d8b45 89460c               mov dword ptr [esi + 0xc], eax
004d8b48 0d00100000           or eax, 0x1000
004d8b4d 89460c               mov dword ptr [esi + 0xc], eax
004d8b50 32c0                 xor al, al
004d8b52 5e                   pop esi
004d8b53 5b                   pop ebx
004d8b54 83c434               add esp, 0x34
004d8b57 c3                   ret 
004d8b58 f6462e0f             test byte ptr [esi + 0x2e], 0xf
004d8b5c 0f85d0fdffff         jne 0x4d8932
004d8b62 a178d18900           mov eax, dword ptr [0x89d178]
004d8b67 8bc8                 mov ecx, eax
004d8b69 8d14c0               lea edx, [eax + eax*8]
004d8b6c 8d04d1               lea eax, [ecx + edx*8]
004d8b6f 8d0481               lea eax, [ecx + eax*4]
004d8b72 c1e002               shl eax, 2
004d8b75 8d04c1               lea eax, [ecx + eax*8]
004d8b78 05df240000           add eax, 0x24df
004d8b7d a378d18900           mov dword ptr [0x89d178], eax
004d8b82 8944241c             mov dword ptr [esp + 0x1c], eax
004d8b86 c14c241c0d           ror dword ptr [esp + 0x1c], 0xd
004d8b8b 8b44241c             mov eax, dword ptr [esp + 0x1c]
004d8b8f a378d18900           mov dword ptr [0x89d178], eax
004d8b94 a801                 test al, 1
004d8b96 0f8596fdffff         jne 0x4d8932
004d8b9c 33c0                 xor eax, eax
004d8b9e fe462d               inc byte ptr [esi + 0x2d]
004d8ba1 8a462b               mov al, byte ptr [esi + 0x2b]
004d8ba4 660fb63c453a6e5a00   movzx di, byte ptr [eax*2 + 0x5a6e3a]
004d8bad 57                   push edi
004d8bae 56                   push esi
004d8baf e88cb4ffff           call 0x4d4040
004d8bb4 c6463900             mov byte ptr [esi + 0x39], 0
004d8bb8 83c408               add esp, 8
004d8bbb 33d2                 xor edx, edx
004d8bbd 0fb7cf               movzx ecx, di
004d8bc0 66c746370100         mov word ptr [esi + 0x37], 1
004d8bc6 8b3d44df5900         mov edi, dword ptr [0x59df44]
004d8bcc 8a563a               mov dl, byte ptr [esi + 0x3a]
004d8bcf 0fbf1c8d58685a00     movsx ebx, word ptr [ecx*4 + 0x5a6858]
004d8bd7 8bca                 mov ecx, edx
004d8bd9 8d2c5b               lea ebp, [ebx + ebx*2]
004d8bdc 8d1c92               lea ebx, [edx + edx*4]
004d8bdf 8a446f01             mov al, byte ptr [edi + ebp*2 + 1]
004d8be3 5d                   pop ebp
004d8be4 5f                   pop edi
004d8be5 8a8c59fb6a5a00       mov cl, byte ptr [ecx + ebx*2 + 0x5a6afb]
004d8bec fec1                 inc cl
004d8bee f6e9                 imul cl
004d8bf0 8886aa000000         mov byte ptr [esi + 0xaa], al
004d8bf6 32c0                 xor al, al
004d8bf8 5e                   pop esi
004d8bf9 5b                   pop ebx
004d8bfa 83c434               add esp, 0x34
004d8bfd c3                   ret 
004d8bfe 8a86aa000000         mov al, byte ptr [esi + 0xaa]
004d8c04 fec8                 dec al
004d8c06 8886aa000000         mov byte ptr [esi + 0xaa], al
004d8c0c 84c0                 test al, al
004d8c0e 0f8f1efdffff         jg 0x4d8932
004d8c14 fec1                 inc cl
004d8c16 33c0                 xor eax, eax
004d8c18 8a462b               mov al, byte ptr [esi + 0x2b]
004d8c1b 884e2d               mov byte ptr [esi + 0x2d], cl
004d8c1e 660fb604453a6e5a00   movzx ax, byte ptr [eax*2 + 0x5a6e3a]
004d8c27 50                   push eax
004d8c28 56                   push esi
004d8c29 e812b4ffff           call 0x4d4040
004d8c2e 83c408               add esp, 8
004d8c31 33c0                 xor eax, eax
004d8c33 c6463900             mov byte ptr [esi + 0x39], 0
004d8c37 66c746370100         mov word ptr [esi + 0x37], 1
004d8c3d 8a462b               mov al, byte ptr [esi + 0x2b]
004d8c40 0fbf14453a6e5a00     movsx edx, word ptr [eax*2 + 0x5a6e3a]
004d8c48 0fbf0c9558685a00     movsx ecx, word ptr [edx*4 + 0x5a6858]
004d8c50 a144df5900           mov eax, dword ptr [0x59df44]
004d8c55 8d1c49               lea ebx, [ecx + ecx*2]
004d8c58 0fbf7e78             movsx edi, word ptr [esi + 0x78]
004d8c5c 8a445801             mov al, byte ptr [eax + ebx*2 + 1]
004d8c60 804e3502             or byte ptr [esi + 0x35], 2
004d8c64 66c746370100         mov word ptr [esi + 0x37], 1
004d8c6a fec8                 dec al
004d8c6c 85ff                 test edi, edi
004d8c6e 884639               mov byte ptr [esi + 0x39], al
004d8c71 0f84bbfcffff         je 0x4d8932
004d8c77 7e37                 jle 0x4d8cb0
004d8c79 8d5e3d               lea ebx, [esi + 0x3d]
004d8c7c 53                   push ebx
004d8c7d 68ff000000           push 0xff
004d8c82 6a0b                 push 0xb
004d8c84 6a05                 push 5
004d8c86 e8154c0100           call 0x4ed8a0
004d8c8b 83c410               add esp, 0x10
004d8c8e 85c0                 test eax, eax
004d8c90 741e                 je 0x4d8cb0
004d8c92 53                   push ebx
004d8c93 83ef64               sub edi, 0x64
004d8c96 50                   push eax
004d8c97 e8e4580100           call 0x4ee580
004d8c9c 83c408               add esp, 8
004d8c9f 6a00                 push 0
004d8ca1 6a0b                 push 0xb
004d8ca3 56                   push esi
004d8ca4 e8a713fbff           call 0x48a050
004d8ca9 83c40c               add esp, 0xc
004d8cac 85ff                 test edi, edi
004d8cae 7fcc                 jg 0x4d8c7c
004d8cb0 85ff                 test edi, edi
004d8cb2 7d02                 jge 0x4d8cb6
004d8cb4 33ff                 xor edi, edi
004d8cb6 66897e78             mov word ptr [esi + 0x78], di
004d8cba 32c0                 xor al, al
004d8cbc 5d                   pop ebp
004d8cbd 5f                   pop edi
004d8cbe 5e                   pop esi
004d8cbf 5b                   pop ebx
004d8cc0 83c434               add esp, 0x34
004d8cc3 c3                   ret 
004d8cc4 f6462e01             test byte ptr [esi + 0x2e], 1
004d8cc8 0f8564fcffff         jne 0x4d8932
004d8cce 8d7e3d               lea edi, [esi + 0x3d]
004d8cd1 6a38                 push 0x38
004d8cd3 8d464f               lea eax, [esi + 0x4f]
004d8cd6 50                   push eax
004d8cd7 6a38                 push 0x38
004d8cd9 57                   push edi
004d8cda e8c1a0f5ff           call 0x432da0
004d8cdf 83c410               add esp, 0x10
004d8ce2 84c0                 test al, al
004d8ce4 0f8448fcffff         je 0x4d8932
004d8cea 66c786890000000000   mov word ptr [esi + 0x89], 0
004d8cf3 8b07                 mov eax, dword ptr [edi]
004d8cf5 89442418             mov dword ptr [esp + 0x18], eax
004d8cf9 8d442418             lea eax, [esp + 0x18]
004d8cfd 50                   push eax
004d8cfe e84dc3f2ff           call 0x405050
004d8d03 83c404               add esp, 4
004d8d06 f6400102             test byte ptr [eax + 1], 2
004d8d0a 7421                 je 0x4d8d2d
004d8d0c 8d4c2418             lea ecx, [esp + 0x18]
004d8d10 51                   push ecx
004d8d11 33c9                 xor ecx, ecx
004d8d13 668b4808             mov cx, word ptr [eax + 8]
004d8d17 81e1ff030000         and ecx, 0x3ff
004d8d1d 8b048d90038900       mov eax, dword ptr [ecx*4 + 0x890390]
004d8d24 50                   push eax
004d8d25 e886b7f2ff           call 0x4044b0
004d8d2a 83c408               add esp, 8
004d8d2d 8d442418             lea eax, [esp + 0x18]
004d8d31 50                   push eax
004d8d32 56                   push esi
004d8d33 e838a1f2ff           call 0x402e70
004d8d38 83c408               add esp, 8
004d8d3b f6057cd1890002       test byte ptr [0x89d17c], 2
004d8d42 742a                 je 0x4d8d6e
004d8d44 8a462b               mov al, byte ptr [esi + 0x2b]
004d8d47 3c07                 cmp al, 7
004d8d49 750a                 jne 0x4d8d55
004d8d4b b027                 mov al, 0x27
004d8d4d 5d                   pop ebp
004d8d4e 5f                   pop edi
004d8d4f 5e                   pop esi
004d8d50 5b                   pop ebx
004d8d51 83c434               add esp, 0x34
004d8d54 c3                   ret 
004d8d55 33c9                 xor ecx, ecx
004d8d57 5d                   pop ebp
004d8d58 8ac8                 mov cl, al
004d8d5a 5f                   pop edi
004d8d5b 8d0489               lea eax, [ecx + ecx*4]
004d8d5e 5e                   pop esi
004d8d5f 5b                   pop ebx
004d8d60 8d1480               lea edx, [eax + eax*4]
004d8d63 83c434               add esp, 0x34
004d8d66 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8d6d c3                   ret 
004d8d6e 33c0                 xor eax, eax
004d8d70 5d                   pop ebp
004d8d71 8a462b               mov al, byte ptr [esi + 0x2b]
004d8d74 5f                   pop edi
004d8d75 8d0c80               lea ecx, [eax + eax*4]
004d8d78 5e                   pop esi
004d8d79 5b                   pop ebx
004d8d7a 8d1489               lea edx, [ecx + ecx*4]
004d8d7d 83c434               add esp, 0x34
004d8d80 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8d87 c3                   ret 
004d8d88 f6057cd1890002       test byte ptr [0x89d17c], 2
004d8d8f 742a                 je 0x4d8dbb
004d8d91 8a462b               mov al, byte ptr [esi + 0x2b]
004d8d94 3c07                 cmp al, 7
004d8d96 750a                 jne 0x4d8da2
004d8d98 b027                 mov al, 0x27
004d8d9a 5d                   pop ebp
004d8d9b 5f                   pop edi
004d8d9c 5e                   pop esi
004d8d9d 5b                   pop ebx
004d8d9e 83c434               add esp, 0x34
004d8da1 c3                   ret 
004d8da2 33c9                 xor ecx, ecx
004d8da4 5d                   pop ebp
004d8da5 8ac8                 mov cl, al
004d8da7 5f                   pop edi
004d8da8 8d0489               lea eax, [ecx + ecx*4]
004d8dab 5e                   pop esi
004d8dac 5b                   pop ebx
004d8dad 8d1480               lea edx, [eax + eax*4]
004d8db0 83c434               add esp, 0x34
004d8db3 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8dba c3                   ret 
004d8dbb 33c0                 xor eax, eax
004d8dbd 5d                   pop ebp
004d8dbe 8a462b               mov al, byte ptr [esi + 0x2b]
004d8dc1 5f                   pop edi
004d8dc2 8d0c80               lea ecx, [eax + eax*4]
004d8dc5 5e                   pop esi
004d8dc6 5b                   pop ebx
004d8dc7 8d1489               lea edx, [ecx + ecx*4]
004d8dca 83c434               add esp, 0x34
004d8dcd 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8dd4 c3                   ret 
004d8dd5 f6057cd1890002       test byte ptr [0x89d17c], 2
004d8ddc 742a                 je 0x4d8e08
004d8dde 8a462b               mov al, byte ptr [esi + 0x2b]
004d8de1 3c07                 cmp al, 7
004d8de3 750a                 jne 0x4d8def
004d8de5 b027                 mov al, 0x27
004d8de7 5d                   pop ebp
004d8de8 5f                   pop edi
004d8de9 5e                   pop esi
004d8dea 5b                   pop ebx
004d8deb 83c434               add esp, 0x34
004d8dee c3                   ret 
004d8def 33c9                 xor ecx, ecx
004d8df1 5d                   pop ebp
004d8df2 8ac8                 mov cl, al
004d8df4 5f                   pop edi
004d8df5 8d0489               lea eax, [ecx + ecx*4]
004d8df8 5e                   pop esi
004d8df9 5b                   pop ebx
004d8dfa 8d1480               lea edx, [eax + eax*4]
004d8dfd 83c434               add esp, 0x34
004d8e00 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8e07 c3                   ret 
004d8e08 33c0                 xor eax, eax
004d8e0a 5d                   pop ebp
004d8e0b 8a462b               mov al, byte ptr [esi + 0x2b]
004d8e0e 5f                   pop edi
004d8e0f 8d0c80               lea ecx, [eax + eax*4]
004d8e12 5e                   pop esi
004d8e13 5b                   pop ebx
004d8e14 8d1489               lea edx, [ecx + ecx*4]
004d8e17 83c434               add esp, 0x34
004d8e1a 8a045564705a00       mov al, byte ptr [edx*2 + 0x5a7064]
004d8e21 c3                   ret 
004d8e22 8bff                 mov edi, edi
004d8e24 7e88                 jle 0x4d8dae
004d8e26 4d                   dec ebp
004d8e27 00a0894d00c8         add byte ptr [eax - 0x37ffb277], ah
004d8e2d 8a4d00               mov cl, byte ptr [ebp]
004d8e30 58                   pop eax
004d8e31 8b4d00               mov ecx, dword ptr [ebp]
004d8e34 fe8b4d003289         dec byte ptr [ebx - 0x76cdffb3]
004d8e3a 4d                   dec ebp
004d8e3b 00c4                 add ah, al
004d8e3d 8c4d00               mov word ptr [ebp], cs
