00438dc0 a810                 test al, 0x10
00438dc2 0f8410010000         je 0x438ed8
00438dc8 6625efff             and ax, 0xffef
00438dcc 66894676             mov word ptr [esi + 0x76], ax
00438dd0 8b4610               mov eax, dword ptr [esi + 0x10]
00438dd3 25f8fffeff           and eax, 0xfffefff8
00438dd8 8d4c240c             lea ecx, [esp + 0xc]
00438ddc 51                   push ecx
00438ddd 894610               mov dword ptr [esi + 0x10], eax
00438de0 83c801               or eax, 1
00438de3 894610               mov dword ptr [esi + 0x10], eax
00438de6 33c0                 xor eax, eax
00438de8 668b8689000000       mov ax, word ptr [esi + 0x89]
00438def 8b3c8590038900       mov edi, dword ptr [eax*4 + 0x890390]
00438df6 57                   push edi
00438df7 e834130800           call 0x4ba130
00438dfc 8d442418             lea eax, [esp + 0x18]
00438e00 83c408               add esp, 8
00438e03 50                   push eax
00438e04 57                   push edi
00438e05 e8b6110800           call 0x4b9fc0
00438e0a 0fbf442418           movsx eax, word ptr [esp + 0x18]
00438e0f 0fbf4e3d             movsx ecx, word ptr [esi + 0x3d]
00438e13 83c408               add esp, 8
00438e16 2bc1                 sub eax, ecx
00438e18 99                   cdq 
00438e19 33c2                 xor eax, edx
00438e1b 2bc2                 sub eax, edx
00438e1d 3d38010000           cmp eax, 0x138
00438e22 7d24                 jge 0x438e48
00438e24 0fbf442412           movsx eax, word ptr [esp + 0x12]
00438e29 0fbf4e3f             movsx ecx, word ptr [esi + 0x3f]
00438e2d 2bc1                 sub eax, ecx
00438e2f 99                   cdq 
00438e30 33c2                 xor eax, edx
00438e32 2bc2                 sub eax, edx
00438e34 3d38010000           cmp eax, 0x138
00438e39 7d0d                 jge 0x438e48
00438e3b 8d44240c             lea eax, [esp + 0xc]
00438e3f 50                   push eax
00438e40 56                   push esi
00438e41 e88a0f0b00           call 0x4e9dd0
00438e46 eb0b                 jmp 0x438e53
00438e48 8d44240c             lea eax, [esp + 0xc]
00438e4c 50                   push eax
00438e4d 56                   push esi
00438e4e e82d0f0b00           call 0x4e9d80
00438e53 668b442414           mov ax, word ptr [esp + 0x14]
00438e58 83c408               add esp, 8
00438e5b 662b463d             sub ax, word ptr [esi + 0x3d]
00438e5f 0fb7f8               movzx edi, ax
00438e62 668b44240e           mov ax, word ptr [esp + 0xe]
00438e67 8bcf                 mov ecx, edi
00438e69 662b463f             sub ax, word ptr [esi + 0x3f]
00438e6d 85ff                 test edi, edi
00438e6f 0fb7c0               movzx eax, ax
00438e72 7d04                 jge 0x438e78
00438e74 8bcf                 mov ecx, edi
00438e76 f7d9                 neg ecx
00438e78 8bd0                 mov edx, eax
00438e7a 85c0                 test eax, eax
00438e7c 7d04                 jge 0x438e82
00438e7e 8bd0                 mov edx, eax
00438e80 f7da                 neg edx
00438e82 81f900800000         cmp ecx, 0x8000
00438e88 7c06                 jl 0x438e90
00438e8a 8db90000ffff         lea edi, [ecx - 0x10000]
00438e90 81fa00800000         cmp edx, 0x8000
00438e96 7c06                 jl 0x438e9e
00438e98 8d820000ffff         lea eax, [edx - 0x10000]
00438e9e f7d8                 neg eax
00438ea0 50                   push eax
00438ea1 57                   push edi
00438ea2 e8cdd11400           call 0x586074
00438ea7 6625ff07             and ax, 0x7ff
00438eab 83c408               add esp, 8
00438eae 8b4e0c               mov ecx, dword ptr [esi + 0xc]
00438eb1 f6c180               test cl, 0x80
00438eb4 7404                 je 0x438eba
00438eb6 66894657             mov word ptr [esi + 0x57], ax
00438eba f6c580               test ch, 0x80
00438ebd 6689465d             mov word ptr [esi + 0x5d], ax
00438ec1 7408                 je 0x438ecb
00438ec3 66050004             add ax, 0x400
00438ec7 6625ff07             and ax, 0x7ff
00438ecb 66894626             mov word ptr [esi + 0x26], ax
00438ecf 56                   push esi
00438ed0 e86bc00900           call 0x4d4f40
00438ed5 83c404               add esp, 4
00438ed8 f6462e01             test byte ptr [esi + 0x2e], 1
00438edc 7532                 jne 0x438f10
00438ede 0fbf464f             movsx eax, word ptr [esi + 0x4f]
00438ee2 0fbf4e3d             movsx ecx, word ptr [esi + 0x3d]
00438ee6 2bc1                 sub eax, ecx
00438ee8 99                   cdq 
00438ee9 33c2                 xor eax, edx
00438eeb 2bc2                 sub eax, edx
00438eed 83f870               cmp eax, 0x70
00438ef0 7d16                 jge 0x438f08
00438ef2 0fbf4651             movsx eax, word ptr [esi + 0x51]
00438ef6 0fbf4e3f             movsx ecx, word ptr [esi + 0x3f]
00438efa 2bc1                 sub eax, ecx
00438efc 99                   cdq 
00438efd 33c2                 xor eax, edx
00438eff 2bc2                 sub eax, edx
00438f01 83f870               cmp eax, 0x70
00438f04 b001                 mov al, 1
00438f06 7c02                 jl 0x438f0a
00438f08 32c0                 xor al, al
00438f0a 84c0                 test al, al
00438f0c 7402                 je 0x438f10
00438f0e b301                 mov bl, 1
00438f10 8ac3                 mov al, bl
00438f12 5f                   pop edi
00438f13 5e                   pop esi
00438f14 5b                   pop ebx
00438f15 83c408               add esp, 8
00438f18 c3                   ret 
00438f19 cc                   int3 
00438f1a cc                   int3 
00438f1b cc                   int3 
00438f1c cc                   int3 
00438f1d cc                   int3 
00438f1e cc                   int3 
00438f1f cc                   int3 
00438f20 83ec04               sub esp, 4
00438f23 53                   push ebx
00438f24 56                   push esi
00438f25 57                   push edi
00438f26 32db                 xor bl, bl
00438f28 8b742414             mov esi, dword ptr [esp + 0x14]
00438f2c 668b4676             mov ax, word ptr [esi + 0x76]
00438f30 a810                 test al, 0x10
00438f32 0f84b6000000         je 0x438fee
00438f38 6625efff             and ax, 0xffef
00438f3c 8d4c240c             lea ecx, [esp + 0xc]
00438f40 66894676             mov word ptr [esi + 0x76], ax
00438f44 51                   push ecx
00438f45 33c0                 xor eax, eax
00438f47 668b8689000000       mov ax, word ptr [esi + 0x89]
00438f4e 8b148590038900       mov edx, dword ptr [eax*4 + 0x890390]
00438f55 52                   push edx
00438f56 e855b5fcff           call 0x4044b0
00438f5b 8d4c2414             lea ecx, [esp + 0x14]
00438f5f 83c408               add esp, 8
00438f62 51                   push ecx
00438f63 56                   push esi
00438f64 e8170e0b00           call 0x4e9d80
00438f69 668b442414           mov ax, word ptr [esp + 0x14]
00438f6e 83c408               add esp, 8
00438f71 662b463d             sub ax, word ptr [esi + 0x3d]
00438f75 0fb7f8               movzx edi, ax
00438f78 668b44240e           mov ax, word ptr [esp + 0xe]
00438f7d 8bcf                 mov ecx, edi
00438f7f 662b463f             sub ax, word ptr [esi + 0x3f]
00438f83 85ff                 test edi, edi
00438f85 0fb7c0               movzx eax, ax
00438f88 7d04                 jge 0x438f8e
00438f8a 8bcf                 mov ecx, edi
00438f8c f7d9                 neg ecx
00438f8e 8bd0                 mov edx, eax
