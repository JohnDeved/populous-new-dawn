004d8300 83ec04               sub esp, 4
004d8303 a100a55a00           mov eax, dword ptr [0x5aa500]
004d8308 f60568c6890004       test byte ptr [0x89c668], 4
004d830f 56                   push esi
004d8310 57                   push edi
004d8311 7503                 jne 0x4d8316
004d8313 c1f801               sar eax, 1
004d8316 8bc8                 mov ecx, eax
004d8318 8b742410             mov esi, dword ptr [esp + 0x10]
004d831c c1f903               sar ecx, 3
004d831f 66894670             mov word ptr [esi + 0x70], ax
004d8323 85c9                 test ecx, ecx
004d8325 7447                 je 0x4d836e
004d8327 a178d18900           mov eax, dword ptr [0x89d178]
004d832c 8bd0                 mov edx, eax
004d832e 8d3cc0               lea edi, [eax + eax*8]
004d8331 8d04fa               lea eax, [edx + edi*8]
004d8334 8d0482               lea eax, [edx + eax*4]
004d8337 c1e002               shl eax, 2
004d833a 8d04c2               lea eax, [edx + eax*8]
004d833d 05df240000           add eax, 0x24df
004d8342 a378d18900           mov dword ptr [0x89d178], eax
004d8347 89442408             mov dword ptr [esp + 8], eax
004d834b c14c24080d           ror dword ptr [esp + 8], 0xd
004d8350 8b442408             mov eax, dword ptr [esp + 8]
004d8354 2bd2                 sub edx, edx
004d8356 a378d18900           mov dword ptr [0x89d178], eax
004d835b f7f1                 div ecx
004d835d 8bfa                 mov edi, edx
004d835f 8bc1                 mov eax, ecx
004d8361 99                   cdq 
004d8362 2bc2                 sub eax, edx
004d8364 c1f801               sar eax, 1
004d8367 662bf8               sub di, ax
004d836a 66017e70             add word ptr [esi + 0x70], di
004d836e 6a00                 push 0
004d8370 6a00                 push 0
004d8372 56                   push esi
004d8373 e8d8d3f6ff           call 0x445750
004d8378 83c40c               add esp, 0xc
004d837b 8b460c               mov eax, dword ptr [esi + 0xc]
004d837e 814e1080000000       or dword ptr [esi + 0x10], 0x80
004d8385 0d00002000           or eax, 0x200000
004d838a 5f                   pop edi
004d838b 89460c               mov dword ptr [esi + 0xc], eax
004d838e 0d00020000           or eax, 0x200
004d8393 89460c               mov dword ptr [esi + 0xc], eax
004d8396 25fffffffd           and eax, 0xfdffffff
004d839b 89460c               mov dword ptr [esi + 0xc], eax
004d839e 5e                   pop esi
004d839f 83c404               add esp, 4
004d83a2 c3                   ret 
004d83a3 cc                   int3 
004d83a4 cc                   int3 
004d83a5 cc                   int3 
004d83a6 cc                   int3 
004d83a7 cc                   int3 
004d83a8 cc                   int3 
004d83a9 cc                   int3 
004d83aa cc                   int3 
004d83ab cc                   int3 
004d83ac cc                   int3 
004d83ad cc                   int3 
004d83ae cc                   int3 
004d83af cc                   int3 
