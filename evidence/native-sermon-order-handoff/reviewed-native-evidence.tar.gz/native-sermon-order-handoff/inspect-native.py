import sys,hashlib,json
from pathlib import Path
root=Path(sys.argv[2]);sys.path.insert(0,str(root/'scripts'))
from decomp import native_cpu
from capstone import Cs,CS_ARCH_X86,CS_MODE_32
cpu,identity=native_cpu(Path(sys.argv[1]));out=root/'work/orchestration/native-sermon-order-handoff'
cs=Cs(CS_ARCH_X86,CS_MODE_32)
for start,end in [(0x43abf0,0x43b070),(0x4d8300,0x4d83b0),(0x4d4690,0x4d47d0),(0x438dc0,0x438f90),(0x435c10,0x435cb0),(0x4d83b0,0x4d8e40)]:
 s='\n'.join(f'{i.address:08x} {i.bytes.hex():20} {i.mnemonic} {i.op_str}' for i in cs.disasm(bytes(cpu.mem_read(start,end-start)),start))
 (out/f'{start:08x}.asm').write_text(s+'\n')
print(json.dumps(identity))
