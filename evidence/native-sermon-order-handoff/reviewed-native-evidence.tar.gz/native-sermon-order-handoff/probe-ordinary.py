"""Finite ordinary non-sermon native worship command/admission witness."""
import sys,json,struct,hashlib,traceback
from pathlib import Path
exe,root=map(Path,sys.argv[1:3]);src=root/'work/orchestration/native-sermon-order-handoff/probe-handoff.py'
exec(compile(src.read_text().split('for n,cmd in [(1,27)',1)[0],str(src),'exec'),globals())
report['cases']=[];report['inputs'][str(Path(__file__))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
case={'label':'ordinary-preacher-worship','stages':[]};report['cases'].append(case)
try:
 setup(0);packet_order(27,100)
 for visit in range(1,257):
  write(p+0x2e,'B',visit&255);write(0x89d188,'I',visit)
  before=snap();events.clear();watch.clear();call(0x4ed700,p)
  if visit<=4 or visit%16==0 or read(p+0x5f,'h')==0:
   case['stages'].append(dict(label=f'ordinary worship person visit {visit}',before=before,after=snap(),events=list(events)))
  if read(p+0x5f,'h')==0 and read(p+0x2d,'B') in [1,2,3]:
   write(trigger+0x2e,'B',4)
   s=stage('native admission after ordinary worship arrival',0x4fb270,trigger)
   if s['after']['headCounts'][0]>0:case['admittedAt']=visit;break
 else:raise Boundary('ordinary worship did not reach native admission in 256 visits')
 case['status']='passed'
except Exception as e:case.update(status='blocked',error=str(e),failure={'eip':f'{cpu.reg_read(UC_X86_REG_EIP):08x}','recent':list(recent),'snapshot':snap(),'events':list(events)},traceback=traceback.format_exc())
report['status']=case['status'];print(json.dumps(report,indent=2))
