"""Original-produced model2 conversion with finite supplied free lists and native allocator.
Uses the actual sermon producer, victim timer/RNG, allocation, replacement flags;
no forced conversion or timer. Scheduling of producer/consumer visits is supplied.
"""
import sys,json,struct,hashlib,traceback
from pathlib import Path
exe,root=map(Path,sys.argv[1:3]);src=root/'work/orchestration/native-sermon-order-handoff/probe-handoff.py'
code=src.read_text().split('for n,cmd in [(1,27)',1)[0]
exec(compile(code,str(src),'exec'),globals())
report['cases']=[];report['scope']='Native sermon/victim/real allocation composition with supplied free lists, flat world, explicit per-person visits; no full world scheduler/campaign.'
report['inputs'][str(Path(__file__))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
observed.update({0x4ed8a0:'allocate-object',0x4edcf0:'delete-object',0x4d47a0:'clear-owner',0x4d8300:'initialize-listener'})
abort.pop(0x4ed8a0)
cpu.mem_map(0x2100000,0x100000)
case={'label':'naturally-expired-conversion','stages':[]};report['cases'].append(case)
try:
 setup(1)
 for base,first,globalptr in [(0x2100000,200,0x890320),(0x2110000,640,0x89031c)]:
  for i in range(16):
   q=base+256*i;write(q,'II',q-256 if i else 0,q+256 if i<15 else 0);write(q+0x24,'H',first+i);write(0x890390+(first+i)*4,'I',q)
  write(globalptr,'I',base)
 write(p+4,'I',listener1);write(listener1,'I',p)
 write(0x892443,'I',0x2120000);write(0x89243a,'B',0)
 packet_order(17,0x1010);stage('prepare sermon',0x4d42a0,p)
 for turn in range(1,1801):
  write(p+0x2e,'B',turn&255);write(listener1+0x2e,'B',turn&255);write(0x89d188,'I',turn)
  before=snap();events.clear();watch.clear();call(0x432590,p)
  if read(listener1+0x2c,'B')==23:call(0x4d83b0,listener1)
  after=snap()
  replacement=next((q for b in (0x2100000,0x2110000) for i in range(16) for q in [b+i*256] if read(q+0x2a,'B')==1 and read(q+0x10,'I')&0x40000),None)
  allocated=replacement is not None
  if turn<6 or turn%32==0 or allocated or any(e['name']=='allocate-object' for e in events):
   case['stages'].append(dict(label=f'producer and listener visit {turn}',before=before,after=after,events=list(events)))
  if allocated:
   actors.append(replacement);case['convertedAt']=turn;case['replacement']=person(replacement);case['replacementPointer']=f'{replacement:08x}';break
 else:raise Boundary('no conversion within 1800 native timer/RNG visits')
 stage('native tribe roster rebuild after allocation',0x4ecac0)
 case['nativeRosterHead']=f'{read(tribe+0x881,"I"):08x}'
 case['flagsBeforeWorship']={k:person(replacement)[k] for k in ['flags2','flags3','flags4']}
 write(p+0x7a,'B',0);write(replacement+0x7a,'B',128)
 packet_order(27,100)
 case['afterWorshipPacket']=person(replacement)
 assert read(replacement+0xa7,'B')==27 and read(replacement+0x72,'H')==100
 for visit in range(1,257):
  write(replacement+0x2e,'B',visit&255);write(0x89d188,'I',1328+visit)
  before=snap();events.clear();watch.clear();call(0x4ed700,replacement)
  if visit<=4 or visit%16==0 or read(replacement+0x5f,'h')==0:
   case['stages'].append(dict(label=f'converted worship person visit {visit}',before=before,after=snap(),events=list(events)))
  if read(replacement+0x5f,'h')==0 and read(replacement+0x2d,'B') in [1,2,3]:
   write(trigger+0x2e,'B',4)
   admission=stage('native admission after converted worship arrival',0x4fb270,trigger)
   if admission['after']['headCounts'][0]>0:
    case['admittedAt']=visit;case['admittedPerson']=person(replacement);break
 else:raise Boundary('converted worship did not reach native admission in 256 visits')
 case['status']='passed'
except Exception as e:
 case.update(status='blocked',error=str(e),failure={'eip':f'{cpu.reg_read(UC_X86_REG_EIP):08x}','recent':list(recent),'snapshot':snap(),'events':list(events)},traceback=traceback.format_exc())
report['status']=case['status'];print(json.dumps(report,indent=2))
