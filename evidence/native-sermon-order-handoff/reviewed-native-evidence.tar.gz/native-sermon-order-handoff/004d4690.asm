004d4690 56                   push esi
004d4691 33c0                 xor eax, eax
004d4693 8b742408             mov esi, dword ptr [esp + 8]
004d4697 8a462b               mov al, byte ptr [esi + 0x2b]
004d469a 8d0c80               lea ecx, [eax + eax*4]
004d469d 8d1489               lea edx, [ecx + ecx*4]
004d46a0 8a04558f705a00       mov al, byte ptr [edx*2 + 0x5a708f]
004d46a7 84462e               test byte ptr [esi + 0x2e], al
004d46aa 7507                 jne 0x4d46b3
004d46ac 814e1400080000       or dword ptr [esi + 0x14], 0x800
004d46b3 8b4614               mov eax, dword ptr [esi + 0x14]
004d46b6 f6c408               test ah, 8
004d46b9 0f8405010000         je 0x4d47c4
004d46bf 25fff7ffff           and eax, 0xfffff7ff
004d46c4 56                   push esi
004d46c5 894614               mov dword ptr [esi + 0x14], eax
004d46c8 e893b80400           call 0x51ff60
004d46cd 83c404               add esp, 4
004d46d0 85c0                 test eax, eax
004d46d2 0f84ec000000         je 0x4d47c4
004d46d8 f605a75d890002       test byte ptr [0x895da7], 2
004d46df 0f85df000000         jne 0x4d47c4
004d46e5 56                   push esi
004d46e6 e8f5fdffff           call 0x4d44e0
004d46eb 83c404               add esp, 4
004d46ee 84c0                 test al, al
004d46f0 0f84ce000000         je 0x4d47c4
004d46f6 f6461108             test byte ptr [esi + 0x11], 8
004d46fa 0f85bb000000         jne 0x4d47bb
004d4700 33c0                 xor eax, eax
004d4702 8a462b               mov al, byte ptr [esi + 0x2b]
004d4705 83f804               cmp eax, 4
004d4708 7419                 je 0x4d4723
004d470a 83f806               cmp eax, 6
004d470d 7477                 je 0x4d4786
004d470f 83f807               cmp eax, 7
004d4712 0f8486000000         je 0x4d479e
004d4718 56                   push esi
004d4719 e8c29e0400           call 0x51e5e0
004d471e 83c404               add esp, 4
004d4721 5e                   pop esi
004d4722 c3                   ret 
004d4723 8a462c               mov al, byte ptr [esi + 0x2c]
004d4726 3c0a                 cmp al, 0xa
004d4728 7404                 je 0x4d472e
004d472a 3c21                 cmp al, 0x21
004d472c 754d                 jne 0x4d477b
004d472e 33c9                 xor ecx, ecx
004d4730 33c0                 xor eax, eax
004d4732 668b869b000000       mov ax, word ptr [esi + 0x9b]
004d4739 3bc1                 cmp eax, ecx
004d473b 7516                 jne 0x4d4753
004d473d 33d2                 xor edx, edx
004d473f 33c0                 xor eax, eax
004d4741 8a96a6000000         mov dl, byte ptr [esi + 0xa6]
004d4747 668b84568b000000     mov ax, word ptr [esi + edx*2 + 0x8b]
004d474f 85c0                 test eax, eax
004d4751 740a                 je 0x4d475d
004d4753 8d0480               lea eax, [eax + eax*4]
004d4756 8d0c4530889300       lea ecx, [eax*2 + 0x938830]
004d475d 85c9                 test ecx, ecx
004d475f 741a                 je 0x4d477b
004d4761 f6410101             test byte ptr [ecx + 1], 1
004d4765 7514                 jne 0x4d477b
004d4767 8a01                 mov al, byte ptr [ecx]
004d4769 3c11                 cmp al, 0x11
004d476b 7408                 je 0x4d4775
004d476d 3c1f                 cmp al, 0x1f
004d476f 7404                 je 0x4d4775
004d4771 3c20                 cmp al, 0x20
004d4773 7506                 jne 0x4d477b
004d4775 f6467640             test byte ptr [esi + 0x76], 0x40
004d4779 7549                 jne 0x4d47c4
004d477b 56                   push esi
004d477c e82fa00400           call 0x51e7b0
004d4781 83c404               add esp, 4
004d4784 5e                   pop esi
004d4785 c3                   ret 
004d4786 56                   push esi
004d4787 e844b50400           call 0x51fcd0
004d478c 83c404               add esp, 4
004d478f 84c0                 test al, al
004d4791 7431                 je 0x4d47c4
004d4793 56                   push esi
004d4794 e807a20400           call 0x51e9a0
004d4799 83c404               add esp, 4
004d479c 5e                   pop esi
004d479d c3                   ret 
004d479e 8a86a7000000         mov al, byte ptr [esi + 0xa7]
004d47a4 3c1c                 cmp al, 0x1c
004d47a6 7408                 je 0x4d47b0
004d47a8 3c13                 cmp al, 0x13
004d47aa 7404                 je 0x4d47b0
004d47ac 3c04                 cmp al, 4
004d47ae 7514                 jne 0x4d47c4
004d47b0 56                   push esi
004d47b1 e8fa9f0400           call 0x51e7b0
004d47b6 83c404               add esp, 4
004d47b9 5e                   pop esi
004d47ba c3                   ret 
004d47bb 56                   push esi
004d47bc e82f9f0400           call 0x51e6f0
004d47c1 83c404               add esp, 4
004d47c4 5e                   pop esi
004d47c5 c3                   ret 
004d47c6 cc                   int3 
004d47c7 cc                   int3 
004d47c8 cc                   int3 
004d47c9 cc                   int3 
004d47ca cc                   int3 
004d47cb cc                   int3 
004d47cc cc                   int3 
004d47cd cc                   int3 
004d47ce cc                   int3 
004d47cf cc                   int3 
