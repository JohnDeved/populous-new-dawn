"""Source-bound finite read-only native receipt; all outputs remain in owned work scope."""
import sys,json,hashlib,subprocess,time,datetime
from pathlib import Path
root=Path(sys.argv[1]).resolve();exe=Path(sys.argv[2]).resolve();python=sys.argv[3];out=root/'work/orchestration/native-sermon-order-handoff'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
inputs=[root/'scripts/decomp.py',root/'app/original-rules.json',root/'app/original-constants.json',root/'decomp/tools.json',root/'decomp/exports.json',root/'work/orchestration/native-guard-lifecycle-20261005/probe-guard-lifecycle.py',out/'probe-handoff.py',out/'probe-converted.py',out/'probe-ordinary.py',exe,exe.parent/'levels/constant.dat',exe.parent/'data/mwsearch.dat',exe.parent/'data/vstart-0.ani',exe.parent/'data/vfra-0.ani']
receipt={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headBefore':git('rev-parse','HEAD'),'statusBefore':git('status','--short'),'inputsBefore':{str(p):sha(p) for p in inputs},'runs':[]}
for name,script in [('handoff','probe-handoff.py'),('converted','probe-converted.py'),('ordinary','probe-ordinary.py')]:
 command=['timeout','60s','taskset','-c','4',python,str(out/script),str(exe),str(root)];start=time.monotonic()
 with (out/f'final-{name}.json').open('w') as stdout,(out/f'final-{name}.stderr').open('w') as stderr:
  run=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,env={**__import__('os').environ,'PYTHONDONTWRITEBYTECODE':'1'})
 receipt['runs'].append({'name':name,'command':command,'exitCode':run.returncode,'durationSeconds':time.monotonic()-start,'stdout':str(out/f'final-{name}.json'),'stdoutSha256':sha(out/f'final-{name}.json'),'stderrSha256':sha(out/f'final-{name}.stderr'),'reportedStatus':json.loads((out/f'final-{name}.json').read_text()).get('status')})
 print(name,run.returncode,receipt['runs'][-1]['reportedStatus'],flush=True)
receipt.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--short'),inputsAfter={str(p):sha(p) for p in inputs})
receipt['sourceStable']=receipt['headBefore']==receipt['headAfter'] and receipt['statusBefore']==receipt['statusAfter'] and receipt['inputsBefore']==receipt['inputsAfter']
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
