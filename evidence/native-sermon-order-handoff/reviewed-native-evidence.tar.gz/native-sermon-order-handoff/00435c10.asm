00435c10 8b442404             mov eax, dword ptr [esp + 4]
00435c14 8b8081080000         mov eax, dword ptr [eax + 0x881]
00435c1a 85c0                 test eax, eax
00435c1c 741a                 je 0x435c38
00435c1e 8a487a               mov cl, byte ptr [eax + 0x7a]
00435c21 f6c180               test cl, 0x80
00435c24 7405                 je 0x435c2b
00435c26 80c901               or cl, 1
00435c29 eb03                 jmp 0x435c2e
00435c2b 80e1fe               and cl, 0xfe
00435c2e 88487a               mov byte ptr [eax + 0x7a], cl
00435c31 8b4008               mov eax, dword ptr [eax + 8]
00435c34 85c0                 test eax, eax
00435c36 75e6                 jne 0x435c1e
00435c38 c3                   ret 
00435c39 cc                   int3 
00435c3a cc                   int3 
00435c3b cc                   int3 
00435c3c cc                   int3 
00435c3d cc                   int3 
00435c3e cc                   int3 
00435c3f cc                   int3 
00435c40 8b442404             mov eax, dword ptr [esp + 4]
00435c44 53                   push ebx
00435c45 56                   push esi
00435c46 57                   push edi
00435c47 8bb881080000         mov edi, dword ptr [eax + 0x881]
00435c4d 85ff                 test edi, edi
00435c4f 7453                 je 0x435ca4
00435c51 33db                 xor ebx, ebx
00435c53 f6477a80             test byte ptr [edi + 0x7a], 0x80
00435c57 7444                 je 0x435c9d
00435c59 33f6                 xor esi, esi
00435c5b 889fa6000000         mov byte ptr [edi + 0xa6], bl
00435c61 66399c778b000000     cmp word ptr [edi + esi*2 + 0x8b], bx
00435c69 740a                 je 0x435c75
00435c6b 56                   push esi
00435c6c 57                   push edi
00435c6d e85e080000           call 0x4364d0
00435c72 83c408               add esp, 8
00435c75 46                   inc esi
00435c76 83fe08               cmp esi, 8
00435c79 7ce6                 jl 0x435c61
00435c7b 66399f9b000000       cmp word ptr [edi + 0x9b], bx
00435c82 740b                 je 0x435c8f
00435c84 6aff                 push -1
00435c86 57                   push edi
00435c87 e844080000           call 0x4364d0
00435c8c 83c408               add esp, 8
00435c8f 81670cfffffff7       and dword ptr [edi + 0xc], 0xf7ffffff
00435c96 816710fffdffff       and dword ptr [edi + 0x10], 0xfffffdff
00435c9d 8b7f08               mov edi, dword ptr [edi + 8]
00435ca0 85ff                 test edi, edi
00435ca2 75af                 jne 0x435c53
00435ca4 5f                   pop edi
00435ca5 5e                   pop esi
00435ca6 5b                   pop ebx
00435ca7 c3                   ret 
00435ca8 cc                   int3 
00435ca9 cc                   int3 
00435caa cc                   int3 
00435cab cc                   int3 
00435cac cc                   int3 
00435cad cc                   int3 
00435cae cc                   int3 
00435caf cc                   int3 
