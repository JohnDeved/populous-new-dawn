0051e150 83ec08               sub esp, 8
0051e153 c644240300           mov byte ptr [esp + 3], 0
0051e158 53                   push ebx
0051e159 56                   push esi
0051e15a 57                   push edi
0051e15b 55                   push ebp
0051e15c 8b6c2420             mov ebp, dword ptr [esp + 0x20]
0051e160 6683bd9d00000000     cmp word ptr [ebp + 0x9d], 0
0051e168 0f8577010000         jne 0x51e2e5
0051e16e 8d453d               lea eax, [ebp + 0x3d]
0051e171 50                   push eax
0051e172 68ff000000           push 0xff
0051e177 6a09                 push 9
0051e179 6a0a                 push 0xa
0051e17b e820f7fcff           call 0x4ed8a0
0051e180 83c410               add esp, 0x10
0051e183 8bf0                 mov esi, eax
0051e185 85f6                 test esi, esi
0051e187 0f8458010000         je 0x51e2e5
0051e18d c644241301           mov byte ptr [esp + 0x13], 1
