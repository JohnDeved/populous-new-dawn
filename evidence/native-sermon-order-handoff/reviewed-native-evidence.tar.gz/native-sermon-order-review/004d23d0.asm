004d23d0 83ec10               sub esp, 0x10
004d23d3 53                   push ebx
004d23d4 56                   push esi
004d23d5 8b74241c             mov esi, dword ptr [esp + 0x1c]
004d23d9 57                   push edi
004d23da 0fbe462f             movsx eax, byte ptr [esi + 0x2f]
004d23de 814e1000010000       or dword ptr [esi + 0x10], 0x100
004d23e5 8bc8                 mov ecx, eax
004d23e7 8d1480               lea edx, [eax + eax*4]
004d23ea 8d0451               lea eax, [ecx + edx*2]
004d23ed 814e1400010400       or dword ptr [esi + 0x14], 0x40100
004d23f4 8d1cc0               lea ebx, [eax + eax*8]
004d23f7 33c0                 xor eax, eax
004d23f9 8a462b               mov al, byte ptr [esi + 0x2b]
004d23fc 8d14d9               lea edx, [ecx + ebx*8]
004d23ff 48                   dec eax
004d2400 8dbc91c8d18900       lea edi, [ecx + edx*4 + 0x89d1c8]
004d2407 83f807               cmp eax, 7
004d240a 0f87c1020000         ja 0x4d26d1
004d2410 ff248518274d00       jmp dword ptr [eax*4 + 0x4d2718]
004d2417 c6462fff             mov byte ptr [esi + 0x2f], 0xff
004d241b 56                   push esi
004d241c e8ff340000           call 0x4d5920
004d2421 83c404               add esp, 4
004d2424 33c0                 xor eax, eax
004d2426 8a462b               mov al, byte ptr [esi + 0x2b]
004d2429 8d0c80               lea ecx, [eax + eax*4]
004d242c 8d1489               lea edx, [ecx + ecx*4]
004d242f 33c9                 xor ecx, ecx
004d2431 8a045567705a00       mov al, byte ptr [edx*2 + 0x5a7067]
004d2438 c0e801               shr al, 1
004d243b 8ac8                 mov cl, al
004d243d a178d18900           mov eax, dword ptr [0x89d178]
004d2442 8bd0                 mov edx, eax
004d2444 8d1cc0               lea ebx, [eax + eax*8]
004d2447 8d04da               lea eax, [edx + ebx*8]
004d244a 8d0482               lea eax, [edx + eax*4]
004d244d c1e002               shl eax, 2
004d2450 8d04c2               lea eax, [edx + eax*8]
004d2453 05df240000           add eax, 0x24df
004d2458 a378d18900           mov dword ptr [0x89d178], eax
004d245d 89442418             mov dword ptr [esp + 0x18], eax
004d2461 c14c24180d           ror dword ptr [esp + 0x18], 0xd
004d2466 8b442418             mov eax, dword ptr [esp + 0x18]
004d246a 2bd2                 sub edx, edx
004d246c a378d18900           mov dword ptr [0x89d178], eax
004d2471 f7f1                 div ecx
004d2473 02ca                 add cl, dl
004d2475 33c0                 xor eax, eax
004d2477 8a462b               mov al, byte ptr [esi + 0x2b]
004d247a 884e7b               mov byte ptr [esi + 0x7b], cl
004d247d 8d0c80               lea ecx, [eax + eax*4]
004d2480 8d1489               lea edx, [ecx + ecx*4]
004d2483 33c9                 xor ecx, ecx
004d2485 8a045568705a00       mov al, byte ptr [edx*2 + 0x5a7068]
004d248c 8b1578d18900         mov edx, dword ptr [0x89d178]
004d2492 c0e801               shr al, 1
004d2495 8d1cd2               lea ebx, [edx + edx*8]
004d2498 8ac8                 mov cl, al
004d249a 8bc2                 mov eax, edx
004d249c 8d14da               lea edx, [edx + ebx*8]
004d249f 8d1490               lea edx, [eax + edx*4]
004d24a2 c1e202               shl edx, 2
004d24a5 8d14d0               lea edx, [eax + edx*8]
004d24a8 81c2df240000         add edx, 0x24df
004d24ae 891578d18900         mov dword ptr [0x89d178], edx
004d24b4 89542414             mov dword ptr [esp + 0x14], edx
004d24b8 c14c24140d           ror dword ptr [esp + 0x14], 0xd
004d24bd 8b442414             mov eax, dword ptr [esp + 0x14]
004d24c1 2bd2                 sub edx, edx
004d24c3 a378d18900           mov dword ptr [0x89d178], eax
004d24c8 f7f1                 div ecx
004d24ca 66c786870000000000   mov word ptr [esi + 0x87], 0
004d24d3 816610ffff7fff       and dword ptr [esi + 0x10], 0xff7fffff
004d24da 02ca                 add cl, dl
004d24dc 884e7c               mov byte ptr [esi + 0x7c], cl
004d24df e9ed010000           jmp 0x4d26d1
004d24e4 56                   push esi
004d24e5 e836340000           call 0x4d5920
004d24ea 83c404               add esp, 4
004d24ed f60568c6890004       test byte ptr [0x89c668], 4
004d24f4 0f84d7010000         je 0x4d26d1
004d24fa 807e2f00             cmp byte ptr [esi + 0x2f], 0
004d24fe 0f85cd010000         jne 0x4d26d1
004d2504 33c0                 xor eax, eax
004d2506 8a462b               mov al, byte ptr [esi + 0x2b]
004d2509 8d0c80               lea ecx, [eax + eax*4]
004d250c 8d1c89               lea ebx, [ecx + ecx*4]
004d250f 8b0c5d70705a00       mov ecx, dword ptr [ebx*2 + 0x5a7070]
004d2516 8d145d00000000       lea edx, [ebx*2]
004d251d 03c9                 add ecx, ecx
004d251f f68290705a0008       test byte ptr [edx + 0x5a7090], 8
004d2526 745c                 je 0x4d2584
004d2528 a178d18900           mov eax, dword ptr [0x89d178]
004d252d 8bd0                 mov edx, eax
004d252f 8d1cc0               lea ebx, [eax + eax*8]
004d2532 8d04da               lea eax, [edx + ebx*8]
004d2535 8d0482               lea eax, [edx + eax*4]
004d2538 c1e002               shl eax, 2
004d253b 8d04c2               lea eax, [edx + eax*8]
004d253e 05df240000           add eax, 0x24df
004d2543 a378d18900           mov dword ptr [0x89d178], eax
004d2548 89442410             mov dword ptr [esp + 0x10], eax
004d254c c14c24100d           ror dword ptr [esp + 0x10], 0xd
004d2551 8b442410             mov eax, dword ptr [esp + 0x10]
004d2555 a378d18900           mov dword ptr [0x89d178], eax
004d255a 8bc1                 mov eax, ecx
004d255c 99                   cdq 
004d255d 83e203               and edx, 3
004d2560 03c2                 add eax, edx
004d2562 2bd2                 sub edx, edx
004d2564 c1f802               sar eax, 2
004d2567 8bd8                 mov ebx, eax
004d2569 8b442410             mov eax, dword ptr [esp + 0x10]
004d256d f7f3                 div ebx
004d256f 8bda                 mov ebx, edx
004d2571 8d0449               lea eax, [ecx + ecx*2]
004d2574 99                   cdq 
004d2575 83e203               and edx, 3
004d2578 03c2                 add eax, edx
004d257a c1f802               sar eax, 2
004d257d 8d0c03               lea ecx, [ebx + eax]
004d2580 66894e6c             mov word ptr [esi + 0x6c], cx
004d2584 66894e6e             mov word ptr [esi + 0x6e], cx
004d2588 e944010000           jmp 0x4d26d1
004d258d 56                   push esi
004d258e e88d330000           call 0x4d5920
004d2593 83c404               add esp, 4
004d2596 e936010000           jmp 0x4d26d1
004d259b 56                   push esi
004d259c e87f330000           call 0x4d5920
004d25a1 83c404               add esp, 4
004d25a4 e928010000           jmp 0x4d26d1
004d25a9 56                   push esi
004d25aa e871330000           call 0x4d5920
004d25af 83c404               add esp, 4
004d25b2 8a462f               mov al, byte ptr [esi + 0x2f]
004d25b5 834e1020             or dword ptr [esi + 0x10], 0x20
004d25b9 c0e006               shl al, 6
004d25bc 8886b2000000         mov byte ptr [esi + 0xb2], al
004d25c2 e90a010000           jmp 0x4d26d1
004d25c7 56                   push esi
004d25c8 e853330000           call 0x4d5920
004d25cd 83c404               add esp, 4
004d25d0 e9fc000000           jmp 0x4d26d1
004d25d5 56                   push esi
004d25d6 e845330000           call 0x4d5920
004d25db 0fbe462f             movsx eax, byte ptr [esi + 0x2f]
004d25df 8d1480               lea edx, [eax + eax*4]
004d25e2 83c404               add esp, 4
004d25e5 8bc8                 mov ecx, eax
004d25e7 8d0451               lea eax, [ecx + edx*2]
004d25ea 8d1cc0               lea ebx, [eax + eax*8]
004d25ed 8d14d9               lea edx, [ecx + ebx*8]
004d25f0 89b49165da8900       mov dword ptr [ecx + edx*4 + 0x89da65], esi
004d25f7 e9d5000000           jmp 0x4d26d1
004d25fc 56                   push esi
004d25fd e81e330000           call 0x4d5920
004d2602 83c404               add esp, 4
004d2605 6a00                 push 0
004d2607 68d8000000           push 0xd8
004d260c 56                   push esi
004d260d e83e7afbff           call 0x48a050
004d2612 83c40c               add esp, 0xc
004d2615 8b460c               mov eax, dword ptr [esi + 0xc]
004d2618 0d00000400           or eax, 0x40000
004d261d 89460c               mov dword ptr [esi + 0xc], eax
004d2620 0d00400000           or eax, 0x4000
004d2625 89460c               mov dword ptr [esi + 0xc], eax
004d2628 8b4610               mov eax, dword ptr [esi + 0x10]
004d262b 0d80000000           or eax, 0x80
004d2630 894610               mov dword ptr [esi + 0x10], eax
004d2633 25ffff7fff           and eax, 0xff7fffff
004d2638 894610               mov dword ptr [esi + 0x10], eax
004d263b a178d18900           mov eax, dword ptr [0x89d178]
004d2640 8bc8                 mov ecx, eax
004d2642 8d14c0               lea edx, [eax + eax*8]
004d2645 8d04d1               lea eax, [ecx + edx*8]
004d2648 8d0481               lea eax, [ecx + eax*4]
004d264b c1e002               shl eax, 2
004d264e 8d04c1               lea eax, [ecx + eax*8]
004d2651 05df240000           add eax, 0x24df
004d2656 a378d18900           mov dword ptr [0x89d178], eax
004d265b 8944240c             mov dword ptr [esp + 0xc], eax
004d265f c14c240c0d           ror dword ptr [esp + 0xc], 0xd
004d2664 8b44240c             mov eax, dword ptr [esp + 0xc]
004d2668 8bc8                 mov ecx, eax
004d266a a378d18900           mov dword ptr [0x89d178], eax
004d266f 81e1ff070000         and ecx, 0x7ff
004d2675 8b460c               mov eax, dword ptr [esi + 0xc]
004d2678 a880                 test al, 0x80
004d267a 7404                 je 0x4d2680
004d267c 66894e57             mov word ptr [esi + 0x57], cx
004d2680 f6c480               test ah, 0x80
004d2683 66894e5d             mov word ptr [esi + 0x5d], cx
004d2687 740a                 je 0x4d2693
004d2689 6681c10004           add cx, 0x400
004d268e 6681e1ff07           and cx, 0x7ff
004d2693 66894e26             mov word ptr [esi + 0x26], cx
004d2697 6a00                 push 0
004d2699 6a00                 push 0
004d269b 8d4633               lea eax, [esi + 0x33]
004d269e 50                   push eax
004d269f e85cc00100           call 0x4ee700
004d26a4 668b4635             mov ax, word ptr [esi + 0x35]
004d26a8 83c40c               add esp, 0xc
004d26ab 8b4e0c               mov ecx, dword ptr [esi + 0xc]
004d26ae 80cc01               or ah, 1
004d26b1 66894635             mov word ptr [esi + 0x35], ax
004d26b5 81c900000010         or ecx, 0x10000000
004d26bb 0c10                 or al, 0x10
004d26bd 894e0c               mov dword ptr [esi + 0xc], ecx
004d26c0 66894635             mov word ptr [esi + 0x35], ax
004d26c4 81c900000040         or ecx, 0x40000000
004d26ca c6462d00             mov byte ptr [esi + 0x2d], 0
004d26ce 894e0c               mov dword ptr [esi + 0xc], ecx
004d26d1 33c0                 xor eax, eax
004d26d3 8a462b               mov al, byte ptr [esi + 0x2b]
004d26d6 83f801               cmp eax, 1
004d26d9 7418                 je 0x4d26f3
004d26db 83f808               cmp eax, 8
004d26de 7413                 je 0x4d26f3
004d26e0 33c0                 xor eax, eax
004d26e2 ff871d090000         inc dword ptr [edi + 0x91d]
004d26e8 8a462b               mov al, byte ptr [esi + 0x2b]
004d26eb 66ff8447270a0000     inc word ptr [edi + eax*2 + 0xa27]
004d26f3 668b463f             mov ax, word ptr [esi + 0x3f]
004d26f7 668b4e3d             mov cx, word ptr [esi + 0x3d]
004d26fb 50                   push eax
004d26fc 51                   push ecx
004d26fd e83ec2f7ff           call 0x44e940
004d2702 66894641             mov word ptr [esi + 0x41], ax
004d2706 83c408               add esp, 8
004d2709 816610fffbffff       and dword ptr [esi + 0x10], 0xfffffbff
004d2710 5f                   pop edi
004d2711 5e                   pop esi
004d2712 5b                   pop ebx
004d2713 83c410               add esp, 0x10
004d2716 c3                   ret 
004d2717 90                   nop 
004d2718 17                   pop ss
004d2719 244d                 and al, 0x4d
004d271b 00e4                 add ah, ah
004d271d 244d                 and al, 0x4d
004d271f 008d254d009b         add byte ptr [ebp - 0x64ffb2db], cl
004d2725 254d00a925           and eax, 0x25a9004d
004d272a 4d                   dec ebp
004d272b 00c7                 add bh, al
004d272d 254d00d525           and eax, 0x25d5004d
004d2732 4d                   dec ebp
004d2733 00fc                 add ah, bh
004d2735 254d00cccc           and eax, 0xcccc004d
004d273a cc                   int3 
004d273b cc                   int3 
004d273c cc                   int3 
004d273d cc                   int3 
004d273e cc                   int3 
004d273f cc                   int3 
