"""Independent byte/export/data bindings and stronger raw witness assertions."""
import hashlib, json, re, struct, sys
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_32
out=Path(__file__).resolve().parent; root=out.parents[2]; packet=out.with_name('native-sermon-order-handoff')
sys.path.insert(0,str(root/'scripts'))
from decomp import native_cpu
exe=Path(sys.argv[1]); cpu,identity=native_cpu(exe); cs=Cs(CS_ARCH_X86,CS_MODE_32)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def insn(a): return next(cs.disasm(bytes(cpu.mem_read(a,15)),a))
def line(i): return f'{i.address:08x} {i.bytes.hex():20} {i.mnemonic} {i.op_str}'
report={'identity':identity,'checks':{},'entries':[],'callers':[],'asm':{}}
mapping=load(packet/'address-map.json'); exports=load(root/'decomp/exports.json')
for row in mapping['entries']:
    a=int(row['address'],16)
    report['entries'].append({'address':row['address'],'bytes32':bytes(cpu.mem_read(a,32)).hex(),'firstInstruction':line(insn(a))})
    if 'retainedExport' in row:
        assert sha(row['retainedExport'])==row['sha256']==exports['files'][Path(row['retainedExport']).name]
for path in packet.glob('*.asm'):
    count=0; output=[]
    for source in path.read_text().splitlines():
        if not source.strip():continue
        a=int(source[:8],16); i=insn(a); rest=source[9:]
        expected=f'{i.mnemonic} {i.op_str}'
        first=rest.split()[0]
        if re.fullmatch('[0-9a-f]+',first):
            assert bytes.fromhex(first)==i.bytes,(path,a)
            assert ' '.join(rest[len(first):].split())==' '.join(expected.split()),(path,a)
        else: assert ' '.join(rest.split())==' '.join(expected.split()),(path,a)
        output.append(line(i)); count+=1
    (out/path.name).write_text('\n'.join(output)+'\n')
    report['asm'][path.name]={'verifiedInstructions':count,'reviewDisassemblySha256':sha(out/path.name)}
for start,end in [(0x436330,0x4364d0),(0x432710,0x432a00),(0x4ed700,0x4ed820),(0x51e150,0x51e195)]:
    (out/f'byte-review-{start:08x}.asm').write_text('\n'.join(line(i) for i in cs.disasm(bytes(cpu.mem_read(start,end-start)),start))+'\n')
h=load(out/'final-handoff.json'); c=load(out/'final-converted.json')['cases'][0]; o=load(out/'final-ordinary.json')['cases'][0]
def enters(s,name):return [e for e in s['events'] if e['event']=='enter' and e['name']==name]
def returns(s,name):return [e for e in s['events'] if e['event']=='return' and e['name']==name]
def direct(ret,target):
    i=insn(ret-5)
    assert i.mnemonic=='call' and i.address+i.size==ret and int(i.op_str,16)==target,(ret,target,line(i))
    row={'return':f'{ret:08x}','target':f'{target:08x}','instruction':line(i)}
    if row not in report['callers']:report['callers'].append(row)
observed_leaves=set()
all_events=[]
for data in [h,load(out/'final-converted.json'),load(out/'final-ordinary.json')]:
    assert data['suppliedLeaves']=={'0047a550':'selection-ui','0048a050':'audio','00436330':'command-acknowledgement'}
    for case in data['cases']:
        for s in case['stages']:all_events.extend(s['events'])
        if 'failure' in case:all_events.extend(case['failure']['events'])
for e in all_events:
    if e.get('supplied'):observed_leaves.add(e['address'])
assert observed_leaves=={'0047a550','0048a050','00436330'}
for case in h['cases'][:-1]:
    n=int(case['label'][9]); cmd=int(case['label'].split('command')[1])
    assert case['acquisitionVisits']==4
    acq=next(s for s in case['stages'] if s['label']=='sermon command visit 4')
    assert enters(acq,'acquire-listeners') and len(enters(acq,'initialize-listener'))==n
    for e in enters(acq,'initialize-listener'):direct(int(e['callerReturn'],16),0x4d8300)
    for i in range(1,n+1):
        assert acq['after']['people'][i]['timer']>0
    order=next(s for s in case['stages'] if s['label']==f'manual command {cmd}')
    old_id=order['before']['people'][0]['commands'][0]
    assert order['before']['orders'][old_id]['model']==17
    assert order['after']['orders'][old_id]['references']==0
    for i in range(1,n+1):
        release=next(s for s in case['stages'] if s['label']==f'next listener full person id{i+1}')
        for name,ret,target in [('listener-update',0x4d3808,0x4d83b0),('clear-work-owner',0x4d2845,0x4a3940),('combat-tail',0x4d3b44,0x4d4690),('attach-order',0x51e6d5,0x436d00)]:
            assert any(e['callerReturn']==f'{ret:08x}' for e in enters(release,name)),(name,case['label'])
            direct(ret,target)
        assert any(e['returnLowByte']==5 for e in returns(release,'engagement-range'))
        assert any(e['returnLowByte']==2 for e in returns(release,'melee-area-search'))
        assert enters(release,'auto-order-install')
        q=release['after']['people'][i]; immediate=release['after']['orders'][q['immediate']]
        assert immediate['model']==21 and immediate['flags']==0x20
        if n==2 and i==1: assert release['before']['people'][2]==release['after']['people'][2]
    f=case['failure']; assert f['stackWords'][4]==0x200003d
    direct(f['stackWords'][0],0x4ed8a0)
    assert not any(e['name'] in ['kill-person','delete-object'] for e in f['events'])
conversion=next(s for s in c['stages'] if s['label']=='producer and listener visit 1328')
for name,target in [('allocate-object',0x4ed8a0),('construct-class',0x4ed580),('construct-person',0x4d23d0),('construct-person-body',0x4d5920),('kill-person',0x4d4b50),('delete-object',0x4edcf0)]:
    ev=enters(conversion,name); assert ev,name
    for e in ev:direct(int(e['callerReturn'],16),target)
rebuild=next(s for s in c['stages'] if s['label']=='native tribe roster rebuild after allocation')
assert rebuild['entry']=='004ecac0' and enters(rebuild,'rebuild-tribe-rosters')
assert c['replacementPointer']=='02110000' and c['nativeRosterHead']=='02110000'
assert c['replacement']['life']==975
for s in c['stages'][c['stages'].index(rebuild):]:
    for snap in [s['before'],s['after']]+[e['snapshot'] for e in s['events']]:
        q=next(p for p in snap['people'] if p['id']==640)
        assert q['flags3']==0x1040104 and q['flags4']==0x20840100,(s['label'],q)
assert c['unforcedInputs']=={'loadFlagsByte3':0,'victimTribeFlags':0,'initialGameplayRng':0x11223344}
binding=load(packet/'mission3-head-binding.json'); data=(exe.parent/'levels/levl2003.dat').read_bytes()
assert hashlib.sha256(data).hexdigest()==binding['privateInputSha256']
records=[]
for row in binding['records']:
    index=row['authoredIndex']; offset=0x14043+index*55; b=data[offset:offset+55]
    assert offset==row['recordOffset'] and hashlib.sha256(b).hexdigest()==row['recordSha256']
    assert [b[1],b[0],b[2]]==[row['class'],row['model'],row['owner']]
    xy=list(struct.unpack_from('<HH',b,3)); x,y=struct.unpack_from('<hh',b,3)
    assert xy==row['nativeCoordinates'] and [x/256-8,-y/256-8]==row['browserCoordinates']
    if index==101:
        settings=list(b[7:39]); assert settings==row['settings']
        assert [settings[0],settings[1],settings[3],struct.unpack_from('<h',b,11)[0],struct.unpack_from('<h',b,33)[0],struct.unpack_from('<H',b,13)[0]]==[0,1,1,1,40,104]
    if index==102: assert struct.unpack_from('<H',b,10)[0]==1536
    records.append({'index':index,'bytes':b.hex()})
leveltext=(root/'app/level-three.ts').read_text(); imported=json.loads(leveltext.split('export default ',1)[1].rstrip().rstrip(';'))
assert imported['sourceSha256']==binding['privateInputSha256']
matches=[p for p in imported['objects'] if p['type']==6 and p['model']==6 and p['x']==-7 and p['z']==115]
assert len(matches)==1 and matches[0]['index']==101 and matches[0]['settings']==settings
for p,hsh in binding['sourceHashes'].items():assert sha(p)==hsh,p
assert sha(binding['runtimeSnapshot'])==binding['runtimeSnapshotSha256']
snapshot=load(binding['runtimeSnapshot']); assert snapshot['turn']==binding['runtimeTurn']==8282
matches=[s for s in snapshot['shrines'] if s['kind']=='erosionEffect' and s['x']==-7 and s['z']==115]
assert len(matches)==1 and {k:matches[0][k] for k in binding['runtimeShrine']}==binding['runtimeShrine']
report['mission3']={'records':records,'runtimeShrine':matches[0],'sourceHashes':binding['sourceHashes'],'runtimeSnapshotSha256':sha(binding['runtimeSnapshot'])}
report['checks']={'retainedExportsVerified':True,'allRetainedAsmInstructionsVerified':True,'rawCallerAndSequenceAssertions':True,'nativeAcquisitionTimers':True,'noImmediateListenerMutation':True,'ownVisitReleaseThenImmediateAttackOrder':True,'otherListenerUntouchedUntilOwnVisit':True,'allocationBoundaryWithoutFight':True,'nativeConversionAllocationDeletionRoster':True,'conversionFlagsUnchangedAcrossAllLaterSnapshots':True,'unforcedInputGatesAndSeed':c['unforcedInputs'],'actualLeafSet':sorted(observed_leaves),'mission3AuthoredRuntimeBinding':True}
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','asmInstructions':sum(r['verifiedInstructions'] for r in report['asm'].values()),'entrypoints':len(report['entries']),'directCallBindings':len(report['callers']),'checks':report['checks']},indent=2))
