import datetime,hashlib,json,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];packet=out.with_name('native-sermon-order-handoff')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=json.loads((out/'preservation-before.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==before['head'] and git('status','--short')==before['status']
assert sha(root/git('rev-parse','--git-path','index'))==before['index'] and git('show-ref')==before['refs']
for p,h in before['tracked'].items():assert sha(root/p)==h,p
for p,h in before['packet'].items():assert sha(packet/p)==h,p
for p,h in before['inputs'].items():assert sha(p)==h,p
extra={}
for p in [root.parent/'prerequisites/env.sh',root.parent/'prerequisites/venv/lib/python3.12/site-packages/unicorn/lib/libunicorn.so.2',root/'decomp/generated/0047a550.c',root/'decomp/generated/0048a050.c',root/'app/live-movement.ts',root/'app/live-command.ts',root/'app/world-turn.ts',root/'app/preacher-conversion.ts',root/'scripts/import-level.py']:
    extra[str(p)]=sha(p)
(out/'final-preservation.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'trackedCount':len(before['tracked']),'frozenPacketCount':len(before['packet']),'sourceHead':before['head'],'status':before['status'],'additionalReadIdentities':extra},indent=2)+'\n')
manifest={'status':'ACCEPT-bounded-native-proof','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewedManifestSha256':sha(packet/'manifest.json'),'reviewSha256':sha(out/'review.md'),'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file() and p.name not in ['manifest.json','seal.stdout','seal.stderr']}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'result':'ACCEPT','review':str(out/'review.md'),'reviewSha256':sha(out/'review.md'),'manifest':str(out/'manifest.json'),'manifestSha256':sha(out/'manifest.json'),'preservation':'passed'},indent=2))
