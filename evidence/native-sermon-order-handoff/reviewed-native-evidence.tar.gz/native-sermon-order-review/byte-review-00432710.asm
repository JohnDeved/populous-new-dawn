00432710 4e                   dec esi
00432711 1008                 adc byte ptr [eax], cl
00432713 eb0c                 jmp 0x432721
00432715 83c908               or ecx, 8
00432718 894e10               mov dword ptr [esi + 0x10], ecx
0043271b eb04                 jmp 0x432721
0043271d 836610f7             and dword ptr [esi + 0x10], 0xfffffff7
00432721 33c0                 xor eax, eax
00432723 8a07                 mov al, byte ptr [edi]
00432725 83e803               sub eax, 3
00432728 83f81e               cmp eax, 0x1e
0043272b 0f870d030000         ja 0x432a3e
00432731 ff2485182d4300       jmp dword ptr [eax*4 + 0x432d18]
00432738 57                   push edi
00432739 56                   push esi
0043273a e8810f0000           call 0x4336c0
0043273f e9f3020000           jmp 0x432a37
00432744 57                   push edi
00432745 56                   push esi
00432746 e8b5100000           call 0x433800
0043274b e9e7020000           jmp 0x432a37
00432750 bb01000000           mov ebx, 1
00432755 e9e4020000           jmp 0x432a3e
0043275a 57                   push edi
0043275b 56                   push esi
0043275c e8bf2d0600           call 0x495520
00432761 e9d1020000           jmp 0x432a37
00432766 57                   push edi
00432767 56                   push esi
00432768 e833190000           call 0x4340a0
0043276d e9c5020000           jmp 0x432a37
00432772 57                   push edi
00432773 56                   push esi
00432774 e8971e0000           call 0x434610
00432779 e9b9020000           jmp 0x432a37
0043277e c644241400           mov byte ptr [esp + 0x14], 0
00432783 f6462e01             test byte ptr [esi + 0x2e], 1
00432787 7546                 jne 0x4327cf
00432789 0fbf464f             movsx eax, word ptr [esi + 0x4f]
0043278d 0fbf4e3d             movsx ecx, word ptr [esi + 0x3d]
00432791 2bc1                 sub eax, ecx
00432793 99                   cdq 
00432794 33c2                 xor eax, edx
00432796 2bc2                 sub eax, edx
00432798 83f870               cmp eax, 0x70
0043279b 7d1b                 jge 0x4327b8
0043279d 0fbf4651             movsx eax, word ptr [esi + 0x51]
004327a1 0fbf4e3f             movsx ecx, word ptr [esi + 0x3f]
004327a5 2bc1                 sub eax, ecx
004327a7 99                   cdq 
004327a8 33c2                 xor eax, edx
004327aa 2bc2                 sub eax, edx
004327ac 83f870               cmp eax, 0x70
004327af 7d07                 jge 0x4327b8
004327b1 c644241401           mov byte ptr [esp + 0x14], 1
004327b6 eb05                 jmp 0x4327bd
004327b8 c644241400           mov byte ptr [esp + 0x14], 0
004327bd 807c241400           cmp byte ptr [esp + 0x14], 0
004327c2 740b                 je 0x4327cf
004327c4 6a00                 push 0
004327c6 56                   push esi
004327c7 e8f4300a00           call 0x4d58c0
004327cc 83c408               add esp, 8
004327cf 33db                 xor ebx, ebx
004327d1 8a5c2414             mov bl, byte ptr [esp + 0x14]
004327d5 e964020000           jmp 0x432a3e
004327da 57                   push edi
004327db 56                   push esi
004327dc e84f520600           call 0x497a30
004327e1 e951020000           jmp 0x432a37
004327e6 57                   push edi
004327e7 56                   push esi
004327e8 e823770e00           call 0x519f10
004327ed e945020000           jmp 0x432a37
004327f2 57                   push edi
004327f3 56                   push esi
004327f4 e807720000           call 0x439a00
004327f9 e939020000           jmp 0x432a37
004327fe bb01000000           mov ebx, 1
00432803 e936020000           jmp 0x432a3e
00432808 57                   push edi
00432809 56                   push esi
0043280a e821750000           call 0x439d30
0043280f e923020000           jmp 0x432a37
00432814 33c0                 xor eax, eax
00432816 8a4706               mov al, byte ptr [edi + 6]
00432819 50                   push eax
0043281a 56                   push esi
0043281b e840bf0a00           call 0x4de760
00432820 668b869f000000       mov ax, word ptr [esi + 0x9f]
00432827 83c408               add esp, 8
0043282a 6685c0               test ax, ax
0043282d 741a                 je 0x432849
0043282f 0fb7c0               movzx eax, ax
00432832 8b1c8590038900       mov ebx, dword ptr [eax*4 + 0x890390]
00432839 85db                 test ebx, ebx
0043283b 740c                 je 0x432849
0043283d 56                   push esi
0043283e e8fdbe0a00           call 0x4de740
00432843 83c404               add esp, 4
00432846 88432f               mov byte ptr [ebx + 0x2f], al
00432849 bb01000000           mov ebx, 1
0043284e e9eb010000           jmp 0x432a3e
00432853 57                   push edi
00432854 56                   push esi
00432855 e8767c0000           call 0x43a4d0
0043285a e9d8010000           jmp 0x432a37
0043285f 57                   push edi
00432860 56                   push esi
00432861 e8aa110000           call 0x433a10
00432866 e9cc010000           jmp 0x432a37
0043286b 57                   push edi
0043286c 56                   push esi
0043286d e82e7a0e00           call 0x51a2a0
00432872 e9c0010000           jmp 0x432a37
00432877 bb01000000           mov ebx, 1
0043287c e9bd010000           jmp 0x432a3e
00432881 57                   push edi
00432882 56                   push esi
00432883 e8187a0e00           call 0x51a2a0
00432888 e9aa010000           jmp 0x432a37
0043288d 57                   push edi
0043288e 56                   push esi
0043288f e8cc280000           call 0x435160
00432894 e99e010000           jmp 0x432a37
00432899 6a01                 push 1
0043289b 8d4706               lea eax, [edi + 6]
0043289e 50                   push eax
0043289f bb01000000           mov ebx, 1
004328a4 56                   push esi
004328a5 e8a62c0000           call 0x435550
004328aa 83c40c               add esp, 0xc
004328ad e98c010000           jmp 0x432a3e
004328b2 bb01000000           mov ebx, 1
004328b7 e982010000           jmp 0x432a3e
004328bc c644241800           mov byte ptr [esp + 0x18], 0
004328c1 57                   push edi
004328c2 56                   push esi
004328c3 e8f80d0000           call 0x4336c0
004328c8 83c408               add esp, 8
004328cb 84c0                 test al, al
004328cd 7465                 je 0x432934
004328cf c644241801           mov byte ptr [esp + 0x18], 1
004328d4 8d442414             lea eax, [esp + 0x14]
004328d8 50                   push eax
004328d9 57                   push edi
004328da e8e1600000           call 0x4389c0
004328df 8d44241c             lea eax, [esp + 0x1c]
004328e3 83c408               add esp, 8
004328e6 50                   push eax
004328e7 e86427fdff           call 0x405050
004328ec 0fbf4006             movsx eax, word ptr [eax + 6]
004328f0 83c404               add esp, 4
004328f3 8b148590038900       mov edx, dword ptr [eax*4 + 0x890390]
004328fa 85d2                 test edx, edx
004328fc 7436                 je 0x432934
004328fe b80a000000           mov eax, 0xa
00432903 b910000000           mov ecx, 0x10
00432908 38422a               cmp byte ptr [edx + 0x2a], al
0043290b 7505                 jne 0x432912
0043290d 384a2b               cmp byte ptr [edx + 0x2b], cl
00432910 741c                 je 0x43292e
00432912 33db                 xor ebx, ebx
00432914 668b5a20             mov bx, word ptr [edx + 0x20]
00432918 8b149d90038900       mov edx, dword ptr [ebx*4 + 0x890390]
0043291f 85d2                 test edx, edx
00432921 75e5                 jne 0x432908
00432923 33db                 xor ebx, ebx
00432925 8a5c2418             mov bl, byte ptr [esp + 0x18]
00432929 e910010000           jmp 0x432a3e
0043292e 66c742700000         mov word ptr [edx + 0x70], 0
00432934 33db                 xor ebx, ebx
00432936 8a5c2418             mov bl, byte ptr [esp + 0x18]
0043293a e9ff000000           jmp 0x432a3e
0043293f bb01000000           mov ebx, 1
00432944 e9f5000000           jmp 0x432a3e
00432949 57                   push edi
0043294a 56                   push esi
0043294b e870930000           call 0x43bcc0
00432950 e9e2000000           jmp 0x432a37
00432955 57                   push edi
00432956 56                   push esi
00432957 e884d30e00           call 0x51fce0
0043295c e9d6000000           jmp 0x432a37
00432961 33c0                 xor eax, eax
00432963 668b4706             mov ax, word ptr [edi + 6]
00432967 8b1c8590038900       mov ebx, dword ptr [eax*4 + 0x890390]
0043296e 8a462d               mov al, byte ptr [esi + 0x2d]
00432971 c644241200           mov byte ptr [esp + 0x12], 0
00432976 84c0                 test al, al
00432978 7560                 jne 0x4329da
0043297a fec0                 inc al
0043297c 88462d               mov byte ptr [esi + 0x2d], al
0043297f 8b4b3d               mov ecx, dword ptr [ebx + 0x3d]
00432982 894c2414             mov dword ptr [esp + 0x14], ecx
00432986 894c2418             mov dword ptr [esp + 0x18], ecx
0043298a 8d4c2418             lea ecx, [esp + 0x18]
0043298e 51                   push ecx
0043298f e8bc26fdff           call 0x405050
00432994 83c404               add esp, 4
00432997 f6400102             test byte ptr [eax + 1], 2
0043299b 7421                 je 0x4329be
0043299d 8d4c2418             lea ecx, [esp + 0x18]
004329a1 51                   push ecx
004329a2 33c9                 xor ecx, ecx
004329a4 668b4808             mov cx, word ptr [eax + 8]
004329a8 81e1ff030000         and ecx, 0x3ff
004329ae 8b048d90038900       mov eax, dword ptr [ecx*4 + 0x890390]
004329b5 50                   push eax
004329b6 e8f51afdff           call 0x4044b0
004329bb 83c408               add esp, 8
004329be 8d442418             lea eax, [esp + 0x18]
004329c2 50                   push eax
004329c3 56                   push esi
004329c4 e8a704fdff           call 0x402e70
004329c9 8d44241c             lea eax, [esp + 0x1c]
004329cd 83c408               add esp, 8
004329d0 50                   push eax
004329d1 56                   push esi
004329d2 e8a9730b00           call 0x4e9d80
004329d7 83c408               add esp, 8
004329da f6462e01             test byte ptr [esi + 0x2e], 1
004329de 7521                 jne 0x432a01
004329e0 6a38                 push 0x38
004329e2 8d464f               lea eax, [esi + 0x4f]
004329e5 50                   push eax
004329e6 8d4e3d               lea ecx, [esi + 0x3d]
004329e9 6a38                 push 0x38
004329eb 51                   push ecx
004329ec e8af030000           call 0x432da0
004329f1 83c410               add esp, 0x10
004329f4 84c0                 test al, al
004329f6 7409                 je 0x432a01
004329f8 56                   push esi
004329f9 e8e2240a00           call 0x4d4ee0
