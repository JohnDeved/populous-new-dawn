00436330 56                   push esi
00436331 57                   push edi
00436332 8b74240c             mov esi, dword ptr [esp + 0xc]
00436336 85f6                 test esi, esi
00436338 0f84f1000000         je 0x43642f
0043633e 8b7c2410             mov edi, dword ptr [esp + 0x10]
00436342 837f1c00             cmp dword ptr [edi + 0x1c], 0
00436346 7426                 je 0x43636e
00436348 0fbe462f             movsx eax, byte ptr [esi + 0x2f]
0043634c 6a00                 push 0
0043634e 8bc8                 mov ecx, eax
00436350 6a19                 push 0x19
00436352 8d1480               lea edx, [eax + eax*4]
00436355 8d0451               lea eax, [ecx + edx*2]
00436358 8d14c0               lea edx, [eax + eax*8]
0043635b 8d04d1               lea eax, [ecx + edx*8]
0043635e 8b8c8165da8900       mov ecx, dword ptr [ecx + eax*4 + 0x89da65]
00436365 51                   push ecx
00436366 e8e53c0500           call 0x48a050
0043636b 83c40c               add esp, 0xc
0043636e 837f0800             cmp dword ptr [edi + 8], 0
00436372 7511                 jne 0x436385
00436374 837f0c00             cmp dword ptr [edi + 0xc], 0
00436378 750b                 jne 0x436385
0043637a 837f1800             cmp dword ptr [edi + 0x18], 0
0043637e b800000000           mov eax, 0
00436383 7405                 je 0x43638a
00436385 b801000000           mov eax, 1
0043638a 83f803               cmp eax, 3
0043638d 7707                 ja 0x436396
0043638f ff248534644300       jmp dword ptr [eax*4 + 0x436434]
00436396 6a00                 push 0
00436398 6a3a                 push 0x3a
0043639a eb10                 jmp 0x4363ac
0043639c 6a00                 push 0
0043639e 6a37                 push 0x37
004363a0 eb0a                 jmp 0x4363ac
004363a2 6a00                 push 0
004363a4 6a38                 push 0x38
004363a6 eb04                 jmp 0x4363ac
004363a8 6a00                 push 0
004363aa 6a39                 push 0x39
004363ac 56                   push esi
004363ad e89e3c0500           call 0x48a050
004363b2 83c40c               add esp, 0xc
004363b5 8b4714               mov eax, dword ptr [edi + 0x14]
004363b8 83f803               cmp eax, 3
004363bb 7707                 ja 0x4363c4
004363bd ff248544644300       jmp dword ptr [eax*4 + 0x436444]
004363c4 6a00                 push 0
004363c6 6a3e                 push 0x3e
004363c8 eb10                 jmp 0x4363da
004363ca 6a00                 push 0
004363cc 6a3b                 push 0x3b
004363ce eb0a                 jmp 0x4363da
004363d0 6a00                 push 0
004363d2 6a3c                 push 0x3c
004363d4 eb04                 jmp 0x4363da
004363d6 6a00                 push 0
004363d8 6a3d                 push 0x3d
004363da 56                   push esi
004363db e8703c0500           call 0x48a050
004363e0 83c40c               add esp, 0xc
004363e3 8b4710               mov eax, dword ptr [edi + 0x10]
004363e6 83f803               cmp eax, 3
004363e9 7707                 ja 0x4363f2
004363eb ff248554644300       jmp dword ptr [eax*4 + 0x436454]
004363f2 6a00                 push 0
004363f4 6a42                 push 0x42
004363f6 56                   push esi
004363f7 e8543c0500           call 0x48a050
004363fc 83c40c               add esp, 0xc
004363ff 5f                   pop edi
00436400 5e                   pop esi
00436401 c3                   ret 
00436402 6a00                 push 0
00436404 6a3f                 push 0x3f
00436406 56                   push esi
00436407 e8443c0500           call 0x48a050
0043640c 83c40c               add esp, 0xc
0043640f 5f                   pop edi
00436410 5e                   pop esi
00436411 c3                   ret 
00436412 6a00                 push 0
00436414 6a40                 push 0x40
00436416 56                   push esi
00436417 e8343c0500           call 0x48a050
0043641c 83c40c               add esp, 0xc
0043641f 5f                   pop edi
00436420 5e                   pop esi
00436421 c3                   ret 
00436422 6a00                 push 0
00436424 6a41                 push 0x41
00436426 56                   push esi
00436427 e8243c0500           call 0x48a050
0043642c 83c40c               add esp, 0xc
0043642f 5f                   pop edi
00436430 5e                   pop esi
00436431 c3                   ret 
