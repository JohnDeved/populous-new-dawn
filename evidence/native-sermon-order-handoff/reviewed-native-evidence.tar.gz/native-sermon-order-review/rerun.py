"""Review-only replay: original command argv, isolated stdout/stderr/receipt.

Do not invoke original run-final.py/verify-results.py in place: each writes beside
the frozen packet. Probes themselves print only and write emulated memory.
"""
import datetime, hashlib, json, os, platform, shutil, subprocess, sys, time
from pathlib import Path
import unicorn, capstone

out = Path(__file__).resolve().parent
root = out.parents[2]
packet = out.with_name('native-sermon-order-handoff')
sealed = json.loads((packet/'receipt.json').read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(['git', *a], cwd=root, text=True).strip()
def identity():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    return {'head':git('rev-parse','HEAD'), 'status':git('status','--short'),
            'index':sha(root/git('rev-parse','--git-path','index')),
            'refs':git('show-ref'),
            'tracked':{p:sha(root/p) for p in paths if p and (root/p).is_file()},
            'packet':{str(p.relative_to(packet)):sha(p) for p in packet.rglob('*') if p.is_file()},
            'inputs':{p:sha(p) for p in sealed['inputsBefore']}}
manifest_sha = sha(packet/'manifest.json')
assert manifest_sha == '781e7c5bfbad0596aab8746848a902dc6e26f7ff00d2dc50adbafa07b10e98fc'
manifest = json.loads((packet/'manifest.json').read_text())
for name, expected in manifest['files'].items():
    p=packet/name
    assert sha(p)==expected['sha256'] and p.stat().st_size==expected['bytes'], name
assert sealed['inputsBefore']==sealed['inputsAfter']
before=identity()
assert before['inputs']==sealed['inputsBefore']
tools={'python':sys.version, 'executable':sys.executable, 'pythonBinarySha256':sha(sys.executable),
       'unicorn':unicorn.__version__, 'unicornPath':unicorn.__file__,
       'capstone':capstone.__version__, 'capstonePath':capstone.__file__,
       'platform':platform.platform(), 'affinity':sorted(os.sched_getaffinity(0)),
       'libraries':{}, 'commands':{}}
for mod in (unicorn,capstone):
    for p in Path(mod.__file__).parent.rglob('*'):
        if p.is_file() and (p.suffix=='.so' or p.name== '__init__.py'):
            tools['libraries'][str(p)]=sha(p)
for name in ['timeout','taskset','git']:
    p=shutil.which(name)
    tools['commands'][name]={'path':p,'sha256':sha(p), 'version':subprocess.check_output([p,'--version'],text=True).strip()}
(out/'tool-identities.json').write_text(json.dumps(tools,indent=2)+'\n')
(out/'preservation-before.json').write_text(json.dumps(before,indent=2)+'\n')
receipt={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'sealedManifestSha256':manifest_sha, 'headBefore':before['head'],
         'statusBefore':before['status'], 'inputsBefore':before['inputs'], 'runs':[],
         'adaptation':'Original receipt command argv executed unchanged. Only redirected output and new receipt destinations differ; original output bytes are compared exactly.'}
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
for original in sealed['runs']:
    name=original['name']; cmd=original['command']; start=time.monotonic()
    stdout=out/f'final-{name}.json'; stderr=out/f'final-{name}.stderr'
    with stdout.open('wb') as a,stderr.open('wb') as b:
        run=subprocess.run(cmd,cwd=root,env=env,stdout=a,stderr=b)
    row={'name':name,'command':cmd,'exitCode':run.returncode,'durationSeconds':time.monotonic()-start,
         'stdout':str(stdout),'stdoutSha256':sha(stdout),'stderrSha256':sha(stderr),
         'reportedStatus':json.loads(stdout.read_text()).get('status'),
         'rawStdoutIdentical':stdout.read_bytes()==(packet/stdout.name).read_bytes(),
         'rawStderrIdentical':stderr.read_bytes()==(packet/stderr.name).read_bytes()}
    receipt['runs'].append(row)
    print(json.dumps(row),flush=True)
    assert row['exitCode']==0 and row['rawStdoutIdentical'] and row['rawStderrIdentical']
after=identity()
assert before==after
receipt.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),headAfter=after['head'],statusAfter=after['status'],inputsAfter=after['inputs'],sourceStable=True,fullPreservationStable=True)
(out/'preservation-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
# Unmodified verifier copy writes only beside itself. Receipt deliberately refers
# to review stdout paths; original source/input paths and contents are unchanged.
shutil.copyfile(packet/'verify-results.py',out/'verify-results.py')
cmd=['timeout','60s','taskset','-c','4',sys.executable,str(out/'verify-results.py')]
with (out/'verification.stdout').open('wb') as a,(out/'verification.stderr').open('wb') as b:
    verified=subprocess.run(cmd,cwd=root,env=env,stdout=a,stderr=b)
assert verified.returncode==0
assert (out/'verified-summary.json').read_bytes()==(packet/'verified-summary.json').read_bytes()
print('PASS: sealed files, exact native output/stderr, all original assertions, full source/index/ref/input/packet preservation.',flush=True)
