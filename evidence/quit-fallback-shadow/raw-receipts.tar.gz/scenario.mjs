import assert from 'node:assert/strict'
import {resolve} from 'node:path'
export default async function({page,browser,url,output}){
 const results=[]
 const main=p=>p.getByRole('dialog',{name:'Main menu',exact:true})
 async function check(p,name){
  await main(p).waitFor();await p.getByRole('button',{name:'Quit',exact:true}).click()
  const panel=p.locator('[data-original-quit-menu]');await panel.waitFor()
  if(!name.includes('question')&&!name.includes('both'))await panel.locator('h2 [aria-hidden="true"]').waitFor()
  if(!name.includes('choice')&&!name.includes('both'))await panel.getByRole('button',{name:'Back',exact:true}).locator('[aria-hidden="true"]').waitFor()
  await panel.getByRole('button',{name:'Back',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Back focus missing')})
  assert.equal(await panel.getByRole('button',{name:'Yes',exact:true}).isDisabled(),true)
  await p.screenshot({path:resolve(output,name+'.png')})
  await p.keyboard.press('Escape');await main(p).getByRole('button',{name:'Quit',exact:true}).evaluate(el=>{if(document.activeElement!==el)throw Error('Quit focus not restored')})
  await p.getByRole('button',{name:'Quit',exact:true}).click();await p.locator('[data-original-quit-menu]').getByRole('button',{name:'No',exact:true}).click();assert.equal(await panel.count(),0)
  results.push(name)
 }
 await check(page,'quit-ready')
 await page.close()
 for(const [name,files] of [['quit-question-fallback',['felo33we']],['quit-choice-fallback',['feft33we']],['quit-both-fallback',['felo33we','feft33we']]]){
  const c=await browser.newContext({viewport:{width:640,height:480},deviceScaleFactor:1});try{
   let blocked=0;for(const file of files)await c.route('**/original/frontend/'+file+'.png',r=>{blocked++;return r.abort('failed')})
   const p=await c.newPage();const errors=[];p.on('pageerror',e=>errors.push(String(e)));await p.goto(url,{waitUntil:'domcontentloaded'});await check(p,name);assert.ok(blocked>=files.length);assert.deepEqual(errors,[])
  }finally{await c.close()}
 }
 return{checks:results,limits:['Real OriginalMainMenu component; no full Home or native execution; controls unchanged browser Quit adaptation']}
}
