#!/usr/bin/env python3
"""Frozen, external benchmark driver. Never changes checked-out source."""
import datetime, hashlib, json, os, pathlib, platform, re, resource, signal, subprocess, sys, threading, time
ROOT=pathlib.Path('/tmp/populous-selector-scene-457')
OUT=pathlib.Path('/tmp/test-throughput-20261016')
GIT='/tmp/selector-scene457/git-bin/git'
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def git(*args): return subprocess.check_output([GIT,*args],cwd=ROOT,text=True).strip()
def snapshot(config):
 return {'head':git('rev-parse','HEAD'),'status':git('status','--porcelain'), 'trackedDiffSha256':hashlib.sha256(subprocess.check_output([GIT,'diff','HEAD','--binary'],cwd=ROOT)).hexdigest(), 'inputs':{p:sha(p if p.startswith('/') else ROOT/p) for p in config['inputs']}}
def write(path,data): path.write_text(json.dumps(data,indent=2)+'\n')
def sample_group(pgid):
 rows=[]
 for path in pathlib.Path('/proc').iterdir():
  if not path.name.isdigit(): continue
  try:
   fields=(path/'stat').read_text().rsplit(')',1)[1].split()
   if int(fields[2])!=pgid: continue
   rss=int((path/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
   rows.append({'pid':int(path.name),'startTicks':int(fields[19]),'rssBytes':rss})
  except (FileNotFoundError,ProcessLookupError,PermissionError,IndexError,ValueError): continue
 return rows
config_path=pathlib.Path(sys.argv[1]); config=json.loads(config_path.read_text())
config_sha=sha(config_path); driver_sha=sha(__file__)
series_start=now(); results=[]
for item in config['runs']:
 dest=OUT/item['name'];dest.mkdir(exist_ok=False)
 (dest/'tmp').mkdir()
 before=snapshot(config)
 if before['head']!=config['head'] or before['status'] or before['inputs']!=config['expectedInputs']: raise RuntimeError('Pre-run source/input drift')
 if sha(config_path)!=config_sha or sha(__file__)!=driver_sha: raise RuntimeError('Frozen driver/config drift')
 command=item['command']
 receipt={'kind':'controlled-node-test-measurement','status':'unknown','phase':'prepared','startedAt':now(),'command':command,'cwd':str(ROOT),'before':before,'driverSha256':driver_sha,'configSha256':config_sha,'limits':config['limits']}
 write(dest/'receipt.json',receipt)
 env=os.environ.copy();env['TMPDIR']=str(dest/'tmp')
 cpu0=resource.getrusage(resource.RUSAGE_CHILDREN)
 stats={'sampleCount':0,'sampledPeakAggregateRssBytes':0,'peakProcessCount':0,'peakRows':[],'observedProcessIdentities':set()}
 stop=threading.Event()
 def sample(pgid):
  while not stop.is_set():
   rows=sample_group(pgid);total=sum(x['rssBytes'] for x in rows)
   stats['sampleCount']+=1;stats['peakProcessCount']=max(stats['peakProcessCount'],len(rows))
   stats['observedProcessIdentities'].update((x['pid'],x['startTicks']) for x in rows)
   if total>stats['sampledPeakAggregateRssBytes']:stats['sampledPeakAggregateRssBytes']=total;stats['peakRows']=rows
   stop.wait(.1)
 with (dest/'stdout.tap').open('wb') as stdout, (dest/'stderr.log').open('wb') as stderr:
  started=time.perf_counter();p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  sampler=threading.Thread(target=sample,args=(p.pid,),daemon=True);sampler.start()
  try: code=p.wait()
  except BaseException:
   os.killpg(p.pid,signal.SIGTERM);p.wait();raise
  finally:
   wall=time.perf_counter()-started;stop.set();sampler.join()
 cpu1=resource.getrusage(resource.RUSAGE_CHILDREN)
 after=snapshot(config);raw=(dest/'stdout.tap').read_text()
 counts={}
 for key in ['tests','suites','pass','fail','cancelled','skipped','todo']:
  found=re.findall(r'^# '+key+r' (\d+)\s*$',raw,re.M)
  counts[key]=int(found[-1]) if found else None
 top_names=re.findall(r'^(?:ok|not ok) \d+ - (.*)$',raw,re.M)
 drift=after!=before or sha(config_path)!=config_sha or sha(__file__)!=driver_sha
 valid=all(counts.get(k)==0 for k in ['fail','cancelled','skipped','todo']) and counts.get('tests')==counts.get('pass') and bool(counts.get('tests'))
 remaining=sample_group(p.pid)
 stats['observedProcessIdentities']=[{'pid':pid,'startTicks':start} for pid,start in sorted(stats['observedProcessIdentities'])]
 receipt.update(status='invalidated' if drift else ('passed' if code==0 and valid and not remaining else 'failed'),phase='finished',finishedAt=now(),exitCode=code,signal=(-code if code<0 else None),wallSeconds=wall,cpuUserSeconds=cpu1.ru_utime-cpu0.ru_utime,cpuSystemSeconds=cpu1.ru_stime-cpu0.ru_stime,metrics=stats,counts=counts,topLevelCaseNames=top_names,topLevelCaseNamesSha256=hashlib.sha256(json.dumps(top_names).encode()).hexdigest(),after=after,remainingOwnedGroup=remaining,artifacts={'stdout':str(dest/'stdout.tap'),'stdoutSha256':sha(dest/'stdout.tap'),'stderr':str(dest/'stderr.log'),'stderrSha256':sha(dest/'stderr.log')})
 write(dest/'receipt.json',receipt);results.append(receipt)
 print(json.dumps({'run':item['name'],'status':receipt['status'],'wallSeconds':wall,'cpuSeconds':receipt['cpuUserSeconds']+receipt['cpuSystemSeconds'],'sampledPeakAggregateRssMiB':stats['sampledPeakAggregateRssBytes']/1048576,'counts':counts}),flush=True)
 if receipt['status']!='passed': break
summary={'startedAt':series_start,'finishedAt':now(),'configSha256':config_sha,'driverSha256':driver_sha,'results':[str(OUT/r['name']/'receipt.json') for r in config['runs'][:len(results)]],'allPassed':len(results)==len(config['runs']) and all(r['status']=='passed' for r in results),'caseCoverageIdentical':len(set(r['topLevelCaseNamesSha256'] for r in results))==1,'totalMeasurementWallSeconds':sum(r['wallSeconds'] for r in results)}
write(OUT/config['summaryName'],summary)
print(json.dumps(summary),flush=True)
if not summary['allPassed'] or not summary['caseCoverageIdentical']:sys.exit(1)
