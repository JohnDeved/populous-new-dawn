import importlib.util,json,pathlib,tempfile
path=pathlib.Path(__file__).with_name('benchmark-v2.py');spec=importlib.util.spec_from_file_location('benchmark',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files=['tests/a.test.mjs','tests/b.test.mjs'];pg=[{'concurrency':1,'files':[f]} for f in files]
groups=[{'command':['node','--test','--test-concurrency=1','--test-reporter=tap',*g['files']],**g,'exitCode':0,'signal':None,'error':None,'status':'passed','wallMs':25} for g in pg]
plan={'kind':'pnd-test-plan','mode':'all','fullSuite':True,'files':files,'groups':pg};result={'kind':'pnd-test-result','mode':'all','fullSuite':True,'complete':True,'interrupted':None,'results':groups,'status':'passed','wallMs':52}
config={'node':'node','files':files,'minimumExpectedTests':2};item={'expectedGroups':pg}
with tempfile.TemporaryDirectory(prefix='benchmark-parser-',dir=path.parent) as tmp:
 tmp=pathlib.Path(tmp);stdout=tmp/'stdout';stderr=tmp/'stderr'
 raw=''.join(f'TAP version 13\n# Subtest: {i}\n    ok 1 - nested {i}\nok 1 - {i}\n# # tests 999\n1..1\n# tests 2\n# suites 0\n# pass 2\n# fail 0\n# cancelled 0\n# skipped 0\n# todo 0\n' for i in ['a','b']);stdout.write_text(raw)
 def parse(plan=plan,groups=groups,result=result,item=item):
  stderr.write_text('\n'.join(json.dumps(x) for x in [plan,*[{'kind':'pnd-test-group',**g} for g in groups],result]))
  return m.parse_output(stdout,stderr,config,item)
 valid=parse();assert not valid['errors'],valid;assert valid['counts']['tests']==4;assert len(valid['fullCaseHierarchy'])==4;assert valid['testChildProcessWallSeconds']==.05;assert valid['testRunnerWallSeconds']==.052
 assert parse(plan={**plan,'files':[files[0],files[0]]})['errors']
 bad=[{**groups[0],'files':['tests/wrong.test.mjs']},groups[1]];assert parse(groups=bad)['errors']
 assert parse(result={**result,'complete':False})['errors']
 assert parse(item={'expectedGroups':[{'concurrency':2,'files':files}]})['errors']
 for command in [['wrong-node',*groups[0]['command'][1:]],['node','--test','--test-concurrency=2','--test-reporter=tap',files[0]],['node','--test','--test-concurrency=1','--test-only',files[0]]]:
  assert parse(groups=[{**groups[0],'command':command},groups[1]])['errors']
 assert parse(groups=[{**groups[0],'exitCode':1},groups[1]])['errors']
 assert parse(groups=[{**groups[0],'concurrency':2},groups[1]])['errors']
 assert parse(result={**result,'results':[groups[1],groups[0]]})['errors']
 stdout.write_text(raw.replace('# fail 0','# fail 1',1));assert parse()['errors']
 stdout.write_text(raw.replace('nested a','nested changed'));changed=parse();assert changed['topLevelCaseNamesMultisetSha256']==valid['topLevelCaseNamesMultisetSha256'];assert changed['fullCaseHierarchyMultisetSha256']!=valid['fullCaseHierarchyMultisetSha256']
 print('PASS: valid strict grouped TAP/argv, nested case hierarchy, diagnostic exclusion, duplicate/missing/changed/predeclared groups, wrong runtime/flag/concurrency, native failure, incomplete/reordered final results, failing counters')
