#!/usr/bin/env python3
"""External source-bound throughput observations; no checked-out-source writes."""
import collections, datetime, hashlib, json, os, pathlib, re, resource, signal, subprocess, sys, threading, time

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write(path,value):
 path=pathlib.Path(path);path.write_text(json.dumps(value,indent=2)+'\n')
def git(config,*args):return subprocess.check_output([config['git'],*args],cwd=config['root'],text=True).strip()
def tree_manifest(path):
 path=pathlib.Path(path);root=path.resolve(strict=True);rows=[];total=0;initial={}
 entries=sorted(root.rglob('*'))
 for entry in entries:
  rel=str(entry.relative_to(root));before=entry.lstat();initial[entry]=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)
  if entry.is_symlink():
   target=entry.resolve(strict=True)
   if not target.is_relative_to(root):raise RuntimeError(f'Dependency symlink outside declared tree: {entry}')
   if target.is_dir():raise RuntimeError(f'Directory symlink requires separate audited tree: {entry}')
   row={'path':rel,'type':'symlink','target':str(entry.readlink()),'resolvedPath':str(target.relative_to(root)),'sha256':sha(target)}
  elif entry.is_file():row={'path':rel,'type':'file','bytes':before.st_size,'sha256':sha(entry)};total+=before.st_size
  elif entry.is_dir():row={'path':rel,'type':'directory'}
  else:raise RuntimeError(f'Unexpected dependency entry type: {entry}')
  after=entry.lstat()
  if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise RuntimeError(f'Input mutated while hashing: {entry}')
  rows.append(row)
 if sorted(root.rglob('*'))!=entries:raise RuntimeError(f'Dependency tree entries changed while hashing: {root}')
 for entry in entries:
  current=entry.lstat()
  if initial[entry]!=(current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns,current.st_ctime_ns):raise RuntimeError(f'Dependency tree mutated while hashing: {entry}')
 return {'path':str(path),'resolvedPath':str(root),'sha256':digest(rows),'entryCount':len(rows),'regularFileBytes':total},rows

def env_hashes(env,keys):return {key:hashlib.sha256(env[key].encode()).hexdigest() if key in env else None for key in keys}
def snapshot(config,env,manifest_dir=None):
 root=pathlib.Path(config['root']);trees={}
 for index,path in enumerate(config['dependencyTrees']):
  summary,rows=tree_manifest(path);trees[path]=summary
  if manifest_dir is not None:write(pathlib.Path(manifest_dir)/f'dependency-tree-{index}.json',{'summary':summary,'entries':rows})
 files=git(config,'ls-files','tests/*.test.mjs').splitlines()
 return {'head':git(config,'rev-parse','HEAD'),'status':git(config,'status','--porcelain'),'trackedDiffSha256':hashlib.sha256(subprocess.check_output([config['git'],'diff','HEAD','--binary'],cwd=root)).hexdigest(),'testFiles':files,'inputs':{p:sha(p if p.startswith('/') else root/p) for p in config['inputs']},'dependencyTrees':trees,'environmentHashes':env_hashes(env,config['environmentKeys'])}

def process_table():
 table={}
 for path in pathlib.Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   f=(path/'stat').read_text().rsplit(')',1)[1].split();pid=int(path.name)
   table[pid]={'pid':pid,'parent':int(f[1]),'group':int(f[2]),'session':int(f[3]),'startTicks':int(f[19]),'state':f[0],'rssBytes':int((path/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')}
  except (FileNotFoundError,ProcessLookupError,PermissionError,IndexError,ValueError):continue
 return table

def owned_rows(table,known):
 owned={pid:row for pid,row in table.items() if known.get(pid)==row['startTicks']}
 while True:
  extra={pid:row for pid,row in table.items() if pid not in owned and row['parent'] in owned}
  if not extra:break
  owned.update(extra);known.update({pid:row['startTicks'] for pid,row in extra.items()})
 return [row for row in owned.values() if row['state']!='Z']

def signal_verified_group(root_identity,known,sig):
 table=process_table();group=root_identity['group'];members=[row for row in table.values() if row['group']==group]
 if not members:return {'signal':sig,'status':'already-absent'}
 verified=[r for r in members if known.get(r['pid'])==r['startTicks'] and r['session']==root_identity['session']]
 if not verified:return {'signal':sig,'status':'blocked-no-current-owned-identity'}
 os.killpg(group,sig)
 return {'signal':sig,'status':'sent','verifiedMembers':[{'pid':r['pid'],'startTicks':r['startTicks']} for r in verified]}

def parse_output(stdout,stderr,config,item=None):
 text=stdout.read_text();errors=[];records=[]
 for line in stderr.read_text().splitlines():
  pos=line.find('{')
  if pos<0:continue
  try:record=json.loads(line[pos:])
  except json.JSONDecodeError:continue
  if isinstance(record,dict):records.append(record)
 def kind(r):return r.get('type',r.get('kind',r.get('event')))
 plans=[r for r in records if kind(r)=='pnd-test-plan'];groups=[r for r in records if kind(r)=='pnd-test-group'];results=[r for r in records if kind(r)=='pnd-test-result']
 if len(plans)!=1:errors.append(f'Expected one runner plan, got {len(plans)}')
 if len(results)!=1:errors.append(f'Expected one runner result, got {len(results)}')
 plan=plans[0] if len(plans)==1 else {};expected=config['files'];planned=plan.get('files',[])
 if len(planned)!=len(set(planned)) or set(planned)!=set(expected):errors.append('Runner plan file coverage mismatch/duplicates')
 plan_groups=plan.get('groups',[])
 if item is not None and plan_groups!=item['expectedGroups']:errors.append('Actual plan differs from predeclared groups/order/concurrency')
 group_files=[f for group in plan_groups for f in group.get('files',[])]
 if len(group_files)!=len(set(group_files)) or set(group_files)!=set(expected):errors.append('Runner group file coverage mismatch/duplicates')
 if plan.get('mode')!='all' or plan.get('fullSuite') is not True:errors.append('Runner plan is not full all-mode')
 if len(groups)!=len(plan_groups):errors.append('Executed group count differs from plan')
 for expected_group,actual in zip(plan_groups,groups):
  if actual.get('files')!=expected_group.get('files') or actual.get('concurrency')!=expected_group.get('concurrency'):errors.append('Executed group differs from planned files/order/concurrency')
  if actual.get('status')!='passed' or actual.get('exitCode')!=0 or actual.get('signal') or actual.get('error'):errors.append('Runner group did not pass natively')
  command=actual.get('command',[])
  if not command or command[-len(actual.get('files',[])):]!=actual.get('files'):errors.append('Executed group command does not match files')
  if config.get('node') and command!=[config['node'],'--test',f"--test-concurrency={expected_group.get('concurrency')}",'--test-reporter=tap',*expected_group.get('files',[])]:errors.append('Executed Node command differs from predeclared flags/runtime')
 result=results[0] if len(results)==1 else {}
 if result.get('status')!='passed' or result.get('complete') is not True or result.get('interrupted') or result.get('fullSuite') is not True:errors.append('Runner result incomplete/interrupted/nonpassing')
 if result.get('results')!=[{k:v for k,v in group.items() if k!='kind'} for group in groups]:errors.append('Final runner result does not match group records')
 counters={key:[int(v) for v in re.findall(r'^# '+key+r' (\d+)\s*$',text,re.M)] for key in ['tests','suites','pass','fail','cancelled','skipped','todo']}
 for key,values in counters.items():
  if len(values)!=len(plan_groups):errors.append(f'{key} summary count {len(values)} differs from planned groups {len(plan_groups)}')
 totals={key:sum(values) for key,values in counters.items()}
 if totals['tests']<config.get('minimumExpectedTests',1):errors.append('Too few tests for declared complete inventory')
 if config.get('expectedTestCount') is not None and totals['tests']!=config['expectedTestCount']:errors.append('Test count differs from predeclared expected complete count')
 if not totals['tests'] or totals['pass']!=totals['tests'] or any(totals[k] for k in ['fail','cancelled','skipped','todo']):errors.append('Missing or nonpassing test cases')
 names=re.findall(r'^(?:ok|not ok) \d+ - (.*)$',text,re.M)
 hierarchy=[{'indent':len(indent),'ordinal':int(ordinal),'name':name} for indent,ordinal,name in re.findall(r'^([ \t]*)(?:ok|not ok) (\d+) - (.*)$',text,re.M)]
 return {'errors':errors,'plan':plan,'groups':groups,'result':results[0] if len(results)==1 else None,'countsPerGroup':counters,'counts':totals,'topLevelCaseNames':names,'topLevelCaseNamesMultisetSha256':digest(sorted(names)),'topLevelCaseNamesOrderedSha256':digest(names),'fullCaseHierarchy':hierarchy,'fullCaseHierarchyOrderedSha256':digest(hierarchy),'fullCaseHierarchyMultisetSha256':digest(sorted(hierarchy,key=lambda x:json.dumps(x,sort_keys=True))),'testChildProcessWallSeconds':sum(group.get('wallMs',0) for group in groups)/1000,'testRunnerWallSeconds':result.get('wallMs',0)/1000 if result.get('wallMs') is not None else None}

def run(config,config_path,item,frozen):
 out=pathlib.Path(config['output']);dest=out/item['name'];dest.mkdir(exist_ok=False);(dest/'tmp').mkdir()
 env=os.environ.copy();env.update(config.get('baseEnv',{}));env.update(item.get('env',{}));env['TMPDIR']=str(dest/'tmp')
 before=snapshot(config,env);expected=config['expectedSnapshot'].copy();expected['environmentHashes']=config['expectedSnapshot']['environmentHashes'].copy()
 for key,value in item.get('env',{}).items():
  if key not in config['environmentKeys']:raise RuntimeError(f'Unfingerprinted environment override: {key}')
  expected['environmentHashes'][key]=hashlib.sha256(value.encode()).hexdigest()
 if before!=expected:write(dest/'unexpected-prelaunch.json',before);raise RuntimeError('Pre-run source/input drift')
 if frozen!={'driverSha256':sha(__file__),'configSha256':sha(config_path)}:raise RuntimeError('Frozen driver/config changed before run')
 receipt={'kind':'controlled-check-throughput-observation','status':'unknown','phase':'prepared','startedAt':now(),'command':item['command'],'cwd':config['root'],'declaredEnvironment':item.get('env',{}),'before':before,'frozen':frozen,'limits':config['limits']}
 write(dest/'receipt.json',receipt)
 stats={'sampleIntervalSeconds':.1,'sampleCount':0,'sampledPeakAggregateRssBytes':0,'peakProcessCount':0,'peakRows':[]};known={};stop=threading.Event();interruption=None;cleanup=[]
 with (dest/'stdout.log').open('wb') as stdout,(dest/'stderr.log').open('wb') as stderr:
  cpu0=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.perf_counter()
  p=subprocess.Popen(item['command'],cwd=config['root'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  root_identity=process_table().get(p.pid)
  if root_identity is None:raise RuntimeError('Failed to capture launched leader identity')
  known[p.pid]=root_identity['startTicks'];receipt['rootIdentity']=root_identity;receipt['phase']='running';write(dest/'receipt.json',receipt)
  def sample():
   while not stop.is_set():
    rows=owned_rows(process_table(),known);total=sum(r['rssBytes'] for r in rows)
    stats['sampleCount']+=1;stats['peakProcessCount']=max(stats['peakProcessCount'],len(rows))
    if total>stats['sampledPeakAggregateRssBytes']:stats['sampledPeakAggregateRssBytes']=total;stats['peakRows']=rows
    stop.wait(.1)
  sampler=threading.Thread(target=sample,daemon=True);sampler.start()
  try:code=p.wait()
  except BaseException as exc:
   interruption={'type':type(exc).__name__,'message':str(exc)}
   cleanup.append(signal_verified_group(root_identity,known,signal.SIGTERM))
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    cleanup.append(signal_verified_group(root_identity,known,signal.SIGKILL))
    try:code=p.wait(timeout=5)
    except subprocess.TimeoutExpired:code=None
  finally:
   wall=time.perf_counter()-started;cpu1=resource.getrusage(resource.RUSAGE_CHILDREN);stop.set();sampler.join(timeout=2)
 remaining=owned_rows(process_table(),known)
 parsed=parse_output(dest/'stdout.log',dest/'stderr.log',config,item)
 after=snapshot(config,env)
 drift=after!=before or frozen!={'driverSha256':sha(__file__),'configSha256':sha(config_path)}
 stats['observedProcessIdentities']=[{'pid':pid,'startTicks':start} for pid,start in sorted(known.items())]
 status='invalidated' if drift else ('passed' if code==0 and not parsed['errors'] and not interruption and not remaining else 'failed')
 receipt.update(status=status,phase='finished',finishedAt=now(),exitCode=code,signal=(-code if code is not None and code<0 else None),wallSeconds=wall,cpuUserSeconds=cpu1.ru_utime-cpu0.ru_utime,cpuSystemSeconds=cpu1.ru_stime-cpu0.ru_stime,metrics=stats,verification=parsed,after=after,interruption=interruption,cleanupAttempts=cleanup,remainingObservedOwnedProcesses=remaining,artifacts={'stdout':str(dest/'stdout.log'),'stdoutSha256':sha(dest/'stdout.log'),'stderr':str(dest/'stderr.log'),'stderrSha256':sha(dest/'stderr.log')})
 write(dest/'receipt.json',receipt)
 print(json.dumps({'run':item['name'],'status':status,'wallSeconds':wall,'cpuSeconds':receipt['cpuUserSeconds']+receipt['cpuSystemSeconds'],'sampledPeakAggregateRssMiB':stats['sampledPeakAggregateRssBytes']/1048576,'counts':parsed['counts'],'errors':parsed['errors']}),flush=True)
 return receipt

def main():
 config_path=pathlib.Path(sys.argv[1]);config=json.loads(config_path.read_text());out=pathlib.Path(config['output'])
 if len(sys.argv)>2 and sys.argv[2]=='--prepare':
  env=os.environ.copy();env.update(config.get('baseEnv',{}));env.update(config['runs'][0].get('env',{}))
  snap=snapshot(config,env,out)
  if snap['status']:raise RuntimeError('Prepare requires clean committed source')
  if set(snap['testFiles'])!=set(config['files']):raise RuntimeError('Configured file list differs from tracked complete test inventory')
  config['expectedSnapshot']=snap;config['preparedAt']=now();write(config_path,config);print(json.dumps({'preparedAt':config['preparedAt'],'head':snap['head'],'files':len(snap['testFiles']),'dependencyTrees':snap['dependencyTrees']}));return
 series_start=now();results=[];frozen={'driverSha256':sha(__file__),'configSha256':sha(config_path)}
 for item in config['runs']:
  receipt=run(config,config_path,item,frozen);results.append(receipt)
  if receipt['status']!='passed':break
 summary={'startedAt':series_start,'finishedAt':now(),'frozen':frozen,'results':[str(out/item['name']/'receipt.json') for item in config['runs'][:len(results)]],'allPassed':len(results)==len(config['runs']) and all(r['status']=='passed' for r in results),'caseCoverageIdentical':len(set(r['verification']['fullCaseHierarchyMultisetSha256'] for r in results))==1 and len(set(digest(r['verification']['counts']) for r in results))==1 and len(set(digest(r['verification']['countsPerGroup']) for r in results))==1,'countsIdentical':len(set(digest(r['verification']['counts']) for r in results))==1,'countsPerGroupIdentical':len(set(digest(r['verification']['countsPerGroup']) for r in results))==1,'fullCaseHierarchyOrderIdentical':len(set(r['verification']['fullCaseHierarchyOrderedSha256'] for r in results))==1,'caseOrderIdentical':len(set(r['verification']['topLevelCaseNamesOrderedSha256'] for r in results))==1,'totalMeasuredWallSeconds':sum(r['wallSeconds'] for r in results)}
 write(out/'summary.json',summary);print(json.dumps(summary),flush=True)
 if not summary['allPassed'] or not summary['caseCoverageIdentical']:sys.exit(1)
if __name__=='__main__':main()
