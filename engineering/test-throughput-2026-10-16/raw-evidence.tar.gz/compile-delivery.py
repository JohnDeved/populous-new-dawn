"""Assemble a portable evidence inventory without modifying measured artifacts."""
import datetime, hashlib, json, math, os, pathlib, re

ROOT = pathlib.Path(__file__).parent
FINAL = ROOT / 'formal-d5fd9b88'
PILOT = pathlib.Path('/tmp/test-throughput-20261016')
def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def clock(seconds):
    minutes, seconds = divmod(seconds, 60)
    return f'{int(minutes)}m {seconds:06.3f}s'
a = read(FINAL / 'formal-1-c1/receipt.json')
b = read(FINAL / 'formal-2-c2/receipt.json')
summary = read(FINAL / 'summary.json')
assert all(summary[k] is True for k in ['allPassed','caseCoverageIdentical','countsIdentical','countsPerGroupIdentical','fullCaseHierarchyOrderIdentical','caseOrderIdentical'])
for receipt in [a, b]:
    assert receipt['status'] == 'passed' and receipt['exitCode'] == 0
    assert not receipt['remainingObservedOwnedProcesses']
    assert receipt['before'] == receipt['after']
    for stream in ['stdout','stderr']:
        assert sha(pathlib.Path(receipt['artifacts'][stream])) == receipt['artifacts'][stream+'Sha256']
v1, v2 = a['verification'], b['verification']
test_saved = v1['testRunnerWallSeconds'] - v2['testRunnerWallSeconds']
check_saved = a['wallSeconds'] - b['wallSeconds']
pilot = [read(PILOT / f'pilot-{i}-c{c}/receipt.json') for i,c in [(1,1),(2,2),(3,2),(4,1)]]
pilot_seconds = sum(r['wallSeconds'] for r in pilot)
superseded_warmup = read(ROOT/'typecheck-warmup/receipt.json')['wallSeconds']
final_warmup = read(FINAL/'typecheck-warmup/receipt.json')['wallSeconds']
command_cost = pilot_seconds + superseded_warmup + final_warmup + a['wallSeconds'] + b['wallSeconds']
rows = []
for label, r in [('serial',a), ('bounded',b)]:
    rows.append({'profile':label,'testRunnerWallSeconds':r['verification']['testRunnerWallSeconds'],
        'wholeCheckWallSeconds':r['wallSeconds'], 'childCpuSeconds':r['cpuUserSeconds']+r['cpuSystemSeconds'],
        'sampledAggregatePeakRssMiB':r['metrics']['sampledPeakAggregateRssBytes']/1024**2,
        'groupWallSeconds':[g['wallMs']/1000 for g in r['verification']['groups']],
        'observedProcessIdentities':len(r['metrics']['observedProcessIdentities']),
        'counts':r['verification']['counts']})
results = {'measuredSource':'d5fd9b889dd6aa301d5e2b2d84362b843085259a','profiles':rows,
    'observedTestPhaseSavingSeconds':test_saved,'observedTestPhaseSavingPercent':100*test_saved/v1['testRunnerWallSeconds'],
    'observedWholeCheckSavingSeconds':check_saved,'observedWholeCheckSavingPercent':100*check_saved/a['wallSeconds'],
    'measurementCommandWallSeconds':command_cost,'measurementCostBreakdownSeconds':{'pilot':pilot_seconds,'supersededWarmup':superseded_warmup,'finalWarmup':final_warmup,'formalPair':a['wallSeconds']+b['wallSeconds']},
    'conditionalBreakEvenComparableFutureRuns':math.ceil(command_cost/test_saved),
    'conditions':'One C1-then-C2 full pair. Dependency hash-warmed, typecheck prewarmed. Unknown host contention and CPU/memory quotas. Future savings conditional, not guaranteed.'}
write(ROOT/'measurement-results.json', results)

report = f'''# Bounded test concurrency: measured result

Measured source: `d5fd9b889dd6aa301d5e2b2d84362b843085259a`. Observation date: 2026-10-16 UTC. This is a predeclared single full C1-then-C2 pair on the same frozen source and installed dependencies.

## Result

The test phase fell from **{clock(v1['testRunnerWallSeconds'])} to {clock(v2['testRunnerWallSeconds'])}**, an observed saving of **{clock(test_saved)} ({100*test_saved/v1['testRunnerWallSeconds']:.2f}%)**. Both runs passed the same **435 files and 2,809 cases**, with no failures, cancellations, skips or TODO cases. Full case hierarchy, case order, per-group counts and totals matched. No assertions or timeouts were weakened, and no library migration was made.

| Measurement | Serial profile | Bounded profile |
| --- | ---: | ---: |
| Test runner wall time, primary | {clock(v1['testRunnerWallSeconds'])} | {clock(v2['testRunnerWallSeconds'])} |
| Whole `npm run check` wall time | {clock(a['wallSeconds'])} | {clock(b['wallSeconds'])} |
| Reviewed 357-file group, 2,166 cases | {clock(rows[0]['groupWallSeconds'][0])} | {clock(rows[1]['groupWallSeconds'][0])} |
| Serial 78-file group, 643 cases | {clock(rows[0]['groupWallSeconds'][1])} | {clock(rows[1]['groupWallSeconds'][1])} |
| Whole-check reaped-child CPU seconds | {rows[0]['childCpuSeconds']:.3f} | {rows[1]['childCpuSeconds']:.3f} |
| Whole-check sampled aggregate peak RSS, MiB | {rows[0]['sampledAggregatePeakRssMiB']:.3f} | {rows[1]['sampledAggregatePeakRssMiB']:.3f} |

Whole-check observed saving: **{clock(check_saved)} ({100*check_saved/a['wallSeconds']:.2f}%)**. It includes typechecking, npm startup and the test runner; it is not an end-to-end development/build/browser timing. The comparison isolates bounded concurrency in the final runner. The serial baseline is that same final runner, not a rerun of the earlier ten-file-batch workflow, so there is no separately measured claim for batching removal or focused-workflow savings.

## Equal work and invocation

The literal command was `npm run check` in both conditions. Both used Node v24.19.0, the same 357 reviewed files followed by the same 78 resource-sensitive files, in identical declared order. Only the first group's file-process concurrency changed from 1 to 2. The 78-file group remained at concurrency 1. Built-in Node per-file process isolation was retained.

Both invocations explicitly set `NODE_PATH='' NODE_OPTIONS=''`; `NODE_COMPILE_CACHE` and `NODE_V8_COVERAGE` were unset. The profile was selected using `PND_TEST_CONCURRENCY=1` and then `PND_TEST_CONCURRENCY=2`. A separate private `TMPDIR` was used for each run. The environment's inherited nonempty `NODE_PATH` would trigger the conservative serial fallback, so an ordinary inherited invocation must not be described as necessarily using concurrency 2. The frozen configuration records the exact executable paths and overrides.

The original 2,795 cases were retained; 14 runner/policy regression cases bring this final candidate to 2,809. Native exit status, structured plan/group/final records, exact 435-file inventory, outer TAP summaries, and full indented case hierarchy were checked. Both commands exited 0, without interruption or cleanup signals. Before/after source, runtime, cache-artifact and dependency-byte identities matched. No observed owned process identities remained at release; unobserved escaped or short-lived descendants are not certified absent.

## Conditions and limits

- This is one full C1-then-C2 observation, not a full-suite repeatability study. There is no statistical confidence interval or guarantee of the same saving on another host. Serial-first order, warm state and host variability can influence the difference. The unchanged serial group itself varied from {rows[0]['groupWallSeconds'][1]:.3f}s to {rows[1]['groupWallSeconds'][1]:.3f}s.
- One fresh final-source typecheck warmup ran before the pair ({final_warmup:.3f}s). Its resulting incremental cache and generated type input bytes were then bound in the measurement. The whole-check comparison still has order/cache caveats.
- Complete node_modules and npm CLI content trees were fingerprinted before and after each run, outside timed wall/child-CPU intervals. This warms dependency pages for both profiles; neither is a cold-cache result. No dependency installation or copy occurred.
- The reused Linux x86_64 environment exposed 9 CPUs. Actual CPU/memory quotas were unavailable (`/sys/fs/cgroup` absent), and global host contention and historical unknown processes remain unknown. Coordinated agent-owned heavy work was serialized; this does not establish host-wide idleness or hardware capacity.
- RSS is the 100 ms sampled sum for observed PID/start-time descendants. The sampling is a lower-bound observation of instantaneous aggregate RSS, shared pages may be counted more than once, and short-lived or unobserved escaped processes can be missed. These are whole-check values, including typechecking, not test-only memory. CPU is the reaped-child `RUSAGE_CHILDREN` delta; native threads can make CPU time exceed wall time. No OOM or machine-capacity conclusion is drawn.

## Preliminary pilot and attempt record

An earlier eight-file/46-case pilot used C1, C2, C2, C1 on accepted main `d5768f9dd957a65c76c12a568a92d32ff164cac5`. All cases passed. Individual wall times were 46.760s, 29.880s, 29.211s and 46.003s. It is **preliminary only**: source/runtime/lockfiles were bound, but actual installed dependency bytes were not. Its observations are retained separately and are not used to calculate or extrapolate the accepted full-suite saving.

The earlier `f2a8a220` preparation and its {superseded_warmup:.3f}s passing typecheck were superseded by source-policy repairs. Reported overlapping edit timing made it unsuitable as final-candidate proof; its raw receipt and qualification are preserved. No full check was launched on that preparation. The `0ed19f09` preparation draft was never launched. Final `d5fd9b88` preparation used a new warmup and configuration. Neither full formal condition failed or was retried. Writer-owned focused/lint failures during implementation are preserved separately in the implementation evidence; they are not silently converted into passing benchmark attempts.

## Measurement cost and conditional payback

Recorded benchmark command wall time invested was **{clock(command_cost)}**: pilot {pilot_seconds:.3f}s, superseded warmup {superseded_warmup:.3f}s, final warmup {final_warmup:.3f}s, and the two full checks {a['wallSeconds']+b['wallSeconds']:.3f}s. This excludes implementation, focused regressions, review, dependency hashing, preparation and coordination time. The formal series spanned {summary['startedAt']} through {summary['finishedAt']}; its extra elapsed time includes input verification outside the command timers. The two full checks also supplied full verification, so no third full suite was run solely for a separate gate.

At the observed test-phase saving, this recorded measurement-command investment is amortized after **{math.ceil(command_cost/test_saved)} comparable future full runs**. This is conditional arithmetic, not a forecast or a claim that the project has already saved net time. Focused test selection is available for shorter feedback, but no unmeasured end-to-end saving is claimed.

## Evidence identity and portability

- Frozen driver SHA-256: `{summary['frozen']['driverSha256']}`
- Frozen final config SHA-256: `{summary['frozen']['configSha256']}`
- Full case hierarchy ordered SHA-256: `{v1['fullCaseHierarchyOrderedSha256']}`
- Full case hierarchy multiset SHA-256: `{v1['fullCaseHierarchyMultisetSha256']}`
- Dependency tree manifest SHA-256: `{sha(FINAL/'dependency-tree-0.json')}`
- npm CLI tree manifest SHA-256: `{sha(FINAL/'dependency-tree-1.json')}`

See `measurement-results.json` for numeric results and `benchmark-artifacts.json` for every included file's original location, portable archive location, byte size and SHA-256. Raw receipts and logs retain their original bytes, including original absolute technical paths; the inventory maps them to portable locations. Identical superseded dependency manifests are deduplicated with both origins recorded. Private temporary directories and Python bytecode caches are excluded. The inventory also retains the preliminary and superseded/unlaunched artifacts rather than discarding unsuccessful or nonqualifying preparation.
'''
(ROOT/'measurement-report.md').write_text(report)

entries = []
def add(source, destination, classification, origins=None):
    source=pathlib.Path(source)
    assert source.is_file() and not source.is_symlink()
    entries.append({'source':str(source),'bundlePath':destination,'classification':classification,
        'bytes':source.stat().st_size,'sha256':sha(source),'additionalIdenticalOrigins':origins or []})
for p in sorted(FINAL.rglob('*')):
    rel=p.relative_to(FINAL)
    if p.is_file() and not any(part in ['tmp','__pycache__'] for part in rel.parts):
        origins=[]
        if p.name.startswith('dependency-tree-'):
            old=ROOT/p.name
            assert old.read_bytes()==p.read_bytes()
            origins=[str(old)]
        add(p,'formal-d5fd9b88/'+str(rel),'accepted-formal',origins)
for p in sorted(PILOT.rglob('*')):
    rel=p.relative_to(PILOT)
    if p.is_file() and not any(part in ['tmp','__pycache__'] for part in rel.parts): add(p,'pilot/'+str(rel),'preliminary-pilot')
for name in ['formal-config.json','prepare-formal.py','preflight-budget.json','expected-plans.json','f2a8a220-preparation-qualification.json','typecheck-warmup/receipt.json','typecheck-warmup/stdout.log','typecheck-warmup/stderr.log']:
    add(ROOT/name,'superseded-f2a8a220/'+name,'superseded-preparation')
for p in sorted((ROOT/'formal-0ed19f09').rglob('*')):
    rel=p.relative_to(ROOT/'formal-0ed19f09')
    if p.is_file() and '__pycache__' not in rel.parts: add(p,'unlaunched-0ed19f09/'+str(rel),'unlaunched-draft')
for name in ['benchmark-v2.py','test-driver.py','parser-regression.txt','measurement-results.json','measurement-report.md','compile-delivery.py']:
    add(ROOT/name,name,'driver-and-report')

# Do not expose matched values; this is a limited heuristic scan, not a secrecy guarantee.
patterns={
    'github-token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
    'openai-key':rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{30,}\b',
    'aws-access-key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'slack-token':rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b',
    'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    'credentialed-url':rb'https?://[^\s/\"<>:]+:[^\s/\"<>]+@',
}
environment_secrets={k:v.encode() for k,v in os.environ.items() if re.search(r'TOKEN|SECRET|PASSWORD|API_KEY|ACCESS_KEY',k,re.I) and len(v)>=12}
findings=[]
for entry in entries:
    data=pathlib.Path(entry['source']).read_bytes()
    for label,pattern in patterns.items():
        count=len(re.findall(pattern,data))
        if count: findings.append({'bundlePath':entry['bundlePath'],'kind':label,'count':count})
    for key,value in environment_secrets.items():
        if value in data: findings.append({'bundlePath':entry['bundlePath'],'kind':'exact-runtime-secret-value','environmentKey':key})
privacy={'status':'no-heuristic-matches' if not findings else 'review-required',
    'scannedFiles':len(entries),'findings':findings,
    'limits':'Known credential-pattern and exact secret-named current environment-value scan only. No guarantee of absence. Raw logs/config include technical absolute paths and selected environment hashes; declared NODE_PATH/NODE_OPTIONS values are empty. Private TMPDIR contents and bytecode excluded.'}
write(ROOT/'privacy-scan.json',privacy)
add(ROOT/'privacy-scan.json','privacy-scan.json','privacy-audit')
write(ROOT/'benchmark-artifacts.json', {'kind':'immutable-benchmark-artifact-inventory','measuredSource':results['measuredSource'],
    'excluded':['All private tmp directories','All __pycache__ directories','Writer-owned implementation artifacts are packaged separately'],
    'duplicateManifestPolicy':'Byte-identical superseded dependency manifests use final bundle copies; original paths are recorded as additionalIdenticalOrigins.',
    'totalBytes':sum(e['bytes'] for e in entries),'entries':entries})
print(json.dumps({'results':results,'privacy':privacy,'artifactCount':len(entries),'artifactBytes':sum(e['bytes'] for e in entries),
    'reportSha256':sha(ROOT/'measurement-report.md'),'manifestSha256':sha(ROOT/'benchmark-artifacts.json')}))
