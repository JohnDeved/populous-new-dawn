Refs #17, #457. Source-bound original bottom strip, c/s/p palette status art, original hand launch, and a coherent fullscreen selector. Existing orbit representation, globe projection/shading, title font/text, focus indicators, enlarged targets, and compatibility controls remain explicitly adapted. Partial presentation slice, not full original selector parity.

Base: `053cda0d35c8d508915cd74c7f07b7ed0ee66792`. Current head: `6c363b1a0ee9df4ea35afb5291e7bfede825e375`. Final runtime/test changes: `3b943abfe0b6ea79031c5b275c2c6475a75b75a4`; subsequent commit adds only retained screenshots and captions.

### Comparable screenshots
Both are untouched fresh-profile Mission 1 selector captures at 640×480 DPR1, sandboxed Chrome Headless Shell 154.0.8037.92. Focus differs: Back before, Mission 1 after. Frontend compositor captures, not original-game screenshots or hardware performance proof.

Before, clean main `053cda0d35c8d508915cd74c7f07b7ed0ee66792`: former scrolling modal.
![Before selector at 640×480](https://raw.githubusercontent.com/JohnDeved/populous-new-dawn/6c363b1a0ee9df4ea35afb5291e7bfede825e375/references/ui-world-selector/before-640x480.png)

After, clean `3b943abfe0b6ea79031c5b275c2c6475a75b75a4`: original 638×61 panel at (1,419), selected palette status glyphs and launch hand in adapted fullscreen layout.
![After selector at 640×480](https://raw.githubusercontent.com/JohnDeved/populous-new-dawn/6c363b1a0ee9df4ea35afb5291e7bfede825e375/references/ui-world-selector/after-640x480.png)

[Both resolutions and detailed captions](https://github.com/JohnDeved/populous-new-dawn/blob/6c363b1a0ee9df4ea35afb5291e7bfede825e375/references/ui-world-selector/README.md).

### Verification
- Passed on clean `3b943abf`: frontend geometry, transparent hover/focus, locked launch, keyboard/pointer selection, repeated Escape/reopen, all 23 direct choices, restored-profile replay/next mission, five viewport widths and DPR2.
- Passed on clean `3b943abf`: actual Mission 1 pointer launch; in-game Select Level through shipped compatibility menu; unchanged paused world identity, turn and level; Back/Escape return to pause menu.
- Source importer reproduction: all 12 frames byte-exact; native static findings and generated-asset provenance retained in `decomp/research/world-selector-panel/`.
- Failure/checkpoint/Tutorial episode is not yet complete. First attempt reached deliberate atlas failure, explicit retry into real Mission 1 and checkpoint save, then failed on stale test navigation. Corrected rerun crashed at initial scene startup. Failures retained; no full pass claimed.
- Passed on clean `6c363b1a`: production build, typecheck, parity:check, orchestration:check, Fallow health and duplicates. Full ESLint/oxlint/format/unused reports remain nonzero; unchanged/error-line attribution is retained. No changed-path Fallow findings; no full baseline Fallow equivalence claim.
- Complete portable test inventory: all 425 distinct `tests/*.test.mjs` files covered in 43 source-bound batches, 2735 tests total. Original result:2734 passed and one unchanged performance-queue timing timeout. Complete affected file then passed20/20 serially without edits. Interrupted aggregate `npm run check` and batch21 attempt1 remain retained; this is complete component coverage, not a clean single aggregate invocation.
- New current-head checkpoint episode: real Mission1 launch and shipped-menu checkpoint save; visible/in-bounds Load Game and Tutorial with no panel overlap at640×480. Clicking Load Game then crashed the renderer during canvas rebind. Separate Tutorial startup likewise crashed. Completion remains explicitly unverified; no repeated unchanged renderer retries.
- Source-bound receipts: `work/orchestration/selector457/recovery-*-3.json`, `inventory-batch-*.json` (use21-2, retain interrupted21-1), and `performance-queue-rerun-1.json`. Exact425-file manifest, hashes and reconciliation retained; prior CLI launch failures and interrupted runs are not passes.
- Fresh independent review pending. Root owns merge.

No original executable execution, natural-victory claim, hardware-performance claim, or full #17 closure. Raw local browser receipts: `/tmp/selector457/frontend2/receipt.json`, `/tmp/selector457/lifecycle1/receipt.json`, and retained failures1/failures2.
