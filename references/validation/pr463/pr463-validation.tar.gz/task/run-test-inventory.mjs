import {readFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {runCommandReceipt} from '/tmp/populous-raid447-fallback-0229/scripts/orchestration/command-receipt.mjs'
const root='/tmp/populous-raid447-fallback-0229', manifest='/tmp/selector457/full-test-inventory.json'
const data=JSON.parse(readFileSync(manifest,'utf8'))
if(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()!==data.head)throw Error('HEAD changed')
if(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim())throw Error('Dirty source')
const actual=execFileSync('git',['ls-files','tests/*.test.mjs'],{cwd:root,encoding:'utf8'}).trim().split('\n').sort()
if(JSON.stringify(actual)!==JSON.stringify(Object.keys(data.files)))throw Error('Inventory mismatch')
for(const [file,hash] of Object.entries(data.files))if(createHash('sha256').update(readFileSync(`${root}/${file}`)).digest('hex')!==hash)throw Error(`Input changed ${file}`)
let failed=0
for(const [index,files] of data.batches.entries()) {
 const output=`work/orchestration/selector457/inventory-batch-${String(index+1).padStart(2,'0')}-1.json`
 if(existsSync(`${root}/${output}`)) {const old=JSON.parse(readFileSync(`${root}/${output}`));if(old.status==='passed'&&old.source.headOid===data.head){console.log(`Retained passed batch ${index+1}`);continue}throw Error(`Prior nonpassed receipt needs review: ${output}`)}
 const result=runCommandReceipt(root,{output,command:['node','--test','--test-concurrency=1',...files],inputs:[manifest,'/tmp/selector457/run-test-inventory.mjs','/tmp/selector457/git-isolated-bin/git']})
 console.log(`Batch ${index+1}/${data.batches.length}: ${result.status}; ${files.length} files`)
 if(result.status!=='passed')failed++
}
console.log(`Complete inventory: ${actual.length} files; ${data.batches.length} batches; failed batches ${failed}`)
process.exitCode=failed?1:0
