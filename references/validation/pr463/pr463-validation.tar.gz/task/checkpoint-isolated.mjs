import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
export default async function({page,root,output,receipt}) {
 const button=name=>page.getByRole('button',{name,exact:true})
 const {bindGame}=await import(pathToFileURL(resolve(root,'scripts/browser-game.mjs')).href)
 await page.setViewportSize({width:640,height:480})
 await button('New Game').click();await button('Start Mission 1').click();await bindGame(page)
 assert.equal(await page.evaluate(()=>window.testStore.getWorld().outcome.level),1)
 const guard=page.getByRole('button',{name:'Continue anyway',exact:false});if(await guard.isVisible())await guard.click()
 const skip=page.locator('.skip-introduction');await skip.waitFor({state:'visible',timeout:45000}).catch(()=>{})
 if(await skip.isVisible())await skip.click()
 await page.waitForFunction(()=>!window.testStore.getWorld().inputMask)
 await button('Game settings').click();await button('Save Game').click();await button('Save checkpoint').click()
 await page.getByText('Checkpoint saved in this browser.',{exact:true}).waitFor()
 const saved=await page.evaluate(()=>{window.selectorSavedWorld=window.testStore.getWorld();return {level:window.selectorSavedWorld.outcome.level,turn:window.selectorSavedWorld.turn}})
 await page.keyboard.press('Escape');await button('Options').click();await button('Browser compatibility and help').click();await button('Select Level').click()
 const load=button('Load Game');await load.waitFor({state:'visible'})
 const tutorial=button('Tutorial');assert.equal(await tutorial.isVisible(),true)
 const bounds={load:await load.boundingBox(),tutorial:await tutorial.boundingBox(),panel:await page.getByLabel('Campaign status panel',{exact:true}).boundingBox()}
 for(const box of [bounds.load,bounds.tutorial]) {assert.ok(box&&box.x>=0&&box.y>=0&&box.x+box.width<=640.1&&box.y+box.height<=480.1);assert.ok(box.y+box.height<=bounds.panel.y||box.y>=bounds.panel.y+bounds.panel.height)}
 await page.screenshot({path:resolve(output,'selector-checkpoint-640x480.png')})
 await load.click();await bindGame(page)
 const restored=await page.evaluate(()=>({level:window.testStore.getWorld().outcome.level,turn:window.testStore.getWorld().turn,replaced:window.testStore.getWorld()!==window.selectorSavedWorld}))
 assert.equal(restored.level,saved.level);assert.ok(restored.turn>=saved.turn);assert.equal(restored.replaced,true)
 assert.deepEqual(receipt.errors,[])
 return {saved,restored,bounds,checks:['real Mission 1 saved through shipped menu','Load Game and Tutorial visible without panel overlap at 640x480','selector Load Game restores real checkpoint into new world'],limits:['Headless software renderer; not hardware performance or natural outcome proof']}
}
