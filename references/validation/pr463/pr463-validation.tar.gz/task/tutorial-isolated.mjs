import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
export default async function({page,root,output,receipt}) {
 const button=name=>page.getByRole('button',{name,exact:true})
 const {bindGame}=await import(pathToFileURL(resolve(root,'scripts/browser-game.mjs')).href)
 await page.setViewportSize({width:640,height:480});await button('New Game').click()
 const tutorial=button('Tutorial');await tutorial.waitFor({state:'visible'})
 const bounds=await tutorial.boundingBox();assert.ok(bounds&&bounds.x>=0&&bounds.y>=0&&bounds.x+bounds.width<=640.1&&bounds.y+bounds.height<=480.1)
 await page.screenshot({path:resolve(output,'selector-tutorial-640x480.png')})
 await tutorial.click();await bindGame(page)
 const level=await page.evaluate(()=>window.testStore.getWorld().outcome.level)
 assert.equal(level,79);assert.deepEqual(receipt.errors,[])
 return {level,bounds,checks:['visible Tutorial action at 640x480','shipped Tutorial launches real level 79'],limits:['Headless software renderer; not Tutorial completion or hardware performance proof']}
}
