/* Ghidra 12.1.3 pseudocode; entry 0042c8f0; FUN_0042c8f0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0042c8f0(void)

{
  int iVar1;
  undefined4 *puVar2;

  DAT_0089c6e1 = 0xffff;
  DAT_008922e8 = 0;
  DAT_008922d8 = 0;
  DAT_0089ce43 = 0;
  DAT_0089d160 = 0;
  DAT_0089bb67 = 0;
  DAT_0089ce60 = 0;
  _DAT_008922e4 = 0;
  DAT_0089d165 = 0xff;
  DAT_0089d166 = 0;
  DAT_0089c669 = DAT_0089c669 & 0xfeffffff;
  FUN_00480e70();
  FUN_004a9c40();
  FUN_004f0de0();
  DAT_0096aa74 = &DAT_0096aaba;
  DAT_0089c669 = DAT_0089c669 & 0xbfffffff;
  FUN_00422fa0();
  DAT_0089ce34 = 0;
  DAT_0089c669 = DAT_0089c669 & 0xffffffdf;
  _DAT_0089c66d = _DAT_0089c66d & 0xfffffdf7;
  DAT_0089c661 = DAT_0089c661 & 0xffefffff;
  DAT_00895da4 = DAT_00895da4 & 0xfdafffff;
  _DAT_0089bc22 = 0;
  _DAT_0089bc26 = 0;
  puVar2 = &DAT_00899ed3;
  for (iVar1 = 0x2e; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  DAT_0089b739 = DAT_0089b739 & 0xfb7fffff;
  DAT_00895da8 = DAT_00895da8 & 0xfeffffff;
  FUN_004a5d20(0,0);
  FUN_004a5eb0();
  FUN_004a5ee0();
  return;
}
