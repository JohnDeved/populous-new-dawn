/* Ghidra 12.1.3 pseudocode; entry 004eef50; FUN_004eef50.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004eef50(void)

{
  int iVar1;
  uint uVar2;
  uint uVar3;

  uVar3 = DAT_00890378;
  if (DAT_00890378 < DAT_00890384) {
    do {
      *(undefined1 *)(uVar3 + 0x2a) = 0;
      uVar2 = uVar3 + 0xb3;
      *(uint *)(uVar3 + 0xc) = *(uint *)(uVar3 + 0xc) & 0xfffffffe;
      uVar3 = uVar2;
    } while (uVar2 < DAT_00890384);
  }
  for (uVar3 = 0; (int)uVar3 < 0x10000; uVar3 = uVar3 + 1) {
    uVar2 = (uVar3 & 0xfe) * 2 | uVar3 & 0xfe00;
    iVar1 = uVar2 * 4;
    (&DAT_008a03f2)[iVar1] = (&DAT_008a03f2)[iVar1] & 0xf0;
    (&DAT_008a03ea)[uVar2 * 2] = 0;
    (&DAT_008a03ec)[uVar2 * 2] = (&DAT_008a03ec)[uVar2 * 2] & 0xfc00;
    (&DAT_008a03ec)[uVar2 * 2] = 0;
    (&DAT_008a03ef)[iVar1] = 0;
    (&DAT_008a03f3)[iVar1] = (&DAT_008a03f3)[iVar1] & 0xf0;
    (&DAT_008a03e4)[uVar2] = (&DAT_008a03e4)[uVar2] & 0xfbfec063;
  }
  FUN_004ee300();
  return;
}
