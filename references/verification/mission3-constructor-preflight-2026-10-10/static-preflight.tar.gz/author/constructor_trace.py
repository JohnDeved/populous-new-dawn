#!/usr/bin/env python3
"""Static-only Mission 3 constructor preflight and exact raw-record inventory.
No Unicorn import, native_cpu call, executable launch, or original instruction
execution. The separate disabled draft is not approved for any native run.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, struct, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
GAME = Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game')
EXE = GAME / 'd3dpoptb.exe'
EXPECTED_EXE = '3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
EXPECTED_HEAD = '76701bda3d02f9fa12684b2e8175ec3809034465'
READER = ROOT / 'scripts/check-static-mission18-sky.py'
EXPECTED_READER = '74dd55ab6d811f0f0d870c94eb404d2c06915bf96232b6dc39c25f19ceee6da2'
BASE, END, SCRATCH, SCRATCH_END = 0x400000, 0xd4e000, 0x2000000, 0x2400000
RECORD, OBJECTS, SHAPES = 0x2000000, 0x2020000, 0x2030000
FACES, POINTS, ANIMATION = 0x2040000, 0x2100000, 0x2140000
STACK, STOP = 0x23ed000, 0x23ee000
HEADER, TERRAIN, POOL, SEEDS = 0x89b741, 0x8a03e4, 0x8e0428, 0x96eac1
INPUT_NAMES = ['levels/levl2003.dat', 'levels/levl2003.hdr', 'levels/levl2003.ver',
               'levels/constant.dat', 'objects/objs0-6.dat', 'objects/objs0-6.ver',
               'objects/pnts0-6.dat', 'objects/facs0-6.dat', 'objects/aniob0-6.dat',
               'objects/morph0-6.dat', 'objects/shapes.dat', 'objects/shapes.ver',
               'data/mwsearch.dat', 'data/vstart-0.ani', 'data/vfra-0.ani']
WINDOWS = [(0x42c7a6,0x42c7b5),(0x42bfa0,0x42c12c),(0x484edc,0x485038),
           (0x485050,0x485122),(0x484a56,0x484a62),(0x40c7d8,0x40c818),
           (0x42b27f,0x42b281),(0x484da9,0x484dc8),(0x484e09,0x484e3a),
           (0x484c9a,0x484cd4)]
EXPLORATORY_LIMITS = [
    'No exact Mission 3 campaign-entry or first-conversion-wave claim.',
    'File-backed PE globals are explicitly conditional image-initial values, not proof of their campaign-entry value.',
    'Unbound zero-fill data and scratch reads abort; original I/O, imports, interrupts, privileged instructions, PE entry, broader loader, and gameplay are prohibited.',
    'Full original reset is attempted without suppressing palette, renderer, clock, or other dependencies; encountering one blocks dependent stages.',
    'Host input placement replaces file transport only. No original API/I/O calls execute and no return is fabricated.',
    'All 2000 file records and all native nested allocations would be visited only after setup succeeds.',
    'The actual postpass predicate is class 7/model 89, not class 10/model 89.',
]
SOURCES = ['scripts/decomp.py','scripts/check-static-mission18-sky.py','decomp/tools.json',
 'app/original-constants.json','decomp/generated/00484a10.c','decomp/generated/0042c790.c',
 'decomp/generated/0042bfa0.c','decomp/generated/0042b230.c','decomp/generated/004ed820.c',
 'decomp/generated/004ed880.c','decomp/generated/004ee300.c','decomp/generated/004ed8a0.c',
 'decomp/generated/004ed580.c','decomp/generated/004ed640.c','decomp/generated/004851e0.c',
 'decomp/generated/004866a0.c','decomp/generated/004edf50.c','decomp/generated/0044ddf0.c',
 'decomp/generated/0044df40.c','decomp/generated/0040c690.c','decomp/generated/0040c920.c',
 'decomp/generated/0040ce30.c','decomp/generated/00418de0.c','decomp/generated/0042c320.c']

def sha(data): return hashlib.sha256(data).hexdigest()
def record_file(path):
    b=path.read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def load_pe():
    if sha(READER.read_bytes()) != EXPECTED_READER: raise ValueError('Static PE reader source drift')
    spec=importlib.util.spec_from_file_location('static_pe',READER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module.PE32(EXE)
def write_json(p,x): p.write_text(json.dumps(x,indent=2)+'\n')
def read_inputs(): return {name:(GAME/name).read_bytes() for name in INPUT_NAMES}

def preflight(out):
    import capstone
    pe=load_pe();inputs=read_inputs();level=inputs['levels/levl2003.dat'];header=inputs['levels/levl2003.hdr']
    assert sha(level)=='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf'
    assert sha(header)=='219dd7611a4e3f6c2d4e78620a4d5bb9cf61bf0e9c66c21b2b43b89c8ba4d3f0'
    assert len(header)==616 and header[88]==3 and header[96:98]==bytes([25,6])
    records=[]
    for i in range(2000):
        b=level[0x14043+i*55:0x14043+(i+1)*55];assert len(b)==55
        records.append({'indexZeroBased':i,'recordNumber':i+1,'fileOffset':0x14043+i*55,
                        'rawHex':b.hex(),'model':b[0],'class':b[1],'ownerSigned':struct.unpack('b',b[2:3])[0],
                        'x':struct.unpack_from('<H',b,3)[0],'y':struct.unpack_from('<H',b,5)[0]})
    assert sum(r['class']!=0 for r in records)==109
    assert sum(r['class']==1 for r in records)==52
    windows=[];cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    for begin,end in WINDOWS:
        b=pe.read(begin,end-begin);ins=list(cs.disasm(b,begin))
        assert sum(i.size for i in ins)==len(b),(hex(begin),'split instruction')
        windows.append({'start':hex(begin),'stopExclusive':hex(end),'sha256':sha(b),
                        'instructions':[{'address':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'op':i.op_str} for i in ins]})
    manifest={'status':'PREPARED_NOT_EXECUTED','claimStatus':'BLOCKED_EXACT_ENTRY_UNPROVED',
       'at':datetime.now(timezone.utc).isoformat(),'preparationBaseHead':EXPECTED_HEAD,
       'observedSourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
       'observedTrackedStatus':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),
       'nativeDriverStatus':'DISABLED_DRAFT_NOT_ACCEPTED_FOR_EXECUTION',
       'driver':record_file(Path(__file__)),'executable':record_file(EXE),
       'sources':[record_file(ROOT/p) for p in SOURCES]+[record_file(HERE.parent/'exports'/f'{a:08x}.c') for a in (0x4eef50,0x42c8f0,0x44ddc0)],
       'inputs':[record_file(GAME/n) for n in INPUT_NAMES],
       'header':{'tribes':header[88],'landscape':header[96],'objectBank':header[97],'flags':header[98],
                 'tribeCountProducer':'0042c7a6..0042c7b5 reads 0089b741+88 to 0096eac0 and0096eabf'},
       'recordCount':2000,'nonemptyRecords':109,'directClass1Records':52,
       'nativeInstructionsExecuted':0,'windows':windows,'imports':{hex(a):n for a,n in pe.imports.items()},
       'limits':EXPLORATORY_LIMITS,
       'stagePlan':['Supply header at0089b741 and original assets in separate mapped fixture memory.',
        'Execute original header tribe-count slice0042c7a6..0042c7b5, then full reset0042bfa0, never bypassing dependency failures.',
        'Original pool pointers004ed820, IDs004ed880, reset004eef50; original misc0042c8f0 and terrain queue0044ddc0.',
        'Original zero terrain REP0042b27f..0042b281, rawLEVL first0x8000 heights, then original0044ddf0(0,64,0) and00422a60(0,64).',
        'Source-bound bank6 relocation0040c920, aniob slice0040c7d8..0040c818, morph0040ce30 and00418de0; animations materialized exactly from VSTART/VFRA linked chains.',
        'Source-bound LEVL terrain mask/tribe fields/sunlight, then every2000raw record through00484edc..00485038 in file order.',
        'Original00485050..00485122 performs trigger links, link clearing,004866a0,004edf50 and conditional class7/model89.',
        'Stop before00485122 texture pass and broader0042b230/gameplay; report any earlier failure and all NOT_RUN phases.'],
       'registerBoundaryPolicy':{'calls':'32-bit cdecl scratch stack with exact arguments and stop return; caller register sentinel0xa5a5a5a5 is explicitly fixture state. DF=0 normal ABI. All register values recorded at every entry; this is not a campaign register snapshot.',
          'headerSlice':'Only absolute header byte read and AL stores; arithmetic flags unused.',
          'terrainRep':'EAX=0,ECX=65536,EDI=008a03e4,DF=0 are values established by0042b25d/25f/24b before0042b27f.',
          'recordSlice':'ESP fixed record frame; ESI=host record+1,EDI=file index+1,EBX=0 from00484ed1; local counts atESP+2c..38 zero-initialized by00484a10 prologue, tribemapESP+40..4c produced by00484a56..62. CMP00484edc establishes flags before branch.',
          'postpass':'ESP unchanged record frame;00485050 call and following instructions establish their own temporary registers.'}}
    write_json(out/'preflight.json',manifest);write_json(out/'raw-records.json',records)
    return pe,inputs,manifest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['prepare'])
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args()
    if a.out.exists():raise ValueError('Output path must be new; no receipts are replaced')
    a.out.mkdir(parents=True)
    _,_,manifest=preflight(a.out)
    print(json.dumps({'status':manifest['status'],'nativeInstructionsExecuted':0,
                     'records':2000,'nonempty':109,'directClass1':52,'tribes':3,'out':str(a.out)}))

if __name__=='__main__':main()
