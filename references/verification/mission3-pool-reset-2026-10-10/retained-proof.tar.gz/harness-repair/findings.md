# Mission 3 initialization harness repair candidate

## Outcome and admission

After fresh review and the parent’s explicit release, the single bounded pool/terrain
diagnostic passed: **1,507,177 original instructions committed** in122.93seconds.
No installer, PE entry, API, clock stub, network, game turn, reset/x87 path, original
allocator, record constructor or postpass was executed. Product files are unchanged.
The candidate source remained frozen at SHA-256
`2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`.

Post-run result: `pool-run01/result.json`; process receipt:
`pool-run01-process-receipt.json`; full trace validation:
`pool-run01-trace-verification.json`. See `post-run-summary.json` for compact
source-bound counts and artifact hashes. Earlier pre-run zero-execution receipts
are intentionally retained as historical preparation/review evidence.

The former full constructor draft remains rejected. This candidate repairs its
unsafe primitive mechanisms and offers a narrower, useful pool/terrain dependency
diagnostic, accepted by a fresh reviewer and separately released by the parent. A reset-only diagnostic
is retained for inspection, but its statically known x87 stop makes running it
uninformative. It should not be released merely to rediscover that stop.

Candidate: `constructor_candidate.py`. Tests: `test_constructor_candidate.py`.
Static dependency evidence: `setup-audit-final.json`, produced by
`prepare_setup_audit.py`. Final command/status/source fingerprints are in
`verification-receipt.json`; earlier unsuccessful test/static receipts are retained.

## Repaired mechanisms

- The real `configure_native_constants` helper is actually invoked through a
  host-only descriptor recorder during preparation and applied through tracked
  supplies in the released pool/terrain diagnostic. It yields 244 balance writes.
- Mapped writable PE bytes and all virtual/scratch zero-fill start unknown. The
  driver never treats image-initial mutable globals as actual campaign values.
- Known-bit masks allow copies and pure AND/OR/TEST operations to preserve unknown
  bits without inventing values. An unknown decisive branch, address, arithmetic
  operand or return address stops. Unknown saved registers remain unknown.
- Register aliases and arithmetic flag masks are tracked for an explicit small
  integer subset. Every unmodeled instruction stops before execution. x87/SIMD and
  OS instructions are not silently allowed. Only DF=0 is a declared C-ABI fixture.
- Pre-write hooks only journal attempts. Memory and register provenance commits
  after instruction completion. An aborted/faulted instruction rolls back bytes
  and registers; no attempted write becomes known. REP iterations commit one at a
  time. Synthetic cross-page faults exercise the actual Unicorn callback behavior.
- Execution is confined to explicitly enumerated .text windows, with other PE
  sections non-executable. There is no CSEG or whole-text permission. Imports,
  source-code writes, unmatched returns and unmodeled memory accesses stop.
- Calls/returns are committed transactionally and include nesting, file origin,
  seed masks and register masks. Unknown snapshot fields have null values. Pool
  chains reject reserved slot0, misalignment, cycles and unbound links. The direct and nested allocation logging mechanisms are
  synthetically tested; the released run executed zero allocations and therefore
  does not prove original constructor/nested-allocation coverage.
- Observed source HEAD, helper, imported constants, complete input hashes and
  driver hash are bound. Approval must match all these identities and a specific
  diagnostic scope plus explicit parent release. The independent reviewer authored the acceptance; this worker copied it to a
  separate release receipt only after the parent explicitly released this exact run. `run-ledger` always rejects before native CPU creation.

## Useful separately gated pool/terrain diagnostic

Scope: original 004ed820 → 004ed880 → 004eef50 (including genuine 004ee300), then
original REP at 0042b27f, stopping at 0042b281. It never executes broader 0042b230.
The two startup producers are source-bound at caller 004a5125/004a512a; they are
explicit prerequisite invocations, not a claim to have replayed all startup.

The diagnostic leaves every prior pool/terrain byte unknown. It supplies fixture
ESP/return/DF and, at the REP boundary only, EAX=0 and ECX=65536 from 0042b25d/25f,
plus conditioned EDI=008a03e4 from 0042b24b. The intervening 00477780 saves/restores
EDI at 0047778c/0047787a; 004eef50 does not otherwise modify it and its 004ee300
callee saves/restores it at 004ee303/004ee463. This is a clearly conditioned caller
boundary, not a fabricated campaign register snapshot or a stubbed call return.

Expected native output, enforced by the candidate rather than just recorded:

- Pool slot0 excluded; active slots1–1999
- Primary low free list: 639..1, count639
- Primary high free list: 1839..640, count1200
- Secondary free list: 1999..1840, count160
- Every prev/next pointer matches that order, every class is0, every ID matches
- Only flags2 mask0x01 must be known-clear; other old object bits remain unknown
- Allocated/deferred heads and four allocation counters are known zero
- All262144 terrain bytes become known zero after the real REP

The static audit retains 46 exact canonical instruction assertions, complete
windows, and a host-only integer proof that the terrain address expression visits
all16384 cells four times. Terrain values never drive its addresses or loop
branches. After masks, 004ee300 accesses disjoint pool/list data; 0042b25d..27f
contains no terrain-dependent read/branch before full zero. The reset-before-zero
order is preserved. A prior claim that this order was defective was corrected;
the original caller genuinely calls 004eef50 at0042b258 before REP0042b27f.

All memory events from the released run streamed to a source-bound JSONL
receipt, avoiding an unbounded in-memory trace. The run remains bounded by explicit
instruction count and180-second per-stage timeout. An inconclusive timeout is a
failure, never a passing initialization result.

## Full constructor remains blocked

- Actual land_flags1 mask0x08 remains prior-history-dependent. The separate mode
  packet binds successful New Game tutorial mask0 and current globe interface10;
  it does not justify seeding land mask0. Two conditioned cases may be useful.
- The former draft omitted the real caller's palette, sunlight, tribe and other
  setup producers. These cannot be silently dropped or replaced by guessed returns.
- Related-record pointer00892443 has a real startup writer0049b65b assigning
  00892447; its lifetime through the selected campaign entry still needs closure.
- Pool and terrain independence can remove false requirements for complete prior
  BSS/pool snapshots. It does not establish every other mutable global or asset.
- Asset initialization must include actual relocation/aniob/morph behavior and
  every consumed VSTART/VFRA/VELE dependency. No count-only or raw-bank shortcut.
- Reset reaches x87 at0042cfd0. Fixed operands do not prove its environment:
  __ftol saves incoming CW, changes only rounding for FISTP, then restores it.
  The preceding FSQRT/FDivR can still depend on precision/exceptions/stack state.
  Actual __control87/__controlfp writers are in the parent control-state packet.
  Bind that state or prove a precise relevant-output independence projection.
- No 2000-record native constructor ledger, class1 seed chronology, first wave,
  browser equivalence, full product check, build, parity credit or merge is claimed.

## Future commands, only after appropriate acceptance and release

Use the existing `work/orchestration/training-native-20261010/native/venv/bin/python`.
`constructor_candidate.py prepare --out <new-directory>` is always static.

`constructor_candidate.py run-pool-diagnostic --out <new-directory> --approval <review-and-parent-release.json>`
requires verdict ACCEPT_POOL_DIAGNOSTIC and scope
pool-terrain-independence-no-constructor-ledger, plus exact driver/source/input
fingerprints and parentReleasedRunLane=true. The driver validates these before
constructing any original native CPU. One released execution of this command
completed successfully; there is no authorization for any additional native run.

## Post-run conclusion and next productive setup boundary

The exact native expectations above all passed. The raw memory trace verifies
that full terrain zero wrote every byte exactly once with known0xff provenance,
and that all1999 active pool classes and mask0x01 flags were produced. Slot0
remains excluded. Native state before the run was deliberately unknown; copying
or masking that prior state never promoted it into complete known provenance.

This closes the bounded pool/list and pre-clear terrain dependency. It does not
prove current campaign pool pointer/ID lifetime, broader setup, actual initial
land mode, class1 seed order, or a single gameplay outcome.

Next minimal productive contract: reuse these accepted pool/reset producers,
then statically close the genuinely consumed mutable tables/globals and complete
bank6/animation producers along the real source-ordered Mission3 setup. Preserve
the two conditioned land-mask alternatives until actual history is bound. The
x87 camera branch needs exact control/status/tag/stack provenance or a reviewed
relevant-output independence proof, with no stubbed return or guessed reset.
No further native execution has been attempted.
