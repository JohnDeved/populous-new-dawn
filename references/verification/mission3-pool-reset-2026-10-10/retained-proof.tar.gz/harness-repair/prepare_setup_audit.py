#!/usr/bin/env python3
"""Canonical-byte static assertions and finite integer projection; no emulation."""
import collections
import argparse
import struct
import capstone
import constructor_candidate as m

parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=m.Path);args=parser.parse_args();out=args.out
if out.exists():raise RuntimeError('Never overwrite receipt')
pe=m.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
windows=[(0x4ed820,0x4ed876),(0x4ed880,0x4ed89a),(0x4eef50,0x4eefd0),(0x4ee300,0x4ee466),
 (0x4ed8a0,0x4edad7),(0x42b230,0x42b281),(0x477780,0x477881),
 (0x4a50f8,0x4a5143),(0x49b640,0x49b661),(0x42cfd0,0x42d03c),(0x55bc54,0x55bc7b)]
rows={};listing=[]
for lo,hi in windows:
 raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo))
 if sum(i.size for i in ins)!=len(raw):raise AssertionError(('split window',hex(lo),hex(hi)))
 item={'start':hex(lo),'stopExclusive':hex(hi),'sha256':m.sha(raw),'instructions':[]}
 for i in ins:
  row={'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str};rows[i.address]=i;item['instructions'].append(row)
 listing.append(item)
checks=[]
def eq(pc,mnemonic,operands):
 i=rows[pc];assert(i.mnemonic,i.op_str)==(mnemonic,operands),(hex(pc),i.mnemonic,i.op_str)
 checks.append({'pc':hex(pc),'mnemonic':mnemonic,'operands':operands,'bytes':i.bytes.hex()})
for pc,mn,op in [
 (0x4ed820,'mov','eax, 0x8e04db'),(0x4ed825,'mov','ecx, 0x937a98'),(0x4ed840,'mov','eax, 0x930ab8'),
 (0x4ed854,'mov','eax, 0x8e0428'),(0x4ed85e,'add','eax, 0xb3'),(0x4ed863,'cmp','ecx, 0x8922d0'),
 (0x4ed86b,'mov','dword ptr [0x890390], 0'),(0x4ed887,'mov','word ptr [eax + 0x24], cx'),
 (0x4ed891,'cmp','ecx, 0x7d0'),(0x4eef60,'mov','byte ptr [eax + 0x2a], cl'),
 (0x4eef68,'and','dword ptr [eax - 0xa7], 0xfffffffe'),(0x4eefc9,'call','0x4ee300'),
 (0x4ee344,'cmp','byte ptr [esi + 0x2a], cl'),(0x4ee349,'test','dword ptr [esi + 0xc], edx'),
 (0x4ee375,'cmp','word ptr [esi + 0x24], di'),(0x4ee41b,'mov','eax, dword ptr [0x89032c]'),
 (0x4ee420,'mov','dword ptr [edx + 4], eax'),(0x4ee423,'mov','dword ptr [edx], ecx'),
 (0x4ee42b,'mov','eax, dword ptr [edx + 4]'),(0x4ed9e7,'mov','ecx, 0x2c'),
 (0x4ed9ee,'rep stosd','dword ptr es:[edi], eax'),(0x4ed9f0,'stosw','word ptr es:[edi], ax'),
 (0x4ed9f2,'stosb','byte ptr es:[edi], al'),(0x42b24b,'mov','edi, 0x8a03e4'),
 (0x42b250,'call','0x477780'),(0x42b258,'call','0x4eef50'),(0x42b25d,'xor','eax, eax'),
 (0x42b25f,'mov','ecx, 0x10000'),(0x42b27f,'rep stosd','dword ptr es:[edi], eax'),
 (0x47778c,'push','edi'),(0x47787a,'pop','edi'),(0x4ee303,'push','edi'),(0x4ee463,'pop','edi'),
 (0x4a5125,'call','0x4ed820'),(0x4a512a,'call','0x4ed880'),(0x4a5134,'call','0x4ee300'),
 (0x4a513e,'call','0x49b640'),(0x49b651,'mov','eax, 0x892447'),(0x49b65b,'mov','dword ptr [0x892443], eax'),
 (0x42cfd0,'fld','qword ptr [0x58f1e8]'),(0x42cfd6,'fsqrt',''),
 (0x55bc5b,'fnstcw','word ptr [ebp - 2]'),(0x55bc63,'or','ah, 0xc'),
 (0x55bc6a,'fldcw','word ptr [ebp - 4]'),(0x55bc6d,'fistp','qword ptr [ebp - 0xc]'),
 (0x55bc70,'fldcw','word ptr [ebp - 2]')]:eq(pc,mn,op)
# Integer address-domain proof of the exact ESI-derived native indexing expression.
terrain=[0x8a03e4+4*(((i&0xfe)*2)|(i&0xfe00)) for i in range(0x10000)]
counts=collections.Counter(terrain)
assert len(counts)==0x4000 and set(counts.values())=={4}
assert sorted(counts)==list(range(0x8a03e4,0x8e03e4,16))
assert 0x8e03e4<0x8e0428
# Mathematical list projection after class=0 and flags2&1=0, not native output.
groups=[('low',1,640),('high',640,1840),('secondary',1840,2000)]
projection={}
for name,lo,hi in groups:
 head=0;links={}
 for index in range(lo,hi):
  ptr=m.POOL+index*179;links[ptr]={'prev':0,'next':head,'index':index}
  if head:links[head]['prev']=ptr
  head=ptr
 chain=[];p=head
 while p:chain.append(links[p]['index']);p=links[p]['next']
 assert chain==list(range(hi-1,lo-1,-1))
 projection[name]={'count':hi-lo,'head':hex(head),'indicesDescending':chain,
   'readsBeforeWrite':'Only previously zeroed head or link just assigned from that head; no prior object prev/next consumed.'}
audit={'status':'STATIC_ONLY_NOT_EXECUTED','originalInstructionsExecuted':0,'source':m.source_identity(),
 'executable':m.file_record(m.EXE),'assertions':checks,'windows':listing,
 'poolIndependence':{'conditionalPrerequisites':['Original004ed820 supplies pointer globals and slot table.','Original004ed880 supplies all2000 IDs.','cdecl stack/DF fixture, not a campaign register capture.'],
  'activeSlots':[1,1999],'reservedSlot0':'Not cleared, not on free lists; no complete2000-slot pool-known claim.',
  'primarySlots':[1,1839],'secondarySlots':[1840,1999],'projection':projection,
  'knownFieldsAfterReset':['class byte0x2a =0','flags2+0xc mask0x01 =0','IDword0x24 from004ed880','prev+0 and next+4 constructed from zeroed heads'],
  'unknownFields':'All other prior bytes retain unknown provenance until the genuine allocator writes them.',
  'allocatedObjectClear':'004ed9e7..004ed9f2 writes44dwords+word+byte=179 bytes; it then restores produced ID/links.'},
 'terrainIndependence':{'maskIterations':65536,'uniqueCells':16384,'visitsPerCell':4,
  'rangeStart':'0x8a03e4','rangeStopExclusive':'0x8e03e4','fullZeroBytes':262144,
  'addressDependency':'004eef83..004eef97 uses only loop ESI, masks0xfe/0xfe00 and constant base. No terrain value enters any address or loop condition.',
  'interveningRead':'After terrain masks,004ee300 visits the disjoint pool/list globals only. Return to0042b25d..0042b27f executes register writes and mode-word masks only; no terrain-dependent branch occurs before full zero.',
  'edi':'0042b24b establishes EDI.00477780 saves/restores at0047778c/0047787a.004eef50 does not modify EDI except004ee300, which saves/restores it at004ee303/004ee463. Diagnostic explicitly conditions this caller register boundary.',
  'sourceOrder':'Preserve reset/masks/list rebuild before full terrain zero. No reordered initialization.'},
 'relatedRecordPointer':{'supplier':'Entry0049b640, caller004a513e',
  'write':'0049b65b sets00892443 to00892447','remaining':'Startup producer is bound; its invocation/history before the selected campaign entry and later pointer movement still require closure.'},
 'x87':{'firstUnsupported':'0042cfd0 FLD, followed0042cfd6 FSQRT','fixedData':[
   {'address':hex(a),'rawHex':pe.read(a,8).hex(),'float64':struct.unpack('<d',pe.read(a,8))[0]} for a in [0x58f1e8,0x58f1f8,0x58f200]],
  'ftol':'0055bc54 saves incoming CW, ORs only rounding-control0x0c00 for FISTP, then restores incoming CW. This does not prove the earlier FSQRT/FDivR precision, exceptions, available stack, or resulting state.',
  'nextProof':'Bind actual entry control/status/tag/stack or prove a relevant-state projection independent of all permissible states; no silent camera stub or guessed FPU reset.'},
 'ledgerAdmission':{'status':'REJECTED','remaining':['Campaign land_flags1 mask0x08 remains prior-history-dependent; modeworker owns its two conditional cases.','Entire actual source-ordered setup between outer loader entry and record producer has not been composed.','Palette pointer0087eff8 and caller resets/tribe helpers are missing from rejected draft setup.','Complete bank6/VSTART/VFRA/VELE dependencies are not proved by raw-file placement.','Direct and nested allocator logging is tested synthetically; no original constructor/allocator invocation has run.']}}
m.json_write(out,audit)
print('static audit passed:',len(checks),'canonical assertions; pool groups',[(n,h-l) for n,l,h in groups],'; terrain cells',len(counts))
