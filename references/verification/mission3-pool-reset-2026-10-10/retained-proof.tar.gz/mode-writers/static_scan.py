import importlib.util,json,sys,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_32
ROOT=Path(__file__).resolve().parents[5]
spec=importlib.util.spec_from_file_location('reader',ROOT/'scripts/check-static-mission18-sky.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=m.PE32(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'))
c=Cs(CS_ARCH_X86,CS_MODE_32);c.detail=True
if sys.argv[1]=='scan':
 c.skipdata=True
 targets=[int(x,16) for x in sys.argv[2:]]
 for sec in p.sections:
  if sec['name']!='.text':continue
  for i in c.disasm(p.read(sec['va'],sec['rawSize']),sec['va']):
   if i.id and any(f'0x{a:x}' in i.op_str for a in targets):print(f'{i.address:08x}: {i.bytes.hex():24} {i.mnemonic} {i.op_str}')
else:
 for a in sys.argv[1:]:
  addr,length=[int(x,16) for x in a.split(':')]
  print(f'RANGE {addr:08x}+{length:x} FILE {p.offset(addr,length):x}')
  for i in c.disasm(p.read(addr,length),addr):print(f'{i.address:08x}: {i.bytes.hex():24} {i.mnemonic} {i.op_str}')
