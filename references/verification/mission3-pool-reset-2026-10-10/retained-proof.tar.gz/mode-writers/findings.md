# Mission 3 mode suppliers: finite static branch proof

## Result

The ordinary New Game → globe → selected-Mission3 route has a concrete tutorial-bit clear and a current-interface10 dispatch. It is NOT the startup upper-loader route and NOT the separate menu level-picker route.

`0089c661 & 0x08` is still a genuine prior-history boundary. Neither New Game nor the globe loader directly clears it. The explicit lobby setter and disconnect clearer are recovered. A presumed zero-filled emulator image is not an admissible replacement for that history.

All 52 direct Mission3 class1 records are locally independent of the tutorial bit: only model2 reaches that test, and the six direct model2 records are owner2, while the effect requires owner0. The land-bit alternative changes exactly six direct model/owner requests and their initialization/RNG histories, while preserving the 52 direct request positions. Neither fact proves the complete class1 allocation ledger or class1 counter seed independent of mode.

No original instruction, PE startup, game/API/file/network leaf, or emulator ran. No product path changed.

## Identities and receipts

- Observed source HEAD: ce246c5b86fc6a9f22c11f58439511f08deef037; tracked status clean before and after.
- Canonical EXE: `/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe`, SHA256 `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`.
- Mission3 DAT: `eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf`.
- Language: `e826c478746d666a3ea9ea36cb7804d1d226d5f83084230987b1de293066cf7d`.
- `prove_modes.py` uses the existing SHA-locked static PE32 reader and Capstone5.0.7 only. Current accepted local static receipt is `proof03/evidence.json`: 2,121 assertions,17 decoded windows, zero original instructions.
- Command: `work/orchestration/training-native-20261010/native/venv/bin/python -B work/orchestration/training-native-20261010/mission3-initialization/mode-writers/prove_modes.py --out work/orchestration/training-native-20261010/mission3-initialization/mode-writers/proof03`; exit0, stdout/stderr retained.
- `proof01` preserves a failed complete-window assertion caused by a three-byte-truncated exploratory window at0040f174; no original execution occurred. `proof02` passed before final additional trigger/table assertions. `proof03` is current.
- Parent-owned Ghidra exports and source/tool completion receipts are in `exports/` and `export*-receipt.json`/`export*.log`. No new private project was opened by this worker.
- Earlier `*-windows.txt`, `target-xrefs.txt`, `caller-xrefs.txt`, `mode-direct-refs.txt`, and `static_scan.py` are exploratory indexes. Some exploratory ranges deliberately begin inside instructions and must not be quoted as accepted disassembly. Only the completely decoded proof03 windows and exact byte assertions support this report. The linear .text xref scan is not an exhaustive alias-aware writer proof.

## Actual ordinary route and tutorial-bit supplier

1. Menu0 entry005d9668 is type5, descriptor005d7c70. Its label index309 is the supplied language string **New Game**, and callback005d7c98 is004c3520.
2. 004c3520 tests byte00895daa mask0x40. When set, it calls004c3340 directly at004c3536. Otherwise it opens menu2. Menu2's **No** control (descriptor005d821c,label236) calls004c3340; **Yes** routes to Tutorial004c5a40 instead. The proof does not invent an observed input click or the actual value of the tutorial-question flag.
3. In004c3340, call004c3463→00426b60(0) must succeed (nonzero;004c346b/6d). Failure returns without establishing the following values. The successful path clears gameFlags bit0x01 at004c346f, then clears tutorial/load bit0x04000000 at004c3476 (`AND dword[0089c665],0xfbffffff`). Thus byte0089c668 bit0x04 is concretely zero at this point, independently of its earlier value.
4. 004c348a/8c queues interface10 through00442a60. That helper writes pending byte0088f001 and phase0088f002=5, not current byte0088f000. The frontend phase service calls00442ab0 at00457cf4;00442abe copies the nonzero pending byte into current byte0088f000.
5. Main-loop dispatch004a4739 reads current0088f000. The actual data tables004a4954/004a4938 map value10 to004a4763→00410e20. Its active path calls004110e0 at00410e3e. In004110e0, globe flag005fc9f4 mask0x08 permits the selection branch. Selected entry[+0x28] (52-byte entry at005f13bc,index005f13b0) supplies the numeric level to004858f0 at00411102.
6. Crucially, only AFTER004858f0 returns does0041110a/0c queue interface2. The ordinary selected constructor is therefore invoked under the globe/current10 caller, not under current2 merely because play is about to begin.
7. 004858f0 first clears load mask0x08000000, which preserves tutorial mask0x04000000. Its gameFlags bit0x01 early-return branch must be clear; the successful New Game writer above supplies that condition until changed. It writes selected numeric level to0089c6dd at0048596b. When selected Mission3 differs from special byte0089a315,0048598a clears load mask0x00000200. The HDR loader00485660 runs, then the clear0x200 branch reaches00485e60(profile index) and00485a86→0042b590. A match to0089a315 follows00412960 instead and is outside this selected constructor path.
8. The retained globe loader never directly clears tutorial mask0x04000000. Its supplier is the successful New Game branch, and it remains conditional on no intervening tutorial/snapshot/menu action rewriting it. No whole load flagword should be synthesized from this one known bit.

### Distinct routes that must not be substituted

- 004c46f0→00410d00 is a separate menu level-picker.00410d19 also clears tutorial0x04000000,00410d25 queues2, and00410dc1 calls0042b590. This clear does not occur in the ordinary globe path.
- 004a4f70→0042c790 at004a51a6 is startup initialization. It later explicitly installs interface7 via00442b00. Its upper-loader sequence must not be labeled the actual globe Mission3 entry.

## Interface guards and local independence

- Trigger postprocessing00485cbe compares current0088f000 with3. Only equality skips the potential nested allocation. If raw trigger byte+9 is1, the non3 path calls004ed8a0 with class6/model10/owner0 at00485cde. This is not a person allocation.
- The final postpass checks class7/model89 and interface!=3 at004850ef,004850f9,004850fe; its conversion helper is00478c60. Current10 follows the non3 side.
- Mission3 has no DIRECT raw class7/model89. That alone does not exclude a nested producer.
- The state10 dispatch and queue-after-loader ordering are source-bound. This is a conditional synchronous route proof, not an observed full menu/callback/state capture; transitive helper effects and the remaining entry globals still need the harness's broader audited setup. For a consumer using only equality3, establish that predicate rather than require or invent all other interface states.

## Land bit0x08: real suppliers and genuine history boundary

- Lobby phase setter:0040f16d performs `OR dword[0089c661],8`.
- Disconnect/cleanup00445430 clears it at0044555f: `AND dword[0089c661],0xf7ffff97`. Its mask also clears0x20,0x40 and0x08000000; the following0044556c clears0x80000000. Those are side effects, not permission to insert the cleanup helper solely to force a desired bit.
- The bounded direct-reference scan found no other immediate .text setter of bit0x08. It is a useful candidate classification only: indirect/bulk writes and code outside the scanned .text are not exhaustively closed by that search.
-0089c661,0089c668,and0088f000 lie in the PE .data section's virtual-only tail. They have no corresponding initialized file bytes. A fresh Windows PE load is expected to zero this tail, but no original loader ran and no complete intervening writer proof was recovered. This report does NOT use that expectation as actual campaign-entry evidence.
- Thus the precise fresh-path precondition would be: a genuine fresh zero-initialized original process; no intervening lobby activation/other writer before successful New Game and globe selection; and no later write before constructor consumption. Alternatively, an observed/source-closed prior0044555f cleanup followed by no setter supplies0. Neither precondition is fully established by this finite packet. New Game/globe alone do not prove it.

## The finite two-value constructor fork

Direct raw records contain109 nonempty entries:52 persons,51 scenery,3 class6 records,2 class2 records,and1 class7 record. There are zero class3 entries, so the class3 exclusion at00484f3f/46 drops no direct Mission3 records for either bit value.

For class1,00484fdb exempts model7;00484fed tests landbit8;when set00484ff6/ffa rewrite owner to-1 and model to1. All52 requests still reach the same single direct callsite00485011 in the same file-record order.44 neutral model1 records already have those values. Exactly6 owner2 model2 records change. The2 model7 Shamans are unchanged, subject to the loader's separately bound identity owner map. `proof03/evidence.json` retains both complete52-record direct request alternatives and the six differing record numbers.

The class1 model switch004d23d0 uses table004d2718:
- model1→004d2417, shared setup004d5920, then two additional world-RNG advances at004d2458 and004d24ae;
- model2→004d24e4, shared setup004d5920, then tutorialbit test004d24ed and owner0 guard004d24fa;
- model7→004d25d5, shared setup then Shaman pointer bookkeeping, without that tutorial test.

This establishes tutorial-bit independence for all52 DIRECT persons for both landbit alternatives. It does not cover a nested owner0 Brave.

The shared setup itself consumes RNG, model tables, terrain and state dispatch. Its image default-state bytes at005a7064+model*0x32 are8 for model1 and10 for model2; these are PE defaults, not a substitute for the separate loaded-constants provenance. The two bodies004d23d0 and004d5920 contain no direct allocator call, but004d5920 calls004ed640 and further helpers. Therefore unchanged direct request counts cannot be promoted to unchanged complete allocation order, allocation success, RNG stream, full object state, or class1 counter seed. No original comparison of the two histories was run.

## Minimal admissible next contract

For a CONDITIONED ordinary-globe comparison, explicitly name: successful NewGame004c3340; Tutorial question bypass or No choice; selected numerical level3 from the globe entry; gameFlags bit0x01 clear; selected3 differs from special byte0089a315; current globe state10; and no intervening state/mode rewrite before constructor. Carry tutorialmask0x04000000=0 from004c3476, and interface!=3 from the state10 route, as separate provenance facts.

Do not silently add landbit0=clear. Either close its actual history, or label two separate conditioned landbit fixtures0/8 and compare every nested allocation/counter/RNG result after the remaining setup is independently accepted. Neither alternative fixture is the demonstrated original campaign history. Keep all other flag bits unknown unless separately supplied. A byte/wholeword read audit must distinguish known predicate bits from unbound preserved bits.

Native run, whole-ledger independence, final class1seed, first conversion waves, and full constructor readiness remain NOT_RUN/UNPROVED. Product checks/build/browser are not applicable to this static-only ignored packet. Proposed durable publication: concise mode-supplier note, relevant exact exports and export hashes, plus the static checker/currentproof; do not publish executable bytes or label exploratory scans accepted evidence.
