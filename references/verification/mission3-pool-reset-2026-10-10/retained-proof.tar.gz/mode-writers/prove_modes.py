#!/usr/bin/env python3
"""Static, bounded Mission3 mode-predicate proof. Never executes original code."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,struct,subprocess
from datetime import datetime,timezone
import capstone
sha=lambda b:hashlib.sha256(b).hexdigest()
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
if a.out.exists():raise ValueError('Refuse to replace prior output')
a.out.mkdir()
reader=ROOT/'scripts/check-static-mission18-sky.py'
assert sha(reader.read_bytes())=='74dd55ab6d811f0f0d870c94eb404d2c06915bf96232b6dc39c25f19ceee6da2'
spec=importlib.util.spec_from_file_location('static_reader',reader);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
game=Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game');pe=r.PE32(game/'d3dpoptb.exe')
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
windows=[(0x4c3340,0x4c34eb),(0x4c3520,0x4c353f),(0x442a60,0x442aa6),(0x442ab0,0x442ad2),(0x457cd8,0x457cf9),(0x4a4737,0x4a4776),(0x410e20,0x410e70),(0x4110e0,0x41111b),(0x4858f0,0x485ae3),(0x445430,0x445578),(0x40f136,0x40f174),(0x410d00,0x410df6),(0x484edc,0x485038),(0x4850d2,0x485122),(0x485b00,0x485db8),(0x4d23d0,0x4d2717),(0x4d5920,0x4d5b5c)]
rows={};listing=[];checks=[]
def eq(x,y,label):
 if x!=y:raise ValueError(f'{label}: {x!r} != {y!r}')
 checks.append(label)
for start,end in windows:
 data=pe.read(start,end-start);ins=list(cs.disasm(data,start));eq(sum(i.size for i in ins),len(data),f'complete code window {start:08x}..{end:08x}')
 rr=[dict(address=f'{i.address:08x}',bytes=i.bytes.hex(),size=i.size,mnemonic=i.mnemonic,op=i.op_str) for i in ins]
 rows.update({i.address:z for i,z in zip(ins,rr)})
 rec=dict(start=f'{start:08x}',endExclusive=f'{end:08x}',fileOffset=pe.offset(start,len(data)),sha256=sha(data),instructions=rr);listing.append(rec)
 (a.out/f'{start:08x}.txt').write_text('STATIC ORIGINAL BYTES, NOT EXECUTED\n'+'\n'.join(f"{x['address']}: {x['bytes']:24} {x['mnemonic']} {x['op']}" for x in rr)+'\n')
def ins(va,mn,op):eq((rows[va]['mnemonic'],rows[va]['op']),(mn,op),f'instruction {va:08x}')
# Conditional successful New Game supplier; no input or I/O success invented.
ins(0x4c3520,'test','byte ptr [0x895daa], 0x40');ins(0x4c3527,'jne','0x4c3534');ins(0x4c352b,'call','0x45a3c0');ins(0x4c3536,'call','0x4c3340')
ins(0x4c3463,'call','0x426b60');ins(0x4c346b,'test','eax, eax');ins(0x4c346d,'je','0x4c34ea');ins(0x4c346f,'and','dword ptr [0x89d17c], 0xfffffffe');ins(0x4c3476,'and','dword ptr [0x89c665], 0xfbffffff');ins(0x4c348a,'push','0xa');ins(0x4c348c,'call','0x442a60')
# Queue/current separation and frontend handover.
ins(0x442a91,'mov','byte ptr [0x88f001], cl');ins(0x442a97,'mov','byte ptr [0x88f002], 5');ins(0x457cf4,'call','0x442ab0');ins(0x442ab9,'mov','al, byte ptr [0x88f001]');ins(0x442abe,'mov','byte ptr [0x88f000], al')
ins(0x4a4739,'mov','al, byte ptr [0x88f000]');ins(0x4a473e,'sub','eax, 2');ins(0x4a4748,'mov','cl, byte ptr [eax + 0x4a4954]');ins(0x4a474e,'jmp','dword ptr [ecx*4 + 0x4a4938]');eq(pe.read(0x4a4954+10-2,1)[0],3,'interface10 dispatcher index');eq(pe.u32(0x4a4938+3*4),0x4a4763,'interface10 branch');ins(0x4a4763,'call','0x410e20')
ins(0x410e3e,'call','0x4110e0');ins(0x4110e3,'test','byte ptr [0x5fc9f4], 8');ins(0x4110ea,'je','0x41111b');ins(0x4110fd,'mov','edx, dword ptr [eax + ecx*4 + 0x28]');ins(0x411102,'call','0x4858f0');ins(0x41110a,'push','2');ins(0x41110c,'call','0x442a60')
# Selected globe route, not upper startup loader or menu level-picker.
ins(0x4858f0,'and','dword ptr [0x89c665], 0xf7ffffff');ins(0x4858fd,'test','byte ptr [0x89d17c], 1');ins(0x485907,'je','0x48591a');ins(0x48596b,'mov','word ptr [0x89c6dd], si');ins(0x48598a,'and','dword ptr [0x89c665], 0xfffffdff');ins(0x4859a9,'call','0x485660');ins(0x4859c0,'test','byte ptr [0x89c666], 2');ins(0x4859c7,'je','0x4859d8');ins(0x485a86,'call','0x42b590')
# Concrete land-bit writers and alternate picker clear, explicitly distinct routes.
ins(0x44555f,'and','dword ptr [0x89c661], 0xf7ffff97');ins(0x40f16d,'or','dword ptr [0x89c661], 8');ins(0x410d19,'and','dword ptr [0x89c665], 0xfbffffff');ins(0x410d25,'call','0x442a60');ins(0x410dc1,'call','0x42b590')
# Actual constructor predicates.
ins(0x484f3f,'test','byte ptr [0x89c661], 8');ins(0x484f46,'jne','0x485038');ins(0x484fed,'test','byte ptr [0x89c661], 8');ins(0x484ff6,'mov','byte ptr [esi + 1], 0xff');ins(0x484ffa,'mov','byte ptr [esi - 1], 1');ins(0x485011,'call','0x4ed8a0');ins(0x48502d,'call','0x485b00');ins(0x4850e0,'mov','ebx, 3');ins(0x4850ef,'cmp','eax, 7');ins(0x4850f9,'cmp','eax, 0x59');ins(0x4850fe,'cmp','byte ptr [0x88f000], bl');ins(0x48510c,'call','0x478c60')
ins(0x485cbe,'cmp','byte ptr [0x88f000], 3');ins(0x485cc5,'je','0x485db2');ins(0x485ccb,'cmp','dl, 1');ins(0x485cd8,'push','0');ins(0x485cda,'push','0xa');ins(0x485cdc,'push','6');ins(0x485cde,'call','0x4ed8a0')
# Person selector and bit independence restricted to the direct raw records.
ins(0x4d23f9,'mov','al, byte ptr [esi + 0x2b]');ins(0x4d23ff,'dec','eax');ins(0x4d2410,'jmp','dword ptr [eax*4 + 0x4d2718]');eq(pe.u32(0x4d2718),0x4d2417,'model1 branch');eq(pe.u32(0x4d271c),0x4d24e4,'model2 branch');eq(pe.u32(0x4d2730),0x4d25d5,'model7 branch');ins(0x4d24ed,'test','byte ptr [0x89c668], 4');ins(0x4d24fa,'cmp','byte ptr [esi + 0x2f], 0');ins(0x4d24fe,'jne','0x4d26d1');ins(0x4d2458,'mov','dword ptr [0x89d178], eax');ins(0x4d24ae,'mov','dword ptr [0x89d178], edx');ins(0x4d5b2c,'mov','bl, byte ptr [edx*2 + 0x5a7064]');ins(0x4d5b40,'call','0x4ed640')
for start,end in ((0x4d23d0,0x4d2717),(0x4d5920,0x4d5b5c)):
 eq(any(z['mnemonic']=='call' and z['op']=='0x4ed8a0' for v,z in rows.items() if start<=v<end),False,f'no direct allocator call in {start:08x}; does not prove transitive closure')
# Original data, localized labels, raw records.
data=[]
for va,size in ((0x5d9ca0,4),(0x5d9668,8),(0x5d7c94,8),(0x5d9b18,8),(0x5d8240,8),(0x4a4938,39),(0x4d2718,32),(0x5a7096,1),(0x5a70c8,1)):
 data.append(dict(address=f'{va:08x}',fileOffset=pe.offset(va,size),bytes=pe.read(va,size).hex(),sha256=sha(pe.read(va,size))))
eq(pe.u32(0x5d9668),5,'NewGame type5');eq(pe.u32(0x5d966c),0x5d7c70,'NewGame descriptor');eq(pe.u32(0x5d7c94),309,'NewGame label');eq(pe.u32(0x5d7c98),0x4c3520,'NewGame callback');eq(pe.u32(0x5d9b1c),0x5d821c,'menu2 No descriptor');eq(pe.u32(0x5d8240),236,'No label');eq(pe.u32(0x5d8244),0x4c3340,'No callback')
lang=(game/'language/lang00.dat').read_bytes();eq(sha(lang),'e826c478746d666a3ea9ea36cb7804d1d226d5f83084230987b1de293066cf7d','language identity');ss=lang.decode('utf-16le').split('\0');eq(ss[309],'New Game','localized New Game');eq(ss[236],'No','localized No')
raw=(game/'levels/levl2003.dat').read_bytes();eq(sha(raw),'eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf','Mission3 DAT identity')
records=[]
for k in range(2000):
 b=raw[0x14043+55*k:0x14043+55*(k+1)];eq(len(b),55,f'raw record bytes {k+1}');records.append(dict(recordNumber=k+1,model=b[0],cls=b[1],owner=struct.unpack('b',b[2:3])[0]))
nonempty=[x for x in records if x['cls']];persons=[x for x in records if x['cls']==1]
eq(len(nonempty),109,'nonempty raw records');eq(len(persons),52,'direct person requests');eq(sum(x['cls']==3 for x in records),0,'no raw class3');eq(sum(x['cls']==7 and x['model']==89 for x in records),0,'no raw class7 model89')
eq([(x['model'],x['owner']) for x in persons].count((1,-1)),44,'44 neutral Wildmen');eq([(x['model'],x['owner']) for x in persons].count((2,2)),6,'6 owner2 Braves');eq([(x['model'],x['owner']) for x in persons].count((7,0)),1,'1 owner0 Shaman');eq([(x['model'],x['owner']) for x in persons].count((7,2)),1,'1 owner2 Shaman')
alternatives={}
for mode in (0,8):
 alternatives[str(mode)]=[dict(x,model=(1 if mode and x['model']!=7 else x['model']),owner=(-1 if mode and x['model']!=7 else x['owner'])) for x in persons]
eq([x['recordNumber'] for x in alternatives['0']],[x['recordNumber'] for x in alternatives['8']],'same direct person request file order across mode8')
eq(sum(x!=y for x,y in zip(alternatives['0'],alternatives['8'])),6,'six changed direct model-owner requests')
eq(pe.read(0x5a7064+1*0x32,1)[0],8,'PE default state for model1');eq(pe.read(0x5a7064+2*0x32,1)[0],10,'PE default state for model2')
# These globals inhabit zero-fill tail; this does NOT supply campaign-history values.
zero_tail=[]
for va in (0x89c661,0x89c668,0x88f000):
 sec=next(s for s in pe.sections if s['va']<=va<s['va']+s['virtualSize']);eq(va>=sec['va']+sec['rawSize'],True,f'{va:08x} lies in virtual-only data tail');zero_tail.append(dict(address=f'{va:08x}',section=sec))
report=dict(status='PASS_STATIC_BRANCH_FACTS_NOT_ACTUAL_ENTRY_CAPTURE',at=datetime.now(timezone.utc).isoformat(),sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),exeSha256=sha(pe.data),readerSha256=sha(reader.read_bytes()),scriptSha256=sha(Path(__file__).read_bytes()),capstone=capstone.__version__,nativeInstructionsExecuted=0,checks=checks,windows=listing,data=data,zeroFillLocations=zero_tail,directPersonAlternatives=alternatives,limits=['No original instruction or OS loader/API executed.','Ordinary NewGame success and selection of numerical Mission3 are conditional path preconditions, not observed input/I/O outcomes.','The exact prior landbit8 value is not supplied by NewGame or globe loading; PE virtual-only location alone is not campaign-state provenance.','No complete nested allocation closure or global class1 seed independence claim.','Exploratory xref scans are candidate indexes, not exhaustive alias-aware writer proofs.'])
(a.out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],assertions=len(checks),windows=len(listing),nativeInstructionsExecuted=0)))
