/* Ghidra 12.1.3 pseudocode; entry 004d5920; FUN_004d5920.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004d5920(int param_1)

{
  ushort *puVar1;
  byte bVar2;
  undefined2 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined1 uVar9;
  undefined2 local_a;

  FUN_004ee470(param_1,(undefined4 *)(param_1 + 0x3d));
  uVar6 = DAT_0089d178 * 0x24a1 + 0x24df;
  uVar4 = uVar6 >> 0xd;
  DAT_0089d178 = uVar4 | uVar6 * 0x80000;
  FUN_004ea460(param_1);
  uVar6 = *(uint *)(param_1 + 0xc);
  *(uint *)(param_1 + 0xc) = uVar6 | 0x80;
  *(uint *)(param_1 + 0xc) = uVar6 | 0x1080;
  *(ushort *)(param_1 + 0x57) = (ushort)uVar4 & 0x7ff;
  iVar5 = (uint)*(byte *)(param_1 + 0x2b) * 0x32;
  *(undefined *)(param_1 + 0x30) = (&DAT_005a7066)[iVar5];
  iVar7 = *(int *)(&DAT_005a7070 + iVar5);
  *(undefined2 *)(param_1 + 0x6c) = 0;
  if (((&DAT_005a7090)[iVar5] & 8) != 0) {
    uVar6 = DAT_0089d178 * 0x24a1 + 0x24df;
    DAT_0089d178 = uVar6 >> 0xd | uVar6 * 0x80000;
    iVar7 = DAT_0089d178 % (uint)((int)(iVar7 + (iVar7 >> 0x1f & 3U)) >> 2) +
            ((int)(iVar7 * 3 + (iVar7 * 3 >> 0x1f & 3U)) >> 2);
    if (DAT_0089c6dd == 0xc) {
      iVar7 = iVar7 + -1;
    }
    *(short *)(param_1 + 0x6c) = (short)iVar7;
  }
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x800000;
  *(short *)(param_1 + 0x6e) = (short)iVar7;
  puVar1 = (ushort *)(param_1 + 0x68);
  *(undefined4 *)puVar1 = *(undefined4 *)(param_1 + 0x3d);
  puVar8 = (undefined4 *)0x0;
  if ((*(uint *)(param_1 + 0xc) & 0x400) != 0) {
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffbff;
    DAT_00892443 = DAT_00892443 + -5;
    puVar8 = DAT_00892443;
  }
  if (puVar8 != (undefined4 *)0x0) {
    *puVar1 = (ushort)*puVar8;
    *(short *)(param_1 + 0x6a) = (short)puVar8[1];
    uVar3 = *(undefined2 *)(puVar8 + 2);
    *(undefined2 *)(param_1 + 0x26) = uVar3;
    *(undefined2 *)(param_1 + 0x5d) = uVar3;
  }
  local_a = CONCAT11((char)((ushort)*(undefined2 *)(param_1 + 0x6a) >> 8),(char)(*puVar1 >> 8));
  uVar6 = (local_a & 0xfe) * 2 | local_a & 0xfe00;
  if ((*(byte *)((int)&DAT_008a03e4 + uVar6 * 4 + 1) & 2) != 0) {
    FUN_004044b0((&DAT_00890390)[(ushort)(&DAT_008a03ec)[uVar6 * 2] & 0x3ff],puVar1);
  }
  *puVar1 = (*puVar1 & 0xfe00) + 0x100;
  *(ushort *)(param_1 + 0x6a) = (*(ushort *)(param_1 + 0x6a) & 0xfe00) + 0x100;
  *(undefined4 *)(param_1 + 0x4f) = *(undefined4 *)puVar1;
  FUN_004e9b40(param_1);
  if ((*(byte *)(param_1 + 0xe) & 0x10) != 0) goto LAB_004d5b48;
  *(undefined1 *)(param_1 + 0x7d) = *(undefined1 *)(param_1 + 0x2c);
  if (((byte)DAT_0089d17c & 2) == 0) {
    bVar2 = *(byte *)(param_1 + 0x2b);
LAB_004d5b2c:
    uVar9 = (&DAT_005a7064)[(uint)bVar2 * 0x32];
  }
  else {
    bVar2 = *(byte *)(param_1 + 0x2b);
    if (bVar2 != 7) goto LAB_004d5b2c;
    uVar9 = 0x27;
  }
  FUN_004ed6f0(param_1);
  *(undefined1 *)(param_1 + 0x2c) = uVar9;
  FUN_004ed640(param_1);
LAB_004d5b48:
  if (*(char *)(param_1 + 0x2f) != -1) {
    *(undefined1 *)(param_1 + 0xb0) = 0xff;
  }
  return;
}
