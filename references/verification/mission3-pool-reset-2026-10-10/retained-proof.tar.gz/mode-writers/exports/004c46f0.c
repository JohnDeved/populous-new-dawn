/* Ghidra 12.1.3 pseudocode; entry 004c46f0; FUN_004c46f0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c46f0(void)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char acStack_110 [272];

  if (-1 < DAT_0089c6dd) {
    FUN_00443100(0xc,1);
    DAT_00895da8 = DAT_00895da8 & 0xffffffef;
    func_0x0042cdd0();
    _DAT_0089c665 = _DAT_0089c665 & 0xfbf7ffff;
    FUN_004fffe0(acStack_110,&DAT_005999ec,0);
    uVar2 = 0xffffffff;
    pcVar5 = s__netpkt_rec_005999e0;
    do {
      pcVar7 = pcVar5;
      if (uVar2 == 0) break;
      uVar2 = uVar2 - 1;
      pcVar7 = pcVar5 + 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar7;
    } while (cVar1 != '\0');
    uVar2 = ~uVar2;
    iVar3 = -1;
    pcVar5 = acStack_110;
    do {
      pcVar6 = pcVar5;
      if (iVar3 == 0) break;
      iVar3 = iVar3 + -1;
      pcVar6 = pcVar5 + 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar6;
    } while (cVar1 != '\0');
    pcVar5 = pcVar7 + -uVar2;
    pcVar7 = pcVar6 + -1;
    for (uVar4 = uVar2 >> 2; uVar4 != 0; uVar4 = uVar4 - 1) {
      *(undefined4 *)pcVar7 = *(undefined4 *)pcVar5;
      pcVar5 = pcVar5 + 4;
      pcVar7 = pcVar7 + 4;
    }
    for (uVar2 = uVar2 & 3; uVar2 != 0; uVar2 = uVar2 - 1) {
      *pcVar7 = *pcVar5;
      pcVar5 = pcVar5 + 1;
      pcVar7 = pcVar7 + 1;
    }
    if ((DAT_0089c669 & 0x400000) == 0) {
      if ((DAT_0089c669 & 0x800000) != 0) {
        DAT_008956d3 = FID_conflict___wfopen(acStack_110,&DAT_005984ac);
        if (DAT_008956d3 == (FILE *)0x0) {
          DAT_0089c669 = DAT_0089c669 & 0xff7fffff;
        }
      }
    }
    else {
      DAT_008956d3 = FID_conflict___wfopen(acStack_110,&DAT_005984b0);
      if (DAT_008956d3 == (FILE *)0x0) {
        DAT_0089c669 = DAT_0089c669 & 0xffbfffff;
      }
    }
    FUN_00410d00();
  }
  return;
}
