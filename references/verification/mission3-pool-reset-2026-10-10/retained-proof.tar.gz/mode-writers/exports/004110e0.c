/* Ghidra 12.1.3 pseudocode; entry 004110e0; FUN_004110e0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004110e0(void)

{
  int iVar1;
  char *pcVar2;
  undefined4 *puVar3;
  DWORD DVar4;
  int iVar5;
  uint uVar6;

  if ((DAT_005fc9f4 & 8) != 0) {
    FUN_004858f0(*(undefined4 *)(DAT_005f13bc + 0x28 + DAT_005f13b0 * 0x34));
    FUN_00442a60(2);
    DAT_005fc9f4 = DAT_005fc9f4 & 0xfffffff7;
  }
  iVar1 = _DAT_005fc9f0;
  if ((DAT_005fc9f4 & 2) != 0) {
    FUN_004a3420(DAT_0087eff8);
    FUN_004a3530();
    FUN_0042adc0(DAT_0087eff8,&DAT_0089c6f4);
    iVar5 = 0;
    DAT_005fc9f4 = DAT_005fc9f4 & 0xfffffffd;
    _DAT_005fc9f0 = 0;
    pcVar2 = DAT_0087eff8;
    do {
      if (((*pcVar2 == '\0') && (pcVar2[1] == '\0')) && (iVar1 = iVar5, pcVar2[2] == '\0')) break;
      iVar5 = iVar5 + 1;
      pcVar2 = pcVar2 + 4;
      iVar1 = _DAT_005fc9f0;
    } while (iVar5 < 0x100);
  }
  _DAT_005fc9f0 = iVar1;
  if ((DAT_005fc9f4 & 0x100) == 0) {
    FUN_00526a80(&DAT_005fc9cc,0,0);
    puVar3 = (undefined4 *)FUN_00526dd0();
    DAT_005fc9e0 = *puVar3;
    DAT_005fc9e4 = puVar3[1];
  }
  else {
    FUN_0042cea0();
  }
  DVar4 = GetTickCount();
  uVar6 = DVar4 - _DAT_005fc9f8;
  if (1000 < uVar6) {
    uVar6 = 1000;
  }
  _DAT_005fc9fc = (float)((float10)uVar6 * (float10)_DAT_0058f028);
  _DAT_005fc9f8 = DVar4;
  if ((DAT_005fc9f4 & 0x100) == 0) {
    FUN_0047e530();
  }
  FUN_00412230();
  FUN_004284d0();
  FUN_00455410();
  FUN_00489770();
  FUN_0048a900();
  return;
}
