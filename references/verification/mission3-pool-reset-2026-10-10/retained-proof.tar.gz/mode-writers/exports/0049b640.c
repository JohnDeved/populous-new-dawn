/* Ghidra 12.1.3 pseudocode; entry 0049b640; FUN_0049b640.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b640(void)

{
  DAT_0089243a = 0;
  _DAT_0089243f = &DAT_008926c7;
  _DAT_0089243b = &DAT_00892447;
  DAT_00892443 = &DAT_00892447;
  return;
}
