/* Ghidra 12.1.3 pseudocode; entry 00410d00; FUN_00410d00.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00410d00(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;

  FUN_0042bf20();
  DAT_0089d17c = DAT_0089d17c | 1;
  _DAT_0089c665 = _DAT_0089c665 & 0xfbffffff | 0x10000000;
  FUN_00442a60(2);
  FUN_00485660((int)DAT_0089c6dd);
  DAT_0096eac0 = DAT_0089b799;
  DAT_0096eabf = DAT_0089b799;
  FUN_0042b910();
  FUN_0042b7f0();
  FUN_0043e320();
  FUN_0047ac30();
  if ((_DAT_0089c665 & 0x10000000) == 0) {
    FUN_00486160();
  }
  else {
    uVar1 = FUN_00485df0((int)DAT_0089c6dd);
    FUN_00485e60(uVar1);
    puVar3 = &DAT_0089b741;
    puVar4 = &DAT_0096070a;
    for (iVar2 = 0xe; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar4 = *puVar3;
      puVar3 = puVar3 + 1;
      puVar4 = puVar4 + 1;
    }
    DAT_0089b73f = (undefined1)uVar1;
  }
  DAT_0089c6f0 = 0;
  FUN_0042b590(DAT_0089b7a1,DAT_0089b7a2,DAT_0089b7a3);
  FUN_0042c730(0,0);
  DAT_0089b739 = DAT_0089b739 | 0x100;
  if (DAT_00895db0 != '\0') {
    FUN_0048b3e0();
  }
  FUN_0048b500();
  return;
}
