/* Ghidra 12.1.3 pseudocode; entry 004858f0; FUN_004858f0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Removing unreachable block (ram,0x00485a3e) */
/* WARNING: Removing unreachable block (ram,0x00485a5e) */
/* WARNING: Removing unreachable block (ram,0x00485a63) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004858f0(uint param_1)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  uint uVar4;
  int iVar5;
  byte *pbVar6;

  _DAT_0089c665 = _DAT_0089c665 & 0xf7ffffff;
  if (((byte)DAT_0089d17c & 1) != 0) {
    FUN_00442a60(7);
    return;
  }
  FUN_0049cad0();
  FUN_00480e70();
  if (param_1 == DAT_0089a315) {
    uVar4 = 99;
  }
  else {
    uVar4 = 0;
    pbVar6 = &DAT_0089a059;
    do {
      if (*pbVar6 == param_1) goto LAB_0048596b;
      pbVar6 = pbVar6 + 0x18;
      uVar4 = uVar4 + 1;
    } while (pbVar6 < &DAT_0089a329);
    if (((int)param_1 < 0x1c) || ((uVar4 = param_1, 0x1e < (int)param_1 && (param_1 != 0x4f)))) {
      uVar4 = 0;
    }
  }
LAB_0048596b:
  DAT_0089c6dd = (short)param_1;
  DAT_0089b73f = (undefined1)uVar4;
  if ((int)DAT_0089c6dd == (uint)DAT_0089a315) {
    _DAT_0089c665 = _DAT_0089c665 | 0x200;
  }
  else {
    _DAT_0089c665 = _DAT_0089c665 & 0xfffffdff;
    FUN_004194f0();
  }
  FUN_004270b0(&DAT_0089a3a9,0);
  FUN_00485660(param_1);
  uVar3 = DAT_0089b7a3;
  uVar2 = DAT_0089b7a2;
  uVar1 = DAT_0089b7a1;
  DAT_0096eac0 = DAT_0089b799;
  DAT_0096eabf = DAT_0089b799;
  if ((_DAT_0089c665 & 0x200) == 0) {
    FUN_00485e60(DAT_0089b73f);
    switch(DAT_0089b73f) {
    case 0xf:
    case 0x10:
    case 0x13:
      iVar5 = 0;
      if ((DAT_0089b0d9 & 1) != 0) {
        iVar5 = 3;
      }
      if (iVar5 != 0) {
        DAT_0089b741 = DAT_0089b741 | 0x10000;
      }
      break;
    case 0x11:
    case 0x12:
    case 0x14:
      iVar5 = 0;
      if ((DAT_0089b035 & 1) != 0) {
        iVar5 = 3;
      }
      if (iVar5 != 0) {
        DAT_0089b741 = DAT_0089b741 | 0x2000;
      }
    }
    FUN_0042b590(uVar1,uVar2,uVar3);
  }
  else {
    FUN_00412960(0);
  }
  FUN_0042c6d0(DAT_0089b73f,(_DAT_0089c665 & 0x200) != 0);
  DAT_0089cf12 = 0;
  FUN_0042cd30();
  FUN_00479f00(8,0,0xffffffff);
  FUN_00479f00(10,(short)DAT_0089c6f0,0);
  return;
}
