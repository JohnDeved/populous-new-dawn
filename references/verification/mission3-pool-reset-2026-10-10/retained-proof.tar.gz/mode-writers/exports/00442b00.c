/* Ghidra 12.1.3 pseudocode; entry 00442b00; FUN_00442b00.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00442b00(char param_1,char param_2,char param_3,short param_4)

{
  if (param_1 != '\0') {
    DAT_0088f000 = param_1;
  }
  if (param_2 != '\0') {
    DAT_0088f001 = param_2;
  }
  if (param_3 != '\0') {
    DAT_0088f002 = param_3;
  }
  if (-1 < param_4) {
    DAT_0088f003 = (undefined1)param_4;
  }
  return;
}
