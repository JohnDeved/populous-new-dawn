/* Ghidra 12.1.3 pseudocode; entry 004d23d0; FUN_004d23d0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004d23d0(int param_1)

{
  int *piVar1;
  short *psVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  undefined2 uVar6;
  uint uVar7;
  uint uVar8;
  ushort uVar9;
  int iVar10;

  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x100;
  *(uint *)(param_1 + 0x14) = *(uint *)(param_1 + 0x14) | 0x40100;
  iVar5 = *(char *)(param_1 + 0x2f) * 0xc65;
  switch(*(undefined1 *)(param_1 + 0x2b)) {
  case 1:
    *(undefined1 *)(param_1 + 0x2f) = 0xff;
    FUN_004d5920(param_1);
    uVar7 = DAT_0089d178 * 0x24a1 + 0x24df;
    DAT_0089d178 = uVar7 >> 0xd | uVar7 * 0x80000;
    *(byte *)(param_1 + 0x7b) =
         ((byte)(&DAT_005a7067)[(uint)*(byte *)(param_1 + 0x2b) * 0x32] >> 1) +
         (char)(DAT_0089d178 %
               (uint)((byte)(&DAT_005a7067)[(uint)*(byte *)(param_1 + 0x2b) * 0x32] >> 1));
    bVar3 = (&DAT_005a7068)[(uint)*(byte *)(param_1 + 0x2b) * 0x32];
    uVar7 = DAT_0089d178 * 0x24a1 + 0x24df;
    DAT_0089d178 = uVar7 >> 0xd | uVar7 * 0x80000;
    uVar7 = DAT_0089d178 % (uint)(bVar3 >> 1);
    *(undefined2 *)(param_1 + 0x87) = 0;
    *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xff7fffff;
    *(byte *)(param_1 + 0x7c) = (bVar3 >> 1) + (char)uVar7;
    break;
  case 2:
    FUN_004d5920(param_1);
    if (((DAT_0089c668 & 4) != 0) && (*(char *)(param_1 + 0x2f) == '\0')) {
      iVar10 = *(int *)(&DAT_005a7070 + (uint)*(byte *)(param_1 + 0x2b) * 0x32) * 2;
      if (((&DAT_005a7090)[(uint)*(byte *)(param_1 + 0x2b) * 0x32] & 8) != 0) {
        uVar7 = DAT_0089d178 * 0x24a1 + 0x24df;
        DAT_0089d178 = uVar7 >> 0xd | uVar7 * 0x80000;
        iVar4 = *(int *)(&DAT_005a7070 + (uint)*(byte *)(param_1 + 0x2b) * 0x32) * 6;
        iVar10 = DAT_0089d178 % (uint)((int)(iVar10 + (iVar10 >> 0x1f & 3U)) >> 2) +
                 ((int)(iVar4 + (iVar4 >> 0x1f & 3U)) >> 2);
        *(short *)(param_1 + 0x6c) = (short)iVar10;
      }
      *(short *)(param_1 + 0x6e) = (short)iVar10;
    }
    break;
  case 3:
    FUN_004d5920(param_1);
    break;
  case 4:
    FUN_004d5920(param_1);
    break;
  case 5:
    FUN_004d5920(param_1);
    *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x20;
    *(char *)(param_1 + 0xb2) = *(char *)(param_1 + 0x2f) << 6;
    break;
  case 6:
    FUN_004d5920(param_1);
    break;
  case 7:
    FUN_004d5920(param_1);
    *(int *)((int)&DAT_0089da65 + *(char *)(param_1 + 0x2f) * 0xc65) = param_1;
    break;
  case 8:
    FUN_004d5920(param_1);
    FUN_0048a050(param_1,0xd8,0);
    uVar7 = *(uint *)(param_1 + 0xc);
    *(uint *)(param_1 + 0xc) = uVar7 | 0x40000;
    *(uint *)(param_1 + 0xc) = uVar7 | 0x44000;
    uVar7 = *(uint *)(param_1 + 0x10);
    *(uint *)(param_1 + 0x10) = uVar7 | 0x80;
    *(uint *)(param_1 + 0x10) = uVar7 & 0xff7fffff | 0x80;
    uVar8 = DAT_0089d178 * 0x24a1 + 0x24df;
    uVar7 = uVar8 >> 0xd;
    DAT_0089d178 = uVar7 | uVar8 * 0x80000;
    uVar9 = (ushort)uVar7 & 0x7ff;
    if ((*(uint *)(param_1 + 0xc) & 0x80) != 0) {
      *(ushort *)(param_1 + 0x57) = uVar9;
    }
    *(ushort *)(param_1 + 0x5d) = uVar9;
    if ((*(uint *)(param_1 + 0xc) & 0x8000) != 0) {
      uVar9 = uVar9 + 0x400 & 0x7ff;
    }
    *(ushort *)(param_1 + 0x26) = uVar9;
    FUN_004ee700(param_1 + 0x33,0,0);
    uVar9 = *(ushort *)(param_1 + 0x35);
    uVar7 = *(uint *)(param_1 + 0xc);
    uVar8 = uVar9 | 0x100;
    *(short *)(param_1 + 0x35) = (short)uVar8;
    *(uint *)(param_1 + 0xc) = uVar7 | 0x10000000;
    *(ushort *)(param_1 + 0x35) = (ushort)CONCAT31((int3)(uVar8 >> 8),(char)uVar9) | 0x10;
    *(undefined1 *)(param_1 + 0x2d) = 0;
    *(uint *)(param_1 + 0xc) = uVar7 | 0x50000000;
  }
  if ((*(char *)(param_1 + 0x2b) != '\x01') && (*(char *)(param_1 + 0x2b) != '\b')) {
    piVar1 = (int *)((int)&DAT_0089dae5 + iVar5);
    *piVar1 = *piVar1 + 1;
    psVar2 = (short *)((int)&DAT_0089dbef + (uint)*(byte *)(param_1 + 0x2b) * 2 + iVar5);
    *psVar2 = *psVar2 + 1;
  }
  uVar6 = FUN_0044e940(*(undefined2 *)(param_1 + 0x3d),*(undefined2 *)(param_1 + 0x3f));
  *(undefined2 *)(param_1 + 0x41) = uVar6;
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffbff;
  return;
}
