/* Ghidra 12.1.3 pseudocode; entry 004c3340; FUN_004c3340.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3340(void)

{
  int iVar1;
  char *pcVar2;
  undefined4 uVar3;

  DAT_0089c6f0 = 0;
  switch(DAT_0089bc6a) {
  case 1:
    uVar3 = 3;
    pcVar2 = s_FMV_p3intro1_tgq_005d46bc;
    break;
  case 2:
    uVar3 = 2;
    pcVar2 = s_FMV_p3intro1_tgq_005d46bc;
    break;
  case 3:
    uVar3 = 0;
    pcVar2 = s_FMV_p3intro3_tgq_005d46e4;
    break;
  case 4:
    uVar3 = 4;
    pcVar2 = s_FMV_p3intro2_tgq_005d46d0;
    break;
  case 5:
    uVar3 = 3;
    pcVar2 = s_FMV_p3intro2_tgq_005d46d0;
    break;
  case 6:
    uVar3 = 4;
    pcVar2 = s_FMV_p3intro1_tgq_005d46bc;
    break;
  case 7:
    uVar3 = 2;
    pcVar2 = s_FMV_p3intro2_tgq_005d46d0;
    break;
  case 8:
    uVar3 = 0;
    pcVar2 = s_FMV_p3intro2_tgq_005d46d0;
    break;
  case 9:
    uVar3 = 0;
    pcVar2 = s_FMV_p3introc_tgq_005d470c;
    break;
  default:
    uVar3 = 0;
    pcVar2 = s_FMV_p3intro1_tgq_005d46bc;
    break;
  case 0xb:
    uVar3 = 0;
    pcVar2 = s_FMV_p3introj_tgq_005d46f8;
  }
  FUN_0049cc80(pcVar2,1,0,uVar3,DAT_00895db5);
  _DAT_0089c665 = _DAT_0089c665 & 0xfff7ffff;
  FUN_0042bf20();
  iVar1 = FUN_00426b60(0);
  if (iVar1 != 0) {
    DAT_0089d17c = DAT_0089d17c & 0xfffffffe;
    _DAT_0089c665 = _DAT_0089c665 & 0xfbffffff;
    DAT_005fc9f4 = 1;
    FUN_00442a60(10);
    DAT_0096eac0 = DAT_0089c650;
    DAT_0096eabf = DAT_0089c650;
    FUN_0042b910();
    FUN_0042b7f0();
    FUN_0043e320();
    FUN_0047ac30();
    DAT_0089a409._0_1_ = (byte)DAT_0089a409 | 4;
    DAT_00749c78 = 1;
    if (DAT_0089ce33 != '\0') {
      FUN_004fca00(DAT_0059df10 + DAT_0089ce33 * 8,0,0);
    }
  }
  return;
}
