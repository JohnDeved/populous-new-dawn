/* Ghidra 12.1.3 pseudocode; entry 0042b7f0; FUN_0042b7f0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0042b7f0(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined *puVar4;
  undefined4 *puVar5;

  DAT_0089798d = 0;
  DAT_00897991 = 0;
  DAT_00897995 = 0;
  _DAT_008926c7 = 0;
  _DAT_008926cb = 0;
  puVar2 = (undefined4 *)&DAT_0089d1c8;
  do {
    *(undefined1 *)(puVar2 + 0x308) = 0;
    puVar3 = (undefined4 *)((int)puVar2 + 0xc65);
    *(undefined4 *)((int)puVar2 + 0x949) = 0;
    *(undefined4 *)((int)puVar2 + 0x91d) = 0;
    *(undefined4 *)((int)puVar2 + 0x925) = 0;
    *(undefined4 *)((int)puVar2 + 0x885) = 0;
    *(undefined4 *)((int)puVar2 + 0x881) = 0;
    *(undefined4 *)((int)puVar2 + 0x945) = 0;
    *(undefined4 *)((int)puVar2 + 0x94d) = 0;
    *(undefined4 *)((int)puVar2 + 0xa27) = 0;
    *(undefined4 *)((int)puVar2 + 0xa2b) = 0;
    *(undefined4 *)((int)puVar2 + 0xa2f) = 0;
    *(undefined4 *)((int)puVar2 + 0xa33) = 0;
    *(undefined2 *)((int)puVar2 + 0xa37) = 0;
    *(undefined4 *)((int)puVar2 + 0xa39) = 0;
    *(undefined4 *)((int)puVar2 + 0xa3d) = 0;
    *(undefined4 *)((int)puVar2 + 0xa41) = 0;
    *(undefined4 *)((int)puVar2 + 0xa45) = 0;
    *(undefined2 *)((int)puVar2 + 0xa49) = 0;
    puVar5 = (undefined4 *)((int)puVar2 + 0xa4b);
    for (iVar1 = 0x16; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
    *(undefined2 *)puVar5 = 0;
    puVar5 = (undefined4 *)((int)puVar2 + 0xaa5);
    for (iVar1 = 0x1b; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
    puVar5 = (undefined4 *)((int)puVar2 + 0xb11);
    for (iVar1 = 0x1b; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
    puVar5 = (undefined4 *)((int)puVar2 + 0xb7d);
    for (iVar1 = 10; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
    *(undefined4 *)((int)puVar2 + 0xba5) = 0;
    *(undefined4 *)((int)puVar2 + 0xba9) = 0;
    *(undefined2 *)((int)puVar2 + 0xbad) = 0;
    puVar2 = (undefined4 *)((int)puVar2 + 0xbaf);
    for (iVar1 = 10; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar2 = 0;
      puVar2 = puVar2 + 1;
    }
    puVar2 = puVar3;
  } while (puVar3 < &DAT_008a035c);
  iVar1 = 0;
  if (DAT_0096eac0 != 0) {
    puVar4 = &DAT_0089d1c8;
    do {
      FUN_0042b660(iVar1);
      iVar1 = iVar1 + 1;
      FUN_00436ff0(puVar4);
      puVar4 = puVar4 + 0xc65;
    } while (iVar1 < (int)(uint)DAT_0096eac0);
  }
  return;
}
