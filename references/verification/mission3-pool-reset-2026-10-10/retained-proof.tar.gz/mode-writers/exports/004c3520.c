/* Ghidra 12.1.3 pseudocode; entry 004c3520; FUN_004c3520.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004c3520(void)

{
  if ((DAT_00895da8._2_1_ & 0x40) == 0) {
    FUN_0045a3c0(2);
    return;
  }
  FUN_004c3340(0);
  return;
}
