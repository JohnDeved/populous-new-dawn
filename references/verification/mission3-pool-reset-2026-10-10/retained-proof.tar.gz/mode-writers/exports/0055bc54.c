/* Ghidra 12.1.3 pseudocode; entry 0055bc54; __ftol.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* Library Function - Single Match
    __ftol

   Library: Visual Studio */

longlong __ftol(void)

{
  float10 in_ST0;

  return (longlong)ROUND(in_ST0);
}
