/* Ghidra 12.1.3 pseudocode; entry 004a4f70; FUN_004a4f70.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_004a4f70(void)

{
  char cVar1;
  HINSTANCE hInstance;
  int iVar2;
  uint uVar3;
  ulong uVar4;
  ulong *puVar5;
  ulong *puVar6;
  undefined4 *puVar7;
  LPCSTR lpTemplateName;
  HWND pHVar8;
  DLGPROC lpDialogFunc;
  LPARAM dwInitParam;
  uint local_5c;
  CHAR local_40 [64];

  dwInitParam = 0;
  lpDialogFunc = (DLGPROC)0x0;
  pHVar8 = (HWND)0x0;
  lpTemplateName = (LPCSTR)0x65;
  hInstance = (HINSTANCE)FUN_0052a6e0();
  pHVar8 = CreateDialogParamA(hInstance,lpTemplateName,pHVar8,lpDialogFunc,dwInitParam);
  if (pHVar8 != (HWND)0x0) {
    FUN_0049a690(local_40,DAT_00972fd8);
    SetWindowTextA(pHVar8,local_40);
    FUN_0049a690(local_40,DAT_009733b4);
    SetDlgItemTextA(pHVar8,0x3e9,local_40);
  }
  CoInitialize((LPVOID)0x0);
  FUN_00499800();
  FUN_0049afe0(7,0,0,0);
  FUN_0049afe0(8,0,0,0);
  FUN_0042a0a0();
  iVar2 = FUN_00493210();
  if (iVar2 != 0) {
    FUN_00454ad0();
  }
  FUN_0042ac70();
  FUN_0049bdf0(s___data_point0_0_dat_005a346e + 2);
  DAT_0059df24 = DAT_0087eff8;
  FUN_0042b1a0();
  FUN_0049afe0(1,0,s___data_point0_0_dat_005a346e + 2,0);
  FUN_0042a140(0);
  FUN_0042a480(0);
  FUN_00429c20();
  FUN_0042bde0();
  FUN_00416db0();
  FUN_00416de0();
  FUN_00417000();
  DAT_0089c6ee = FUN_004171f0(0x280,0x1e0);
  FUN_00417310();
  FUN_004a5310(2);
  FUN_004f15d0(DAT_0089bc6e);
  FUN_004f1820((DAT_0089c661 & 0x8000) == 0);
  FUN_00522420();
  uVar3 = 4;
  if (local_5c != 0) {
    uVar3 = (local_5c & 0xf00) >> 8;
  }
  FUN_00d1b012(5 < uVar3);
  DAT_0096eac0 = DAT_0089c650;
  DAT_0096eabf = DAT_0089c650;
  FUN_0042bfa0();
  FUN_0045db50();
  FUN_004b26c0();
  FUN_0042c130();
  FUN_0042bf20();
  FUN_0042c170();
  FUN_004ed820();
  FUN_004ed880();
  FUN_0042c150();
  FUN_004ee300();
  FUN_00443980();
  FUN_0049b640();
  cVar1 = FUN_0042a570();
  if (cVar1 == '\0') {
    FUN_005009e0(0);
  }
  FUN_004bce20();
  FUN_00402e20();
  FUN_0049a5f0();
  FUN_00422fa0();
  FUN_0040c880();
  FUN_0049c1a0();
  FUN_00429c00();
  FUN_0042bea0();
  FUN_0042b910();
  FUN_0042b7f0();
  FUN_0042c1a0();
  FUN_0042c1c0();
  FUN_0042c210();
  FUN_00429a00();
  FUN_00429ad0();
  FUN_004c24e0();
  FUN_0042c790();
  FUN_00458790();
  FUN_00410fd0();
  if (pHVar8 != (HWND)0x0) {
    DestroyWindow(pHVar8);
  }
  FUN_005002e0();
  FUN_0048b950();
  if (DAT_008956aa == '\0') {
    FUN_00523170();
  }
  FUN_00458b00();
  DAT_0089c6ee = FUN_004171f0((int)DAT_0089c6cf,(int)DAT_0089c6d1);
  FUN_00417310();
  FUN_0042bec0();
  FUN_00429f90();
  FUN_00499660(DAT_0089c6f0);
  FUN_00429ba0();
  FUN_00417310();
  FUN_0042b930();
  FUN_0042b940();
  FUN_0041ce00();
  FUN_005009b0();
  FUN_0044a280();
  FUN_0042c6c0();
  FUN_0047a930(CONCAT22(DAT_0089c6f0 >> 7,DAT_0089c6c1),&DAT_0089d1c8 + DAT_0089c6f0 * 0xc65);
  if (DAT_008956aa == '\0') {
    FUN_00442b00(7,7,1,0);
  }
  else {
    FUN_00442b00(7,7,1,0);
    puVar7 = (undefined4 *)&DAT_00894cfe;
    for (iVar2 = 0x2a; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar7 = 0;
      puVar7 = puVar7 + 1;
    }
    _DAT_00894e26 = 0;
    DAT_008956b7 = 0x1010101;
    FUN_00415fb0();
    puVar5 = &DAT_008956bf;
    do {
      puVar6 = puVar5 + 1;
      uVar4 = MLDPlay::GetCurrentMs(DAT_00599c38);
      *puVar5 = uVar4;
      puVar5 = puVar6;
    } while (puVar6 < &DAT_008956cf);
  }
  DAT_0089d17c = DAT_0089d17c | 1;
  DAT_0089b739 = DAT_0089b739 | 0x100;
  _DAT_0089c665 = _DAT_0089c665 | 0x80000;
  FUN_0041ffd0();
  FUN_00404640();
  return 1;
}
