/* Ghidra 12.1.3 pseudocode; entry 00445430; FUN_00445430.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00445430(int param_1)

{
  int iVar1;

  if ((DAT_0089c669 & 0xc00000) != 0) {
    if (DAT_008956d3 != (FILE *)0x0) {
      _fclose(DAT_008956d3);
      DAT_008956d3 = (FILE *)0x0;
    }
    if (DAT_008956d7 != (FILE *)0x0) {
      _fclose(DAT_008956d7);
    }
    DAT_0089c669 = DAT_0089c669 & 0xff3fffff;
    DAT_008956d7 = (FILE *)0x0;
    DAT_008956d3 = (FILE *)0x0;
  }
  FUN_004154a0();
  if (DAT_008956db != (FILE *)0x0) {
    _fclose(DAT_008956db);
    DAT_008956db = (FILE *)0x0;
  }
  MLDPlay::DestroySession(DAT_00599c38);
  FUN_004130f0();
  FUN_0047aaa0();
  DAT_0089569d = 0;
  if (param_1 == 1) {
    FUN_004996b0(DAT_0089c6f0);
    DAT_0059dee0 = 1;
    DAT_0089d16e = (undefined1)DAT_0089c6dd;
    if (DAT_0088f000 == '\x02') {
      DAT_00749cf0 = DAT_00984590;
    }
    DAT_0088f001 = 7;
    DAT_0088f002 = 5;
    DAT_0088f003 = 0;
    if (DAT_008956aa != '\0') {
      DAT_0089c6f2 = DAT_0089c6f2 | 1;
    }
  }
  else {
    iVar1 = 0;
    if (DAT_0096eac0 != 0) {
      do {
        if (DAT_0089c6f0 != iVar1) {
          FUN_004996b0(iVar1);
        }
        iVar1 = iVar1 + 1;
      } while (iVar1 < (int)(uint)DAT_0096eac0);
    }
  }
  FUN_00486c80(0);
  DAT_0089c661 = DAT_0089c661 & 0x77ffff97;
  return;
}
