# Independent Mission 3 mode-boundary review

## Verdict

ACCEPT static publication of the mode-writers packet bound below. REJECT interpreting it as an observed campaign entry, full constructor readiness, a complete nested class-1 allocation ledger, a counter seed, or original execution evidence.

Reviewed source HEAD: `ce246c5b86fc6a9f22c11f58439511f08deef037`. Initial tracked status was clean. Original executable SHA-256: `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`. This reviewer performed no original-code execution.

Accepted identities:

- `mode-writers/findings.md`: `866d40fb87b8daa00a693dffb94ee7eac7db42a1ce2fc39dd615cf4ea1347994`
- `mode-writers/prove_modes.py`: `74c70c27d814d58a4681d6f947a8c74212aa97c0fc91242ef15e73af24efddf7`
- `mode-writers/proof03/evidence.json`: `8b1974561c43486696ee6f10be9343a6a0aeee032eeae7c77fc10087356566b1`

## Findings and retained limits

1. The successful New Game branch clears tutorial/load mask `0x04000000` at `004c3476`. Failure of its preceding call does not establish the successful branch's state. The ordinary globe route must not be replaced by the distinct menu level-picker or startup route.
2. The state transition helper queues byte `0088f001`; `00442ab0` installs current byte `0088f000`. The main-loop table maps current 10 to the globe path. Globe selection invokes `004858f0` before it queues 2. The proof is conditional on the stated successful path and absence of intervening mode changes; it does not demonstrate an actual UI execution or transitive state capture.
3. Land bit `0089c661 & 8` remains an unresolved history dependency. Its virtual-only PE location does not prove its campaign-entry value. The recovered lobby setter and cleanup clearer must not be silently inserted as fixture state suppliers.
4. Both direct class-1 request alternatives preserve the 52 raw record positions. They differ in six owner-2/model-2 records. This does not establish unchanged transitive allocation, RNG, success, state, or seed. The local tutorial-bit predicate is irrelevant to these direct person requests under the named selector branches; this does not close nested owner-0 persons or downstream helpers.
5. Exploratory text scans are appropriately excluded from accepted disassembly and are not exhaustive alias-aware writer proofs. Only the complete proof03 windows and their exact assertions support publication.

## Independent checks

Ran the reviewed static checker with the existing venv, writing fresh `review-boundary/mode-proof01` output. Exit 0; 2,121 assertions and 17 windows reproduced exactly apart from timestamp. Verified 1,271 retained instruction rows, all 22 manifest artifact hashes, and all 15 exports against retained successful export receipts. Reader and executable hashes are enforced by the static checker. Receipt: `mode-identity01.json`; stdout/stderr: `mode-proof01.stdout` and `mode-proof01.stderr`.

No product edits, native dispatch, full check/build, browser run, publication, commit, merge, or deployment was performed by this reviewer. Product gates are not applicable to this static-only review. Harness execution admission is a separate verdict, pending the frozen candidate and repaired pool/terrain checks.
