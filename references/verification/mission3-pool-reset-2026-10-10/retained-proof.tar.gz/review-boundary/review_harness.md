# Independent frozen harness review

## Verdicts

- Publication: ACCEPT the repaired static/synthetic research packet with its stated limitations. No original execution result exists in this review.
- Execution: ACCEPT only `run-pool-diagnostic`, scope `pool-terrain-independence-no-constructor-ledger`, after separate parent release of the exact bindings in `pool-review-verdict.json`.
- Execution: REJECT reset-only known-stop execution, x87, full constructor, allocator, postpass, broader loader, startup, and gameplay. The full-ledger command still rejects before native CPU creation.

Frozen driver SHA-256: `2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`.
Source HEAD: `ce246c5b86fc6a9f22c11f58439511f08deef037`; tracked status clean.
Canonical executable SHA-256: `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`.
Reviewer original instructions executed: 0.

## Accepted bounded experiment

The exact five allowed windows are `004ed820..004ed876`, `004ed880..004ed89a`, `004eef50..004eefd0`, `004ee300..004ee466`, and `0042b27f..0042b281`, with exclusive ends. The first two initialize pointers/IDs. The third calls the fourth to rebuild lists; the final instruction zeros the terrain. No original allocation occurs.

Admission covers a conditioned prerequisite composition, not a complete startup/campaign replay. All mapped prior pool and terrain bytes begin unknown. Fixture ESP/return slot and DF=0 are explicit. The final REP conditions EAX=0, ECX=65536, and EDI=008a03e4 on their retained caller producers. EDI preservation by 00477780 and 004ee300 is byte-bound. This does not supply any actual campaign mode word, x87 state, or caller register snapshot.

Required observed output is enforced: active slot range1..1999, free-list orders639..1 /1839..640 /1999..1840, counts639/1200/160, exact IDs/classes/prev/next, known-clear flags2 bit0, zero allocation/deferred heads and four counters, and all262144 terrain bytes known-zero. Slot0 remains reserved. Other prior object fields remain unknown. Complete pool-byte initialization is not claimed.

The terrain addressing expression uses loop/register values rather than prior terrain data. Static integer enumeration covers16384 cells four times. The subsequent list builder accesses disjoint pool/list data; the intervening caller register/mode instructions have no terrain-dependent branch before the full overwrite. This closes a useful narrow prior-byte independence question without pretending that all constructor setup is bound.

## Repairs checked

The 244 constant descriptor writes are applied rather than merely hashed. Bit-level provenance keeps preserved flag bits unknown; unknown decisive branches, addresses, arithmetic operands and return addresses fail closed. Attempted writes are journaled and only committed after completed instructions. Fault/abort handling rolls back current uncommitted memory/register effects. REP iteration behavior and actual cross-page callback failures are synthetically tested.

Windows are exact and instruction-bounded; non-.text sections are non-executable; imports, prohibited targets, code writes, interrupts and unmodeled instructions stop. The approved mode does not require broad x86 emulation or implementation of new unsupported instructions. Passing these focused checks is not an acceptance of the mechanism for arbitrary original programs or complete nested allocation tracing.

Two review findings were repaired before the freeze: terrain coverage must now be asserted before success, and preparation records the selected mode, separate scopes, full conditioned register supplies and mode-specific stop. Failure now reports the correct pool-mode status.

## Independent verification

- Existing venv, author suite:25/25 synthetic tests, exit0. `harness-synthetic-final.log`.
- Reviewer synthetic memory fixtures:5/5, exit0. Valid exact lists accepted; unknown ID/counter, wrong predecessor and reserved slot0 rejected. `pool-validation-final.log` and `test_pool_validation.py`.
- Static preparation rerun: exit0, byte-for-byte equivalent JSON to author preflight;244 constant writes,2000 raw record slots,12 input bindings. `preflight-final/` and `preflight-final.log`.
- Verified all46 setup assertions,483 decoded instruction rows in11 complete windows against canonical EXE bytes. Independently enumerated terrain address domain and validated all source/input/log hashes in the final packet.
- Frozen driver/test/audit hashes unchanged across reviewer tests. `frozen-inputs.sha256`; full bindings and results in `pool-review-verdict.json`.
- All22 mode packet manifest artifacts and15 exports separately verified; mode proof rerun passed2,121 assertions. See `review_modes.md`.

The earlier reviewer `pool-validation01.log` failed because its synthetic fixture omitted the newly required flags2 bit0 provenance. The fixture was corrected to supply only that one known bit. The failure is retained; no original code ran. Earlier exploratory static windows in `pool-terrain-static01.txt` are superseded by the complete `pool-terrain-static02` receipt and are not accepted evidence.

No product edits, product check/build, rendered browser verification, native output, parity credit, commit, publication, merge or deployment was performed. Product gates are not applicable to this ignored research review. A changed driver/source/input binding requires re-review before execution release.
