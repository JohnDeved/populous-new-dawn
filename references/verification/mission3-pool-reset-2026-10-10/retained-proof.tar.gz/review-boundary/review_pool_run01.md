# Independent post-run review: pool-run01

## Verdict

ACCEPT the conditioned pool/terrain prerequisite result. No new original execution is authorized by this review. The reviewer only read retained files and streamed the existing trace; no original code was rerun.

Frozen driver: `2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`.
Result: `ea4ff6e02cdb05095d3bbbaff1b9f53d0eacc444a309a21e6ffda7c53db99b2f`.
Trace: `390ee36c09d76cb88c44435fb5e39c2b9bf237410b7eab93797982faa24e352c`.
Detailed independent receipt: `pool-run01-post-review.json`; verifier: `verify_pool_run01.py`; log: `pool-run01-post-review.log`.

## Checked result

The retained process exited0 in122.925seconds. Its approval, source/input bindings, driver-before/after hashes and stdout/stderr hashes match. The original run reports1,507,177 attempted and committed instructions, no blocker/error/abort, exactly one returned call from004eefc9 to004ee300, no open frames, no allocator calls and no object records visited. Final EIP is0042b281.

A single read-only trace pass verified every one of1,445,992 events:277,829 reads and1,168,163 committed byte-writes. Every event PC lies in its admitted phase window. Every recorded read-known mask equals a fresh reconstruction from the244 declared constant supplies, four return-slot supplies and preceding committed trace writes. No undocumented memory supply was needed.

Only allowed partial-read sites occur: mask operations on unknown old flags/terrain, a value-copy MOV, preserved-register POPs, and1,839 TEST reads at004ee349 where precisely the consumed bit0 is known. Preserved unknown bits were not promoted to known values.

Verified all2,000 ID-word writes, exactly1,999 class-clear addresses, and every retained active node's raw ID/class/prev/next bytes and known-bit masks. Free-list orders are639..1,1839..640,1999..1840; counts639/1200/160. All active flags2 bit0 values are known-clear; unrelated model/state/counter/owner fields remain unknown. Reserved slot0 has only its ID initialized, with no free-list membership.

The final phase has exactly262,144 sequential committed known-byte writes at0042b27f, covering008a03e4..008e03e4 without gaps or duplicates. The reviewed driver retains successful full-memory zero and full-known-mask assertions. EAX=0, ECX=0 and EDI=008e03e4 match that REP boundary. The JSONL does not separately retain every written value; zero-value acceptance combines the exact source REP, declared EAX=0, successful final native memory assertion and full trace coverage.

The approval references the initial reviewer verdict before extra artifact hashes were appended. Its exact referenced bytes were reconstructed without changing any approval fields, retained as `pool-review-verdict-released-snapshot.json`, and verified against the approval's referenced SHA-256169a220a90675d57de4b5f34a6d251db0bda7c70c332ad555036a1cbe7f2da54. Core approval bindings did not change.

## Limits and next proof

This is a conditioned prerequisite composition, not an actual startup/campaign replay. It removes the need to invent a complete prior pool/terrain snapshot for these exact outputs. The class1 seed remains entirely unknown. It does not establish actual land-bit history, whole constructor initialization, bank6/animation dependencies, nested allocation order, first conversion waves, browser equivalence or gameplay parity.

Next bounded proof: close the relevant x87 entry/output state at0042cfd0, including FSQRT/FDivR and0055bc54's save/change/restore of control state, before admitting the full reset. Either provide source-closed actual control/status/tag/stack state or prove the specific produced fields and relevant subsequent state independent of every admitted input state. Merely executing the already-known x87 stop adds no evidence. Keep this separate from the remaining source-ordered caller/palette/tribe/asset dependencies and land-bit0/8 conditions; this result alone does not release any constructor run.

No product files changed; tracked status remained clean. Product checks, build, browser verification, parity credit, publication and merge are outside this review.
