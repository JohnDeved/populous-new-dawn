"""Reviewer-owned synthetic memory fixtures only; no original bytes or code executed."""
from pathlib import Path
import importlib.util,struct,unittest,unicorn
P=Path(__file__).resolve().parent.parent/'harness-repair/constructor_candidate.py'
s=importlib.util.spec_from_file_location('candidate',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class PoolValidation(unittest.TestCase):
 def make(self):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(0x890000,0xb0000)
  e=m.Engine(c,[(0x890000,0xb0000)],[(0x100000,0x100001)])
  def w(a,b):e.supply(a,b,'reviewer synthetic memory only')
  for head,lo,hi in [(0x890320,1,640),(0x89031c,640,1840),(0x89032c,1840,2000)]:
   order=list(range(hi-1,lo-1,-1));w(head,struct.pack('<I',m.POOL+order[0]*179))
   for pos,k in enumerate(order):
    a=m.POOL+k*179;prev=0 if pos==0 else m.POOL+order[pos-1]*179;next_=0 if pos==len(order)-1 else m.POOL+order[pos+1]*179
    w(a,struct.pack('<II',prev,next_));w(a+0x24,struct.pack('<H',k));w(a+0x2a,b'\0');w(a+0xc,b'\0'*4);e.shadow.put(a+0xc,4,1)
  for a in [0x890324,0x890328,0x890330,0x89c651,0x89c659,0x89c655,0x89c65d]:w(a,b'\0'*4)
  return e
 def test_exact_three_lists_accept(self):
  r=m.validate_pool(self.make());self.assertEqual([r[k]['count'] for k in ['low','high','secondary']],[639,1200,160])
 def test_unknown_id_rejected(self):
  e=self.make();e.shadow.put(m.POOL+639*179+0x24,2,0)
  with self.assertRaises(m.Blocked):m.validate_pool(e)
 def test_wrong_prev_rejected(self):
  e=self.make();e.supply(m.POOL+639*179,b'\1\0\0\0','synthetic wrong previous')
  with self.assertRaises(m.Blocked):m.validate_pool(e)
 def test_unknown_counter_rejected(self):
  e=self.make();e.shadow.put(0x89c655,4,0)
  with self.assertRaises(m.Blocked):m.validate_pool(e)
 def test_reserved_slot_zero_rejected(self):
  e=self.make();e.supply(0x890320,struct.pack('<I',m.POOL),'synthetic reserved slot')
  with self.assertRaises(m.Blocked):m.validate_pool(e)
if __name__=='__main__':unittest.main(verbosity=2)
