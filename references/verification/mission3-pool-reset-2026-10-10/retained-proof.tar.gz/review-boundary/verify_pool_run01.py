"""Read-only independent validation of retained results/trace. Never emulates code."""
from pathlib import Path
import collections,hashlib,json,struct,subprocess
BASE=Path(__file__).resolve().parent.parent; A=BASE/'harness-repair'; RUN=A/'pool-run01'; OUT=BASE/'review-boundary/pool-run01-post-review.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected_driver='2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f'
assert sha(A/'constructor_candidate.py')==expected_driver
assert sha(RUN/'result.json')=='ea4ff6e02cdb05095d3bbbaff1b9f53d0eacc444a309a21e6ffda7c53db99b2f'
r=json.loads((RUN/'result.json').read_text());p=json.loads((RUN/'preflight.json').read_text());ap=json.loads((A/'pool-run01-approval.json').read_text());process=json.loads((A/'pool-run01-process-receipt.json').read_text())
assert process['status']=='passed' and process['exitCode']==0 and process['sourceStable']
assert process['driverSha256Before']==process['driverSha256After']==expected_driver
assert process['approvalSha256']==sha(A/'pool-run01-approval.json')
for name in ['pool-run01.stdout.log','pool-run01.stderr.log']:assert sha(A/name)==process[name]['sha256']
assert ap['parentReleasedRunLane'] and ap['verdict']=='ACCEPT_POOL_DIAGNOSTIC' and ap['scope']=='pool-terrain-independence-no-constructor-ledger'
assert ap['driverSha256']==expected_driver and p['source']['driver']['sha256']==expected_driver
assert ap['sourceBindingSha256']==hashlib.sha256(json.dumps(p['source'],sort_keys=True).encode()).hexdigest()
assert ap['inputBindingSha256']==hashlib.sha256(json.dumps(p['inputs'],sort_keys=True).encode()).hexdigest()
assert p['selectedMode']==r['mode']=='run-pool-diagnostic'
assert r['status']=='POOL_DIAGNOSTIC_REACHED_STOP' and not r['blocker'] and not r['error']
assert r['attemptedInstructions']==r['committedInstructions']==1507177
for k in ['openCalls','allocations','abortedInstructions','substitutions','fabricatedReturns']:assert r[k]==[]
assert r['recordsVisited']==0
assert len(r['calls'])==1
call=r['calls'][0];assert call['caller']=='0x4eefc9' and call['target']=='0x4ee300' and call['returned'] and call['return']==0x4eefce
assert call['seedBefore']['value'] is None and call['seedAfter']['value'] is None
assert r['before']['class1Seed']['knownMask']==r['after']['class1Seed']['knownMask']=='0x0'
assert r['after']['registers']['eip']['value']=='0x42b281'
assert r['after']['registers']['eax']['value']=='0x0' and r['after']['registers']['ecx']['value']=='0x0' and r['after']['registers']['edi']['value']=='0x8e03e4'
phases=['original pool bounds','original pool IDs','original reset/list rebuild','source-ordered full terrain zero']
assert [s['name'] for s in r['stages']]==phases and all(s['status']=='passed' for s in r['stages'])
assert r['stages'][-1]['terrainAllKnown'] and r['stages'][-1]['terrainAllZero']
windows=[(int(a,16),int(b,16)) for a,b in p['poolAllowedWindows']]
ins={int(i['pc'],16):i for w in p['windows'] for i in w['instructions'] if any(a<=int(i['pc'],16)<b for a,b in windows)}
# Reconstruct every memory-known-mask from declared initial supplies and committed trace writes.
regions=[(0x400000,0xd4e000,bytearray(0xd4e000-0x400000)),(0x2000000,0x2400000,bytearray(0x400000))]
def locate(a,n):
 for lo,hi,b in regions:
  if lo<=a and a+n<=hi:return b,a-lo
 raise AssertionError(('outside admitted memory',hex(a),n))
def put(a,n,k):
 b,i=locate(a,n);b[i:i+n]=k.to_bytes(n,'little')
def get(a,n):
 b,i=locate(a,n);return int.from_bytes(b[i:i+n],'little')
expected_supplies=[]
for c in p['constantWrites']:
 b=bytes.fromhex(c['bytesHex']);a=int(c['address'],16);put(a,len(b),(1<<(8*len(b)))-1);expected_supplies.append((a,len(b),hashlib.sha256(b).hexdigest()))
actual_constants=[(int(s['address'],16),s['size'],s['sha256']) for s in r['suppliedInputs'] if s.get('source','').startswith('configure_native_constants:')]
assert actual_constants==expected_supplies
assert len(actual_constants)==244
other_memory=[s for s in r['suppliedInputs'] if 'address' in s and not s.get('source','').startswith('configure_native_constants:')]
assert len(other_memory)==4 and all(int(s['address'],16)==0x23ed000 and s['size']==4 for s in other_memory)
put(0x23ed000,4,0xffffffff)
registers=[(s['register'],s['value'],s['knownMask']) for s in r['suppliedInputs'] if 'register' in s]
assert registers==[('esp','0x23ed000','0xffffffff'),('eflags','0x2','0x400')]+[('esp','0x23ed000','0xffffffff')]*3+[('eax','0x0','0xffffffff'),('ecx','0x10000','0xffffffff'),('edi','0x8a03e4','0xffffffff')]
counts=collections.Counter();phase_counts=collections.defaultdict(collections.Counter);unknown_reads=collections.Counter();pcs=collections.Counter();phases_seen=[];h=hashlib.sha256();terrain_cursor=0x8a03e4;id_bytes=set();classes=set();lines=0
for raw in (RUN/'memory-events.jsonl').open('rb'):
 h.update(raw);e=json.loads(raw);lines+=1;kind=e['kind'];phase=e['phase'];pc=int(e['pc'],16);a=int(e['address'],16);n=e['size'];k=int(e['knownMask'],16)
 assert phase in phases and pc in ins
 if not phases_seen or phase!=phases_seen[-1]:phases_seen.append(phase)
 pi=phases.index(phase)
 allowed=(windows[:1] if pi==0 else windows[1:2] if pi==1 else windows[2:4] if pi==2 else windows[4:])
 assert any(lo<=pc<hi for lo,hi in allowed),(phase,hex(pc))
 counts[kind]+=1;phase_counts[phase][kind]+=1;pcs[pc]+=1
 if kind=='read':
  assert get(a,n)==k,('read provenance mismatch',lines,e,hex(get(a,n)))
  if k!=(1<<(8*n))-1:unknown_reads[(pc,ins[pc]['mnemonic'],k,n)]+=1
 elif kind=='write':
  assert e['committed'] and n==1 and 0<=k<=255
  put(a,n,k)
  if pc==0x4ed887:id_bytes.add(a)
  if pc==0x4eef60:classes.add(a)
  if phase==phases[-1]:assert pc==0x42b27f and a==terrain_cursor and k==255;terrain_cursor+=1
 else:raise AssertionError(kind)
assert phases_seen==phases
assert counts==collections.Counter(r['memoryEvents']['counts'])=={'read':277829,'write':1168163}
assert h.hexdigest()==r['memoryEvents']['sha256']=='390ee36c09d76cb88c44435fb5e39c2b9bf237410b7eab93797982faa24e352c'
assert terrain_cursor==0x8e03e4 and get(0x8a03e4,0x40000)==(1<<(8*0x40000))-1
POOL=0x8e0428
assert id_bytes=={POOL+179*i+0x24+j for i in range(2000) for j in range(2)}
assert classes=={POOL+179*i+0x2a for i in range(1,2000)}
for name,head,lo,hi in [('low',0x890320,1,640),('high',0x89031c,640,1840),('secondary',0x89032c,1840,2000)]:
 chain=r['freeLists'][name];order=list(range(hi-1,lo-1,-1));assert chain['status']=='complete' and len(chain['order'])==hi-lo
 assert chain['head']['value']==POOL+179*order[0] and chain['head']['knownMask']=='0xffffffff'
 assert r['poolProof'][name]['indexOrder']==order
 for pos,(o,idx) in enumerate(zip(chain['order'],order)):
  a=POOL+idx*179;assert int(o['pointer'],16)==a and o['validPoolSlot'];raw=bytes.fromhex(o['rawHex']);known=bytes.fromhex(o['knownBitsHex'])
  assert known==get(a,179).to_bytes(179,'little')
  prev=0 if pos==0 else POOL+order[pos-1]*179;next_=0 if pos==len(order)-1 else POOL+order[pos+1]*179
  assert struct.unpack_from('<II',raw)==(prev,next_) and struct.unpack_from('<H',raw,0x24)[0]==idx and raw[0x2a]==0
  assert o['id']['value']==idx and o['class']['value']==0 and o['prev']['value']==prev and o['next']['value']==next_
  assert known[0xc]==1 and known[0xd:0x10]==bytes(3) and raw[0xc]&1==0
  for field in ['model','state','counter','ownerRaw']:assert o[field]['value'] is None and o[field]['knownMask']=='0x0'
# Partial reads are confined to pure mask operations, value copies/saved registers, or the known-bit0 TEST.
for (pc,mn,k,n),count in unknown_reads.items():
 assert mn in ['and','mov','test','pop'],(hex(pc),mn,k,n)
 if mn=='test':assert pc==0x4ee349 and k==1 and n==4
assert get(POOL,179)==0xffff<<(8*0x24) # Only the reserved slot's original ID is initialized.
for a in [0x890324,0x890328,0x890330,0x89c651,0x89c659,0x89c655,0x89c65d]:assert get(a,4)==0xffffffff
summary={'verdict':'ACCEPT_CONDITIONED_POOL_TERRAIN_RESULT','reviewerOriginalInstructionsExecuted':0,'driverSha256':expected_driver,'resultSha256':sha(RUN/'result.json'),'traceSha256':h.hexdigest(),'traceEvents':lines,'traceCounts':dict(counts),'phases':{k:dict(v) for k,v in phase_counts.items()},'allReadKnownMasksMatchPriorSuppliesAndCommittedWrites':True,'allTracePCsInsideApprovedPhaseWindows':True,'freeListCounts':[639,1200,160],'activeSlotsVerified':1999,'idSlotsVerified':2000,'terrainKnownZeroBytes':262144,'terrainCoverage':'One complete sequential byte-write span from original REP; final zero assertion retained and EAX=0/ECX=0/EDI=end checked. Trace does not separately retain every written value.','class1Seed':'Still wholly unknown; no seed or constructor claim.','unknownReadSites':[{'pc':hex(pc),'mnemonic':mn,'knownMask':hex(k),'size':n,'events':count} for (pc,mn,k,n),count in sorted(unknown_reads.items())],'limits':['Conditioned prerequisite composition, not actual startup/campaign state capture.','Unknown object fields remain unknown; reserved slot0 only has an ID.','No reset/x87, original allocator, object-record producer/postpass or gameplay run.','No further native run admitted by this review.']}
OUT.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='unknownReadSites'},indent=2))
