from pathlib import Path
import struct,json,hashlib
ROOT=Path(__file__).resolve().parents[5]
EXE=ROOT/'original-game-restoration-20261010/game/d3dpoptb.exe'
b=EXE.read_bytes();pe=struct.unpack_from('<I',b,60)[0];n=struct.unpack_from('<H',b,pe+6)[0];opt=struct.unpack_from('<H',b,pe+20)[0];base=struct.unpack_from('<I',b,pe+52)[0]
def read(a,size):
 for i in range(n):
  va,rs,ro=struct.unpack_from('<III',b,pe+24+opt+i*40+12)
  if va<=a-base and a-base+size<=va+rs:return b[ro+a-base-va:ro+a-base-va+size]
 raise ValueError(hex(a))
out=Path(__file__).resolve().parent;rows=[]
for model in [1,18]:
 a=0x5a7228+model*76;raw=read(a+0x3e,2);rows.append({'model':model,'address':hex(a+0x3e),'rawHex':raw.hex(),'signedWord':int.from_bytes(raw,'little',signed=True),'flagsAddress':hex(a+0x48),'flags':int.from_bytes(read(a+0x48,4),'little')})
targets=[int(r['address'],16) for r in rows];overlap=[];count=0
for index in range(512):
 data=read(0x5aa5f0+index*31,31);name=data[:25].split(b'\0')[0]
 if not name:break
 size,flags=data[25:27];address=struct.unpack_from('<I',data,27)[0];count+=1
 if any(address<t+2 and t<address+size for t in targets):overlap.append({'name':name.decode('ascii'),'size':size,'flags':flags,'address':hex(address)})
verified=0
for line in (out/'callback-facts.tsv').read_text().splitlines():
 fields=line.split('\t')
 if fields[0]=='INS':
  a=int(fields[2],16);raw=bytes.fromhex(fields[3]);assert read(a,len(raw))==raw,(fields[1],fields[2]);verified+=1
j={'mode':'canonical PE data and instruction-byte comparison only; no original instructions executed','exeSha256':hashlib.sha256(b).hexdigest(),'descriptorRows':rows,'constantDescriptorCount':count,'overlappingBalanceTargets':overlap,'verifiedInstructionCount':verified,'factsSha256':hashlib.sha256((out/'callback-facts.tsv').read_bytes()).hexdigest()}
(out/'static-verification.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
