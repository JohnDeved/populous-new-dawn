/* Ghidra 12.1.3 pseudocode; entry 00503230; FUN_00503230.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00503230(void)

{
  int iVar1;

  DAT_0089c65d = 0;
  for (iVar1 = DAT_00890330; iVar1 != 0; iVar1 = *(int *)(iVar1 + 4)) {
    if ((*(char *)(iVar1 + 0x2a) == '\n') && (*(char *)(iVar1 + 0x2b) == '\x10')) {
      DAT_0089c65d = DAT_0089c65d + 1;
    }
  }
  DAT_0089ce61 = 0;
  if (DAT_0089c65d < 0x21) {
    DAT_0089ce61 = 8;
  }
  if (DAT_0089c65d < 0x16) {
    DAT_0089ce61 = 4;
  }
  if (DAT_0089c65d < 0xd) {
    DAT_0089ce61 = 2;
  }
  return;
}
