/* Ghidra 12.1.3 pseudocode; entry 0041b520; FUN_0041b520.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_0041b520(char param_1)

{
  int iVar1;
  undefined4 *puVar2;

  puVar2 = (undefined4 *)(&DAT_00969dc6 + param_1 * 0x30);
  for (iVar1 = 0xc; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  DAT_00969dc2 = timeGetTime();
  return;
}
