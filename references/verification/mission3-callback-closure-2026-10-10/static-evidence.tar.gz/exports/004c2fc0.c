/* Ghidra 12.1.3 pseudocode; entry 004c2fc0; FUN_004c2fc0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2fc0(undefined4 param_1)

{
  DAT_005d4678 = 1;
  _DAT_005d467c = param_1;
  return;
}
