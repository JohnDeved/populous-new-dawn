/* Ghidra 12.1.3 pseudocode; entry 00408e30; FUN_00408e30.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00408e30(byte param_1,int param_2)

{
  (&DAT_0096070e)[param_2 * 0xe] = (&DAT_0096070e)[param_2 * 0xe] | 1 << (param_1 & 0x1f);
  return;
}
