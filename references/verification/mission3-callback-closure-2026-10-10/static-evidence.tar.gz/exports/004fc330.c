/* Ghidra 12.1.3 pseudocode; entry 004fc330; FUN_004fc330.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004fc330(int param_1)

{
  undefined4 *puVar1;
  undefined2 uVar2;
  uint uVar3;
  short sVar4;
  int iVar5;
  undefined2 extraout_var;
  int *piVar6;
  undefined2 extraout_var_00;
  int iVar7;
  int iVar8;
  int iVar9;
  uint local_20;
  int local_14;
  undefined2 uStack_e;
  undefined2 local_c;
  undefined4 local_8;

  iVar7 = -1;
  iVar9 = 0;
  iVar8 = 0;
  iVar5 = 0x6b;
  local_20 = 0xffffffff;
  piVar6 = (int *)0x0;
  if ((*(uint *)(param_1 + 0xc) & 0x400) != 0) {
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffbff;
    DAT_00892443 = DAT_00892443 + -5;
    piVar6 = DAT_00892443;
  }
  if (piVar6 != (int *)0x0) {
    iVar7 = *piVar6;
    local_20 = piVar6[1];
    iVar8 = piVar6[2];
    iVar9 = (int)*(short *)(iVar8 + 0x26);
    iVar5 = (int)*(short *)(iVar8 + 0x33);
  }
  if (iVar7 < 1) {
    uVar3 = DAT_0089d178 * 0x24a1 + 0x24df;
    DAT_0089d178 = uVar3 >> 0xd | uVar3 * 0x80000;
    local_20 = 0xffffffff;
    iVar7 = DAT_0089d178 % 3 + 1;
  }
  if ((int)local_20 < 0) {
    if (iVar7 == 3) {
      local_20 = 2;
    }
    else {
      uVar3 = DAT_0089d178 * 0x24a1 + 0x24df;
      local_20 = uVar3 >> 0xd;
      DAT_0089d178 = local_20 | uVar3 * 0x80000;
      local_20 = local_20 & 1;
    }
  }
  if (iVar8 == 0) {
    local_8 = *(undefined4 *)(param_1 + 0x3d);
  }
  else {
    local_14 = *(char *)(iVar5 * 0x36 + ((int)(iVar9 + (iVar9 >> 0x1f & 0x1ffU)) >> 9) + 0x2c +
                        DAT_00895ec1) * 0x30 + DAT_0059df3c;
    local_8 = CONCAT22(*(short *)(iVar8 + 0x7c) + (ushort)*(byte *)(local_14 + 3) * -0x100,
                       *(short *)(iVar8 + 0x7a) + (ushort)*(byte *)(local_14 + 2) * -0x100);
  }
  iVar8 = local_20 * 3 + local_14;
  sVar4 = (ushort)*(byte *)(iVar8 + 0x11) * 0x20 + (short)local_8;
  local_8._2_2_ = (ushort)*(byte *)(iVar8 + 0x13) * 0x20 + local_8._2_2_;
  uVar2 = FUN_0044e940(CONCAT22(uStack_e,sVar4),CONCAT22(local_c,local_8._2_2_));
  if ((*(byte *)(param_1 + 0xe) & 0x10) == 0) {
    FUN_004ed6f0(param_1);
    *(undefined1 *)(param_1 + 0x2c) = 7;
    FUN_004ed640(param_1);
  }
  puVar1 = (undefined4 *)(param_1 + 0x3d);
  *puVar1 = CONCAT22(local_8._2_2_,sVar4);
  *(undefined2 *)(param_1 + 0x41) = uVar2;
  FUN_004ee470(param_1,puVar1);
  uVar2 = FUN_0044e940(CONCAT22(extraout_var_00,*(undefined2 *)puVar1),
                       CONCAT22(extraout_var,*(undefined2 *)(param_1 + 0x3f)));
  *(undefined2 *)(param_1 + 0x41) = uVar2;
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffbff;
  *(short *)(param_1 + 0x26) = (short)iVar9;
  *(char *)(param_1 + 0x2d) = (char)iVar7;
  *(undefined1 *)(param_1 + 0xa7) = (undefined1)local_20;
  FUN_004ee700(param_1 + 0x33,*(undefined4 *)(&DAT_005a781c + iVar7 * 0xc),
               *(undefined4 *)(&DAT_005a7818 + iVar7 * 0xc));
  return;
}
