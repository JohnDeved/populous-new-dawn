/* Ghidra 12.1.3 pseudocode; entry 0042ca00; FUN_0042ca00.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_0042ca00(void)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  short *psVar6;
  undefined4 *puVar7;

  iVar3 = 0;
  if (((byte)DAT_0089c661 & 8) == 0) {
    puVar5 = &DAT_0089b741;
    puVar7 = &DAT_0096070a;
    for (iVar2 = 0xe; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar7 = *puVar5;
      puVar5 = puVar5 + 1;
      puVar7 = puVar7 + 1;
    }
    if (((byte)DAT_0089c661 & 8) == 0) goto LAB_0042ca9e;
  }
  if ((DAT_0089bc61 & 0x10) != 0) {
    DAT_0089d178 = DAT_0089d178 + DAT_00894d24;
    uVar1 = DAT_0089d178 * 0x24a1 + 0x24df;
    DAT_0089d178 = uVar1 >> 0xd | uVar1 * 0x80000;
    uVar1 = DAT_0089d178 % 3;
    if (uVar1 == 0) {
      iVar3 = 0x15;
    }
    else if (uVar1 == 1) {
      iVar3 = 0x12;
    }
    else if (uVar1 == 2) {
      iVar3 = 0x14;
    }
  }
LAB_0042ca9e:
  iVar2 = 0;
  if (DAT_0096eac0 != 0) {
    do {
      FUN_00408e30(0x11,iVar2);
      if (((byte)DAT_0089c661 & 8) == 0) {
        iVar4 = 0;
        psVar6 = &DAT_005a80d0;
        do {
          if ((*psVar6 == 0) || (*psVar6 == 2)) {
            FUN_004c2c60(iVar4,iVar2);
          }
          psVar6 = psVar6 + 0x1f;
          iVar4 = iVar4 + 1;
        } while (psVar6 < (short *)0x5a85e7);
        FUN_004c2fc0(0);
      }
      else {
        iVar4 = 0;
        psVar6 = &DAT_005a80d0;
        do {
          if ((psVar6 != (short *)&DAT_005a82fe) && ((*psVar6 == 0 || (*psVar6 == 2)))) {
            FUN_004c2c60(iVar4,iVar2);
          }
          psVar6 = psVar6 + 0x1f;
          iVar4 = iVar4 + 1;
        } while (psVar6 < (short *)0x5a85e7);
        if ((DAT_0089bc61 & 2) == 0) {
          if ((DAT_0089bc61 & 8) == 0) {
            if ((DAT_0089bc61 & 4) != 0) {
              iVar3 = 0x14;
            }
          }
          else {
            iVar3 = 0x12;
          }
        }
        else {
          iVar3 = 0x15;
        }
        if (iVar3 != 0) {
          DAT_0089d17c = DAT_0089d17c | 0x100;
          FUN_004c2fc0(iVar3);
          FUN_004c2c40(iVar3,iVar2);
        }
      }
      FUN_0041b520(iVar2);
      iVar2 = iVar2 + 1;
    } while (iVar2 < (int)(uint)DAT_0096eac0);
  }
  if ((DAT_0089c668 & 4) == 0) {
    DAT_005a7157 = 1;
    return;
  }
  DAT_005a7157 = 0;
  return;
}
