/* Ghidra 12.1.3 pseudocode; entry 004c2c60; FUN_004c2c60.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004c2c60(int param_1,int param_2)

{
  byte *pbVar1;

  (&DAT_0096070a)[param_2 * 0xe] = (&DAT_0096070a)[param_2 * 0xe] & ~(1 << ((byte)param_1 & 0x1f));
  pbVar1 = (byte *)((int)&DAT_0096071e + param_1 + param_2 * 0x38);
  *pbVar1 = *pbVar1 & 0xf0;
  *pbVar1 = 0;
  return;
}
