import java.nio.file.*;
import java.util.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
public class CallbackFacts extends GhidraScript {
 public void run() throws Exception {
  StringBuilder out=new StringBuilder();
  for(String s:new String[]{"004fc330","00503230","0042ca00","00408e30","0041b520","004c2c60","004c2fc0"}) {
   Function f=getFunctionAt(toAddr(s));
   if(f==null)throw new IllegalStateException("Missing "+s);
   out.append("FUNCTION\t").append(s).append("\t").append(f.getBody()).append("\t").append(f.getBody().getNumAddresses()).append("\n");
   var ins=currentProgram.getListing().getInstructions(f.getBody(),true);
   while(ins.hasNext()) {var i=ins.next();out.append("INS\t").append(s).append("\t").append(i.getAddress()).append("\t").append(HexFormat.of().formatHex(i.getBytes())).append("\t").append(i).append("\n");}
   var addrs=f.getBody().getAddresses(true);
   while(addrs.hasNext()) {var a=addrs.next();for(var r:getReferencesFrom(a))ref(out,"OUT",s,r);for(var r:getReferencesTo(a))ref(out,"IN",s,r);}
  }

  Files.writeString(Path.of(getScriptArgs()[0]),out.toString());
  println("CALLBACK_FACTS_COMPLETE");
 }
 void ref(StringBuilder out,String dir,String s,Reference r) {out.append(dir).append("\t").append(s).append("\t").append(r.getFromAddress()).append("\t").append(r.getToAddress()).append("\t").append(r.getReferenceType()).append("\t").append(r.getSource()).append("\t").append(r.getOperandIndex()).append("\n");}
}
