# Sunlight source boundary: finite independent review

The exact integer helper boundary is viable. **No original execution is admitted
yet**: a separately frozen implementation, synthetic tests, selected-output
contract and parent release are still required.

## Closed source facts

- Verified all171 canonical instruction rows in the author's four retained
  windows and independently reproduced both1024-byte host expectation hashes.
  The separate host calculation uses signed16/32-bit extraction, explicit
  signed-division truncation and the actual integer-root iteration. All2048
  modeled root calls match integer square root. These remain host expectations,
  not observed native outputs or authorized replacements.
- Exact fast-sqrt code is`00586000..00586034`. Its first CSEG section has original
  PE characteristics`0x60000020` (RX); the second CSEG is different and RW. The
  helper is integer code, with zero bypassing BSR/DIV and nonzero BSR selecting a
  word index0..31. Its seed table is32 UINT16 words/64bytes at`00586034..00586074`.
- The sin/cos sampled address sets overlap. There are40 distinct DWORDs,160 input
  bytes, at`005ddde8 + i*0x100` for`i=0..39`, used4096 times. Canonical inputs yield
  positive squared norms268388690..268464132 and root16382..16384; only seed
  indices27/28 are exercised in the host calculation.
- Decoded every retained trig reference:154 rows,150 distinct instruction PCs.
  There are150 indexed/absolute read rows, two LEAs and two reads through their
  local aliases. Both NO_FUNCTION entries are genuine indexed loads. Ghidra's
  DATA label does not itself mean a pointer escapes. The two sqrt xref rows are
  the same indexed word load at`00586011`, not two independent instructions.
- Closed the identified local aliases in`00473210`. The sin-pointer EBX live CFG
  covers199 instructions, nine callsites with seven bounded helper summaries and
  five kill frontiers. Its only semantic live use is`MOV EAX,[EBX]`. Callees either
  leave EBX unused or save it locally and overwrite it before semantic use. The
  cos-pointer ECX is read locally then killed by`XOR ECX,ECX` at`0042a079` before
  subsequent use. No retained pointer escape or write-through was found.

Receipts: `sunlight-boundary-review.json`, `trig-reference-review.json` and
`trig-alias-cfg-review.json`, each with its independent static verifier and log.
The reviewer executed zero original instructions throughout this work.

## Precise remaining condition

Any next bounded candidate must explicitly condition that the40 sampled writable
`.data` DWORDs equal the canonical EXE bytes **at prefix entry**. It must retain
their source hashes and reject every attempted write overlapping those160 bytes
throughout the selected prefix. The finite xref/alias audit does not prove their
actual campaign lifetime or exclude arbitrary bulk writes and corrupted pointers
elsewhere. Do not relabel the condition as captured entry state or universal
immutability.

Admit only the exact fast-sqrt instruction window above. Page-granular RX mapping
may cover its containing page, but the instruction hook must reject the seed
table, following helpers and every other CSEG address. No section-name-wide
execution permission is justified.

Implement only the integer forms required by the retained source. Undefined
flags must stay unknown; divide faults must leave no committed outputs. BSR zero
may be explicitly rejected if unsupported, since the helper bypasses it. Extra
widths, prefixes or operand forms should fail closed. Native integer execution
must produce the outputs; host expected arrays are comparison data only.

New shared event ordinals may join reads, committed writes and declared boundary
events, but describe observer order rather than instruction retirement. Preserve
the historical frozen drivers and receipts. Sunlight extension acceptance must
also carry forward the existing floating-fragment condition, palette pointer
expiry and remaining unknown-state boundaries.
