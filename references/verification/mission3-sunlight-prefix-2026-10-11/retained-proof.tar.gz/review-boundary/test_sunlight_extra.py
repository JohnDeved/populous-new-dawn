"""Reviewer-authored synthetic x86 only; never loads canonical native CPU."""
from pathlib import Path
import sys, struct, unittest
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'harness-repair'))
import test_sunlight as t
s,b=t.s,t.b
class Extra(unittest.TestCase):
 def make(self,code,regs=None,**kw):return t.IntegerTests().make(bytes.fromhex(code),regs,**kw)
 def test_bsr_alias_zero_then_consumption_is_rejected(self):
  e=self.make('0fbdc083c001',{'eax':0})
  with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
  self.assertEqual(e.committed,1);self.assertEqual(e.shadow.reg_get('eax'),0)
 def test_bsr_source_alias_nonzero(self):
  e=self.make('0fbdc0',{'eax':0x40000000});e.run(t.CODE,t.STOP)
  self.assertEqual(e.reg_value('eax'),30);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32)
 def test_count31_shifts_sign_and_cf(self):
  for code,value,want,cf in [('c1e01f',3,0x80000000,1),('c1e81f',0xfffffffe,1,1),('c1f81f',0x80000000,0xffffffff,0)]:
   e=self.make(code,{'eax':value});e.run(t.CODE,t.STOP)
   self.assertEqual(e.reg_value('eax'),want);self.assertEqual(e.reg_value('eflags')&b.CF,cf)
   self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.PF|b.ZF|b.SF)
 def test_two_operand_imul_memory_requires_all_bits_and_address(self):
  for known in (0,0xffff,b.MASK32):
   e=self.make('0faf03',{'eax':-4,'ebx':t.DATA});e.cpu.mem_write(t.DATA,struct.pack('<I',9));e.shadow.put(t.DATA,4,known)
   if known!=b.MASK32:
    with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
    self.assertEqual(e.committed,0)
   else:
    e.run(t.CODE,t.STOP);self.assertEqual(e.reg_value('eax'),(-36)&b.MASK32)
    self.assertEqual(e.read_events[0]['knownMask'],'0xffffffff')
  e=self.make('0faf03',{'eax':-4,'ebx':t.DATA});e.shadow.reg_put('ebx',0)
  with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
 def test_unknown_sign_cdq_remains_rejected(self):
  e=self.make('99',{'eax':0});e.shadow.reg_put('eax',0x7fffffff)
  with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
  self.assertEqual(e.committed,0)
 def test_undefined_division_flags_can_only_be_killed(self):
  e=self.make('f7f331c07400',{'eax':19,'edx':0,'ebx':4});e.run(t.CODE,t.STOP)
  self.assertEqual(e.reg_value('eax'),0);self.assertEqual(e.reg_value('edx'),3)
  self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ARITH&~b.AF)
 def test_protected_word_overlap_endpoints(self):
  for offset,blocked in [(0,False),(1,True),(4,True),(7,True),(8,False)]:
   code=b'\xa3'+struct.pack('<I',t.DATA+offset)
   e=t.IntegerTests().make(code,{'eax':123});e.protected_inputs=[t.DATA+4]
   if blocked:
    with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
    self.assertFalse(e.write_events);self.assertEqual(e.committed,0)
   else:e.run(t.CODE,t.STOP);self.assertEqual(len(e.write_events),4)
 def test_memory_divisor_is_outside_finite_forms(self):
  e=self.make('f733',{'eax':19,'edx':0,'ebx':t.DATA});e.supply(t.DATA,struct.pack('<I',4),'synthetic divisor')
  with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
  self.assertEqual(e.committed,0)
if __name__=='__main__':unittest.main(verbosity=2)
