"""Finite canonical register-alias CFG review, no original execution."""
from pathlib import Path
import hashlib,importlib.util,json
import capstone
ROOT=Path.cwd();OUT=ROOT/'work/orchestration/training-native-20261010/mission3-initialization/review-boundary'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
s=importlib.util.spec_from_file_location('static_reader',ROOT/'scripts/check-static-mission18-sky.py');reader=importlib.util.module_from_spec(s);s.loader.exec_module(reader)
pe=reader.PE32(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'));assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
def instruction(pc):return next(cs.disasm(pe.read(pc,15),pc))
def desc(i):return {'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str}
def names(i):
    r,w=i.regs_access();return {i.reg_name(v) for v in r},{i.reg_name(v) for v in w}
# Complete finite helper bodies; each can be decoded without a new Ghidra export.
bodies={0x42a070:0x42a096,0x47f7b0:0x47f927,0x47f930:0x47f9b0,0x47f9b0:0x47fa2c,
        0x47fab0:0x47fe83,0x55bc54:0x55bc7b,0x40cd00:0x40cdd8}
summaries={}
for start,stop in bodies.items():
    work=[start];seen=set();uses=[];kills=[];calls=[];returns=[]
    while work:
        pc=work.pop()
        if pc in seen:continue
        seen.add(pc);assert start<=pc<stop,(hex(start),hex(pc))
        i=instruction(pc);read,written=names(i)
        if 'ebx' in written:
            assert 'ebx' not in read or (i.mnemonic in ['xor','sub','sbb'] and i.op_str=='ebx, ebx'),desc(i)
            kills.append(desc(i));continue
        if 'ebx' in read:
            assert i.mnemonic=='push' and i.op_str=='ebx',desc(i)
            uses.append(desc(i))
        if i.mnemonic=='ret':returns.append(desc(i));continue
        if i.mnemonic=='call':
            target=i.operands[0].imm;assert target==0x47f7b0 and start in [0x47f930,0x47f9b0],desc(i)
            calls.append(desc(i));work.append(pc+i.size)
        elif i.mnemonic.startswith('j'):
            assert i.operands[0].type==capstone.x86.X86_OP_IMM
            work.append(i.operands[0].imm)
            if i.mnemonic!='jmp':work.append(pc+i.size)
        else:work.append(pc+i.size)
    summaries[hex(start)]={'window':[hex(start),hex(stop)],'sha256':sha(pe.read(start,stop-start)),
                           'reachableBeforeKillOrReturn':len(seen),'incomingEbxUses':uses,'firstKills':kills,'callsBeforeKill':calls,'returnsWithoutEbxConsumption':returns}
# All earlier helper summaries are now checked, including the one matrix callee.
assert {int(d['pc'],16) for d in summaries['0x47f7b0']['firstKills']}=={0x47f879}
assert {int(d['pc'],16) for d in summaries['0x47fab0']['firstKills']}=={0x47fb20}
assert {int(d['pc'],16) for d in summaries['0x40cd00']['firstKills']}=={0x40cd0a}
assert not summaries['0x42a070']['incomingEbxUses'] and not summaries['0x55bc54']['incomingEbxUses']
work=[0x4733fb];seen={};kills=[];uses=[];calls=[]
while work:
    pc=work.pop()
    if pc in seen:continue
    assert 0x4733f4<=pc<0x474000,hex(pc)
    i=instruction(pc);seen[pc]=desc(i);read,written=names(i)
    if 'ebx' in written:
        assert 'ebx' not in read or (i.mnemonic in ['xor','sub','sbb'] and i.op_str=='ebx, ebx'),desc(i)
        kills.append(desc(i));continue
    if 'ebx' in read:
        assert i.mnemonic=='mov' and i.op_str=='eax, dword ptr [ebx]',desc(i)
        uses.append(desc(i))
    if i.mnemonic=='ret':raise AssertionError(('return with unclosed local alias',desc(i)))
    if i.mnemonic=='call':
        target=i.operands[0].imm;assert hex(target) in summaries,desc(i)
        calls.append({**desc(i),'calleeSummary':hex(target)});work.append(pc+i.size)
    elif i.mnemonic.startswith('j'):
        assert i.operands[0].type==capstone.x86.X86_OP_IMM
        work.append(i.operands[0].imm)
        if i.mnemonic!='jmp':work.append(pc+i.size)
    else:work.append(pc+i.size)
assert len(seen)==199 and len(calls)==9 and len(uses)==1 and len(kills)==5
# The cos ECX address remains local in the read loop; the first post-loop helper
# explicitly zeroes ECX before consuming it. Its table-load use is already bound.
assert (instruction(0x42a079).mnemonic,instruction(0x42a079).op_str)==('xor','ecx, ecx')
assert (instruction(0x473444).mnemonic,instruction(0x473444).op_str)==('mov','eax, dword ptr [ecx]')
report={'verdict':'LOCAL_TRIG_POINTER_ALIAS_CLOSURE_PASSED','originalInstructionsExecuted':0,
        'ebxAliasCreation':desc(instruction(0x4733f4)),'ecxAliasCreation':desc(instruction(0x47340d)),
        'ebxLiveCfgInstructionCount':199,'ebxOnlyValueUse':uses,'ebxKills':kills,'ebxLiveCallsites':calls,
        'calleeIncomingEbxSummaries':summaries,'canonicalLiveCfgInstructions':[seen[pc] for pc in sorted(seen)],
        'ecxLocalKill':'0042a079 XOR ECX,ECX in call00473493; earlier local loop only reads[ECX].',
        'limit':'These are finite register-dependency and ordinary local-stack/call summaries. They establish no retained pointer escape or write-through for the two identified aliases. They do not prove against arbitrary corrupted pointers/bulk writes or all pre-entry history, and do not remove the declared canonical-table input condition.'}
(OUT/'trig-alias-cfg-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'ebxLiveCfgInstructions':199,'callsiteSummaries':9,'killFrontiers':5,'originalInstructionsExecuted':0}))
