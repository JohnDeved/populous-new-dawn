# Frozen sunlight prefix review

Verdict: ACCEPT_SUNLIGHT_PREFIX, with the parent execution lane still held in the
immutable reviewer payload. No original instructions were executed by this reviewer.

Driver SHA256: da1d0eb6b11cc024ef0ae9e843aaac7c380bab60c8dcd555073a7f0ae6ea0388.
Preflight SHA256: 5fa6bc1c284981e34a78199beacc471599324bbb346b7f5200f736ca60472bf3.
Held verdict SHA256: 2e74b7f1c400f840bbc24f4e644b75a280e102458db1509bad561a6741b5932a.
Source HEAD: c7abae13e31d476d4d8ba6f170305cb2a4d0e914, tracked status clean.

## Checks

- Independently reran all 86 author synthetic tests and eight additional synthetic
  tests. The extras cover BSR destination/source aliasing, zero-result consumption,
  count-31 shifts, memory IMUL masks and addresses, unknown-sign CDQ, killing DIV's
  undefined flags, both ends of protected-word overlap, and excluded memory DIV.
- Regenerated static preparation; it is byte-identical to the frozen preflight.
  Verified every file hash in the author verification receipt, all frozen parents,
  current source identity, and the supplied static source/alias audit conclusions.
- New arithmetic is limited to the declared 32-bit forms. Decisive operands require
  full knownness; zero shifts preserve unknown bits; BSR zero output stays unknown;
  undefined flags remain unknown; division faults cannot commit registers or writes.
- The original reset/palette 33-field and complete CPU/unknown-output contract is
  checked after committing the real XOR at 0042b5a1. The palette pointer expires
  before continuing at 0042b5a3. The new stop is 0042b5a8 before terrain-mask setup.
- Only 00586000..00586034 of first CSEG is admitted as code. Runtime page RX does
  not extend the instruction-hook boundary. The canonical 64-byte seed table has
  read-only source provenance. All 40 sampled mutable trig words are separately
  conditioned at entry and protected against overlapping native writes.
- The final 43 memory fields, two table hashes, CPU masks/values, preserved unknown
  outputs and 2,048 returned sqrt calls are predeclared and approval-hash-bound.
  Final EDX is correctly permitted to become known via genuine integer definitions.
- One shared ordinal covers observed reads, committed byte writes and 12 explicit
  invalidations. Projection records do not duplicate ordinals. This is observer
  order, not instruction retirement or complete register/value replay. The two
  20-byte omitted call footprints are invalidated at the declared callbacks;
  later genuine stack writes may legitimately redefine those bytes.

## Acceptance limits

A parent-released run may establish only the selected source-ordered prefix result
under the existing normal/no-fault camera omission condition, live disjoint palette
allocation renaming, balance constants and the explicit canonical sampled-trig
entry condition. The local alias audit does not prove universal pre-entry table
nonmutation. No additional presentation omission, fabricated return, terrain mask,
command/tribe/pool/bank initialization, allocator, authored-record constructor,
postpass or gameplay is admitted.

Until a terminal run and independent post-check exist, publication is limited to
static/synthetic preparation and conditional execution admission. Retain all failure
receipts before repair; substantive changes require a new review.
