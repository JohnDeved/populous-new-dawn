"""Independent file/source/host-math review; NO original execution or native import."""
from pathlib import Path
from collections import Counter
import hashlib,importlib.util,json,struct,math
import capstone
ROOT=Path.cwd();BASE=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=BASE/'harness-repair';OUT=BASE/'review-boundary';R=H/'sunlight-run01'
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(p.read_text());digest=lambda v:sha(json.dumps(v,sort_keys=True).encode())
EXPECTED='e61d5f6bbf61ff8692fc948d4560aab525233b9996b668c93f73c0b8ce436f7a'
raw=(R/'sunlight-result.json').read_bytes();assert sha(raw)==EXPECTED;r=json.loads(raw);m=read(R/'sunlight-preflight.json');base=read(R/'preflight.json')
v=read(OUT/'sunlight-review-verdict.json');a=read(H/'sunlight-run01-approval-released.json');process=read(H/'sunlight-run01-process-receipt.json')
assert sha((OUT/'sunlight-review-verdict.json').read_bytes())=='2e74b7f1c400f840bbc24f4e644b75a280e102458db1509bad561a6741b5932a'
assert a['parentReleasedRunLane'] and not v['parentReleasedRunLane']
assert {k:value for k,value in a.items() if k!='parentReleasedRunLane'}=={k:value for k,value in v.items() if k!='parentReleasedRunLane'}
assert process['approval']['sha256']==sha((H/'sunlight-run01-approval-released.json').read_bytes())
assert m==read(H/'sunlight-preflight01/sunlight-preflight.json')
assert process['exitCode']==0 and process['status']=='passed' and not process['trackedStatus']
assert process['sourceHead']==m['source']['observedSourceHead']==a['observedSourceHead']
assert process['conditions']==m['conditionalAssumptions']
assert process['driversBefore']==process['driversAfter']
for file,d in process['driversBefore'].items():assert sha((H/file).read_bytes())==d
for file,d in v['reviewedHashes'].items():assert sha((H/file).read_bytes())==d
for file,record in process['artifacts'].items():
 data=(H/file).read_bytes();assert len(data)==record['bytes'] and sha(data)==record['sha256']
assert a['sourceBindingSha256']==digest(m['source']) and a['inputBindingSha256']==digest(m['inputs'])
keys=['entry','expectedStop','allowedWindows','omittedFragments','heapContract','prefixBoundaryContract','prefixUnknownOutputs','conditionalAssumptions','trigInputs','sqrtTable','selectedObservables','expectedInvalidationEvents','finalBoundaryContract','eventSchema']
assert a['scopeBindingSha256']==digest({k:m[k] for k in keys})
for record in [m['driver'],m['frozenPrefix'],m['projectedReset'],m['frozenEngine'],m['executable'],*m['inputs'],*[x for x in m['source'].values() if isinstance(x,dict) and 'path' in x]]:
 data=Path(record['path']).read_bytes();assert len(data)==record['bytes'] and sha(data)==record['sha256']
for k in ['scope','conditionalAssumptions','heapContract','trigInputs','notRun','driver','frozenPrefix','projectedReset','frozenEngine']:assert r[k]==m[k],k
assert r['status']=='SUNLIGHT_PREFIX_SELECTED_OBSERVABLES_PASSED'
assert r['attemptedOriginalInstructions']==r['committedOriginalInstructions']==198587
assert r['blocker'] is None and r['error'] is None and not r['allocations'] and not r['openCalls'] and not r['abortedInstructions'] and r['recordsVisited']==0
spec=importlib.util.spec_from_file_location('static_pe_reader',ROOT/'scripts/check-static-mission18-sky.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
pe=reader.PE32(Path(m['executable']['path']));assert sha(pe.data)==r['identity']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;rows={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);ins=list(cs.disasm(data,lo))
 assert sha(data)==w['sha256'] and sum(i.size for i in ins)==len(data);rows.update({i.address:i for i in ins})
oldraw=(H/'reset-palette-run01/reset-palette-result.json').read_bytes();assert sha(oldraw)=='2bb2f8d7bd4a3054df601e117d25d3ab176958d77545800908feabf1dc5a61f2';old=json.loads(oldraw)
# Existing independent review established this historic prefix. Compare every
# recorded prefix event, then reconstruct its chronology from retained source.
assert r['prefixObservableAssertions']==old['selectedObservableAssertions'] and r['prefixBoundary']==old['after']['registers']
assert r['projections']==old['projections'] and len(r['projections'])==3
assert r['relocatedFlagEvents']==old['relocatedFlagEvents']
regions=[(0x42b590,0x42b59c),(0x42bfa0,0x42bfd3),(0x4a32d0,0x4a3330),(0x42bfd3,0x42c085),(0x41ce00,0x41ce2f),(0x42cfd0,0x42d03c),(0x42c085,0x42c09e),(0x475530,0x475548),(0x42c09e,0x42c12c),(0x42b59c,0x42b5a1),(0x4a2920,0x4a2944),(0x42b5a1,0x42b5a3)]
rank={}
for lo,hi in regions:
 for i in cs.disasm(pe.read(lo,hi-lo),lo):rank[i.address]=len(rank)
ordered=[]
for kind,priority,key in [('memoryReads',0,'memoryReads'),('memoryWrites',1,'memoryWrites')]:
 for index,e in enumerate(old[key]):
  pc=int(e['pc'],16);iteration=(int(e['address'],16)-(0x20101c0 if kind=='memoryReads' else 0x899f8d))//4 if pc==0x4a293f else 0
  ordered.append((rank[pc],iteration,priority,index,kind,e))
# The predeclared descriptors already bind source and mask effects. Place them
# using the exact callback PCs, before following native events, not result ordinals.
for index,e in enumerate(m['expectedInvalidationEvents'][:-1]):ordered.append((rank[int(e['pc'],16)],0,-1,index,'invalidationEvents',e))
expected=[]
for *_,kind,e in sorted(ordered):expected.append((kind,dict(e)))
expected.append(('invalidationEvents',dict(m['expectedInvalidationEvents'][-1])))
assert len(expected)==57559
S=0x23ed000;sp=S-60
# New source schedule is finite: helper's Newton loop has no memory access.
# Norm positivity is independently computed below, excluding zero-root paths.
def rd(pc,address,size,mask=None):
 expected.append(('memoryReads',{'pc':hex(pc),'address':hex(address),'size':size,'knownMask':hex((1<<(8*size))-1 if mask is None else mask)}))
def wr(pc,address,size,mask=None):
 mask=(1<<(8*size))-1 if mask is None else mask
 for j in range(size):expected.append(('memoryWrites',{'pc':hex(pc),'address':hex(address+j),'size':1,'knownMask':hex((mask>>(8*j))&255),'committed':True}))
def sqrt_events(norm):
 idx=norm.bit_length()-1;assert idx in (27,28)
 for pc,addr in [(0x586003,S-76),(0x586004,S-80),(0x586005,S-84)]:wr(pc,addr,4)
 rd(0x586006,S-64,4);rd(0x586011,0x586034+2*idx,2)
 for pc,addr in [(0x58602d,S-84),(0x58602e,S-80),(0x58602f,S-76),(0x586033,S-68)]:rd(pc,addr,4)
def sint(value,bits=32):
 value&=(1<<bits)-1;return value-(1<<bits) if value&(1<<(bits-1)) else value
def trig(a):return struct.unpack('<i',pe.read(a,4))[0]
def prod(a,b):return sint((a*b)>>18,16)
def idiv(n,d):return (-1 if n<0 else 1)*(abs(n)//d)
wr(0x42b5a3,S-12,4);wr(0x401040,S-16,4)
for pc,addr,size in [(0x401046,0x937aae,1),(0x40104d,0x937aaf,1),(0x401054,0x937aa8,2),(0x40105f,0x937ab0,1),(0x401066,0x937aac,2),(0x40106c,0x937aaa,2)]:wr(pc,addr,size)
wr(0x401072,S-20,4)
for pc,addr,mask in [(0x401793,S-48,0xffffffff),(0x401794,S-52,0),(0x401795,S-56,0xffffffff),(0x401798,S-60,0)]:wr(pc,addr,4,mask)
norms=[];outputs=[[],[]]
for i in range(1024):
 ia=(i&31)<<6;ib=(i&~31)<<1;ca=trig(0x5de5e8+4*ia);cb=trig(0x5de5e8+4*ib);sa=trig(0x5ddde8+4*ia);sb=trig(0x5ddde8+4*ib)
 x,y,z=prod(ca,cb),prod(sa,cb),sint(sb>>2,16);norm=x*x+y*y+z*z;assert norm>0;norms.append(norm);root=math.isqrt(norm)
 outputs[0].append((28+(15*max(0,147*(idiv(x<<8,root)+idiv(y<<8,root)+idiv(z<<8,root)))>>16))&255)
 outputs[1].append((28+(15*max(0,-200*idiv(z<<8,root))>>16))&255)
 rd(0x4017a6,0x5de5e8+4*ib,4);wr(0x4017b4,sp+0x20,4);rd(0x4017b8,0x5de5e8+4*ia,4);wr(0x4017c6,sp+0x24,4)
 rd(0x4017ca,sp+0x24,4);rd(0x4017ce,sp+0x20,4);rd(0x4017dd,0x5ddde8+4*ib,4);wr(0x4017e6,sp+0x18,4)
 rd(0x4017ed,0x5ddde8+4*ia,4);wr(0x4017f3,sp+0x1c,4);rd(0x4017f7,sp+0x1c,4);rd(0x4017fb,sp+0x18,4);wr(0x40180d,sp+0x10,4)
 wr(0x40182b,S-64,4);wr(0x40182c,S-68,4);sqrt_events(norm)
 wr(0x401845,sp+0x14,4);rd(0x401849,sp+0x10,4)
 for pc,addr in [(0x401864,0x937aaa),(0x40186e,0x937aac),(0x40187a,0x937aa8)]:rd(pc,addr,2)
 rd(0x401881,sp+0x14,4);wr(0x401890,S-64,4);rd(0x401891,0x937aaf,1);rd(0x4018a0,0x937aae,1);wr(0x4018ad,0x89bc8e+i,1)
 wr(0x4018b3,S-68,4);sqrt_events(norm)
 rd(0x4018c6,sp+0x10,4);rd(0x4018e4,0x937aaf,1);rd(0x4018f3,0x937aae,1);wr(0x401906,0x89c08e+i,1)
for pc,addr,mask in [(0x401912,S-60,0),(0x401913,S-56,0xffffffff),(0x401914,S-52,0),(0x401915,S-48,0xffffffff),(0x401919,S-20,0xffffffff)]:rd(pc,addr,4,mask)
wr(0x40107e,0x937c46,3048);wr(0x401080,0x937c46+3048,2);wr(0x401082,0x96aa7c,2);rd(0x401088,S-16,4);rd(0x401089,S-12,4)
assert len(expected)==158959
for ordinal,(kind,e) in enumerate(expected):e['eventOrdinal']=ordinal
actual=sorted([(key,e) for key in ['memoryReads','memoryWrites','invalidationEvents'] for e in r[key]],key=lambda item:item[1]['eventOrdinal'])
assert len(actual)==len(expected)
for ordinal,((kind,wanted),(actualkind,actualevent)) in enumerate(zip(expected,actual)):
 assert (kind,wanted)==(actualkind,actualevent),(ordinal,kind,wanted,actualkind,actualevent)
 # All native event PCs are genuine instruction starts in exact byte-bound windows.
 if kind!='invalidationEvents':
  pc=int(wanted['pc'],16);assert pc in rows and not any(f['start']<=pc<f['stop'] for f in m['omittedFragments'])
print('source-derived event chronology matched',len(expected))
# Independently verify supplies and construct a nonoverlapping initial mask map.
sup=r['suppliedInputs'];assert len(sup)==289 and len(base['constantWrites'])==244
initial={}
def supply(item,address,data,source):
 assert item['address']==hex(address) and item['size']==len(data) and item['sha256']==sha(data),(item,address)
 for offset in range(len(data)):initial[address+offset]=(255,source)
for item,record in zip(sup[:244],base['constantWrites']):supply(item,int(record['address'],16),bytes.fromhex(record['bytesHex']),'verified balance descriptor writes')
assert sup[244]['register']=='esp' and sup[244]['value']==hex(S) and sup[244]['knownMask']=='0xffffffff'
assert sup[245]['register']=='eflags' and sup[245]['value']=='0x2' and sup[245]['knownMask']=='0x400'
supply(sup[246],S,struct.pack('<I',0x23ee000),'declared root return fixture')
supply(sup[247],0x87eff8,struct.pack('<I',0x2010000),'scoped successful/live/disjoint heap renaming')
assert [int(w['address'],16) for w in m['trigInputs']['words']]==[0x5ddde8+256*i for i in range(40)]
for word,item in zip(m['trigInputs']['words'],sup[248:288]):
 addr=int(word['address'],16);data=pe.read(addr,4);assert data.hex()==word['bytesHex'] and sha(data)==word['sha256'];supply(item,addr,data,'explicit canonical sampled-trig entry condition')
seed=pe.read(0x586034,64);assert seed.hex()==m['sqrtTable']['bytesHex'] and sha(seed)=='227b9ef05a5e86dc490f85c14feb71e8be859e3c4076dfc5640275906231f219';supply(sup[288],0x586034,seed,'canonical read-only sqrt seeds')
entries=[]
for addr,(mask,source) in sorted(initial.items()):
 if entries and addr==int(entries[-1]['address'],16)+entries[-1]['size'] and source==entries[-1]['source']:
  entry=entries[-1];entry['size']+=1;entry['knownMask']=hex((1<<(8*entry['size']))-1)
 else:entries.append({'address':hex(addr),'size':1,'knownMask':'0xff','source':source})
counts=dict(Counter(kind for kind,e in expected));eventstream={'schemaVersion':1,'ordering':'observer','eventCount':len(expected),'firstOrdinal':0,'lastOrdinal':len(expected)-1,'counts':counts}
assert r['eventStream']==eventstream
pc_rules={kind:{} for kind in ['memoryReads','memoryWrites']}
for kind,e in expected:
 if kind in pc_rules:
  rule=pc_rules[kind].setdefault(e['pc'],{'sizes':set(),'knownMasks':set()});rule['sizes'].add(e['size']);rule['knownMasks'].add(e['knownMask'])
for rules in pc_rules.values():
 for rule in rules.values():rule['sizes']=sorted(rule['sizes']);rule['knownMasks']=sorted(rule['knownMasks'])
contract={'case':'reviewed sunlight-run01 conditional 0042b590..0042b5a8','eventStream':eventstream,'memoryRanges':[[0x400000,0xd4e000],[0x2000000,0x2400000]],'forbiddenPcRanges':[[f['start'],f['stop']] for f in m['omittedFragments']],'pcRules':pc_rules,'initialMemory':entries,'invalidationEvents':[e for kind,e in expected if kind=='invalidationEvents']}
helperpath=Path('/workspace/scratch/69fd8163d94e/native-event-replay-20261011/scripts/native-event-replay.py');HELPER_SHA='8a016740eef10a95e61e821b1a8adf5a9999025074e8b332ae2a32d9102d4f16';assert sha(helperpath.read_bytes())==HELPER_SHA
spec=importlib.util.spec_from_file_location('reviewed_event_replay',helperpath);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
contract_hash=helper.contract_digest(contract)
(OUT/'sunlight-run01-replay-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
# The contract is constructed only from independently checked source schedule,
# previous reviewed receipt, predeclared descriptors and canonical initial bytes.
# Expected receipt identity comes from the parent's external run handoff.
state=helper.replay_receipt(raw,EXPECTED,contract,contract_hash)
assert state.counts==counts
print('frozen pure helper reconstructed all masks; contract',contract_hash)
# Exact call topology, return sites and stack positions: no imported/hidden calls.
oldcalls=[(e['caller'],e['target'],e['return'],e['parent'],e['returnSp']) for e in old['calls']]
expectedcalls=oldcalls+[(hex(0x42b5a3),hex(0x401040),0x42b5a8,None,S-8),(hex(0x401072),hex(0x401790),0x401077,5,S-16)]
for i in range(1024):expectedcalls.extend([('0x40182c','0x586000',0x401831,6,S-64),('0x4018b3','0x586000',0x4018b8,6,S-64)])
assert [(e['caller'],e['target'],e['return'],e['parent'],e['returnSp']) for e in r['calls']]==expectedcalls
assert len(r['calls'])==2055 and all(e['returned'] and e['sequence']==i for i,e in enumerate(r['calls']))
for index,event in enumerate(r['calls'][7:]):
 norm=norms[index//2];assert event['entryRegisters']['edi']=={'value':hex(norm),'knownMask':'0xffffffff'}
 assert event['returnRegisters']['eax']=={'value':hex(math.isqrt(norm)),'knownMask':'0xffffffff'}
for fragment,wanted in zip(r['projections'],m['omittedFragments']):
 assert fragment['bytesSha256']==wanted['sha256']==sha(pe.read(wanted['start'],wanted['stop']-wanted['start']))
 assert fragment['start']==hex(wanted['start']) and fragment['stopExclusive']==hex(wanted['stop'])
# All 43 predeclared observations; independent host arithmetic supplies table hashes.
assert len(r['selectedObservableAssertions'])==len(m['selectedObservables'])==43
hosthash=[sha(bytes(out)) for out in outputs]
assert hosthash==['aa4787ac8921047228e66966915a1703b2592ccbd0dfed77f41e836c9e46227d','997ab09f7e99c3d05b9cc78d4252b261fc7b6daab301bdaf24bdba0e3b344a1f']
lastwriters=[]
for expectedfield,observation in zip(m['selectedObservables'],r['selectedObservableAssertions']):
 assert all(observation[k]==expectedfield[k] for k in ['name','address','bytes'])
 addr=int(observation['address'],16);n=observation['bytes'];known=(1<<(8*n))-1
 assert observation['knownMask']==hex(known)==hex(state.known_mask(addr,n))
 if 'expectedValue' in expectedfield:
  assert observation['value']==expectedfield['expectedValue']
  assert observation['sha256']==sha(observation['value'].to_bytes(n,'little'))
 else:assert observation['sha256']==expectedfield['expectedSha256']
 sources=state.byte_sources(addr,n);assert all(source[0]=='write' for source in sources)
 pcs=sorted({source[2] for source in sources});lastwriters.append({'name':observation['name'],'lastWriterPcs':pcs,'instructions':[rows[int(pc,16)].mnemonic+' '+rows[int(pc,16)].op_str for pc in pcs]})
for addr,n in [(0x899f8d,64),(0x2010000,1024),(0x87eff8,4),(0x59df24,4),(0x5fe3f0,8),(S-8,8)]:assert state.known_mask(addr,n)==0,hex(addr)
assert r['paletteScopeClosed'] is True and r['paletteCacheKnownMask']==r['abstractAllocationKnownMask']=='0x0'
for key,addr in [('expiredPalettePointer',0x87eff8),('unsuppliedPaletteAlias',0x59df24),('savedOuterStack',S-8)]:assert r[key]=={'address':hex(addr),'value':None,'knownMask':'0x0'}
assert r['omittedWords']==[{'address':hex(addr),'value':None,'knownMask':'0x0'} for addr in [0x5fe3f0,0x5fe3f4]]
bound=m['finalBoundaryContract'];assert r['boundaryContract']==bound
for reg,value in bound['knownRegisters'].items():assert r['after']['registers'][reg]=={'value':hex(value),'knownMask':'0xffffffff'}
for reg in bound['unknownRegisters']:assert r['after']['registers'][reg]['knownMask']=='0x0'
f=r['after']['registers']['eflags'];assert f['knownMask']==bound['eflagsKnownMask'] and int(f['value'],16)&int(f['knownMask'],16)==int(bound['eflagsValueUnderMask'],16)
footprint=[]
for offset in range(20):
 addr=S-52+offset;footprint.append({'address':hex(addr),'finalKnownMask':hex(state.known_mask(addr,1)),'lastSource':state.byte_sources(addr,1)[0],'lastWriter':state.byte_writers(addr,1)[0]})
# Canonical sampled words were never written, and seed reads use just entries27/28.
trigaddrs={0x5ddde8+256*i for i in range(40)}
assert not any(int(e['address'],16) in {a+j for a in trigaddrs for j in range(4)} for e in r['memoryWrites'])
trigreads=[e for e in r['memoryReads'] if int(e['address'],16) in trigaddrs]
seedreads=[e for e in r['memoryReads'] if e['pc']=='0x586011']
assert len(trigreads)==4096 and len(seedreads)==2048
assert Counter(int(e['address'],16) for e in seedreads)==Counter({0x586034+2*27:1408,0x586034+2*28:640})
report={'verdict':'ACCEPT_CONDITIONAL_SUNLIGHT_PREFIX_RESULT','reviewerOriginalInstructionsExecuted':0,'resultSha256':EXPECTED,'processReceiptSha256':sha((H/'sunlight-run01-process-receipt.json').read_bytes()),'driverSha256':m['driver']['sha256'],'approvalSha256':process['approval']['sha256'],'committedOriginalInstructions':198587,'predeclaredKnownMemoryFieldsVerified':43,'historicalPrefixCheckpointFieldsVerified':33,'projectionsVerified':3,'genuineCallsReturned':2055,'sqrtCallsReturned':2048,'sourceDerivedOrderedEventsVerified':len(expected),'eventCounts':counts,'replayHelperSha256':HELPER_SHA,'replayContractCanonicalSha256':contract_hash,'replayContractFileSha256':sha((OUT/'sunlight-run01-replay-contract.json').read_bytes()),'hostComputedOutputHashes':hosthash,'trigReads':4096,'trigInputWords':40,'sqrtSeedIndices':{'27':1408,'28':640},'abstractAllocationBytesRemainUnknown':1024,'paletteCacheBytesRemainUnknown':64,'pointerExpiredAndAliasUnknown':True,'finalCpuAndStackMatchPredeclaredContract':True,'omittedFootprintFinalProvenance':footprint,'selectedObservableLastWriters':lastwriters,'conditions':m['conditionalAssumptions'],'notRun':m['notRun'],'evidenceLimits':['Observer-event schedule was independently derived from the previously reviewed prefix and exact sunlight memory-access source, not by sorting this result by PC. The frozen pure helper replayed only masks/provenance.','Full CPU instruction chronology and register values are not independently replayed; code semantics, source PCs, call/return captures and final selected assertions supply those narrower checks.','Write events retain masks, not values. Both output table hashes are independently host-derived from explicitly conditioned canonical trig bytes.','Later genuine stack writes may redefine omitted-call footprint bytes; the known/unknown final state and last writers are reported, rather than falsely requiring the old footprint to remain unknown.','Canonical trig values at prefix entry, normal no-fault omitted FP return and scoped heap renaming remain explicit conditions. No terrain/constructor/gameplay or whole-camera equivalence is established.']}
(OUT/'sunlight-run01-post-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','committedOriginalInstructions','predeclaredKnownMemoryFieldsVerified','sourceDerivedOrderedEventsVerified','eventCounts','replayContractCanonicalSha256','reviewerOriginalInstructionsExecuted']}))
