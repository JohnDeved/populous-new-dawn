"""Independent static/host-math sunlight review. No CPU emulation or native code."""
from pathlib import Path
import hashlib,importlib.util,json,math,struct,collections
import capstone
ROOT=Path.cwd();BASE=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=BASE/'harness-repair';OUT=BASE/'review-boundary'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
spec=importlib.util.spec_from_file_location('static_reader',ROOT/'scripts/check-static-mission18-sky.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
pe=reader.PE32(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'))
audit=json.loads((H/'sunlight-source-audit.json').read_text());assert sha(pe.data)==audit['executable']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
assert sha(Path(audit['script']['path']).read_bytes())==audit['script']['sha256']
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);rows={}
for w in audit['windows']:
    lo,hi=int(w['start'],16),int(w['endExclusive'],16);raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo))
    assert sha(raw)==w['sha256'] and sum(i.size for i in ins)==len(raw)
    assert [{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]==w['instructions']
    rows.update({i.address:i for i in ins})
assert (rows[0x586011].mnemonic,rows[0x586011].op_str)==('movzx','ebx, word ptr [eax*2 + 0x586034]')
assert (rows[0x58600e].mnemonic,rows[0x58600e].op_str)==('bsr','eax, ecx')
assert (rows[0x58600c].mnemonic,rows[0x58600c].op_str)==('je','0x586029')
assert (rows[0x58601d].mnemonic,rows[0x58601d].op_str)==('div','ebx')
assert all(not i.mnemonic.startswith('f') and i.mnemonic not in ['int','syscall','sysenter','rdtsc'] for pc,i in rows.items() if 0x586000<=pc<0x586034)
peoff=struct.unpack_from('<I',pe.data,60)[0];optional=struct.unpack_from('<H',pe.data,peoff+20)[0]
for index,section in enumerate(pe.sections):
    if section['va']<=0x586000<section['va']+section['virtualSize']:
        flags=struct.unpack_from('<I',pe.data,peoff+24+optional+40*index+36)[0]
        assert section['name']=='CSEG' and section['va']==0x586000 and flags==0x60000020
seeds=struct.unpack('<32H',pe.read(0x586034,64));assert list(seeds)==audit['sqrtInput']['values']
assert sha(pe.read(0x586034,64))==audit['sqrtInput']['sha256']
MASK32=(1<<32)-1
def signed(value,bits):
    value&=(1<<bits)-1
    return value-(1<<bits) if value&(1<<(bits-1)) else value
def shifted_product(a,b):
    product=(a*b)&((1<<64)-1)
    eax,edx=product&MASK32,product>>32
    stitched=(eax>>16)|((edx<<16)&MASK32)
    return signed(signed(stitched,32)>>2,16)
reads=collections.Counter();indices=collections.Counter();norms=[];roots=[];divisions=[];out1=[];out2=[]
def table(base,index):
    addr=base+4*index;reads[addr]+=1
    return struct.unpack('<i',pe.read(addr,4))[0]
def root(value):
    assert 0<value<(1<<31)
    index=value.bit_length()-1;indices[index]+=1;guess=seeds[index];count=0
    while True:
        assert guess>0
        quotient=value//guess;count+=1
        assert quotient<(1<<31) and guess<(1<<31)
        if signed(quotient,32)>=signed(guess,32):break
        assert guess+quotient<1<<32
        guess=(guess+quotient)>>1
        assert count<32
    assert guess==math.isqrt(value);divisions.append(count);return guess
def idiv(n,d):
    q=abs(n)//abs(d)
    q=-q if (n<0)!=(d<0) else q
    assert -(1<<31)<=q<(1<<31)
    return q
for i in range(1024):
    index_a=(i&31)<<6;index_b=(i&~31)<<1
    ca,cb=table(0x5de5e8,index_a),table(0x5de5e8,index_b)
    sa,sb=table(0x5ddde8,index_a),table(0x5ddde8,index_b)
    x,y,z=shifted_product(ca,cb),shifted_product(sa,cb),signed(sb>>2,16)
    n=x*x+y*y+z*z;norms.append(n);d=root(n);roots.append(d)
    nx,ny,nz=(idiv(v<<8,d) for v in [x,y,z])
    brightness=max(0,147*(nx+ny+nz));product=15*brightness
    assert 0<=product<1<<31
    out1.append((28+(product>>16))&255)
    d=root(n);brightness=max(0,-200*idiv(z<<8,d));product=15*brightness
    assert 0<=product<1<<31
    out2.append((28+(product>>16))&255)
assert sorted(reads)==[0x5ddde8+i*256 for i in range(40)] and sum(reads.values())==4096
assert {hex(a):n for a,n in reads.items()}=={w['address']:w['readCount'] for w in audit['trigInputs']['words']}
for w in audit['trigInputs']['words']:
    raw=pe.read(int(w['address'],16),4);assert sha(raw)==w['sha256'] and struct.unpack('<i',raw)[0]==w['signedValue']
expect=audit['hostMathConditionalExpectations']
assert [min(norms),max(norms)]==expect['normRange'] and [min(divisions),max(divisions)]==expect['sqrtDivisionIterationsRange']
for raw,expected in zip([bytes(out1),bytes(out2)],expect['outputs']):assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
report={'verdict':'EXACT_CSEG_HELPER_DESIGN_VIABLE_TRIG_LIFETIME_AND_SEMANTICS_GATE_OPEN','originalInstructionsExecuted':0,
        'authorAuditSha256':sha((H/'sunlight-source-audit.json').read_bytes()),'canonicalInstructionRowsVerified':len(rows),
        'helperWindow':['0x586000','0x586034'],'firstCsegCharacteristics':'0x60000020','sqrtTable':{'address':'0x586034','words':32,'wordBytes':2,'bytes':64,'sha256':sha(pe.read(0x586034,64))},
        'trigReadDomain':{'base':'0x5ddde8','stride':256,'count':40,'sourceBytes':160,'totalReads':4096,'overlappingSinCosBases':True},
        'independentHostMath':{'iterations':1024,'sqrtCalls':2048,'normRange':[min(norms),max(norms)],'rootRange':[min(roots),max(roots)],'sqrtIndices':dict(indices),'divisionIterationsRange':[min(divisions),max(divisions)],'outputHashes':[sha(bytes(out1)),sha(bytes(out2))]},
        'requiredBeforeNativeAdmission':['Bind or explicitly condition the40 sampled writable .data words; raw PE values alone do not establish campaign-entry nonmutation.',
                                         'Fresh synthetic review of only required32-bit integer forms and accurate defined/undefined flag masks, zero/overflow faults and transactional rollback.',
                                         'RX mapping may cover page00586000 for hardware granularity, but execution hooks admit only00586000..00586034. No broad CSEG name or second-CSEG permission.',
                                         'Retain exact helper/table bytes and predeclare whole relevant output regions and continued unknown-state contract; no arithmetic helper return substitution.',
                                         'Fresh frozen-candidate review and separate parent release remain required.'],
        'claimLimit':'The two output hashes are independently reproduced host expectations conditioned on canonical trig values; neither original execution nor actual campaign-state equivalence is claimed.'}
(OUT/'sunlight-boundary-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'rowsVerified':len(rows),'trigWords':len(reads),'sqrtCallsHostOnly':len(divisions),'originalInstructionsExecuted':0}))
