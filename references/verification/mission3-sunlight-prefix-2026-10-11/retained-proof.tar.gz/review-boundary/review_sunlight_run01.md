# Sunlight prefix: independent post-run review

Accepted: the conditional selected-observable result for the actual source-ordered
0042b590 → 0042b5a8 prefix. The reviewer executed no original instructions.

- Result SHA256: e61d5f6bbf61ff8692fc948d4560aab525233b9996b668c93f73c0b8ce436f7a.
- Frozen driver: da1d0eb6b11cc024ef0ae9e843aaac7c380bab60c8dcd555073a7f0ae6ea0388.
- Post-review JSON: 73cd7039ba7de9a2b1020084171c88eb843541ef30174d62da419cc1c4098e80.
- Replay contract canonical digest: 6953dd549074f843787867043d833bd97dd2e9454e2eb49b0cb7212f3ed1fb4a.
- Replay contract file SHA256: be546ae8bc06d6e740d08408bef4eee727bdab628ad7533ef62d9d8b5b9a6fbf.

## Verified result

All 43 predeclared memory fields and the distinct final CPU/stack contract pass.
The historical 33-field reset/palette checkpoint and its complete CPU/unknown
contract match the previously reviewed result. The process receipt binds the
separately released approval, unchanged four drivers, canonical input/source
identity, exit 0, and 198,587 attempted/committed original instructions.

All 2,055 calls return with exact source caller/target/return/stack topology,
including 2,048 genuine sqrt calls. Every captured sqrt result matches independent
integer square root of the canonical-input norm. The two 1,024-byte output hashes
match independently computed integer lighting values. The 4,096 trig reads cover
the declared 40-word domain; sqrt seed indices 27/28 occur 1,408/640 times.

## Recorded-event and provenance checks

The wrapper independently constructed the complete expected memory-event schedule
from the already reviewed reset/palette source ordering and the exact sunlight
memory-access source. The known-positive norms exclude the zero-root paths; the
sqrt Newton loop has no repeated memory operations. Every source-derived event
matches the result in recorded ordinal order:

- 30,766 reads
- 128,181 committed byte writes
- 12 explicit invalidations
- 158,959 total observer events

The projection and expiry ordinals were derived from that schedule, not adopted
from the result. Canonical initial bytes/supply hashes, PC boundaries, omitted
windows, all 16 palette-copy iterations and exact per-event masks were checked
before supplying the independent contract to the frozen pure replay helper
SHA256 8a016740eef10a95e61e821b1a8adf5a9999025074e8b332ae2a32d9102d4f16.
The helper then reconstructed all memory masks and last-writer provenance.

Both omitted camera words remain unknown. All 1,024 abstract palette bytes, the
64-byte cache, expired pointer, unsupplied startup alias and outer saved-register
stack bytes remain unknown. The old 20-byte omitted-call footprint is legitimately
reused: its first four bytes hold the unknown saved ESI, and the remaining 16 have
source-identified native writes. No omitted value is thereby certified.

## Limits and next boundary

This is conditional on canonical sampled trig values at entry, normal/no-fault
return of the three omitted FP fragments, and the previously declared live,
disjoint palette allocation renaming. It does not prove pre-entry table lifetime,
whole-camera/rendering parity, or actual campaign capture.

The stream records observer order and memory masks, not full CPU retirement or
memory values. Final values are supported by the frozen assertions and independent
source/host arithmetic. Register invalidations are descriptor-checked; the pure
helper does not reconstruct registers. No performance improvement was measured.

The next finite setup edge is the call at 0042b5a8 to 0044fa30, stopping before the
following call. Its complete source dependencies, mutable reads, integer forms
and selected outputs need their own bounded review. This result admits no terrain
mask, command/tribe/pool/bank initialization, allocator, record constructor,
postpass or gameplay execution.
