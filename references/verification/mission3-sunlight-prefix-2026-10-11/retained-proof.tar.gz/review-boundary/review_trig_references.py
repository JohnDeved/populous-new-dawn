"""Decode retained Ghidra xrefs against canonical bytes; no native execution."""
from pathlib import Path
import collections,hashlib,importlib.util,json
import capstone
ROOT=Path.cwd();BASE=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';OUT=BASE/'review-boundary'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
s=importlib.util.spec_from_file_location('static_reader',ROOT/'scripts/check-static-mission18-sky.py');reader=importlib.util.module_from_spec(s);s.loader.exec_module(reader)
pe=reader.PE32(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'))
assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
records=[]
for file in ['trig-references.tsv','sqrt-references.tsv']:
    for line in (BASE/file).read_text().splitlines():
        dest,source,kind,function,ghidra=line.split('\t');pc=int(source,16)
        ins=next(cs.disasm(pe.read(pc,15),pc));assert ins.address==pc
        memories=[o for o in ins.operands if o.type==capstone.x86.X86_OP_MEM]
        assert len(memories)==1
        mem=memories[0];assert not mem.access&capstone.CS_AC_WRITE
        if ins.mnemonic=='lea':
            category='local address construction'
            assert pc in [0x4733f4,0x47340d]
        else:
            assert ins.mnemonic in ['mov','movzx','imul','fild','fimul']
            category='indirect local-alias read' if pc in [0x473413,0x473444] else 'indexed/absolute memory read'
        records.append({'file':file,'target':dest,'pc':hex(pc),'ghidraReferenceType':kind,'function':function,
                        'bytes':ins.bytes.hex(),'mnemonic':ins.mnemonic,'operands':ins.op_str,'classification':category})
trig=[r for r in records if r['file']=='trig-references.tsv'];sqrt=[r for r in records if r['file']=='sqrt-references.tsv']
assert len(trig)==154 and len(set(r['pc'] for r in trig))==150
counts=collections.Counter(r['classification'] for r in trig)
assert counts=={'indexed/absolute memory read':150,'local address construction':2,'indirect local-alias read':2}
assert len(sqrt)==2 and set(r['pc'] for r in sqrt)=={'0x586011'}
assert set(r['pc'] for r in trig if r['function']=='NO_FUNCTION')=={'0x47ff7f','0x47ff93'}
raw=pe.read(0x42a070,0x26);helper=list(cs.disasm(raw,0x42a070));assert sum(i.size for i in helper)==len(raw)
assert [(i.mnemonic,i.op_str) for i in helper[:3]]==[('mov','eax, dword ptr [esp + 4]'),('mov','edx, 0x4000'),('xor','ecx, ecx')]
assert not any('ebx' in i.op_str or i.mnemonic=='call' for i in helper)
report={'verdict':'FINITE_XREF_OPERAND_AUDIT_PASSED_NOT_UNIVERSAL_NONMUTATION_PROOF','originalInstructionsExecuted':0,
        'trigRows':154,'trigDistinctInstructionPcs':150,'trigClassifications':dict(counts),'sqrtRows':2,'sqrtDistinctInstructionPcs':1,
        'inputHashes':{f:sha((BASE/f).read_bytes()) for f in ['trig-references.tsv','trig-references-receipt.json','sqrt-references.tsv','sqrt-references-receipt.json']},
        'decodedReferences':records,'ecxAliasKill':{'caller':'0x473493','target':'0x42a070','kill':'0x42a079 XOR ECX,ECX','completeHelperSha256':sha(raw),'ebxUntouched':True},
        'ebxAliasStatus':'Local loop only reads EBX; remaining call/epilogue lifetime is being closed by the author and is not silently assumed here.',
        'limits':['Ghidra DATA is not equivalent to pointer address-taking; operand semantics distinguish the two LEAs from memory loads.',
                  'All retained direct/reference-resolved operands are non-writing. This does not rule out arbitrary bulk writes, unrepresented computed aliases or changed pre-entry history.',
                  'A bounded native continuation must explicitly condition canonical sampled trig values and reject writes to the supplied words throughout its prefix, unless stronger actual-entry provenance is separately established.',
                  'No new original execution is admitted by this source-only reference audit.']}
(OUT/'trig-reference-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','trigRows','trigDistinctInstructionPcs','trigClassifications','sqrtRows','originalInstructionsExecuted']}))
