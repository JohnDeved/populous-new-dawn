#!/usr/bin/env python3
"""Separately gated conditional reset/palette/sunlight prefix.

Original execution requires exact fresh review AND parent lane release. The new
integer operations are finite 32-bit forms. Three prior camera omissions remain
conditional. Canonical sampled trig words are an explicit entry condition.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, platform, struct, sys
HERE=Path(__file__).resolve().parent
PREFIX=HERE/'reset_palette_candidate.py'
PREFIX_SHA='8c79bb31264c233a6878136539f20339952b5085a200cd95b006e658048a8915'
if hashlib.sha256(PREFIX.read_bytes()).hexdigest()!=PREFIX_SHA:raise RuntimeError('Frozen reset/palette drift')
spec=importlib.util.spec_from_file_location('frozen_reset_palette',PREFIX)
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);p=q.p;b=q.b
ENTRY,STOP=0x42b590,0x42b5a8
SCOPE='conditional-source-ordered-reset-palette-sunlight-prefix'
WINDOWS=b.RESET_WINDOWS+[(ENTRY,STOP),(0x4a2920,0x4a2944),(0x401040,0x40108a),(0x401790,0x40191a),(0x586000,0x586034)]
TRIG=[0x5ddde8+256*i for i in range(40)]
SEEDS=(1,2,2,4,5,8,11,16,22,32,45,64,90,128,181,256,362,512,724,1024,1448,2048,2896,4096,5792,8192,11585,16384,23170,32768,46340,65535)
REASONS={'stack':'omitted __ftol stack footprint','gpr':'omitted __ftol result','flags':'omitted __ftol arithmetic flags','camera':'omitted floating-derived camera output','relocation':'heap-renamed ADD arithmetic flags','expiry':'palette pointer scope expired'}

class Sunlight(q.ResetPalette):
    def __init__(self,*args,enforce_prefix=True,protected_inputs=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.event_ordinal=0;self.invalidation_events=[];self.enforce_prefix=enforce_prefix
        self.prefix_claims=None;self.prefix_boundary=None
        self.protected_inputs=TRIG if protected_inputs is None else protected_inputs
    def ordinal(self):
        value=self.event_ordinal;self.event_ordinal+=1;return value
    def memory_event(self,kind,event):
        event={**event,'eventOrdinal':self.ordinal()}
        super().memory_event(kind,event)
    def invalidation(self,pc,target,size,mask,reason,**location):
        self.invalidation_events.append({'eventOrdinal':self.ordinal(),'pc':hex(pc),'target':target,'size':size,'knownMask':hex(mask),'reason':reason,**location})
    def event_stream(self):
        return {'schemaVersion':1,'ordering':'observer','eventCount':self.event_ordinal,
          'firstOrdinal':0 if self.event_ordinal else None,'lastOrdinal':self.event_ordinal-1 if self.event_ordinal else None,
          'counts':{'memoryReads':len(self.read_events),'memoryWrites':len(self.write_events),'invalidationEvents':len(self.invalidation_events)}}
    def commit(self):
        pc=self.pending['address'] if self.pending else None
        super().commit()
        if pc==0x4a292d and self.enforce_palette_context:
            self.invalidation(pc,'register',4,self.shadow.reg['eflags'],REASONS['relocation'],register='eflags')
    def close_palette_scope(self):
        if self.palette_scope_closed:raise b.Blocked('palette scope expired twice')
        super().close_palette_scope()
        self.invalidation(q.STOP,'memory',4,0,REASONS['expiry'],address=hex(q.PALETTE_SLOT))
    def _code(self,c,a,n,unused):
        if a==q.STOP and self.enforce_prefix:
            try:
                self.commit();self.close_palette_scope()
                self.prefix_claims=q.assert_claims(self);self.prefix_boundary=self.register_snapshot()
            except b.Blocked as error:self.fail(error)
        count=len(self.projections)
        super()._code(c,a,n,unused)
        if len(self.projections)>count:
            fragment=self.projections[-1]
            if fragment['omittedCall'] is not None:
                # Mirrors the exact host invalidation order in the frozen base.
                first,last=fragment['invalidations']
                self.invalidation(a,'memory',first['size'],0,REASONS['stack'],address=first['address'])
                for reg in ('eax','edx'):
                    self.invalidation(a,'register',4,0,REASONS['gpr'],register=reg)
                self.invalidation(a,'register',4,self.shadow.reg['eflags'],REASONS['flags'],register='eflags')
                self.invalidation(a,'memory',last['size'],0,REASONS['camera'],address=last['address'])
    def _write(self,c,access,a,n,value,unused):
        if any(a<word+4 and word<a+n for word in self.protected_inputs):
            self.fail(b.Blocked('write overlaps conditioned trig input',address=hex(a),size=n))
        super()._write(c,access,a,n,value,unused)
    def _plan(self,ins):
        m=ins.mnemonic;ops=ins.operands;x=self.cs_module.x86;plan=self.pending
        new={'shl','shr','sar','imul','cdq','idiv','div','neg','bsr'}
        if m not in new:return super()._plan(ins)
        if any(ins.prefix):raise b.Blocked('unsupported integer prefix')
        if any(op.size!=4 for op in ops if op.type!=x.X86_OP_IMM):raise b.Blocked('integer extension requires 32-bit operands')
        if m in ('shl','shr','sar'):
            if len(ops)!=2 or ops[0].type!=x.X86_OP_REG or ops[1].type!=x.X86_OP_IMM:raise b.Blocked('only immediate-count register shifts admitted')
            count=ops[1].imm&31
            if not count:return # No destination/flags consumption or change.
            self.scalar(ops[0],ins);self.destination(ops[0],b.MASK32,ins)
            self.flags(b.CF|b.PF|b.ZF|b.SF|(b.OF if count==1 else 0));return
        if m=='imul':
            if len(ops)==1:
                self.require(self.shadow.reg_get('eax'),b.MASK32,'IMUL accumulator');self.scalar(ops[0],ins)
                plan['registers'].update(eax=b.MASK32,edx=b.MASK32)
            elif len(ops)==2 and ops[0].type==x.X86_OP_REG:
                self.scalar(ops[0],ins);self.scalar(ops[1],ins);self.destination(ops[0],b.MASK32,ins)
            else:raise b.Blocked('only one/two operand IMUL forms admitted')
            self.flags(b.CF|b.OF);return
        if m=='cdq':
            if ops:raise b.Blocked('unexpected CDQ operands')
            self.require(self.shadow.reg_get('eax'),b.MASK32,'CDQ accumulator')
            plan['registers']['edx']=b.MASK32;return
        if m in ('div','idiv'):
            if len(ops)!=1 or ops[0].type!=x.X86_OP_REG:raise b.Blocked('only 32-bit register divisor admitted')
            for reg in ('eax','edx'):self.require(self.shadow.reg_get(reg),b.MASK32,'division dividend',register=reg)
            self.scalar(ops[0],ins) # Native fault (if any) aborts/rolls back, never commits these masks.
            plan['registers'].update(eax=b.MASK32,edx=b.MASK32);self.flags(0);return
        if m=='neg':
            if len(ops)!=1 or ops[0].type!=x.X86_OP_REG:raise b.Blocked('only register NEG admitted')
            self.scalar(ops[0],ins);self.destination(ops[0],b.MASK32,ins);self.flags(b.ARITH);return
        if m=='bsr':
            if len(ops)!=2 or any(op.type!=x.X86_OP_REG for op in ops):raise b.Blocked('only register BSR admitted')
            value=self.scalar(ops[1],ins)
            self.destination(ops[0],b.MASK32 if value else 0,ins);self.flags(b.ZF);return


def observable_spec():
    result=q.observable_spec()
    for address,size,value in [(0x937aa8,2,147),(0x937aaa,2,147),(0x937aac,2,147),(0x937aae,1,28),(0x937aaf,1,15),(0x937ab0,1,32)]:
        result.append({'name':'sunlight_constant_'+hex(address),'address':hex(address),'bytes':size,'expectedValue':value,'requiredKnownMask':hex((1<<(8*size))-1)})
    for name,address,size,digest in [
      ('sunlight_table_primary',0x89bc8e,1024,'aa4787ac8921047228e66966915a1703b2592ccbd0dfed77f41e836c9e46227d'),
      ('sunlight_table_secondary',0x89c08e,1024,'997ab09f7e99c3d05b9cc78d4252b261fc7b6daab301bdaf24bdba0e3b344a1f'),
      ('sunlight_scratch_zero',0x937c46,3050,b.sha(bytes(3050))),('sunlight_final_zero',0x96aa7c,2,b.sha(bytes(2)))]:
        result.append({'name':name,'address':hex(address),'bytes':size,'expectedSha256':digest,'requireEveryBitKnown':True})
    return result


def invalidation_contract():
    events=[]
    for pc,word in [(0x42cfe7,0x5fe3f4),(0x42d001,0x5fe3f0)]:
        # Outer pushes8 + reset CALL4 + reset pushes8 + wrapper CALL4 + camera pushes8.
        events.append({'pc':hex(pc),'target':'memory','size':20,'knownMask':'0x0','reason':REASONS['stack'],'address':hex(b.STACK-52)})
        for reg in ('eax','edx'):events.append({'pc':hex(pc),'target':'register','size':4,'knownMask':'0x0','reason':REASONS['gpr'],'register':reg})
        events.append({'pc':hex(pc),'target':'register','size':4,'knownMask':hex(b.DF),'reason':REASONS['flags'],'register':'eflags'})
        events.append({'pc':hex(pc),'target':'memory','size':4,'knownMask':'0x0','reason':REASONS['camera'],'address':hex(word)})
    events.append({'pc':'0x4a292d','target':'register','size':4,'knownMask':hex(b.DF),'reason':REASONS['relocation'],'register':'eflags'})
    events.append({'pc':hex(q.STOP),'target':'memory','size':4,'knownMask':'0x0','reason':REASONS['expiry'],'address':hex(q.PALETTE_SLOT)})
    return events


def prepare(out):
    pe,base,prefix=q.prepare(out)
    import capstone
    cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
    windows=[]
    for lo,hi in WINDOWS:
        raw=pe.read(lo,hi-lo);instructions=list(cs.disasm(raw,lo))
        if sum(i.size for i in instructions)!=len(raw):raise b.Blocked('split sunlight code window',address=hex(lo))
        windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw)})
    if struct.unpack('<32H',pe.read(0x586034,64))!=SEEDS:raise b.Blocked('sqrt seed table drift')
    data=pe.data;header=struct.unpack_from('<I',data,60)[0];opt=struct.unpack_from('<H',data,header+20)[0]
    cseg=next((s for i,s in enumerate(pe.sections) if s['va']==0x586000 and struct.unpack_from('<I',data,header+24+opt+i*40+36)[0]==0x60000020),None)
    if cseg is None:raise b.Blocked('exact sqrt executable section mismatch')
    trig=[{'address':hex(a),'bytesHex':pe.read(a,4).hex(),'sha256':b.sha(pe.read(a,4))} for a in TRIG]
    m={'status':'PREPARED_SUNLIGHT_NOT_EXECUTED','originalInstructionsExecuted':0,'scope':SCOPE,
      'driver':b.file_record(Path(__file__)),'frozenPrefix':b.file_record(PREFIX),'projectedReset':b.file_record(q.PROJECTED),'frozenEngine':b.file_record(p.BASE_DRIVER),
      'source':prefix['source'],'inputs':prefix['inputs'],'executable':prefix['executable'],
      'entry':hex(ENTRY),'expectedStop':hex(STOP),'allowedWindows':windows,
      'omittedFragments':prefix['omittedFragments'],'heapContract':prefix['heapContract'],
      'prefixBoundaryContract':prefix['boundaryContract'],'prefixUnknownOutputs':prefix['requiredUnknownOutputs'],
      'conditionalAssumptions':prefix['conditionalAssumptions']+['The40 sampled mutable trig DWORDs equal the canonical EXE bytes at prefix entry; pre-entry lifetime/nonmutation is not proved.'],
      'trigInputs':{'words':trig,'bytes':160,'readCount':4096,'protection':'All overlapping writes to the160 sampled bytes abort; containing pages are read-only during this bounded prefix.'},
      'sqrtTable':{'address':'0x586034','bytesHex':pe.read(0x586034,64).hex(),'source':'original read-only CSEG, flags0x60000020','allowedCode':['0x586000','0x586034']},
      'selectedObservables':observable_spec(),'expectedInvalidationEvents':invalidation_contract(),
      'finalBoundaryContract':{'knownRegisters':{'eax':0,'ebx':0,'ecx':0,'edx':0,'edi':0x8979d3,'esp':b.STACK-8,'eip':STOP},'unknownRegisters':['esi','ebp'],'eflagsKnownMask':hex(b.DF|(b.ARITH&~b.AF)),'eflagsValueUnderMask':hex(b.PF|b.ZF),'savedOuterStack':{'address':hex(b.STACK-8),'bytes':8,'knownMask':'0x0'}},
      'eventSchema':{'schemaVersion':1,'ordering':'observer','ordinal':'zero-based contiguous across actual reads, committed byte writes and explicit invalidationEvents; not CPU retirement','registerLimit':'Register invalidation descriptors are checked; full register history is not replayed.','attemptedWrites':'No committed ordinal; aborted instruction records retained.'},
      'newDependencyResolved':'Actual caller order through integer sunlight initialization, preserving reset RNG/class counters and unknown palette/camera outputs under the declared input/normal-return conditions.',
      'notRun':['terrain mask','command initialization','tribe reset','pool/terrain setup','bank6','allocator','record constructor','postpass','gameplay']}
    b.json_write(out/'sunlight-preflight.json',m);return pe,base,m


def approval_bindings(m):
    digest=lambda v:b.sha(json.dumps(v,sort_keys=True).encode())
    return {'verdict':'ACCEPT_SUNLIGHT_PREFIX','parentReleasedRunLane':True,'scope':SCOPE,
      'driverSha256':b.sha(Path(__file__).read_bytes()),'frozenPrefixSha256':PREFIX_SHA,'projectedResetSha256':q.PROJECTED_SHA,'frozenEngineSha256':p.BASE_SHA,
      'observedSourceHead':m['source']['observedSourceHead'],'sourceBindingSha256':digest(m['source']),'inputBindingSha256':digest(m['inputs']),
      'scopeBindingSha256':digest({key:m[key] for key in ['entry','expectedStop','allowedWindows','omittedFragments','heapContract','prefixBoundaryContract','prefixUnknownOutputs','conditionalAssumptions','trigInputs','sqrtTable','selectedObservables','expectedInvalidationEvents','finalBoundaryContract','eventSchema']})}


def validate_approval(approval,m):
    for key,value in approval_bindings(m).items():
        if approval.get(key)!=value:raise b.Blocked('missing/stale sunlight review or parent lane release',field=key)
    if m['source']['trackedStatus']:raise b.Blocked('tracked source drift')


def assert_claims(e,m):
    if e.prefix_claims is None or not e.palette_scope_closed:raise b.Blocked('prior prefix boundary was not asserted')
    if e.frames or e.allocations or e.aborted:raise b.Blocked('unexpected calls/allocations/aborts at sunlight stop')
    claims=[]
    for field in m['selectedObservables']:
        a,n=int(field['address'],16),field['bytes'];raw=bytes(e.cpu.mem_read(a,n));mask=e.shadow.get(a,n)
        if mask!=(1<<(8*n))-1:raise b.Blocked('selected sunlight output not fully known',claim=field['name'])
        result={'name':field['name'],'address':hex(a),'bytes':n,'knownMask':hex(mask),'sha256':b.sha(raw)}
        if 'expectedValue' in field:
            result['value']=int.from_bytes(raw,'little')
            if result['value']!=field['expectedValue']:raise b.Blocked('selected sunlight value incorrect',claim=field['name'])
        elif result['sha256']!=field['expectedSha256']:raise b.Blocked('selected sunlight bytes incorrect',claim=field['name'])
        claims.append(result)
    for a,n in [(q.DEST,64),(q.PAL,1024),(q.PALETTE_SLOT,4),(0x59df24,4),(0x5fe3f0,8),(b.STACK-8,8)]:
        if e.shadow.get(a,n):raise b.Blocked('required unknown output falsely known',address=hex(a))
    boundary=m['finalBoundaryContract']
    for reg,value in boundary['knownRegisters'].items():
        if e.shadow.reg_get(reg)!=b.MASK32 or e.reg_value(reg)!=value:raise b.Blocked('sunlight register contract mismatch',register=reg)
    for reg in boundary['unknownRegisters']:
        if e.shadow.reg_get(reg):raise b.Blocked('sunlight preserved register falsely known',register=reg)
    mask=int(boundary['eflagsKnownMask'],16)
    if e.shadow.reg['eflags']!=mask or e.reg_value('eflags')&mask!=int(boundary['eflagsValueUnderMask'],16):raise b.Blocked('sunlight final flags mismatch')
    actual=[{k:v for k,v in event.items() if k!='eventOrdinal'} for event in e.invalidation_events]
    if actual!=m['expectedInvalidationEvents']:raise b.Blocked('invalidation chronology differs from predeclared contract',actual=actual)
    events=e.read_events+e.write_events+e.invalidation_events
    if sorted(event['eventOrdinal'] for event in events)!=list(range(e.event_ordinal)):raise b.Blocked('event ordinal gap/duplication')
    if len(e.projections)!=3:raise b.Blocked('camera projection count drift')
    trig_reads=[r for r in e.read_events if int(r['address'],16) in TRIG]
    if len(trig_reads)!=4096 or any(r['size']!=4 or r['knownMask']!='0xffffffff' for r in trig_reads):raise b.Blocked('trig read coverage mismatch')
    for word in m['trigInputs']['words']:
        a=int(word['address'],16)
        if bytes(e.cpu.mem_read(a,4)).hex()!=word['bytesHex'] or e.shadow.get(a,4)!=b.MASK32:raise b.Blocked('conditioned trig input changed')
    calls=[c for c in e.events if c['target']=='0x586000']
    if len(calls)!=2048 or any(not c['returned'] for c in calls):raise b.Blocked('sqrt call coverage mismatch')
    return claims


def execute(pe,base,m,approval,out):
    validate_approval(approval,m) # Must precede CPU construction.
    import unicorn,capstone
    helper=b.load_module('sunlight_native_helper',b.ROOT/'scripts/decomp.py')
    cpu,identity=helper.native_cpu(b.EXE);cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
    e=Sunlight(cpu,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],WINDOWS,iat=pe.imports)
    for section in pe.sections:
        perms=unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE
        if section['name']=='.text':perms=unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC
        cpu.mem_protect(section['va'],(max(section['virtualSize'],section['rawSize'])+4095)&~4095,perms)
    cpu.mem_protect(0x586000,4096,unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC)
    cpu.mem_protect(b.SCRATCH,b.SCRATCH_END-b.SCRATCH,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    for a,data in b.constant_writes(pe):e.supply(a,data,'verified constant.dat descriptor projection; frozen prerequisite')
    e.reg_supply('esp',b.STACK,b.MASK32,'cdecl diagnostic stack, not campaign capture')
    e.reg_supply('eflags',2,b.DF,'cdecl DF=0 only')
    e.supply(b.STACK,struct.pack('<I',b.STOP),'unused outer diagnostic return sentinel')
    e.supply(q.PALETTE_SLOT,struct.pack('<I',q.PAL),'declared live/disjoint heap-location renaming scoped to palette helper; all content unknown')
    for word in m['trigInputs']['words']:e.supply(int(word['address'],16),bytes.fromhex(word['bytesHex']),'explicit canonical sampled-trig input condition; lifetime before entry not proved')
    e.supply(0x586034,bytes.fromhex(m['sqrtTable']['bytesHex']),'canonical read-only CSEG sqrt seed constants')
    for page in sorted({a&~4095 for a in TRIG}):cpu.mem_protect(page,4096,unicorn.UC_PROT_READ)
    e.phase='conditional actual reset/palette/sunlight prefix';before=e.snapshot();claims=[];error=None
    try:
        e.run(ENTRY,STOP,timeout_us=180_000_000);claims=assert_claims(e,m);status='SUNLIGHT_PREFIX_SELECTED_OBSERVABLES_PASSED'
    except BaseException as exc:status='BLOCKED_SUNLIGHT_PREFIX';error={'type':type(exc).__name__,'message':str(exc)}
    result={'status':status,'scope':SCOPE,'identity':identity,'tools':{'python':sys.version,'unicorn':unicorn.__version__,'capstone':capstone.__version__,'platform':platform.platform()},
      'conditionalAssumptions':m['conditionalAssumptions'],'heapContract':m['heapContract'],'trigInputs':m['trigInputs'],
      'attemptedOriginalInstructions':e.attempted,'committedOriginalInstructions':e.committed,'projections':e.projections,
      'selectedObservableAssertions':claims,'prefixObservableAssertions':e.prefix_claims,'prefixBoundary':e.prefix_boundary,
      'before':before,'after':e.snapshot(),'blocker':e.blocker,'error':error,'calls':e.events,'openCalls':e.frames,'allocations':e.allocations,
      'abortedInstructions':e.aborted,'suppliedInputs':e.supplies,'memoryReads':e.read_events,'memoryWrites':e.write_events,
      'invalidationEvents':e.invalidation_events,'eventStream':e.event_stream(),'relocatedFlagEvents':e.relocated_flag_events,
      'paletteScopeClosed':e.palette_scope_closed,'paletteCacheKnownMask':hex(e.shadow.get(q.DEST,64)),
      'expiredPalettePointer':e.observed(q.PALETTE_SLOT,4),'unsuppliedPaletteAlias':e.observed(0x59df24,4),
      'omittedWords':[e.observed(p.CAMERA+offset,4) for offset in [0x100,0x104]],'abstractAllocationKnownMask':hex(e.shadow.get(q.PAL,1024)),
      'savedOuterStack':e.observed(b.STACK-8,8),'boundaryContract':m['finalBoundaryContract'],'recordsVisited':0,'notRun':m['notRun'],
      'driver':b.file_record(Path(__file__)),'frozenPrefix':b.file_record(PREFIX),'projectedReset':b.file_record(q.PROJECTED),'frozenEngine':b.file_record(p.BASE_DRIVER)}
    b.json_write(out/'sunlight-result.json',result);return result


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['prepare','run-prefix']);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--approval',type=Path);args=ap.parse_args()
    if args.out.exists():raise b.Blocked('output directory must be new')
    args.out.mkdir(parents=True);pe,base,m=prepare(args.out)
    if args.mode=='prepare':print(json.dumps({'status':m['status'],'originalInstructionsExecuted':0}));return
    if not args.approval:raise b.Blocked('fresh sunlight review and parent release required before CPU construction')
    result=execute(pe,base,m,json.loads(args.approval.read_text()),args.out)
    print(json.dumps({'status':result['status'],'committedOriginalInstructions':result['committedOriginalInstructions'],'error':result['error']}))
    if result['status'].startswith('BLOCKED'):raise SystemExit(2)
if __name__=='__main__':main()
