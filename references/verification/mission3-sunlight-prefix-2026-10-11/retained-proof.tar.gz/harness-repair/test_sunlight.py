"""Authored synthetic x86 and static contracts only; no canonical native execution."""
import json,struct,unittest
from unittest.mock import patch
import unicorn
from unicorn import x86_const as x
import sunlight_candidate as s
import test_reset_palette as oldcopy
import test_projected_reset as oldprojection
b=s.b
CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00

class IntegerTests(unittest.TestCase):
 def make(self,code,regs=None,flags=2|b.CF|b.ZF,flagmask=b.MASK32):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:c.mem_map(a,4096)
  c.mem_write(CODE,code+b'\xc3')
  e=s.Sunlight(c,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(code)+1)],enforce_prefix=False,enforce_palette_context=False)
  e.reg_supply('esp',STACK,b.MASK32,'synthetic stack');e.supply(STACK,struct.pack('<I',STOP),'synthetic return')
  e.reg_supply('eflags',flags,flagmask,'synthetic flags')
  for reg,value in (regs or {}).items():e.reg_supply(reg,value&b.MASK32,b.MASK32,'synthetic arithmetic operand')
  return e
 def test_signed_one_operand_multiply_defines_high_half(self):
  e=self.make(bytes.fromhex('f7e9'),{'eax':-3,'ecx':5});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eax'),(-15)&b.MASK32);self.assertEqual(e.reg_value('edx'),b.MASK32)
  self.assertEqual(e.shadow.reg_get('edx'),b.MASK32);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.OF)
 def test_two_operand_multiply_overflow_flags_only(self):
  e=self.make(bytes.fromhex('0fafc1'),{'eax':0x7fffffff,'ecx':2});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eax'),0xfffffffe);self.assertEqual(e.reg_value('eflags')&(b.CF|b.OF),b.CF|b.OF)
  self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.OF)
 def test_imul_unknown_and_undefined_branch_fail_closed(self):
  e=self.make(bytes.fromhex('f7e9'),{'eax':3});e.shadow.reg_put('ecx',0)
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  e=self.make(bytes.fromhex('0fafc17400'),{'eax':3,'ecx':2})
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
  self.assertEqual(e.committed,1)
 def test_cdq_defines_edx_preserves_flags(self):
  for value,high in [(-3,b.MASK32),(3,0)]:
   e=self.make(b'\x99',{'eax':value});before=e.reg_value('eflags');e.run(CODE,STOP)
   self.assertEqual(e.reg_value('edx'),high);self.assertEqual(e.reg_value('eflags'),before);self.assertEqual(e.shadow.reg['eflags'],b.MASK32)
 def test_signed_division_truncates_toward_zero(self):
  e=self.make(bytes.fromhex('f7f9'),{'eax':-17,'edx':-1,'ecx':5});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eax'),(-3)&b.MASK32);self.assertEqual(e.reg_value('edx'),(-2)&b.MASK32)
  self.assertEqual(e.shadow.reg['eflags']&b.ARITH,0)
 def test_unsigned_division_uses_high_half(self):
  e=self.make(bytes.fromhex('f7f3'),{'eax':8,'edx':1,'ebx':3});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eax'),(2**32+8)//3);self.assertEqual(e.reg_value('edx'),(2**32+8)%3)
 def test_divide_zero_and_overflow_rollback(self):
  for code,regs in [(bytes.fromhex('f7f3'),{'eax':7,'edx':0,'ebx':0}),
    (bytes.fromhex('f7f3'),{'eax':0,'edx':1,'ebx':1}),
    (bytes.fromhex('f7f9'),{'eax':0x80000000,'edx':-1,'ecx':-1})]:
   e=self.make(code,regs);before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events)
   for reg in ['eax','edx','eflags']:self.assertEqual(e.register_snapshot()[reg],before[reg])
   self.assertTrue(e.aborted);self.assertNotIn('eventOrdinal',e.aborted[0])
 def test_division_unknown_operand_or_flags_abort(self):
  e=self.make(bytes.fromhex('f7f3'),{'eax':7,'ebx':3})
  with self.assertRaisesRegex(b.Blocked,'division dividend'):e.run(CODE,STOP)
  e=self.make(bytes.fromhex('f7f37400'),{'eax':7,'edx':0,'ebx':3})
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
 def test_bsr_nonzero_and_zero_masks(self):
  for value,index in [(1,0),(0x80000000,31)]:
   e=self.make(bytes.fromhex('0fbdc1'),{'ecx':value});e.run(CODE,STOP)
   self.assertEqual(e.reg_value('eax'),index);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ZF)
  e=self.make(bytes.fromhex('0fbdc1'),{'ecx':0,'eax':123});e.run(CODE,STOP)
  self.assertEqual(e.shadow.reg_get('eax'),0);self.assertTrue(e.reg_value('eflags')&b.ZF)
 def test_bsr_undefined_flags_cannot_drive_branch(self):
  e=self.make(bytes.fromhex('0fbdc17700'),{'ecx':10})
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
 def test_shift_zero_preserves_unknown_register_and_flags(self):
  for code in ['c1e000','c1e820','c1f840']:
   e=self.make(bytes.fromhex(code),{'eax':0x80000000},flagmask=0);e.shadow.reg_put('eax',0x1234);before=e.reg_value('eflags');e.run(CODE,STOP)
   self.assertEqual(e.reg_value('eax'),0x80000000);self.assertEqual(e.shadow.reg_get('eax'),0x1234)
   self.assertEqual(e.shadow.reg['eflags'],0);self.assertEqual(e.reg_value('eflags'),before)
 def test_shift_results_and_defined_flags(self):
  for code,wanted,count in [('d1e0',0,1),('c1e810',0x8000,16),('c1f802',0xe0000000,2)]:
   e=self.make(bytes.fromhex(code),{'eax':0x80000000});e.run(CODE,STOP)
   self.assertEqual(e.reg_value('eax'),wanted)
   self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.PF|b.SF|b.ZF|(b.OF if count==1 else 0))
 def test_multibit_shift_undefined_overflow_cannot_branch(self):
  e=self.make(bytes.fromhex('c1e0027000'),{'eax':1})
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
 def test_neg_flags_and_result(self):
  e=self.make(bytes.fromhex('f7d9'),{'ecx':0x80000000});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('ecx'),0x80000000);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ARITH);self.assertTrue(e.reg_value('eflags')&b.OF)
 def test_unsupported_forms_widths_prefixes_and_unknown_inputs(self):
  for code in ['66f7e9','d3e0','6bc003','66f7f3','f0f7d9']:
   e=self.make(bytes.fromhex(code),{'eax':1,'ecx':1,'edx':0,'ebx':1})
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
  for code in ['c1e006','f7d9','0fbdc1','99']:
   e=self.make(bytes.fromhex(code))
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
 def test_exact_cseg_window_does_not_allow_adjacent_code(self):
  e=self.make(b'\x90');e.windows=[(0x586000,0x586034)]
  e.check_target(0x586033)
  for address in [0x585fff,0x586034,0x586100,0xd0e000]:
   with self.assertRaises(b.Blocked):e.check_target(address)

class EventTests(unittest.TestCase):
 def copy(self,**kw):
  with patch.object(oldcopy.q,'ResetPalette',lambda *a,**k:s.Sunlight(*a,enforce_prefix=False,**k)):
   return oldcopy.CopyTests().make(**kw)
 def check(self,e):
  allrows=e.read_events+e.write_events+e.invalidation_events
  self.assertEqual(sorted(r['eventOrdinal'] for r in allrows),list(range(e.event_ordinal)))
  self.assertEqual(e.event_stream()['eventCount'],len(allrows))
 def test_rep_order_overlap_and_mixed_masks(self):
  e=self.copy(src=oldcopy.SOURCE,dst=oldcopy.SOURCE+4);e.cpu.mem_write(oldcopy.SOURCE,b'abcdefghijklmnop');e.shadow.put(oldcopy.SOURCE,4,0x12345678)
  e.run(oldcopy.CODE,oldcopy.STOP);self.check(e)
  rows=sorted(e.read_events+e.write_events,key=lambda r:r['eventOrdinal'])
  self.assertEqual([r['eventOrdinal'] for r in e.read_events],[0,5,10,15])
  self.assertEqual([e.shadow.get(oldcopy.SOURCE+4*i,4) for i in range(4)],[0x12345678]*4)
  self.assertEqual([r['knownMask'] for r in rows[:5]],['0x12345678','0x78','0x56','0x34','0x12'])
 def test_rep_fault_assigns_no_ordinal_to_attempted_writes(self):
  e=self.copy(dst=oldcopy.DEST+4090,count=2);e.supply(oldcopy.SOURCE,b'abcdefgh','synthetic source');e.cpu.mem_write(oldcopy.DEST+4090,b'123456')
  with self.assertRaises(b.Blocked):e.run(oldcopy.CODE,oldcopy.STOP)
  self.check(e);self.assertEqual(len(e.write_events),4);self.assertEqual(e.event_ordinal,6)
  self.assertEqual(bytes(e.cpu.mem_read(oldcopy.DEST+4090,6)),b'abcd56')
  self.assertTrue(e.aborted[-1]['attemptedWrites'])
  self.assertTrue(all('eventOrdinal' not in row for row in e.aborted[-1]['attemptedWrites']))
 def test_source_fault_preserves_read_observer_order(self):
  e=self.copy(src=oldcopy.SOURCE+4092,count=2);e.supply(oldcopy.SOURCE+4092,b'abcd','synthetic source')
  with self.assertRaises(b.Blocked):e.run(oldcopy.CODE,oldcopy.STOP)
  self.check(e);self.assertEqual(len(e.write_events),4)
 def test_zero_rep_and_reverse_order(self):
  e=self.copy(count=0);e.run(oldcopy.CODE,oldcopy.STOP);self.check(e);self.assertEqual(e.event_ordinal,1)
  e=self.copy(df=True,src=oldcopy.SOURCE+8,dst=oldcopy.DEST+8);e.run(oldcopy.CODE,oldcopy.STOP);self.check(e)
  self.assertEqual([int(r['address'],16) for r in e.read_events[:-1]],[oldcopy.SOURCE+8,oldcopy.SOURCE+4,oldcopy.SOURCE])
 def test_projection_invalidations_share_stream_without_duplicate_envelope(self):
  with patch.object(oldprojection.p,'ProjectedReset',lambda *a,**k:s.Sunlight(*a,enforce_prefix=False,enforce_palette_context=False,**k)):
   e,_=oldprojection.ProjectionTests().make()
  e.run(oldprojection.CODE,oldprojection.STOP);self.check(e)
  self.assertEqual(len(e.invalidation_events),10)
  self.assertEqual([v['target'] for v in e.invalidation_events],['memory','register','register','register','memory']*2)
  self.assertTrue(all('eventOrdinal' not in v for v in e.projections))
  self.assertEqual(e.invalidation_events[0]['address'],hex(oldprojection.STACK-32))
 def test_scope_expiration_emits_memory_invalidation_once(self):
  e=self.copy();e.cpu.mem_map(0x87e000,0x2000);e.shadow.regions.append((0x87e000,0x880000,bytearray(0x2000)))
  e.supply(s.q.PALETTE_SLOT,struct.pack('<I',s.q.PAL),'synthetic renamed pointer');e.cpu.reg_write(x.UC_X86_REG_EIP,s.q.STOP)
  e.close_palette_scope();self.check(e);self.assertEqual(e.invalidation_events,[{'eventOrdinal':0,'pc':hex(s.q.STOP),'target':'memory','size':4,'knownMask':'0x0','reason':s.REASONS['expiry'],'address':hex(s.q.PALETTE_SLOT)}])
  with self.assertRaisesRegex(b.Blocked,'twice'):e.close_palette_scope()
 def test_conditioned_trig_write_aborts_before_journal_commit(self):
  e=IntegerTests().make(b'\xa3'+struct.pack('<I',DATA),{'eax':123});e.protected_inputs=[DATA+2]
  with self.assertRaisesRegex(b.Blocked,'conditioned trig'):e.run(CODE,STOP)
  self.assertEqual(e.committed,0);self.assertFalse(e.write_events);self.assertEqual(e.shadow.get(DATA,4),0)
 def test_relocated_flag_event_emitted_only_at_commit(self):
  e=IntegerTests().make(b'\x90');e.enforce_palette_context=True
  e.pending={'address':0x4a292d,'journal':[],'registers':{},'flags':b.DF,'call':None,'return':None}
  self.assertFalse(e.invalidation_events);e.commit();self.check(e)
  self.assertEqual(e.invalidation_events[0]['knownMask'],hex(b.DF));self.assertEqual(e.invalidation_events[0]['register'],'eflags')
  e.commit();self.assertEqual(len(e.invalidation_events),1)
 def test_predeclared_fields_nonoverlapping_and_new_contract(self):
  fields=s.observable_spec();self.assertEqual(len(fields),43);seen=set()
  for field in fields:
   a=int(field['address'],16);positions=set(range(a,a+field['bytes']));self.assertFalse(seen&positions);seen|=positions
  events=s.invalidation_contract();self.assertEqual(len(events),12);self.assertEqual(events[0]['address'],hex(b.STACK-52))
 def test_prefix_checkpoint_commits_preceding_xor_before_asserting(self):
  e=IntegerTests().make(b'\x90');e.enforce_prefix=True
  e.cpu.mem_map(0x42b000,4096);e.cpu.mem_write(s.q.STOP,b'\x90')
  e.cpu.mem_map(0x87e000,0x2000);e.shadow.regions.append((0x87e000,0x880000,bytearray(0x2000)))
  e.windows.append((s.q.STOP,s.q.STOP+1));e.cpu.reg_write(x.UC_X86_REG_EIP,s.q.STOP)
  e.shadow.put(s.q.PALETTE_SLOT,4,b.MASK32)
  e.pending={'address':s.q.STOP-2,'journal':[],'registers':{'ebx':b.MASK32},'flags':b.DF|b.CF|b.PF|b.ZF|b.SF|b.OF,'call':None,'return':None}
  checked=[]
  def checkpoint(engine):
   self.assertIsNone(engine.pending);self.assertEqual(engine.committed,1)
   self.assertEqual(engine.shadow.reg_get('ebx'),b.MASK32);self.assertEqual(engine.shadow.get(s.q.PALETTE_SLOT,4),0)
   self.assertEqual(len(engine.invalidation_events),1);checked.append(True);return ['checked']
  with patch.object(s.q,'assert_claims',checkpoint):e._code(e.cpu,s.q.STOP,1,None)
  self.assertEqual(checked,[True]);self.assertEqual(e.prefix_claims,['checked'])
  self.assertEqual(e.pending['address'],s.q.STOP)
 def test_approval_binds_all_new_scope_and_input_contracts(self):
  keys=['entry','expectedStop','allowedWindows','omittedFragments','heapContract','prefixBoundaryContract','prefixUnknownOutputs','conditionalAssumptions','trigInputs','sqrtTable','selectedObservables','expectedInvalidationEvents','finalBoundaryContract','eventSchema']
  m={'source':{'observedSourceHead':'synthetic','trackedStatus':''},'inputs':[],**{key:{} for key in keys}}
  approval=s.approval_bindings(m);s.validate_approval(approval,m)
  for key in keys:
   old=m[key];m[key]={'changed':True}
   with self.assertRaisesRegex(b.Blocked,'missing/stale'):s.validate_approval(approval,m)
   m[key]=old
  approval['parentReleasedRunLane']=False
  with self.assertRaisesRegex(b.Blocked,'lane release'):s.validate_approval(approval,m)
 def test_missing_approval_precedes_any_native_cpu_creation(self):
  with patch.object(b,'load_module',side_effect=AssertionError('native helper must not load')):
   with self.assertRaises((b.Blocked,KeyError)):s.execute(None,None,{},None,None)
 def test_frozen_hashes_unchanged(self):
  self.assertEqual(b.sha(s.PREFIX.read_bytes()),s.PREFIX_SHA);self.assertEqual(b.sha(s.q.PROJECTED.read_bytes()),s.q.PROJECTED_SHA);self.assertEqual(b.sha(s.p.BASE_DRIVER.read_bytes()),s.p.BASE_SHA)

if __name__=='__main__':unittest.main(verbosity=2)
