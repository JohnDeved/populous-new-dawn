"""Synthetic, authored x86 only. No original instructions execute."""
import unittest,struct
import unicorn
from unicorn import x86_const as x
import reset_palette_candidate as q
b=q.b
CODE,SOURCE,DEST,STACK,STOP=0x100000,0x200000,0x300000,0x400800,0x400f00
class CopyTests(unittest.TestCase):
 def make(self,code=b'\xf3\xa5\xc3',count=3,df=False,src=None,dst=None):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,SOURCE,DEST,0x400000]:c.mem_map(a,4096)
  c.mem_write(CODE,code)
  e=q.ResetPalette(c,[(CODE,4096),(SOURCE,8192),(DEST,8192),(0x400000,4096)],[(CODE,CODE+len(code))],enforce_palette_context=False)
  e.reg_supply('esp',STACK,b.MASK32,'synthetic stack');e.supply(STACK,struct.pack('<I',STOP),'synthetic return')
  e.reg_supply('eflags',2|(b.DF if df else 0)|b.CF|b.ZF,b.MASK32,'synthetic flags')
  for r,v in [('esi',SOURCE if src is None else src),('edi',DEST if dst is None else dst),('ecx',count)]:e.reg_supply(r,v,b.MASK32,'synthetic copy registers')
  return e
 def test_mixed_unknown_masks_and_real_bytes(self):
  e=self.make();raw=bytes(range(12));e.cpu.mem_write(SOURCE,raw)
  masks=[0xff00aacc,0,0xffffffff]
  for i,m in enumerate(masks):e.shadow.put(SOURCE+4*i,4,m)
  e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DEST,12)),raw)
  self.assertEqual([e.shadow.get(DEST+4*i,4) for i in range(3)],masks)
  self.assertEqual(e.reg_value('esi'),SOURCE+12);self.assertEqual(e.reg_value('edi'),DEST+12);self.assertEqual(e.reg_value('ecx'),0)
 def test_reverse_direction(self):
  e=self.make(df=True,src=SOURCE+8,dst=DEST+8);e.supply(SOURCE,bytes(range(12)),'synthetic source');e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DEST,12)),bytes(range(12)))
  self.assertEqual(e.shadow.get(DEST,12),(1<<96)-1)
  self.assertEqual(e.reg_value('esi'),SOURCE-4);self.assertEqual(e.reg_value('edi'),DEST-4)
 def test_zero_count_no_memory_or_address_or_direction_consumption(self):
  e=self.make(count=0,src=0xdead0000,dst=0xbeef0000)
  for r in ['esi','edi','eflags']:e.shadow.reg_put(r,0)
  e.run(CODE,STOP)
  self.assertFalse(e.write_events);self.assertEqual(len(e.read_events),1) # root RET only
  self.assertEqual(e.reg_value('esi'),0xdead0000);self.assertEqual(e.shadow.reg_get('esi'),0)
 def test_forward_overlap_propagates_previous_iteration(self):
  e=self.make(src=SOURCE,dst=SOURCE+4);e.cpu.mem_write(SOURCE,b'abcdefghijklmnop');e.shadow.put(SOURCE,4,0x12345678)
  e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(SOURCE,16)),b'abcd'*4)
  self.assertEqual([e.shadow.get(SOURCE+4*i,4) for i in range(4)],[0x12345678]*4)
 def test_reverse_overlap_propagates_previous_iteration(self):
  e=self.make(df=True,src=SOURCE+12,dst=SOURCE+8);e.cpu.mem_write(SOURCE,b'abcdefghijklmnop');e.shadow.put(SOURCE+12,4,0xabcdef12)
  e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(SOURCE,16)),b'mnop'*4)
  self.assertEqual([e.shadow.get(SOURCE+4*i,4) for i in range(4)],[0xabcdef12]*4)
 def test_source_fault_preserves_only_completed_iteration(self):
  e=self.make(src=SOURCE+4092,count=2);e.supply(SOURCE+4092,b'abcd','synthetic source');e.cpu.mem_write(DEST,b'12345678')
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DEST,8)),b'abcd5678');self.assertEqual(e.shadow.get(DEST,4),b.MASK32);self.assertEqual(e.shadow.get(DEST+4,4),0)
  self.assertEqual(e.committed,1);self.assertEqual(e.reg_value('ecx'),1);self.assertEqual(e.reg_value('esi'),SOURCE+4096)
 def test_destination_cross_page_fault_rolls_back_partial_iteration(self):
  e=self.make(dst=DEST+4090,count=2);e.supply(SOURCE,b'abcdefgh','synthetic source');e.cpu.mem_write(DEST+4090,b'123456')
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DEST+4090,6)),b'abcd56')
  self.assertEqual(e.shadow.get(DEST+4090,4),b.MASK32);self.assertEqual(e.shadow.get(DEST+4094,2),0)
  self.assertEqual(e.committed,1);self.assertEqual(e.reg_value('ecx'),1);self.assertEqual(e.reg_value('edi'),DEST+4094)
 def test_copy_does_not_change_flags(self):
  e=self.make();before=e.reg_value('eflags');known=e.shadow.reg['eflags'];e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eflags'),before);self.assertEqual(e.shadow.reg['eflags'],known)
 def test_unsupported_address_and_segment_overrides_stop(self):
  for code in [b'\x67\xf3\xa5\xc3',b'\x64\xf3\xa5\xc3']:
   e=self.make(code=code)
   with self.assertRaisesRegex(b.Blocked,'unsupported MOVSD'):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_unknown_decisive_count_direction_and_addresses_stop(self):
  for reg in ['ecx','esi','edi','eflags']:
   e=self.make();e.shadow.reg_put(reg,0)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_scope_expiration_invalidates_only_renamed_slot(self):
  e=self.make();e.cpu.mem_map(0x87e000,0x2000);e.shadow.regions.append((0x87e000,0x880000,bytearray(0x2000)))
  e.supply(q.PALETTE_SLOT,struct.pack('<I',q.PAL),'synthetic renamed pointer')
  with self.assertRaisesRegex(b.Blocked,'outside exact prefix stop'):e.close_palette_scope()
  e.cpu.reg_write(x.UC_X86_REG_EIP,q.STOP);e.close_palette_scope()
  self.assertTrue(e.palette_scope_closed);self.assertEqual(e.shadow.get(q.PALETTE_SLOT,4),0)
 def test_palette_context_must_match_all_three_fields(self):
  e=self.make()
  with self.assertRaisesRegex(b.Blocked,'outside declared'):e.palette_context()
  correct={'caller':'0x42b59c','target':'0x4a2920','return':0x42b5a1}
  e.frames=[correct];e.palette_context()
  for key in correct:
   wrong=dict(correct);wrong[key]='0x1' if key!='return' else 1;e.frames=[wrong]
   with self.assertRaisesRegex(b.Blocked,'wrong palette'):e.palette_context()
 def test_approval_requires_exact_heap_contract_and_release(self):
  m={'source':{'observedSourceHead':'synthetic','trackedStatus':''},'inputs':[],
    'omittedFragments':q.p.SKIPS,'selectedObservables':q.observable_spec(),'heapContract':{'requestedBytes':1024},'boundaryContract':{},'requiredUnknownOutputs':{}}
  digest=lambda v:b.sha(q.json.dumps(v,sort_keys=True).encode())
  approval={'verdict':'ACCEPT_RESET_PALETTE_PREFIX','parentReleasedRunLane':True,'scope':q.SCOPE,
    'driverSha256':b.sha(q.Path(q.__file__).read_bytes()),'projectedResetSha256':q.PROJECTED_SHA,'frozenEngineSha256':q.p.BASE_SHA,
    'sourceBindingSha256':digest(m['source']),'inputBindingSha256':digest(m['inputs']),
    'projectionBindingSha256':digest(m['omittedFragments']),'observableBindingSha256':digest(m['selectedObservables']),
    'heapBindingSha256':digest(m['heapContract']),
    'boundaryBindingSha256':digest({'boundary':m['boundaryContract'],'unknownOutputs':m['requiredUnknownOutputs']}),'observedSourceHead':'synthetic'}
  q.validate_approval(approval,m)
  approval['parentReleasedRunLane']=False
  with self.assertRaisesRegex(b.Blocked,'missing/stale'):q.validate_approval(approval,m)
  approval['parentReleasedRunLane']=True;m['heapContract']['requestedBytes']=2048
  with self.assertRaisesRegex(b.Blocked,'missing/stale'):q.validate_approval(approval,m)
 def test_frozen_import_hashes(self):
  self.assertEqual(b.sha(q.PROJECTED.read_bytes()),q.PROJECTED_SHA)
  self.assertEqual(b.sha(q.p.BASE_DRIVER.read_bytes()),q.p.BASE_SHA)
 def test_spec_predeclares_new_known_field(self):
  self.assertEqual(len(q.observable_spec()),33);self.assertEqual(q.observable_spec()[-1]['name'],'palette_cache_size')
if __name__=='__main__':unittest.main(verbosity=2)
