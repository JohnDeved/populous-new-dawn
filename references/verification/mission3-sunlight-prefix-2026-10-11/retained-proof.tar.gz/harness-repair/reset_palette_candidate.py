#!/usr/bin/env python3
"""Review-gated actual reset/palette prefix with one declared heap renaming.

No original execution without a fresh matching review and parent lane release.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,struct,sys
HERE=Path(__file__).resolve().parent
PROJECTED_SHA='9a0a81d78c68376191c065096ada7b9658f3ac22b0391d3b76445570909588ed'
PROJECTED=HERE/'projected_reset_candidate.py'
if hashlib.sha256(PROJECTED.read_bytes()).hexdigest()!=PROJECTED_SHA:raise RuntimeError('Frozen projected reset drift')
spec=importlib.util.spec_from_file_location('frozen_projected_reset',PROJECTED);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);b=p.b
SCOPE='conditional-reset-palette-source-ordered-prefix'
ENTRY,STOP=0x42b590,0x42b5a3
PAL,PALETTE_SLOT,DEST=0x2010000,0x87eff8,0x899f8d
WINDOWS=b.RESET_WINDOWS+[(ENTRY,STOP),(0x4a2920,0x4a2944)]

class ResetPalette(p.ProjectedReset):
    def __init__(self,*args,palette=PAL,enforce_palette_context=True,**kwargs):
        super().__init__(*args,**kwargs);self.palette=palette;self.enforce_palette_context=enforce_palette_context
        self.palette_scope_closed=False;self.relocated_flag_events=[]
    def palette_context(self):
        if not self.frames:raise b.Blocked('palette outside declared caller context')
        f=self.frames[-1]
        if (f['caller'],f['target'],f['return'])!=('0x42b59c','0x4a2920',0x42b5a1):raise b.Blocked('wrong palette caller context')
    def _plan(self,ins):
        m=ins.mnemonic
        if ins.address in (0x4a2927,0x4a292d,0x4a293f) and self.enforce_palette_context:self.palette_context()
        if m=='rep movsd':
            if bytes(ins.bytes)!=b'\xf3\xa5':raise b.Blocked('unsupported MOVSD prefix/address/segment form')
            self.require(self.shadow.reg_get('ecx'),b.MASK32,'repeat count')
            count=self.reg_value('ecx');self.pending['registers']['ecx']=b.MASK32
            if not count:return
            self.require(self.shadow.reg['eflags'],b.DF,'direction flag')
            for reg in ('esi','edi'):self.require(self.shadow.reg_get(reg),b.MASK32,'string '+reg)
            src,dst=self.reg_value('esi'),self.reg_value('edi')
            if ins.address==0x4a293f and self.enforce_palette_context:
                if not (0<count<=16 and src==self.palette+0x1c0+4*(16-count) and dst==DEST+4*(16-count) and not self.reg_value('eflags')&b.DF):
                    raise b.Blocked('palette copy leaves exact renamed source/destination span')
            self.pending['reads'].append((src,4))
            self.pending['writes'].append((dst,4,self.shadow.get(src,4)))
            self.pending['registers'].update(esi=b.MASK32,edi=b.MASK32)
            return
        super()._plan(ins)
        if ins.address==0x4a292d and self.enforce_palette_context:
            if self.reg_value('esi')!=self.palette:raise b.Blocked('palette pointer differs from declared heap renaming')
            # The numerical relocated address is not an actual-address flag proof.
            # Actual XOR EBX,EBX at0042b5a1 later kills these arithmetic flags.
            self.flags(0);self.relocated_flag_events.append({'pc':hex(ins.address),'effect':'arithmetic flags unknown due to heap renaming','actualKill':'0x42b5a1 XOR EBX,EBX'})
    def close_palette_scope(self):
        if self.reg_value('eip')!=STOP:raise b.Blocked('palette scope closed outside exact prefix stop')
        self.shadow.put(PALETTE_SLOT,4,0)
        self.palette_scope_closed=True


def observable_spec():
    return p.observable_spec()+[{'name':'palette_cache_size','address':'0x899f8b','bytes':1,'expectedValue':16,'requiredKnownMask':'0xff'}]


def prepare(out):
    pe,base,reset=p.prepare(out)
    manifest={'status':'PREPARED_RESET_PALETTE_NOT_EXECUTED','originalInstructionsExecuted':0,'scope':SCOPE,
      'driver':b.file_record(Path(__file__)),'projectedReset':b.file_record(PROJECTED),'frozenEngine':b.file_record(p.BASE_DRIVER),
      'source':reset['source'],'inputs':reset['inputs'],'executable':reset['executable'],
      'entry':hex(ENTRY),'expectedStop':hex(STOP),'allowedWindows':[[hex(a),hex(z)] for a,z in WINDOWS],
      'omittedFragments':reset['omittedFragments'],'selectedObservables':observable_spec(),
      'requiredUnknownOutputs':{'cameraWords':['0x5fe3f0','0x5fe3f4'],'paletteCache':{'address':hex(DEST),'bytes':64},'expiredAbstractPointerSlot':hex(PALETTE_SLOT),'unsuppliedAliases':['0x59df24'],'EDX':True},
      'heapContract':{'descriptor':'0x5a3590 *PALETTE','requestedBytes':0x400,'allocationProducer':'0049c050..0049c089 through00526630','slot':hex(PALETTE_SLOT),'renamedBase':hex(PAL),'conditions':['Successful live0x400-byte heap allocation.','Allocation disjoint from original image, diagnostic stack and other fixture regions.','Only this pointer slot is renamed and known inside the exact reviewed palette helper; other aliases remain unknown.','All1024 content bytes remain unknown; no palette asset or zero-content value is supplied.','Arithmetic flags from relocated ADD remain unknown until actual XOR EBX,EBX; renamed pointer knownness expires at selected stop.'],'sourceReadOffset':'0x1c0','sourceReadBytes':64},
      'boundaryContract':{'knownRegisters':{'eax':0,'ebx':0,'ecx':0,'edi':0x8979d3,'esp':b.STACK-8,'eip':STOP},'unknownRegisters':['esi','edx','ebp'],'eflagsKnownMask':hex(b.DF|(b.ARITH&~b.AF)),'eflagsValueUnderMask':hex(b.PF|b.ZF),'savedOuterStack':{'address':hex(b.STACK-8),'bytes':8,'knownMask':'0x0'}},
      'conditionalAssumptions':[reset['conditionalAssumption'],'The declared abstract palette allocation is live and disjoint; the normal copy completes without fault.'],
      'sourceWindows':[{'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(pe.read(a,z-a))} for a,z in [(ENTRY,STOP),(0x4a2920,0x4a2944),(0x49c050,0x49c089)]],
      'newDependencyResolved':'Original0042b590 ordering through reset, palette-copy and flag kill, preserving unknown palette contents while checking unchanged selected RNG/counter outputs. No later palette/RNG reader is omitted.',
      'notRun':['sunlight','tribe reset','pool/terrain setup','bank6','allocator','record constructor','postpass','gameplay']}
    b.json_write(out/'reset-palette-preflight.json',manifest);return pe,base,manifest


def validate_approval(approval,m):
    digest=lambda value:b.sha(json.dumps(value,sort_keys=True).encode())
    expected={'verdict':'ACCEPT_RESET_PALETTE_PREFIX','parentReleasedRunLane':True,'scope':SCOPE,
      'driverSha256':b.sha(Path(__file__).read_bytes()),'projectedResetSha256':PROJECTED_SHA,'frozenEngineSha256':p.BASE_SHA,
      'sourceBindingSha256':digest(m['source']),'inputBindingSha256':digest(m['inputs']),
      'projectionBindingSha256':digest(m['omittedFragments']),'observableBindingSha256':digest(m['selectedObservables']),
      'heapBindingSha256':digest(m['heapContract']),
      'boundaryBindingSha256':digest({'boundary':m['boundaryContract'],'unknownOutputs':m['requiredUnknownOutputs']}),'observedSourceHead':m['source']['observedSourceHead']}
    for key,value in expected.items():
        if approval.get(key)!=value:raise b.Blocked('missing/stale reset palette acceptance or release',field=key)
    if m['source']['trackedStatus']:raise b.Blocked('tracked source drift')


def assert_claims(e):
    claims=p.assert_claims(e)
    if e.allocations or e.frames:raise b.Blocked('unexpected allocation or open frame')
    if not e.palette_scope_closed:raise b.Blocked('abstract palette scope remains open')
    if e.observed(0x899f8b,1)['value']!=16:raise b.Blocked('palette cache size unknown or wrong')
    claims.append({'name':'palette_cache_size','address':'0x899f8b','bytes':1,'value':16,'knownMask':'0xff'})
    for a,n,label in [(DEST,64,'cache'),(PAL,0x400,'allocation'),(PALETTE_SLOT,4,'expired pointer'),(0x59df24,4,'unsupplied startup alias')]:
        if e.shadow.get(a,n):raise b.Blocked('abstract palette falsely known',field=label)
    for reg,wanted in {'eax':0,'ebx':0,'ecx':0,'edi':0x8979d3,'esp':b.STACK-8,'eip':STOP}.items():
        if e.shadow.reg_get(reg)!=b.MASK32 or e.reg_value(reg)!=wanted:raise b.Blocked('prefix known register incorrect',register=reg)
    for reg in ['esi','edx','ebp']:
        if e.shadow.reg_get(reg):raise b.Blocked('prefix preserved unknown register falsely known',register=reg)
    flag_mask=b.DF|(b.ARITH&~b.AF)
    if e.shadow.reg['eflags']!=flag_mask or e.reg_value('eflags')&flag_mask != b.PF|b.ZF:raise b.Blocked('flag kill provenance incorrect')
    if e.shadow.get(b.STACK-8,8):raise b.Blocked('outer saved registers falsely known')
    written=[w for w in e.write_events if DEST<=int(w['address'],16)<DEST+64]
    if len(written)!=64 or sorted(int(w['address'],16) for w in written)!=list(range(DEST,DEST+64)) or any(w['knownMask']!='0x0' for w in written):raise b.Blocked('exact unknown palette copy coverage missing')
    reads=[r for r in e.read_events if PAL+0x1c0<=int(r['address'],16)<PAL+0x200]
    if [(int(r['address'],16),r['size']) for r in reads]!=[(PAL+0x1c0+4*i,4) for i in range(16)]:raise b.Blocked('palette source read coverage incorrect')
    if len(e.relocated_flag_events)!=1:raise b.Blocked('relocated flag provenance coverage incorrect')
    return claims


def execute(pe,base,m,approval,out):
    validate_approval(approval,m)
    import unicorn
    helper=b.load_module('reset_palette_native_helper',b.ROOT/'scripts/decomp.py');cpu,identity=helper.native_cpu(b.EXE)
    cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
    e=ResetPalette(cpu,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],WINDOWS,iat=pe.imports)
    section=base['textSection'];cpu.mem_protect(section['va'],(section['virtualSize']+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC)
    for section in pe.sections:
        if section['name']!='.text':cpu.mem_protect(section['va'],(max(section['virtualSize'],section['rawSize'])+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    cpu.mem_protect(b.SCRATCH,b.SCRATCH_END-b.SCRATCH,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    for a,data in b.constant_writes(pe):e.supply(a,data,'verified constant descriptor projection')
    e.reg_supply('esp',b.STACK,b.MASK32,'cdecl prefix fixture; no campaign stack capture')
    e.reg_supply('eflags',2,b.DF,'cdecl DF=0 only')
    e.supply(b.STACK,struct.pack('<I',b.STOP),'unused outer diagnostic return sentinel')
    e.supply(PALETTE_SLOT,struct.pack('<I',PAL),'declared heap-location renaming, scoped to exact palette helper; allocation contents unknown')
    e.phase='actual reset/palette source-ordered prefix';before=e.snapshot();claims=[];error=None
    try:
        e.run(ENTRY,STOP,timeout_us=180_000_000);e.close_palette_scope();claims=assert_claims(e);status='RESET_PALETTE_PREFIX_SELECTED_OBSERVABLES_PASSED'
    except BaseException as exc:status='BLOCKED_RESET_PALETTE_PREFIX';error={'type':type(exc).__name__,'message':str(exc)}
    result={'status':status,'scope':SCOPE,'identity':identity,'conditionalAssumptions':m['conditionalAssumptions'],'heapContract':m['heapContract'],
      'attemptedOriginalInstructions':e.attempted,'committedOriginalInstructions':e.committed,'projections':e.projections,
      'selectedObservableAssertions':claims,'before':before,'after':e.snapshot(),'blocker':e.blocker,'error':error,
      'calls':e.events,'openCalls':e.frames,'allocations':e.allocations,'abortedInstructions':e.aborted,'suppliedInputs':e.supplies,
      'memoryReads':e.read_events,'memoryWrites':e.write_events,'relocatedFlagEvents':e.relocated_flag_events,
      'paletteScopeClosed':e.palette_scope_closed,'paletteCacheKnownMask':hex(e.shadow.get(DEST,64)),
      'expiredPalettePointer':e.observed(PALETTE_SLOT,4),'unsuppliedPaletteAlias':e.observed(0x59df24,4),
      'omittedWords':[e.observed(p.CAMERA+offset,4) for offset in [0x100,0x104]],
      'abstractAllocationKnownMask':hex(e.shadow.get(PAL,0x400)),'savedOuterStack':e.observed(b.STACK-8,8),
      'boundaryContract':m['boundaryContract'],'recordsVisited':0,'notRun':m['notRun'],
      'driver':b.file_record(Path(__file__)),'projectedReset':b.file_record(PROJECTED),'frozenEngine':b.file_record(p.BASE_DRIVER)}
    b.json_write(out/'reset-palette-result.json',result);return result


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['prepare','run-prefix']);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--approval',type=Path);args=ap.parse_args()
    if args.out.exists():raise b.Blocked('output directory must be new')
    args.out.mkdir(parents=True);pe,base,m=prepare(args.out)
    if args.mode=='prepare':print(json.dumps({'status':m['status'],'originalInstructionsExecuted':0}));return
    if not args.approval:raise b.Blocked('new review and parent release required before native CPU construction')
    r=execute(pe,base,m,json.loads(args.approval.read_text()),args.out);print(json.dumps({'status':r['status'],'committedOriginalInstructions':r['committedOriginalInstructions'],'error':r['error']}))
    if r['status'].startswith('BLOCKED'):raise SystemExit(2)
if __name__=='__main__':main()
