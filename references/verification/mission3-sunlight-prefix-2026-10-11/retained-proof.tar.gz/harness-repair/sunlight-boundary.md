# Conditional sunlight prefix: frozen review boundary

Status at preparation: original sunlight instructions NOT RUN. Only static PE reads,
host reference arithmetic, and authored synthetic x86 tests have run. A fresh
ACCEPT_SUNLIGHT_PREFIX verdict matching this driver and preflight, plus a separate
parent lane release, is required before constructing the original native CPU.

## Exact continuation and useful result

Entry 0042b590 is the actual level-loader prefix. It performs the previously
reviewed projected reset, genuine palette copy, and XOR EBX,EBX. At 0042b5a3 the
engine first commits that XOR, expires the abstract palette pointer, and asserts
all prior 33 memory fields plus the complete previous CPU/stack/unknown-output
contract. It preserves this checkpoint in the result. It then executes the real
CALL 00401040, its integer loop 00401790, and sqrt helper 00586000..00586034.
The stop is 0042b5a8, before the next CALL to terrain-mask setup 0044fa30.

This resolves one actual source-ordered setup edge toward Mission 3 object
initialization. It does not run terrain, command, tribe, bank, allocator, authored
records, postpass, or gameplay. No callback is replaced by a fabricated return.

## Conditions and original-code boundary

- The existing three camera fragment omissions are unchanged and context-bound.
  Normal/no-fault return of omitted floating operations is assumed, not proved.
  The two floating-derived words, EAX/EDX/flags live-outs, and both 20-byte omitted
  call footprints are invalidated as before. Later integer definitions may make
  CPU/stack bits known; there is no claim that the old footprint remains unused.
- The same successful, live, disjoint abstract 0x400-byte palette allocation is
  declared. All contents and copied cache bytes remain unknown. Only [0087eff8]
  is temporarily renamed; it becomes unknown at 0042b5a3. Alias [0059df24] remains
  unknown. The real XOR, not a supplied flag value, kills the relocated ADD flags.
- Forty sampled DWORDs at 005ddde8 + 0x100*i, i=0..39, are explicitly conditioned
  to equal canonical EXE data at prefix entry. This is not a historical campaign
  capture or a proof of universal pre-entry nonmutation. The union covers 160
  bytes used by 4,096 trig reads. Every overlapping native write aborts; containing
  pages are also read-only for this prefix.
- The 32 uint16 sqrt seeds at 00586034..00586074 are bound to the canonical
  read-only first CSEG (PE flags 0x60000020). Only the 52-byte code window
  00586000..00586034 is admitted by the instruction hook. Page-level RX permission
  does not admit neighboring CSEG code. The second CSEG remains non-executable.
- Unknown consumed addresses, arithmetic inputs, branch flags, import accesses,
  all later x87, unsupported instructions, and targets outside the finite windows
  still stop. No OS, time, network, PE-entry, or gameplay behavior is admitted.

Source-only supporting packets: sunlight-source-audit.json (four full code
windows and independent host expectations), trig-reference-operands.json,
trig-alias-slices03.json, and the reviewer's trig-reference-review.json and
trig-alias-cfg-review.json. The local alias closure is not promoted into a
universal writer-absence claim.

## Finite integer semantics

The extension admits 32-bit register immediate-count SHL/SHR/SAR, one-/two-operand
IMUL, CDQ, register DIV/IDIV, register NEG and register BSR. Other widths/prefixes,
CL shifts and three-operand IMUL stop. Inputs consumed for arithmetic must be
known. Count-zero shifts preserve unknown destination and flag masks. Nonzero
shifts leave AF unknown and OF unknown except count one. IMUL defines only CF/OF;
DIV/IDIV leave arithmetic flags unknown. Native zero-divisor/overflow faults roll
back without committed outputs. BSR defines only ZF and marks a zero-input
destination unknown. CDQ preserves flags. These rules follow Intel's instruction
reference; the synthetic tests cover undefined-flag consumption and faults.

Reference: https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html

## Predeclared selected observables

The preflight fixes 43 nonoverlapping memory fields: all previous 33, six sunlight
constants (three uint16 values 147 and bytes 28,15,32), both 1,024-byte output
arrays, a 3,050-byte zero region at 00937c46, and a two-byte zero at 0096aa7c.
Every selected output bit must be known. Expected table hashes are independently
host-derived from canonical inputs and source integer widths, not native results:

- 0089bc8e: aa4787ac8921047228e66966915a1703b2592ccbd0dfed77f41e836c9e46227d
- 0089c08e: 997ab09f7e99c3d05b9cc78d4252b261fc7b6daab301bdaf24bdba0e3b344a1f

The final CPU contract is separately predeclared: EAX/EBX/ECX/EDX=0 known,
EDI=008979d3 known, ESP=initial STACK-8, EIP=0042b5a8; ESI/EBP remain unknown.
EDX is defined by actual IMUL/CDQ rather than supplied. The final nonnegative
lighting product leaves its CDQ/AND EDX zero. The caller's final XOR EAX,EAX
supplies flags with known mask 0xcc5, masked value 0x44, AF unknown.
Outer saved EBX/EDI eight bytes remain unknown. Both omitted camera words,
64 cache bytes, all 1,024 abstract allocation bytes, expired pointer and unsupplied
alias must remain unknown. Exactly 2,048 genuine sqrt calls must return. No
allocation, open call, aborted instruction, or changed trig input is allowed.

## Recorded observer-order stream

Existing memoryReads and memoryWrites rows keep their raw fields and add
zero-based eventOrdinal. Only committed byte writes get ordinals. New
invalidationEvents contain pc, target (memory/register), size in bytes, post
knownMask, reason, plus address or register. eventStream version 1 describes
observer order and exact counts/extent. It does not claim CPU-retirement order.

The two camera omission callbacks perform five atomic mask changes each, with no
intervening native event. The extension records their existing order: stack,
EAX, EDX, EFLAGS, camera word. The source-bound footprint is initial STACK-52
through STACK-33: outer pushes8 + reset CALL4 + reset pushes8 + wrapper CALL4 +
camera pushes8 + omitted frame20. Committed palette ADD invalidation and pointer
expiry add the last two rows. The preflight binds all 12 descriptors and order;
actual ordinals are recorded during the eventual run. Projection envelopes have
no duplicate ordinal and the first no-op camera omission emits no memory event.

The separate pure replay helper owns no driver changes. Its wrapper must verify
initial supplies, PCs, omissions, descriptor ordinals, final values and scope
independently. Register invalidations are descriptor-checked only; the stream
cannot replay full registers or memory values. The producer-only synthetic JSON
supports schema compatibility, not native replay or a performance claim.

## Synthetic and execution gates

sunlight-all-tests02.log reports 86 tests passed: 57 frozen-engine/projection/copy
regressions plus 29 new integer/metadata/admission tests. Coverage includes REP
DF0/DF1, zero count, overlapping provenance, source and destination faults,
attempted writes without ordinals, projection invalidations, pointer expiry,
trig overlap write rejection and exact checkpoint commit ordering.

Run preparation is read-only with respect to original inputs. The CLI refuses
existing output directories. The native run gate binds all four driver hashes,
source HEAD/status, input hashes and the full new input/observable/boundary/event
contract before native_cpu is constructed. Native instruction count is capped
at 2,000,000 and emulation time at 180 seconds; the parent owns a separate process
timeout and tool/process receipt. No native execution is authorized by this file.
