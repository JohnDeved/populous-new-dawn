#!/usr/bin/env python3
"""Finite static sunlight source/operand audit plus host integer reference math.

Never creates a native CPU or executes original instructions. Trig-data lifetime
is explicitly unproved; host expectations are conditional on canonical inputs.
"""
import argparse,json,struct,math,collections
from pathlib import Path
import capstone
import constructor_candidate as b

def s16(n):return ((n+32768)&65535)-32768
def truncdiv(n,d):return (1 if n>=0 else -1)*(abs(n)//d)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assert not a.out.exists()
 pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
 windows=[];instructions={}
 for lo,hi in [(0x42b5a3,0x42b5a8),(0x401040,0x40108a),(0x401790,0x40191a),(0x586000,0x586034)]:
  raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw)
  instructions.update({i.address:i for i in ins});windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
 for pc,target in {0x42b5a3:0x401040,0x401072:0x401790,0x40182c:0x586000,0x4018b3:0x586000}.items():assert instructions[pc].mnemonic=='call' and instructions[pc].op_str==hex(target)
 seeds=struct.unpack('<32H',pe.read(0x586034,64));assert all(seeds)
 samples=[struct.unpack('<i',pe.read(0x5ddde8+i*256,4))[0] for i in range(40)]
 reads=collections.Counter();norms=[];sqrt_indices=collections.Counter();iterations=[];out1=[];out2=[];vectors=[]
 def lookup(base,index):
  addr=base+4*index;reads[addr]+=1
  assert (addr-0x5ddde8)%256==0 and 0<=(addr-0x5ddde8)//256<40
  return samples[(addr-0x5ddde8)//256]
 def sqrt_helper(n):
  if not n:return 0
  index=n.bit_length()-1;sqrt_indices[index]+=1;guess=seeds[index];count=0
  while True:
   assert guess>0;quotient=n//guess;count+=1
   if quotient>=guess:break
   guess=(guess+quotient)>>1
   assert count<=32
  assert guess==math.isqrt(n);iterations.append(count);return guess
 for u in range(1024):
  hi=(u&~31)*2;lo=(u&31)*64
  ch=lookup(0x5de5e8,hi);cl=lookup(0x5de5e8,lo);sh=lookup(0x5ddde8,hi);sl=lookup(0x5ddde8,lo)
  vx=s16((cl*ch)>>18);vy=s16((sl*ch)>>18);vz=s16(sh>>2)
  norm=vx*vx+vy*vy+vz*vz;assert 0<norm<0x80000000;norms.append(norm)
  root=sqrt_helper(norm);nx,ny,nz=[truncdiv(v<<8,root) for v in (vx,vy,vz)]
  val1=(28+(15*max(0,147*(nx+ny+nz))>>16))&255
  root2=sqrt_helper(norm);val2=(28+(15*max(0,-200*truncdiv(vz<<8,root2))>>16))&255
  out1.append(val1);out2.append(val2);vectors.append([vx,vy,vz])
 assert len(reads)==40 and sum(reads.values())==4096
 gaps={'shl','shr','sar','imul','cdq','idiv','div','neg','bsr'}
 opcodes={op:[{'pc':hex(i.address),'bytes':i.bytes.hex(),'operands':i.op_str} for i in instructions.values() if i.mnemonic==op] for op in sorted(gaps)}
 data=pe.data;offset=struct.unpack_from('<I',data,60)[0];opt=struct.unpack_from('<H',data,offset+20)[0]
 sections=[{**s,'characteristics':hex(struct.unpack_from('<I',data,offset+24+opt+n*40+36)[0])} for n,s in enumerate(pe.sections) if s['name'] in ['.text','CSEG','.data']]
 result={'status':'STATIC_SUNLIGHT_INTEGER_CLOSURE_CANONICAL_INPUT_CONDITIONAL','originalInstructionsExecuted':0,'executable':b.file_record(b.EXE),'script':b.file_record(Path(__file__)),'windows':windows,'sections':sections,
 'trigInputs':{'status':'Canonical initialized .data values bound; actual pre-entry nonmutation/lifetime NOT_PROVED.','sinBase':'0x5ddde8','cosBase':'0x5de5e8','distinctDwordCount':40,'sourceBytes':160,'readCount':4096,'words':[{'address':hex(addr),'signedValue':samples[(addr-0x5ddde8)//256],'readCount':count,'sha256':b.sha(pe.read(addr,4))} for addr,count in sorted(reads.items())]},
 'sqrtInput':{'address':'0x586034','bytes':64,'values':seeds,'sha256':b.sha(pe.read(0x586034,64)),'source':'Read-only executable CSEG image constants (section flags0x60000020); no original execution yet.','actuallyUsedIndices':dict(sqrt_indices)},
 'integerOpcodeGaps':opcodes,
 'hostMathConditionalExpectations':{'iterations':1024,'sqrtCalls':2048,'normRange':[min(norms),max(norms)],'sqrtDivisionIterationsRange':[min(iterations),max(iterations)],'sqrtMatchedPythonIsqrtForAllInputs':True,'outputs':[{'address':'0x89bc8e','bytes':1024,'sha256':b.sha(bytes(out1)),'range':[min(out1),max(out1)]},{'address':'0x89c08e','bytes':1024,'sha256':b.sha(bytes(out2)),'range':[min(out2),max(out2)]}],'warning':'Host-derived expected hashes, not observed original outputs or an admitted replacement.'},
 'otherSourceWrites':{'constants':{'0x937aa8':147,'0x937aaa':147,'0x937aac':147,'0x937aae':28,'0x937aaf':15,'0x937ab0':32},'zeroRanges':[{'address':'0x937c46','bytes':0x2fa*4+2},{'address':'0x96aa7c','bytes':2}]},
 'scopeRequired':'Fresh review must explicitly admit only CSEG00586000..00586034, with0064-byte sqrt table readable; never permit a wholeCSEG execution range. Trig .data words require producer/nonmutation proof or an explicit conditional input contract.',
 'boundary':'No implementation or native run authorized by this source-only packet.'}
 a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'windows':len(windows),'trigWords':len(reads),'sqrtCallsHostOnly':len(iterations),'hostExpectedOutputs':result['hostMathConditionalExpectations']['outputs'],'originalInstructionsExecuted':0}))
if __name__=='__main__':main()
