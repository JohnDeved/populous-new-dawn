#!/usr/bin/env python3
"""Finite static classification of the only two trig-address aliases in retained xrefs."""
import argparse,json
from pathlib import Path
import capstone
import constructor_candidate as b

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assert not a.out.exists()
 pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;windows=[]
 for lo,hi in [(0x42a070,0x42a096),(0x47f9b0,0x47fa2c),(0x47f930,0x47f9ae),(0x47f7b0,0x47f927),(0x47fab0,0x47fb24),(0x40cd00,0x40cdd8),(0x55bc54,0x55bc7b)]:
  raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw)
  windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
 aliases={'ebx':{'start':0x4733fb,'read':0x473413},'ecx':{'start':0x473413,'read':0x473444}}
 proof={}
 for reg,cfg in aliases.items():
  pending=[cfg['start']];seen=set();kills=[];reads=[];calls=[];rows=[]
  while pending:
   pc=pending.pop()
   if pc in seen:continue
   seen.add(pc);assert 0x473210<=pc<0x473c8f,hex(pc)
   i=next(cs.disasm(pe.read(pc,15),pc));rr,ww=i.regs_access();r={i.reg_name(v) for v in rr};w={i.reg_name(v) for v in ww}
   row={'pc':hex(pc),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str};rows.append(row)
   kill=reg in w and i.mnemonic in ('mov','movsx','movzx','lea','pop')
   if i.mnemonic in ('xor','sbb') and len(i.operands)==2 and i.operands[0].type==i.operands[1].type==capstone.x86.X86_OP_REG and i.operands[0].reg==i.operands[1].reg and i.reg_name(i.operands[0].reg)==reg:kill=True
   if kill:kills.append(row);continue
   if reg in r:
    assert pc==cfg['read'] and i.mnemonic=='mov' and i.operands[1].type==capstone.x86.X86_OP_MEM and i.operands[1].access==capstone.CS_AC_READ,(reg,row)
    reads.append(row)
   if i.mnemonic=='call':
    target=i.operands[0].imm;calls.append(row)
    if reg=='ecx' and target==0x42a070:kills.append({**row,'reason':'callee XOR ECX,ECX at0042a079 before first semantic read'});continue
    assert reg=='ebx' and target in (0x42a070,0x47f9b0,0x47f930,0x47fab0,0x55bc54,0x40cd00),(reg,row)
   assert i.mnemonic!='ret',('live alias returns',reg,row)
   if i.group(capstone.CS_GRP_JUMP):
    assert i.operands[0].type==capstone.x86.X86_OP_IMM
    pending.append(i.operands[0].imm)
    if i.mnemonic!='jmp':pending.append(pc+i.size)
   else:pending.append(pc+i.size)
  proof[reg]={'reachableInstructionCountBeforeKill':len(seen),'onlyExplicitSemanticReads':reads,'callBoundaries':calls,'terminalKills':kills,'instructions':sorted(rows,key=lambda v:int(v['pc'],16))}
 result={'status':'FINITE_LOCAL_ALIAS_USES_CLASSIFIED','originalInstructionsExecuted':0,'executable':b.file_record(b.EXE),'script':b.file_record(Path(__file__)),'windows':windows,'proof':proof,
 'calleeContracts':{'0042a070':'No EBX read; ECX killed0042a079.','0047f9b0/0047f930':'No direct EBX use; each calls only0047f7b0; angle loaded as low16 after zeroingEAX.','0047f7b0':'IncomingEBX copied by PUSH0047f7b7; first semantic value is defined0047f879; restored0047f922; no calls.','0055bc54':'Complete conversion body has no EBX operand.','0040cd00':'IncomingEBX saved0040cd07, first overwritten0040cd0a before semantic use, restored0040cdd3.','0047fab0':'IncomingEBX copied by PUSH0047fab9; first semantic value defined0047fb20 before other operations/calls. Later saved-register restoration is an ABI/local-frame obligation, not a table dereference.'},
 'limits':'Closes explicit local register-address consumption and identifies preserving callee contracts. Does not claim an exhaustive proof against arbitrary indirect/bulk writes throughout the whole executable or campaign history.'}
 a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'aliases':{k:{'instructions':v['reachableInstructionCountBeforeKill'],'kills':len(v['terminalKills']),'reads':len(v['onlyExplicitSemanticReads'])} for k,v in proof.items()},'originalInstructionsExecuted':0}))
if __name__=='__main__':main()
