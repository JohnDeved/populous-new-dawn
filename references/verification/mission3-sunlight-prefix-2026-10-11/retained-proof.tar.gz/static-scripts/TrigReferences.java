import java.nio.file.*;
import ghidra.app.script.GhidraScript;
public class TrigReferences extends GhidraScript {
 public void run() throws Exception {
  StringBuilder o=new StringBuilder();
  for(long a=0x005ddde8L;a<0x005e05e8L;a++) {
   for(var r:getReferencesTo(toAddr(a))) {
    var f=getFunctionContaining(r.getFromAddress());var i=getInstructionAt(r.getFromAddress());
    o.append(Long.toHexString(a)).append("\t").append(r.getFromAddress()).append("\t").append(r.getReferenceType()).append("\t").append(f==null?"NO_FUNCTION":f.getEntryPoint()).append("\t").append(i==null?"DATA":i.toString()).append("\n");
   }
  }
  Files.writeString(Path.of(getScriptArgs()[0]),o.toString());println("TRIG_REFERENCES_COMPLETE");
 }
}
