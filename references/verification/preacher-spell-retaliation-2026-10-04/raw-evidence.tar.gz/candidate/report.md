# Active Preacher retaliation: failure-first disposition

## Result and supported repair

The live assignment adapter is a confirmed integration gap at accepted main
`dcfb0dc2afe3e2501f964b109933e43d8bdbd451` (app tree
`ad26a1a94f3d0262d72e762b29a9287f6a1d52ab`). The actual sermon producer sets
assignment bit 64; the private `computerSpellPerson` adapter overwrites it with
zero; the already native-backed complete spell controller therefore misses its
Preacher retaliation branch.

Proposed bounded repair: change only `assignment: 0` in `computerSpellPerson`
(`app/computer-runtime.ts:1788`) to `assignment: live?.assignment ?? 0`, preserving
the existing `unitAnimationSource(u)` ownership selection. That same source already
supplies state/flags4 here, returns the actual sermon record in this reproduction,
and supplies assignment in `computerSelectionWorld` at lines 129-144. Do not change
flags2, disguise, person ordering, native controller behavior, readiness or payment.

No production change, commit, push, issue or PR was made. The only untracked source
file is `tests/preacher-spell-retaliation.test.mjs`. This is a reproducible failing
regression and proposed repair, not a repaired or accepted feature. No parity credit.

## Reproduction and observations

From this worktree:

```sh
node --test tests/preacher-spell-retaliation.test.mjs
```

The fixture adds a Blue Preacher and Red Brave through `addUnit`, then advances the
ordinary fixed-turn system. At turn 6, command 17 is active, the native Preacher has
assignment 336 (`336 & 64 === 64`), and the live listener is in state 23 with its
`workTarget` equal to that Preacher's id. No assignment bit is injected in positive
cases. `unitAnimationSource(preacher) === preacher.native` is asserted.

The fixture then bounds the spell decision: the existing Red Shaman is positioned
six world units away, supplied ordinary mana/payment availability, and one ready
scan entry. Turn 1 excludes ordinary 16-turn dispatch and shoreline Blast; no early
emergency flags/frequency are active. Actors and spell prerequisites are deliberately
staged, so this is a live-producer/adapter/controller regression, not a natural
campaign acquisition, complete game turn outcome, or browser acceptance run.

The existing `processComputerSpells` is used as a comparison at the adapter boundary,
supplied the actual produced person record. It requests the native priority models
2 (Blast), 5 (Swarm), or 3 (Lightning), at the Preacher's packed cell 54802. This
comparison omits unrelated friendly terrain objects and supplies allocation/delay,
matching the bounded consumer question; it is not new native execution.

For each positive case, the real exported `stepComputerSpells(w, 1)` executes its
private `computerSpellWorld` / `computerSpellPerson` path, advances scan cursor to
80, and stores cell 54802 in target slots. It allocates no spell: the spell-count
assertion fails with actual 0 versus expected 1. Thus cell traversal reaches the
actual Preacher, while only the expected retaliation outcome is absent. Post-cast
assertions in these three tests are not reached until a repair is tested.

Final regression result: 14 tests, 11 passed, 3 intentionally failed, 1.31 seconds
in Node v24.19.0. The three failures are exactly Blast priority / Swarm fallback /
Lightning fallback at the live spell-count assertion.

Passing exclusions: bit 64 absent; native source absent; same tribe; allied tribe;
actual `setUnitInvisibility` status; caster AI cooldown; no ready scan entry; paused
scan; no valid payment; stored Lightning with 79,999 mana. A separate live
`stepComputerSpells` control confirms the existing enemy-Shaman Lightning path still
spends stock at zero mana and preserves queued scan work. These controls are baseline
coverage; unchanged behavior after a repair still requires the repair run.

## Original and live correspondence

- `decomp/generated/0043a4d0.c:268-277`: the native shared sermon command executes
  `0043abf0` acquisition on its scan phase and clears/sets `+0x76 & 0x40` from the
  returned count. `app/preacher-conversion.ts:210-213` retains that behavior.
- `app/world-turn.ts:1285-1290` dispatches active sermon orders to
  `stepLivePreaching`; `app/live-movement.ts:562-594` calls `stepPreachingOrder`
  with actual `acquirePreacherVictims`. The six-turn test exercises this producer.
- `app/world-turn.ts:471-478` calls `stepComputerSpells` in the normal computer
  tribe pass. `app/computer-runtime.ts:1776-1800` builds its person/cell adapter;
  line 1788 discards assignment. The test calls that actual exported system entry.
- `decomp/generated/004d0860.c:181-188,218-283` gates enemy, alliance, visibility,
  model 4 and assignment bit 64, then tries models 2, 5, 3 with eligibility,
  payment, mana, usage and range. `app/computer-spells.ts:268-301,496-507`
  implements the same branch. `allocateComputerSpell` at runtime lines 959-972
  reaches ordinary `beginCast` for the spell allocation.
- `scripts/check-native-emergency-spells.py` already compares 1,040 complete
  native `004d0860` passes. It writes assignment at +0x76 from the established
  person field map, exercises deterministic three-spell fallback/stock boundaries,
  and varies assignment/invisibility/alliance/readiness cases. Only final allocator
  `004f4de0` is intercepted to record requests and apply delay 12; native queries,
  range, geometry, scoring and scan/dispatch execute. The retained documented result
  is 17 Blast, 4 Lightning, 1 Swarm and 4 preacher-response cases
  (`references/reverse-engineering.md:1943-1982`, `decomp/README.md:926-944`).
  This existing proof is reused; it was not re-executed in this assignment.

The two C export SHA-256 values were verified against `decomp/exports.json`, which
binds them to executable SHA-256
`3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f` and Ghidra 12.1.3.
`source-manifest.json` records hashes of the producer, adapter, consumer, normal
callers, probe, exports and regression. No byte layout or unproved native leaf was
introduced. The selected source/probe/export files have no difference between the
prior threat report's b381851 application and dcfb0dc.

## Receipts and limits

- `failure-first-02.json` and its `.artifacts/stdout.log`: source-bound final
  failing regression; command exit 1; untracked test is an explicit hashed input.
- `source-manifest.json`: exact source and export fingerprints; empty production
  diff. Test SHA-256 `0b8613679d5fbedf56b744f1b980b9494a43258d1bf0e498d486c072f92ca1b4`.
- `failure-first-01.json` is retained honestly: it also contained a mistaken test
  expectation comparing a projectile's cell center to its cell corner. The final
  regression fixes that assertion and adds absent-source coverage; only the three
  intended adapter failures remain. No production edit was used to obtain results.
- Full check/build, browser, new native emulation/composition, Ghidra, parity/fixture
  recording and performance measurement are **not run**, respecting M3 Run11's lane.
  They remain future repair/acceptance work as applicable, not passed gates.
- No dependency transfer/install occurred; no resource or heavy lane is held.
  The released inode-925605 dependency tree remains in reincarnation-site-wave.

This gap suppresses attacks on active Preachers. It cannot explain the earlier M3
Preacher deaths and is not evidence of their attacker. Existing general/shoreline/
defense spells retain separate threat paths. The original producer and controller
are supported by retained source/probe evidence separately; this work does not claim
an uninterrupted native producer-to-controller execution or full original campaign.

Stop condition reached: reproducible live failure plus bounded native/source
correspondence. Await parent scope disposition before changing production. If approved,
retain the failing receipt, make the one-field repair, rerun these tests, then schedule
standard and affected native/browser/quality checks with the parent and an independent
review. Fresh native composition is not currently needed for this adapter repair.
