# Independent frozen checker/native preflight

**ACCEPT preflight**, 2026-10-04 23:47 UTC. No blocking source/checker finding.
This permits the parent-authorized serialized gates to begin; it is not acceptance
of unrun evidence or a merge recommendation.

- Base: `dcfb0dc2afe3e2501f964b109933e43d8bdbd451`
- Reviewed clean head: `3df229bf4ab76cb8d08722cef728829c60fc0023`
- Full base/head binary diff SHA-256:
  `a7d3118a0e8ba2788cdc48b4991941084158367ccb0b4c06b2c8f24a4cbe6fd3`
- Previous source review: `ec13a07/independent-review.md`; all production remains
  the same accepted one-field assignment fix.
- Read-only review; only ignored reports written. No browser, heavy gate, native
  emulation or shared process launched by this reviewer.

## Reviewed delta

All changes since ec13a075 reviewed: new 160-line browser checker, native mismatch
diagnostic path portability, and evidence/project-map links. The later mesh-name
correction appropriately requires actual membership in fxMeshes rather than a
nonempty optional debug name. It preserves the real GPU contribution assertion.

The browser fixture obtains the sermon bit through real fixed turns and asserts
command17, actual selected native owner, and owned state23 listener before staging
the computer Shaman/readiness. All Blast/Swarm/Lightning positives use real tick
through processTribes and withCampaignTribe. It asserts next turn2, scan80, exactly
one intended spell and projectile, expected caster and target. Independent short
Node observation confirmed the produced fixture point is exactly {x:11,z:33},
equal to its allocated packed-cell-center target, so that stronger equality is
valid here. This fixture does not generalize point equality for arbitrary targets.

The movement control uses the real command path, then asserts command3, cleared
bit64 and released listener before the next AI tick; the invisibility control uses
setUnitInvisibility. Both require no spell allocations/projectiles after dispatch.
The fixture is explicitly staged; it is not represented as ordinary campaign play.

Positive effects must materialize through later real ticks, meet specific Swarm/
Lightning readiness conditions, have an actual scene mesh and contribute nonzero
framebuffer pixels. Reviewed effectPixels implementation compares framebuffer
pixels with the selected effect visible/hidden and restores visibility. The caller
also renders again before its screenshot, preserving the actual visible effect.
Texture readiness, GL context status, renderer identity and browser errors are
recorded/checked. No expected pixel assertion or known gameplay gate was weakened.

The before mode requires a supplied candidate capture turn, advances to that exact
turn, asserts no retaliation, and takes a real screenshot. Its correctness as a
true-base capture depends on the planned separate game root: final review must
verify the browser receipt's source commit/root is exact dcfb0dc, not simply accept
the mode label. The isolated harness serves options.gameRoot, records source before
and after, rejects drift, owns its server PID/process group and fresh browser
context, and closes only those resources. Use fresh output directories, a fresh
ephemeral context, the assigned port4367, and serial dependency moves with receipts.
No M3 persisted profile is involved or authorized for alteration.

Native script delta replaces only argv parsing and the mismatch-artifact location.
The executable argument remains explicit; --failure-output accepts an owned path;
the default is ignored work/native-emergency-failure.json. Parent directories are
created only for a detected mismatch, and the same case/native/browser payload is
written before the unchanged AssertionError. Fixture generation, native functions,
emulation bounds, all comparisons, length/coverage assertions and supplied allocator
remain unchanged. Rerun must use an explicit path in this run's artifact directory.

## Source verification

Independently computed hashes:

- browser checker:
  `8e07d6dd26e61aca62e1fcc6af12554d892e8e05b8ad6e0acfecfb0d8f1ec265`
- native emergency probe:
  `3a8d8cc0eaa3206f7bf8edc12a0b7abdc4e7860fcef7dd31f336d257ab659c1e`
- local-render harness:
  `af11148b0c896a255bc1a8f431b7054e6e3dee928b3c1217115a5c9b027d390c`
- browser-game helper:
  `061ecb23dbcc5296fa6cdd044f44910af52884bb20d4fce5a9d64eb4391d9ba9`
- HUD readiness helper:
  `72e92a34a7b282edea371af92fdcf657a43dc80dbc5bb7fb44293a9b329b24a1`

Independent `node --check scripts/check-browser-preacher-retaliation.mjs` and
base/head `git diff --check` pass. Production TypeScript quality disposition remains
the ec13a075 review; added JavaScript is bounded/reuses existing renderer/harness,
and Python changes follow the probe's established style without touching the oracle.

## Pending final acceptance

Approved serial plan: native emergency oracle; standard npm check/build; full
quality/Fallow advisory checks; candidate rendered cases; detached exact-base
capture at candidate's observed turn; final receipt and screenshot review.
None is asserted passed by this report. Preserve any natural-M3 regression and
failed attempts without weakening tests. Native/controller evidence remains bounded
at the supplied final allocator, browser evidence remains staged/software WebGL,
and neither creates campaign parity or hardware-performance credit.
