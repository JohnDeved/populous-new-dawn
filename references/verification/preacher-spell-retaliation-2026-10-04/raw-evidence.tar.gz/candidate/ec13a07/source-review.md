# Source review request: Preacher retaliation

- Issue: https://github.com/JohnDeved/populous-new-dawn/issues/206
- Draft PR: https://github.com/JohnDeved/populous-new-dawn/pull/207
- Base: dcfb0dc2afe3e2501f964b109933e43d8bdbd451
- Frozen/pushed head: ec13a075070c2819c001e29a89b7d3d65e9e4718
- Worktree: /workspace/scratch/69fd8163d94e/cloud-dev-20261004/preacher-spell-retaliation
- Full diff: source.patch beside this file, or git diff BASE HEAD.

The only production delta preserves assignment from the existing selected live
person in computerSpellPerson. Review all five changed files, the source/producer
ownership, native correspondence, reference-fixture boundaries and unchanged control
gates. No flags2/disguise/native-controller extension, parity or M3 source transition.
This bug suppresses retaliation and cannot explain the previously observed deaths.

## Completed focused evidence

Receipts here bind exact frozen head and empty tracked diff:

- focused.json: 14/14 live producer/adapter/controller tests pass.
- typecheck.json: npm run typecheck passes with root and installed lock inputs.
- format-focused.json: Oxfmt check on the sole maintained TS file passes.
- eslint-focused.json: changed TS file and new regression pass ESLint.
- oxlint-focused.json: failed, 73 inherited diagnostics (16 errors / 57 warnings).
  oxlint-baseline/base.json came from the clean exact dcfb integration tree, read-only,
  using the same installed tool/config; current.json came from this candidate.
  comparison-02.json proves identical diagnostic code/message/severity/help and
  source line/column/length. Root filenames/cycle paths and shifted absolute byte
  offsets are excluded. comparison.json retains the earlier offset-sensitive failed
  comparison honestly. No warning/error was suppressed or fixed opportunistically.
- source-diff.json: git diff --check BASE HEAD passes.
- orchestration-structural.json: manifest/index structure passes.
- plan.json: plan from exact base, no unknown changed paths. Broad campaign mapping
  selects unrelated legacy campaign checks; the reviewer should assess the affected
  acceptance proposal below. The plan itself executes nothing.

Earlier failure-first-02.json (one directory above) records base 11/14 pass and three
expected missing-cast failures, with explicit SHA of the new untracked regression.
source-manifest.json binds the pre-repair inputs/exports; report.md retains the
original stop-at-proof disposition. repaired-focused-01.json records the first dirty
repair pass. These historical files are immutable; this packet supersedes only their
then-current task status.

## Proposed deferred acceptance

Source review must precede these heavier checks. Parent owns queue admission; M3
Run11 keeps its separate b381851 bytes and its browser/profile throughout.

1. Standard npm run check and npm run build on the frozen candidate. Retain failures;
   do not weaken existing natural preaching/campaign expectations to hide changed
   behavior. Full format:check, lint and lint:standard plus Fallow advisory evidence
   remain separate from the completed focused checks.
2. Rerun existing scripts/check-native-emergency-spells.py against the verified
   external original EXE through restored Python. It exercises all 1,040 complete
   controller cases without changed fixtures. Keep final allocation's known supplied
   boundary; no new native composition or Ghidra export is proposed. Native consumer
   source, producer source and their reviewed exports are otherwise unchanged.
3. Bounded local-render acceptance, in an isolated fresh harness profile after lane
   admission: prepare the same short staged live-sermon fixture with actual fixed
   turns, then run the positive Blast through one actual tick(1 / 12): processTribes
   -> withCampaignTribe -> stepComputerSpells. Observe the projectile/cast and
   subsequent rendered effect at the Preacher's cell. The reviewer verified this
   caller with a short read-only probe (turn 1 -> 2, scan 80, one Blast). Cover all
   three positive priority/fallback cases and an inactive/invisible negative; use
   a normal Preacher movement command for the inactive control, asserting listener
   release and assignment-bit clearance before the next AI turn. Explicitly identify
   any fallback case that still invokes the exported step directly. Retain normal renderer,
   scene update, screenshots, errors, source and software-renderer identity. Explicitly
   label fixture staging and direct simulation as such; this does not replace #192's
   ordinary controls or prove natural acquisition.
4. Capture a comparable base/candidate active-Preacher scene pair in that same bounded
   harness and publish the real images with SHA captions to #206/#207. No fabricated
   before image, no hardware-performance claim, and no changes to original game data.

A dedicated browser harness is not yet written or run; review this acceptance scope
before implementation and re-review any substantive harness changes. No current
browser result, original executable run, full check/build or complete feature
acceptance is claimed. Existing natural-preacher regression participates in the
standard repository gate; any behavior change must be diagnosed rather than masked.

## Resources

No check/server/browser process is running. This worktree exclusively owns real
node_modules inode 925605, installed lock SHA-256
65e45d0a87d1ecd4fbf56508b9821eb3bfb3867c8477db4aaa1452eb2bed13d8.
Fresh transfer receipts exist at both ends; the previous reincarnation-site-wave
path now contains exactly its original .package-lock.json stub. No install/copy,
shared fixture recording, native project or fixed port is held.

Request: source/acceptance-plan ACCEPT or concrete findings before heavy validation.
This is not a request to approve a merge with the required deferred gates missing.
