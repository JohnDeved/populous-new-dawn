# Independent source and acceptance preflight

Decision at 2026-10-04 23:35 UTC: **ACCEPT source and revised preflight plan**.
This is not final feature or merge acceptance. Required heavy, native and rendered
gates remain pending. No source defect was found in the bounded change.

- Reviewer: `/root/finish_reviewed_pr_batch/review_preacher_retaliation_fix`
- Issue/PR: #206 / #207
- Base: `dcfb0dc2afe3e2501f964b109933e43d8bdbd451`
- Reviewed head: `ec13a075070c2819c001e29a89b7d3d65e9e4718`
- Full binary diff SHA-256: `ccf05817dcf6fbbe68d0820e2466c8fcfa8666b8d8d5f6a0fccd5f0334c1e7ea`
- Worktree was clean on entry and after inspection. Only this ignored report is written.
- Read AGENTS.md, GOAL.md, engineering/README.md, repository populous-engineering
  skill, and the relevant assistant engineering skill. No heavy gate, browser,
  native emulation, Ghidra, shared profile or M3 worktree was operated.

## Full delta and source ownership

All five changed files reviewed. The sole production change is
`computerSpellPerson.assignment = live?.assignment ?? 0`. The selected live source
already supplies state and flags4; flags2, disguise, ordering, controller,
readiness, stock and mana are unchanged. Documentation accurately labels staged
regression, native reuse, no parity credit, and separate campaign acceptance.
The project-map additions index the new test and evidence without changing gates.

The shipped fixed-turn caller is `world-turn.ts:471-478`, through computer tribe
processing and `withCampaignTribe`. The object loop reaches actual sermon work at
`world-turn.ts:1285-1290`; `stepLivePreaching` uses the retained native person and
the actual acquisition/release consumers. `unitAnimationSource` directly selects
that native record for commandStatus 17, 31 and 32. Flight and encounter records
take precedence when they own the person's actual current state. Combat entry
initializes the same retained record, while fresh combat records begin with zero
assignment. No ownership defect exposed by this adapter change was found.

Lifecycle clearing is not a guessed extra filter in the adapter. Native
`0043a4d0.c:244,268-277` and `preacher-conversion.ts:195,210-213` clear bit64 on
queued-sermon completion or acquisition returning no listeners. Generic state
initialization clears it via `assignment &= 0xf51f` in `person-state.ts:258`,
matching `004d2740.c:58`. Normal command replacement reaches this initializer;
the independent probe below verifies bit clearance and listener release before
the next AI turn, followed by no retaliation.

## Native eligibility and byte correspondence

The reviewed native controller checks enemy/alliance, visibility and disguise,
then model4 and assignment bit64 at its exact location in cell traversal. It
tries models2,5,3 with independent payment, mana, usage, cast readiness and range
gates. The unchanged port has the same predicate and fallback order. In particular,
stock does not bypass the Preacher branch's mana requirement; the independent
enemy-Shaman response remains a different stock/mana path. No new native execution
or uninterrupted producer-to-controller composition is claimed here.

The source-manifest hashes were independently checked against working bytes. Every
listed source/probe/export/test matches the pre-repair manifest except the intended
computer-runtime one-line edit. Base computer-runtime hash is
`7b26c03a301ae0a4e50084bdd9b1cdd1f04a711260f998324ffe6e2b7a2dae72`;
candidate hash is `1ca8fd533d5634cc5d82feb5909ab136506c966713c04508b1d487167e052f5c`.
The failure-first and candidate regression have identical SHA-256
`0b8613679d5fbedf56b744f1b980b9494a43258d1bf0e498d486c072f92ca1b4`.
The two native producer/controller exports match decomp/exports.json and its
executable `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`,
Ghidra 12.1.3. The additional lifecycle export `004d2740.c` matches indexed hash
`02dd6d6bcdebfd1fbb5065c50af5e8f40d33140676e99c316ceb3ebe85835747`;
that export and person-state.ts are unchanged from the reviewed base.

The existing 1,040-case emergency probe supplies only final allocation and delay12,
with native query/range/scan/dispatch execution. Its historical pass count is
documentary evidence, not a raw run receipt recovered in this task. The proposed
exact-candidate rerun is required before accepting that native gate.

## Failure-first and current receipts

Independently verified stdout/stderr artifact hashes, stable before/after source,
command, status and exit for failure-first-02, candidate focused, typecheck,
focused format, ESLint, Oxlint, diff check, structural and planner receipts.
All reference the stated base or head with empty tracked diff as appropriate.
Failure-first has exactly three intended missing-cast failures and eleven passes;
the identical test on the candidate has fourteen passes. The three positive tests
produce their sermon bit by six real turns and assert the exact selected source,
owned state23 listener, target scan and native-backed reference response before
checking the live allocation. They do not rewrite the private adapter or monkeypatch
the live controller. Reference simplification and staged prerequisites are explicit.

Negative coverage includes absent assignment/source, same/allied tribe, real
invisibility status, cooldown, absent ready entry, paused scan, payment and the
stored-Lightning mana boundary. The unrelated early enemy-Shaman case still
spends stock at zero mana and preserves pending scan state.

The maintained TypeScript change is clear and reuses an existing owner. No new
abstraction, duplication, deletion or complexity concern; Ponytail principles met.
Focused typecheck/Oxfmt/ESLint pass. Oxlint is honestly failed with 73 inherited
diagnostics (16 errors,57 warnings); the retained base/current comparison preserves
code/message/severity/help/source locations while excluding root paths and shifted
byte offsets. Full quality and Fallow advisory runs remain pending with the other
scheduled gates; do not describe them as passed or suppress inherited findings.

## Independent lightweight caller/lifecycle probe

Executed read-only from the reviewed worktree with Node v24.19.0 on 2026-10-04.
It evaluates only the existing regression's import/helper prefix in memory, then
calls actual tick/command APIs. No repository test or production source is altered.

```js
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { tick, command, unitAnimationSource } from './app/model.ts';
import { currentPersonOrder } from './app/person-orders.ts';
let source=fs.readFileSync('tests/preacher-spell-retaliation.test.mjs','utf8');
source=source.slice(0,source.indexOf('for (const [name, available'));
source=source.replaceAll("'../app/",`'${pathToFileURL(process.cwd()+'/app/').href}`)+'\nexport { scenario };';
const {scenario}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
for (const [name,available,model] of [['Blast',44,2],['Swarm',40,5],['Lightning',8,3]]) {
 const {w,preacher,shaman}=scenario(); w.manaWorld.spells[1].available=available;
 assert.equal(unitAnimationSource(preacher),preacher.native);
 tick(w,1/12);
 assert.equal(w.turn,2); assert.equal(w.spellScan.cursor,80); assert.equal(w.spellCasts[1][model],1); assert.equal(w.projectiles.length,1);
 console.log(JSON.stringify({check:'normal fixed-turn '+name,result:'passed',turn:w.turn,assignment:preacher.native.assignment,scan:w.spellScan.cursor,castCount:w.spellCasts[1][model],projectiles:w.projectiles.length,casting:shaman.casting.spell}));
}
const {w,preacher,victim}=scenario(); w.selected=[preacher.id]; command(w,{x:preacher.x+1,z:preacher.z+1});
assert.equal(preacher.native.assignment&64,0); assert.notEqual(victim.native.state,23); assert.equal(victim.native.workTarget,0); assert.equal(currentPersonOrder(w.buildingOrders,preacher.native)?.model,3);
const afterCommand={assignment:preacher.native.assignment,victimState:victim.native.state,workTarget:victim.native.workTarget};
tick(w,1/12); assert.equal(w.spellCasts[1].reduce((a,b)=>a+b,0),0); assert.equal(w.projectiles.length,0);
console.log(JSON.stringify({check:'normal movement replacement clears retaliation',result:'passed',turn:w.turn,afterCommand,liveSourceAfterTurn:unitAnimationSource(preacher)?.state??null,castCount:0,projectiles:0}));
```

Command: `node --input-type=module` with this exact stdin. Exit0; runtime0.663s.
Tool result chunk `1754c5`. Raw stdout:

```jsonl
{"check":"normal fixed-turn Blast","result":"passed","turn":2,"assignment":336,"scan":80,"castCount":1,"projectiles":1,"casting":"blast"}
{"check":"normal fixed-turn Swarm","result":"passed","turn":2,"assignment":336,"scan":80,"castCount":1,"projectiles":1,"casting":"swarm"}
{"check":"normal fixed-turn Lightning","result":"passed","turn":2,"assignment":336,"scan":80,"castCount":1,"projectiles":1,"casting":"lightning"}
{"check":"normal movement replacement clears retaliation","result":"passed","turn":2,"afterCommand":{"assignment":280,"victimState":10,"workTarget":0},"liveSourceAfterTurn":25,"castCount":0,"projectiles":0}
```

Retained attempt limit: the preceding probe (chunk da7eee) completed all the same
behavioral assertions but exited1 because its final diagnostic dereferenced
preacher.native after normal combat ownership made it null. The correction snapshots
post-command fields before ticking and uses unitAnimationSource after the turn.
No behavioral assertion or production code was weakened. An earlier observation-only
probe (chunk80edcf) also observed the Blast tick and immediate command clearance.

These short Node checks establish caller feasibility and lifecycle behavior only.
They are not browser acceptance, hardware performance, or natural campaign proof.

## Acceptance-plan disposition

The first proposed browser plan repeated direct stepComputerSpells. Requested one
positive path through actual fixed-turn tribe dispatch and normal movement-command
negative; the owner added both to source-review.md item3. **Revised plan ACCEPT**:

1. Standard exact-candidate check/build and planned quality/advisory evidence.
2. Existing exact-candidate emergency native probe on hash-verified external inputs.
3. Isolated rendered staged-sermon scene with actual tick-triggered cast, all three
   spell outcomes, movement/invisibility negatives, real subsequent effects,
   screenshots, errors and browser/renderer identity. All three fallback cases can
   use actual ticks, as this review proved; any direct-only case must stay labeled.
4. Comparable true base/candidate captures with source captions on issue/PR.

Review substantive browser harness changes and final receipts before merge. Preserve
the natural-M3 test's existing assertions and report any exposed regression instead
of changing its claims. Do not change M3's separately pinned b381851 application,
profile or resource lane. This fix restores attacks; it cannot explain past M3
deaths. No parity or broader campaign closure is authorized by this preflight.
