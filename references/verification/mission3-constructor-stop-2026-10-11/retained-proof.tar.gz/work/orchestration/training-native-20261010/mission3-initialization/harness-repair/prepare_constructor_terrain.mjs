// Pure host model. No original executable/emulator import or execution.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
const root = process.cwd()
const output = resolve(process.argv[2])
if (existsSync(output)) throw new Error('New output directory required')
const game = '/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game'
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const data = readFileSync(`${game}/levels/levl2003.dat`)
if (digest(data) !== 'eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf') throw new Error('Canonical level hash mismatch')
const { createNativeTerrain, queueTerrain, updateWalkMasks } = await import(pathToFileURL(`${root}/app/native-terrain.ts`))
const land = createNativeTerrain(Array.from({ length: 16384 }, (_, i) => data.readInt16LE(i * 2)))
land.landFlags = 0 // Explicitly conditioned land80=0. Land08 does not enter these model calculations.
let textureCalls = 0
const forbiddenTexture = () => { textureCalls++; throw new Error('Unexpected texture callback') }
queueTerrain(land, 0, 64, 0, { surface: forbiddenTexture, globe: forbiddenTexture })
updateWalkMasks(land, 0, 64)
// Original00484da9..00484dc8 overlays the third plane AFTER walk-mask construction.
for (let i = 0; i < 16384; i++) if (data[0x10000 + i]) land.flags[i] |= 4
const terrain = Buffer.alloc(0x40000)
for (let i = 0; i < 16384; i++) {
  terrain.writeUInt32LE(land.flags[i], i * 16)
  terrain.writeInt16LE(land.heights[i], i * 16 + 4)
  terrain[i * 16 + 10] = land.cliffs[i]
  terrain[i * 16 + 12] = land.categories[i]
  terrain[i * 16 + 14] = land.shadows[i]
}
if (land.queued.length || land.recursing || land.dirty.some(Boolean) || textureCalls) throw new Error('Incomplete model boundary')
mkdirSync(output)
const files = [['terrain.bin', terrain], ['walk0.bin', land.walkMasks[0]], ['walk1.bin', land.walkMasks[1]]]
for (const [name, bytes] of files) writeFileSync(`${output}/${name}`, bytes)
const sourceFiles = ['app/native-terrain.ts', 'app/native-math.ts', 'app/original-rules.json', 'scripts/check-native-terrain.py', process.argv[1]]
const receipt = {
  status: 'MODEL_DERIVED_MISSION3_TERRAIN_CONDITION', originalInstructionsExecuted: 0,
  claim: 'Native-validated model applied to canonical Mission3; not an exact Mission3 native snapshot.',
  conditions: ['The supplied pre-constructor terrain equals this hashed model result.', 'Terrain initially zero except canonical signed heights; land mask0x80 clear; initial queue/dirty/recursion state empty.'],
  sourceOrder: ['signed heights', 'queue/process0,64,0', 'walk masks0,64', 'third plane flag0x04 overlay'],
  input: { path: `${game}/levels/levl2003.dat`, bytes: data.length, sha256: digest(data) },
  sources: sourceFiles.map(path => ({ path, sha256: digest(readFileSync(path)) })),
  files: files.map(([name, bytes]) => ({ name, bytes: bytes.length, sha256: digest(bytes), knownness: 'All bytes supplied as model-derived condition, not observed native writes.' })),
  counters: { attempts: land.attempts, duplicates: land.duplicates, queued: land.queued.length, textureCalls },
  node: process.version,
  limits: ['Different terrain may change genuine constructor decisions and allocation counts; those decisions remain native in the later ledger.', 'The existing native comparison script was inspected but not run.']
}
writeFileSync(`${output}/receipt.json`, `${JSON.stringify(receipt, null, 2)}\n`)
console.log(JSON.stringify(receipt))
