# Conditional Mission 3 StageA constructor diagnostic

## Claim and stop

This candidate investigates actual original allocator/initializer behavior under a
predeclared selected-state seam. It is not an original Mission 3 startup capture.
The first admitted case is `land-clear`, class-counter entry bytes all zero and
both RNG streams `0x09d78afe`. No alternate-seed sweep is requested. A matching
fresh review plus the parent's separate released lane receipt is mandatory before
CPU construction.

The objective is the genuine 20 blocks × 100 slots loop, including all 1,891 empty
slots, all 109 authored nonempty records, nested allocations, per-record
postprocessing and original ID publication. The final stop is `00485050`, before
the separate global callback pass. A first unknown decisive input, unsupported
instruction/target, import, x87 instruction, memory fault or finite budget is a
retained diagnostic outcome, not a completed StageA ledger.

An open allocator can already have changed free lists, copied its class counter,
incremented that counter, changed RNG and initialized part of a node. The receipt
therefore separately retains CALL-entry order, return order, open calls, committed
counter copies/increments, fully returned successful nodes and completed records.
No final class1 total is guessed. For class1, the actual descriptor increment bit
is clear; the asserted per-trace law is entry seed + committed class1 increments
modulo256. Fully returned class1 count need not equal committed increments at a
blocked initializer. Every declared returned identity/model/owner/state/counter/link
field must be fully known. All 179 object bytes and masks are retained without a
blanket all-object-bytes-known claim.

## Source-ordered selected setup

The candidate executes original selected producers in this order:

1. Startup pool bounds and IDs, then related-record reserve initialization.
   The earlier startup free-list traversal is not needed as a producer here; the
   later real pool reset rebuilds its lists. Prior-unit deletion `00477780` is
   outside the seam, with omitted-history preservation explicitly conditioned.
2. Integer animation transform `0042c4b6..0042c5ee`, with canonical raw VSTART,
   VFRA and VELE inputs and successful disjoint allocations. The 1,602-byte unused
   chain tail remains unknown. Then genuine shape pointer relocation.
3. Genuine pre-loader tribe reset, with source-bound player/count/identity/script
   inputs and the labeled land08 alternative.
4. Genuine loader pool reset before the real terrain-zero REP. Pool proof retains
   slot0 exclusion, low slots639..1, high1839..640 and secondary1999..1840.
5. Canonical bank6 relocation, the actual24 ANI rows, morph transform and fixed
   model flags, in their original relative order.
6. The separately hashed model-derived terrain/walk outputs. The model preserves
   height copy → process(0,64,0) → walk masks → third-plane bit4 overlay, under
   land80clear and no texture callback. This is a native-validated model input
   condition, not an exact native Mission3 terrain result.
7. Genuine64-byte tribe-ID copy (offsets+8a1/+8a3), followed by the actual final
   lighting-byte copy, integer sunlight and20-block counter setup. Lighting
   defaults28/15 come from earlier `00401040` with a lifetime condition, not from
   a fictitious copy of the first two lighting DAT bytes.
8. Twenty source-bound successful data-transport boundaries and genuine record
   loops. `00484ebd` retains the real byte-count CMP; `00485011`, `0048502d` and
   `00485035` retain allocation, postprocessing and publication.

The exact asset addresses are concrete seam conditions, not a claim of arbitrary
heap-address invariance. Canonical mutable class/model descriptors plus all
constant.dat writes are explicitly conditioned. Unsupplied mutable bytes stay
unknown. Original PE write permissions are preserved; only exact instruction
windows may execute, including the narrow integer sqrt helper in RX CSEG.

## Omitted effects and guarded outputs

All prior supplied state and mappings are conditioned to survive omitted earlier
callers until their next genuine producer. This applies to every known byte later
consumed, not just counters. The diagnostic does not infer neutrality of opaque
sound/UI calls from a later unknown-read guard.

At each transport boundary the exact next canonical0x157c bytes and byte count are
supplied. Nonvolatile registers/caller frame and prior known game state are
conditioned preserved. EAX/ECX/EDX, arithmetic flags and the entire declared stack
below the caller frame become unknown. No OS return or fabricated CALL/RET event
is supplied. Each selected standalone producer also expires its reusable scratch
frame before exact source locals are supplied. No extra boundary destroys the
native final sunlight block counter.

Only one new computation is projected: the exact85-byte scenery proximity loop
`004a5f63..004a5fb8`. It is gameplay-derived, not presentation. Four output bytes
`0096eaba..bd`, EAX/EDX/EBX/ECX and arithmetic flags become unknown. Source position
setup, ESI/EBP/EDI/ESP and all other scenery instructions/calls remain genuine.
The exact dispatcher context/model guard is checked. Later decisive reads of an
unknown projected output stop. The canonical tribe-ID file block does not supply
tribe+911/+913 start coordinates. Old camera skips are explicitly disabled with
`skips=[]`; every later x87 instruction still aborts.

## Synthetic tests and bounded receipts

The test suite executes only authored synthetic x86, never canonical instructions.
It covers narrow shifts/division/IMUL/ROR, undefined flags, division rollback,
protected-data faults, known/unknown conditional branches, zero-count memory
access, exact transport sequencing/stack invalidation, source-cursor supplies,
projection context/taint, partial counter accounting and full-stage completion.
Earlier frozen tests are rerun unchanged as inheritance regression coverage.

Each selected kernel and each100-record block has a3,000,000-instruction /
240-second cap. Global caps are12,000,000 attempted instructions and5,000,000
observer events. The outer process recipe is timeout1200 seconds. These are
finite safety limits, not a performance forecast. The prior admitted pool run
retired1,507,177 instructions; animation is bounded by792 starts,3,961 frames,
16,076 elements and at most792×791/2 prior-chain comparisons. No new standalone
native setup probe is requested.

A live JSONL trace retains read, committed-write, invalidation and conditioned
supply rows, flushed at phase checkpoints. Supply sequence/phase/current observer
ordinal distinguish mid-run input from time-zero memory. The shared event ordinal
still describes observer order rather than CPU retirement. The final JSON retains
all arrays and failed instruction journals; an outer process termination may leave
only the durable partial JSONL/process logs and cannot count as a valid ledger.
