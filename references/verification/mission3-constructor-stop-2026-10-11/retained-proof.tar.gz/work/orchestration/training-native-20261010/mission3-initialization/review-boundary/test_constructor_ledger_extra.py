"""Independent synthetic-only edge tests; no original PE read or execution."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'harness-repair'))
import constructor_ledger_candidate as ledger
import test_constructor_ledger as authored

b = ledger.b


class ExtraLedgerTests(unittest.TestCase):
    def engine(self, code, regs=None, **kwargs):
        return authored.FiniteIntegerTests().make(bytes.fromhex(code), regs, **kwargs)

    def test_signed_word_division_does_not_promote_unknown_upper_halves(self):
        e = self.engine('66f7f9', {'eax': 0xaabbffe9, 'edx': 0xccddffff, 'ecx': 6})
        e.shadow.reg_put('eax', 0xffff)
        e.shadow.reg_put('edx', 0xffff)
        e.run(authored.CODE, authored.STOP)
        self.assertEqual(e.reg_value('eax'), 0xaabbfffd)
        self.assertEqual(e.reg_value('edx'), 0xccddfffb)
        self.assertEqual(e.shadow.reg_get('eax'), 0xffff)
        self.assertEqual(e.shadow.reg_get('edx'), 0xffff)
        self.assertEqual(e.shadow.reg['eflags'] & b.ARITH, 0)

    def test_same_byte_sbb_requires_only_carry_without_promoting_high_bits(self):
        e = self.engine('18c0', {'eax': 0xaabbcc22}, flags=3, flagmask=b.CF)
        e.shadow.reg_put('eax', 0)
        e.run(authored.CODE, authored.STOP)
        self.assertEqual(e.reg_value('eax'), 0xaabbccff)
        self.assertEqual(e.shadow.reg_get('eax'), 0xff)
        self.assertEqual(e.shadow.reg['eflags'] & b.ARITH, b.ARITH)

    def test_unknown_memory_rotate_aborts_without_guest_read_or_write(self):
        e = self.engine('c10d000020000d')
        e.supply(authored.DATA, ledger.pack(0x12345678), 'synthetic input')
        e.shadow.put(authored.DATA, 4, 0x00ffffff)
        with self.assertRaisesRegex(b.Blocked, 'unbound'):
            e.run(authored.CODE, authored.STOP)
        self.assertEqual(e.committed, 0)
        self.assertEqual(e.event_ordinal, 0)
        self.assertEqual(e.shadow.get(authored.DATA, 4), 0x00ffffff)

    def test_zero_count_rotate_keeps_partial_unknowns_and_unknown_flags(self):
        e = self.engine('c1c820', {'eax': 0x12345678}, flagmask=0)
        e.shadow.reg_put('eax', 0x0f0f0f0f)
        e.run(authored.CODE, authored.STOP)
        self.assertEqual(e.reg_value('eax'), 0x12345678)
        self.assertEqual(e.shadow.reg_get('eax'), 0x0f0f0f0f)
        self.assertEqual(e.shadow.reg['eflags'], 0)

    def test_adc_with_unknown_carry_never_commits(self):
        e = self.engine('83d001', {'eax': 8}, flagmask=b.DF)
        with self.assertRaisesRegex(b.Blocked, 'carry'):
            e.run(authored.CODE, authored.STOP)
        self.assertEqual(e.committed, 0)
        self.assertEqual(e.reg_value('eax'), 8)


if __name__ == '__main__':
    unittest.main()
