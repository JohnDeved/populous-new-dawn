# Run02 independent review limits

Accepted result: a conditional diagnostic stop at 004eda87, before the first
record's allocation returned. Record 1 is class 2/model 1. Its class counter was
copied as 0 and incremented to 1 before the stop. Class1 has no copy/increment and
remains 0. No completed record, successful returned allocation, scenery projection,
complete StageA ledger, or actual Mission3 startup capture is established.

The file-only verifier checks compressed and expanded result identities, released
approval/process/preflight consistency, canonical instruction bytes and allowed PC
boundaries, direct CALL targets, canonical first-record bytes, reported setup seed
preservation, the failed CMP's empty write journal, and the open/returned/completed
separation. It reconciles all 2,412,445 raw observer events to final arrays and
reconstructs every memory read's known-bit mask from prior conditioned supplies,
committed writes and invalidations at exact insertion cursors. Byte 0089ce37 has no
supply or committed write and stays wholly unknown. The 1,602-byte animation tail
also remains unknown.

This is not an independent CPU arithmetic/value interpreter. It does not recompute
all setup memory values, prove all register effects, or infer retirement from
observer ordinals. The 4,026,972 committed/4,026,973 attempted counts are retained
engine metadata whose internal terminal consistency was checked. Canonical model
terrain and omitted-history/pointer/transport preservation remain explicit input
conditions. Read-mask reconciliation cannot establish neutrality of omitted writes
to previously supplied known state.

## Reproduction dependencies

`verify_constructor_ledger_run02.py` runs host/file analysis only. It requires:

- The result and event gzip files, result-stream receipt and exact run preflight.
- The adjacent run02 process receipt, its referenced released approval, and the
  held `constructor-ledger-protection-held-approval.json` in review-boundary.
- Canonical EXE SHA256
  `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`
  and canonical Mission3 DAT SHA256
  `eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf`.
- The repository's static PE reader `scripts/check-static-mission18-sky.py`,
  SHA256 `74dd55ab6d811f0f0d870c94eb404d2c06915bf96232b6dc39c25f19ceee6da2`,
  and Capstone (review used 5.0.7 with Python 3.12.14).

It uses historical workspace paths stored in receipts, plus a literal local game
path. A portable reproduction must materialize those exact hash-bound inputs and
adapt path lookup only; the archive is not by itself a standalone native emulator
or a substitute for the canonical game files. No prior raw native result or
original execution is needed. The full expanded result is loaded into memory;
review ran serially with approximately 8.3 GiB available memory and did not write
an expanded duplicate to disk.
