#!/usr/bin/env python3
"""Review-gated coherent pre-loader prefix, with explicitly labeled land cases.

No new projection. Original execution requires fresh exact review and parent release.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,platform,struct,sys
HERE=Path(__file__).resolve().parent
SUN=HERE/'sunlight_candidate.py';SUN_SHA='da1d0eb6b11cc024ef0ae9e843aaac7c380bab60c8dcd555073a7f0ae6ea0388'
if hashlib.sha256(SUN.read_bytes()).hexdigest()!=SUN_SHA:raise RuntimeError('Frozen sunlight drift')
spec=importlib.util.spec_from_file_location('frozen_sunlight',SUN);s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);q=s.q;p=s.p;b=s.b
ENTRY,STOP=s.ENTRY,0x42b638
SCOPE='conditional-coherent-preloader-prefix'
NEW_WINDOWS=[(0x44fa30,0x44fa4e),(0x47ac30,0x47ac56),(0x43e320,0x43e3b7),(0x42b7f0,0x42b909),(0x42b660,0x42b7ef),(0x436ff0,0x437008),(0x461d70,0x461eb5),(0x4f52c0,0x4f52cc),(0x4d1420,0x4d1446),(0x41a4f0,0x41a4ff)]
WINDOWS=[w for w in s.WINDOWS if w!=(s.ENTRY,s.STOP)]+[(ENTRY,STOP)]+NEW_WINDOWS
TRIBE=0x89d1c8;STRIDE=0xc65
SCRIPT=b.GAME/'levels/cpscr012.dat';SCRIPT_SHA='d5dfcd826f77909a64cca03ca9d9e3d351d2a7cb3f63eb8ba811b59916e83601'
MAP=HERE/'preloader-input-map02.json';MAP_SHA='653df7ac9c092b7e2c8887ddd7da273f181c57f637720833d8626a1d45c3a250'
CASES={'land-clear':0,'land-set':8}

class Preloader(s.Sunlight):
 def __init__(self,*args,sunlight_manifest=None,enforce_sunlight=True,**kwargs):
  super().__init__(*args,**kwargs);self.sunlight_manifest=sunlight_manifest;self.enforce_sunlight=enforce_sunlight
  self.sunlight_claims=None;self.sunlight_boundary=None
 def masked_supply(self,address,size,value,mask,source):
  full=(1<<(8*size))-1
  if not source or size<1 or value&~mask or mask&~full:raise b.Blocked('invalid masked entry supply')
  old=int.from_bytes(self.cpu.mem_read(address,size),'little');raw=((old&~mask)|(value&mask)).to_bytes(size,'little')
  self.cpu.mem_write(address,raw);self.shadow.put(address,size,mask)
  self.supplies.append({'address':hex(address),'size':size,'sha256':b.sha(raw),'knownMask':hex(mask),'valueUnderKnownMask':hex(value),'source':source})
 def _code(self,c,a,n,unused):
  if a==s.STOP and self.enforce_sunlight:
   try:
    self.commit();self.sunlight_claims=s.assert_claims(self,self.sunlight_manifest);self.sunlight_boundary=self.register_snapshot()
   except b.Blocked as error:self.fail(error)
  super()._code(c,a,n,unused)


def known_fields(case):
 fields=s.observable_spec()
 def value(name,a,n,v,source='genuine prefix producer'):
  fields.append({'name':name,'address':hex(a),'bytes':n,'expectedValue':v,'requiredKnownMask':hex((1<<(8*n))-1),'source':source})
 def region(name,a,raw,source='genuine prefix writes'):fields.append({'name':name,'address':hex(a),'bytes':len(raw),'expectedSha256':b.sha(raw),'requireEveryBitKnown':True,'source':source})
 command=bytearray(6024);struct.pack_into('<H',command,0,1);struct.pack_into('<H',command,4,1)
 region('four_command_rings',0x8979d3,command);region('temp_commands',0x897997,bytes(60))
 region('queue_header',0x89798d,bytes(10));region('related_header',0x8926c7,bytes(8))
 region('fixed_record_auxiliary',0x64f4a0,bytes(1999*4+1));region('fixed_two_planes',0x96aaba,bytes(0x4000))
 for name,a,n,v in [('turn',0x89d184,4,0),('mode_word',0x96aa78,2,1),('mode_word_zero',0x96aa7a,2,0),('two_flags',0x895ebb,2,0),('constant_timing_bytes',0x89ce5c,4,0x00c800c8)]:value(name,a,n,v)
 for i in range(4):
  base=TRIBE+i*STRIDE
  for off in [0x949,0x91d,0x925,0x885,0x881,0x945,0x94d]:value(f'tribe{i}_zero_{off:x}',base+off,4,0)
  value(f'tribe{i}_active',base+0xc20,1,1 if i<3 else 0)
  value(f'tribe{i}_id',base+0xc22,1,i,'explicit startup-ID lifetime condition, preserved')
  if i<3:
   value(f'tribe{i}_control_kind',base+0xc1f,1,1 if i and case=='land-clear' else 2)
   value(f'tribe{i}_mana',base+0x955,4,30000)
 for i,a in enumerate([0x9608bc,0x9639c4]):region(f'tribe{i+1}_script_words',a,bytes.fromhex('eb03e803f603'),'canonical successful-transport input, preserved by genuine prefix; not a native prefix write')
 for i,v in enumerate([25,6,0]):value(f'loader_argument_{i}',b.STACK-20+i*4,4,v,'HDR-derived caller argument, genuinely copied/pushed')
 return fields


def bit_fields(case):
 fields=[{'name':'land_predicates','address':'0x89c661','bytes':2,'requiredKnownMask':'0x108','expectedMaskedValue':CASES[case]},
         {'name':'load_predicate','address':'0x89c666','bytes':1,'requiredKnownMask':'0x2','expectedMaskedValue':0}]
 for i in range(3):
  base=TRIBE+i*STRIDE
  fields.append({'name':f'tribe{i}_flags93d','address':hex(base+0x93d),'bytes':4,'requiredKnownMask':'0x60023','expectedMaskedValue':0x20 if i and case=='land-clear' else 0})
  fields.append({'name':f'tribe{i}_flags941','address':hex(base+0x941),'bytes':4,'requiredKnownMask':'0xff','expectedMaskedValue':0})
 return fields


def entry_contract(case):
 return {'landCase':case,'actualHistory':'Not established; the land08 alternative is explicitly conditioned.',
  'maskedSupplies':[{'address':'0x89c661','size':2,'knownMask':'0x108','valueUnderKnownMask':hex(CASES[case]),'source':'0x100 clear from New Game004c34b2→0047ac30 normal return, with unchanged lifetime; 0x08 is the explicitly labeled alternative'},
                    {'address':'0x89c666','size':1,'knownMask':'0x2','valueUnderKnownMask':'0x0','source':'normal globe branch0048598a and004859c0/7 supplies load mask0x200 clear'}],
  'player':{'address':'0x89c6f0','value':0,'source':'New Game004c3340 writer; unchanged lifetime condition'},
  'count':{'address':'0x96eac0','value':3,'source':'canonical HDR[88]→004859b1/b6'},
  'ids':[{'address':hex(TRIBE+i*STRIDE+0xc22),'value':i,'source':'startup004a512f→0042c150, unchanged lifetime condition'} for i in range(4)],
  'scriptSpans':[{'address':hex(a),'bytesHex':'eb03e803f603','source':'successful canonical CPSCR012 transport00485660→00486550; bounded profile/accepted-prefix lifetime'} for a in [0x9608bc,0x9639c4]],
  'rootArguments':[{'address':hex(b.STACK+4+i*4),'value':v,'source':'HDR[96..98]→004859d8..f2 zero-extension→00485a83/84/85 pushes'} for i,v in enumerate([25,6,0])]}


def prepare(out,case):
 if case not in CASES:raise b.Blocked('explicit land case required')
 if b.sha(MAP.read_bytes())!=MAP_SHA:raise b.Blocked('frozen source input map drift')
 data=SCRIPT.read_bytes()
 if len(data)!=0x3108 or b.sha(data)!=SCRIPT_SHA or data[2:8]!=bytes.fromhex('eb03e803f603'):raise b.Blocked('canonical script input drift')
 pe,base,sun=s.prepare(out)
 import capstone
 cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[]
 for lo,hi in WINDOWS:
  raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo))
  if sum(i.size for i in ins)!=len(raw):raise b.Blocked('split preloader window')
  windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw)})
 m={'status':'PREPARED_PRELOADER_NOT_EXECUTED','originalInstructionsExecuted':0,'scope':SCOPE,'landCase':case,'driver':b.file_record(Path(__file__)),'frozenSunlight':b.file_record(SUN),'frozenPrefix':sun['frozenPrefix'],'projectedReset':sun['projectedReset'],'frozenEngine':sun['frozenEngine'],
  'source':sun['source'],'inputs':sun['inputs']+[b.file_record(SCRIPT)],'executable':sun['executable'],'sourceInputMap':b.file_record(MAP),
  'entry':hex(ENTRY),'expectedStop':hex(STOP),'allowedWindows':windows,'entryContract':entry_contract(case),'sunlightCheckpoint':sun,
  'selectedObservables':known_fields(case),'selectedBitObservables':bit_fields(case),'terrainContract':{'base':'0x8a03e4','records':16384,'stride':16,'bytes':0x40000,'exactKnownMaskPerRecordHex':'040000000000000000fc000000000f00','expectedValueUnderMaskHex':'00000000000000000000000000000000','noFullTerrainValueClaim':True},
  'finalBoundaryContract':{'knownRegisters':{'eax':25,'ebx':0,'ecx':0,'edx':6,'edi':0x96eaba,'esp':b.STACK-20,'eip':STOP},'unknownRegisters':['esi','ebp'],'eflagsKnownMask':hex(b.DF|(b.ARITH&~b.AF)),'eflagsValueUnderMask':hex(b.PF|b.ZF),'savedOuterStack':{'address':hex(b.STACK-8),'bytes':8,'knownMask':'0x0'}},
  'requiredUnknownOutputs':['two omitted camera words','palette64 cache bytes','palette1024 allocation bytes','expired palette pointer','unsupplied palette alias0059df24','outer saved EBX/EDI','copied AI default table240bytes for each nonplayer when land-clear'],
  'conditionalAssumptions':sun['conditionalAssumptions']+['Player0, clear land0x100, and startup identity tribe IDs retain their named earlier producer values until entry.','Land0x08 is the explicitly selected alternative, not proved actual campaign history.','Canonical HDR and CPSCR012 bytes were successfully transported as described; no filesystem/OS return is supplied or executed.'],
  'newProjectionCount':0,'expectedInvalidationEvents':sun['expectedInvalidationEvents'],'eventSchema':sun['eventSchema'],
  'notRun':['loader0042b230','pool/terrain full reset composition','bank6','allocator','authored-record constructor','postpass','gameplay']}
 b.json_write(out/'preloader-preflight.json',m);return pe,base,m


def approval_bindings(m):
 digest=lambda value:b.sha(json.dumps(value,sort_keys=True).encode())
 return {'verdict':'ACCEPT_COHERENT_PRELOADER_PREFIX','parentReleasedRunLane':True,'scope':SCOPE,'landCase':m['landCase'],'driverSha256':b.sha(Path(__file__).read_bytes()),'frozenSunlightSha256':SUN_SHA,'frozenPrefixSha256':s.PREFIX_SHA,'projectedResetSha256':q.PROJECTED_SHA,'frozenEngineSha256':p.BASE_SHA,'observedSourceHead':m['source']['observedSourceHead'],'sourceBindingSha256':digest(m['source']),'inputBindingSha256':digest(m['inputs']),'scopeBindingSha256':digest({k:m[k] for k in ['entry','expectedStop','allowedWindows','entryContract','sunlightCheckpoint','selectedObservables','selectedBitObservables','terrainContract','finalBoundaryContract','requiredUnknownOutputs','conditionalAssumptions','newProjectionCount','expectedInvalidationEvents','eventSchema','sourceInputMap']})}


def validate_approval(a,m):
 for key,value in approval_bindings(m).items():
  if a.get(key)!=value:raise b.Blocked('missing/stale coherent preloader review or parent release',field=key)
 if m['source']['trackedStatus']:raise b.Blocked('tracked source drift')


def assert_terrain(e,contract):
 a=int(contract['base'],16);n=contract['bytes'];mask=bytes.fromhex(contract['exactKnownMaskPerRecordHex'])*contract['records']
 actual=e.shadow.get(a,n).to_bytes(n,'little');raw=bytes(e.cpu.mem_read(a,n))
 if actual!=mask:raise b.Blocked('terrain known-mask coverage incorrect')
 masked=bytes(v&k for v,k in zip(raw,mask))
 if any(masked):raise b.Blocked('terrain masked output not clear')
 return {'base':hex(a),'bytes':n,'records':contract['records'],'knownMaskSha256':b.sha(mask),'valueUnderMaskSha256':b.sha(masked),'wholeTerrainKnown':False}


def assert_claims(e,m):
 if e.sunlight_claims is None:raise b.Blocked('sunlight checkpoint was not asserted')
 if e.frames or e.allocations or e.aborted or len(e.projections)!=3:raise b.Blocked('unexpected final calls/allocations/abort/projection')
 claims=[]
 for field in m['selectedObservables']:
  a,n=int(field['address'],16),field['bytes'];raw=bytes(e.cpu.mem_read(a,n));mask=e.shadow.get(a,n)
  if mask!=(1<<(8*n))-1:raise b.Blocked('selected preloader bytes unknown',claim=field['name'])
  claim={'name':field['name'],'address':hex(a),'bytes':n,'knownMask':hex(mask),'sha256':b.sha(raw)}
  if 'expectedValue' in field:
   claim['value']=int.from_bytes(raw,'little')
   if claim['value']!=field['expectedValue']:raise b.Blocked('selected preloader value incorrect',claim=field['name'])
  elif claim['sha256']!=field['expectedSha256']:raise b.Blocked('selected preloader hash incorrect',claim=field['name'])
  claims.append(claim)
 bits=[]
 for field in m['selectedBitObservables']:
  a,n,want=int(field['address'],16),field['bytes'],int(field['requiredKnownMask'],16);mask=e.shadow.get(a,n);raw=int.from_bytes(e.cpu.mem_read(a,n),'little')
  if mask&want!=want or raw&want!=field['expectedMaskedValue']:raise b.Blocked('selected bit predicate unknown/wrong',claim=field['name'])
  bits.append({**field,'actualKnownMask':hex(mask),'actualValueUnderRequiredMask':raw&want})
 unknown=[(q.DEST,64),(q.PAL,1024),(q.PALETTE_SLOT,4),(0x59df24,4),(0x5fe3f0,8),(b.STACK-8,8)]
 if m['landCase']=='land-clear':unknown += [(TRIBE+i*STRIDE+0x36e,240) for i in [1,2]]
 for a,n in unknown:
  if e.shadow.get(a,n):raise b.Blocked('required unknown preloader output falsely known',address=hex(a))
 boundary=m['finalBoundaryContract']
 for reg,value in boundary['knownRegisters'].items():
  if e.shadow.reg_get(reg)!=b.MASK32 or e.reg_value(reg)!=value:raise b.Blocked('preloader register contract mismatch',register=reg)
 for reg in boundary['unknownRegisters']:
  if e.shadow.reg_get(reg):raise b.Blocked('preserved preloader register falsely known',register=reg)
 mask=int(boundary['eflagsKnownMask'],16)
 if e.shadow.reg['eflags']!=mask or e.reg_value('eflags')&mask!=int(boundary['eflagsValueUnderMask'],16):raise b.Blocked('preloader flags mismatch')
 if [{k:v for k,v in row.items() if k!='eventOrdinal'} for row in e.invalidation_events]!=m['expectedInvalidationEvents']:raise b.Blocked('unexpected new invalidations')
 rows=e.read_events+e.write_events+e.invalidation_events
 if sorted(v['eventOrdinal'] for v in rows)!=list(range(e.event_ordinal)):raise b.Blocked('event stream gap/duplication')
 calls={target:sum(v['target']==target for v in e.events) for target in ['0x44fa30','0x47ac30','0x43e320','0x42b7f0','0x42b660','0x436ff0','0x461d70','0x4f52c0','0x4d1420','0x41a4f0']}
 expected=[1,1,1,1,3,3,2 if m['landCase']=='land-clear' else 0,2 if m['landCase']=='land-clear' else 0,2 if m['landCase']=='land-clear' else 0,3]
 if list(calls.values())!=expected:raise b.Blocked('preloader source call coverage incorrect',calls=calls)
 return {'fields':claims,'bits':bits,'terrain':assert_terrain(e,m['terrainContract']),'newCalls':calls,'unknownRanges':[{'address':hex(a),'bytes':n,'knownMask':'0x0'} for a,n in unknown]}


def execute(pe,base,m,approval,out):
 validate_approval(approval,m) # Before original CPU construction.
 import unicorn,capstone
 helper=b.load_module('preloader_native_helper',b.ROOT/'scripts/decomp.py');cpu,identity=helper.native_cpu(b.EXE);cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
 e=Preloader(cpu,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],WINDOWS,iat=pe.imports,sunlight_manifest=m['sunlightCheckpoint'])
 for section in pe.sections:
  perms=unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE
  if section['name']=='.text':perms=unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC
  cpu.mem_protect(section['va'],(max(section['virtualSize'],section['rawSize'])+4095)&~4095,perms)
 cpu.mem_protect(0x586000,4096,unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC);cpu.mem_protect(b.SCRATCH,b.SCRATCH_END-b.SCRATCH,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
 for a,data in b.constant_writes(pe):e.supply(a,data,'verified constant.dat descriptor projection; frozen prerequisite')
 e.reg_supply('esp',b.STACK,b.MASK32,'cdecl diagnostic stack, not campaign capture');e.reg_supply('eflags',2,b.DF,'cdecl DF=0 only')
 e.supply(b.STACK,struct.pack('<I',b.STOP),'unused outer diagnostic return sentinel');e.supply(q.PALETTE_SLOT,struct.pack('<I',q.PAL),'declared live/disjoint palette heap renaming, contents unknown')
 for word in m['sunlightCheckpoint']['trigInputs']['words']:e.supply(int(word['address'],16),bytes.fromhex(word['bytesHex']),'canonical sampled-trig condition, unchanged')
 e.supply(0x586034,bytes.fromhex(m['sunlightCheckpoint']['sqrtTable']['bytesHex']),'canonical read-only CSEG sqrt seed constants')
 contract=m['entryContract']
 for field in contract['maskedSupplies']:e.masked_supply(int(field['address'],16),field['size'],int(field['valueUnderKnownMask'],16),int(field['knownMask'],16),field['source'])
 for field in [contract['player'],contract['count']]+contract['ids']:e.supply(int(field['address'],16),bytes([field['value']]),field['source'])
 for field in contract['scriptSpans']:e.supply(int(field['address'],16),bytes.fromhex(field['bytesHex']),field['source'])
 for field in contract['rootArguments']:e.supply(int(field['address'],16),struct.pack('<I',field['value']),field['source'])
 for page in sorted({a&~4095 for a in s.TRIG}):cpu.mem_protect(page,4096,unicorn.UC_PROT_READ)
 e.phase='conditional coherent preloader '+m['landCase'];before=e.snapshot();claims=None;error=None
 try:
  e.run(ENTRY,STOP,timeout_us=180_000_000);claims=assert_claims(e,m);status='COHERENT_PRELOADER_SELECTED_OBSERVABLES_PASSED'
 except BaseException as exc:status='BLOCKED_COHERENT_PRELOADER';error={'type':type(exc).__name__,'message':str(exc)}
 result={'status':status,'scope':SCOPE,'landCase':m['landCase'],'identity':identity,'tools':{'python':sys.version,'unicorn':unicorn.__version__,'capstone':capstone.__version__,'platform':platform.platform()},'conditionalAssumptions':m['conditionalAssumptions'],'entryContract':contract,
  'attemptedOriginalInstructions':e.attempted,'committedOriginalInstructions':e.committed,'projections':e.projections,'selectedObservableAssertions':claims,'sunlightCheckpointAssertions':e.sunlight_claims,'sunlightCheckpointRegisters':e.sunlight_boundary,'prefixObservableAssertions':e.prefix_claims,'prefixBoundary':e.prefix_boundary,
  'before':before,'after':e.snapshot(),'blocker':e.blocker,'error':error,'calls':e.events,'openCalls':e.frames,'allocations':e.allocations,'abortedInstructions':e.aborted,'suppliedInputs':e.supplies,'memoryReads':e.read_events,'memoryWrites':e.write_events,'invalidationEvents':e.invalidation_events,'eventStream':e.event_stream(),'recordsVisited':0,'notRun':m['notRun'],
  'driver':b.file_record(Path(__file__)),'frozenSunlight':b.file_record(SUN),'frozenPrefix':b.file_record(s.PREFIX),'projectedReset':b.file_record(q.PROJECTED),'frozenEngine':b.file_record(p.BASE_DRIVER)}
 b.json_write(out/'preloader-result.json',result);return result


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['prepare','run-prefix']);ap.add_argument('--land-case',choices=list(CASES),required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--approval',type=Path);args=ap.parse_args()
 if args.out.exists():raise b.Blocked('output directory must be new')
 args.out.mkdir(parents=True);pe,base,m=prepare(args.out,args.land_case)
 if args.mode=='prepare':print(json.dumps({'status':m['status'],'landCase':m['landCase'],'originalInstructionsExecuted':0}));return
 if not args.approval:raise b.Blocked('fresh preloader review and parent release required before CPU construction')
 r=execute(pe,base,m,json.loads(args.approval.read_text()),args.out);print(json.dumps({'status':r['status'],'landCase':r['landCase'],'committedOriginalInstructions':r['committedOriginalInstructions'],'error':r['error']}))
 if r['status'].startswith('BLOCKED'):raise SystemExit(2)
if __name__=='__main__':main()
