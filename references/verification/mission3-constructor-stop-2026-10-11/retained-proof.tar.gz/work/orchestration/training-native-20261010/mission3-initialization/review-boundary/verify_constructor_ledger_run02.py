"""File-only audit of frozen run02. Does not construct a CPU or execute x86."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,heapq,importlib.util,json,struct,time
import capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';R=H/'constructor-ledger-clear-run02'
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1048576):h.update(data)
 return h.hexdigest()
started=time.monotonic();stream=read(R/'constructor-ledger-result-stream-receipt.json');process=read(H/'constructor-ledger-clear-run02-process-receipt.json');m=read(R/'constructor-ledger-preflight.json')
assert filehash(R/'constructor-ledger-result.json.gz')==stream['sha256']=='2a956a5a1d0ac50ccdbdb4db17f122396781d125b138bf2af6c86ec8f1833d30'
assert filehash(R/'constructor-ledger-events.jsonl.gz')=='f677c94b355c862c95462f0aa6ac45a8c7ac7cacf8a0abf20abb5f87133ad476'
h=hashlib.sha256();n=0
with gzip.open(R/'constructor-ledger-result.json.gz','rb') as f:
 while chunk:=f.read(1048576):h.update(chunk);n+=len(chunk)
assert n==stream['uncompressedBytes']==380379069 and h.hexdigest()==stream['uncompressedSha256']=='c70e1c275329016fad84f891e5cb7fce25c13b9358f45b647a77077ed6f9dc07'
with gzip.open(R/'constructor-ledger-result.json.gz','rt') as f:r=json.load(f)
print('loaded',flush=True)
assert process['status']=='terminal' and process['exitCode']==2 and not process['trackedStatus']
assert process['driversBefore']==process['driversAfter']
assert process['driversBefore']['constructor_ledger_candidate.py']=='9b60152139791b363c5bab656b11ce24437e13edee75d6a67768f26f94e733c2'
ap=Path(process['approval']['path']);ap=ap if ap.is_absolute() else ROOT/ap;approval=read(ap)
assert filehash(ap)==process['approval']['sha256'] and approval['parentReleasedRunLane']
held=read(O/'constructor-ledger-protection-held-approval.json')
for k,v in held.items():
 if k!='parentReleasedRunLane':assert approval[k]==v,(k,approval.get(k),v)
assert r['conditions']==m['conditions'] and r['selectedLedgerContract']==m['selectedLedgerContract']
assert r['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP' and r['complete'] is False
assert (r['attemptedOriginalInstructions'],r['committedOriginalInstructions'])==(4026973,4026972)
assert r['blocker']['pc']=='0x4eda87' and r['blocker']['record']==1 and r['blocker']['reason']=='unbound consumed operand'
assert r['blocker']['details']=={'knownMask':'0x0','requiredMask':'0xff','instruction':'cmp byte ptr [0x89ce37], cl'}
assert len(r['abortedInstructions'])==1 and r['abortedInstructions'][0]['pc']=='0x4eda87' and r['abortedInstructions'][0]['attemptedWrites']==[]
assert not r['returnedAllocations'] and not r['publications'] and not r['projections']
assert len(r['openCalls'])==1 and r['openCalls'][0]['target']=='0x4ed8a0' and r['openCalls'][0]['caller']=='0x485011' and not r['openCalls'][0]['returned']
assert len(r['records'])==len(r['blocks'])==1 and r['records'][0]['status']=='entered'
level=(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/levels/levl2003.dat')).read_bytes()
assert sha(level)=='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf'
assert r['records'][0]['rawHex']==level[0x14043:0x14043+55].hex()
assert r['selectedAssertions']['completedRecords']==0 and r['selectedAssertions']['fullStageAComplete'] is False
assert r['selectedAssertions']['committedClass1Copies']==r['selectedAssertions']['committedClass1Increments']==r['selectedAssertions']['fullyReturnedSuccessfulClass1Count']==0
assert r['selectedAssertions']['finalKnownClass1Seed']=={'address':'0x96eac2','value':0,'knownMask':'0xff'}
for p in r['phaseReceipts']:
 if 'seedPreservation' in p:
  assert all(x['value']==0x09d78afe and x['knownMask']=='0xffffffff' for x in p['seedPreservation']['rng'])
  assert all(x['value']==0 and x['knownMask']=='0xff' for x in p['seedPreservation']['classCounters'])
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);pe=module.PE32(Path(m['executable']['path']))
assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;instructions={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);assert sha(data)==w['sha256'];ins=list(cs.disasm(data,lo));assert sum(x.size for x in ins)==len(data);instructions.update({x.address:x for x in ins})
assert pe.read(0x4eda87,6).hex()=='380d37ce8900'
assert r['abortedInstructions'][0]['bytes']=='380d37ce8900'
for call in r['calls']:
 pc=int(call['caller'],16);target=int(call['target'],16);assert pc in instructions and target in instructions,(call['caller'],call['target'])
 assert instructions[pc].mnemonic=='call'
 if instructions[pc].operands[0].type==capstone.x86.X86_OP_IMM:assert instructions[pc].operands[0].imm==target
 assert call['returned'] or call==r['openCalls'][0]
# Reconstruct only memory known-bit provenance. This is not an independent CPU
# value interpreter and does not infer retirement counts from observer ordinals.
ranges=[(0x400000,bytearray(0xd4e000-0x400000)),(0x2000000,bytearray(0x400000))]
def location(a,n):
 for base,mem in ranges:
  if base<=a and a+n<=base+len(mem):return mem,a-base
 raise AssertionError(('outside memory domain',hex(a),n))
def put(a,n,mask=None):
 mem,off=location(a,n);mem[off:off+n]=bytes([255])*n if mask is None else mask.to_bytes(n,'little')
def get(a,n):
 mem,off=location(a,n);return int.from_bytes(mem[off:off+n],'little')
arrays={'read':r['memoryReads'],'write':r['memoryWrites'],'invalidation':r['invalidationEvents']};cursors=Counter();ordinal=0;supply_seq=0;phases=[];pcs=Counter();tracehash=hashlib.sha256();tracebytes=0;stop_byte_touches=[]
with gzip.open(R/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  tracehash.update(line);tracebytes+=len(line);row=json.loads(line);kind=row.pop('kind')
  if kind=='conditionedSupply':
   assert row==r['suppliedInputs'][supply_seq] and row['supplySequence']==supply_seq and row['beforeEventOrdinal']==ordinal
   supply_seq+=1
   if 'address' in row:
    a=int(row['address'],16);size=row['size'];put(a,size,int(row['knownMask'],16) if 'knownMask' in row else None)
    if a<=0x89ce37<a+size:stop_byte_touches.append(('supply',row))
   continue
  if kind=='phaseCheckpoint':phases.append(row);assert row in r['phaseReceipts'];continue
  assert kind in arrays and row==arrays[kind][cursors[kind]],(kind,cursors[kind])
  cursors[kind]+=1;assert row['eventOrdinal']==ordinal;ordinal+=1
  if kind=='invalidation':
   if row['target']=='memory':put(int(row['address'],16),row['size'],int(row['knownMask'],16))
   continue
  pc=int(row['pc'],16);a=int(row['address'],16);size=row['size'];mask=int(row['knownMask'],16)
  assert pc in instructions and pc!=0x4eda87,(row['pc'],kind)
  assert not instructions[pc].mnemonic.startswith('f'),instructions[pc].mnemonic
  pcs[pc]+=1
  if kind=='read':assert get(a,size)==mask,(row,get(a,size))
  else:
   assert row['committed'] and size==1;put(a,size,mask)
   if a<=0x89ce37<a+size:stop_byte_touches.append(('write',row))
assert all(cursors[k]==len(v) for k,v in arrays.items()) and supply_seq==len(r['suppliedInputs'])
assert ordinal==r['eventStream']['eventCount'] and not stop_byte_touches and get(0x89ce37,1)==0
assert tracehash.hexdigest()==r['rawEventTrace']['uncompressedSha256'] and tracebytes==r['rawEventTrace']['uncompressedBytes']
assert get(0x2140000+6320,1602)==0
for x in r['finalSeeds']['classCounters']:assert get(int(x['address'],16),1)==int(x['knownMask'],16)
summary={'status':'ACCEPT_CONDITIONAL_DIAGNOSTIC_STOP','resultCompressedSha256':stream['sha256'],'resultUncompressedSha256':stream['uncompressedSha256'],'attempted':r['attemptedOriginalInstructions'],'committed':r['committedOriginalInstructions'],'eventCount':ordinal,'counts':dict(cursors),'supplies':supply_seq,'phaseCheckpoints':len(phases),'calls':len(r['calls']),'openCalls':r['openCalls'],'records':r['records'],'blocks':r['blocks'],'counterCopies':r['counterCopies'],'counterIncrements':r['counterIncrements'],'rngWrites':r['rngWrites'],'selectedAssertions':r['selectedAssertions'],'blocker':r['blocker'],'abortedInstructions':r['abortedInstructions'],'finalRegisters':r['finalRegisters'],'finalSeeds':r['finalSeeds'],'stopByteProvenance':{'knownMask':0,'suppliesOrCommittedWrites':[]},'animationTailMask':'all 1602 bytes unknown','observerValidation':'All raw rows equal final arrays; ordinals contiguous; mid-run supplies applied at exact insertion cursor; every read mask equals reconstructed prior supplies/committed writes/invalidations. Raw memory-event and call PCs match source-bound instruction boundaries.','limits':['Observer chronology is not retirement proof.','This is mask/provenance reconciliation, not independent CPU arithmetic replay.','Conditional model terrain and omitted-history/input seams remain as predeclared.','No successful allocation, record completion, class1 total or actual startup result established.'],'originalInstructionsExecutedByReviewer':0,'elapsedSeconds':time.monotonic()-started}
p=O/'constructor-ledger-run02-post-review.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':filehash(p),'events':ordinal,'counts':dict(cursors),'openCalls':len(r['openCalls']),'counterCopies':r['counterCopies'],'counterIncrements':r['counterIncrements'],'seconds':summary['elapsedSeconds']},indent=2),flush=True)
