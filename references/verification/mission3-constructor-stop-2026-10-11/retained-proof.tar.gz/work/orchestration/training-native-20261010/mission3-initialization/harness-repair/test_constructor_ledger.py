"""Synthetic authored x86 and host contract tests; NEVER executes canonical code."""
import gzip,hashlib,json,struct,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import unicorn
from unicorn import x86_const as x
import constructor_ledger_candidate as l
b=l.b
CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00
class FiniteIntegerTests(unittest.TestCase):
 def make(self,code,regs=None,flags=2,flagmask=b.MASK32):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:c.mem_map(a,4096)
  c.mem_write(CODE,code+b'\xc3');e=l.Ledger(c,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(code)+1)],protected_inputs=[])
  e.reg_supply('esp',STACK,b.MASK32,'synthetic');e.supply(STACK,l.pack(STOP),'synthetic return');e.reg_supply('eflags',flags,flagmask,'synthetic')
  for r,v in (regs or {}).items():e.reg_supply(r,v&b.MASK32,b.MASK32,'synthetic')
  return e
 def test_sub_same_unknown_half_register_defines_only_half(self):
  e=self.make(bytes.fromhex('662bd2'),{'edx':0x12345678});e.shadow.reg_put('edx',0);e.run(CODE,STOP)
  self.assertEqual(e.reg_value('edx'),0x12340000);self.assertEqual(e.shadow.reg_get('edx'),65535);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ARITH)
 def test_narrow_shifts_preserve_upper_mask(self):
  for code,val,want in [('66c1e003',0x12340011,0x12340088),('c0e001',0x12345681,0x12345602),('66c1f803',0x1234fff0,0x1234fffe)]:
   e=self.make(bytes.fromhex(code),{'eax':val});e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),want);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32)
 def test_shift_rejects_unknown_source_and_unsupported_counts(self):
  for code in ['66c1e010','c0e008','d3e0','67c1e001','f0c1e001']:
   e=self.make(bytes.fromhex(code),{'eax':1,'ecx':1})
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  e=self.make(bytes.fromhex('66c1e003'));e.shadow.reg_put('ax',0)
  with self.assertRaisesRegex(b.Blocked,'unbound'):e.run(CODE,STOP)
 def test_shift_zero_preserves_unknown_and_flags(self):
  e=self.make(bytes.fromhex('66c1e020'),{'eax':0x1234},flagmask=0);e.shadow.reg_put('eax',0x55);e.run(CODE,STOP)
  self.assertEqual(e.shadow.reg_get('eax'),0x55);self.assertEqual(e.shadow.reg['eflags'],0)
 def test_shift_zero_memory_models_read_and_committed_unchanged_write(self):
  e=self.make(bytes.fromhex('c12d0000200000'));e.supply(DATA,l.pack(42),'synthetic');e.shadow.put(DATA,4,0xabc);e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),l.pack(42));self.assertEqual(e.shadow.get(DATA,4),0xabc)
  self.assertTrue(any(r['address']==hex(DATA) for r in e.read_events))
 def test_ror_memory_rng_style(self):
  e=self.make(bytes.fromhex('c10d000020000d'),flags=2|b.ZF|b.SF);e.supply(DATA,l.pack(0x12345678),'synthetic');e.run(CODE,STOP)
  self.assertEqual(int.from_bytes(e.cpu.mem_read(DATA,4),'little'),0xb3c091a2);self.assertEqual(e.shadow.reg['eflags']&b.OF,0);self.assertEqual(e.shadow.reg['eflags']&(b.ZF|b.SF),b.ZF|b.SF)
 def test_ror_one_defines_of_only_with_true_count_one(self):
  e=self.make(bytes.fromhex('c0c801'),{'eax':0x80},flagmask=b.DF);e.run(CODE,STOP);self.assertEqual(e.shadow.reg['eflags'],b.DF|b.CF|b.OF)
  for code in ['c0c808','c0c809','66c1c810','66c1c811']:
   e=self.make(bytes.fromhex(code),{'eax':0x80})
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
 def test_word_division_preserves_upper_halves(self):
  e=self.make(bytes.fromhex('66f7f1'),{'eax':0xaabb0017,'edx':0xccdd0000,'ecx':6});e.run(CODE,STOP)
  self.assertEqual(e.reg_value('eax'),0xaabb0003);self.assertEqual(e.reg_value('edx'),0xccdd0005);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,0)
 def test_word_division_fault_rolls_back_no_committed_ordinal(self):
  for regs in [{'eax':1,'edx':0,'ecx':0},{'eax':0,'edx':1,'ecx':1}]:
   e=self.make(bytes.fromhex('66f7f1'),regs);old=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertEqual(e.event_ordinal,0);self.assertEqual(e.reg_value('eax'),int(old['eax']['value'],16));self.assertTrue(e.aborted)
 def test_word_imul_three_operand_flags(self):
  e=self.make(bytes.fromhex('666bc003'),{'eax':0xabcd8000});e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),0xabcd8000);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.OF)
 def test_not_and_neg_narrow(self):
  e=self.make(bytes.fromhex('f6d066f7d8'),{'eax':0x12340080});e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),0x1234ff81)
 def test_adc_and_sbb_require_carry(self):
  e=self.make(bytes.fromhex('83d0ff'),{'eax':4},flags=3);e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),4)
  e=self.make(bytes.fromhex('1bc0'),{'eax':5},flags=3,flagmask=b.CF);e.shadow.reg_put('eax',0);e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),b.MASK32);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32)
  e=self.make(bytes.fromhex('1bc0'),flagmask=0)
  with self.assertRaisesRegex(b.Blocked,'carry'):e.run(CODE,STOP)
 def test_known_untaken_branch_does_not_admit_target(self):
  e=self.make(bytes.fromhex('0f8500100000'),flags=2|b.ZF);e.run(CODE,STOP)
  e=self.make(bytes.fromhex('0f8500100000'),flags=2)
  with self.assertRaisesRegex(b.Blocked,'outside exact'):e.run(CODE,STOP)
 def test_unknown_branch_still_fails(self):
  e=self.make(bytes.fromhex('7400'),flagmask=0)
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
 def test_every_condition_matches_native_truth(self):
  for opcode in range(0x70,0x80):
   for flags in [0,b.CF,b.ZF,b.SF,b.OF,b.PF,b.ARITH]:
    # Taken jumps out of allowed window; untaken executes RET. Native executed
    # path itself confirms our guard permits exactly the non-taken cases.
    e=self.make(bytes([opcode,0x20]),flags=2|flags)
    truth={0x70:bool(flags&b.OF),0x71:not flags&b.OF,0x72:bool(flags&b.CF),0x73:not flags&b.CF,0x74:bool(flags&b.ZF),0x75:not flags&b.ZF,0x76:bool(flags&(b.CF|b.ZF)),0x77:not flags&(b.CF|b.ZF),0x78:bool(flags&b.SF),0x79:not flags&b.SF,0x7a:bool(flags&b.PF),0x7b:not flags&b.PF,0x7c:bool(flags&b.SF)!=bool(flags&b.OF),0x7d:bool(flags&b.SF)==bool(flags&b.OF),0x7e:bool(flags&b.ZF) or bool(flags&b.SF)!=bool(flags&b.OF),0x7f:not flags&b.ZF and bool(flags&b.SF)==bool(flags&b.OF)}[opcode]
    if truth:
     with self.assertRaisesRegex(b.Blocked,'outside exact'):e.run(CODE,STOP)
    else:e.run(CODE,STOP)
 def test_protected_data_write_fault_rolls_back_without_committed_write(self):
  e=self.make(bytes.fromhex('c7050000200011223344'));e.supply(DATA,l.pack(9),'synthetic readonly');e.cpu.mem_protect(DATA,4096,unicorn.UC_PROT_READ)
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),l.pack(9));self.assertFalse(e.write_events);self.assertEqual(e.committed,0);self.assertEqual(e.event_ordinal,0)
 def test_undefined_ror_of_cannot_drive_branch(self):
  e=self.make(bytes.fromhex('c1c80d7000'),{'eax':3})
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
 def test_event_order_memory_ror(self):
  e=self.make(bytes.fromhex('c10d000020000d'));e.supply(DATA,l.pack(11),'synthetic');e.run(CODE,STOP)
  rows=sorted(e.read_events+e.write_events,key=lambda r:r['eventOrdinal']);self.assertEqual([r['eventOrdinal'] for r in rows],list(range(len(rows))));self.assertEqual(rows[0]['address'],hex(DATA));self.assertTrue(all(r.get('committed') for r in rows[1:5]))

class SeamTests(unittest.TestCase):
 def make(self):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  level=bytearray(l.LEVEL_OFFSET+20*l.BLOCK_BYTES)
  for i in range(20):level[l.LEVEL_OFFSET+i*l.BLOCK_BYTES:l.LEVEL_OFFSET+(i+1)*l.BLOCK_BYTES]=bytes([i])*l.BLOCK_BYTES
  e=l.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[],level=bytes(level),protected_inputs=[],enable_tree_projection=True)
  e.reg_supply('esp',l.FRAME,b.MASK32,'synthetic');e.reg_supply('eip',l.NEXT,b.MASK32,'synthetic');e.reg_supply('edi',1,b.MASK32,'synthetic');e.reg_supply('eflags',2,b.MASK32,'synthetic');e.supply(l.FRAME+0x28,l.pack(20),'synthetic');return e
 def test_twenty_transport_spans_and_preserved_ordinals(self):
  e=self.make()
  for i in range(20):
   e.reg_supply('edi',1+100*i,b.MASK32,'synthetic iteration');e.supply(l.FRAME+0x28,l.pack(20-i),'synthetic decrement');e.transport(i)
   self.assertEqual(bytes(e.cpu.mem_read(l.BUFFER,l.BLOCK_BYTES)),bytes([i])*l.BLOCK_BYTES);self.assertEqual(e.observed(l.FRAME+0x18,4)['value'],l.BLOCK_BYTES)
  self.assertEqual(len(e.blocks),20);self.assertFalse(e.events);self.assertEqual(e.committed,0);self.assertEqual(e.event_ordinal,100)
 def test_transport_invalidates_entire_lower_stack_and_volatile_only(self):
  e=self.make();e.supply(l.STACK_BOTTOM,b'\xff'*64,'synthetic old stack');e.supply(l.FRAME-4,b'\xff'*4,'synthetic old stack');e.supply(l.FRAME+0x2c,l.pack(7),'synthetic caller');e.reg_supply('ebx',99,b.MASK32,'synthetic preserved');e.transport(0)
  self.assertEqual(e.shadow.get(l.STACK_BOTTOM,64),0);self.assertEqual(e.shadow.get(l.FRAME-4,4),0);self.assertEqual(e.observed(l.FRAME+0x2c,4)['value'],7);self.assertEqual(e.reg_value('ebx'),99)
  for r in ['eax','ecx','edx']:self.assertEqual(e.shadow.reg_get(r),0)
  self.assertEqual(e.shadow.reg['eflags']&b.ARITH,0)
 def test_transport_bad_frame_order_and_count_rejected(self):
  for kind in ['index','esp','edi','count','pc','open']:
   e=self.make()
   if kind=='esp':e.reg_supply('esp',l.FRAME+4,b.MASK32,'synthetic')
   if kind=='edi':e.reg_supply('edi',2,b.MASK32,'synthetic')
   if kind=='count':e.supply(l.FRAME+0x28,l.pack(19),'synthetic')
   if kind=='pc':e.reg_supply('eip',l.ENTRY,b.MASK32,'synthetic')
   if kind=='open':e.frames=[{}]
   with self.assertRaises(b.Blocked):e.transport(1 if kind=='index' else 0)
 def projection_ready(self):
  e=self.make();e.phase='authored-record-loop';e.windows=[(l.TREE_START,l.TREE_END+2)];e.frames=[{'caller':'0x4ed5b8','target':'0x4a5ef0','return':0x4ed5bd,'returnSp':l.FRAME+32}];e.record=2
  for r,val in [('esi',b.POOL+179),('ebx',l.v.TRIBE),('ecx',0),('ebp',0x1234),('edi',0x5678)]:e.reg_supply(r,val,b.MASK32,'synthetic context')
  e.supply(l.FRAME+0x10,l.pack(0xabcd),'synthetic local');e.supply(b.POOL+179+0x2b,b'\x03','synthetic model');e.supply(0x5a79c5+72,b'\x81','synthetic model flags');e.supply(0x96eaba,b'\0'*4,'synthetic old flags');return e
 def test_tree_projection_exact_unknown_outputs_and_preserved_context(self):
  e=self.projection_ready();before={r:e.register_snapshot()[r] for r in ['esi','edi','ebp','esp']};e.tree_projection()
  self.assertEqual(e.reg_value('eip'),l.TREE_END);self.assertEqual(e.shadow.get(0x96eaba,4),0);self.assertEqual(len(e.invalidation_events),6)
  for r in ['eax','edx','ebx','ecx']:self.assertEqual(e.shadow.reg_get(r),0)
  for r,old in before.items():self.assertEqual(e.register_snapshot()[r],old)
  self.assertEqual(e.observed(l.FRAME+0x10,4)['value'],0xabcd);self.assertEqual(e.committed,0);self.assertEqual(len(e.projections),1)
 def test_tree_projection_rejects_wrong_context_position_or_model(self):
  for kind in ['phase','caller','ebx','ecx','position','model','return','frame','window']:
   e=self.projection_ready()
   if kind=='phase':e.phase='wrong'
   if kind=='return':e.frames[0]['return']=0
   if kind=='frame':e.frames[0]['returnSp']+=4
   if kind=='window':e.windows=[]
   if kind=='caller':e.frames[0]['caller']='0x0'
   if kind=='ebx':e.reg_supply('ebx',0,b.MASK32,'synthetic')
   if kind=='ecx':e.reg_supply('ecx',1,b.MASK32,'synthetic')
   if kind=='position':e.shadow.reg_put('bp',0)
   if kind=='model':e.supply(0x5a79c5+72,b'\x85','synthetic')
   with self.assertRaises(b.Blocked):e.tree_projection()
 def test_no_inherited_projection_is_armed(self):self.assertEqual(self.make().skips,[])
 def test_partial_committed_counter_is_distinct_from_returned_allocations(self):
  e=self.make();e.supply(b.SEED,b'\x01','synthetic committed increment');e.counter_copies=[{'requestedClass':1,'knownMask':'0xff','counter':0}];e.counter_increments=[{'class':1,'valueAfter':{'value':1}}]
  r=l.ledger_assertions(e,False);self.assertEqual(r['committedClass1Increments'],1);self.assertEqual(r['fullyReturnedSuccessfulClass1Count'],0);self.assertFalse(r['fullStageAComplete'])
 def test_partial_copy_without_increment_keeps_seed(self):
  e=self.make();e.supply(b.SEED,b'\0','synthetic');e.counter_copies=[{'requestedClass':1,'knownMask':'0xff','counter':0}]
  self.assertEqual(l.ledger_assertions(e,False)['committedClass1Increments'],0)
 def test_incorrect_counter_law_rejected(self):
  e=self.make();e.supply(b.SEED,b'\x02','synthetic')
  with self.assertRaises(b.Blocked):l.ledger_assertions(e,False)
 def test_full_complete_requires_every_empty_slot(self):
  e=self.make();e.supply(b.SEED,b'\0','synthetic')
  with self.assertRaisesRegex(b.Blocked,'incomplete StageA'):l.ledger_assertions(e,True)
 def test_midrun_supplies_have_exact_observer_insertion_cursor(self):
  e=self.make();e.invalidation(l.NEXT,'memory',1,0,'synthetic',address=hex(l.BUFFER));e.supply(l.BUFFER,b'\x55','synthetic midrun');row=e.supplies[-1]
  self.assertEqual(row['beforeEventOrdinal'],1);self.assertEqual(row['supplySequence'],len(e.supplies)-1);self.assertEqual(row['phase'],e.phase)
  e.masked_supply(l.BUFFER,1,1,1,'synthetic bit');self.assertEqual(e.supplies[-1]['beforeEventOrdinal'],1);self.assertEqual(e.supplies[-1]['knownMask'],'0x1')
 def test_new_kernel_frame_expires_old_stack_knownness(self):
  e=self.make();e.supply(l.FRAME+0x200,l.pack(7),'synthetic previous locals');e.supply(l.FRAME-100,l.pack(8),'synthetic previous callee');e.boundary_registers('next')
  self.assertEqual(e.shadow.get(l.FRAME+0x200,4),0);self.assertEqual(e.shadow.get(l.FRAME-100,4),0)
 def test_lighting_sources_are_earlier_defaults_not_dat_bytes(self):
  e=self.make();e.level=bytes(l.LEVEL_OFFSET+20*l.BLOCK_BYTES);e.root=lambda *args:None;e.cut=lambda *args,**kw:None;e.run=lambda *args,**kw:None;e.checkpoint_seeds=lambda *args:None
  with patch.object(b,'validate_pool',return_value={}):l.setup(e,{})
  for a,value in [(0x937aae,28),(0x937aaf,15)]:
   self.assertEqual(e.observed(a,1)['value'],value);self.assertIn('00401040',next(r['source'] for r in e.supplies if r.get('address')==hex(a)));self.assertIn('not a DAT copy',next(r['source'] for r in e.supplies if r.get('address')==hex(a)))
 def test_approval_denial_precedes_native_cpu(self):
  with patch.object(l,'approval_bindings',return_value={'driverSha256':'correct','parentReleasedRunLane':True}):
   with self.assertRaises(b.Blocked):l.validate_approval({'driverSha256':'wrong','parentReleasedRunLane':True},{'source':{'trackedStatus':''}})
 def test_setup_order_host_mock_only(self):
  e=self.make();e.level=bytes(l.LEVEL_OFFSET+20*l.BLOCK_BYTES);calls=[]
  e.root=lambda a,name:calls.append(('root',a));e.cut=lambda a,z,name,regs=None:calls.append(('cut',a,z));e.run=lambda a,z,**kw:calls.append(('run',a,z));e.checkpoint_seeds=lambda name:None
  with patch.object(b,'validate_pool',return_value={'synthetic':True}):l.setup(e,{})
  self.assertLess(calls.index(('root',0x42b7f0)),calls.index(('root',0x4eef50)));self.assertLess(calls.index(('root',0x4eef50)),calls.index(('cut',0x42b27f,0x42b281)));self.assertLess(calls.index(('root',0x40c920)),calls.index(('root',0x40ce30)))

class StorageTests(unittest.TestCase):
 def test_gzip_trace_roundtrip_and_uncompressed_identity(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'trace.gz';t=l.GzipTrace(path);parts=['{"eventOrdinal":0,"knownMask":"0xff"}\n','{"eventOrdinal":1,"reason":"synthetic invalidation"}\n']
   for text in parts:t.write(text)
   t.flush();t.close();t.close();raw=''.join(parts).encode()
   self.assertEqual(gzip.decompress(path.read_bytes()),raw);self.assertEqual(t.uncompressed_bytes,len(raw));self.assertEqual(t.uncompressed_hash.hexdigest(),hashlib.sha256(raw).hexdigest())
 def test_diagnostic_exception_still_closes_terminal_gzip(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'trace.gz';t=l.GzipTrace(path)
   try:
    t.write('retained before diagnostic stop\n');raise b.Blocked('synthetic stop')
   except b.Blocked:pass
   finally:t.close()
   self.assertEqual(gzip.decompress(path.read_bytes()),b'retained before diagnostic stop\n');self.assertTrue(t.closed)
 def test_final_json_gzip_roundtrip_no_expanded_duplicate(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'result.json.gz';value={'memoryReads':[{'eventOrdinal':0,'knownMask':'0xff'}],'status':'synthetic'};receipt=l.write_bounded_json(path,value)
   raw=gzip.decompress(path.read_bytes());self.assertEqual(json.loads(raw),value);self.assertEqual(receipt['uncompressedBytes'],len(raw));self.assertEqual(receipt['uncompressedSha256'],hashlib.sha256(raw).hexdigest());self.assertFalse(path.with_suffix('.partial').exists());self.assertEqual(list(Path(td).iterdir()),[path])
 def test_json_limit_is_explicit_partial_not_silent_success(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'result.json.gz'
   with self.assertRaisesRegex(b.Blocked,'resource limit'):l.write_bounded_json(path,{'many':'a'*100},limit=20)
   self.assertFalse(path.exists());partial=path.with_suffix(path.suffix+'.partial');self.assertTrue(partial.exists());gzip.decompress(partial.read_bytes())
 def test_disk_admission_before_original_cpu_construction(self):
  with patch.object(l,'validate_approval'),patch.object(l.shutil,'disk_usage',return_value=SimpleNamespace(free=l.REQUIRED_FREE-1)),patch.object(b,'load_module') as native:
   with self.assertRaisesRegex(b.Blocked,'insufficient free'):l.execute(None,{},None,Path('.'))
   native.assert_not_called()
  with patch.object(l.shutil,'disk_usage',return_value=SimpleNamespace(free=l.REQUIRED_FREE)):
   self.assertEqual(l.check_storage(Path('.'))['requiredFreeBytes'],l.REQUIRED_FREE)
 def test_failed_final_assertion_cannot_claim_complete_host_mock_only(self):
  # Native helper and all engine execution are mocked; this is result assembly only.
  cpu=SimpleNamespace(mem_map=lambda *a:None);e=SimpleNamespace(forbidden={},trace_sink=None,transport=lambda i:None,run=lambda *a,**k:None,attempted=0,committed=0,blocker=None,last=[],event_stream=lambda:{},register_snapshot=lambda:{},snapshot=lambda:{})
  for name in ['phase_receipts','blocks','records','events','frames','allocations','counter_copies','counter_increments','rng_writes','publications','projections','aborted','supplies','read_events','write_events','invalidation_events']:setattr(e,name,[])
  def assertions(engine,complete):
   if complete:raise b.Blocked('synthetic final selected field unknown')
   return {'fullStageAComplete':False}
  with tempfile.TemporaryDirectory() as td,patch.object(l,'validate_approval'),patch.object(l,'check_storage',return_value={}),patch.object(b,'load_module',return_value=SimpleNamespace(native_cpu=lambda exe:(cpu,{'synthetic':True}))),patch.object(l,'Ledger',return_value=e),patch.object(l,'protect_image'),patch.object(l,'apply_entry'),patch.object(l,'setup'),patch.object(l,'ledger_assertions',side_effect=assertions),patch.object(l,'selected_seeds',return_value={}):
   result=l.execute(SimpleNamespace(imports={}),{'conditions':[],'selectedLedgerContract':{},'source':{}},{},Path(td))
   self.assertFalse(result['complete']);self.assertEqual(result['status'],'CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP');self.assertFalse(result['selectedAssertions']['fullStageAComplete'])
 def test_large_output_identity_uses_streaming_reads(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'large';raw=b'abc'*(l.MIB//3+2);path.write_bytes(raw)
   with patch.object(Path,'read_bytes',side_effect=AssertionError('whole-file read prohibited')):receipt=l.stream_file_record(path)
   self.assertEqual(receipt['bytes'],len(raw));self.assertEqual(receipt['sha256'],hashlib.sha256(raw).hexdigest())
 def test_trace_resource_boundary_has_explicit_headroom(self):
  with tempfile.TemporaryDirectory() as td:
   t=l.GzipTrace(Path(td)/'trace.gz',limit=1)
   self.assertTrue(t.near_limit());t.close()

class ImageProtectionTests(unittest.TestCase):
 def pe(self,sections,size=0x5000):
  raw=bytearray(1024);struct.pack_into('<I',raw,60,0x80);struct.pack_into('<H',raw,0x80+20,0xe0);struct.pack_into('<I',raw,0x80+24+28,b.BASE);struct.pack_into('<I',raw,0x80+24+56,size)
  rows=[]
  for i,(offset,flags) in enumerate(sections):
   struct.pack_into('<I',raw,0x80+24+0xe0+i*40+36,flags);rows.append({'name':str(i),'va':b.BASE+offset,'virtualSize':4096,'rawSize':4096})
  return SimpleNamespace(data=bytes(raw),sections=rows)
 def permissions(self,cpu,address):return next(p for lo,hi,p in cpu.mem_regions() if lo<=address<=hi)
 def test_real_helper_handles_gapped_map_and_smaller_image_than_shadow(self):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,8192);c.mem_map(b.BASE+0x3000,8192);c.mem_map(b.SCRATCH,4096)
  p=self.pe([(0x1000,0x60000020),(0x3000,0xc0000040),(0x4000,0x40000040)])
  l.protect_image(c,p)
  self.assertEqual(self.permissions(c,b.BASE),unicorn.UC_PROT_READ);self.assertEqual(self.permissions(c,b.BASE+0x1000),unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC);self.assertEqual(self.permissions(c,b.BASE+0x3000),unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE);self.assertEqual(self.permissions(c,b.BASE+0x4000),unicorn.UC_PROT_READ);self.assertEqual(self.permissions(c,b.SCRATCH),unicorn.UC_PROT_ALL)
  with self.assertRaises(unicorn.UcError):c.mem_read(b.BASE+0x2000,1)
 def test_actual_sized_contiguous_map_does_not_protect_shadow_tail(self):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,0x3000);p=self.pe([(0x1000,0x60000020),(0x2000,0xc0000040)],size=0x3000);l.protect_image(c,p)
  with self.assertRaises(unicorn.UcError):c.mem_read(b.BASE+0x3000,1)
 def test_section_outside_size_or_unmapped_section_rejected(self):
  for p in [self.pe([(0x4000,0x40000040)],size=0x3000),self.pe([(0x2000,0x40000040)],size=0x5000)]:
   c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,8192)
   with self.assertRaises(b.Blocked):l.protect_image(c,p)
   self.assertEqual(self.permissions(c,b.BASE),unicorn.UC_PROT_ALL)

if __name__=='__main__':unittest.main()
