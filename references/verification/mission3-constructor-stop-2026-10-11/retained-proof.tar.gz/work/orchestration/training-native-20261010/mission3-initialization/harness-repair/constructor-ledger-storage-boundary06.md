# Lossless storage revision for the conditional StageA diagnostic

The semantic/input/phase contract in constructor-ledger-boundary.md is unchanged.
The unexecuted05e182 driver and its tests/preflight/verification receipts remain
retained. This revision changes artifact storage and admission only.

Both the live event JSONL and final complete JSON are streamed through gzip. There
is no expanded duplicate on disk. Every event remains present; final JSON still
contains all original arrays. The event trace and the separate final-result stream
receipt bind the compressed file and exact uncompressed SHA256/byte length.
Normal and diagnostic terminal paths close the gzip footer. A partial file is not
reported as a complete result.

Conservative disk admission requires1,409,286,144 free bytes (1,344MiB):
512MiB maximum compressed event trace,512MiB maximum compressed final result,
64MiB other output allowance and256MiB free-space margin. The expanded final JSON
has a1,536MiB serialization cap but is never materialized as a disk duplicate.
The native observer checks compressed trace capacity with4MiB headroom before
the next instruction. A resource boundary is an explicit diagnostic stop, retaining
and closing the lossless trace. Final serialization uses a .partial name and only
renames after successful complete close; exceeding either final cap is an explicit
process failure, never silent event truncation. The complete event gzip is retained.
External concurrent disk use is still capable of an I/O failure, so the admission
receipt is an observed capacity snapshot rather than a reservation guarantee.

Synthetic tests cover row/JSON round trips and identities, terminal close after a
diagnostic exception, explicit partial-result behavior, capacity headroom and disk
rejection before original CPU construction. No new native instruction was executed
while preparing this storage revision.
