# Source-ordered reset and real palette-copy prefix

Status: one fresh-reviewed, parent-released prefix run passed. The pre-run contract below is retained as reviewed. Candidate `reset_palette_candidate.py` SHA256 8c79bb31264c233a6878136539f20339952b5085a200cd95b006e658048a8915. Both previously admitted drivers remain unchanged: projected reset `9a0a81d78c68376191c065096ada7b9658f3ac22b0391d3b76445570909588ed` and guarded base `2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`. Imports verify those hashes before use.

## New dependency being tested

Execute the real caller prefix `0042b590..0042b5a3`: outer pushes, EDI assignment, genuine reset call `0042b597`, real palette-copy call `0042b59c`, and actual `XOR EBX,EBX` at `0042b5a1`. Stop before the sunlight call at `0042b5a3`. This composes the reset into its actual immediate caller and preserves the unknown palette data through the intervening setup edge. It is not another separately invoked copy helper or a claim that later initialization is complete.

The only omitted original instructions remain the three exact camera fragments in the previously reviewed reset context. Their normal-return/no-fault condition and all unknown output/temporary-stack effects are retained. No palette instruction is skipped; no palette/RNG reader, API or file leaf is stubbed.

## Declared heap-location renaming

Canonical descriptor `005a3590` is `*PALETTE`, allocation size0x400, destination slot `0087eff8`, null tail slot. Startup `004a501d -> 0049bdf0` visits it using stride0x120; the starred-resource branch loads size at `0049c050`, calls the real allocation helper at `0049c057`, loads the destination slot address at `0049c05f`, and stores the returned pointer indirectly at `0049c065`. These are static facts, not an executed OS allocation. See `palette-source-audit.json` and the independent palette-boundary review.

The fixture conditions on a successful, live, disjoint 1024-byte allocation and renames its address to `02010000` inside already mapped scratch storage. Only `[0087eff8]` receives this scoped known model address. All1024 data bytes remain unknown. No current/prior palette file bytes, zero contents or original heap address are asserted. The startup alias `[0059df24]` remains unknown; an unbound alias consumer would stop. Allocation lifetime and historical content at actual globe entry are not proved.

The helper reads the exact source interval +0x1c0..+0x1ff and writes64 bytes at `00899f8d..00899fcc`. Its fixed size byte `00899f8b=16` is a genuine store. The relocated ADD's arithmetic-flag masks are invalidated at that ADD, before any claim; native XOR EBX immediately after the return establishes its own source-defined flags. At the stop, the pointer slot's knownness expires explicitly, so no future candidate can treat the fixture address as an original-address invariant.

## Guarded REP MOVSD extension

Only exact bytes F3 A5 are admitted by this extension. Address-size and segment overrides reject. A fully known count is required; zero count consumes no source, destination or direction value and causes no memory event. For a nonzero count, addresses and DF must be known. Each iteration copies the source's exact bit mask, using the existing transactional read/write journal; overlapping regions see only previously committed writes. Partial writes on a failing iteration roll back. REP does not alter arithmetic flag provenance. At the actual palette PC, caller/target/return, DF0, count and every source/destination position are additionally checked against the declared64-byte span.

## Exact predeclared end contract

Current manifest: `reset-palette-preflight02/reset-palette-preflight.json`. It declares33 fully known memory fields: the previous32 selected reset outputs plus the palette size byte. The64-byte cache and1024-byte abstract allocation must remain entirely unknown, as must both omitted floating words, EDX, expired `[0087eff8]` and unsupplied `[0059df24]`.

At `0042b5a3`, native EAX/EBX/ECX must be0; EDI must be `008979d3`; ESP must be initial STACK-8; EIP must equal the exact stop. ESI/EDX/EBP masks remain unknown. Meaningful arithmetic flags plus DF have mask0xcc5 and value0x44 under that mask; AF remains unknown. The outer saved EBX/EDI stack bytes remain unknown. There must be exactly16 ordered source reads and64 committed destination-byte writes with unknown masks, one relocated-flag event, no allocations and no open call frame.

Approval binds driver, both frozen dependencies, source/input identities, camera omissions, exact memory observables, heap contract, and register/unknown-output boundary contract. It must say `ACCEPT_RESET_PALETTE_PREFIX`; parent lane release is a separate requirement. Approval is checked before native CPU construction.

## Verification and limits

`reset-palette-verification-receipt.json` records compilation, static preparation and57 passing synthetic tests (42 existing plus15 new). The new tests cover mixed known bits, unknown copies, DF0/DF1, zero-count inaccessible addresses, overlap in both directions, source faults, cross-page destination rollback, flag preservation, unsupported prefixes, context, pointer expiry and approval binding. They use only authored synthetic code or host checks.

No sunlight, tribe reset, pool/terrain composition, bank6, allocator, record constructor, postpass or gameplay is authorized here. The new original command, only after fresh acceptance and explicit release, is `reset_palette_candidate.py run-prefix --out <new directory> --approval <new receipt>`, using the existing native venv. Preserve full process identity, timeout, status and result receipts; no automatic repair/retry after failure.

## Completed conditional result

The single admitted run finished at 2026-10-11 00:18:18 UTC, exit0, in1.92 seconds. It committed14,461 original instructions and passed all33 predeclared memory observations plus the exact CPU/stack and unknown-output contracts. All five genuine calls returned. The real palette REP made16 source reads and64 committed byte writes, all preserving unknown content; all1024 abstract allocation bytes remained unknown, the unsupplied alias remained unknown, and the renamed pointer expired at the stop. No sunlight or later stage ran.

`reset-palette-post-run-summary.json` binds raw and compressed results and host-only reconciliation. `reset-palette-run01-process-receipt.json` binds the exact command, released approval, tools and all three unchanged driver hashes. This closes the reviewed immediate caller edge only under the documented camera-normal-return and live-disjoint-palette conditions; it does not establish actual palette history or the complete Mission3 constructor.
