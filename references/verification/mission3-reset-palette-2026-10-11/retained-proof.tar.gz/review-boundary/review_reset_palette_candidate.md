# Reset/palette prefix: independent pre-run review

Verdict: **ACCEPT_RESET_PALETTE_PREFIX**, with the separate parent release still
required. Publication acceptance currently covers static/synthetic evidence only.
The hash-bound payload is `reset-palette-review-verdict.json`. No original
instruction was executed by this reviewer.

Frozen driver: `reset_palette_candidate.py`, SHA256
`8c79bb31264c233a6878136539f20339952b5085a200cd95b006e658048a8915`.
The inherited projected-reset and guarded-engine files remain unchanged.

## Checks

- Re-ran all 57 author synthetic tests and six independent adversarial tests.
  All 63 passed. The extra tests cover removal of old destination knowledge,
  self-copy masks, a partially readable first source word, unknown copied data
  later consumed by arithmetic, unsupported string variants, and relocated ADD
  flag taint planning. Only authored synthetic instructions were executed.
- Independently prepared the static manifest; it is byte-identical to the
  author's frozen preflight02. All source/input/driver/log/receipt fingerprints
  verified. HEAD `fed2c30b...` differs from the earlier proof head only by the
  reviewed projected-reset documentation/evidence publication.
- Independently bound 34 canonical palette assertions in eight exact windows.
  Descriptor `005a3590` is `*PALETTE`, size1024, destination slot `0087eff8`.
  The startup array loop reaches it and `0049c065` stores the allocator's returned
  pointer indirectly. An initial file fill exists; unchanged current palette
  content is deliberately not inferred from it.

## Accepted bounded mechanism

The candidate begins at actual caller `0042b590`, retains its outer frame and EDI
producer, calls reset and palette natively, executes `XOR EBX,EBX` at `0042b5a1`,
and stops at `0042b5a3` before sunlight. The three previously reviewed camera
omissions retain their normal/no-fault condition and precise taints.

One declared successful, live, disjoint1024-byte allocation is renamed to fixture
address `02010000`. This is a conditional abstract heap location, not a captured
original address or an executed/fabricated allocator return. Every allocation
byte stays unknown. No palette file or zero-content value is supplied. The exact
64-byte original REP MOVSD copy propagates those unknown masks to the cache.

The MOVSD extension admits only F3 A5, checks count/address/DF provenance, handles
zero count without touching memory, and retains transactional per-iteration fault
and overlap behavior. At the palette instruction, exact call context and every
source/destination position are additionally guarded. The address-dependent ADD
flags are tainted before the genuine caller XOR defines the final flags.

The predeclared final contract requires33 fully-known memory fields, exact CPU
and saved-stack masks, all64 cache bytes and1024 source bytes unknown, omitted
camera words unknown, EDX unknown, and startup alias `0059df24` unknown. The
renamed pointer slot's knownness expires at the stop. This prevents the current
fixture from silently admitting later pointer arithmetic or alias consumers.

No blocking review defect remains for this exact scope. Any later sunlight,
tribe/asset, constructor or gameplay extension needs its own source/semantics and
selected-output review. The next sunlight producer is an integer/table dependency
question; its name supplies no basis for an additional floating-point omission.
