# Reset/palette prefix run 01: independent post-review

Verdict: **ACCEPT_CONDITIONAL_RESET_PALETTE_PREFIX_RESULT**. This accepts the
retained result within its reviewed conditions. It admits no further execution.

The read-only verifier `verify_reset_palette_run01.py` passed. Its full receipt is
`reset-palette-run01-post-review.json`; command output is retained in the matching
`.log`. The reviewer executed zero original instructions.

## Verified result

- Exact released approval, immutable reviewer verdict, historical source HEAD,
  all three unchanged driver hashes, source/input identities, manifest, runtime
  tool identities and process result/log hashes match. Exit0 in1.9186seconds.
- Exactly14,461 attempted and committed original instructions. Five genuine
  calls returned. No error, blocker, aborted instruction, allocation, record or
  open call frame.
- All33 predeclared memory observations are fully known and correct. Both RNG
  words remain `0x09d78afe`, twelve class counters remain zero, and the original
  palette-cache size store establishes16. The complete CPU and saved-stack
  contract matches at `0042b5a3`, before sunlight.
- All39 read masks were reconstructed from declared supplies, committed writes
  and exact camera omissions. All57,508 committed byte-write masks have valid
  canonical PCs in the approved windows. Source-order reconstruction interleaves
  the16 palette iterations using their exact source/destination offsets.
- Original REP MOVSD reads sixteen unknown dwords from the renamed allocation's
  `+0x1c0..+0x1ff` span and writes exactly64 unknown cache bytes. All1024 allocation
  bytes stay unknown. There is no palette-file-content or zero-content supply.
- The renamed pointer's knowledge expires at the stop; alias`0059df24` remains
  unknown. ADD flags were tainted for relocation and the actual caller XOR
  independently establishes final mask`0xcc5`, value`0x44` under that mask.
- Three exact camera omissions/context checks match. Both skipped conversions
  invalidate `[0x23ecfcc,0x23ecfe0)`, the same20-byte footprint. All those bytes,
  both omitted camera words and EDX remain unknown at the final boundary.

The extra33 instruction commits relative to the prior reset-only result are
consistent with the retained outer prefix, actual palette helper/REP and XOR.
The trace establishes16 copying iterations; it is not a saved full instruction
trace. Reads and writes are separate arrays joined by canonical source/call
order. Writes store masks rather than value bytes; selected values are supported
by frozen final-memory assertions and canonical original last-writer instructions.

## Limits and next finite boundary

The result conditions on normal, fault-free completion of the omitted floating
fragments and a successful, live, disjoint1024-byte palette allocation. Renaming
that allocation is a scoped model, not a captured original heap address or a proof
of its lifetime at actual globe entry. No allocator, sunlight, tribe reset,
pool/terrain composition, bank6, constructor, postpass or gameplay ran. The class-1
counter is zero here; later allocation/RNG chronology remains unproved.

The next source-only target is actual call`0042b5a3 -> 00401040 -> 00401790`.
Bind the exact trig-table inputs and integer semantics rather than infer another
floating-point omission from the function name. The author's new inventory also
identifies fast-sqrt`00586000..00586034` in CSEG and its following32-word seed
table. Any future admission must source-review that exact helper window and its
data provenance, never restore the rejected broad CSEG permission. This report
does not admit that next helper or substitute its return.
