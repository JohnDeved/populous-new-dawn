"""Read-only receipt/source/trace validation; no original instructions executed."""
from pathlib import Path
import hashlib,importlib.util,json,struct
import capstone
ROOT=Path.cwd();BASE=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=BASE/'harness-repair';OUT=BASE/'review-boundary'
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda f:json.loads(f.read_text());digest=lambda v:sha(json.dumps(v,sort_keys=True).encode())
R=H/'reset-palette-run01';r=read(R/'reset-palette-result.json');m=read(R/'reset-palette-preflight.json');b=read(R/'preflight.json')
v=read(OUT/'reset-palette-review-verdict.json');process=read(H/'reset-palette-run01-process-receipt.json');a=read(H/'reset-palette-run01-approval-released.json')
assert sha((R/'reset-palette-result.json').read_bytes())=='2bb2f8d7bd4a3054df601e117d25d3ab176958d77545800908feabf1dc5a61f2'
assert a['parentReleasedRunLane'] is True and v['parentReleasedRunLane'] is False
for key,value in v.items():
    if key!='parentReleasedRunLane':assert a[key]==value,key
assert a['reviewVerdictSha256']==sha((OUT/'reset-palette-review-verdict.json').read_bytes())
assert process['approval']['sha256']==sha(Path(process['approval']['path']).read_bytes())
assert m==read(H/'reset-palette-preflight02/reset-palette-preflight.json')
assert process['exitCode']==0 and process['status']=='passed' and not process['trackedStatus']
assert process['sourceHead']==a['observedSourceHead']==m['source']['observedSourceHead']
assert process['tools']['unicorn']=='2.1.4' and process['tools']['capstone']=='5.0.7'
assert process['driversBefore']==process['driversAfter']
for file,value in process['driversBefore'].items():assert sha((H/file).read_bytes())==value
for file,value in v['reviewedHashes'].items():assert sha((H/file).read_bytes())==value,file
for file,record in process['artifacts'].items():
    raw=(H/file).read_bytes();assert len(raw)==record['bytes'] and sha(raw)==record['sha256'],file
for key,value in [('source',m['source']),('input',m['inputs']),('projection',m['omittedFragments']),('observable',m['selectedObservables']),('heap',m['heapContract']),('boundary',{'boundary':m['boundaryContract'],'unknownOutputs':m['requiredUnknownOutputs']})]:assert a[key+'BindingSha256']==digest(value),key
for record in [m['driver'],m['projectedReset'],m['frozenEngine'],m['executable'],*m['inputs'],*[v for v in m['source'].values() if isinstance(v,dict) and 'path' in v]]:
    raw=Path(record['path']).read_bytes();assert len(raw)==record['bytes'] and sha(raw)==record['sha256'],record['path']
for key in ['driver','projectedReset','frozenEngine','scope','conditionalAssumptions','heapContract','boundaryContract','notRun']:assert r[key]==m[key],key
assert r['status']=='RESET_PALETTE_PREFIX_SELECTED_OBSERVABLES_PASSED'
assert r['attemptedOriginalInstructions']==r['committedOriginalInstructions']==14461
assert r['blocker'] is None and r['error'] is None and not r['allocations'] and not r['openCalls'] and not r['abortedInstructions'] and r['recordsVisited']==0
calls=[('0x42b597','0x42bfa0',0x42b59c),('0x42bfce','0x4a32d0',0x42bfd3),('0x42c080','0x41ce00',0x42c085),('0x42c099','0x475530',0x42c09e),('0x42b59c','0x4a2920',0x42b5a1)]
assert [(e['caller'],e['target'],e['return']) for e in r['calls']]==calls and all(e['returned'] for e in r['calls'])
assert [e['parent'] for e in r['calls']]==[None,0,0,0,None]

spec=importlib.util.spec_from_file_location('static_reader',ROOT/'scripts/check-static-mission18-sky.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
pe=reader.PE32(Path(m['executable']['path']));assert sha(pe.data)==r['identity']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
# Reconstruct the retained arrays' interleaving with the exact source call order.
regions=[(0x42b590,0x42b59c),(0x42bfa0,0x42bfd3),(0x4a32d0,0x4a3330),(0x42bfd3,0x42c085),
         (0x41ce00,0x41ce2f),(0x42cfd0,0x42d03c),(0x42c085,0x42c09e),(0x475530,0x475548),
         (0x42c09e,0x42c12c),(0x42b59c,0x42b5a1),(0x4a2920,0x4a2944),(0x42b5a1,0x42b5a3)]
rows={};rank={};windows=[]
for lo,hi in regions:
    raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw)
    windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':sha(raw)})
    for i in ins:rank[i.address]=len(rank);rows[i.address]=i
assert rows[0x4a293f].bytes==b'\xf3\xa5' and rows[0x42b5a1].mnemonic=='xor' and rows[0x42b5a1].op_str=='ebx, ebx'
assert len(r['projections'])==3
footprints=[]
for idx,(event,expected) in enumerate(zip(r['projections'],m['omittedFragments'])):
    assert event['index']==idx and int(event['start'],16)==expected['start'] and int(event['stopExclusive'],16)==expected['stop']
    assert event['bytesSha256']==expected['sha256']==sha(pe.read(expected['start'],expected['stop']-expected['start']))
    before=event['registersBefore'];after=event['registersAfterInvalidation']
    assert before['ecx']=={'value':'0x5fe2f0','knownMask':'0xffffffff'} and event['espUnchanged']
    wanted=r['calls'][2]['returnSp']-(4 if idx==0 else 12)
    assert before['esp']=={'value':hex(wanted),'knownMask':'0xffffffff'}
    if idx:
        assert before['esi']=={'value':'0x5fe2f0','knownMask':'0xffffffff'}
        assert event['omittedCall']=='0x55bc54'
        assert [(int(i['address'],16),i['size']) for i in event['invalidations']]==[(wanted-20,20),(0x5fe3f4 if idx==1 else 0x5fe3f0,4)]
        assert after['eax']['knownMask']==after['edx']['knownMask']=='0x0' and int(after['eflags']['knownMask'],16)&0x8d5==0
        footprints.append((wanted-20,20))
    else:assert not event['invalidations']

known={};sources={};sup=r['suppliedInputs']
assert len(b['constantWrites'])==244 and len(sup)==248
for expected,observed in zip(b['constantWrites'],sup[:244]):
    addr=int(expected['address'],16);data=bytes.fromhex(expected['bytesHex'])
    assert observed['address']==hex(addr) and observed['size']==len(data) and observed['sha256']==sha(data)
    for j in range(len(data)):known[addr+j]=255;sources[addr+j]='constant descriptor'
assert sup[-4]['register']=='esp' and sup[-4]['value']=='0x23ed000' and sup[-4]['knownMask']=='0xffffffff'
assert sup[-3]['register']=='eflags' and sup[-3]['knownMask']=='0x400'
for addr,value,item in [(0x23ed000,0x23ee000,sup[-2]),(0x87eff8,0x2010000,sup[-1])]:
    assert item['address']==hex(addr) and item['size']==4 and item['sha256']==sha(struct.pack('<I',value))
    for j in range(4):known[addr+j]=255;sources[addr+j]='root fixture' if addr==0x23ed000 else 'scoped heap renaming'
assert len(r['memoryReads'])==39 and len(r['memoryWrites'])==57508
events=[]
for kind,priority,data in [('read',0,r['memoryReads']),('write',1,r['memoryWrites'])]:
    previous=-1
    for index,event in enumerate(data):
        pc=int(event['pc'],16);rr=rank[pc];assert rr>=previous;previous=rr
        assert any(int(lo,16)<=pc<int(hi,16) for lo,hi in m['allowedWindows'])
        assert not any(s['start']<=pc<s['stop'] for s in m['omittedFragments'])
        if kind=='write':assert event['committed'] is True and event['size']==1
        iteration=0
        if pc==0x4a293f:
            addr=int(event['address'],16)
            iteration=(addr-(0x20101c0 if kind=='read' else 0x899f8d))//4
            assert 0<=iteration<16
        events.append((rr,iteration,priority,index,kind,event))
for idx,event in enumerate(r['projections']):events.append((rank[int(event['start'],16)],0,-1,idx,'invalidate',event))
provenance=[]
for _,_,_,_,kind,event in sorted(events):
    if kind=='invalidate':
        for item in event['invalidations']:
            for addr in range(int(item['address'],16),int(item['address'],16)+item['size']):known[addr]=0;sources[addr]='omitted fragment '+event['start']
        continue
    addr=int(event['address'],16);n=event['size'];mask=int(event['knownMask'],16)
    if kind=='read':
        actual=sum(known.get(addr+j,0)<<(8*j) for j in range(n));assert actual==mask,(event,hex(actual))
        provenance.append({**event,'byteSources':[sources.get(addr+j,'unknown prior memory') for j in range(n)]})
    else:known[addr]=mask;sources[addr]=event['pc']
assert r['paletteScopeClosed'] is True
for j in range(4):known[0x87eff8+j]=0;sources[0x87eff8+j]='explicit scope expiration at0x42b5a3'
assert len(r['selectedObservableAssertions'])==len(m['selectedObservables'])==33
last_writers=[]
for expected,observed in zip(m['selectedObservables'],r['selectedObservableAssertions']):
    assert observed=={k:expected[k] for k in ['name','address','bytes']}|{'value':expected['expectedValue'],'knownMask':expected['requiredKnownMask']}
    addr=int(observed['address'],16);n=observed['bytes'];assert all(known.get(addr+j,0)==255 for j in range(n))
    pcs=sorted(set(sources[addr+j] for j in range(n)));assert all(pc.startswith('0x') for pc in pcs)
    last_writers.append({'name':observed['name'],'lastWriterPcs':pcs,'instructions':[rows[int(pc,16)].mnemonic+' '+rows[int(pc,16)].op_str for pc in pcs]})
for addr,n in [(0x899f8d,64),(0x2010000,1024),(0x87eff8,4),(0x59df24,4),(0x5fe3f0,8),(0x23ecff8,8),*footprints]:assert all(known.get(addr+j,0)==0 for j in range(n)),hex(addr)
assert r['paletteCacheKnownMask']==r['abstractAllocationKnownMask']=='0x0'
for key,addr in [('expiredPalettePointer',0x87eff8),('unsuppliedPaletteAlias',0x59df24),('savedOuterStack',0x23ecff8)]:assert r[key]=={'address':hex(addr),'value':None,'knownMask':'0x0'}
assert r['omittedWords']==[{'address':hex(addr),'value':None,'knownMask':'0x0'} for addr in [0x5fe3f0,0x5fe3f4]]
after=r['after']['registers'];contract=m['boundaryContract']
for reg,value in contract['knownRegisters'].items():assert after[reg]=={'value':hex(value),'knownMask':'0xffffffff'},reg
for reg in contract['unknownRegisters']:assert after[reg]['knownMask']=='0x0',reg
assert after['eflags']['knownMask']==contract['eflagsKnownMask'] and int(after['eflags']['value'],16)&int(contract['eflagsKnownMask'],16)==int(contract['eflagsValueUnderMask'],16)
assert r['relocatedFlagEvents']==[{'pc':'0x4a292d','effect':'arithmetic flags unknown due to heap renaming','actualKill':'0x42b5a1 XOR EBX,EBX'}]
copy_reads=[e for e in r['memoryReads'] if e['pc']=='0x4a293f'];copy_writes=[e for e in r['memoryWrites'] if e['pc']=='0x4a293f']
assert [(int(e['address'],16),e['size'],e['knownMask']) for e in copy_reads]==[(0x20101c0+4*i,4,'0x0') for i in range(16)]
assert [(int(e['address'],16),e['size'],e['knownMask']) for e in copy_writes]==[(0x899f8d+i,1,'0x0') for i in range(64)]
report={'verdict':'ACCEPT_CONDITIONAL_RESET_PALETTE_PREFIX_RESULT','reviewerOriginalInstructionsExecuted':0,
        'resultSha256':sha((R/'reset-palette-result.json').read_bytes()),'processReceiptSha256':sha((H/'reset-palette-run01-process-receipt.json').read_bytes()),
        'driverSha256':m['driver']['sha256'],'approvalSha256':process['approval']['sha256'],
        'committedOriginalInstructions':14461,'predeclaredKnownMemoryFieldsVerified':33,'projectionsVerified':3,'genuineCallsReturned':5,
        'memoryReadsReconstructed':39,'committedByteWritesVerified':57508,'paletteCopyIterations':16,'paletteUnknownBytesWritten':64,
        'abstractAllocationBytesRemainUnknown':1024,'abstractPointerScopeExpired':True,'startupAliasRemainsUnknown':True,
        'nativeXorKilledRelocatedFlags':True,'finalCpuAndStackMatchPredeclaredContract':True,
        'projectionStackFootprints':[{'address':hex(a),'bytes':n,'allRemainUnknown':True} for a,n in footprints],
        'sourceWindows':windows,'memoryReadProvenance':provenance,'selectedObservableLastWriters':last_writers,
        'conditions':m['conditionalAssumptions'],'notRun':m['notRun'],
        'evidenceLimits':['Separate read/write arrays are joined using the verified canonical call order; palette iterations additionally use exact source/destination offsets. This is not an independent instruction replay.',
                          'Write events retain masks, not values. Selected values are supported by frozen final-memory assertions and canonical original last writers.',
                          'Heap renaming is a scoped successful/live/disjoint allocation condition, not actual campaign address or lifetime capture.',
                          'Normal fault-free omitted floating-point work remains an explicit condition. No native constructor/gameplay equivalence or later RNG chronology is established.']}
out=OUT/'reset-palette-run01-post-review.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','committedOriginalInstructions','predeclaredKnownMemoryFieldsVerified','memoryReadsReconstructed','committedByteWritesVerified','paletteCopyIterations','reviewerOriginalInstructionsExecuted']}))
