"""Canonical static palette allocation/copy boundary review; no native execution."""
from pathlib import Path
import hashlib, importlib.util, json, struct, subprocess
import capstone
ROOT=Path.cwd()
OUT=ROOT/'work/orchestration/training-native-20261010/mission3-initialization/review-boundary'
spec=importlib.util.spec_from_file_location('static_reader',ROOT/'scripts/check-static-mission18-sky.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
pe=reader.PE32(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
windows=[(0x4a5018,0x4a5034),(0x49bdf0,0x49be1e),(0x49bed5,0x49bee1),
         (0x49c050,0x49c089),(0x526630,0x526645),(0x429c20,0x429c66),
         (0x4a2920,0x4a2944),(0x42b590,0x42b5a8)]
rows={};listing=[]
for lo,hi in windows:
    raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw)
    rows.update({i.address:i for i in ins})
    listing.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':sha(raw),
                    'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
checks=[]
def eq(pc,mnemonic,operands):
    i=rows[pc];assert(i.mnemonic,i.op_str)==(mnemonic,operands),(hex(pc),i.mnemonic,i.op_str)
    checks.append({'pc':hex(pc),'mnemonic':mnemonic,'operands':operands,'bytes':i.bytes.hex()})
for row in [(0x4a5018,'push','0x5a3470'),(0x4a501d,'call','0x49bdf0'),
            (0x4a5025,'mov','eax, dword ptr [0x87eff8]'),(0x4a502a,'mov','dword ptr [0x59df24], eax'),
            (0x49bdf8,'cmp','byte ptr [esi], 0x21'),(0x49be00,'add','esi, 0x120'),(0x49be06,'call','0x49beb0'),
            (0x49bed8,'cmp','byte ptr [edi], 0x2a'),(0x49bedb,'je','0x49c050'),
            (0x49c050,'mov','eax, dword ptr [edi + 0x116]'),(0x49c057,'call','0x526630'),
            (0x49c05f,'mov','ecx, dword ptr [edi + 0x10e]'),(0x49c065,'mov','dword ptr [ecx], eax'),
            (0x49c06f,'test','edx, edx'),(0x49c071,'je','0x49c089'),(0x52663c,'call','0x55c210'),
            (0x429c43,'mov','ecx, dword ptr [0x87eff8]'),(0x429c4a,'push','0x400'),
            (0x429c55,'call','0x525f80'),(0x429c5d,'call','0x4a2920'),
            (0x4a2920,'push','esi'),(0x4a2921,'mov','ecx, 0x10'),(0x4a2926,'push','edi'),
            (0x4a2927,'mov','esi, dword ptr [0x87eff8]'),(0x4a292d,'add','esi, 0x1c0'),
            (0x4a2933,'mov','edi, 0x899f8d'),(0x4a2938,'mov','byte ptr [0x899f8b], 0x10'),
            (0x4a293f,'rep movsd','dword ptr es:[edi], dword ptr [esi]'),
            (0x4a2941,'pop','edi'),(0x4a2942,'pop','esi'),(0x4a2943,'ret',''),
            (0x42b59c,'call','0x4a2920'),(0x42b5a1,'xor','ebx, ebx'),(0x42b5a3,'call','0x401040')]:eq(*row)
descriptor=pe.read(0x5a3590,0x120)
assert 0x5a3470+0x120==0x5a3590 and descriptor[:9]==b'*PALETTE\0'
assert struct.unpack_from('<III',descriptor,0x10e)==(0x87eff8,0,0x400)
assert 0x1c0+16*4<=0x400
report={'verdict':'VIABLE_SCOPED_ABSTRACT_ALLOCATION_CONTRACT_NOT_EXECUTION_ADMISSION',
        'originalInstructionsExecuted':0,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'exeSha256':sha(pe.data),'assertions':checks,'windows':listing,
        'descriptor':{'address':'0x5a3590','sha256':sha(descriptor),'path':'*PALETTE','destinationSlot':'0x87eff8','tailSlot':None,'allocationBytes':1024,
                      'producer':'0049c057 calls00526630 with1024, then0049c065 writes EAX through descriptor+10e.'},
        'directAlias':'004a502a copies allocated pointer to0059df24; do not silently bind or disregard this alias in wider compositions.',
        'initialFill':'00429c55 calls00525f80 with pointer and1024bytes, then00429c5d calls004a2920. Neither this nor a palette-file hash proves later globe bytes unchanged.',
        'copy':{'sourceOffset':'0x1c0','sourceEndOffsetExclusive':'0x200','bytes':64,'destination':'0x899f8d','destinationEndExclusive':'0x899fcd','sizeByte':'0x899f8b','sizeValue':16},
        'minimalContract':['Condition on successful startup allocation still live at this boundary, with at least1024readable bytes and ordinary RAM semantics.',
                           'Use one explicitly renamed fresh allocation disjoint from image, stack and all other declared allocations; keep all1024contents unknown.',
                           'Only bind0087eff8 to that renamed block for the reviewed copy. No selected current palette file or fabricated allocator execution/return.',
                           'ESI/EDI/ESP/DF and stack effects must be handled natively with provenance; ordinary cdecl DF=0 is declared, not inferred from zero-filled CPU state.',
                           'The exact64copied bytes remain unknown; size-byte16 and ECX0 may be known; preserve all unbound saved-register masks.',
                           'Heap-location-dependent arithmetic flags are not actual-entry invariants. The actual caller0042b5a1 XOR kills meaningful ADD flags before the next call; AF remains unknown.',
                           'Other aliases stay unknown unless consistently renamed. Scope or revoke the known abstract pointer after this copy, or separately review every future use and any pointer-derived observable.',
                           'Predeclare fully-known relevant outputs and reject unknown decisive consumption. Full constructor/gameplay or actual campaign capture remains outside this contract.'],
        'repMovsdSyntheticRequirements':['Mixed known-bit and unknown copy masks','DF0 and DF1','Zero ECX produces no memory access','Overlapping copies use per-iteration current source masks','Source and destination faults preserve only completed prior iterations','No arithmetic flag changes','Reject unsupported address-size/segment overrides'],
        'nextGate':'Fresh review of the exact extended semantics and selected composition/copy observables; no original run is admitted by this static result.'}
(OUT/'palette-boundary-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'assertions':len(checks),'windows':len(listing),'originalInstructionsExecuted':0}))
