"""Reviewer-authored synthetic instructions only; never reads/executes original PE."""
from pathlib import Path
import sys, unittest, struct
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'harness-repair'))
import test_reset_palette as t
q=t.q; b=t.b

class ExtraCopyTests(unittest.TestCase):
    def fixture(self,**kwargs): return t.CopyTests().make(**kwargs)
    def test_unknown_source_removes_old_destination_knowledge_only_in_span(self):
        e=self.fixture(count=2)
        e.supply(t.DEST,b'Z'*12,'synthetic previously known destination')
        e.cpu.mem_write(t.SOURCE,b'abcdefgh')
        e.run(t.CODE,t.STOP)
        self.assertEqual(e.shadow.get(t.DEST,8),0)
        self.assertEqual(e.shadow.get(t.DEST+8,4),b.MASK32)
        self.assertEqual(bytes(e.cpu.mem_read(t.DEST,12)),b'abcdefghZZZZ')
    def test_identical_source_destination_preserves_partial_masks(self):
        e=self.fixture(src=t.SOURCE,dst=t.SOURCE,count=2)
        e.cpu.mem_write(t.SOURCE,b'abcdefgh');e.shadow.put(t.SOURCE,8,0xff00aacc12345678)
        e.run(t.CODE,t.STOP)
        self.assertEqual(e.shadow.get(t.SOURCE,8),0xff00aacc12345678)
        self.assertEqual(bytes(e.cpu.mem_read(t.SOURCE,8)),b'abcdefgh')
    def test_partial_first_source_read_fault_cannot_commit_destination(self):
        e=self.fixture(src=t.SOURCE+4094,count=1)
        e.supply(t.SOURCE+4094,b'ab','synthetic partial source')
        e.supply(t.DEST,b'WXYZ','synthetic destination')
        with self.assertRaises(b.Blocked): e.run(t.CODE,t.STOP)
        self.assertEqual(e.committed,0)
        self.assertEqual(bytes(e.cpu.mem_read(t.DEST,4)),b'WXYZ')
        self.assertEqual(e.shadow.get(t.DEST,4),b.MASK32)
        self.assertEqual(e.reg_value('ecx'),1)
    def test_unknown_copy_cannot_later_drive_arithmetic(self):
        code=b'\xf3\xa5\xa1'+struct.pack('<I',t.DEST)+b'\x83\xc0\x01\xc3'
        e=self.fixture(code=code,count=1)
        e.cpu.mem_write(t.SOURCE,struct.pack('<I',123))
        with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'): e.run(t.CODE,t.STOP)
        self.assertEqual(e.shadow.get(t.DEST,4),0)
        self.assertEqual(e.shadow.reg_get('eax'),0)
    def test_unneeded_string_variants_fail_closed(self):
        for code in [b'\xf3\x66\xa5\xc3',b'\xf2\xa5\xc3',b'\x26\xf3\xa5\xc3']:
            e=self.fixture(code=code,count=1)
            with self.assertRaises(b.Blocked): e.run(t.CODE,t.STOP)
            self.assertEqual(e.committed,0)
    def test_relocated_add_planning_taints_flags_without_executing_it(self):
        e=self.fixture();e.enforce_palette_context=True;e.palette=t.SOURCE
        e.frames=[{'caller':'0x42b59c','target':'0x4a2920','return':0x42b5a1}]
        e.pending={'registers':{},'reads':[],'writes':[],'flags':None}
        # Inspect the planner only, using a generated ADD immediate instruction.
        ins=next(e.decoder.disasm(b'\x81\xc6'+struct.pack('<I',0x1c0),0x4a292d))
        e._plan(ins)
        self.assertEqual(e.pending['flags']&b.ARITH,0)
        self.assertEqual(e.pending['flags']&b.DF,b.DF)
        self.assertEqual(len(e.relocated_flag_events),1)
        self.assertEqual(e.reg_value('esi'),t.SOURCE)
        self.assertEqual(e.attempted,0)

if __name__=='__main__':unittest.main(verbosity=2)
