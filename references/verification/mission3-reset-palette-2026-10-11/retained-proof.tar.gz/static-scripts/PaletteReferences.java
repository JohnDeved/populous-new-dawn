import java.nio.file.*;
import ghidra.app.script.GhidraScript;
public class PaletteReferences extends GhidraScript {
 public void run() throws Exception {
  StringBuilder o=new StringBuilder();
  for(long a=0x00899f8bL;a<0x00899fcdL;a++) refs(o,a);
  refs(o,0x0087eff8L);
  Files.writeString(Path.of(getScriptArgs()[0]),o.toString());println("PALETTE_REFERENCES_COMPLETE");
 }
 void refs(StringBuilder o,long a) throws Exception { for(var r:getReferencesTo(toAddr(a))) {
  var f=getFunctionContaining(r.getFromAddress());var i=getInstructionAt(r.getFromAddress());
  o.append(Long.toHexString(a)).append("\t").append(r.getFromAddress()).append("\t").append(r.getReferenceType()).append("\t").append(f==null?"NO_FUNCTION":f.getEntryPoint()).append("\t").append(i==null?"DATA":i.toString()).append("\n");
 }}
}
