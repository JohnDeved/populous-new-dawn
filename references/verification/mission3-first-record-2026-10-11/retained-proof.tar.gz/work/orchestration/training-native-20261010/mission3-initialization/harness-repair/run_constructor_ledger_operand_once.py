#!/usr/bin/env python3
"""One explicitly released frozen diagnostic; process receipts, no retries."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,platform,subprocess,sys,time
HERE=Path(__file__).resolve().parent
SHA='423311e1247d3f84d9b0bad1ccc1ef58485a3187c8d455bee984a4e58039c856'
DRIVER=HERE/'constructor_ledger_operand_candidate.py'
def digest(path):
 h=hashlib.sha256();size=0
 with Path(path).open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk);size+=len(chunk)
 return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--approval',type=Path,required=True);a=ap.parse_args()
 if digest(DRIVER)['sha256']!=SHA:raise RuntimeError('frozen driver hash changed')
 spec=importlib.util.spec_from_file_location('released_ledger_driver',DRIVER);l=importlib.util.module_from_spec(spec);spec.loader.exec_module(l)
 m=json.loads((HERE/'ledger-operand-preflight01/constructor-ledger-preflight.json').read_text());approval=json.loads(a.approval.read_text());l.validate_approval(approval,m)
 out=HERE/'constructor-ledger-clear-run07';receipt_path=HERE/'constructor-ledger-clear-run07-process-receipt.json'
 if out.exists() or receipt_path.exists():raise RuntimeError('one-run output/receipt already exists; retry prohibited')
 drivers=['constructor_ledger_operand_candidate.py','constructor_ledger_context_candidate.py','constructor_ledger_budget_candidate.py','constructor_ledger_closure_candidate.py','constructor_ledger_inputs_candidate.py','constructor_ledger_candidate.py','preloader_candidate.py','sunlight_candidate.py','reset_palette_candidate.py','projected_reset_candidate.py','constructor_candidate.py']
 import unicorn,capstone
 command=[sys.executable,str(DRIVER),'run-ledger','--case','land-clear','--out',str(out),'--approval',str(a.approval.resolve())]
 start=time.monotonic();r={'status':'running','command':command,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=l.b.ROOT,text=True).strip(),'trackedStatus':subprocess.check_output(['git','status','--short'],cwd=l.b.ROOT,text=True).strip(),'approval':digest(a.approval),'wrapper':digest(Path(__file__)),'driversBefore':{n:digest(HERE/n)['sha256'] for n in drivers},'outerTimeoutSeconds':1200,'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tools':{'pythonExecutable':sys.executable,'pythonVersion':sys.version,'unicorn':unicorn.__version__,'capstone':capstone.__version__,'platform':platform.platform()},'storageAdmission':l.check_storage(HERE),'conditions':m['conditions']}
 receipt_path.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'status':'STARTED_EXACT_RELEASED_CONSTRUCTOR_DIAGNOSTIC','output':str(out),'driverSha256':SHA}),flush=True)
 stdout=HERE/'constructor-ledger-clear-run07-stdout.log';stderr=HERE/'constructor-ledger-clear-run07-stderr.log'
 try:
  with stdout.open('w') as so,stderr.open('w') as se:completed=subprocess.run(command,cwd=l.b.ROOT,stdout=so,stderr=se,timeout=1200)
  code=completed.returncode;r['status']='terminal';r['exitCode']=code
 except subprocess.TimeoutExpired:
  code=124;r['status']='outer-process-timeout';r['exitCode']=code
 r['elapsedSeconds']=time.monotonic()-start;r['finishedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['driversAfter']={n:digest(HERE/n)['sha256'] for n in drivers};r['artifacts']=[digest(p) for p in [stdout,stderr]+sorted(out.glob('*')) if p.is_file()]
 receipt_path.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'status':r['status'],'exitCode':code,'elapsedSeconds':r['elapsedSeconds'],'processReceipt':str(receipt_path)}),flush=True)
 print(stdout.read_text()[-20000:],flush=True)
 if stderr.stat().st_size:print(stderr.read_text()[-6000:],file=sys.stderr,flush=True)
 raise SystemExit(code)
if __name__=='__main__':main()
