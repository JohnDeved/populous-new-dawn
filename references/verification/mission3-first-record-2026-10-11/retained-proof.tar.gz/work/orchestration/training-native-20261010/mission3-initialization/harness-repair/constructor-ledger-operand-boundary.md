# Finite operand capability and actual animation dispatch repair

This separate candidate preserves run06 and frozen6efb7128. The last attempt stopped before executing `00404153 IDIV DWORD [ESP+3Ch]`, after two reviewed texture contexts. No allocation returned and no record completed.

## Bounded capability scan

`constructor-capability-audit01.json` scans9,332 distinct canonical instructions in all91 admitted windows, grouped into160 operand-form signatures. The19 retained dispatch tables all point to audited instruction boundaries. The181 direct control-flow edges outside admission remain explicit guarded residuals; no claim excludes nested allocation/state changes or proves their inactivity.

Exactly two static form gaps are repaired:

- DWORD memory IDIV, observed at00404153. It requires known EDX:EAX, the complete memory divisor and its effective address. The real original memory read and arithmetic instruction execute. Quotient/remainder masks commit only after successful completion; arithmetic flags become unknown. Zero divisors, signed quotient overflow and access faults retain native failure/transaction rollback. No unsigned memory DIV, narrower memory division, new multiplication or string forms are added.
- Byte-register SETLE, statically present at00422de5 in the admitted walk-mask helper. It requires known ZF/SF/OF, defines only the byte destination and preserves all flags and other register bits. This instruction was not reached by run06; admitting it addresses a foreseeable finite form gap without claiming path reachability.

All three CL shifts have canonical suppliers constraining their consumed counts to0..7. Existing finite shift semantics suffice. Unknown inputs still stop. The scan is a finite syntax/capability inventory, not an emulator-completeness or full native-lifetime proof.

Normative arithmetic reference: Intel's [instruction-set reference](https://cdrdv2-public.intel.com/789581/325383-sdm-vol-2abcd.pdf), IDIV and SETcc entries. The IDIV expectations use signed EDX:EAX divided toward zero, quotient range−2³¹..2³¹−1, and a signed remainder; divide errors do not produce committed outputs. Expectations and SETLE's eight flag combinations are independently specified in the synthetic test rather than copied from the driver.

## Actual setup-dispatch correction

The prior budget patch changed an unused `Ledger.cut` path. The direct animation `setup()` call still used240seconds in runs05/06. Their animation completion is valid under that original cap, but cannot be attributed to a300-second allowance. See the separate immutable `constructor-animation-dispatch-correction.md` and reviewer addendum.

This candidate changes the actual `setup()` call to300seconds. A host-only recorder invokes the real setup function, verifies its three preceding root selections, captures the exact animation call arguments and stops before executing anything. The same fixture shows240seconds in frozen6efb7128. Other phase/global/instruction/event/storage/outer bounds are unchanged.

## Tests and unchanged limits

The new tests cover signed divisor/dividend signs, high-half dividends, boundary quotients/remainders, zero/overflow rollback, address/divisor/CPU knownness, protection/cross-page faults, undefined-flag consumers, rejected prefixes/widths, all SETLE flag combinations and preserved subregister bits/flags. Existing16-bit signed/unsigned register division is regression-tested. The old historical caller fixtures and output-footprint guards remain unchanged.

No executable windows, input conditions, projections, class/model contexts, seed values, source producers, event representation or completed-allocation assertions change. Land-clear/class-seed0, model-derived terrain, valid/disjoint opaque resources and normal omitted-fragment completion remain conditional. First unknown consumer, unsupported target or fault still stops and preserves open calls and preceding committed counter mutations.

Fresh independent code/test/preflight review and a separate parent release are required before any run07. No original code has been executed by preparing or testing this candidate. Product check/build is not applicable to the ignored isolated research delta; publication HEAD will be bound by fresh static preflight.
