"""Independent file-only masks/source/call/first-record audit; no canonical CPU."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,importlib.util,json,struct,time
import capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';R=H/'constructor-ledger-clear-run07'
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1048576):h.update(data)
 return h.hexdigest()
started=time.monotonic();stream=read(R/'constructor-ledger-result-stream-receipt.json');process=read(H/'constructor-ledger-clear-run07-process-receipt.json');m=read(R/'constructor-ledger-preflight.json')
assert filehash(H/'constructor-ledger-clear-run07-process-receipt.json')=='c9ab69ca6afc355982d32da89cf3f8becd07e3e122715206b910abcb5509d8c6'
assert filehash(R/'constructor-ledger-result.json.gz')==stream['sha256']=='5422c12bce7ae031fed95e686619e6efd99738e062fce9133e827ca306d0cd11'
assert filehash(R/'constructor-ledger-events.jsonl.gz')=='6ebfa2da85370d5182f3c6597785d0cbc1dc0575cbe5e1db0819c06170ed531f'
h=hashlib.sha256();n=0
with gzip.open(R/'constructor-ledger-result.json.gz','rb') as f:
 while chunk:=f.read(1048576):h.update(chunk);n+=len(chunk)
assert n==stream['uncompressedBytes'] and h.hexdigest()==stream['uncompressedSha256']
with gzip.open(R/'constructor-ledger-result.json.gz','rt') as f:r=json.load(f)
print('loaded',flush=True)
assert process['status']=='terminal' and process['exitCode']==2 and not process['trackedStatus'];assert process['sourceHead']=='adae85b9df3085f2f63b4661195dd80fd633a2b3'
assert process['driversBefore']==process['driversAfter'] and len(process['driversBefore'])==11
for name,hash in process['driversAfter'].items():assert filehash(H/name)==hash
assert process['driversBefore']['constructor_ledger_operand_candidate.py']=='423311e1247d3f84d9b0bad1ccc1ef58485a3187c8d455bee984a4e58039c856'
for f in process['artifacts']+[process['wrapper']]:assert Path(f['path']).stat().st_size==f['bytes'] and filehash(Path(f['path']))==f['sha256']
ap=Path(process['approval']['path']);ap=ap if ap.is_absolute() else ROOT/ap;approval=read(ap);assert filehash(ap)==process['approval']['sha256'] and approval['parentReleasedRunLane']
for k,v in read(O/'constructor-ledger-operand-held-approval.json').items():
 if k!='parentReleasedRunLane':assert approval[k]==v
assert r['conditions']==m['conditions'] and r['selectedLedgerContract']==m['selectedLedgerContract']
assert r['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP' and r['complete'] is False;assert (r['attemptedOriginalInstructions'],r['committedOriginalInstructions'])==(4077815,4077814)
assert r['blocker']=={'reason':'unbound consumed operand','phase':'authored-record-loop','record':2,'pc':'0x4ed8ed','details':{'knownMask':'0x0','requiredMask':'0xff','instruction':'inc byte ptr [0x96ead5]'}}
assert r['abortedInstructions']==[{'pc':'0x4ed8ed','instruction':'inc byte ptr [0x96ead5]','bytes':'fe05d5ea9600','status':'not-committed','attemptedWrites':[]}]
assert len(r['returnedAllocations'])==len(r['publications'])==len(r['openCalls'])==1
ret=r['returnedAllocations'][0];pub=r['publications'][0];pending=r['openCalls'][0];assert ret['sequence']==2065 and ret['returned'] and ret['originRecord']==1 and ret['return']==0x485016 and ret['target']=='0x4ed8a0';assert ret['returnRegisters']['eax']=={'value':'0x8fc2f5','knownMask':'0xffffffff'}
assert pending['sequence']==2115 and pending['originRecord']==2 and pending['caller']=='0x485011' and pending['target']=='0x4ed8a0' and not pending['returned']
assert len(r['records'])==2 and len(r['blocks'])==1;assert [x['status'] for x in r['records']]==['completed','entered'];assert r['records'][0]['completedInstruction']==4077744
level=Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/levels/levl2003.dat').read_bytes();assert sha(level)=='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf'
for i,x in enumerate(r['records']):assert x['record']==i+1 and x['rawHex']==level[0x14043+i*55:0x14043+(i+1)*55].hex()
assert (r['records'][0]['class'],r['records'][0]['model'],r['records'][1]['class'],r['records'][1]['model'])==(2,1,5,3)
assert r['selectedAssertions']['completedRecords']==1 and not r['selectedAssertions']['fullStageAComplete'];assert r['selectedAssertions']['committedClass1Copies']==r['selectedAssertions']['committedClass1Increments']==r['selectedAssertions']['fullyReturnedSuccessfulClass1Count']==0
assert r['selectedAssertions']['finalKnownClass1Seed']=={'address':'0x96eac2','value':0,'knownMask':'0xff'}
for p in r['phaseReceipts']:
 if 'seedPreservation' in p:
  assert all(x['value']==0x09d78afe and x['knownMask']=='0xffffffff' for x in p['seedPreservation']['rng']);assert all(x['value']==0 and x['knownMask']=='0xff' for x in p['seedPreservation']['classCounters'])
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);pe=module.PE32(Path(m['executable']['path']));assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;instructions={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);assert sha(data)==w['sha256'];ii=list(cs.disasm(data,lo));assert sum(x.size for x in ii)==len(data);instructions.update({x.address:x for x in ii})
assert pe.read(0x4ed8ed,6).hex()=='fe05d5ea9600';assert instructions[0x485035].mnemonic=='mov' and instructions[0x485035].op_str=='dword ptr [ebp + 8], edi'
for call in r['calls']:
 pc=int(call['caller'],16);target=int(call['target'],16);assert pc in instructions and target in instructions;assert instructions[pc].mnemonic=='call'
 if instructions[pc].operands[0].type==capstone.x86.X86_OP_IMM:assert instructions[pc].operands[0].imm==target
 assert call['returned'] or call in r['openCalls']
post=[c for c in r['calls'] if c['caller']=='0x48502d'];assert len(post)==1 and post[0]['target']=='0x485b00' and post[0]['returned'] and post[0]['originRecord']==1 and post[0]['return']==0x485032
# Field values are checked against the retained raw snapshot bytes, masks against
# the independently reconstructed observer history. No full CPU value emulation.
fields={'id':(0x24,2,639),'class':(0x2a,1,2),'model':(0x2b,1,1),'state':(0x2c,1,2),'counter':(0x2e,1,0),'ownerRaw':(0x2f,1,0),'prev':(0,4,0),'next':(4,4,0)}
for obj in [ret['allocation'],pub['object']]:
 assert obj['pointer']=='0x8fc2f5' and obj['validPoolSlot'];raw=bytes.fromhex(obj['rawHex']);mask=bytes.fromhex(obj['knownBitsHex']);assert len(raw)==len(mask)==179
 for field,(off,size,value) in fields.items():assert int.from_bytes(raw[off:off+size],'little')==value and mask[off:off+size]==bytes([255])*size and obj[field]['value']==value
assert int.from_bytes(bytes.fromhex(ret['allocation']['rawHex'])[8:12],'little')==0
assert pub['record']==1 and pub['pointer']=='0x8fc2f5' and pub['publishedID']=={'address':'0x8fc2fd','value':1,'knownMask':'0xffffffff'};assert bytes.fromhex(pub['object']['rawHex'])[8:12]==b'\x01\0\0\0'
ranges=[(0x400000,bytearray(0xd4e000-0x400000)),(0x2000000,bytearray(0x400000))]
def location(a,n):
 for base,mem in ranges:
  if base<=a and a+n<=base+len(mem):return mem,a-base
 raise AssertionError(('outside domain',hex(a),n))
def put(a,n,mask=None):
 mem,off=location(a,n);mem[off:off+n]=bytes([255])*n if mask is None else mask.to_bytes(n,'little')
def get(a,n):
 mem,off=location(a,n);return int.from_bytes(mem[off:off+n],'little')
arrays={'read':r['memoryReads'],'write':r['memoryWrites'],'invalidation':r['invalidationEvents']};cursors=Counter();ordinal=0;supply_seq=0;phases=[];pcs=Counter();tracehash=hashlib.sha256();tracebytes=0;stop_touches=[];publication_writes=[];object_mask_at_publication=None
with gzip.open(R/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  tracehash.update(line);tracebytes+=len(line);row=json.loads(line);kind=row.pop('kind')
  if kind=='conditionedSupply':
   assert row==r['suppliedInputs'][supply_seq] and row['supplySequence']==supply_seq and row['beforeEventOrdinal']==ordinal;supply_seq+=1
   if 'address' in row:
    a=int(row['address'],16);size=row['size'];put(a,size,int(row['knownMask'],16) if 'knownMask' in row else None)
    if a<=0x96ead5<a+size:stop_touches.append(('supply',row))
   continue
  if kind=='phaseCheckpoint':phases.append(row);assert row in r['phaseReceipts'];continue
  assert kind in arrays and row==arrays[kind][cursors[kind]];cursors[kind]+=1;assert row['eventOrdinal']==ordinal;ordinal+=1
  if kind=='invalidation':
   if row['target']=='memory':put(int(row['address'],16),row['size'],int(row['knownMask'],16))
   continue
  pc=int(row['pc'],16);a=int(row['address'],16);size=row['size'];mask=int(row['knownMask'],16);assert pc in instructions and pc!=0x4ed8ed;assert not instructions[pc].mnemonic.startswith('f');pcs[pc]+=1
  if kind=='read':assert get(a,size)==mask,(row,get(a,size))
  else:
   assert row['committed'] and size==1;put(a,size,mask)
   if a<=0x96ead5<a+size:stop_touches.append(('write',row))
   if pc==0x485035:publication_writes.append(row);object_mask_at_publication=get(0x8fc2f5,179)
assert all(cursors[k]==len(v) for k,v in arrays.items()) and supply_seq==len(r['suppliedInputs']);assert ordinal==r['eventStream']['eventCount'];assert tracehash.hexdigest()==r['rawEventTrace']['uncompressedSha256'] and tracebytes==r['rawEventTrace']['uncompressedBytes']
assert get(0x96ead5,1)==0 and not stop_touches
assert len(publication_writes)==4 and [int(x['address'],16) for x in publication_writes]==list(range(0x8fc2fd,0x8fc301)) and all(x['knownMask']=='0xff' for x in publication_writes)
assert object_mask_at_publication==int.from_bytes(bytes.fromhex(pub['object']['knownBitsHex']),'little')
assert get(0x2140000+6320,1602)==0
for x in r['finalSeeds']['classCounters']:assert get(int(x['address'],16),1)==int(x['knownMask'],16)
assert len(r['projections'])==2;inv=[x for x in r['invalidationEvents'] if x['pc']=='0x4bdebe'];assert len(inv)==24
for index,projection in enumerate(r['projections']):
 assert projection['start']=='0x4bdebe' and projection['endExclusive']=='0x4bdfdb' and projection['classModel']==[2,1];sp=int(projection['entryRegisters']['esp']['value'],16);group=inv[index*12:(index+1)*12]
 expected=[('memory',sp-156,156),('memory',sp+16,6),('memory',sp+28,4),('memory',0x9bc318,1024)];actual=[(x['target'],int(x['address'],16),x['size']) for x in group if x['target']=='memory'];assert sorted(actual)==sorted(expected)
 assert all(x['knownMask']=='0x0' for x in group if x['target']=='memory');assert [x['register'] for x in group if x['target']=='register']==['eax','ebx','ecx','edx','esi','edi','ebp','eflags'];assert all(x['knownMask']=='0x0' for x in group if x.get('register') not in [None,'eflags']);assert int(group[-1]['knownMask'],16)&0x8d5==0
assert get(0x9bc318,1024)==0 and all(get(a,4)==0 for a in [0x9bcfc8,0x9bcfd8,0x5d45b0]);assert not any(0x4bdebe<=pc<0x4bdfdb or 0x4bee20<=pc<0x4bf622 for pc in pcs);assert pcs[0x404153]==1
assert not any(x['target'] in ['0x4bee20','0x4bf1b0'] for x in r['calls'])
stat_counts={}
for pc,address in [(0x44de5b,0x68c6d0),(0x44deab,0x6906dc)]:
 reads=[x for x in r['memoryReads'] if int(x['pc'],16)==pc];writes=[x for x in r['memoryWrites'] if int(x['pc'],16)==pc];assert all(x['knownMask']=='0x0' and int(x['address'],16)==address and x['size']==4 for x in reads);assert len(writes)==4*len(reads) and all(x['knownMask']=='0x0' and address<=int(x['address'],16)<address+4 for x in writes);stat_counts[hex(pc)]={'reads':len(reads),'byteWrites':len(writes)}
summary={'verdict':'ACCEPT_CONDITIONAL_FIRST_RECORD_COMPLETION_AND_SECOND_RECORD_UNKNOWN_STOP','originalInstructionsExecutedByReviewer':0,'resultCompressedSha256':stream['sha256'],'resultExpandedSha256':stream['uncompressedSha256'],'attempted':r['attemptedOriginalInstructions'],'committed':r['committedOriginalInstructions'],'eventCount':ordinal,'counts':dict(cursors),'supplies':supply_seq,'phaseCheckpoints':len(phases),'calls':len(r['calls']),'firstAllocation':ret,'firstRecord':r['records'][0],'postprocessCall':post[0],'publication':pub,'publicationWriteEvents':publication_writes,'poolSlotIdVersusAuthoredId':'WORD pool identity atobject+0x24=639; separate DWORD authored record identity atobject+0x08=1.','pendingSecondRecord':r['records'][1],'openCalls':r['openCalls'],'counterCopies':r['counterCopies'],'counterIncrements':r['counterIncrements'],'selectedAssertions':r['selectedAssertions'],'blocker':r['blocker'],'abortedInstructions':r['abortedInstructions'],'unknownCounter':{'address':'0x96ead5','reconstructedKnownMask':0,'suppliesOrWrites':stop_touches,'rejectedInstructionMemoryEvents':0},'projectionCount':2,'projectionInvalidations':inv,'statisticEvents':stat_counts,'finalSeeds':r['finalSeeds'],'rngWrites':r['rngWrites'],'observerValidation':'All raw observer rows equal retained final arrays; ordinals contiguous; supplies applied at exact insertion cursors; every read mask equals reconstructed prior supply/committed write/invalidation. Raw memory/call PCs match canonical instruction boundaries.','valueChecks':'Selected object fields independently decoded from raw179-byte snapshots; published ID1 checked against known native EDI/source MOV and four committed write locations. This is not an independent interpreter of all CPU arithmetic or all memory values.','limits':['One conditional class2/model1 Hut allocation and authored record complete; second class5/model3 scenery allocator stops before unknown auxiliary counter mutation.','Class1 remains untouched; no whole2000-record completion, final person count, actual startup seed or product repair claim.','Engine attempted/committed instruction counts remain metadata, not inferred from observer ordinals.','All predeclared selected-state lifetime, model-terrain, transport and opaque projection conditions remain explicit.','SETLE path execution is not inferred from opcode admission. Unknown scenery counter cannot be assigned zero from this stop alone.'],'elapsedSeconds':time.monotonic()-started,'verifierSha256':filehash(Path(__file__))}
p=O/'constructor-ledger-run07-post-review.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'status':summary['verdict'],'sha256':filehash(p),'events':ordinal,'counts':dict(cursors),'seconds':summary['elapsedSeconds']},indent=2),flush=True)
