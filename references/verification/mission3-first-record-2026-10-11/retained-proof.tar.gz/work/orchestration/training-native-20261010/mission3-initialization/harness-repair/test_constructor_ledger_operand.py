"""Independent arithmetic expectations and intercepted real setup; synthetic x86 only."""
import hashlib,itertools,json,unittest
from types import SimpleNamespace
import unicorn
import constructor_ledger_operand_candidate as l
import constructor_ledger_context_candidate as old
b=l.b;CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00
class OperandTests(unittest.TestCase):
 def make(self,raw='f77c243c',low=17,high=0,divisor=5,flags=2|b.CF|b.OF,flagmask=b.MASK32):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:c.mem_map(a,4096)
  code=bytes.fromhex(raw);c.mem_write(CODE,code+b'\xc3');e=l.Ledger(c,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(code)+1)],protected_inputs=[])
  for r,v in [('esp',STACK),('eax',low),('edx',high),('ecx',DATA),('ebx',0),('esi',0),('edi',0)]:e.reg_supply(r,v&b.MASK32,b.MASK32,'authored synthetic arithmetic operand')
  e.reg_supply('eflags',flags,flagmask,'authored synthetic flags');e.supply(STACK,l.pack(STOP),'synthetic root stop');e.supply(STACK+0x3c,l.pack(divisor&b.MASK32),'synthetic divisor');e.supply(DATA,l.pack(divisor&b.MASK32),'synthetic effective-address divisor');return e
 @staticmethod
 def expected_signed(low,high,divisor):
  dividend=(high&b.MASK32)<<32|(low&b.MASK32)
  if dividend&(1<<63):dividend-=1<<64
  d=divisor&b.MASK32
  if d&(1<<31):d-=1<<32
  q=abs(dividend)//abs(d)
  if (dividend<0)!=(d<0):q=-q
  return q,dividend-q*d
 def test_signed_memory_division_all_signs_and_boundary_results(self):
  for n,d in [(17,5),(-17,5),(17,-5),(-17,-5),(0,7),(0x7fffffff,1),(-0x80000000,1),(-0x80000000,2),(2**32+8,3)]:
   low=n&b.MASK32;high=(n>>32)&b.MASK32;e=self.make(low=low,high=high,divisor=d);q,r=self.expected_signed(low,high,d);e.run(CODE,STOP)
   self.assertEqual(e.reg_value('eax'),q&b.MASK32);self.assertEqual(e.reg_value('edx'),r&b.MASK32);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32);self.assertEqual(e.shadow.reg_get('edx'),b.MASK32);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,0);self.assertTrue(any(x['pc']==hex(CODE) and x['address']==hex(STACK+0x3c) and x['knownMask']=='0xffffffff' for x in e.read_events));self.assertFalse(e.write_events)
 def test_known_effective_address_register_index_and_absolute_forms(self):
  for raw in ['f739','f73c19','f73d00002000']:
   e=self.make(raw=raw,low=17,divisor=5);e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),3);self.assertEqual(e.reg_value('edx'),2)
 def test_division_requires_both_halves_and_complete_divisor(self):
  for reg in ['eax','edx']:
   e=self.make();e.shadow.reg_put(reg,b.MASK32^1)
   with self.assertRaisesRegex(b.Blocked,'memory IDIV dividend'):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events)
  for mask in [0,0xff,0x7fffffff]:
   e=self.make();e.shadow.put(STACK+0x3c,4,mask)
   with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_unknown_base_or_index_rejects_before_native_read(self):
  for raw,reg in [('f739','ecx'),('f73c19','ebx')]:
   e=self.make(raw=raw);e.shadow.reg_put(reg,0)
   with self.assertRaisesRegex(b.Blocked,'address register'):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.read_events)
 def test_zero_and_signed_quotient_overflow_rollback(self):
  for low,high,d in [(17,0,0),(0x80000000,0xffffffff,-1),(0,1,1),(0,0xffffffff,1)]:
   e=self.make(low=low,high=high,divisor=d);before=e.register_snapshot();before_bytes=bytes(e.cpu.mem_read(STACK,64))
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events);self.assertEqual(bytes(e.cpu.mem_read(STACK,64)),before_bytes)
   for reg in ['eax','edx','esp','eflags']:self.assertEqual(e.register_snapshot()[reg],before[reg])
   self.assertEqual(e.aborted[0]['attemptedWrites'],[]);self.assertNotIn('eventOrdinal',e.aborted[0]);self.assertEqual(e.event_ordinal,len(e.read_events))
 def test_divisor_read_protection_and_cross_page_fault_rollback(self):
  for raw,address,protect in [('f739',DATA,True),('f739',DATA+4094,False)]:
   e=self.make(raw=raw);e.reg_supply('ecx',address,b.MASK32,'synthetic fault address');e.shadow.put(address,min(4,DATA+4096-address),0xffff)
   if protect:e.shadow.put(address,4,b.MASK32);e.cpu.mem_protect(DATA,4096,unicorn.UC_PROT_NONE)
   before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events)
   for r in ['eax','edx','esp','eflags']:self.assertEqual(e.register_snapshot()[r],before[r])
 def test_undefined_division_flags_cannot_feed_branch_or_setle(self):
  for tail in ['7400','0f9ec0']:
   e=self.make(raw='f77c243c'+tail)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,1);self.assertFalse(e.write_events)
 def test_unadmitted_division_width_prefix_and_unsigned_memory_reject(self):
  for raw in ['66f77c243c','f67c243c','f774243c','67f77c243c','f0f77c243c']:
   e=self.make(raw=raw)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_existing_unsigned_word_division_independent_values_and_upper_masks(self):
  for lo,hi,d in [(23,0,6),(1,1,3),(0xffff,0,1)]:
   e=self.make(raw='66f7f1',low=0xabcd0000|lo,high=0xef120000|hi);e.reg_supply('ecx',d,b.MASK32,'synthetic word divisor');e.run(CODE,STOP);q,r=divmod((hi<<16)|lo,d);self.assertEqual(e.reg_value('eax'),0xabcd0000|q);self.assertEqual(e.reg_value('edx'),0xef120000|r)
 def test_existing_word_divide_errors_and_signed_boundary(self):
  for raw,lo,hi,d in [('66f7f1',1,0,0),('66f7f1',0,1,1),('66f7f9',0x8000,0xffff,0xffff)]:
   e=self.make(raw=raw,low=lo,high=hi);e.reg_supply('ecx',d,b.MASK32,'synthetic');before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events)
   for r in ['eax','edx','eflags']:self.assertEqual(e.register_snapshot()[r],before[r])
 def test_setle_independent_truth_table_preserves_flags_and_other_bits(self):
  for zf,sf,of in itertools.product([0,1],repeat=3):
   flags=2|b.CF|b.PF|b.AF|(b.ZF if zf else 0)|(b.SF if sf else 0)|(b.OF if of else 0)
   for raw,shift in [('0f9ec0',0),('0f9ec4',8)]:
    e=self.make(raw=raw,low=0xa1b2c3d4,flags=flags,flagmask=b.ZF|b.SF|b.OF);e.shadow.reg_put('eax',0x00ff00ff);e.run(CODE,STOP);want=1 if zf or sf!=of else 0;mask=255<<shift
    self.assertEqual(e.reg_value('eax'),(0xa1b2c3d4&~mask)|(want<<shift));self.assertEqual(e.shadow.reg_get('eax'),0x00ff00ff|mask);self.assertEqual(e.reg_value('eflags'),flags);self.assertEqual(e.shadow.reg['eflags'],b.ZF|b.SF|b.OF)
 def test_setle_requires_each_decisive_flag(self):
  for missing in [b.ZF,b.SF,b.OF]:
   e=self.make(raw='0f9ec0',flagmask=(b.ZF|b.SF|b.OF)^missing);before=e.register_snapshot()
   with self.assertRaisesRegex(b.Blocked,'SETLE condition flags'):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertEqual(e.register_snapshot()['eax'],before['eax'])
 def test_setle_unadmitted_memory_prefix_other_conditions_reject(self):
  for raw in ['0f9e01','660f9ec0','670f9ec0','f00f9ec0','0f94c0']:
   e=self.make(raw=raw)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_setle_real_synthetic_cmp_output_controls_later_branch(self):
  for a,c,want in [(2,3,1),(3,3,1),(4,3,0),(-2,3,1)]:
   e=self.make(raw='39c80f9ec00fb6c0',low=a);e.reg_supply('ecx',c,b.MASK32,'synthetic cmp');e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),want)
class DispatchAndAuditTests(unittest.TestCase):
 def actual_setup_dispatch(self,module):
  events=[]
  class StopAtActualRun(Exception):pass
  def run(*a,**kw):events.append(('run',a,kw));raise StopAtActualRun()
  e=SimpleNamespace(root=lambda *a:events.append(('root',a)),boundary_registers=lambda *a:events.append(('boundary',a)),supply=lambda *a:events.append(('supply',a)),run=run,phase=None)
  with self.assertRaises(StopAtActualRun):module.setup(e,{})
  return events
 def test_actual_setup_dispatch_uses300seconds_after_original_precursors(self):
  events=self.actual_setup_dispatch(l);self.assertEqual(events[:3],[('root',(0x4ed820,'startup pool bounds')),('root',(0x4ed880,'startup pool IDs')),('root',(0x49b640,'startup related reserve'))]);self.assertEqual(events[-1],('run',(0x42c4b6,0x42c5ee),{'budget':3000000,'timeout_us':300000000}));self.assertEqual(len(events),7)
 def test_same_actual_setup_fixture_exposes_old240second_dispatch(self):
  self.assertEqual(self.actual_setup_dispatch(old)[-1],('run',(0x42c4b6,0x42c5ee),{'budget':3000000,'timeout_us':240000000}))
 def test_finite_audit_exact_forms_and_dispatch_coverage(self):
  p=l.HERE/'constructor-capability-audit01.json';self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),'4dcc446986477e5aec4cd8fe810cabe54ec9206892f0dfc3702cf306c70c8f84');a=json.loads(p.read_text());self.assertEqual((a['instructionCount'],a['windowCount'],len(a['operandFormGroups']),len(a['dispatchTables'])),(9332,91,160,19));self.assertEqual([r['pc'] for r in a['unsupportedInstructionForms']],['0x404153','0x422de5']);self.assertTrue(all(r['admitted'] and r['instructionBoundary'] for t in a['dispatchTables'] for r in t['targetAdmission']))
 def test_all_prior_windows_conditions_contexts_and_storage_budgets_retained(self):
  for name in ['TEXTURE_CONTEXTS','ADDITIONAL_TEXTURE_CONTEXTS','TRACE_LIMIT','FINAL_JSON_LIMIT','FINAL_COMPRESSED_LIMIT','OTHER_OUTPUT_ALLOWANCE','SPACE_MARGIN','REQUIRED_FREE','ENTRY','NEXT','FINAL']:self.assertEqual(getattr(l,name),getattr(old,name))
  self.assertEqual(l.ranges(),old.ranges());self.assertEqual(l.entry_conditions('land-clear'),old.entry_conditions('land-clear'))
if __name__=='__main__':unittest.main()
