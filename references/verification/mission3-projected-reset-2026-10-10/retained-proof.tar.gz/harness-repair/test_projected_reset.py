"""Authored synthetic programs only. No original execution."""
import pathlib,struct,unittest
import unicorn
from unicorn import x86_const as x
import projected_reset_candidate as p
b=p.b
CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00

def call(pc,target):return b'\xe8'+struct.pack('<i',target-pc-5)

class ProjectionTests(unittest.TestCase):
    def make(self,*,wrong_context=False,unknown_ecx=False,wrong_base=False,bad_stack=False,consume_flags=False):
        target=CODE+0x40
        body=bytearray(b'\x0f\x31\x56\x57\x8b\xf1')
        if bad_stack:body+=b'\x50'
        first=target+len(body);body+=b'\x0f\x31\x0f\x31'
        if consume_flags:body+=b'\x75\x00'
        body+=b'\xc7\x46\x34'+struct.pack('<I',0x466a6000)
        second=target+len(body);body+=b'\x0f\x31'
        body+=b'\xb8\x00\x40\x00\x00\x5f\x5e\xc3'
        program=call(CODE,target)+b'\xc3'+b'\x90'*(0x40-6)+body
        cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
        for a in [CODE,DATA,0x300000]:cpu.mem_map(a,4096)
        cpu.mem_write(CODE,bytes(program))
        skips=[{'start':target,'stop':target+2,'description':'synthetic forbidden RDTSC','ftol':False,'unknownWord':None},
         {'start':first,'stop':first+4,'description':'synthetic omitted call effects','ftol':True,'unknownWord':DATA+0x104},
         {'start':second,'stop':second+2,'description':'synthetic omitted call effects','ftol':True,'unknownWord':DATA+0x100}]
        e=p.ProjectedReset(cpu,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(program))],
          skips=skips,camera=DATA,caller=CODE+1 if wrong_context else CODE,target=target,return_pc=CODE+5)
        e.reg_supply('esp',STACK,b.MASK32,'synthetic fixture');e.reg_supply('eflags',2,b.DF,'synthetic DF=0')
        e.reg_supply('ecx',DATA+4 if wrong_base else DATA,0 if unknown_ecx else b.MASK32,'synthetic camera')
        e.reg_supply('edx',0x11223344,b.MASK32,'synthetic sentinel to detect accidental RDTSC execution')
        e.supply(STACK-100,b'\x55'*104,'preexisting known reused stack')
        e.supply(STACK,struct.pack('<I',STOP),'synthetic root return')
        e.supply(DATA+0x100,struct.pack('<II',123,456),'previously known camera words')
        return e,target
    def test_exact_projection_skips_unsupported_instructions_and_preserves_frames(self):
        e,_=self.make();e.run(CODE,STOP)
        self.assertEqual(len(e.projections),3);self.assertEqual(len(e.events),1)
        self.assertTrue(e.events[0]['returned']);self.assertEqual(e.frames,[])
        self.assertEqual(e.reg_value('edx'),0x11223344) # authored RDTSC bytes never ran
        self.assertEqual(e.shadow.reg_get('edx'),0)
        self.assertEqual(e.reg_value('eax'),0x4000);self.assertEqual(e.shadow.reg_get('eax'),b.MASK32)
        self.assertEqual(e.reg_value('esp'),STACK+4)
    def test_skipped_words_keep_raw_bytes_but_become_unknown(self):
        e,_=self.make();e.run(CODE,STOP)
        self.assertEqual(bytes(e.cpu.mem_read(DATA+0x100,8)),struct.pack('<II',123,456))
        self.assertIsNone(e.observed(DATA+0x100,4)['value']);self.assertIsNone(e.observed(DATA+0x104,4)['value'])
    def test_entire_omitted_20byte_stack_footprint_invalidated(self):
        e,_=self.make();e.run(CODE,STOP)
        # Root CALL =>S=STACK-4; ESI/EDIpushes =>SP=STACK-12; ftol writesSP-20..SP.
        self.assertEqual(e.shadow.get(STACK-32,20),0)
        self.assertEqual(e.shadow.get(STACK-33,1),255)
        self.assertEqual(e.shadow.get(STACK-4,4),b.MASK32) # real outer return not tainted
        self.assertEqual([v['invalidations'][0]['address'] for v in e.projections[1:]],[hex(STACK-32)]*2)
    def test_fixed_integer_store_still_executes_natively(self):
        e,_=self.make();e.run(CODE,STOP)
        self.assertEqual(e.observed(DATA+0x34,4)['value'],0x466a6000)
    def test_unknown_or_wrong_camera_instance_stops(self):
        for args,reason in [({'unknown_ecx':True},'unbound consumed projection camera base'),({'wrong_base':True},'wrong camera instance')]:
            e,_=self.make(**args)
            with self.assertRaisesRegex(b.Blocked,reason):e.run(CODE,STOP)
            self.assertEqual(e.projections,[])
    def test_wrong_caller_stops(self):
        e,_=self.make(wrong_context=True)
        with self.assertRaisesRegex(b.Blocked,'wrong caller'):e.run(CODE,STOP)
    def test_direct_fragment_entry_without_parent_frame_stops(self):
        e,target=self.make()
        with self.assertRaisesRegex(b.Blocked,'outside its exact reset call context'):e.run(target,STOP)
    def test_changed_stack_depth_stops(self):
        e,_=self.make(bad_stack=True)
        with self.assertRaisesRegex(b.Blocked,'stack/frame mismatch'):e.run(CODE,STOP)
    def test_changed_saved_base_stops(self):
        e,target=self.make();e.cpu.mem_write(target+4,b'\x8b\xf2') # MOV ESI,EDX instead of ECX
        with self.assertRaisesRegex(b.Blocked,'wrong saved camera base'):e.run(CODE,STOP)
    def test_unknown_flags_cannot_drive_branch_after_omission(self):
        e,_=self.make(consume_flags=True)
        with self.assertRaisesRegex(b.Blocked,'unbound consumed branch flags'):e.run(CODE,STOP)
    def test_original_x87_elsewhere_remains_unsupported(self):
        e,_=self.make();e.cpu.mem_write(CODE+5,b'\xd9\xfa')
        with self.assertRaisesRegex(b.Blocked,'unsupported instruction semantics'):e.run(CODE,STOP)
    def claim_fixture(self):
        cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);cpu.mem_map(b.BASE,b.END-b.BASE)
        e=p.ProjectedReset(cpu,[(b.BASE,b.END-b.BASE)],b.RESET_WINDOWS);e.projections=[{}, {}, {}]
        for a,value in [(0x89d178,0x09d78afe),(0x89bc72,0x09d78afe),(0x89d180,0)]:e.supply(a,struct.pack('<I',value),'synthetic selected observation')
        e.supply(0x96eac1,bytes(12),'synthetic counters')
        for offset,value in p.FIXED_CAMERA.items():e.supply(p.CAMERA+offset,struct.pack('<I',value),'synthetic fixed output')
        for a,value in p.WRAPPER.items():e.supply(a,struct.pack('<I',value),'synthetic wrapper output')
        return e
    def test_selected_claims_require_each_byte_known(self):
        e=self.claim_fixture();claims=p.assert_claims(e);self.assertEqual(len(claims),32)
        e.shadow.put(0x96eac2,1,0)
        with self.assertRaisesRegex(b.Blocked,'observable unknown'):p.assert_claims(e)
    def test_correct_concrete_seed_with_unknown_bit_is_not_proof(self):
        e=self.claim_fixture();e.shadow.put(0x89d178,4,0xfffffffe)
        with self.assertRaisesRegex(b.Blocked,'observable unknown'):p.assert_claims(e)
    def test_false_knowledge_of_skipped_word_or_edx_is_rejected(self):
        e=self.claim_fixture();e.shadow.put(p.CAMERA+0x100,4,b.MASK32)
        with self.assertRaisesRegex(b.Blocked,'camera word falsely known'):p.assert_claims(e)
        e=self.claim_fixture();e.shadow.reg_put('edx',b.MASK32)
        with self.assertRaisesRegex(b.Blocked,'EDX result falsely known'):p.assert_claims(e)
    def test_exact_observable_spec_has_32_nonoverlapping_fields(self):
        spec=p.observable_spec();self.assertEqual(len(spec),32)
        covered=set()
        for field in spec:
            start=int(field['address'],16);positions=set(range(start,start+field['bytes']))
            self.assertFalse(covered & positions);covered |= positions
            self.assertEqual(int(field['requiredKnownMask'],16),(1<<(8*field['bytes']))-1)
    def test_approval_binds_exact_observables_before_execution(self):
        manifest={'source':{'observedSourceHead':'synthetic','trackedStatus':''},'inputs':[],
          'omittedFragments':p.SKIPS,'selectedObservables':p.observable_spec()}
        digest=lambda value:b.sha(p.json.dumps(value,sort_keys=True).encode())
        approval={'verdict':'ACCEPT_PROJECTED_RESET_DIAGNOSTIC','parentReleasedRunLane':True,'scope':p.SCOPE,
          'driverSha256':b.sha(pathlib.Path(p.__file__).read_bytes()),'frozenEngineSha256':p.BASE_SHA,
          'sourceBindingSha256':digest(manifest['source']),'inputBindingSha256':digest(manifest['inputs']),
          'projectionBindingSha256':digest(manifest['omittedFragments']),
          'observableBindingSha256':digest(manifest['selectedObservables']),'observedSourceHead':'synthetic'}
        p.validate_approval(approval,manifest)
        manifest['selectedObservables'][0]['requiredKnownMask']='0x0'
        with self.assertRaisesRegex(b.Blocked,'missing/stale'):p.validate_approval(approval,manifest)
    def test_base_engine_hash_is_fixed(self):
        self.assertEqual(b.sha(p.BASE_DRIVER.read_bytes()),p.BASE_SHA)

if __name__=='__main__':unittest.main(verbosity=2)
