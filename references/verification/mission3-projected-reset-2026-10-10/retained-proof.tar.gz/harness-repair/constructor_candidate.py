#!/usr/bin/env python3
"""Reviewed-gate candidate; only prepare and synthetic tests may run before release.

Original mode is deliberately a bounded reset diagnostic, NOT the rejected full
constructor setup. No game/OS returns are fabricated. Unimplemented semantics,
unbound consumed values and every target outside exact .text windows stop.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import platform
import struct
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
GAME = Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game')
EXE = GAME / 'd3dpoptb.exe'
EXPECTED_EXE = '3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
EXPECTED_READER = '74dd55ab6d811f0f0d870c94eb404d2c06915bf96232b6dc39c25f19ceee6da2'
PREPARATION_BASE = 'ce246c5b86fc6a9f22c11f58439511f08deef037'
RESET_WINDOWS = [(0x42bfa0,0x42c12c),(0x4a32d0,0x4a3330),
                 (0x41ce00,0x41ce2f),(0x42cfd0,0x42d03c),(0x475530,0x475548)]
POOL_WINDOWS = [(0x4ed820,0x4ed876),(0x4ed880,0x4ed89a),
                (0x4eef50,0x4eefd0),(0x4ee300,0x4ee466),(0x42b27f,0x42b281)]
STATIC_WINDOWS = RESET_WINDOWS + POOL_WINDOWS + [(0x42b590,0x42b653),(0x42b230,0x42b281),
    (0x484a10,0x484a67),(0x484edc,0x485038),(0x485050,0x485122)]
BASE, END = 0x400000, 0xd4e000
SCRATCH, SCRATCH_END, STACK, STOP = 0x2000000, 0x2400000, 0x23ed000, 0x23ee000
POOL, POOL_END, SEED = 0x8e0428, 0x8e0428 + 2000*179, 0x96eac2
INPUT_NAMES = ['levels/levl2003.dat','levels/levl2003.hdr','levels/constant.dat',
 'objects/objs0-6.dat','objects/pnts0-6.dat','objects/facs0-6.dat',
 'objects/aniob0-6.dat','objects/morph0-6.dat','objects/shapes.dat',
 'data/mwsearch.dat','data/vstart-0.ani','data/vfra-0.ani']
CF, PF, AF, ZF, SF, DF, OF = 1, 4, 16, 64, 128, 1024, 2048
ARITH = CF|PF|AF|ZF|SF|OF
MASK32 = (1 << 32)-1
REGS = ('eax','ebx','ecx','edx','esi','edi','ebp','esp','eip','eflags')
ALIASES = {r:(r,0,32) for r in REGS}
for full,word,lo,hi in [('eax','ax','al','ah'),('ebx','bx','bl','bh'),('ecx','cx','cl','ch'),('edx','dx','dl','dh')]:
    ALIASES.update({word:(full,0,16),lo:(full,0,8),hi:(full,8,8)})
for full,word in [('esi','si'),('edi','di'),('ebp','bp'),('esp','sp')]: ALIASES[word]=(full,0,16)
BRANCH_FLAGS = {'je':ZF,'jne':ZF,'ja':CF|ZF,'jae':CF,'jb':CF,'jbe':CF|ZF,
 'jg':ZF|SF|OF,'jge':SF|OF,'jl':SF|OF,'jle':ZF|SF|OF,'jo':OF,'jno':OF,
 'js':SF,'jns':SF,'jp':PF,'jnp':PF}


def sha(b): return hashlib.sha256(b).hexdigest()
def json_write(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def file_record(path):
    b=path.read_bytes(); return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def source_identity():
    return {'preparationBaseHead':PREPARATION_BASE,
      'observedSourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'trackedStatus':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),
      'driver':file_record(Path(__file__)), 'decompHelper':file_record(ROOT/'scripts/decomp.py'),
      'constantImport':file_record(ROOT/'app/original-constants.json')}

class Blocked(RuntimeError):
    def __init__(self,reason,**details):
        super().__init__(reason);self.reason=reason;self.details=details

class ImageWriter:
    """Host-only descriptor replay. Never creates an emulator or runs instructions."""
    def __init__(self,pe):self.pe=pe;self.writes=[]
    def mem_read(self,a,n):return self.pe.read(a,n)
    def mem_write(self,a,b):self.writes.append((a,bytes(b)))

def constant_writes(pe):
    writer=ImageWriter(pe)
    helper=load_module('constructor_decomp_helper',ROOT/'scripts/decomp.py')
    helper.configure_native_constants(writer,EXE)
    if not writer.writes:raise Blocked('constant.dat produced no descriptor writes')
    return writer.writes

def load_pe():
    p=ROOT/'scripts/check-static-mission18-sky.py'
    if sha(p.read_bytes())!=EXPECTED_READER:raise Blocked('static reader drift')
    return load_module('constructor_pe_reader',p).PE32(EXE)

class Shadow:
    """Known-bit masks only; mapped zero bytes are never campaign provenance."""
    def __init__(self,regions):
        self.regions=[(a,a+n,bytearray(n)) for a,n in regions]
        self.reg={r:0 for r in REGS}
    def at(self,a,n):
        for lo,hi,data in self.regions:
            if lo<=a and a+n<=hi:return data,a-lo
        raise Blocked('address outside declared memory',address=hex(a),size=n)
    def get(self,a,n):
        data,i=self.at(a,n);return int.from_bytes(data[i:i+n],'little')
    def put(self,a,n,mask):
        data,i=self.at(a,n);data[i:i+n]=(mask & ((1<<(n*8))-1)).to_bytes(n,'little')
    def reg_get(self,name):
        if name not in ALIASES:raise Blocked('unsupported register provenance',register=name)
        full,shift,bits=ALIASES[name];return self.reg[full]>>shift & ((1<<bits)-1)
    def reg_put(self,name,mask):
        full,shift,bits=ALIASES[name];field=((1<<bits)-1)<<shift
        self.reg[full]=(self.reg[full]&~field)|((mask<<shift)&field)

class Engine:
    """Small fail-closed x86 subset needed by reset and its integer helpers.

    Pre-write hooks journal attempted bytes only. Shadow state is committed after
    a completed instruction: the next code hook, or a successful exact-stop exit.
    A failed/aborted instruction rolls memory and registers back to pre-instruction
    state. REP commits one observed iteration at a time, never its future writes.
    """
    def __init__(self,cpu,regions,windows,*,iat=None,allocator=0x4ed8a0):
        import capstone,unicorn
        from unicorn import x86_const
        self.cpu,self.cs_module,self.uc,self.x=cpu,capstone,unicorn,x86_const
        self.shadow=Shadow(regions);self.windows=windows;self.iat=iat or {}
        self.decoder=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);self.decoder.detail=True
        self.allocator=allocator;self.pending=None;self.blocker=None
        self.committed=0;self.attempted=0;self.events=[];self.frames=[];self.allocations=[]
        self.phase='setup';self.record=None;self.origin=None;self.supplies=[];self.last=[]
        self.forbidden={0x485122:'texture postpass',0x42b230:'broader loader',0x4ec630:'gameplay turn'}
        self.read_events=[];self.write_events=[]
        self.aborted=[]
        self.memory_sink=None
        cpu.hook_add(unicorn.UC_HOOK_CODE,self._code)
        cpu.hook_add(unicorn.UC_HOOK_MEM_READ,self._read)
        cpu.hook_add(unicorn.UC_HOOK_MEM_WRITE,self._write)
        cpu.hook_add(unicorn.UC_HOOK_MEM_INVALID,self._invalid)
        cpu.hook_add(unicorn.UC_HOOK_INTR,self._interrupt)
    def reg_value(self,name):return self.cpu.reg_read(getattr(self.x,'UC_X86_REG_'+name.upper()))
    def register_snapshot(self):
        return {r:{'value':hex(self.reg_value(r)),'knownMask':hex(self.shadow.reg[r])} for r in REGS}
    def supply(self,a,b,source):
        if not source:raise Blocked('missing supply provenance')
        self.cpu.mem_write(a,b);self.shadow.put(a,len(b),(1<<(8*len(b)))-1)
        self.supplies.append({'address':hex(a),'size':len(b),'sha256':sha(b),'source':source})
    def reg_supply(self,name,value,mask,source):
        if not source:raise Blocked('missing register provenance')
        self.cpu.reg_write(getattr(self.x,'UC_X86_REG_'+name.upper()),value)
        self.shadow.reg_put(name,mask)
        self.supplies.append({'register':name,'value':hex(value),'knownMask':hex(mask),'source':source})
    def require(self,mask,want,what,**detail):
        if mask & want != want:raise Blocked('unbound consumed '+what,knownMask=hex(mask),requiredMask=hex(want),**detail)
    def address(self,op,ins):
        m=op.mem
        if m.segment and ins.reg_name(m.segment) not in ('ds','es','ss'):
            raise Blocked('unsupported segment',segment=ins.reg_name(m.segment))
        a=m.disp
        for reg,scale in [(m.base,1),(m.index,m.scale)]:
            if reg:
                name=ins.reg_name(reg);self.require(self.shadow.reg_get(name),MASK32,'address register',register=name)
                a+=self.reg_value(name)*scale
        return a & MASK32
    def operand(self,op,ins):
        x=self.cs_module.x86;bits=op.size*8;full=(1<<bits)-1
        if op.type==x.X86_OP_IMM:return op.imm&full,full,bits
        if op.type==x.X86_OP_REG:
            name=ins.reg_name(op.reg);return self.reg_value(name)&full,self.shadow.reg_get(name),bits
        if op.type==x.X86_OP_MEM:
            a=self.address(op,ins);self.shadow.at(a,op.size);self.no_import(a,op.size)
            self.pending['reads'].append((a,op.size))
            return int.from_bytes(self.cpu.mem_read(a,op.size),'little'),self.shadow.get(a,op.size),bits
        raise Blocked('unsupported operand',type=op.type)
    def destination(self,op,mask,ins):
        x=self.cs_module.x86
        if op.type==x.X86_OP_REG:self.pending['registers'][ins.reg_name(op.reg)]=mask
        elif op.type==x.X86_OP_MEM:self.pending['writes'].append((self.address(op,ins),op.size,mask))
        else:raise Blocked('unsupported destination')
    def flags(self,mask,affected=ARITH):
        self.pending['flags']=(self.shadow.reg['eflags']&~affected)|(mask&affected)
    def no_import(self,a,n):
        for slot,symbol in self.iat.items():
            if a<slot+4 and slot<a+n:raise Blocked('import access prohibited',slot=hex(slot),symbol=symbol)
    def scalar(self,op,ins):
        v,k,b=self.operand(op,ins);self.require(k,(1<<b)-1,'operand',instruction=ins.mnemonic+' '+ins.op_str);return v
    def _plan(self,ins):
        m=ins.mnemonic;ops=ins.operands;x=self.cs_module.x86;p=self.pending
        if m=='mov':
            _,known,_=self.operand(ops[1],ins);self.destination(ops[0],known,ins)
        elif m in ('movzx','movsx'):
            val,known,bits=self.operand(ops[1],ins);outbits=ops[0].size*8
            upper=((1<<outbits)-1)^((1<<bits)-1)
            if m=='movzx' or known&(1<<(bits-1)):known|=upper
            self.destination(ops[0],known,ins)
        elif m=='lea':
            self.address(ops[1],ins);self.destination(ops[0],(1<<(ops[0].size*8))-1,ins)
        elif m in ('and','or','xor','test'):
            a,ak,bits=self.operand(ops[0],ins);b,bk,_=self.operand(ops[1],ins);full=(1<<bits)-1
            if m in ('and','test'):known=(ak&bk)|(ak&~a)|(bk&~b);result=a&b
            elif m=='or':known=(ak&bk)|(ak&a)|(bk&b);result=a|b
            else:
                same=ops[0].type==ops[1].type==x.X86_OP_REG and ops[0].reg==ops[1].reg
                known=full if same else ak&bk;result=a^b
            known&=full
            if m!='test':self.destination(ops[0],known,ins)
            flag_known=CF|OF
            if known&(1<<(bits-1)):flag_known|=SF
            if known&255==255:flag_known|=PF
            if known==full or result&known:flag_known|=ZF
            self.flags(flag_known)
        elif m in ('add','sub','cmp','inc','dec'):
            for op in ops:self.scalar(op,ins)
            if m!='cmp':self.destination(ops[0],(1<<(ops[0].size*8))-1,ins)
            self.flags(ARITH,ARITH&~CF if m in ('inc','dec') else ARITH)
        elif m in ('push','pop','call','ret'):
            self.require(self.shadow.reg_get('esp'),MASK32,'stack pointer')
            sp=self.reg_value('esp');p['registers']['esp']=MASK32
            if m=='push':
                _,known,bits=self.operand(ops[0],ins)
                if bits!=32:raise Blocked('unsupported non-32-bit push')
                p['writes'].append((sp-4,4,known))
            elif m=='pop':
                if ops[0].type!=x.X86_OP_REG or ops[0].size!=4:raise Blocked('unsupported pop destination')
                p['reads'].append((sp,4));self.destination(ops[0],self.shadow.get(sp,4),ins)
            elif m=='call':
                target=self.scalar(ops[0],ins);self.check_target(target)
                p['writes'].append((sp-4,4,MASK32))
                p['call']={'sequence':len(self.events),'parent':self.frames[-1]['sequence'] if self.frames else None,
                 'phase':self.phase,'originRecord':self.record,'fileOrigin':self.origin,'depth':len(self.frames),
                 'caller':hex(ins.address),'target':hex(target),'return':ins.address+ins.size,'returnSp':sp,
                 'seedBefore':self.observed(SEED,1),'entryRegisters':self.register_snapshot(),'returned':False}
            else:
                p['reads'].append((sp,4));self.require(self.shadow.get(sp,4),MASK32,'return address')
                target=int.from_bytes(self.cpu.mem_read(sp,4),'little')
                if self.frames:
                    frame=self.frames[-1]
                    if target!=frame['return'] or sp+4!=frame['returnSp']:raise Blocked('call return mismatch',target=hex(target),stack=hex(sp))
                    p['return']=frame
                elif target!=self.stop:raise Blocked('unmatched root return',target=hex(target))
                if ops:raise Blocked('unsupported callee-cleanup return')
                if target!=self.stop:self.check_target(target)
        elif m in ('stosb','stosw','stosd','rep stosb','rep stosw','rep stosd'):
            self.require(self.shadow.reg['eflags'],DF,'direction flag')
            self.require(self.shadow.reg_get('edi'),MASK32,'string destination')
            size={'stosb':1,'stosw':2,'stosd':4}[m.split()[-1]]
            if m.startswith('rep '):
                self.require(self.shadow.reg_get('ecx'),MASK32,'repeat count');p['registers']['ecx']=MASK32
                if self.reg_value('ecx')==0:return
            p['writes'].append((self.reg_value('edi'),size,self.shadow.reg_get({1:'al',2:'ax',4:'eax'}[size])))
            p['registers']['edi']=MASK32
        elif m=='jmp':self.check_target(self.scalar(ops[0],ins))
        elif m in BRANCH_FLAGS:
            self.require(self.shadow.reg['eflags'],BRANCH_FLAGS[m],'branch flags',instruction=m)
            self.check_target(self.scalar(ops[0],ins))
        elif m=='nop':pass
        else:raise Blocked('unsupported instruction semantics',instruction=m+' '+ins.op_str,
              note='No x87, SIMD, OS, interrupt or unmodeled instruction is executed.')
    def check_target(self,a):
        if a in self.forbidden:raise Blocked('forbidden original boundary',target=hex(a),boundary=self.forbidden[a])
        if not any(lo<=a<hi for lo,hi in self.windows):raise Blocked('outside exact approved text windows',target=hex(a))
    def _code(self,c,a,n,_):
        try:
            self.commit()
            self.check_target(a)
            if not any(lo<=a and a+n<=hi for lo,hi in self.windows):raise Blocked('instruction crosses approved window')
            ins=next(self.decoder.disasm(bytes(c.mem_read(a,n)),a),None)
            if ins is None or ins.size!=n:raise Blocked('decode-size mismatch')
            self.attempted+=1;self.last=(self.last+[hex(a)])[-40:]
            self.pending={'address':a,'bytes':ins.bytes.hex(),'instruction':ins.mnemonic+' '+ins.op_str,
                'registers':{},'flags':None,'reads':[],'writes':[],'journal':[],
                'oldRegisters':{r:self.reg_value(r) for r in REGS},'call':None,'return':None}
            self._plan(ins)
        except Blocked as error:self.fail(error)
    def _read(self,c,access,a,n,value,_):
        try:
            self.no_import(a,n)
            if not self.pending or not any(lo<=a and a+n<=lo+size for lo,size in self.pending['reads']):
                raise Blocked('unmodeled memory read',address=hex(a),size=n)
            self.memory_event('read',{'pc':hex(self.pending['address']),'address':hex(a),'size':n,'knownMask':hex(self.shadow.get(a,n))})
        except Blocked as error:self.fail(error)
    def _write(self,c,access,a,n,value,_):
        try:
            if any(a<hi and lo<a+n for lo,hi in self.windows):raise Blocked('original code write',address=hex(a),size=n)
            self.no_import(a,n);self.shadow.at(a,n)
            if not self.pending:raise Blocked('write without instruction')
            expected=next(((lo,size,k) for lo,size,k in self.pending['writes'] if lo<=a and a+n<=lo+size),None)
            if expected is None:raise Blocked('unmodeled memory write',address=hex(a),size=n)
            lo,size,known=expected;known=(known>>(8*(a-lo)))&((1<<(8*n))-1)
            # Journal byte-by-byte so a cross-page fault cannot hide already
            # addressable bytes behind a failed whole-span mem_read.
            for offset in range(n):
                try:old=bytes(c.mem_read(a+offset,1))
                except self.uc.UcError:
                    raise Blocked('invalid memory before write',address=hex(a+offset),size=1)
                self.pending['journal'].append((a+offset,1,old,(known>>(offset*8))&255))
        except Blocked as error:self.fail(error)
    def _invalid(self,c,access,a,n,value,_):self.fail(Blocked('invalid memory',access=access,address=hex(a),size=n));return False
    def _interrupt(self,c,n,_):self.fail(Blocked('interrupt prohibited',number=n))
    def fail(self,error):
        if self.blocker is None:
            self.blocker={'reason':error.reason,'phase':self.phase,'record':self.record,
              'pc':hex(self.reg_value('eip')),'details':error.details}
        self.cpu.emu_stop();raise error
    def memory_event(self,kind,event):
        if self.memory_sink:self.memory_sink(kind,event)
        else:(self.read_events if kind=='read' else self.write_events).append(event)
    def commit(self):
        p=self.pending
        if p is None:return
        for a,n,old,k in p['journal']:
            self.shadow.put(a,n,k)
            self.memory_event('write',{'pc':hex(p['address']),'address':hex(a),'size':n,'knownMask':hex(k),'committed':True})
        for r,k in p['registers'].items():self.shadow.reg_put(r,k)
        if p['flags'] is not None:self.shadow.reg['eflags']=p['flags']
        self.shadow.reg['eip']=MASK32
        if p['call']:
            self.events.append(p['call']);self.frames.append(p['call'])
        if p['return']:
            event=self.frames.pop();event.update(returned=True,seedAfter=self.observed(SEED,1),returnRegisters=self.register_snapshot())
            if int(event['target'],16)==self.allocator:
                event['allocation']=(self.object_snapshot(self.reg_value('eax')) if self.shadow.reg_get('eax')==MASK32
                    else {'pointer':None,'status':'unbound-allocator-return','knownMask':hex(self.shadow.reg_get('eax'))})
                self.allocations.append(event)
        self.pending=None;self.committed+=1
    def rollback(self):
        p=self.pending
        if p:
            self.aborted.append({'pc':hex(p['address']),'instruction':p['instruction'],
                'bytes':p['bytes'],'status':'not-committed',
                'attemptedWrites':[{'address':hex(a),'size':n,'oldBytes':old.hex(),
                    'proposedKnownMask':hex(k)} for a,n,old,k in p['journal']]})
            for a,n,old,k in reversed(p['journal']):self.cpu.mem_write(a,old)
            for r,v in p['oldRegisters'].items():self.cpu.reg_write(getattr(self.x,'UC_X86_REG_'+r.upper()),v)
            self.pending=None
    def run(self,start,stop,budget=2_000_000,timeout_us=15_000_000):
        self.stop=stop
        try:
            self.cpu.emu_start(start,stop,count=budget,timeout=timeout_us)
            if self.reg_value('eip')!=stop:raise Blocked('instruction/time bound before exact stop',eip=hex(self.reg_value('eip')))
            self.commit()
            if self.frames:raise Blocked('unfinished call frames at boundary',count=len(self.frames))
        except BaseException as error:
            if self.blocker is None:self.blocker={'reason':str(error),'phase':self.phase,'pc':hex(self.reg_value('eip'))}
            self.rollback()
            if isinstance(error,self.uc.UcError):raise Blocked(self.blocker['reason'],**self.blocker.get('details',{})) from error
            raise
    def observed(self,a,n):
        try:
            known=self.shadow.get(a,n);full=(1<<(8*n))-1
            return {'address':hex(a),'value':int.from_bytes(self.cpu.mem_read(a,n),'little') if known==full else None,'knownMask':hex(known)}
        except Blocked:return {'address':hex(a),'value':None,'knownMask':None}
    def object_snapshot(self,p):
        if not POOL+179<=p<POOL_END or (p-POOL)%179:return {'pointer':hex(p),'validPoolSlot':False}
        return {'pointer':hex(p),'validPoolSlot':True,'rawHex':bytes(self.cpu.mem_read(p,179)).hex(),
          'knownBitsHex':self.shadow.get(p,179).to_bytes(179,'little').hex(),
          'id':self.observed(p+0x24,2),'class':self.observed(p+0x2a,1),'model':self.observed(p+0x2b,1),
          'prev':self.observed(p,4),'next':self.observed(p+4,4),
          'state':self.observed(p+0x2c,1),'counter':self.observed(p+0x2e,1),'ownerRaw':self.observed(p+0x2f,1)}
    def chain(self,head):
        value=self.observed(head,4)
        if value['value'] is None:return {'status':'unbound-head','head':value,'order':[]}
        p=value['value'];seen=set();order=[]
        while p:
            if p in seen or not POOL+179<=p<POOL_END or (p-POOL)%179:
                return {'status':'invalid-node','head':value,'order':order,'next':hex(p)}
            seen.add(p);order.append(self.object_snapshot(p));link=self.observed(p+4,4)
            if link['value'] is None:return {'status':'unbound-link','head':value,'order':order,'link':link}
            p=link['value']
        return {'status':'complete','head':value,'order':order}
    def snapshot(self):
        return {'class1Seed':self.observed(SEED,1),'registers':self.register_snapshot(),
          'primary':self.chain(0x890324),'secondary':self.chain(0x890330)}


def prepare(out,selected_mode='prepare'):
    import capstone
    pe=load_pe();level=(GAME/INPUT_NAMES[0]).read_bytes();header=(GAME/INPUT_NAMES[1]).read_bytes()
    if sha(level)!='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf':raise Blocked('level input drift')
    if sha(header)!='219dd7611a4e3f6c2d4e78620a4d5bb9cf61bf0e9c66c21b2b43b89c8ba4d3f0':raise Blocked('header input drift')
    records=[{'number':i+1,'fileOffset':0x14043+i*55,'rawHex':level[0x14043+i*55:0x14043+(i+1)*55].hex()} for i in range(2000)]
    if any(len(r['rawHex'])!=110 for r in records):raise Blocked('record length mismatch')
    cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[]
    text=next(s for s in pe.sections if s['name']=='.text');text_end=text['va']+text['virtualSize']
    for lo,hi in STATIC_WINDOWS:
        if not text['va']<=lo<hi<=text_end:raise Blocked('non-.text static window')
        raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo))
        if sum(i.size for i in ins)!=len(raw):raise Blocked('split window',start=hex(lo))
        windows.append({'start':hex(lo),'stopExclusive':hex(hi),'sha256':sha(raw),'instructions':[
          {'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
    constants=constant_writes(pe)
    manifest={'status':'PREPARED_NOT_EXECUTED','originalInstructionsExecuted':0,
      'source':source_identity(),'inputs':[file_record(GAME/p) for p in INPUT_NAMES],
      'executable':file_record(EXE),'scope':'static-preparation-of-separately-gated-diagnostics',
      'selectedMode':selected_mode,
      'diagnosticScopes':{'run-diagnostic':'reset-diagnostic-no-constructor-ledger',
        'run-pool-diagnostic':'pool-terrain-independence-no-constructor-ledger'},
      'conditionalRegisterSupplies':{'both':{'esp':'cdecl scratch stack/return fixture','eflags':'Only DF=0 known; other flags unknown'},
        'run-pool-diagnostic':{'eax':'0 from0042b25d','ecx':'65536 from0042b25f',
          'edi':'008a03e4 from0042b24b across00477780 push/popEDI0047778c/0047787a and004eef50→004ee300 push/popEDI004ee303/004ee463; explicitly conditioned boundary, not a campaign snapshot'}},
      'runReady':'REQUIRES_FRESH_REVIEW_AND_PARENT_RELEASE','ledgerAdmission':'REJECTED_SETUP_UNPROVED',
      'textSection':text,'resetAllowedWindows':[[hex(a),hex(b)] for a,b in RESET_WINDOWS],
      'poolAllowedWindows':[[hex(a),hex(b)] for a,b in POOL_WINDOWS],
      'windows':windows,'constantWrites':[{'address':hex(a),'bytesHex':b.hex()} for a,b in constants],
      'records':{'slots':2000,'nonempty':sum(bytes.fromhex(r['rawHex'])[1]!=0 for r in records),
                 'directClass1':sum(bytes.fromhex(r['rawHex'])[1]==1 for r in records)},
      'expectedStops':{'run-diagnostic':{'pc':'0x42cfd0','reason':'unsupported x87 instruction and unproved entry x87 state','originalNotRun':True},
        'run-pool-diagnostic':{'pc':'0x42b281','reason':'exact boundary after full terrain zero; requires validated639/1200/160 free lists and full0x40000-byte zero coverage','originalNotRun':True}},
      'limits':['Mapped writable PE raw bytes and zero-fill remain unknown.',
       'Both modes supply fixture ESP/return/DF and descriptor balance writes. Pool mode additionally conditions EAX/ECX/EDI at the genuine terrain REP on retained caller producers/preservation.',
       'No CSEG, whole .text allowance, imports, OS calls, stubs, clock replacement or gameplay.',
       'Reset diagnostic is not a Mission3 entry capture, allocation ledger or parity evidence.',
       'Full constructor setup remains rejected; see setup-audit.json.']}
    json_write(out/'preflight.json',manifest);json_write(out/'raw-records.json',records)
    return pe,manifest


def validate_approval(approval,manifest,mode='run-diagnostic'):
    scope=('pool-terrain-independence-no-constructor-ledger' if mode=='run-pool-diagnostic' else 'reset-diagnostic-no-constructor-ledger')
    expected={'verdict':('ACCEPT_POOL_DIAGNOSTIC' if mode=='run-pool-diagnostic' else 'ACCEPT_RESET_DIAGNOSTIC'),'parentReleasedRunLane':True,
      'scope':scope,'driverSha256':sha(Path(__file__).read_bytes()),
      'observedSourceHead':manifest['source']['observedSourceHead'],
      'sourceBindingSha256':sha(json.dumps(manifest['source'],sort_keys=True).encode()),
      'inputBindingSha256':sha(json.dumps(manifest['inputs'],sort_keys=True).encode())}
    for key,value in expected.items():
        if approval.get(key)!=value:raise Blocked('missing/stale explicit review or parent release',field=key)
    if manifest['source']['trackedStatus']:raise Blocked('tracked source drift')


def validate_pool(engine):
    groups=[('low',0x890320,1,640),('high',0x89031c,640,1840),('secondary',0x89032c,1840,2000)]
    result={}
    for name,head,lo,hi in groups:
        chain=engine.chain(head);wanted=list(range(hi-1,lo-1,-1))
        if chain['status']!='complete' or [o['id']['value'] for o in chain['order']]!=wanted:
            raise Blocked('pool order differs from source-bound expected indices',list=name)
        for pos,obj in enumerate(chain['order']):
            wanted_prev=0 if pos==0 else POOL+(wanted[pos-1])*179
            wanted_next=0 if pos==len(wanted)-1 else POOL+wanted[pos+1]*179
            if obj['prev']['value']!=wanted_prev or obj['next']['value']!=wanted_next or obj['class']['value']!=0:
                raise Blocked('pool link/class proof incomplete',list=name,index=wanted[pos])
        result[name]={'head':hex(head),'count':len(wanted),'indexOrder':wanted}
    for index in range(1,2000):
        address=POOL+index*179+0xc
        if not engine.shadow.get(address,4)&1 or int.from_bytes(engine.cpu.mem_read(address,4),'little')&1:
            raise Blocked('pool flags2 mask01 not proven clear',index=index)
    for address in [0x890324,0x890328,0x890330,0x89c651,0x89c659,0x89c655,0x89c65d]:
        if engine.observed(address,4)['value']!=0:raise Blocked('pool reset counter/head not proven zero',address=hex(address))
    return result


def run_original(pe,manifest,approval,out,mode='run-diagnostic'):
    # The approval is validated BEFORE constructing a native CPU.
    validate_approval(approval,manifest,mode)
    import unicorn
    helper=load_module('constructor_decomp_native',ROOT/'scripts/decomp.py')
    cpu,identity=helper.native_cpu(EXE);cpu.mem_map(SCRATCH,SCRATCH_END-SCRATCH)
    windows=POOL_WINDOWS if mode=='run-pool-diagnostic' else RESET_WINDOWS
    engine=Engine(cpu,[(BASE,END-BASE),(SCRATCH,SCRATCH_END-SCRATCH)],windows,iat=pe.imports)
    memory_log=(out/'memory-events.jsonl').open('wb');memory_hash=hashlib.sha256();memory_counts={'read':0,'write':0}
    def memory_sink(kind,event):
        raw=(json.dumps({'kind':kind,'phase':engine.phase,**event},separators=(',',':'))+'\n').encode()
        memory_log.write(raw);memory_hash.update(raw);memory_counts[kind]+=1
    engine.memory_sink=memory_sink
    text=manifest['textSection'];cpu.mem_protect(text['va'],(text['virtualSize']+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC)
    # Sections other than .text are never executable, even if marked CSEG in PE.
    for s in pe.sections:
        if s['name']!='.text':cpu.mem_protect(s['va'],(max(s['virtualSize'],s['rawSize'])+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    cpu.mem_protect(SCRATCH,SCRATCH_END-SCRATCH,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    for a,b in constant_writes(pe):engine.supply(a,b,'configure_native_constants: verified constant.dat + native descriptor; conditional startup balance projection')
    engine.reg_supply('esp',STACK,MASK32,'cdecl fixture stack address; not campaign register capture')
    engine.reg_supply('eflags',2,DF,'cdecl DF=0 contract only; arithmetic flags unknown')
    engine.supply(STACK,struct.pack('<I',STOP),'cdecl fixture return sentinel, never an original API/game return')
    engine.phase='pool setup' if mode=='run-pool-diagnostic' else 'full original clear-level reset'
    before=engine.snapshot();error=None;stages=[]
    try:
        if mode=='run-pool-diagnostic':
            for label,address in [('original pool bounds',0x4ed820),('original pool IDs',0x4ed880),('original reset/list rebuild',0x4eef50)]:
                engine.phase=label;engine.reg_supply('esp',STACK,MASK32,'fresh cdecl diagnostic frame')
                engine.supply(STACK,struct.pack('<I',STOP),'diagnostic return sentinel')
                engine.run(address,STOP,timeout_us=180_000_000);stages.append({'name':label,'status':'passed','snapshot':engine.snapshot()})
            pool_proof=validate_pool(engine)
            engine.phase='source-ordered full terrain zero'
            engine.reg_supply('eax',0,MASK32,'0042b25d xor eax,eax')
            engine.reg_supply('ecx',0x10000,MASK32,'0042b25f mov ecx,0x10000')
            engine.reg_supply('edi',0x8a03e4,MASK32,'Conditioned caller boundary:0042b24b across00477780 push/popEDI0047778c/0047787a and004eef50→004ee300 push/popEDI004ee303/004ee463')
            engine.run(0x42b27f,0x42b281,timeout_us=180_000_000)
            if engine.shadow.get(0x8a03e4,0x40000)!=(1<<(8*0x40000))-1 or bytes(cpu.mem_read(0x8a03e4,0x40000))!=bytes(0x40000):
                raise Blocked('full terrain zero coverage not proven')
            stages.append({'name':engine.phase,'status':'passed','terrainAllKnown':engine.shadow.get(0x8a03e4,0x40000)==(1<<(8*0x40000))-1,
              'terrainAllZero':bytes(cpu.mem_read(0x8a03e4,0x40000))==bytes(0x40000)})
            status='POOL_DIAGNOSTIC_REACHED_STOP'
        else:
            engine.run(0x42bfa0,STOP);status='RESET_DIAGNOSTIC_REACHED_RETURN'
    except BaseException as e:
        status='BLOCKED_POOL_DIAGNOSTIC' if mode=='run-pool-diagnostic' else 'BLOCKED_RESET_DIAGNOSTIC'
        error={'type':type(e).__name__,'message':str(e)}
    memory_log.close()
    result={'status':status,'claimStatus':'NO_CONSTRUCTOR_LEDGER_OR_CAMPAIGN_ENTRY_CLAIM','identity':identity,
      'tools':{'python':sys.version,'unicorn':unicorn.__version__,'capstone':engine.cs_module.__version__,'platform':platform.platform()},
      'attemptedInstructions':engine.attempted,'committedInstructions':engine.committed,
      'mode':mode,'stages':stages,
      'blocker':engine.blocker,'error':error,'before':before,'after':engine.snapshot(),
      'calls':engine.events,'openCalls':engine.frames,'allocations':engine.allocations,
      'suppliedInputs':engine.supplies,'reads':engine.read_events,'writes':engine.write_events,'last':engine.last,
      'abortedInstructions':engine.aborted,
      'memoryEvents':{'file':'memory-events.jsonl','sha256':memory_hash.hexdigest(),'counts':memory_counts},
      'substitutions':[],'fabricatedReturns':[],'recordsVisited':0,
      'stagesNotRun':(['complete campaign setup','bank6 setup','terrain heights/walk masks','2000-slot constructor','postpass']
         if mode=='run-pool-diagnostic' else ['pool initialization','bank6 setup','terrain setup','2000-slot constructor','postpass'])}
    if mode=='run-pool-diagnostic':
        result['freeLists']={name:engine.chain(address) for name,address in [('low',0x890320),('high',0x89031c),('secondary',0x89032c)]}
        result['poolProof']=pool_proof if error is None else None
    json_write(out/'result.json',result)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['prepare','run-diagnostic','run-pool-diagnostic','run-ledger'])
    p.add_argument('--out',type=Path,required=True);p.add_argument('--approval',type=Path);a=p.parse_args()
    if a.out.exists():raise Blocked('output must be new; receipts never overwritten')
    a.out.mkdir(parents=True);pe,manifest=prepare(a.out,a.mode)
    if a.mode=='prepare':print(json.dumps({'status':manifest['status'],'originalInstructionsExecuted':0,'constantWrites':len(manifest['constantWrites'])}));return
    if a.mode=='run-ledger':raise Blocked('constructor ledger rejected: source-ordered setup and entry dependencies unproved; no original instructions executed')
    if not a.approval:raise Blocked('fresh independent review and parent release required; no native CPU constructed')
    result=run_original(pe,manifest,json.loads(a.approval.read_text()),a.out,a.mode)
    print(json.dumps({'status':result['status'],'blocker':result['blocker']}))
    if result['status'].startswith('BLOCKED'):raise SystemExit(2)
if __name__=='__main__':main()
