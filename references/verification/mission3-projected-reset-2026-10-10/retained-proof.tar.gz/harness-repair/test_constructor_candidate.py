#!/usr/bin/env python3
"""Only hand-authored synthetic x86 programs. Never reads or executes original code."""
import hashlib
import json
import pathlib
import struct
import sys
import unittest
import unicorn
from unicorn import x86_const as x
import constructor_candidate as m

CODE, DATA, STACK, STOP = 0x100000,0x200000,0x300800,0x300f00

def relcall(pc,target):return b'\xe8'+struct.pack('<i',target-(pc+5))
def mov32(address,value):return b'\xc7\x05'+struct.pack('<II',address,value)

class SyntheticCase(unittest.TestCase):
    def make(self,program,extra=None,*,iat=None,allocator=0x4ed8a0,code_size=None):
        cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
        for a in [CODE,DATA,0x300000]:cpu.mem_map(a,4096)
        cpu.mem_write(CODE,program)
        regions=[(CODE,4096),(DATA,4096),(0x300000,4096)]
        if extra:
            for a,n in extra:cpu.mem_map(a,n);regions.append((a,n))
        e=m.Engine(cpu,regions,[(CODE,CODE+(code_size or len(program)))],iat=iat,allocator=allocator)
        e.reg_supply('esp',STACK,m.MASK32,'synthetic fixture')
        e.reg_supply('eflags',2,m.DF,'synthetic DF=0 only')
        e.supply(STACK,struct.pack('<I',STOP),'synthetic return sentinel')
        return e
    def blocked(self,e,word,start=CODE):
        with self.assertRaises(m.Blocked) as err:e.run(start,STOP)
        self.assertIn(word,str(err.exception));return err.exception
    def test_mov_immediate_commits_at_exact_stop(self):
        e=self.make(mov32(DATA,123)+b'\xc3');e.run(CODE,STOP)
        self.assertEqual(e.observed(DATA,4)['value'],123)
        self.assertEqual(e.committed,2)
    def test_unknown_register_save_restore_does_not_become_known(self):
        e=self.make(b'\x53\xbb\x01\x00\x00\x00\x5b\xc3')
        e.cpu.reg_write(x.UC_X86_REG_EBX,0xdeadbeef);e.run(CODE,STOP)
        self.assertEqual(e.reg_value('ebx'),0xdeadbeef)
        self.assertEqual(e.shadow.reg_get('ebx'),0)
        self.assertEqual(e.shadow.get(STACK-4,4),0)
    def test_unknown_value_copy_is_allowed_but_not_consumption(self):
        e=self.make(b'\xa1'+struct.pack('<I',DATA)+b'\x83\xc0\x01\xc3')
        self.blocked(e,'unbound consumed operand')
        self.assertEqual(e.shadow.reg_get('eax'),0)
        self.assertEqual(e.committed,1)
    def test_partial_register_write_preserves_unknown_upper(self):
        e=self.make(b'\xb0\x12\xc3');e.run(CODE,STOP)
        self.assertEqual(e.shadow.reg_get('eax'),255)
    def test_xor_self_binds_all_bits_and_flags(self):
        e=self.make(b'\x31\xc0\x74\x01\x90\xc3');e.run(CODE,STOP)
        self.assertEqual(e.shadow.reg_get('eax'),m.MASK32)
        self.assertEqual(e.shadow.reg['eflags']&m.ZF,m.ZF)
    def test_masked_unknown_word_has_decisive_known_bit(self):
        # AND memory clears bit3. TEST that bit is decisively false even though other bits unknown.
        program=b'\x83\x25'+struct.pack('<I',DATA)+b'\xf7'+b'\xf6\x05'+struct.pack('<I',DATA)+b'\x08'+b'\x74\x01\x90\xc3'
        e=self.make(program);e.run(CODE,STOP)
        self.assertEqual(e.shadow.get(DATA,4),8)
        self.assertEqual(e.shadow.reg['eflags']&m.ZF,m.ZF)
    def test_or_unknown_word_has_decisive_set_bit(self):
        program=b'\x83\x0d'+struct.pack('<I',DATA)+b'\x08'+b'\xf6\x05'+struct.pack('<I',DATA)+b'\x08'+b'\x75\x01\x90\xc3'
        e=self.make(program);e.run(CODE,STOP)
        self.assertEqual(e.shadow.get(DATA,4),8)
    def test_unknown_branch_stops_before_branch(self):
        e=self.make(b'\xf6\x05'+struct.pack('<I',DATA)+b'\x08\x74\x01\x90\xc3')
        self.blocked(e,'unbound consumed branch flags');self.assertEqual(e.committed,1)
    def test_unknown_address_stops_before_read(self):
        e=self.make(b'\x8b\x03\xc3');e.cpu.reg_write(x.UC_X86_REG_EBX,DATA)
        self.blocked(e,'unbound consumed address register');self.assertEqual(e.committed,0)
    def test_failed_cross_page_write_rolls_back_bytes_and_mask(self):
        e=self.make(mov32(DATA+4094,0x12345678)+b'\xc3')
        # Declare guard region so unmodeled-region rejection does not hide emulator failure.
        e.shadow.regions[1]=(DATA,DATA+8192,bytearray(8192))
        e.cpu.mem_write(DATA+4094,b'\x55\xaa')
        self.blocked(e,'invalid memory')
        self.assertEqual(bytes(e.cpu.mem_read(DATA+4094,2)),b'\x55\xaa')
        self.assertEqual(e.shadow.get(DATA+4094,4),0)
        self.assertEqual(e.committed,0)
    def test_error_preserves_prior_committed_write(self):
        e=self.make(mov32(DATA,11)+b'\x0f\x31\xc3')
        self.blocked(e,'unsupported instruction semantics')
        self.assertEqual(e.observed(DATA,4)['value'],11)
        self.assertEqual(e.committed,1)
    def test_import_read_stops_even_through_plain_mov(self):
        e=self.make(b'\xa1'+struct.pack('<I',DATA)+b'\xc3',iat={DATA:'winmm!timeGetTime'})
        e.supply(DATA,b'\x00'*4,'synthetic IAT')
        self.blocked(e,'import access prohibited');self.assertEqual(e.committed,0)
    def test_code_write_stops(self):
        e=self.make(mov32(CODE,0)+b'\xc3');self.blocked(e,'original code write')
        self.assertEqual(e.committed,0)
    def test_outside_window_jump_stops_before_transfer(self):
        e=self.make(b'\xe9'+struct.pack('<i',DATA-(CODE+5))+b'\xc3')
        self.blocked(e,'outside exact approved text windows')
    def test_unsupported_x87_stops_before_execution(self):
        e=self.make(b'\xd9\xfa\xc3');self.blocked(e,'unsupported instruction semantics')
        self.assertEqual(e.committed,0)
    def test_rep_stos_commits_each_iteration(self):
        e=self.make(b'\xf3\xab\xc3')
        e.reg_supply('edi',DATA,m.MASK32,'synthetic pointer');e.reg_supply('ecx',3,m.MASK32,'synthetic count')
        e.reg_supply('eax',0x99,m.MASK32,'synthetic value');e.run(CODE,STOP)
        self.assertEqual(bytes(e.cpu.mem_read(DATA,12)),struct.pack('<III',0x99,0x99,0x99))
        self.assertEqual(e.shadow.get(DATA,12),(1<<96)-1)
        self.assertEqual(sum(w['size'] for w in e.write_events),12)
        self.assertEqual([int(w['address'],16) for w in e.write_events],list(range(DATA,DATA+12)))
        self.assertTrue(all(w['committed'] for w in e.write_events))
    def test_rep_unknown_df_is_rejected(self):
        e=self.make(b'\xf3\xab\xc3');e.shadow.reg['eflags']=0
        self.blocked(e,'unbound consumed direction flag')
    def test_budget_abort_rolls_back_last_uncommitted_instruction(self):
        e=self.make(mov32(DATA,17)+b'\xeb\xfe')
        with self.assertRaises(m.Blocked):e.run(CODE,STOP,budget=1)
        self.assertEqual(e.shadow.get(DATA,4),0)
        self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),b'\x00'*4)
    def test_nested_call_return_logging_and_allocator(self):
        # Root calls allocator at+16; allocator calls helper at+32 and returns zero.
        program=relcall(CODE,CODE+16)+b'\xc3'+b'\x90'*10
        program+=relcall(CODE+16,CODE+32)+b'\x31\xc0\xc3'+b'\x90'*8+b'\xc3'
        e=self.make(program,allocator=CODE+16)
        e.record=7;e.origin={'file':'synthetic','offset':123};e.run(CODE,STOP)
        self.assertEqual(len(e.events),2);self.assertEqual(len(e.allocations),1)
        self.assertEqual([v['depth'] for v in e.events],[0,1])
        self.assertEqual([v['returned'] for v in e.events],[True,True])
        self.assertEqual(e.events[1]['parent'],0)
        self.assertEqual(e.allocations[0]['fileOrigin']['offset'],123)
        self.assertEqual(e.frames,[])
    def test_failed_call_is_not_logged_as_committed(self):
        e=self.make(relcall(CODE,CODE+5)+b'\xc3')
        e.reg_supply('esp',0x300000,m.MASK32,'unwritable stack')
        self.blocked(e,'outside declared memory');self.assertEqual(e.events,[])
    def test_unknown_snapshot_fields_are_null_not_fabricated(self):
        e=self.make(b'\xc3',extra=[(0x890000,0x1000),(0x8e0000,0x1000)])
        e.supply(0x890324,struct.pack('<I',m.POOL+179),'synthetic primary head')
        e.supply(m.POOL+179+4,b'\x00'*4,'synthetic link')
        snap=e.chain(0x890324)
        self.assertEqual(snap['status'],'complete')
        self.assertIsNone(snap['order'][0]['class']['value'])
        self.assertEqual(snap['order'][0]['class']['knownMask'],'0x0')
    def test_cycle_and_misaligned_pool_pointer_detected(self):
        e=self.make(b'\xc3',extra=[(0x890000,0x1000),(0x8e0000,0x1000)])
        e.supply(0x890324,struct.pack('<I',m.POOL+179),'synthetic head')
        e.supply(m.POOL+179+4,struct.pack('<I',m.POOL+179),'synthetic cycle')
        self.assertEqual(e.chain(0x890324)['status'],'invalid-node')
        e.supply(0x890324,struct.pack('<I',m.POOL+1),'synthetic misalignment')
        self.assertEqual(e.chain(0x890324)['status'],'invalid-node')
    def test_no_blanket_zero_fill_provenance(self):
        e=self.make(b'\xc3');self.assertEqual(e.shadow.get(DATA,4096),0)
    def test_source_bound_pool_expectations_and_reserved_slot(self):
        e=self.make(b'\xc3',extra=[(0x890000,0x10000),(0x8e0000,0x60000)])
        for head,lo,hi in [(0x890320,1,640),(0x89031c,640,1840),(0x89032c,1840,2000)]:
            e.supply(head,struct.pack('<I',m.POOL+(hi-1)*179),'synthetic mathematical projection')
            for index in range(lo,hi):
                p=m.POOL+index*179
                e.supply(p,struct.pack('<II',0 if index==hi-1 else p+179,0 if index==lo else p-179),'synthetic links')
                e.supply(p+0x24,struct.pack('<H',index),'synthetic ID')
                e.supply(p+0x2a,b'\0','synthetic cleared class')
                # Only bit0 is known, exactly the reset predicate, never blanket zero provenance.
                e.shadow.put(p+0xc,4,1)
        for a in [0x890324,0x890328,0x890330,0x89c651,0x89c659,0x89c655,0x89c65d]:
            e.supply(a,b'\0'*4,'synthetic zero counter/head')
        proof=m.validate_pool(e)
        self.assertEqual([proof[k]['count'] for k in ['low','high','secondary']],[639,1200,160])
        self.assertEqual(e.shadow.get(m.POOL,179),0)
        self.assertFalse(e.object_snapshot(m.POOL)['validPoolSlot'])
        e.shadow.put(m.POOL+179+0xc,4,0)
        with self.assertRaisesRegex(m.Blocked,'flags2 mask01'):m.validate_pool(e)
    def test_approval_required_and_hash_bound(self):
        manifest={'source':{'observedSourceHead':'x','trackedStatus':''},'inputs':[]}
        with self.assertRaises(m.Blocked):m.validate_approval({},manifest)
        approval={'verdict':'ACCEPT_RESET_DIAGNOSTIC','parentReleasedRunLane':True,'scope':'reset-diagnostic-no-constructor-ledger',
          'driverSha256':m.sha(pathlib.Path(m.__file__).read_bytes()),'observedSourceHead':'x',
          'sourceBindingSha256':m.sha(json.dumps(manifest['source'],sort_keys=True).encode()),
          'inputBindingSha256':m.sha(json.dumps([],sort_keys=True).encode())}
        m.validate_approval(approval,manifest)
        approval['driverSha256']='stale'
        with self.assertRaises(m.Blocked):m.validate_approval(approval,manifest)

if __name__=='__main__':unittest.main(verbosity=2)
