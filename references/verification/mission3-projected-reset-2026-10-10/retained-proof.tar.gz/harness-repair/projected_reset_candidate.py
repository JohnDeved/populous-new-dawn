#!/usr/bin/env python3
"""Explicit conditional reset projection. No execution until new review/release.

Only the single 0042c080 -> 0041ce00 -> 0042cfd0 camera-reset context may omit
three exact floating-point fragments. Their outputs, CPU live-outs and transient
stack writes remain unknown. This conditions on normal return/no-fault of the
omitted fragments and never proves original x87 exception behavior.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import struct
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
BASE_DRIVER=HERE/'constructor_candidate.py'
BASE_SHA='2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f'
if hashlib.sha256(BASE_DRIVER.read_bytes()).hexdigest()!=BASE_SHA:raise RuntimeError('Frozen guarded-engine drift')
spec=importlib.util.spec_from_file_location('frozen_constructor_engine',BASE_DRIVER)
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
SCOPE='conditional-projected-reset-rng-and-class-counters'
CAMERA=0x5fe2f0
SKIPS=[{'start':0x42cfd0,'stop':0x42cfd8,'description':'FLD first fixed operand and FSQRT','ftol':False,'unknownWord':None},
 {'start':0x42cfe7,'stop':0x42cffa,'description':'first __ftol, second FLD/FSQRT and store camera+104','ftol':True,'unknownWord':CAMERA+0x104},
 {'start':0x42d001,'stop':0x42d012,'description':'FDIVR, second __ftol and store camera+100','ftol':True,'unknownWord':CAMERA+0x100}]
FIXED_CAMERA={0:0,0x18:0x4000,0x1c:0x4000,0x2c:8,0x30:0x44bb8000,0x34:0x466a6000,0x4c:0,0x50:0,0x54:0,0xdc:0,0x108:0}
WRAPPER={0x5fe418:0,0x5fe41c:0,0x5fe420:0,0x5fe428:6,0x5fe430:0,0x5fe434:0}

def observable_spec():
    fields=[('rng_game',0x89d178,4,0x09d78afe),('rng_secondary',0x89bc72,4,0x09d78afe),('units_allocated',0x89d180,4,0)]
    fields += [('class_counter_'+str(i),0x96eac1+i,1,0) for i in range(12)]
    fields += [('camera_fixed_'+hex(offset),CAMERA+offset,4,value) for offset,value in FIXED_CAMERA.items()]
    fields += [('camera_wrapper_'+hex(a),a,4,value) for a,value in WRAPPER.items()]
    return [{'name':name,'address':hex(a),'bytes':n,'expectedValue':value,'requiredKnownMask':hex((1<<(8*n))-1)} for name,a,n,value in fields]

class ProjectedReset(b.Engine):
    def __init__(self,*args,skips=None,camera=CAMERA,caller=0x42c080,target=0x41ce00,return_pc=0x42c085,**kwargs):
        super().__init__(*args,**kwargs)
        self.skips=SKIPS if skips is None else skips;self.camera=camera
        self.projection_caller=caller;self.projection_target=target;self.projection_return=return_pc
        self.projections=[];self.x87_state='unknown and unsupported'
    def _code(self,c,a,n,unused):
        entry=next((s for s in self.skips if s['start']==a),None)
        if entry is None:return super()._code(c,a,n,unused)
        try:
            self.commit();self.check_target(a);self.check_target(entry['stop'])
            index=self.skips.index(entry)
            if index!=len(self.projections):raise b.Blocked('projection fragment repeated/out of order',index=index)
            if not self.frames:raise b.Blocked('projection outside its exact reset call context')
            frame=self.frames[-1]
            if (int(frame['caller'],16),int(frame['target'],16),frame['return'])!=(self.projection_caller,self.projection_target,self.projection_return):
                raise b.Blocked('projection wrong caller/target/return context')
            self.require(self.shadow.reg_get('ecx'),b.MASK32,'projection camera base')
            if self.reg_value('ecx')!=self.camera:raise b.Blocked('projection wrong camera instance')
            self.require(self.shadow.reg_get('esp'),b.MASK32,'projection stack')
            expected_sp=frame['returnSp']-(4 if index==0 else 12)
            if self.reg_value('esp')!=expected_sp:raise b.Blocked('projection stack/frame mismatch',expected=hex(expected_sp))
            if index:
                self.require(self.shadow.reg_get('esi'),b.MASK32,'projection saved camera base')
                if self.reg_value('esi')!=self.camera:raise b.Blocked('projection wrong saved camera base')
            before=self.register_snapshot();invalidations=[]
            if entry['ftol']:
                # Original CALL pushes4; PUSH EBP adds4; ADD ESP,-12 allocates12.
                # CWlocals and FISTPqword are within this exact20-byte interval.
                stack=self.reg_value('esp')-20;self.shadow.put(stack,20,0)
                invalidations.append({'address':hex(stack),'size':20,'why':'omitted __ftol returnslot,savedEBP,CWlocals,FISTPqword'})
                self.shadow.reg_put('eax',0);self.shadow.reg_put('edx',0)
                self.shadow.reg['eflags']&=~b.ARITH
            if entry['unknownWord'] is not None:
                self.shadow.put(entry['unknownWord'],4,0)
                invalidations.append({'address':hex(entry['unknownWord']),'size':4,'why':'omitted floating-derived camera output'})
            self.projections.append({'index':index,'start':hex(a),'stopExclusive':hex(entry['stop']),
              'description':entry['description'],'bytesSha256':b.sha(bytes(c.mem_read(a,entry['stop']-a))),
              'condition':'Omitted floating fragment returns normally without fault; not proved by this projection.',
              'omittedCall':hex(0x55bc54) if entry['ftol'] else None,'invalidations':invalidations,
              'registersBefore':before,'registersAfterInvalidation':self.register_snapshot(),
              'espUnchanged':self.reg_value('esp')==expected_sp})
            self.shadow.reg['eip']=b.MASK32
            c.reg_write(self.x.UC_X86_REG_EIP,entry['stop'])
        except b.Blocked as error:self.fail(error)


def prepare(out):
    pe,base=b.prepare(out,'prepare')
    import capstone
    cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);parts=[]
    for part in SKIPS:
        raw=pe.read(part['start'],part['stop']-part['start']);ins=list(cs.disasm(raw,part['start']))
        if sum(i.size for i in ins)!=len(raw):raise b.Blocked('projection split instruction')
        parts.append({**part,'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
    manifest={'status':'PREPARED_PROJECTED_RESET_NOT_EXECUTED','originalInstructionsExecuted':0,
      'scope':SCOPE,'driver':b.file_record(Path(__file__)),'frozenEngine':b.file_record(BASE_DRIVER),
      'source':base['source'],'inputs':base['inputs'],'executable':base['executable'],
      'allowedWindows':base['resetAllowedWindows'],'omittedFragments':parts,
      'entry':'0x42bfa0','expectedStop':hex(b.STOP),'selectedObservables':observable_spec(),
      'omittedCallee':{'start':'0x55bc54','stopExclusive':'0x55bc7b','sha256':b.sha(pe.read(0x55bc54,0x27)),
        'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in cs.disasm(pe.read(0x55bc54,0x27),0x55bc54)]},
      'supplies':['244 source-bound constant.dat descriptor writes','diagnostic ESP and root return sentinel','cdecl direction flag DF=0 only'],
      'conditionalAssumption':'Each omitted x87 fragment and __ftol call would return normally with no fault. No exception/state-equivalence claim.',
      'singleCallContext':{'caller':'0x42c080','target':'0x41ce00','tailTarget':'0x42cfd0','return':'0x42c085','knownEcx':'0x5fe2f0'},
      'claims':['Both original RNG words fully known and equal0x09d78afe.','All12 class counter bytes fully known and zero.','units_allocated word fully known and zero.','17 retained fixed camera/wrapper words fully known and source-defined.'],
      'nonclaims':['No exact campaign-entry equivalence.','No x87 state/exception equivalence.','No allocation/record identity order or relevant object-byte proof; no allocator or constructor is in scope.','No effects, rendering, pixels, gameplay or parity.'],
      'taintPolicy':{'words':['0x5fe3f0','0x5fe3f4'],'cpu':'EAX,EDX and arithmetic flags invalidated at omitted__ftol; all laterx87 instructions abort.','stack':'Entire20-byte omitted callframe footprint invalidated on both calls.','observables':'Reaching return is insufficient; each claimed byte/value must be fully known and correct.'}}
    b.json_write(out/'projection-preflight.json',manifest);return pe,base,manifest


def validate_approval(approval,manifest):
    expected={'verdict':'ACCEPT_PROJECTED_RESET_DIAGNOSTIC','parentReleasedRunLane':True,'scope':SCOPE,
      'driverSha256':b.sha(Path(__file__).read_bytes()),'frozenEngineSha256':BASE_SHA,
      'sourceBindingSha256':b.sha(json.dumps(manifest['source'],sort_keys=True).encode()),
      'inputBindingSha256':b.sha(json.dumps(manifest['inputs'],sort_keys=True).encode()),
      'projectionBindingSha256':b.sha(json.dumps(manifest['omittedFragments'],sort_keys=True).encode()),
      'observableBindingSha256':b.sha(json.dumps(manifest['selectedObservables'],sort_keys=True).encode()),
      'observedSourceHead':manifest['source']['observedSourceHead']}
    for key,value in expected.items():
        if approval.get(key)!=value:raise b.Blocked('missing/stale projected reset acceptance or parent release',field=key)
    if manifest['source']['trackedStatus']:raise b.Blocked('tracked source drift')


def assert_claims(engine):
    if len(engine.projections)!=3:raise b.Blocked('projection fragment coverage mismatch')
    claims=[]
    for spec in observable_spec():
        a,n,wanted=int(spec['address'],16),spec['bytes'],spec['expectedValue']
        observed=engine.observed(a,n)
        if observed['value']!=wanted:raise b.Blocked('selected reset observable unknown or incorrect',claim=spec['name'],observed=observed,expected=wanted)
        claims.append({'name':spec['name'],'address':hex(a),'bytes':n,'value':wanted,'knownMask':observed['knownMask']})
    for a in [CAMERA+0x100,CAMERA+0x104]:
        if engine.shadow.get(a,4)!=0:raise b.Blocked('omitted camera word falsely known',address=hex(a))
    if engine.shadow.reg_get('edx')!=0:raise b.Blocked('omitted EDX result falsely known at reset boundary')
    return claims


def execute(pe,base,manifest,approval,out):
    validate_approval(approval,manifest) # BEFORE native_cpu construction.
    import unicorn
    helper=b.load_module('projected_reset_native_helper',b.ROOT/'scripts/decomp.py')
    cpu,identity=helper.native_cpu(b.EXE);cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
    engine=ProjectedReset(cpu,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],b.RESET_WINDOWS,iat=pe.imports)
    text=base['textSection'];cpu.mem_protect(text['va'],(text['virtualSize']+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_EXEC)
    for section in pe.sections:
        if section['name']!='.text':cpu.mem_protect(section['va'],(max(section['virtualSize'],section['rawSize'])+4095)&~4095,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    cpu.mem_protect(b.SCRATCH,b.SCRATCH_END-b.SCRATCH,unicorn.UC_PROT_READ|unicorn.UC_PROT_WRITE)
    for a,data in b.constant_writes(pe):engine.supply(a,data,'verified constant.dat descriptor projection; same244 applied writes as accepted base')
    engine.reg_supply('esp',b.STACK,b.MASK32,'cdecl diagnostic fixture, not campaign capture')
    engine.reg_supply('eflags',2,b.DF,'Only cdecl DF=0 known; arithmetic flags unknown')
    engine.supply(b.STACK,struct.pack('<I',b.STOP),'diagnostic root return sentinel')
    engine.phase='explicitly projected clear-level reset';before=engine.snapshot();error=None;claims=[]
    try:
        engine.run(0x42bfa0,b.STOP,timeout_us=180_000_000)
        claims=assert_claims(engine);status='PROJECTED_RESET_SELECTED_OBSERVABLES_PASSED'
    except BaseException as exc:
        status='BLOCKED_PROJECTED_RESET';error={'type':type(exc).__name__,'message':str(exc)}
    result={'status':status,'scope':SCOPE,'identity':identity,'conditionalAssumption':manifest['conditionalAssumption'],
      'attemptedOriginalInstructions':engine.attempted,'committedOriginalInstructions':engine.committed,
      'projections':engine.projections,'selectedObservableAssertions':claims,'before':before,'after':engine.snapshot(),
      'blocker':engine.blocker,'error':error,'calls':engine.events,'openCalls':engine.frames,'allocations':engine.allocations,
      'abortedInstructions':engine.aborted,'suppliedInputs':engine.supplies,'memoryReads':engine.read_events,'memoryWrites':engine.write_events,
      'omittedWords':[engine.observed(CAMERA+offset,4) for offset in [0x100,0x104]],
      'x87State':engine.x87_state,'recordsVisited':0,'notRun':['pool initialization','asset setup','terrain setup','constructor','postpass','gameplay'],
      'driver':b.file_record(Path(__file__)),'frozenEngine':b.file_record(BASE_DRIVER),
      'approvalSha256':b.sha(json.dumps(approval,sort_keys=True).encode())}
    b.json_write(out/'projection-result.json',result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['prepare','run-projected-reset'])
    parser.add_argument('--out',type=Path,required=True);parser.add_argument('--approval',type=Path);args=parser.parse_args()
    if args.out.exists():raise b.Blocked('output must be new; never overwrite receipts')
    args.out.mkdir(parents=True);pe,base,manifest=prepare(args.out)
    if args.mode=='prepare':print(json.dumps({'status':manifest['status'],'originalInstructionsExecuted':0,'omittedFragments':len(SKIPS)}));return
    if not args.approval:raise b.Blocked('new review and parent release required; no native CPU constructed')
    result=execute(pe,base,manifest,json.loads(args.approval.read_text()),args.out)
    print(json.dumps({'status':result['status'],'committedOriginalInstructions':result['committedOriginalInstructions'],'blocker':result['blocker'],'error':result['error']}))
    if result['status'].startswith('BLOCKED'):raise SystemExit(2)
if __name__=='__main__':main()
