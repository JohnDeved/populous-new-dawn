# Conditional projected reset candidate

Status: the frozen candidate passed one independently reviewed, parent-released conditional projected reset. The pre-run contract below is retained as reviewed. The separate accepted pool/terrain result remains in `pool-run01/`.

Driver: `projected_reset_candidate.py`, SHA256 9a0a81d78c68376191c065096ada7b9658f3ac22b0391d3b76445570909588ed. It imports the unchanged guarded engine `constructor_candidate.py` only after checking SHA256 `2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`.

## Exact scope and assumption

Enter original reset at `0042bfa0`, retain original integer instructions and calls, and stop at the diagnostic root return. No pool setup, asset setup, terrain setup, allocator, record constructor, postpass or gameplay is included. The only substituted execution is three byte-bound fragments in the single call context `0042c080 -> 0041ce00 -> 0042cfd0`, returning to `0042c085`, with fully known ECX `005fe2f0`.

This result would be conditional on the omitted floating-point calculations and conversion calls returning normally without a fault. It does not prove original x87 exception absence, initial control/status/tag/stack state, or complete CPU-state equivalence.

Fragments (exclusive upper endpoints):
- `0042cfd0..0042cfd8`: first FLD and FSQRT.
- `0042cfe7..0042cffa`: first `__ftol`, second FLD and FSQRT, and store to camera+104.
- `0042d001..0042d012`: FDIVR, second `__ftol`, and store to camera+100.

All fixed integer camera and wrapper stores remain real original instructions. Native PUSH ESI/PUSH EDI, outer CALL/RET and restore effects remain intact. The skip index, caller/target/return, known ECX, known ESI for later fragments, and exact stack depth are checked at every fragment. No function-wide stub or fabricated return value is installed.

## Provenance effects

The two omitted camera words `005fe3f0` and `005fe3f4` become unknown. Both omitted calls invalidate EAX, EDX, arithmetic flags, and the entire 20-byte stack footprint at current ESP-20 through ESP-1. Equivalently, if S is ESP on camera function entry, this is S-28 through S-9: call return slot, saved EBP, control-word locals and FISTP qword. Preserved ESP/frame effects are not guessed. EDX remains unknown through the selected reset boundary; it is not prematurely supplied based on a later caller overwrite.

Later x87/status instructions, imports, unknown branch conditions and unknown addresses still abort. Pure copies of unknown data may proceed but cannot support claimed outputs. Every declared output must be fully known at the end.

## Predeclared observables and review gate

`projected-preflight-final/projection-preflight.json` contains an exact list of 32 selected observations (name, address, byte length, expected value and full required-known mask): two RNG words, units-allocated word, all 12 class counter bytes, 11 fixed camera words and six wrapper words. `assert_claims` consumes that same source-defined specification. No unknown field is dropped after a run. Both omitted words and EDX must remain unknown, and all three projections must have occurred exactly once.

Fresh review must bind the new driver, frozen engine, source/input manifests, exact projection fragments, and exact observable list. `validate_approval` runs before constructing a native CPU. Required verdict is `ACCEPT_PROJECTED_RESET_DIAGNOSTIC`, scope `conditional-projected-reset-rng-and-class-counters`, and the parent must separately set `parentReleasedRunLane=true`. The pool approval cannot authorize this candidate.

## Verification and later run

`projected-verification-receipt.json` records static preparation, compilation and 42 synthetic tests (25 guarded-engine tests plus 17 projection tests), all passed. Synthetic tests include forbidden-instruction skip checks, preserved native frames/stores, exact stack invalidation, incorrect caller/camera/stack rejection, unknown flags and later x87 rejection, selected-output taint checks and exact observable approval binding. No original execution was involved in those tests.

If independently admitted and released, use the existing native venv Python with `projected_reset_candidate.py run-projected-reset --out <new directory> --approval <new approval receipt>`. The original run has a 180-second native timeout and two-million-instruction limit. Retain the process stdout/stderr, exit status, elapsed time, result JSON and source hashes. A blocked run is not a pass and must preserve the failed receipt; no retry without fresh review of any repair.

## Post-run result

The single admitted run completed at 2026-10-10 23:57:16 UTC, exit 0, in 2.32 seconds. It committed 14,428 original instructions and all 32 predeclared fully-known observations passed. The three explicit omissions were recorded; both omitted camera words and EDX remained unknown. All three genuine nested calls returned; there were no aborted instructions, open calls, allocations or record visits. Tool identities and unchanged driver/base hashes are in `projected-run01-process-receipt.json`. `projected-post-run-summary.json` binds the raw and compressed result and host-only post-checks.

This establishes only the declared reset-output projection, conditional on normal/no-fault return of the omitted floating fragments. It does not establish the full original campaign state, constructor ledger or behavior parity. No further original run is authorized by this receipt.
