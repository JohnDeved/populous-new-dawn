"""Read-only post-review of retained receipts. Does not construct a native CPU."""
from pathlib import Path
import hashlib, importlib.util, json, struct
import capstone

ROOT = Path.cwd()
BASE = ROOT / 'work/orchestration/training-native-20261010/mission3-initialization'
H = BASE / 'harness-repair'
OUT = BASE / 'review-boundary'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
result_path = H / 'projected-run01/projection-result.json'
r = read(result_path)
p = read(H / 'projected-run01/projection-preflight.json')
b = read(H / 'projected-run01/preflight.json')
a = read(H / 'projected-run01-approval-released.json')
v = read(OUT / 'projected-reset-review-verdict.json')
process = read(H / 'projected-run01-process-receipt.json')
assert sha(result_path.read_bytes()) == '6d7c7ed828b4819096f2a2d126d34739d6cfc252a2e68e9137a3a31275ab59f8'
assert a['parentReleasedRunLane'] is True and v['parentReleasedRunLane'] is False
assert a['reviewVerdictSha256'] == sha((OUT / 'projected-reset-review-verdict.json').read_bytes())
for key, value in v.items():
    if key != 'parentReleasedRunLane': assert a[key] == value, key
assert process['approvalSha256'] == sha((H / 'projected-run01-approval-released.json').read_bytes())
assert r['approvalSha256'] == sha(json.dumps(a, sort_keys=True).encode())
assert process['exitCode'] == 0 and process['status'] == 'passed'
assert process['tools']['unicorn'] == '2.1.4' and process['tools']['capstone'] == '5.0.7'
assert process['sourceHead'] == a['observedSourceHead'] == p['source']['observedSourceHead']
for name, record in process['artifacts'].items():
    raw = (H / name).read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256'], name
for file, expected in v['reviewedHashes'].items(): assert sha((H / file).read_bytes()) == expected, file
for key, data in [('source', p['source']), ('input', p['inputs']), ('projection', p['omittedFragments']), ('observable', p['selectedObservables'])]:
    assert a[key + 'BindingSha256'] == sha(json.dumps(data, sort_keys=True).encode()), key
assert p == read(H / 'projected-preflight-final/projection-preflight.json')
for record in [p['driver'], p['frozenEngine'], p['executable'], *p['inputs'], *[x for x in p['source'].values() if isinstance(x, dict) and 'path' in x]]:
    raw = Path(record['path']).read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256'], record['path']
assert r['driver'] == p['driver'] and r['frozenEngine'] == p['frozenEngine']
for prefix, expected in [('driver', a['driverSha256']), ('frozenEngine', a['frozenEngineSha256'])]:
    assert process[prefix + 'Sha256Before'] == process[prefix + 'Sha256After'] == expected
assert r['conditionalAssumption'] == p['conditionalAssumption'] == process['conditionalAssumption']
assert r['scope'] == p['scope'] == v['scope']
assert r['status'] == 'PROJECTED_RESET_SELECTED_OBSERVABLES_PASSED'
assert r['attemptedOriginalInstructions'] == r['committedOriginalInstructions'] == 14428
assert r['blocker'] is None and r['error'] is None
assert not r['allocations'] and not r['openCalls'] and not r['abortedInstructions'] and r['recordsVisited'] == 0
assert r['notRun'] == ['pool initialization', 'asset setup', 'terrain setup', 'constructor', 'postpass', 'gameplay']
assert len(r['calls']) == 3
assert [(e['caller'], e['target'], e['return'], e['returned']) for e in r['calls']] == [
    ('0x42bfce', '0x4a32d0', 0x42bfd3, True), ('0x42c080', '0x41ce00', 0x42c085, True), ('0x42c099', '0x475530', 0x42c09e, True)]

spec = importlib.util.spec_from_file_location('static_pe_reader', ROOT / 'scripts/check-static-mission18-sky.py')
reader = importlib.util.module_from_spec(spec); spec.loader.exec_module(reader)
pe = reader.PE32(Path(p['executable']['path']))
assert sha(pe.data) == r['identity']['sha256'] == '3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
# Linear source regions in the recorded, exact call order. REP iterations repeat
# one PC. The separate read/write arrays lack shared event ordinals; this joins
# them by canonical source order, not by claiming a saved instruction trace.
regions = [(0x42bfa0,0x42bfd3),(0x4a32d0,0x4a3330),(0x42bfd3,0x42c085),
           (0x41ce00,0x41ce2f),(0x42cfd0,0x42d03c),(0x42c085,0x42c09e),
           (0x475530,0x475548),(0x42c09e,0x42c12c)]
rows = {}; ranks = {}; source_windows = []
for lo, hi in regions:
    raw = pe.read(lo,hi-lo); ins = list(cs.disasm(raw,lo))
    assert sum(i.size for i in ins) == len(raw)
    source_windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':sha(raw)})
    for i in ins: ranks[i.address] = len(ranks); rows[i.address] = i
assert rows[0x41ce2a].mnemonic == 'jmp' and rows[0x41ce2a].op_str == '0x42cfd0'
assert len(r['projections']) == 3
for idx, (event, expected) in enumerate(zip(r['projections'], p['omittedFragments'])):
    assert event['index'] == idx and int(event['start'],16) == expected['start'] and int(event['stopExclusive'],16) == expected['stop']
    assert event['bytesSha256'] == expected['sha256'] == sha(pe.read(expected['start'],expected['stop']-expected['start']))
    assert event['espUnchanged']
    before = event['registersBefore']; after = event['registersAfterInvalidation']
    assert before['ecx'] == {'value':'0x5fe2f0','knownMask':'0xffffffff'}
    assert before['esp']['knownMask'] == '0xffffffff'
    wanted_sp = r['calls'][1]['returnSp'] - (4 if idx == 0 else 12)
    assert int(before['esp']['value'],16) == wanted_sp
    if idx:
        assert before['esi'] == {'value':'0x5fe2f0','knownMask':'0xffffffff'}
        assert event['omittedCall'] == '0x55bc54'
        assert [(int(e['address'],16),e['size']) for e in event['invalidations']] == [(wanted_sp-20,20),(0x5fe3f4 if idx == 1 else 0x5fe3f0,4)]
        assert after['eax']['knownMask'] == after['edx']['knownMask'] == '0x0'
        assert int(after['eflags']['knownMask'],16) & 0x8d5 == 0
        assert int(after['eflags']['knownMask'],16) & 0x400 == 0x400
    else: assert not event['invalidations'] and event['omittedCall'] is None

known = {}; sources = {}; initial = b['constantWrites']
assert len(initial) == 244 and len(r['suppliedInputs']) == 247
for expected, observed in zip(initial, r['suppliedInputs'][:244]):
    addr = int(expected['address'],16); data = bytes.fromhex(expected['bytesHex'])
    assert observed['address'] == hex(addr) and observed['size'] == len(data) and observed['sha256'] == sha(data)
    for j in range(len(data)): known[addr+j] = 255; sources[addr+j] = 'constant descriptor'
assert r['suppliedInputs'][-3]['register'] == 'esp' and r['suppliedInputs'][-3]['value'] == '0x23ed000'
assert r['suppliedInputs'][-2]['register'] == 'eflags' and r['suppliedInputs'][-2]['knownMask'] == '0x400'
assert r['suppliedInputs'][-1]['address'] == '0x23ed000' and r['suppliedInputs'][-1]['sha256'] == sha(struct.pack('<I',0x23ee000))
for j in range(4): known[0x23ed000+j] = 255; sources[0x23ed000+j] = 'root return fixture'

events = []
assert len(r['memoryReads']) == 19 and len(r['memoryWrites']) == 57419
for kind, priority, data in [('read',0,r['memoryReads']),('write',1,r['memoryWrites'])]:
    previous = -1
    for index, event in enumerate(data):
        pc = int(event['pc'],16); rank = ranks[pc]
        assert rank >= previous, (kind,index,hex(pc)); previous = rank
        assert not any(s['start'] <= pc < s['stop'] for s in p['omittedFragments'])
        assert any(int(lo,16) <= pc < int(hi,16) for lo,hi in p['allowedWindows'])
        if kind == 'write': assert event['committed'] is True and event['size'] == 1
        events.append((rank,priority,index,kind,event))
for index, event in enumerate(r['projections']): events.append((ranks[int(event['start'],16)],-1,index,'invalidate',event))
read_provenance = []
for _,_,_,kind,event in sorted(events):
    if kind == 'invalidate':
        for item in event['invalidations']:
            for addr in range(int(item['address'],16),int(item['address'],16)+item['size']):
                known[addr] = 0; sources[addr] = 'projection invalidation '+event['start']
        continue
    addr = int(event['address'],16); n = event['size']; mask = int(event['knownMask'],16)
    if kind == 'read':
        reconstructed = sum(known.get(addr+j,0) << (8*j) for j in range(n))
        assert reconstructed == mask, (event,hex(reconstructed))
        read_provenance.append({**event,'canonicalInstruction': rows[int(event['pc'],16)].mnemonic+' '+rows[int(event['pc'],16)].op_str,
                                'byteSources':[sources.get(addr+j,'unknown prior memory') for j in range(n)]})
    else:
        known[addr] = mask; sources[addr] = event['pc']

assert len(p['selectedObservables']) == len(r['selectedObservableAssertions']) == 32
claim_writers = []
for expected, observed in zip(p['selectedObservables'],r['selectedObservableAssertions']):
    assert observed == {key:expected[key] for key in ['name','address','bytes']} | {'value':expected['expectedValue'],'knownMask':expected['requiredKnownMask']}
    addr = int(observed['address'],16); n = observed['bytes']
    assert all(known.get(addr+j,0) == 255 for j in range(n))
    last = sorted(set(sources[addr+j] for j in range(n)))
    assert all(s.startswith('0x') for s in last)
    claim_writers.append({'name':observed['name'],'address':observed['address'],'lastNativeWriterPcs':last,
                         'instructions':[rows[int(s,16)].mnemonic+' '+rows[int(s,16)].op_str for s in last]})
for address, observed in zip([0x5fe3f0,0x5fe3f4],r['omittedWords']):
    assert observed == {'address':hex(address),'value':None,'knownMask':'0x0'}
    assert all(known.get(address+j,0) == 0 for j in range(4))
assert all(known.get(addr,0) == 0 for addr in range(0x23ecfd8,0x23ecfec))
after = r['after']['registers']
assert after['edx']['knownMask'] == '0x0' and r['x87State'] == 'unknown and unsupported'
assert after['eax']['knownMask'] == after['ecx']['knownMask'] == '0xffffffff'
assert after['esp'] == {'value':'0x23ed004','knownMask':'0xffffffff'} and after['eip'] == {'value':'0x23ee000','knownMask':'0xffffffff'}
assert r['before']['class1Seed'] == {'address':'0x96eac2','value':None,'knownMask':'0x0'}
assert r['after']['class1Seed'] == {'address':'0x96eac2','value':0,'knownMask':'0xff'}
report = {'verdict':'ACCEPT_CONDITIONAL_PROJECTED_RESET_RESULT','reviewerOriginalInstructionsExecuted':0,
          'resultSha256':sha(result_path.read_bytes()),'processReceiptSha256':sha((H/'projected-run01-process-receipt.json').read_bytes()),
          'approvalSha256':process['approvalSha256'],'driverSha256':a['driverSha256'],'frozenEngineSha256':a['frozenEngineSha256'],
          'originalInstructionsCommitted':14428,'selectedObservablesVerified':32,'projectionFragmentsVerified':3,
          'memoryReadsReconstructed':19,'committedByteWritesVerified':57419,'sourceWindows':source_windows,
          'memoryReadProvenance':read_provenance,'selectedObservableLastWriters':claim_writers,
          'stackFootprint':{'start':'0x23ecfd8','endExclusive':'0x23ecfec','bytes':20,'invalidations':2,'allRemainUnknown':True},
          'omittedWordsUnknown':True,'edxUnknown':True,'x87Unsupported':True,'genuineCallsReturned':3,
          'conditionalAssumption':p['conditionalAssumption'],
          'evidenceLimits':['Reads and writes are separate arrays without a shared ordinal. The verified canonical call order and monotone source regions reconstruct their order; this is not an independent instruction execution replay.',
                            'Writes retain masks, not value bytes. Selected values are checked in the frozen native final-memory assertions and bound to original last-writer instructions.',
                            'No original floating-point instructions, constructor, allocator, assets, terrain, pool, postpass or gameplay ran in this diagnostic.',
                            'This is a conditioned reset-return result; neither actual campaign-entry provenance nor later class1 allocation chronology is proved.']}
(OUT/'projected-run01-post-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','originalInstructionsCommitted','selectedObservablesVerified','projectionFragmentsVerified','memoryReadsReconstructed','committedByteWritesVerified','reviewerOriginalInstructionsExecuted']}))
