# Fresh review: frozen projected-reset candidate

## Verdict

ACCEPT_PROJECTED_RESET_DIAGNOSTIC, after separate parent release, for only scope `conditional-projected-reset-rng-and-class-counters`.

New driver SHA-256: `9a0a81d78c68376191c065096ada7b9658f3ac22b0391d3b76445570909588ed`.
Frozen guarded engine: `2b4594cf3d212d0f5aeb73f837037ff4653f468769b22d3f3acf6c018c74a46f`.
Reviewed HEAD: `ee13adccedec8a801382f1f51e3a0a969073020d`; tracked status clean. The change from the previous review HEAD is solely the reviewed pool/terrain evidence publication, not product or helper code.

The exact release payload is `projected-reset-review-verdict.json`, with parent release initially false. It binds driver, frozen engine, source, inputs, three projection fragments and the complete32-field observable specification. Do not edit that reviewer payload; the parent can create its separate release receipt.

Publication acceptance covers the prepared static/synthetic packet. The reviewer executed no original instructions. No runtime result is claimed here.

## Mechanism and boundary

Entry is0042bfa0; stop is the root diagnostic return. Only the single0042c080→0041ce00→0042cfd0 camera context may omit three exact byte-bound spans:0042cfd0..0042cfd8,0042cfe7..0042cffa,0042d001..0042d012. Endpoints are exclusive. The hook checks fragment sequence, exact caller/target/return, known camera pointer, known saved camera pointer where applicable, and exact stack depth.

Native integer stores, real outer call/return, saved ESI/EDI and stack restoration remain. Each omitted conversion invalidates EAX, EDX, arithmetic flags and20 stack bytes at current ESP-20..ESP-1. The omitted100/104 camera words are unknown; raw old bytes cannot support a claim. The frozen guard still rejects unknown decisive use, unsupported instructions, later x87/status instructions, imports, prohibited targets and unmodeled accesses.

The predeclared32 observations are two RNG words, one allocation count,12 class-counter bytes,11 fixed camera words and six wrapper words. Every observation must have its exact expected value with full known provenance. The two omitted camera words and EDX must still be unknown at the reset boundary. Reaching return alone does not pass.

Acceptance is explicitly conditional on normal, fault-free completion of the omitted floating fragment. No x87 exception/control/status/tag/stack equivalence, complete native-state equivalence or actual campaign history is established. There is no function-wide stub, fabricated numeric return, constructor/allocator trace, renderer result or gameplay admission.

## Independent checks

- Ran the frozen author suite with existing venv:42/42 synthetic tests passed, exit0. Log:`projected-synthetic-final.log`.
- Reran static prepare into a fresh reviewer directory:exit0, projection preflight identical to the author JSON. Log:`projected-preflight-final.log`; output:`projected-preflight-final/`.
- Verified all frozen driver/base/test/preflight/receipt hashes, receipt log hashes, source/helper/input identities and the canonical bytes/instruction boundaries of all three skipped spans.
- Driver/base/test remained unchanged throughout checks:`projected-frozen-inputs.sha256`.
- Tests cover exact20-byte reused-stack invalidation, fragment/frame/context rejection, retained native integer stores, unknown branch rejection, unsupported later x87, fully-known output checks and observable-list approval binding.

No unresolved correctness blocker was found for this narrow diagnostic. Runtime tool identity is required in the process receipt: Python executable/version, Unicorn, Capstone and platform. The author confirmed this will be recorded without changing the frozen code.

No original reset, x87, allocator, constructor, postpass, gameplay, full product check/build or browser verification was run by the reviewer. Product verification is not applicable to this isolated research candidate. A new driver/source/input/fragment/observable binding requires fresh review; no broader lane is released by this verdict.
