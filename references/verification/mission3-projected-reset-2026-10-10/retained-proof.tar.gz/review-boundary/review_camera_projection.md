# Finite review: camera x87 output projection

Verdict: VIABLE CONDITIONED PROJECTION DESIGN, NOT EXECUTION ADMISSION.

This review executed no original instructions and changed no product or harness code. It verified31 exact canonical assertions across19 complete static windows/455 instructions. Raw source evidence and conditions are retained in `camera-projection-review.json`; the read-only checker and log are alongside it.

## Narrow the dependency

The two float-derived integer outputs are camera+100 at005fe3f0 and camera+104 at005fe3f4. Known precise readers:

-0042d2c9: IDIV by camera+100, only after camera+4c is nonzero.
-0042dab5: camera+104 via ECX.
-0042dd71: camera+104 via EDI alias.
-0041d73e: direct005fe3f4 read in the globe drawing body.

The potential model86 path through00477060 reaches camera operations, but that alone does not prove consumption of these two outputs.0041ef80 sets ECX=005fe2f0 then calls0042d060, whose relevant old-field reads and updated arrays do not overlap100/104; the arrays finish at+d8.0041fb10 tail-jumps0042d380, which only clears+4c. Ghidra's NO_FUNCTION alias0041cdb0 is an additional initializer thunk into0042cfd0, not an unidentified reader.

The direct Mission3 class7/model23 switch evidence remains distinct from nested reachability. One apparently missing state-initializer edge is closed: class7 dispatch004ed693 targets0050a740, whose complete body is RET. No actual Mission3 route to the four precise readers was established in this finite review, and incomplete graph absence is not an exclusion proof.

## CPU and stack live-outs

EDX is dead on the actual0042b590 continuation: reset suffix and00475530 do not read it;004a2920 and00401040 do not read it;00401790 first defines it with one-operand IMUL004017ce before its first subsequent read004017d2. This is specific to that caller continuation, not a claim for every reset caller.

Skipping __ftol has stack effects as well as register/output effects. Relative to0042cfd0 entry ESP=S, each call writes20 contiguous bytes S-28 through S-9: return address4, saved EBP4, saved/modified control words4, and FISTP qword8. Those slots must be invalidated conservatively or proved dead if the actual writes are omitted. Previously known reused stack bytes must not retain false provenance.

## Required design contract

A complete fail-closed trace can establish independence of selected observables without exhaustive static reader reachability if:

1. The omission is bound to one named reset phase/call context with ECX=005fe2f0. It must not become a global stub of0042cfd0 or any arbitrary camera routine.
2. Source-bound integer camera/global stores and correct frame/ESP effects remain intact. Omitted100/104, uncertain CPU live-outs, and omitted stack-write footprint remain unknown.
3. The guards still abort on unknown decisive operands/addresses/branches and all unsupported, x87/status, interrupt or OS/import operations.
4. The exact observable set is declared before the trace; every claimed final seed/RNG/ledger/object/link observation must be fully known. Unknown MOVs and stack copies are permitted, so reaching the stop is insufficient. Unknown fields cannot be excluded after the fact merely to pass.
5. The result is explicitly conditioned on normal completion without a fault in the omitted x87 fragment. Skipping it cannot prove absence of an original exception, bad stack tag or other nonreturning behavior.
6. Exact skipped instruction spans are disclosed as projection substitutions. This is not full-native execution, complete machine-state equality, actual campaign-entry history, renderer parity, or permission to run the unfinished constructor.

The current accepted driver remains unchanged and no omission is implemented or admitted. Any candidate needs its own exact scope, invalidation tests, predeclared observations and fresh independent review before execution.
