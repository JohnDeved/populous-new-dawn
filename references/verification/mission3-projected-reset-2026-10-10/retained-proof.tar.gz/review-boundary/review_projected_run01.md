# Projected reset run 01: independent post-review

Verdict: **ACCEPT_CONDITIONAL_PROJECTED_RESET_RESULT**. This accepts the retained
result for its predeclared selected observables; it admits no additional run.

The read-only verifier `verify_projected_run01.py` passed with zero original
instructions executed by the reviewer. Full checks and source/read/write
provenance are in `projected-run01-post-review.json`; its command output is in
`projected-run01-post-review.log`.

## Checked identity and result

- The released approval matches the immutable independent verdict and all five
  source/input/driver/projection/observable bindings. The parent's separate
  release preceded the run. The preflight matches the reviewed preflight exactly.
- Canonical EXE, current helper/input bytes, frozen driver `9a0a81d7...`, frozen
  base engine `2b4594cf...`, receipt artifacts and before/after fingerprints match.
  The process receipt records Python 3.12.14, Unicorn 2.1.4, Capstone 5.0.7 and
  platform identity. Exit 0, elapsed 2.3195 seconds.
- Exactly 14,428 attempted and committed original integer instructions, three
  declared projections, three returned genuine calls, zero aborted instructions,
  errors, blockers, allocations, records or open call frames.
- Exactly the 32 predeclared observations are fully known and correct: both RNG
  words equal `0x09d78afe`; twelve class-counter bytes and units-allocated are zero;
  seventeen fixed camera/wrapper words match their source-defined values.
- The class-1 counter starts unknown and finishes known zero **at reset return**.
  This is not a claim about its value after object allocation or a mission wave.

## Taint and trace checks

All 19 memory-read masks were reconstructed from the declared 244 constant
descriptor writes, diagnostic root-return supply, committed original writes and
the three projection events. All 57,419 byte-write events are marked committed,
have canonical PCs in the approved windows, and avoid omitted instruction spans.
Every selected observation has a fully-known final mask and original last-writer
PC. The retained arrays have no shared event ordinal: their order was reconstructed
from the canonical, exact recorded call order and monotone source regions, not
from a claimed independent instruction replay.

The projection events match the exact three source-byte ranges and known camera,
stack and caller context. Both conversions invalidate the entire same 20-byte
stack interval `[0x23ecfd8, 0x23ecfec)`. That interval remains unknown at return;
no retained read touches it. Neither omitted camera word is read or promoted into
known state. Both final omitted words are null with mask zero. EDX remains
unknown; EAX and ECX are made known by retained integer definitions. x87 state
remains unknown and unsupported.

Write events record masks rather than value bytes. The selected values are
supported by the frozen driver's final-memory assertions, exact predeclared
expectations and source-bound final writer instructions. This report does not
misrepresent the trace as an independent complete value replay.

## Accepted claim limits

The condition remains explicit: every omitted floating fragment and `__ftol`
invocation would return normally without fault. This run does not prove that
condition, floating-point exceptions, x87 state equivalence, all-state equivalence,
actual campaign-entry history, rendering or gameplay. No pool, terrain, assets,
allocator, constructor, postpass or game turn executed in this diagnostic.

The earlier pool/terrain result and this reset result are separate dependency
proofs. They cannot be treated as a captured campaign state or concatenated into
a complete constructor ledger without reviewing the intervening real setup.

## Smallest next constructor-setup proof

The next finite source-only target is the first real caller continuation:
`0042b59c -> 004a2920`. At `004a2927`, the palette helper loads pointer
`[0087eff8]`; `004a292d` adds `0x1c0`; `004a293f` copies sixteen dwords to
`00899f8d`. This reset result does not write that pointer. Bind its actual producer
and lifetime to this boundary, plus the known provenance of the exact 64 source
bytes, or obtain a separately reviewed selected-output omission proof. A guessed
palette pointer or blanket successful helper return is not acceptable. With the
current conservative integer guard, the unknown pointer would become decisive at
the ADD; do not run merely to rediscover that known stop.

After that small gap is closed, review the next source-ordered sunlight/tribe and
asset producers before composing a constructor-only candidate. Keep the omitted
camera words, x87 state and other unbound fields tainted across that composition;
retain both land-mask `0x08` alternatives until actual history is bound. Genuine
bank-6 relocation/aniob/morph and consumed animation data, related-record pointer
`00892443` lifetime, and complete direct/nested allocation logging remain open.
