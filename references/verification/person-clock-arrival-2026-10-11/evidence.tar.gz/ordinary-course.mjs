import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { createMission1VaultInput } from '../../scripts/local-render/mission1-vault-input.mjs'

// Ordinary Mission 3 controls and uninterrupted real RAF; observations are copied only.
export default async function ({ page, openMission, output, signal, receipt }) {
  const report = { status: 'running', actions: [], source: receipt.source,
    checkerSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'),
    method: 'Direct Mission 3 startup through shipped All missions UI, ordinary construction and group order. Real RAF only; no simulation, entity, camera or storage injection.',
    limits: 'Headless software-WebGL. Direct mission access does not prove campaign unlocking. No original executable run or pixel parity. Frozen product source with detached passive snapshots only; observation overhead may alter wall-clock scheduling. Browser actions follow the retained main witness, but real RAF action turns and chosen construction site can differ. Canonical Unit phases do not claim exact original Mission3 startup history. First-seen people are first-observed snapshots, never allocation-time birth claims: openMission may already have advanced startup.' }
  const save = () => writeFileSync(resolve(output, 'ordinary-m3.json'), JSON.stringify(report,null,2)+'\n')
  const read = () => page.evaluate(() => {
    const s=window.testSceneRef.current, w=s.world, gl=s.renderer.getContext(), d=gl.getExtension('WEBGL_debug_renderer_info')
    return { turn:w.turn, time:w.time, status:w.status, paused:w.paused, speed:w.speed, selected:[...w.selected], mode:w.mode, inputMask:w.inputMask, unlockedCamp:w.unlockedCamp,
      sceneMatches:s.world===window.testStore.getWorld(), renderer:d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
      buildings:w.buildings.filter(b=>b.team==='blue').map(b=>({id:b.id,kind:b.kind,x:b.x,z:b.z,hp:b.hp,progress:b.progress,logs:b.logs,stage:b.construction?.stage,admission:b.admission&&structuredClone(b.admission)})),
      people:w.units.filter(u=>u.team==='blue').map(u=>({id:u.id,kind:u.kind,hp:u.hp,x:u.x,z:u.z,inside:u.inside,work:u.work,builder:!!u.builder,entry:u.entry&&{substate:u.entry.person.substate}})) }
  })
  let input, installed=false, clockInstalled=false, capture=null
  report.screencast={method:'Read-only Chrome Page.startScreencast, every tenth rendered frame, capped at12 for this bounded callback diagnostic; captured pixels may lag copied turn time. No baseline screencast exists.',maxFrames:12,frames:[],errors:[],closed:false}
  const capturePending=[]
  const stopCapture=async()=>{if(!capture||report.screencast.closed)return
    try{await capture.send('Page.stopScreencast');await Promise.all(capturePending);await capture.detach();report.screencast.closed=true}
    catch(e){report.screencast.errors.push(String(e))}
  }
  const wait = async (label,predicate,ms) => {
    const start=Date.now(); let lastLog=0
    for(;;){ signal.throwIfAborted(); const s=await read(); report.latest=s
      if(Date.now()-lastLog>10000){report.actions.push({label,observed:s});save();lastLog=Date.now()}
      if(predicate(s))return s
      assert.equal(s.status,'playing'); assert.equal(s.speed,1)
      assert(Date.now()-start<ms,`${label} timed out`)
      await page.waitForTimeout(250)
    }
  }
  const clear = async()=>{ for(let i=0;i<3;i++){const s=await read();if(!s.mode&&!s.selected.length)return;await input.action('clear-selection',()=>page.keyboard.press('Escape'))}throw Error('Selection did not clear')}
  try {
    await openMission(3)
    report.initial=await read()
    report.ownerInitial=await page.evaluate(()=>{
      const scene=window.testSceneRef.current,w=scene.world,c=scene.gameClock,prior=c.afterTurn,seen=new Set(),births=[],errors=[],objects=new WeakMap();let nextObject=0
      const objectId=o=>{if(!o||typeof o!=='object')return null;if(!objects.has(o))objects.set(o,++nextObject);return objects.get(o)}
      const person=p=>p?{object:objectId(p),id:p.id,counter:p.counter,state:p.state,substate:p.substate,flags2:p.flags2,flags3:p.flags3,flags4:p.flags4,x:p.x,y:p.y,model:p.model,commands:[...p.commands],commandCursor:p.commandCursor}:null
      const snapshot=(world,ids)=>({turn:world.turn,clock:structuredClone(world.personClock),people:ids.map(id=>{const u=world.units.find(u=>u.id===id);return u?{id:u.id,object:objectId(u),kind:u.kind,team:u.team,hp:u.hp,x:u.x,z:u.z,inside:u.inside,work:u.work,counter:u.personCounter,owners:{native:person(u.native),entry:person(u.entry?.person),builder:person(u.builder?.person),flight:person(u.flight),fight:person(u.fight?.motion),resident:person(u.resident?.person),path:person(world.pathfinding.people.get(id))}}:{id,removed:true}})})
      const observeBirths=()=>{try{for(const u of w.units.filter(u=>u.team==='blue'))if(!seen.has(u.id)){if(births.length>=256)throw Error('Birth observation capacity');seen.add(u.id);births.push(snapshot(w,[u.id]))}}catch(e){if(errors.length<8)errors.push(String(e))}}
      function wrapper(...args){const result=prior?.apply(this,args);observeBirths();return result}
      c.afterTurn=wrapper;observeBirths()
      window.personClockObservation={snapshot,read:()=>structuredClone({births,errors}),close(){if(c.afterTurn!==wrapper)throw Error('Birth observer changed');c.afterTurn=prior;return structuredClone({births,errors,restored:true})}}
      return snapshot(w,w.units.filter(u=>u.team==='blue').map(u=>u.id))
    });clockInstalled=true;save()
    const shaman=report.initial.people.find(u=>u.kind==='shaman'&&u.hp>0)
    assert(shaman); assert(report.initial.unlockedCamp)
    input=createMission1VaultInput({page,signal,report,save,originalShamanId:shaman.id})
    await clear()
    await wait('initial-Braves-ready',s=>s.people.filter(u=>u.kind==='brave'&&u.hp>0).length>=5,120000)
    await input.action('select-five-builders',()=>page.getByRole('button',{name:'Select brave',exact:true}).click({modifiers:['Control']}))
    report.builders=(await read()).selected;assert.equal(report.builders.length,5)
    const home=report.initial.buildings.find(b=>b.kind==='hut')??shaman
    await input.view(home)
    report.site=await page.evaluate(async home=>{
      const {placementError}=await import('/app/model.ts'),s=window.testSceneRef.current,probe=structuredClone(s.world),r=s.renderer.domElement.getBoundingClientRect(),seen=new Set(),rejected={ownership:0,object:0,pick:0,placement:0}
      for(let radius=5;radius<=20;radius++)for(let angle=0;angle<Math.PI*2;angle+=Math.PI/12){
        const target={x:home.x+Math.cos(angle)*radius,z:home.z+Math.sin(angle)*radius},p=s.screen(target),hit={x:Math.round(r.left+(p.x+1)*r.width/2),y:Math.round(r.top+(1-p.y)*r.height/2)},key=`${hit.x},${hit.y}`
        if(seen.has(key))continue;seen.add(key)
        const event={clientX:hit.x,clientY:hit.y}
        if(document.elementFromPoint(hit.x,hit.y)!==s.renderer.domElement){rejected.ownership++;continue}
        if(s.pickUnit(event)||s.picking.pickPerson(event)||s.pickWorldObject(event)){rejected.object++;continue}
        const point=s.pick(event)
        if(!point||Math.hypot(point.x-target.x,point.z-target.z)>1.5){rejected.pick++;continue}
        if(placementError(probe,'camp',point)){rejected.placement++;continue}
        return {...hit,point:{x:point.x,z:point.z},rejected}
      }return {rejection:'No legal owned Warrior site',rejected}
    },home); save();assert(!report.site.rejection)
    await input.button('buildings B');await input.button('Warrior Training Hut, 8 wood')
    report.beforePlacement=await read()
    await input.action('place-Warrior-training-hut',()=>page.mouse.click(report.site.x,report.site.y))
    report.afterPlacement=await read();save()
    const target=report.afterPlacement.buildings.find(b=>b.kind==='camp'&&!report.beforePlacement.buildings.some(p=>p.id===b.id));assert(target)
    report.target=target
    assert(report.builders.every(id=>report.afterPlacement.people.find(u=>u.id===id)?.work===target.id))
    report.completed=await wait('ordinary-Warrior-hut-completed',s=>s.buildings.some(b=>b.id===target.id&&b.progress===1),180000);save()
    await input.pause();await clear();await input.view(target)
    await page.mouse.move(400,800);await page.screenshot({path:resolve(output,'ordinary-completed-warrior-hut.png')})
    await input.resume()
    await wait('builders-released',s=>report.builders.every(id=>!s.people.find(u=>u.id===id)?.builder),30000)
    await clear()
    await input.action('select-first-five-trainees',()=>page.getByRole('button',{name:'Select brave',exact:true}).click({modifiers:['Control']}))
    await input.action('select-next-five-trainees',()=>page.getByRole('button',{name:'Select brave',exact:true}).click({modifiers:['Control']}))
    report.selected=(await read()).selected; assert(report.selected.length>5)
    await input.view(target)
    await input.prepareDispatch();report.hit=await input.entityPoint('buildings',target.id,8);save();assert.equal(report.hit.rejection,null)
    report.arrivalArm=await page.evaluate(({targetId,ids})=>window.arrivalObservation.arm(window.testSceneRef.current.world,[513,300,312,519],targetId,ids),{targetId:target.id,ids:report.selected});save()
    report.observerInitial=await page.evaluate(({targetId,ids})=>{
      const s=window.testSceneRef.current,w=s.world,c=s.gameClock,prior=c.afterTurn,rows=[],errors=[]
      const snapshot=()=>{const b=w.buildings.find(b=>b.id===targetId),a=b?.admission
        return {owners:window.personClockObservation.snapshot(w,ids),observedAtMs:Date.now(),turn:w.turn,time:w.time,paused:w.paused,target:b&&{id:b.id,hp:b.hp,progress:b.progress,inside:a?.inside,entering:a?.entering,entryDelay:a?.entryDelay,entryTimer:a?.entryTimer,queueHead:a?.queueHead,queueFrom:a?.queueFrom,occupants:a&&[...a.occupants]},
          people:ids.map(id=>{const u=w.units.find(u=>u.id===id),p=u?.entry?.person;return {id,kind:u?.kind,hp:u?.hp,x:u?.x,z:u?.z,inside:u?.inside,work:u?.work,entry:p&&{state:p.state,substate:p.substate,counter:p.counter,speed:p.speed,x:p.x,y:p.y,goalX:p.goalX,goalY:p.goalY,flags2:p.flags2,flags3:p.flags3,flags4:p.flags4,renderFlags:p.renderFlags,reservationNext:p.reservationNext,commandPhase:p.commandPhase}}})}}
      const observe=()=>{try{if(rows.length>=2400)throw Error('Observer capacity reached');rows.push(snapshot())}catch(e){if(errors.length<8)errors.push(String(e))}}
      function wrapper(...args){const result=prior?.apply(this,args);observe();return result}
      c.afterTurn=wrapper; observe()
      window.issue29Observer={read:()=>({rows,errors}),snapshot,close(){if(c.afterTurn!==wrapper)throw Error('Observer changed');c.afterTurn=prior;return {rows,errors,restored:true}}}
      return snapshot()
    },{targetId:target.id,ids:report.selected});installed=true
    capture=await page.context().newCDPSession(page)
    capture.on('Page.screencastFrame',event=>{
      const index=report.screencast.frames.length
      if(index<report.screencast.maxFrames){try{
        const file=`entry-frame-${String(index).padStart(3,'0')}.png`
        writeFileSync(resolve(output,file),Buffer.from(event.data,'base64'))
        report.screencast.frames.push({index,file,receivedAtMs:Date.now(),metadata:event.metadata})
      }catch(e){report.screencast.errors.push(String(e))}}
      const acknowledged=capture.send('Page.screencastFrameAck',{sessionId:event.sessionId}).catch(e=>report.screencast.errors.push(String(e)))
      capturePending.push(acknowledged)
    })
    await capture.send('Page.startScreencast',{format:'png',maxWidth:1440,maxHeight:1000,everyNthFrame:10})
    report.clickObserverArmed=await page.evaluate(ids=>{
      const s=window.testSceneRef.current,w=s.world,canvas=s.renderer.domElement,record={before:[],after:[],errors:[]}
      const observe=(phase,event)=>{try{record[phase].push({type:event.type,trusted:event.isTrusted,button:event.button,clientX:event.clientX,clientY:event.clientY,ctrlKey:event.ctrlKey,shiftKey:event.shiftKey,altKey:event.altKey,metaKey:event.metaKey,canvasTarget:event.target===canvas,worldMatches:s.world===window.testStore.getWorld(),owners:window.personClockObservation.snapshot(w,ids)})}catch(e){record.errors.push(String(e))}}
      const before=e=>observe('before',e),after=e=>observe('after',e)
      canvas.addEventListener('pointerup',before,true);canvas.addEventListener('pointerup',after)
      window.issue29ClickOwners={close(){canvas.removeEventListener('pointerup',before,true);canvas.removeEventListener('pointerup',after);return record}}
      return {turn:w.turn,ids}
    },report.selected)
    try {report.dispatch=await input.dispatch(report.hit,8,report.selected)}
    finally {report.trustedClickOwners=await page.evaluate(()=>{const result=window.issue29ClickOwners.close();delete window.issue29ClickOwners;return result});save()}
    assert.equal(report.trustedClickOwners.before.length,1);assert.equal(report.trustedClickOwners.after.length,1)
    assert.deepEqual(report.trustedClickOwners.errors,[])
    assert(report.trustedClickOwners.before.concat(report.trustedClickOwners.after).every(s=>s.trusted&&s.button===0&&s.canvasTarget&&s.worldMatches))
    assert.equal(report.trustedClickOwners.before[0].owners.turn,report.trustedClickOwners.after[0].owners.turn)
    save()
    await page.mouse.move(400,800)
    const started=Date.now();let captured=false
    for(;;){signal.throwIfAborted();const data=await page.evaluate(()=>window.issue29Observer.read());report.timeline=data
      const arrival=await page.evaluate(()=>window.arrivalObservation.status()); if(arrival.errors.length)throw Error(arrival.errors.join('; '));
      const latest=data.rows.at(-1),residents=latest.people.filter(u=>u.inside===target.id),waiting=latest.people.filter(u=>u.inside!==target.id)
      if(!captured&&data.rows.some(r=>r.people.filter(u=>u.entry?.substate===5&&u.inside===null).length>1)){
        await input.pause();report.frozen=await page.evaluate(()=>window.issue29Observer.snapshot());await page.screenshot({path:resolve(output,'ordinary-multiple-entering.png')});await input.resume();captured=true
      }
      if(latest.target.inside===5&&residents.length===5&&waiting.length===report.selected.length-5&&waiting.every(u=>u.work===target.id&&u.entry?.substate===3))break
      if(Date.now()-started>75000)break
      if(data.errors.length)throw Error(data.errors.join('\n'))
      await page.waitForTimeout(50)
    }
    await stopCapture();await input.pause();report.terminal=await read();report.timeline=await page.evaluate(()=>window.issue29Observer.close());installed=false
    const last=report.timeline.rows.at(-1),residents=last.people.filter(u=>u.inside===target.id),waiting=last.people.filter(u=>u.inside!==target.id)
    assert.equal(last.target.inside,5,'Complete witness needs five actual residents')
    assert.equal(residents.length,5,'Exactly five selected people must be inside')
    assert.equal(waiting.length,report.selected.length-5)
    assert(waiting.length>0&&waiting.every(u=>u.work===target.id&&u.entry?.substate===3),'Every overflow selected person must reach the actual queue')
    assert.deepEqual(last.target.occupants.filter(Boolean).sort((a,b)=>a-b),residents.map(u=>u.id).sort((a,b)=>a-b))
    const queue=[],seen=new Set();let next=last.target.queueHead
    while(next){assert(!seen.has(next),'Queue must not cycle');seen.add(next);queue.push(next);const p=waiting.find(u=>u.id===next);assert(p,'Queue must contain a selected overflow person');next=p.entry.reservationNext}
    assert.deepEqual(queue.slice().sort((a,b)=>a-b),waiting.map(u=>u.id).sort((a,b)=>a-b),'Every overflow person must occur exactly once in actual queue chain')
    assert.deepEqual(report.dispatch.after.units.filter(u=>u.work===target.id).map(u=>u.id),report.selected,'Trusted command must reach the whole selected cohort')
    report.terminalAcceptance={residents:residents.map(u=>u.id),queue,complete:true}
    await page.screenshot({path:resolve(output,'ordinary-admitted-and-waiting.png')})
    report.summary={maxSubstate5:Math.max(...report.timeline.rows.map(r=>r.people.filter(u=>u.entry?.substate===5&&u.inside===null).length)),maxEntering:Math.max(...report.timeline.rows.map(r=>r.target.entering??0)),maxInside:Math.max(...report.timeline.rows.map(r=>r.target.inside??0)),perPerson:report.selected.map(id=>{const rows=report.timeline.rows;return {id,firstSubstate5:rows.find(r=>r.people.find(u=>u.id===id)?.entry?.substate===5)?.turn,firstInside:rows.find(r=>r.people.find(u=>u.id===id)?.inside===target.id)?.turn,firstQueue:rows.find(r=>[2,3,6].includes(r.people.find(u=>u.id===id)?.entry?.substate))?.turn}})}
    assert.deepEqual(await page.evaluate(()=>window.personClockObservation.read().errors),[]);assert(report.trustedClickOwners.before[0].owners.people.every(u=>Number.isInteger(u.counter)&&u.counter>=0&&u.counter<=255));assert.deepEqual(report.timeline.errors,[]);assert.deepEqual(receipt.errors,[]);assert.deepEqual(report.screencast.errors,[]);assert(report.screencast.frames.length>0);report.status='passed';save();return report
  }catch(error){report.status='failed';report.failure=String(error?.stack??error);throw error}
  finally {
    const successful=report.status==='passed',cleanupErrors=[]
    try{report.arrival=await page.evaluate(()=>window.arrivalObservation.close());writeFileSync(resolve(output,'arrival-calls.json'),JSON.stringify(report.arrival,null,2)+'\n');if(report.arrival.errors.length)cleanupErrors.push(...report.arrival.errors);if(successful){if(!report.arrival.stoppedAfterAllInside)cleanupErrors.push('Four-person arrival boundary not reached');for(const id of [513,300,312,519])for(const name of ['recoverPersonMovement','randomPersonSpeed','random','moveLivePerson','groundVelocity','limitPersonVelocity','terrainPointHeight','stepLiveRoute','stepTrainingPerson','enterBuilding'])if(!report.arrival.events.some(e=>e.kind==='call'&&e.name===name&&e.state.person.id===id))cleanupErrors.push(`Missing actual ${name} for ${id}`)}}catch(e){cleanupErrors.push(String(e))}
    await stopCapture()
    if(report.screencast.errors.length)cleanupErrors.push(...report.screencast.errors)
    if(installed){try{report.timeline=await page.evaluate(()=>window.issue29Observer.close());installed=false}catch(e){report.cleanupError=String(e);cleanupErrors.push(String(e))}}
    if(clockInstalled){try{report.firstObservedPeople=await page.evaluate(()=>{const r=window.personClockObservation.close();delete window.personClockObservation;return r});clockInstalled=false;cleanupErrors.push(...report.firstObservedPeople.errors)}catch(e){report.birthObserverCleanupError=String(e);cleanupErrors.push(String(e))}}
    if(cleanupErrors.length)report.status='failed'
    report.cleanupErrors=cleanupErrors;save()
    if(successful&&cleanupErrors.length)throw Error('Observation cleanup failed: '+cleanupErrors.join('; '))
  }
}
