# Historical 24e ordinary-course arrival observation

One admitted Mission3 UI course, task-owned detached24e checkout. This is not
current main or final blocked PR341. Source product and input helper are unchanged.
The sole private dependencies were moved exclusively; product341 has no live gates.

The original ordinary-course actions, trusted selection/click, pauses, placement
validation on a detached clone, final five-resident/overflow-chain checks and
wall-clock limits are retained. Capture is reduced to12 every-tenth rendered
frames; this observation has no matched-pixel claim. Real RAF timings may differ.
Only people513,300,312,519 are armed, requiring the actual selected Blue Braves,
then preserving their exact Unit object identities. Replacement/removal invalidates
the evidence. Capture ends at their four physical admissions; if one remains an
overflow person, this diagnostic cannot claim the requested local comparison.

A private copied harness installs route interception before initial navigation.
The emitted module body is untouched; assignments appended after it wrap the
named live function bindings. Every original call is forwarded once with original
receiver/arguments/result/throw. Falsy throws and foreign-person nesting have
explicit host tests. Wrappers are restored using exact binding guards. No helper
is evaluated to obtain observer data. Module original/transformed hashes and
source HEAD/hashes are retained. No product source edit or gameplay injection.

Actual random state/result, recovery, turning, motion slope height callbacks,
velocity before/after clamp, collision return/backing bytes, registered route
bytes/index, command8 and physical admission events have a shared ordinal and
call parent. Terrain/collision backing values are labeled as backing, not proof
every branch consumed them. Formation fields are copied only for referenced
membership; no extra formation call or history reconstruction occurs.

Per-person successful coverage requires recover/motion/route/command/admit calls,
all four physical admissions and no observer/runtime/cleanup errors. Analyze
ordered rows only until the first source-local mismatch. If those local laws
agree, earlier RNG/arrival history remains unresolved; native attempt08 lacks
per-call recovery RNG/velocity/route event rows and cannot establish exact
ordinary Mission3 history. It retains before/preCommand/after snapshots only for
that part of the comparison.

Resource admission900MB, runtime stop below600MB,200MB serialization reserve,
400MB intended floor. Event stream capped40,000 rows/48MiB encoded bytes, twelve
frames plus three stills; caps fail the diagnostic without suppressing original
calls or claiming complete evidence. Only own harness is signaled on resource or
540-second outer timeout; harness510 seconds owns its browser/server cleanup.
