import {readFileSync,writeFileSync,statfsSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {installObserver} from './observer.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
export const modules={
 'live-building-entry.ts':['stepBuildingEntry'],
 'live-people.ts':['moveLivePerson'],
 'training.ts':['stepTrainingPerson'],
 'person-state.ts':['recoverPersonMovement','randomPersonSpeed'],
 'native-math.ts':['random','positionDistance'],
 'person-motion.ts':['turnPerson','groundVelocity','positionsOverlap','stepMotionRecovery','recoverGroundObstacle'],
 'person-physics.ts':['limitPersonVelocity'],
 'native-terrain.ts':['terrainPointHeight'],
 'person-collision.ts':['personStepCollision','buildingBlocksPerson'],
 'live-pathfinding.ts':['stepLiveRoute'],
 'route-advance.ts':['advancePersonRoute'],
 'person-routes.ts':['setDirectPersonDestination','releasePersonRoute'],
 'building-occupants.ts':['enterBuilding'],
};
export async function install(page,root,output){
 const expected='24e90cbe86b4f970f04f5b531f9bc1744e896e0b';
 if(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()!==expected)throw Error('Wrong historical source');
 if(execFileSync('git',['status','--porcelain','--untracked-files=no'],{cwd:root,encoding:'utf8'}).trim())throw Error('Historical tracked source changed');
 const f=statfsSync(root);if(f.bavail*f.bsize<750000000)throw Error('Insufficient browser admission storage');
 const bindings={head:expected,files:Object.fromEntries(Object.keys(modules).map(x=>[x,sha(readFileSync(resolve(root,'app',x)))])),responses:[],errors:[]};
 const save=()=>writeFileSync(resolve(output,'module-bindings.json'),JSON.stringify(bindings,null,2)+'\n');save();
 await page.addInitScript(installObserver,Object.values(modules).flat());
 await page.route('**/app/*.ts*',async route=>{
  const name=new URL(route.request().url()).pathname.split('/').at(-1),names=modules[name];if(!names)return route.continue();
  try{
   const response=await route.fetch(),body=await response.text();
   for(const name of names)if(!new RegExp(`(?:export )?function ${name}\\(`).test(body))throw Error(`Missing emitted function ${name}`);
   const appendix='\n'+names.map(name=>`${name} = globalThis.arrivalObservation.wrap(${JSON.stringify(name)}, ${name}, {read:()=>${name},restore:value=>{${name}=value}});`).join('\n')+'\n';
   bindings.responses.push({url:route.request().url(),name,functions:names,originalSha256:sha(body),observedSha256:sha(body+appendix)});save();
   await route.fulfill({response,body:body+appendix});
  }catch(e){bindings.errors.push(String(e));save();await route.abort('failed');}
 });
}
