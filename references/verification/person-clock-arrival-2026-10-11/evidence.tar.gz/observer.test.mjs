import assert from 'node:assert/strict';
import test from 'node:test';
import {installObserver} from './observer.mjs';
function fixture(){
 installObserver();const api=globalThis.arrivalObservation;
 const units=[513,300,312,519].map(id=>({id,team:'blue',kind:'brave',hp:50,personCounter:4,inside:null,native:{id,counter:4,state:10,substate:4,x:10,y:20,motionGroup:0}}));
 const w={turn:1,randomState:7,units,pathfinding:{people:new Map(units.map(u=>[u.id,u.native]))},motionRoutes:{records:new Uint8Array(109)},buildings:[{id:1022,admission:{inside:0,occupants:[0,0,0,0,0,0]}}],marching:[]};
 const wrap=(name,fn)=>{let current;const binding={read:()=>current,restore:x=>{current=x}};current=api.wrap(name,fn,binding);return {invoke:(...a)=>current(...a),current:()=>current,original:fn}};
 return {api,w,units,wrap,arm:()=>api.arm(w,[513,300,312,519],1022,units.map(u=>u.id))};
}
test('original executes once, same arguments receiver result and nested actual RNG order',()=>{
 const {api,w,units,wrap,arm}=fixture();let n=0;const ref={result:1}, receiver={};
 let random=wrap('random',function(rng){assert.equal(this,receiver);assert.equal(rng,w);n++;rng.randomState=123;return ref});
 const recovery=wrap('recoverPersonMovement',function(rng,p){assert.equal(p,units[0].native);return random.current().call(receiver,rng)});
 arm();assert.equal(recovery.invoke(w,units[0].native),ref);assert.equal(n,1);
 const r=api.close();assert.equal(recovery.current(),recovery.original);assert.equal(random.current(),random.original);assert.deepEqual(r.errors,[]);assert.deepEqual(r.events.map(e=>[e.eventOrdinal,e.name,e.kind]),[[0,'recoverPersonMovement','call'],[1,'random','call'],[2,'random','return'],[3,'recoverPersonMovement','return']]);assert.equal(r.events[1].args.rng,7);assert.equal(r.events[2].args.rng,123);
});
test('throw identity retained, no invented return, original restored',()=>{
 const {api,w,units,wrap,arm}=fixture();const e=new Error('original');let n=0;const fn=wrap('moveLivePerson',()=>{n++;throw e});arm();assert.throws(()=>fn.invoke(w,units[0],units[0].native),x=>x===e);const r=api.close();assert.equal(n,1);assert.deepEqual(r.events.map(x=>x.kind),['call','throw']);assert.equal(fn.current(),fn.original);
});
test('unarmed and unrelated calls execute but produce no rows',()=>{const {api,w,units,wrap,arm}=fixture();let n=0;const fn=wrap('moveLivePerson',()=>++n);fn.invoke(w,units[0],units[0].native);arm();fn.invoke(w,{id:999},{id:999});assert.equal(n,2);assert.equal(api.close().events.length,0)});
test('copied snapshots cannot mutate original state',()=>{const {api,w,units,wrap,arm}=fixture();const fn=wrap('moveLivePerson',()=>{});arm();fn.invoke(w,units[0],units[0].native);const r=api.close();r.events[0].state.person.x=999;assert.equal(units[0].native.x,10)});
test('exact four identities required and replacements stop valid evidence without blocking original',()=>{const {api,w,units,wrap,arm}=fixture();assert.throws(()=>api.arm(w,[513,300,312,999],1022,[513,300,312,519]));arm();w.units[0]={...units[0]};let calls=0;wrap('moveLivePerson',()=>calls++).invoke(w,w.units[0],units[0].native);const r=api.close();assert.equal(calls,1);assert.match(r.errors[0],/identity replaced/);assert.equal(r.events.length,0)});
test('observer capacity fails evidence without suppressing calls',()=>{const {api,w,units,wrap,arm}=fixture();let n=0;const fn=wrap('moveLivePerson',()=>++n);arm();for(let i=0;i<20001;i++)fn.invoke(w,units[0],units[0].native);const r=api.close();assert.equal(n,20001);assert.equal(r.events.length,40000);assert.match(r.errors[0],/event limit/)});
test('restoration mismatch fails closed',()=>{const {api,w,units,arm}=fixture();let actual;const fn=()=>1;actual=api.wrap('moveLivePerson',fn,{read:()=>actual,restore:v=>{actual=v}});arm();actual=()=>2;const r=api.close();assert.match(r.errors[0],/binding changed/)});
test('all four physical admissions stop recording only outside original call',()=>{const {api,w,units,wrap,arm}=fixture();let n=0;const fn=wrap('moveLivePerson',()=>{n++;for(const u of units)u.inside=1022});arm();fn.invoke(w,units[0],units[0].native);assert.equal(api.status().armed,false);fn.invoke(w,units[0],units[0].native);const r=api.close();assert.equal(n,2);assert.equal(r.events.length,2);assert.equal(r.stoppedAfterAllInside,true)});
test('falsy throw values are recorded as throws and retained exactly',()=>{for(const value of [undefined,null,0]){const {api,w,units,wrap,arm}=fixture();const fn=wrap('moveLivePerson',()=>{throw value});arm();let caught=false;try{fn.invoke(w,units[0],units[0].native)}catch(e){caught=true;assert.equal(e,value)}assert(caught);assert.equal(api.close().events.at(-1).kind,'throw')}});
test('foreign-person nested RNG is not attributed to selected parent',()=>{const {api,w,units,wrap,arm}=fixture();let n=0;const rng=wrap('random',()=>++n);const foreign=wrap('recoverPersonMovement',()=>rng.invoke(w));const selected=wrap('moveLivePerson',()=>foreign.invoke(w,{id:999}));arm();selected.invoke(w,units[0],units[0].native);const r=api.close();assert.equal(n,1);assert.deepEqual(r.events.map(e=>e.name),['moveLivePerson','moveLivePerson'])});
test('missing required wrapper fails arm',()=>{installObserver(['random']);assert.throws(()=>globalThis.arrivalObservation.arm({},[1,2,3,4],10,[1,2,3,4]),/module bindings/)});
test('replacement inside original callback and between last callback/close invalidates evidence',()=>{for(const during of [true,false]){const {api,w,units,wrap,arm}=fixture();const fn=wrap('moveLivePerson',()=>{if(during)w.units[0]={...units[0]}});arm();fn.invoke(w,units[0],units[0].native);if(!during)w.units[0]={...units[0]};const r=api.close();assert(r.errors.some(e=>/identity/.test(e)))}});
