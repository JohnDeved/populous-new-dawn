import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
const raw=readFileSync('work/arrival-observer/ordinary1/arrival-calls.json'),trace=JSON.parse(raw),rules=JSON.parse(readFileSync('app/original-rules.json'));
const events=trace.events,calls=new Map(),stack=[];const checks=[],firstMismatch=[];
const check=(name,call,ok,detail)=>{const row={name,callId:call.callId,eventOrdinal:call.eventOrdinal,turn:call.turn,id:call.state.person.id,ok,...detail};checks.push(row);if(!ok&&!firstMismatch.length)firstMismatch.push(row)};
const short=n=>(n<<16)>>16;
for(let i=0;i<events.length;i++){
 const e=events[i];assert.equal(e.eventOrdinal,i);
 if(e.kind==='call'){assert.equal(e.parent,stack.at(-1)?.callId??null);calls.set(e.callId,{start:e,children:[]});if(e.parent)calls.get(e.parent).children.push(e.callId);stack.push(e)}
 else {assert.equal(stack.pop()?.callId,e.callId);assert.equal(e.kind,'return','Original call threw');calls.get(e.callId).end=e}
}
assert.equal(stack.length,0);assert.deepEqual(trace.errors,[]);assert(trace.closed);assert(trace.stoppedAfterAllInside);
const children=(c,name)=>c.children.map(id=>calls.get(id)).filter(c=>c.start.name===name);
const descendants=(c,name)=>c.children.flatMap(id=>{const child=calls.get(id);return [...(child.start.name===name?[child]:[]),...descendants(child,name)]});
for(const c of calls.values()){
 if(firstMismatch.length)break;
 const a=c.start,z=c.end,p=a.state.person;
 if(a.name==='random'){
  const n=(Math.imul(a.args.rng,0x24a1)+0x24df)>>>0,expected=((n>>>13)|(n<<19))>>>0;
  check('native RNG rotate/update',a,z.result===expected&&z.args.rng===expected,{before:a.args.rng,expected,actual:z.result});
 }
 if(a.name==='recoverPersonMovement'){
  const draws=descendants(c,'random'),raw=rules.personSpeeds[p.physics],base=short(raw),spread=(base>>2)>>>0;
  const expected=draws.length===1?short((short(base+draws[0].end.result%(spread||1)))*(p.flags3&0x80000?2:1)):null;
  check('native recovery one speed draw',a,draws.length===1&&z.state.person.speed===expected,{physics:p.physics,base,spread,draws:draws.map(x=>({callId:x.start.callId,before:x.start.args.rng,after:x.end.args.rng})),beforeSpeed:p.speed,expected,actual:z.state.person.speed});
 }
 if(a.name==='groundVelocity'&&a.args.speed){
  const heights=children(c,'terrainPointHeight');
  if(heights.length!==2){check('native ground height call count',a,false,{count:heights.length});continue}
  const angle=a.args.angle&2047,expectedAhead={x:short(p.x+((rules.sine[angle]<<5)>>16)),y:short(p.y+((rules.sine[(angle+512)&2047]<<5)>>16))},slope=heights[0].end.result-heights[1].end.result,extra=Math.imul(Math.max(1,Math.min(16,Math.abs(slope)))*16,a.args.speed)>>8,speed=Math.max(3,(a.args.speed+(slope<0?-extra:extra))|0),before=a.args.velocity,expected={x:short(before.x+(Math.imul(rules.sine[angle],speed)>>16)),y:before.y,z:short(before.z+(Math.imul(rules.sine[(angle+512)&2047],speed)>>16))},actual=z.args.velocity;
  check('native slope velocity',a,heights[0].start.args.point.x===p.x&&heights[0].start.args.point.y===p.y&&heights[1].start.args.point.x===expectedAhead.x&&heights[1].start.args.point.y===expectedAhead.y&&Object.entries(expected).every(([k,v])=>actual[k]===v),{heightSamples:heights.map(h=>({point:h.start.args.point,value:h.end.result})),slope,inputSpeed:a.args.speed,effectiveSpeed:speed,expected,actual});
 }
 if(a.name==='limitPersonVelocity'){
  const physics=a.args.physics,[xy,vertical]=a.args.impulse?rules.personImpulseLimits[physics]:[short(rules.personVelocityLimits[physics]),short(rules.personVerticalLimits[physics])],v=a.args.velocity,expected={x:Math.min(xy,Math.max(-xy,v.x)),y:Math.min(vertical,Math.max(-vertical,v.y)),z:Math.min(xy,Math.max(-xy,v.z))};
  check('native velocity clamp',a,Object.entries(expected).every(([k,v])=>z.args.velocity[k]===v),{physics,xy,vertical,expected,actual:z.args.velocity});
 }
 if(a.name==='moveLivePerson'){
  const route=children(c,'stepLiveRoute'),vel=children(c,'limitPersonVelocity'),collision=descendants(c,'personStepCollision');
  check('route after actual motion',a,route.length===1&&(!vel.length||route[0].start.eventOrdinal>vel.at(-1).end.eventOrdinal),{routeCalls:route.map(x=>x.start.eventOrdinal),velocityCalls:vel.map(x=>x.start.eventOrdinal)});
  if(vel.length===1&&collision.length===1&&collision[0].end.result===0){const v=vel[0].end.args.velocity,expected={x:(p.x+v.x)&65535,y:(p.y+v.z)&65535};check('unblocked position uses actual clamped velocity',a,expected.x===z.state.person.x&&expected.y===z.state.person.y,{expected,actual:{x:z.state.person.x,y:z.state.person.y}})}
 }
 if(a.name==='stepBuildingEntry'){
  const motion=children(c,'moveLivePerson'),commands=descendants(c,'stepTrainingPerson');
  for(const command of commands)check('physics and route before command8',command.start,motion.length===1&&motion[0].end.eventOrdinal<command.start.eventOrdinal,{motion:motion.map(x=>[x.start.eventOrdinal,x.end.eventOrdinal]),command:command.start.eventOrdinal});
 }
 if(a.name==='enterBuilding'){
  const dx=Math.abs(short(p.goalX)-short(p.x)),dy=Math.abs(short(p.goalY)-short(p.y)),b=a.state.building,after=z.state.building;
  check('case5 actual admission gate',a,p.substate===5&&!(p.counter&1)&&dx<112&&dy<112&&b.inside<5&&z.result===1&&after.occupants.includes(p.id),{phase:p.counter,dx,dy,beforeInside:b.inside,afterInside:after.inside,slot:after.occupants.indexOf(p.id),position:{x:p.x,y:p.y},goal:{x:p.goalX,y:p.goalY}});
 }
}
const result={status:firstMismatch.length?'local-mismatch':'no-local-mismatch-in-captured-laws',traceSha256:sha(raw),traceBytes:raw.length,observerScope:trace.scope,eventCount:events.length,callCount:calls.size,checks:checks.length,firstMismatch,recoveries:checks.filter(c=>c.name==='native recovery one speed draw'),admissions:checks.filter(c=>c.name==='case5 actual admission gate'),formationReferences:events.filter(e=>e.state.formations.length).length,limits:'Historical24e ordinary replay, not currentmain/final341. Native formulas are retained-source comparisons, not an original Mission3 execution. No claim about uncaptured earlier RNG/formation history, native collision/route equivalence, rendering, or root-cause fix.'};
writeFileSync('work/arrival-observer/local-comparison.json',JSON.stringify(result,null,2)+'\n');writeFileSync('work/arrival-observer/local-checks.json',JSON.stringify(checks,null,2)+'\n');console.log(JSON.stringify(result,null,2));
