from pathlib import Path
import json,hashlib
root=Path('.');old=root/'../person-allocation-clock-20261011/work/person-clock-browser/ordinary1/ordinary-m3.json';new=root/'work/arrival-observer/ordinary1/ordinary-m3.json';trace=root/'work/arrival-observer/ordinary1/arrival-calls.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads(new.read_text());b=json.loads(old.read_text());t=json.loads(trace.read_text());events=t['events'];end={e['callId']:e for e in events if e['kind']=='return'}
def course(r):
 click=r['trustedClickOwners'];before=click['before'][0]['owners']['turn'];after=click['after'][0]['owners']['turn'];assert before==after
 return {'initialTurn':r['initial']['turn'],'builders':r['builders'],'selected':r['selected'],'site':r['site'],'beforePlacementTurn':r['beforePlacement']['turn'],'afterPlacementTurn':r['afterPlacement']['turn'],'completedTurn':r['completed']['turn'],'armTurn':r.get('arrivalArm',{}).get('turn'),'trustedClickTurn':before,'target':r['target'],'summary':r['summary']}
a1,b1=course(a),course(b);assert a1['armTurn']==1069;assert a1['trustedClickTurn']==1077;assert a1['selected']==b1['selected'];assert a1['builders']==b1['builders']
recoveries=[];admissions=[]
for e in events:
 if e['kind']!='call':continue
 if e['name']=='recoverPersonMovement':
  p=e['state']['person'];z=end[e['callId']];draws=[d for d in events if d['kind']=='call' and d['name']=='random' and e['eventOrdinal']<d['eventOrdinal']<z['eventOrdinal']];assert len(draws)==1
  recoveries.append({'eventOrdinal':e['eventOrdinal'],'callId':e['callId'],'turn':e['turn'],'id':p['id'],'state':p['state'],'substate':p['substate'],'speedBefore':p['speed'],'speedAfter':z['state']['person']['speed'],'rngBefore':draws[0]['args']['rng'],'rngAfter':end[draws[0]['callId']]['args']['rng']})
 if e['name']=='enterBuilding':
  p=e['state']['person'];z=end[e['callId']];admissions.append({'eventOrdinal':e['eventOrdinal'],'turn':e['turn'],'id':p['id'],'x':p['x'],'y':p['y'],'goalX':p['goalX'],'goalY':p['goalY'],'counter':p['counter'],'insideBefore':e['state']['building']['inside'],'insideAfter':z['state']['building']['inside'],'slot':z['state']['building']['occupants'].index(p['id'])})
case4=[x for x in recoveries if x['substate']==5];assert [(x['id'],x['speedAfter']) for x in case4]==[(513,80),(312,71),(519,84),(300,86)]
assert [(x['id'],x['turn']) for x in admissions]==[(513,1103),(519,1105),(312,1107),(300,1107)]
r={'status':'extracted; independent review pending','inputs':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [new,old,trace]},'newCourse':a1,'retainedCourse':b1,'recoveries':recoveries,'case4Recoveries':case4,'admissions':admissions,'limits':['Observer arm1069 is not actual trusted click1077. Prior prose saying trusted click1069 is superseded.','Same selected identities but different construction/input/approach history. These RNG rows do not backfill the old pairs.','No observed formation reference; this says nothing about formation or RNG history before observation.','No original Mission3 run or product fix is established.']}
(root/'work/arrival-observer/outcome.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'newClick':a1['trustedClickTurn'],'oldClick':b1['trustedClickTurn'],'case4':case4,'admissions':admissions},indent=2))
