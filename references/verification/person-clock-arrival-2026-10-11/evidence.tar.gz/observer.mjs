// Read-only browser observer. No helper is invoked to construct a snapshot.
export function installObserver(expectedNames = []) {
  const events=[], errors=[], stack=[], wrappers=[], objects=new WeakMap();
  let encodedBytes=0, ordinal=0, calls=0, nextObject=0, world=null, ids=null, owners=null, targetId=null, armed=false, closed=false;
  const identity=o=>{if(!o||typeof o!=='object')return null;if(!objects.has(o))objects.set(o,++nextObject);return objects.get(o)};
  const fields=['id','class','model','tribe','counter','state','substate','speed','physics','x','y','h','heading','angle','turnAngle','turnY','slowTurn','goalX','goalY','destinationX','destinationY','motionGroup','motionIndex','motionTimer','motionMode','recoveryCounter','supportHeight','flags2','flags3','flags4','cargo','commandPhase','commandCursor','assignment','reservationNext','formationCell','workTarget','target','object','draw'];
  const person=p=>p?Object.assign({identity:identity(p)},Object.fromEntries(fields.filter(k=>typeof p[k]==='number').map(k=>[k,p[k]]))):null;
  const scalar=o=>{if(o===undefined)return {undefined:true};if(o===null||['number','boolean','string'].includes(typeof o))return o;return {identity:identity(o),...Object.fromEntries(['x','y','z','h','flags','building','category'].filter(k=>typeof o[k]==='number').map(k=>[k,o[k]]))}};
  const error=e=>{if(errors.length<12)errors.push(String(e?.stack??e))};
  const row=r=>{if(events.length>=40000)throw Error('Arrival observer event limit');const record={eventOrdinal:ordinal,turn:world.turn,...r},bytes=new TextEncoder().encode(JSON.stringify(record)).length;if(encodedBytes+bytes>48*1024*1024)throw Error('Arrival observer byte limit');encodedBytes+=bytes;ordinal++;events.push(record)};
  const unit=p=>world.units.find(u=>u.id===p.id);
  const state=p=>{
    const u=unit(p), registered=world.pathfinding.people.get(p.id), route=registered?.motionGroup, a=route*109, b=world.buildings.find(b=>b.id===targetId), adm=b?.admission;
    return {person:person(p),unit:u&&{identity:identity(u),id:u.id,team:u.team,kind:u.kind,hp:u.hp,counter:u.personCounter,x:u.x,z:u.z,inside:u.inside,work:u.work},aliases:{native:identity(u?.native),entry:identity(u?.entry?.person),registered:identity(registered)},route:registered&&{person:person(registered),record:route?Array.from(world.motionRoutes.records.subarray(a,a+109)):null},building:adm&&{id:b.id,inside:adm.inside,entering:adm.entering,entryDelay:adm.entryDelay,entryTimer:adm.entryTimer,queueHead:adm.queueHead,queueFrom:adm.queueFrom,occupants:[...adm.occupants]},formations:world.marching.filter(g=>g.members.includes(p.id)).map(g=>({identity:identity(g),id:g.id,class:g.class,tribe:g.tribe,members:[...g.members],timer:g.timer,counter:g.counter})),worldRng:world.randomState};
  };
  const ownPerson=(name,args)=>{
    if(name==='moveLivePerson')return args[2];
    if(name==='stepBuildingEntry')return args[1]?.entry?.person;
    if(name==='stepLiveRoute')return args[0]?.pathfinding?.people.get(args[1]?.id);
    if(['stepTrainingPerson','recoverPersonMovement','randomPersonSpeed','setDirectPersonDestination','releasePersonRoute','advancePersonRoute','personStepCollision','buildingBlocksPerson','enterBuilding'].includes(name))return args[1];
    if(['turnPerson','stepMotionRecovery','recoverGroundObstacle','positionsOverlap'].includes(name))return args[0];
    if(name==='groundVelocity')return args[1];
    return null;
  };
  const argsSnapshot=(name,args)=>{
    if(name==='random'||name==='randomPersonSpeed'||name==='recoverPersonMovement')return {rngIdentity:identity(args[0]),rng:args[0].randomState};
    if(name==='groundVelocity')return {velocity:scalar(args[0]),speed:args[2],angle:args[3]};
    if(name==='limitPersonVelocity')return {physics:args[0],velocity:scalar(args[1]),impulse:args[2]??false};
    if(name==='terrainPointHeight')return {point:scalar(args[1])};
    if(name==='positionsOverlap'||name==='positionDistance')return {args:args.map(scalar)};
    if(name==='setDirectPersonDestination')return {destination:scalar(args[2])};
    if(name==='personStepCollision'){
      const to=args[2],cell=((to.y&65535)>>9)*128+((to.x&65535)>>9),bit=((to.y>>>8)&255)*256+((to.x>>>8)&255);
      return {to:scalar(to),backingCell:{index:cell,flags:world.land.flags[cell],building:world.land.buildingIds[cell],category:world.land.categories[cell],walkByte:args[0].walkMask[bit>>3],walkBit:bit&7},note:'Backing bytes copied at real collision entry; branches determine which bytes are consumed.'};
    }
    if(name==='buildingBlocksPerson')return {cell:scalar(args[2])};
    return {};
  };
  const api={
    wrap(name,fn,binding){
      function wrapped(...args){
        if(!armed||closed)return Reflect.apply(fn,this,args);
        let own,p;
        try{own=ownPerson(name,args);p=own??stack.at(-1)?.p}catch(e){error(e);return Reflect.apply(fn,this,args)}
        if(own&&!ids.has(own.id)){stack.push({callId:null,p:null});try{return Reflect.apply(fn,this,args)}finally{stack.pop()}}
        if(!p||!ids.has(p.id))return Reflect.apply(fn,this,args);
        if(unit(p)!==owners.get(p.id)){error(Error('Observed Unit identity replaced'));return Reflect.apply(fn,this,args)}
        const callId=++calls, parent=stack.at(-1)?.callId??null;
        let captured=false;
        try{row({kind:'call',callId,parent,name,args:argsSnapshot(name,args),state:state(p)});captured=true}catch(e){error(e)}
        stack.push({callId,p});
        let value,thrown,didThrow=false;
        try{value=Reflect.apply(fn,this,args);return value}catch(e){didThrow=true;thrown=e;throw e}finally{
          stack.pop();
          if(unit(p)!==owners.get(p.id))error(Error('Observed Unit identity replaced during callback'));
          if(captured)try{row({kind:didThrow?'throw':'return',callId,parent,name,result:didThrow?String(thrown):scalar(value),args:argsSnapshot(name,args),state:state(p)})}catch(e){error(e)}
          if(!stack.length&&ids&&[...ids].every(id=>world.units.find(u=>u.id===id)?.inside===targetId))armed=false;
        }
      }
      wrappers.push({name,original:fn,wrapper:wrapped,binding});return wrapped;
    },
    arm(w,wanted,target,selected){
      if(world||closed)throw Error('Observer cannot be rearmed');
      if(expectedNames.length&&JSON.stringify(wrappers.map(x=>x.name).sort())!==JSON.stringify([...expectedNames].sort()))throw Error('Incomplete or duplicate observed module bindings');
      if(wanted.length!==4||new Set(wanted).size!==4||!wanted.every(id=>selected.includes(id)))throw Error('Historical four-person cohort is absent');
      if(!wanted.every(id=>{const u=w.units.find(u=>u.id===id);return u&&u.team==='blue'&&u.kind==='brave'&&u.hp>0}))throw Error('Historical identities changed');
      world=w;ids=new Set(wanted);owners=new Map(wanted.map(id=>[id,w.units.find(u=>u.id===id)]));targetId=target;armed=true;return {ids:wanted,targetId,turn:w.turn,wrappers:wrappers.map(x=>x.name)};
    },
    status(){return {armed,closed,events:events.length,errors:[...errors]}},
    close(){if(stack.length)throw Error('Observer closed during actual call');armed=false;closed=true;if(world)for(const id of ids)if(world.units.find(u=>u.id===id)!==owners.get(id))error(Error('Observed Unit identity changed before close'));for(const row of wrappers){try{if(row.binding.read()!==row.wrapper)throw Error('Observed binding changed: '+row.name);row.binding.restore(row.original);if(row.binding.read()!==row.original)throw Error('Binding restoration failed: '+row.name)}catch(e){error(e)}}return {schemaVersion:1,encodedBytes,scope:'Historical24e four actual identities, event order only. Original calls/results forwarded exactly once. Zero helper recomputation.',events,errors,ids:ids&&[...ids],targetId,stoppedAfterAllInside:world&&[...ids].every(id=>world.units.find(u=>u.id===id)?.inside===targetId),wrappers:wrappers.map(x=>x.name),closed:true}},
  };
  globalThis.arrivalObservation=api;
}
