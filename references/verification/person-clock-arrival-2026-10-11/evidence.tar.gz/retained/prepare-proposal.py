import json,hashlib,pathlib,subprocess
P=pathlib.Path;src=P('work/person-clock-browser/ordinary1/ordinary-m3.json');x=json.loads(src.read_text());rows=x['timeline']['rows'];ids=[513,300,312,519];out=[]
for id in ids:
 points=[]
 for r in rows:
  if not 1069<=r['turn']<=1099:continue
  u=next(p for p in r['people'] if p['id']==id);e=u.get('entry')
  if not e:continue
  points.append({'turn':r['turn'],'state':e['state'],'substate':e['substate'],'counter':e['counter'],'x':e['x'],'y':e['y'],'speed':e['speed'],'goalX':e['goalX'],'goalY':e['goalY'],'flags3':e['flags3'],'reservationNext':e['reservationNext'],'queueHead':r['target']['queueHead'],'inside':u['inside'],'axisDistance':[abs(e['goalX']-e['x']),abs(e['goalY']-e['y'])]})
 direct=next(p for p in points if p['substate']==5);entry=next(p for p in points if p['inside'] is not None)
 assert all(p['queueHead']==0 and p['reservationNext']==0 and not p['flags3']&32 for p in points)
 out.append({'id':id,'firstState5':direct,'firstAdmission':entry,'rows':points})
# Independent literal coordinate anchors from the raw ordinary1 rows. These
# assertions prevent a different-turn lookup from silently changing the gap.
anchors={(1080,513):(11414,37959),(1080,300):(11390,37821),
         (1082,312):(11414,37944),(1082,519):(11444,37775),
         (1097,513):(11519,39298),(1097,300):(11520,39299),
         (1099,312):(11509,39202),(1099,519):(11510,39193)}
for (turn,id),expected in anchors.items():
 matching=[r for r in rows if r['turn']==turn];assert len(matching)==1
 people=[u for u in matching[0]['people'] if u['id']==id];assert len(people)==1
 e=people[0]['entry'];assert (e['x'],e['y'])==expected,(turn,id,e)
pairs=[]
for a,b in [(513,300),(312,519)]:
 aa=next(p for p in out if p['id']==a);bb=next(p for p in out if p['id']==b);start=max(aa['firstState5']['turn'],bb['firstState5']['turn']);end=aa['firstAdmission']['turn'];assert end==bb['firstAdmission']['turn']
 def at(u,t):return next(p for p in u['rows'] if p['turn']==t)
 pairs.append({'ids':[a,b],'firstSharedState5Turn':start,'initialYGap':at(aa,start)['y']-at(bb,start)['y'],'admissionTurn':end,'finalYGap':at(aa,end)['y']-at(bb,end)['y'],'lastThreeRows':{str(a):[at(aa,t) for t in range(end-2,end+1)],str(b):[at(bb,t) for t in range(end-2,end+1)]}})
paths=['app/training.ts','app/person-state.ts','app/live-building-entry.ts','app/live-people.ts','app/live-pathfinding.ts','app/route-advance.ts','app/person-motion.ts','app/live-movement.ts','app/marching-formations.ts','decomp/generated/00434610.c','decomp/generated/004d4f40.c','decomp/generated/004eadc0.c','decomp/generated/004e93f0.c','decomp/generated/00500a30.c','decomp/generated/004ecac0.c']
manifest=json.loads(P('decomp/exports.json').read_text())
for p in paths:
 if p.startswith('decomp/generated/'):
  assert hashlib.sha256(P(p).read_bytes()).hexdigest()==manifest['files'][P(p).name]
proof={'coordinateAnchors':[{'turn':t,'id':i,'x':xy[0],'y':xy[1]} for (t,i),xy in anchors.items()],'nativeExportsManifestMatched':True,'status':'source-only proposed observation; no new execution admitted','observationHead':'24e90cbe86b4f970f04f5b531f9bc1744e896e0b','currentCodeHead':'7d2bdca419867594f82fc837f5ae2bd2b5adebff','reportSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'people':out,'pairs':pairs,'sourceHashes':{p:hashlib.sha256(P(p).read_bytes()).hexdigest() for p in paths},'limits':['After-turn states prove sampled direct-entry progression; they do not expose every within-turn motion/route callback.','Earlier prose gaps188/212 and second-pair317 were arithmetic errors; the latter mixed different turns. Same-turn extracted gaps are138/169, ending-1/9.','No recorded ordinary RNG state surrounds these four recoveries; observed valid speeds do not prove the complete RNG chronology.','Native controlled eight-person fixture is differently conditioned; it is not an original Mission3 history or counterfactual for these four identities.']}
P('work/person-clock-arrival/retained-four-person-comparison.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(pairs,indent=2))
