# Four-person direct-arrival discriminator (proposal only)

No new simulation, browser or original execution. Product remains blocked. These
observations belong to the frozen24e ordinary UI witness, not the later reader
candidate. Source hashes and exact sampled rows are in
`retained-four-person-comparison.json`.

## What existing data already closes

Both observed pairs traverse command8 states1→4→5, with sampled queueHead=0,
reservationNext=0 and queued flag32 clear throughout. `training.ts:282–337`
contains the queued state3 predecessor/delay policy; it is not read in the
observed direct cases4/5 (`training.ts:338–374`, native434610:355–428).
Neither a missing state3 predecessor delay nor a global one-person semaphore is
established for these pairs.

- 513 enters state5 at1078, speed77;300 at1080, speed84. At the first shared
  state5 snapshot1080 the y gap is138, not188. At1095 their inside-point y
  distances are137/165; at1096 both are within112 (57/77), but phases111/107
  are odd. At1097 phases112/108 allow both actual admissions, ending y gap−1.
- 312 enters state5 at1080, speed71;519 at1082, speed80. Shared state5 begins
 1082 with y gap169. Prior prose317 mistakenly mixed turns1084 and1082;
  the same-turn extracted rows are authoritative. At1098 distances168/187 remain outside112; at1099
  distances94/103 and phases114/116 satisfy both admissions, ending y gap9.

All x distances at the relevant final snapshots also satisfy the strict112-axis
gate. The later entrant is faster in each pair, so direct travel closes the gap.
This describes the recorded motion, not a proof that native Mission3 should have
those same speeds/history.

## Four separable questions

1. **RNG draw and order.** Native4d4f40 and `person-state.ts:66–85` draw one
   speed on case4 recovery. Brave physics2 has base70/spread17, so all four
   observed speeds77/84/71/80 are permitted. No ordinary RNG state is retained
   around these assignments. A known missing formation constructor draw from
   rejected322 cannot be assigned as their cause without an actual call.
2. **Distance metric.** Command8 compares signed per-axis differences strictly
   below112, not Euclidean separation or distance to a predecessor. Current
   source and native434610 agree at that gate. Motion's speed clamp and native
   position-distance calculation are a separate question from the entry gate.
3. **Within-turn route and motion timing.** `live-building-entry.ts:488–514`
   prepares/moves before command8. `live-people.ts:1079–1118` turns, computes
   slope-adjusted velocity/collision, updates position, then calls
   `stepLiveRoute`; `live-pathfinding.ts:375–388` advances actual registered
   route owner. Native4eadc0 and controlled attempt08 have route observations,
   but ordinary1 lacks exact callback sequence/route index/heading/terrain slope.
4. **Parity.** Existing Unit/adapter phases explain which geometric visit admits.
   Distinct bytes do not imply distinct even-parity turns. No extra phase repair
   is suggested by these rows.

## Smallest proposed additional observation

Only if required after source review, replay the same trusted ordinary course on
its declared frozen source and observe the four actual identities (joined by
same cohort lineage if IDs differ). Begin at the trusted training command; end
when both pairs physically occupy slots, or disclose a changed cohort/course.
Do not change commands, positions, phases, seeds or frame scheduling.

Capture these absent fields at real callback boundaries with a shared monotonic
observer ordinal and identity checks:
- Case4 recover entry/return: Unit/adapter identity, retained phase, state/substate,
  physics/model, speed before/after, flags3, cargo, simulation RNG before/after,
  call context, and the exact destination selected by the genuine caller.
- Motion/route/command8 pre/post: position/height, heading/turnAngle/turnY,
  speed, goal, relevant movement flags; route owner identity, group/index and
  referenced current/next route bytes; effective velocity and consumed terrain
  sample values if exposed by the genuine call. Record each call/return once;
  no recomputed or invented native return.
- Admission call: actual slot/capacity/inside/entering, queued flag/head/link,
  state4/5, post-motion position and strict-axis distances, phase, success and
  resulting slot. Queue predecessor fields are conditional on actually entering
  state3; do not manufacture a predecessor for direct state5.
- Formation metadata only when these people actually reference/join a group in
  this window: group identity/member order/timer and observed allocation/draw
  ordinal. Do not instrument or reconstruct unrelated formation history.

The stopping discriminator is the first source-defined local mismatch among
recovery draw, motion/route update order or final gate inputs. If all are locally
consistent, report that the remaining gap is earlier conditioned RNG/arrival
history. Do not compose rejected322, invent spacing, or request full boot.

The retained controlled native eight-person trace can validate the same event
schema and local operation order, with its different initialization/animation
limits kept explicit. It cannot serve as an exact paired ordinary-Mission3 run.
