import json, pathlib, hashlib, math, collections
ROOT=pathlib.Path('/workspace/scratch/69fd8163d94e/person-clock-arrival-24e-20261011')
p=ROOT/'work/arrival-observer/ordinary1/arrival-calls.json'; t=json.loads(p.read_text()); es=t['events']; rules=json.loads((ROOT/'app/original-rules.json').read_text()); stack=[]; calls={}; checks=collections.Counter(); failures=[]
def check(name,ok,e,detail=None):
 checks[name]+=1
 if not ok:failures.append({'check':name,'ordinal':e['eventOrdinal'],'call':e['callId'],'turn':e['turn'],'person':e['state']['person']['id'],'detail':detail})
def short(n):return ((n+32768)&65535)-32768
def s32(n):return ((n+2147483648)&4294967295)-2147483648
def children(c,name):return [calls[n] for n in c['children'] if calls[n]['a']['name']==name]
def descendants(c,name):
 out=[]
 for n in c['children']:
  d=calls[n]
  if d['a']['name']==name:out.append(d)
  out.extend(descendants(d,name))
 return out
for n,e in enumerate(es):
 assert n==e['eventOrdinal'];assert e['state']['person']['id'] in [513,300,312,519]
 if e['kind']=='call':
  assert e['parent']==(stack[-1] if stack else None)
  assert e['callId'] not in calls
  calls[e['callId']]={'a':e,'children':[]}
  if stack:calls[stack[-1]]['children'].append(e['callId'])
  stack.append(e['callId'])
 else:
  assert e['kind']=='return';assert stack.pop()==e['callId'];calls[e['callId']]['z']=e
assert not stack
recoveries=[]; admissions=[]; speeds=[]
for c in calls.values():
 a,z=c['a'],c['z'];p0,p1=a['state']['person'],z['state']['person'];name=a['name']
 if name=='random':
  n=(a['args']['rng']*0x24a1+0x24df)&0xffffffff; v=((n>>13)|(n<<19))&0xffffffff
  check('RNG transform',z['args']['rng']==v==z['result'],a)
 if name=='recoverPersonMovement':
  ds=descendants(c,'random');base=short(rules['personSpeeds'][p0['physics']]);spread=(base>>2)&0xffffffff
  expect=short(short(base+ds[0]['z']['result']%(spread or 1))*(2 if p0['flags3']&0x80000 else 1)) if len(ds)==1 else None
  check('One recovery draw and speed',len(ds)==1 and expect==p1['speed'],a)
  recoveries.append({'id':p0['id'],'turn':a['turn'],'counter':p0['counter'],'substate':p0['substate'],'speedBefore':p0['speed'],'speedAfter':p1['speed'],'rngBefore':a['args']['rng'],'rngAfter':z['args']['rng'],'draws':len(ds)})
 if name=='groundVelocity' and a['args']['speed']:
  hs=children(c,'terrainPointHeight');check('Two actual slope samples',len(hs)==2,a)
  if len(hs)==2:
   angle=a['args']['angle']&2047; sn=rules['sine'][angle];cs=rules['sine'][(angle+512)&2047];point=hs[0]['a']['args']['point'];nextp=hs[1]['a']['args']['point'];slope=hs[0]['z']['result']-hs[1]['z']['result'];v=a['args']['velocity'];sp=a['args']['speed'];extra=s32(max(1,min(16,abs(slope)))*16*sp)>>8;effective=max(3,s32(sp+(-extra if slope<0 else extra)));expected={'x':short(v['x']+(s32(sn*effective)>>16)),'y':v['y'],'z':short(v['z']+(s32(cs*effective)>>16))};got=z['args']['velocity']
   check('Native slope sample coordinates',point['x']==p0['x'] and point['y']==p0['y'] and nextp['x']==short(p0['x']+(s32(sn<<5)>>16)) and nextp['y']==short(p0['y']+(s32(cs<<5)>>16)),a)
   check('Native slope velocity formula',all(got[k]==v for k,v in expected.items()),a,{'expected':expected,'got':got})
 if name=='limitPersonVelocity':
  xy,vertical=rules['personImpulseLimits'][a['args']['physics']] if a['args']['impulse'] else (short(rules['personVelocityLimits'][a['args']['physics']]),short(rules['personVerticalLimits'][a['args']['physics']]))
  v=a['args']['velocity']; expected={'x':max(-xy,min(xy,v['x'])),'y':max(-vertical,min(vertical,v['y'])),'z':max(-xy,min(xy,v['z']))};check('Velocity cap',all(z['args']['velocity'][k]==v for k,v in expected.items()),a)
 if name=='moveLivePerson':
  route=children(c,'stepLiveRoute');vel=children(c,'limitPersonVelocity');col=children(c,'personStepCollision')
  check('One route callback after movement',len(route)==1 and (not vel or route[0]['a']['eventOrdinal']>vel[-1]['z']['eventOrdinal']),a)
  if len(vel)==1 and len(col)==1 and col[0]['z']['result']==0:
   v=vel[0]['z']['args']['velocity'];check('Unblocked displacement',p1['x']==(p0['x']+v['x'])&65535 and p1['y']==(p0['y']+v['z'])&65535,a)
 if name=='stepBuildingEntry':
  mv=children(c,'moveLivePerson');cmd=descendants(c,'stepTrainingPerson')
  check('One command after one motion',len(mv)==1 and len(cmd)==1 and mv[0]['z']['eventOrdinal']<cmd[0]['a']['eventOrdinal'],a)
 if name=='stepTrainingPerson' and p0['substate']==4:
  ds=children(c,'recoverPersonMovement');direct=children(c,'setDirectPersonDestination')
  check('Case4 recovery then direct destination',len(ds)==1 and len(direct)==1 and ds[0]['z']['eventOrdinal']<direct[0]['a']['eventOrdinal'],a)
 if name=='setDirectPersonDestination':
  d=a['args']['destination'];check('Direct route release and copied destinations',p1['motionGroup']==0 and all(p1[k]==d['x']&65535 for k in ['goalX','destinationX','turnAngle']) and all(p1[k]==d['y']&65535 for k in ['goalY','destinationY','turnY']) and p1['flags2']==(p0['flags2']&~128)|0x1000,a)
 if name=='enterBuilding':
  b=a['state']['building'];q=z['state']['building'];dx=abs(short(p0['goalX'])-short(p0['x']));dy=abs(short(p0['goalY'])-short(p0['y']));check('Physical admission gate',p0['substate']==5 and p0['counter']%2==0 and dx<112 and dy<112 and b['inside']<5 and z['result']==1 and p0['id'] in q['occupants'] and q['inside']==b['inside']+1,a);admissions.append({'turn':a['turn'],'id':p0['id'],'counter':p0['counter'],'distances':[dx,dy],'position':[p0['x'],p0['y']],'slot':q['occupants'].index(p0['id']),'insideBefore':b['inside'],'insideAfter':q['inside'],'queueHead':b['queueHead'],'queued':bool(p0['flags3']&32)})
report=json.loads((ROOT/'work/arrival-observer/ordinary1/ordinary-m3.json').read_text())
out={'verdict':'VALID_HISTORICAL_OBSERVATION_CHANGED_INPUT_TIMING' if not failures else 'REVIEW_LOCAL_MISMATCH','traceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'eventCount':len(es),'callCount':len(calls),'turnRange':[min(e['turn'] for e in es),max(e['turn'] for e in es)],'errors':t['errors'],'armTurn':report['arrivalArm']['turn'],'trustedClickTurn':report['trustedClickOwners']['before'][0]['owners']['turn'],'checks':dict(checks),'failures':failures,'recoveries':recoveries,'admissions':admissions,'formationReferenceRows':sum(bool(e['state']['formations']) for e in es),'summary':report['summary'],'limits':['Source-law arithmetic over actual recorded inputs only; no gameplay or native execution.','Observed trusted click1077 differs from retained ordinary1 click1069, so original two pairs and speed history were not reproduced.','Local ground slope/speed/cap and command ordering only: no exhaustive route solver/collision or original ordinary RNG history equivalence.','Native controlled attempt08 supplies state boundaries, not exact ordinary history. Product341 remains HOLD.']}
p=pathlib.Path('work/review-person-clock-fix-20261011/arrival-trace-review.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
