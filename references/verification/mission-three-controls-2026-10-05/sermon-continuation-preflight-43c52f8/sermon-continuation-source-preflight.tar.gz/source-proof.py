import pathlib,json,hashlib,subprocess
root=pathlib.Path.cwd();out=root/'work/orchestration/mission-three-sermon-continuation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode().strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
base='81dab9e1ac74fd4aa3879d629758edbd388cfd7f';runtime='b3818511da0b420129b03092f397ad76bc6111a8';built='6b6eb684f4f010420a758cfe4fd481b6dfca9545'
changes=git('diff','--name-only',base,'HEAD').splitlines();assert changes and all(p.startswith('qa/mission-three-controls/') for p in changes)
guards=[]
for entry in json.loads((root/'qa/mission-three-controls/source-manifest.json').read_text())['files']:
 local=sha(root/entry['path']);accepted=hashlib.sha256(subprocess.check_output(['git','show',runtime+':'+entry['path']])).hexdigest();assert local==entry['sha256']==accepted;guards.append({**entry,'actual':local,'accepted':accepted})
production=[]
for path in ['app','public','worker','build','package.json','package-lock.json','tsconfig.json','next-env.d.ts','next.config.ts','vite.config.ts','postcss.config.mjs','wrangler.cloudflare.jsonc','.openai/hosting.json']:
 current=git('rev-parse','HEAD:'+path);tested=git('rev-parse',built+':'+path);assert current==tested;production.append({'path':path,'current':current,'tested':tested})
harness=[]
for name in ['harness.mjs','owned-profile.mjs','checkpoint-observer.mjs','vite.config.mjs']:
 path='scripts/local-render/'+name;current=git('rev-parse','HEAD:'+path);previous=git('rev-parse',base+':'+path);assert current==previous;harness.append({'path':path,'current':current,'previous':previous})
p=out/'run14-observations';manifest=json.loads((p/'inventory.json').read_text())
for e in manifest['files']:assert sha(p/e['path'])==e['sha256']
saved=json.loads((p/'sermon-saved.json').read_text());late=json.loads((p/'batch-0048-failed.json').read_text());first=saved['observation']['sermon']['firstOwned'];assert saved['turn']==4813 and first['turnBefore']==4777 and first['turnAfter']==4778 and first['victim']['id']==50
journal=[json.loads(l) for l in (p/'actions.jsonl').read_text().splitlines()];saves=[e for e in journal if e['action']=='checkpoint-persisted'];assert len(saves)==1 and saves[0]['turn']==4813
report={'status':'passed','head':head,'base':base,'acceptedApplication':runtime,'changedPaths':changes,'guards':guards,'productionBuildSource':built,'productionObjects':production,'unchangedHarness':harness,'retainedRun14':{'inventorySha256':sha(p/'inventory.json'),'savedTurn':saved['turn'],'firstOwned':first,'cancellationFailureTurn':late['turn'],'lastObservedUISave':saves[0],'innerTerminalReceipt':'absent in retained interruption observation','limits':'No full saved checkpoint digest or verified profile cleanup from Run14; no retroactive cancellation milestone or storage restoration.'},'limits':'Source/Node preflight only in isolated worktree. No profile/browser/package/build access or runtime repair acceptance.'}
f=out/f'source-proof-{head[:7]}.json';f.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'head':head,'guards':len(guards),'productionObjects':len(production),'harnessFiles':len(harness),'retainedSave':saved['turn'],'output':str(f.relative_to(root))}))
