// Offline source-derived geometry only. No browser/profile, World creation, ticks or commands.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root = process.cwd(), base = path.join(root, 'work/orchestration/mission-three-controls');
const load = rel => import(path.join(root, rel));
const [{default:level}, {default:rules}, terrain, shapes, spell, math, starts] = await Promise.all([
  load('app/level-three.ts'), load('app/original-rules.json').catch(() => ({default:JSON.parse(fs.readFileSync(path.join(root,'app/original-rules.json')))})),
  load('app/world-terrain-runtime.ts'), load('app/building-shapes.ts'), load('app/spell-casting.ts'),
  load('app/native-math.ts'), load('app/level-start.ts'),
]);
const {terrainPointHeight} = await load('app/native-terrain.ts');
const sha = raw => createHash('sha256').update(raw).digest('hex');
const snapPath = process.argv[2] ?? path.join(base, 'browser-12/batch-0045-failed.json');
const snap = JSON.parse(fs.readFileSync(snapPath)), caster=snap.units.find(u=>u.id===46), target=snap.units.find(u=>u.id===47);
assert(caster && target && caster.inside===null);
const native=p=>({x:math.short(Math.round((p.x+8)*256)),y:math.short(Math.round((-p.z-8)*256))});
const n=native(caster), t=native(target), cell=((n.y&65535)>>>9)*128+((n.x&65535)>>>9);
const corners=i=>[i,(i+128)&16383,(((i+128)&16383)&~127)|((i+1)&127),(i&~127)|((i+1)&127)];
const cornerIds=corners(cell), land=terrain.createMissionLand(level);
const histories=new Map(), inputFiles=[];
for(const [directory,maxTurn] of [['browser-06',2909],['browser-12',snap.turn]])
  for(const name of fs.readdirSync(path.join(base,directory)).filter(n=>n.endsWith('.json'))){
    const file=path.join(base,directory,name), raw=fs.readFileSync(file);let s;try{s=JSON.parse(raw);}catch{continue;}
    if(!Array.isArray(s.buildings)||!Array.isArray(s.units)||!(s.turn<=maxTurn))continue;
    inputFiles.push({path:path.relative(root,file),sha256:sha(raw),turn:s.turn});
    for(const b of s.buildings) histories.set(JSON.stringify([b.id,b.kind,b.team,b.x,b.z,b.progress<1]),b);
  }
const geometry=[];
for(const b of histories.values()){
  const tribe=b.team==='blue'?0:2;
  const objects=[];
  if(b.kind==='hut')for(let model=1;model<=3;model++)for(let family=0;family<3;family++)objects.push(rules.buildingObjects[model]+family*12+tribe*3);
  else objects.push(rules.buildingObjects[shapes.buildingModel({...b,level:1})]+tribe);
  if(b.progress<1) objects.push(rules.buildingObjects[shapes.buildingModel({...b,level:1})]);
  const display=native(b), found=[];
  for(const object of new Set(objects))for(const angle of[0,512,1024,1536]){
    const zero=shapes.buildingPosition({object,angle,anchorX:0,anchorY:0});
    const pose={object,angle,anchorX:(display.x-zero.x)&65535,anchorY:(display.y-zero.y)&65535};
    if(pose.anchorX%512||pose.anchorY%512)continue;
    const back=shapes.buildingPosition(pose);
    if(back.x!==(display.x&65535)||back.y!==(display.y&65535))continue;
    // Include both grading vertices and every corner lowered/levelled for the footprint.
    const touched=new Set([...shapes.buildingGradeVertices(pose).map(c=>c.index),...shapes.buildingFootprintCells(pose).flatMap(corners)]);
    found.push({...pose,touchedCasterCorners:cornerIds.filter(i=>touched.has(i))});
  }
  assert(found.length,`No source-compatible pose for observed building${b.id}`);
  assert(found.every(p=>!p.touchedCasterCorners.length),`A building can grade the caster cell: ${b.id}`);
  geometry.push({id:b.id,kind:b.kind,x:b.x,z:b.z,underConstruction:b.progress<1,compatiblePoses:found});
}
const startup=level.objects.filter(o=>o.type===1&&o.model===7).map(o=>{
  const p=native(o),center={x:(p.x&0xfe00)+256,y:(p.y&0xfe00)+256,h:0};
  const cells=starts.levelStartCells(center).map(c=>(c>>>9)*128+((c&254)>>>1));
  const touched=cornerIds.filter(i=>cells.includes(i));assert(!touched.length,'Opening wave can touch caster cell');
  return{tribe:o.owner,center,touchedCasterCorners:touched};
});
const height=terrainPointHeight(land,n), range=spell.nativeSpellRange(0,0,{height,flags2:0,building:null},2), distance=math.positionDistance(n,t);
assert(snap.stats.cast===0 && snap.shrines.find(s=>s.kind==='erosionEffect').uses===0);
assert(distance>range);
const sources=['app/level-three.ts','app/original-rules.json','app/original-shapes.json','app/building-shapes.ts','app/construction-runtime.ts','app/world-terrain-runtime.ts','app/native-terrain.ts','app/native-math.ts','app/level-start.ts','app/level-start-runtime.ts','app/spell-casting.ts','app/live-command.ts','app/world-state.ts','app/campaign-command-runtime.ts','qa/mission-three-controls/driver.mjs'];
console.log(JSON.stringify({scope:'Offline source derivation from retained coordinates and untouched local terrain; not a new gameplay observation or a recovered failed pick.',snapshot:path.relative(root,snapPath),snapshotSha256:sha(fs.readFileSync(snapPath)),turn:snap.turn,caster:{id:caster.id,point:{x:caster.x,z:caster.z},native:n},target:{id:target.id,point:{x:target.x,z:target.z},native:t},terrain:{cell,corners:cornerIds.map(index=>({index,height:land.heights[index]})),diagonal:land.flags[cell]&1,height,startup,geometry},range:{heightBand:Math.floor(height/128),native:range,world:range/256,distanceNative:distance,distanceWorld:distance/256,marginWorld:(range-distance)/256,requestedPointInRange:false},sourceConditions:['Source initializes normal game mode, no alternate-range bit32 writer is used by these ordinary inputs.','Blue casting starts without unlimited-range bit0x80000; observed inputs and campaign flag writes do not set it.','Caster is outside a building, so no tower range bonus.','All compatible retained building grading/footprint corners and both authored opening-wave cells miss the four caster terrain vertices. Positive corner heights exclude the zero-to-one terrain repair.','No Blue spell was cast; Erosion shrine remains unused. Mission3 computer spell producers here are Blast, Lightning, Convert Wild or configured Swarm, with no terrain-height writer.','The source-derived terrain triangle uses only these unchanged four corner heights; compatibility terrain resynchronization cannot write this out-of-crop z=-105 cell.'],unknown:['The failed helper does not log the actual picked point, renderer ownership result, pick distance or spellTargetError code. The first failed predicate remains unknown.','A picked point may differ from the requested point by up to1.5world units before the helper rejects it; no actual sampled point was retained. Range shortfall at the requested point is established, not the first executed rejection.'],reuseContract:'At a future paused boundary use actual current caster/target coordinates and complete retained building history. Derive native height only if startup/building/effect terrain-writer checks still pass; otherwise the unchanged snapshot interface lacks exact live terrain and must not invent a range. Require derived range minus actual native distance>=2world units, preferably a planned3-unit margin for arrival drift; then ordinary spell validation remains mandatory.',inputFiles,sources:sources.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(root,p)))}))},null,2));
