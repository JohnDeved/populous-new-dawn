import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { resolve, dirname } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'
const root = process.cwd(), out = resolve(root, 'work/orchestration/mission-three-controls')
const { sourceReceipt } = await import(pathToFileURL(resolve(root, 'scripts/local-render/harness.mjs')))
const { profileInputReceipt, sha256 } = await import(pathToFileURL(resolve(root, 'scripts/local-render/owned-profile.mjs')))
const read = path => JSON.parse(readFileSync(path)), git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim()
const source = sourceReceipt(root), inputs = profileInputReceipt(root, resolve(root, 'qa/mission-three-controls/driver.mjs'))
assert.equal(source.status, ''); assert.deepEqual(source.untracked, [])
const priorPath = resolve(out, 'browser-13/receipt.json'), prior = read(priorPath)
const preparationPath = resolve(out, 'browser-13/preparation-record.json'), preparation = read(preparationPath)
const markerPath = resolve(root, 'work/local-render-profiles/mission-three-controls/populous-profile.json'), marker = read(markerPath)
assert.equal(inputs.application, prior.profile.inputs.application)
assert.deepEqual(prior.source, prior.sourceAfter); assert.deepEqual(prior.runtime, prior.runtimeAfter)
assert.deepEqual(prior.scenario, prior.scenarioAfter)
assert.equal(prior.profile.cleanupVerified, true); assert.equal(prior.profile.continuationVerified, true)
assert.equal(marker.lastRun.receiptSha256, sha256(readFileSync(priorPath)))
assert.equal(marker.lastRun.runId, prior.profile.runId)
assert.equal(preparation.qaAdmission.recordedByRunId, marker.lastRun.runId)
assert.deepEqual(marker.lastRun.checkpointAtEnd, prior.profile.checkpointAtEnd)
assert.equal(preparation.checkpoint.sha256, marker.lastRun.checkpointAtEnd.checkpointSha256)
assert.equal(preparation.checkpoint.sha256, '5695417cfe5ba1ae554477635cafbf66360a6696871473cc7ce3e577e2c0bd7a')
assert.equal(existsSync(resolve(dirname(markerPath), 'owner.lock')), false)
const require = createRequire(resolve(root, 'package.json'))
const runtime = { node: process.version, platform: process.platform, arch: process.arch,
  browserPath: prior.runtime.browserPath, browserSha256: sha256(readFileSync(prior.runtime.browserPath)),
  playwright: require('@playwright/test/package.json').version,
  playwrightCoreSha256: sha256(readFileSync(resolve(dirname(require.resolve('playwright-core/package.json')), 'lib/coreBundle.js'))),
  installedLockSha256: sha256(readFileSync(resolve(root, 'node_modules/.package-lock.json'))),
  harness: Object.fromEntries(Object.keys(prior.runtime.harness).map(name => [name, sha256(readFileSync(resolve(root, 'scripts/local-render', name)))])) }
assert.deepEqual(runtime, prior.runtime); assert.deepEqual(runtime, marker.binding.runtime)
const acceptedRuntime = 'b3818511da0b420129b03092f397ad76bc6111a8'
const guards = read(resolve(root, 'qa/mission-three-controls/source-manifest.json')).files.map(entry => {
  const local = sha256(readFileSync(resolve(root, entry.path)))
  const accepted = sha256(execFileSync('git', ['show', `${acceptedRuntime}:${entry.path}`]))
  assert.equal(local, entry.sha256); assert.equal(accepted, entry.sha256)
  return { ...entry, local, accepted }
})
const buildSource = '6b6eb684f4f010420a758cfe4fd481b6dfca9545'
const production = read(resolve(out, 'replay-four-correspondence-2f5869b.json')).productionObjects.map(entry => {
  const current = git('rev-parse', `HEAD:${entry.path}`), tested = git('rev-parse', `${buildSource}:${entry.path}`)
  assert.equal(current, tested); assert.equal(tested, entry.testedObject)
  return { path: entry.path, current, tested }
})
const buildPath = resolve(out, 'build-carry-6b6eb68/build.json'), build = read(buildPath)
assert.equal(build.status, 'passed'); assert.equal(sha256(readFileSync(buildPath)), '6ddc4bf5ab3124d9504440d465834700503c662283b7611764dc4b84866e1033')
const streams = ['stdout', 'stderr'].map(name => {
  const actual = sha256(readFileSync(resolve(out, `build-carry-6b6eb68/${name}.log`)))
  const expected = read(resolve(out, 'replay-four-correspondence-2f5869b.json')).streams.find(s => s.name === name).expected
  assert.equal(actual, expected); return { name, sha256: actual }
})
const suffix = source.commit.slice(0, 7)
const proposed = { priorRunId: marker.lastRun.runId, previousSourceFingerprint: prior.source.fingerprint,
  currentSourceFingerprint: source.fingerprint, previousChecker: prior.profile.inputs.checker,
  currentChecker: inputs.checker, decision: 'PENDING_REVIEW', reviewer: '/root/finish_reviewed_pr_batch/review_early_sermon_capture',
  reference: `Pending independent early-sermon capture and second QA admission review at ${source.commit}`,
  provenance: { priorReceiptSha256: sha256(readFileSync(priorPath)),
    forwardedPreparationSha256: sha256(readFileSync(preparationPath)),
    originalPreparationSha256: sha256(readFileSync(resolve(out, 'browser-06/preparation-record.json'))),
    originalSourceFingerprint: preparation.source.fingerprint, checkpointSha256: preparation.checkpoint.sha256,
    firstAdmissionSha256: sha256(JSON.stringify(preparation.qaAdmission)),
    firstCorrespondenceSha256: preparation.qaAdmission.correspondence.sha256 } }
const facts = { status: 'passed', head: source.commit, acceptedRuntime, source, inputs, runtime,
  priorReceipt: { path: priorPath, sha256: sha256(readFileSync(priorPath)) },
  preparation: { path: preparationPath, sha256: sha256(readFileSync(preparationPath)), originalSource: preparation.source,
    firstAdmission: preparation.qaAdmission, checkpoint: preparation.checkpoint },
  profile: { id: marker.id, origin: marker.binding.origin, previousRun: marker.lastRun, ownerLockAbsent: true },
  guards, production, buildCarry: { source: buildSource, receiptSha256: sha256(readFileSync(buildPath)), streams },
  limits: 'Read-only source/provenance equality. No profile lease, browser, storage read/write, game action or runtime acceptance. Second QA correspondence remains independently pending.' }
writeFileSync(resolve(out, `staging-source-facts-${suffix}.json`), JSON.stringify(facts, null, 2) + '\n')
writeFileSync(resolve(out, `profile-correspondence-${suffix}-proposed.json`), JSON.stringify(proposed, null, 2) + '\n')
console.log(JSON.stringify({ head: source.commit, sourceFingerprint: source.fingerprint, inputs, guards: guards.length,
  productionObjects: production.length, priorRunId: marker.lastRun.runId, checkpoint: preparation.checkpoint.sha256,
  facts: `staging-source-facts-${suffix}.json`, proposed: `profile-correspondence-${suffix}-proposed.json` }))
