"""Exact admission delta and synthetic fail-closed regressions; no canonical run."""
import ast,hashlib,json,unittest
from pathlib import Path
import capstone,unicorn
import constructor_ledger_tail_candidate as l
import constructor_ledger_alternator_candidate as old

b=l.b;START=0x4fc790;END=0x4fc849;DATA=0x200000;STACK=0x300800;STOP=0x300f00

class TailWindowTests(unittest.TestCase):
 def make(self,raw,known=True):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for address in [START&~4095,DATA,STACK&~4095]:c.mem_map(address,4096)
  c.mem_write(START,raw)
  e=l.Ledger(c,[(START&~4095,4096),(DATA,4096),(STACK&~4095,4096)],l.ranges(),protected_inputs=[])
  for reg,value in [('esp',STACK),('ecx',DATA),('eax',0x12345678)]:e.reg_supply(reg,value,b.MASK32,'authored synthetic input')
  e.supply(STACK,l.pack(STOP),'synthetic sentinel')
  c.mem_write(DATA,l.pack(7))
  if known:e.supply(DATA,l.pack(7),'synthetic known value')
  return e
 def test_exact185byte_allowlist_delta_and_end_exclusion(self):
  self.assertEqual(set(l.ranges())-set(old.ranges()),{(START,END)})
  self.assertEqual(set(old.ranges())-set(l.ranges()),set())
  self.assertEqual(END-START,185)
  self.assertTrue(all(not any(a<=pc<z for a,z in l.ranges()) for pc in [START-1,END,END+1]))
 def test_every_runtime_method_and_function_except_preparation_ranges_is_identical(self):
  def defs(module):
   t=ast.parse(Path(module.__file__).read_text());return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  before,after=defs(old),defs(l)
  self.assertEqual(set(before),set(after))
  for name in before:
   if name not in ['prepare','ranges']:self.assertEqual(before[name],after[name],name)
 def test_all_entry_conditions_resource_constants_and_guards_unchanged(self):
  for case in ['land-clear','land-set']:self.assertEqual(l.entry_conditions(case),old.entry_conditions(case))
  for name in ['TEXTURE_CONTEXTS','ADDITIONAL_TEXTURE_CONTEXTS','STAT_INCREMENTS','TRACE_LIMIT','FINAL_JSON_LIMIT','FINAL_COMPRESSED_LIMIT','OTHER_OUTPUT_ALLOWANCE','SPACE_MARGIN','REQUIRED_FREE','ENTRY','NEXT','FINAL','SETUP_WINDOWS','BOUND_FILES','TREE_START','TREE_END','TEXTURE_START','TEXTURE_END']:
   self.assertEqual(getattr(l,name),getattr(old,name),name)
 def test_source_bound_capability_scan_has_only_existing_operand_families(self):
  self.assertEqual(hashlib.sha256(l.TAIL_SOURCE.read_bytes()).hexdigest(),l.TAIL_SOURCE_SHA)
  packet=json.loads(l.TAIL_SOURCE.read_text());self.assertEqual(len(packet['remainingRootResiduals']),7)
  cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
  ii=list(cs.disasm(b.load_pe().read(START,END-START),START));self.assertEqual(sum(i.size for i in ii),185)
  old_forms={(i.mnemonic,tuple((o.type,o.size) for o in i.operands),tuple(i.prefix)) for a,z in old.ranges() for i in cs.disasm(b.load_pe().read(a,z-a),a)}
  for i in ii:self.assertIn((i.mnemonic,tuple((o.type,o.size) for o in i.operands),tuple(i.prefix)),old_forms)
  self.assertEqual([i.operands[0].imm for i in ii if i.mnemonic=='call'],[0x404540,0x4b9fc0,0x4044b0])
 def test_new_window_runs_only_authored_synthetic_code_and_retains_unknown_guard(self):
  for known in [False,True]:
   e=self.make(bytes.fromhex('8b0185c07400c3'),known)
   if known:e.run(START,STOP);self.assertEqual(e.reg_value('eax'),7)
   else:
    with self.assertRaises(b.Blocked):e.run(START,STOP)
    self.assertEqual(e.committed,2);self.assertEqual(e.shadow.reg_get('eax'),0)
   self.assertEqual(e.read_events[0]['knownMask'],'0xffffffff' if known else '0x0')
 def test_adjacent_target_still_rejects_before_instruction(self):
  e=self.make(b'\xc3');e.cpu.mem_write(END,b'\xc3')
  with self.assertRaisesRegex(b.Blocked,'outside exact approved'):e.run(END,STOP)
  self.assertEqual(e.committed,0);self.assertFalse(e.read_events);self.assertFalse(e.write_events)
 def test_protected_data_store_in_new_window_keeps_fault_rollback(self):
  e=self.make(bytes.fromhex('8901c3'));before=bytes(e.cpu.mem_read(DATA,4));mask=e.shadow.get(DATA,4)
  e.cpu.mem_protect(DATA,4096,unicorn.UC_PROT_READ)
  with self.assertRaises(b.Blocked):e.run(START,STOP)
  self.assertEqual(e.committed,0);self.assertFalse(e.write_events);self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),before);self.assertEqual(e.shadow.get(DATA,4),mask)

if __name__=='__main__':unittest.main()
