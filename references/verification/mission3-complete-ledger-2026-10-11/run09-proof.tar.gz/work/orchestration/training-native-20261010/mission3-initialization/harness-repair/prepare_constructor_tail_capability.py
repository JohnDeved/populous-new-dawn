#!/usr/bin/env python3
"""Read-only exact operand-form extension to the retained91-window audit."""
from pathlib import Path
import json
import capstone
import constructor_ledger_tail_candidate as new
import constructor_ledger_alternator_candidate as old

def main():
 b=new.b;pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
 def form(i):return (i.mnemonic,tuple((o.type,o.size) for o in i.operands),tuple(i.prefix))
 old_rows={i.address:i for a,z in old.ranges() for i in cs.disasm(pe.read(a,z-a),a)}
 old_forms={form(i) for i in old_rows.values()}
 added=sorted(set(new.ranges())-set(old.ranges()));assert added==[(0x4fc790,0x4fc849)]
 ii=list(cs.disasm(pe.read(0x4fc790,185),0x4fc790));assert sum(i.size for i in ii)==185
 rows=[]
 for i in ii:
  assert form(i) in old_forms
  rows.append({'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str,'prefixes':list(i.prefix),'operandForms':[{'type':o.type,'size':o.size} for o in i.operands],'sameFormPriorPc':hex(next(j.address for j in old_rows.values() if form(j)==form(i))),'status':'existing supported form; runtime provenance and native-fault guards remain mandatory'})
 out={'status':'SOURCE_ONLY_CAPABILITY_EXTENSION_PASS','script':b.file_record(Path(__file__)),'driver':b.file_record(Path(new.__file__)),'frozenPriorDriver':b.file_record(Path(old.__file__)),'previousFiniteAudit':b.file_record(new.CAPABILITY_AUDIT),'newSourceBoundary':b.file_record(new.TAIL_SOURCE),'originalInstructionsExecuted':0,'priorWindowCount':len(old.ranges()),'newWindowCount':len(new.ranges()),'priorInstructions':len(old_rows),'newInstructions':len(ii),'combinedUniqueInstructions':len(set(old_rows)|{i.address for i in ii}),'addedWindow':{'start':'0x4fc790','endExclusive':'0x4fc849','bytes':185,'sha256':b.sha(pe.read(0x4fc790,185))},'instructions':rows,'limits':'This extends operand-form coverage only. It does not prove all paths finish, all inputs are known, or already-admitted callees have recursively closed execution.'}
 p=new.HERE/'constructor-tail-capability01.json';b.json_write(p,out);print(json.dumps({'path':str(p),'sha256':b.sha(p.read_bytes()),'newInstructions':len(ii),'combinedInstructions':out['combinedUniqueInstructions']}))

if __name__=='__main__':main()
