#!/usr/bin/env python3
"""Bound the observed nested class6/model10 edge and remaining authored records.

Source/file inspection only. Never creates a CPU or executes original code.
"""
from pathlib import Path
import json
import capstone
import constructor_ledger_alternator_candidate as l

H=Path(__file__).resolve().parent
b=l.b

def main():
 pe=b.load_pe(); cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
 checks=[]
 def check(name,value):
  assert value,name
  checks.append({'name':name,'passed':True})
 manifest=json.loads((H/'ledger-alternator-preflight01/constructor-ledger-preflight.json').read_text())
 inv=json.loads(l.INVENTORY.read_text())
 summary=json.loads((H/'constructor-ledger-run08-selected-summary.json').read_text())
 level=(b.GAME/'levels/levl2003.dat').read_bytes()
 windows=[]
 for a,z,name in [(0x485c9b,0x485d00,'real postprocess class6/model2 branch and nested allocation arguments'),(0x4fa757,0x4fa7c1,'class6/model10 initializer tail'),(0x4fc790,0x4fc849,'height/point helper complete body')]:
  raw=pe.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' complete decode',sum(i.size for i in ii)==len(raw))
  windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]})
 helper=list(cs.disasm(pe.read(0x4fc790,0xb9),0x4fc790))
 calls=[(i.address,i.operands[0].imm) for i in helper if i.mnemonic=='call']
 check('three exact helper calls',calls==[(0x4fc7fd,0x404540),(0x4fc829,0x4b9fc0),(0x4fc830,0x4044b0)])
 check('all helper callees already admitted',all(any(a<=t<z for a,z in l.ranges()) for _,t in calls))
 check('all jumps remain in helper body',all(i.operands[0].type==capstone.x86.X86_OP_IMM and 0x4fc790<=i.operands[0].imm<0x4fc849 for i in helper if i.mnemonic.startswith('j')))
 check('single genuine RET at exact end',[i.address for i in helper if i.mnemonic=='ret']==[0x4fc848])
 check('no new opcode family',set(i.mnemonic for i in helper)<={'mov','sub','push','xor','and','add','or','lea','je','movzx','test','cmp','jne','call','jmp','pop','ret'})
 check('exact nested class/model/owner argument bytes',pe.read(0x485cd7,12).hex()=='506a006a0a6a06e8bd7b0600')
 check('record93 authored settings select nested case',level[0x14043+92*55:0x14043+92*55+11].hex()=='0206ff00e3007d02050101')
 check('interface actual10 remains named condition',any('interface state10' in c for c in manifest['conditions']))
 check('observed rejected target',summary['blocker']['pc']=='0x4fa7af' and summary['blocker']['details']['target']=='0x4fc790')
 check('open nested allocator copied class6 counter2',summary['counterCopies'][-1]['requestedClass']==6 and summary['counterCopies'][-1]['counter']==2 and summary['counterCopies'][-1]['allocatorSequence']==4282)
 check('open nested allocator committed class6 seed3',summary['counterIncrements'][-1]['class']==6 and summary['counterIncrements'][-1]['valueAfter']['value']==3)
 old=next(r for r in inv['flowInventory'] if r['pc']=='004fa7af')
 check('previous source inventory explicitly left nested edge unclosed',old['admission']=='unclosed' and 'unclosed' in old['nestedScope'])
 records=[]
 for ordinal in range(93,110):
  off=0x14043+(ordinal-1)*55;r=level[off:off+55]
  group=('nested class6/model10 during class6/model2 postprocess' if ordinal==93 else 'already admitted person model1 and real postprocess' if r[1]==1 else 'already admitted class6/model6, raw settings copy without nested allocation' if r[1]==6 else 'already admitted model9 scenery; real nine-cell neighbor mutations remain guarded' if r[1]==5 else 'already admitted class7/model23 and common initializer' if r[1]==7 else 'already admitted model18 building; real state/terrain/job consumers remain guarded')
  records.append({'record':ordinal,'fileOffset':off,'rawSha256':b.sha(r),'model':r[0],'class':r[1],'owner':r[2],'settings7to14':r[7:15].hex(),'classification':group})
 check('remaining authored person slots are exactly twelve',[r['record'] for r in records if r['class']==1]==list(range(94,102))+list(range(106,110)))
 roots=['0x402ec0','0x403610','0x403d50','0x4030c0','0x4a5ef0','0x4a9030','0x509c10','0x50bcd0','0x485b00']
 residual=[]
 for root in roots:
  walk=inv['localWalks'][root]
  for row in inv['flowInventory']:
   if int(row['root'],16)==int(root,16) and hex(int(row['pc'],16)) in walk['callPCs'] and not any(a<=int(row['target'],16)<z for a,z in l.ranges()):
    residual.append({**row,'meaning':'Source-local conditional residual; no assertion of actual future reachability or of absence. Actual taken edge remains a hard stop.'})
 out={'status':'SOURCE_ONLY_REMAINING_RECORD_MAP_NO_NATIVE_EXECUTION','script':b.file_record(Path(__file__)),'executable':b.file_record(b.EXE),'inputs':[b.file_record(p) for p in [l.INVENTORY,H/'constructor-ledger-run08-selected-summary.json',H/'ledger-alternator-preflight01/constructor-ledger-preflight.json',b.GAME/'levels/levl2003.dat']],'assertions':checks,'windows':windows,'observedNestedArguments':{'class':6,'model':10,'owner':0,'caller':'0x485cde','allocatorSequence':4282,'copiedClass6Counter':2,'committedClass6SeedAfter':3,'returned':False},'helperWriteFootprint':{'direct':'Stack temporaries and DWORD through original second argument at004fc840 only. Genuine calls may have their own already-admitted effects.','calleeCalls':[{'pc':hex(pc),'target':hex(t)} for pc,t in calls],'reads':'Position DWORD, terrain tile flags and 10-bit occupant handle, handle-indexed object pointer and class/model; caller-output pointer. All require ordinary runtime provenance guards.','nonvolatiles':'ESI is genuinely saved/restored; ESP restored by actual epilogue; no fabricated return.'},'priorClassification':old,'remainingAuthoredRecords':records,'remainingRootResiduals':residual,'groupedLimits':['The12 remaining direct class1 records do not prove final class1 count or pre-wave seed; nested allocations/destructors remain genuine.','Model9 uses source-conditioned d188=0 and therefore the real nine-cell neighbor path. Previously constructed triggers/objects cannot be assumed absent. Damage/state-change targets remain explicit guarded residuals.','Model18 retains the existing exact object/frame-bound texture projection only. Actual alternate state, job, queue, geometry, metadata and unknown-input consumers remain guarded.','The finite closure of004fc790 adds no new semantic family and all three calls are already admitted, but does not close every nested descendant of all remaining constructors.','Every empty record and subsequent19 block transports remains required before StageA can complete. No predeclared final count or automatic retry.']}
 p=H/'constructor-tail-source01.json';b.json_write(p,out);print(json.dumps({'path':str(p),'sha256':b.sha(p.read_bytes()),'assertions':len(checks),'windows':len(windows),'remainingRecords':len(records),'explicitLocalResidualEdges':len(residual)}))

if __name__=='__main__':main()
