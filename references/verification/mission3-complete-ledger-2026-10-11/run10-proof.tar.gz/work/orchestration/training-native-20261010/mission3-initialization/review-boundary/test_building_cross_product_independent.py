"""Eight independent literal context fixtures and effect-free rejection; synthetic only."""
from pathlib import Path
import hashlib,importlib,json,sys,unittest
import unicorn
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'harness-repair'))
q=importlib.import_module(sys.argv.pop(1));b=q.b
f=R/'constructor-run09-context-fixture.json';assert hashlib.sha256(f.read_bytes()).hexdigest()=='9ff06c150127ff71b0506fbf8882aeaa4055c36bb4ae47593be3afb001caa23f';F=json.loads(f.read_text())
# These values are deliberately literal, independently source-reviewed, and are
# never derived from production context dictionaries.
CASES=[(2,1,('0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8)),(2,1,('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)),(2,18,('0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8)),(2,18,('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8))]+[(5,m,('0x403c10','0x4a68b6',0x4a68bb,'0x403d3c',0x403d41)) for m in (2,3,6,9)]
class CrossProduct(unittest.TestCase):
 def make(self,case=CASES[3]):
  cls,model,t=case;c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  e=q.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(0x4bdebe,0x4bdfdb+5)],protected_inputs=[],enable_texture_projection=True)
  e.phase='authored-record-loop';e.record=7;e.origin={'notAuthoritativeForObject':True};sp=0x23ecbd8;parent_sp=0x23ecc38;ptr=0x8fb0c7
  e.frames=[{'target':t[0],'caller':t[1],'return':t[2],'returnSp':parent_sp},{'target':'0x4bdd40','caller':t[3],'return':t[4],'returnSp':0x23ecbfc}]
  for reg,v in F['finalRegisters'].items():e.reg_supply(reg,int(v['value'],16),int(v['knownMask'],16),'independent run09-derived synthetic register')
  for a,raw in [(sp-156,b'\xa5'*204),(0x5d45a8,b'\3'),(parent_sp,q.pack(ptr)),(ptr+42,bytes([cls,model])),(sp+24,q.pack(7)),(sp+36,q.pack(0x0b107ce2)),(sp+40,q.pack(3)),(0x9bc318,b'\xa6'*1024)]:e.supply(a,raw,'independent literal synthetic fixture')
  return e,sp,ptr
 def fingerprint(self,e,sp):
  return (e.register_snapshot(),bytes(e.cpu.mem_read(sp-156,204)),e.shadow.get(sp-156,204),bytes(e.cpu.mem_read(0x9bc318,1024)),e.shadow.get(0x9bc318,1024),len(e.projections),len(e.invalidation_events),e.event_ordinal)
 def reject_without_effect(self,e,sp):
  before=self.fingerprint(e,sp)
  with self.assertRaises(b.Blocked):e.texture_projection()
  self.assertEqual(self.fingerprint(e,sp),before)
 def test_all_eight_literals_preserve_same_exact_projection_footprint(self):
  for case in CASES:
   e,sp,ptr=self.make(case);before=bytes(e.cpu.mem_read(sp-156,204));e.texture_projection();self.assertEqual(len(e.projections),1);self.assertEqual(e.projections[0]['classModel'],list(case[:2]));self.assertEqual(e.projections[0]['callerContext'],list(case[2]));self.assertEqual(e.projections[0]['object'],hex(ptr));self.assertEqual(e.reg_value('eip'),0x4bdfdb)
   self.assertEqual(bytes(e.cpu.mem_read(sp-156,204)),before);self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertEqual(e.observed(sp+24,4)['value'],7);self.assertEqual(e.reg_value('esp'),sp)
   for a,n in [(sp-156,156),(sp+16,6),(sp+28,4),(0x9bc318,1024)]:self.assertEqual(e.shadow.get(a,n),0)
   for reg in ['eax','ebx','ecx','edx','esi','edi','ebp']:self.assertEqual(e.shadow.reg_get(reg),0)
   self.assertFalse(e.shadow.reg['eflags']&b.ARITH);self.assertEqual(len(e.invalidation_events),12);self.assertFalse(e.write_events);self.assertFalse(e.events);self.assertEqual(e.committed,0)
 def test_actual_run09_model18_context_uses_independent_values(self):
  e,sp,ptr=self.make();self.assertEqual(e.observed(0x23ecc38,4)['value'],0x8fb0c7);self.assertEqual(e.observed(sp+36,2)['value'],0x7ce2);self.assertEqual(e.observed(sp+40,2)['value'],3);self.assertEqual(e.observed(sp+24,4)['value'],7);e.texture_projection();self.assertEqual(e.projections[0]['entryRegisters'],F['finalRegisters'])
 def test_every_wrong_caller_return_target_and_frame_is_effect_free(self):
  for case in CASES:
   for frame,key,value in [(0,'target','0x1'),(0,'caller','0x1'),(0,'return',1),(1,'target','0x1'),(1,'caller','0x1'),(1,'return',1),(1,'returnSp',0x23ecbfb)]:
    e,sp,ptr=self.make(case);e.frames[frame][key]=value;self.reject_without_effect(e,sp)
 def test_unproved_class_model_cross_combinations_are_effect_free(self):
  for cls,model,ctx in [(2,2,CASES[0][2]),(2,7,CASES[1][2]),(5,1,CASES[4][2]),(2,18,CASES[4][2]),(5,3,CASES[3][2]),(7,23,CASES[0][2])]:
   e,sp,ptr=self.make((cls,model,ctx));self.reject_without_effect(e,sp)
 def test_unknown_arguments_width_and_pointers_reject_before_taint(self):
  for address,size,mask in [(0x23ecc38,4,0xfffffffe),(0x8fb0c7+42,2,0xff),(0x23ecbfc,2,0xff),(0x23ecc00,2,0xff),(0x23ecbf0,4,0xffff),(0x9bcfc8,4,1),(0x9bcfd8,4,255),(0x5d45b0,4,0xffffffff)]:
   e,sp,ptr=self.make();e.shadow.put(address,size,mask);self.reject_without_effect(e,sp)
 def test_bad_geometry_and_mode_are_effect_free(self):
  for a,n,value in [(0x23ecc00,2,0),(0x23ecc00,2,129),(0x23ecbf0,4,8),(0x5d45a8,1,2)]:
   e,sp,ptr=self.make();e.supply(a,q.pack(value,n),'synthetic invalid guard input');self.reject_without_effect(e,sp)
if __name__=='__main__':unittest.main()
