"""File-only cursor/mask/call/conditional allocation ledger audit. No original CPU."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,importlib.util,json,struct,sys,time
import capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';R=H/'constructor-ledger-clear-run10'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while data:=f.read(1048576):h.update(data)
 return h.hexdigest()
started=time.monotonic();stream=read(R/'constructor-ledger-result-stream-receipt.json');process=read(H/'constructor-ledger-clear-run10-process-receipt.json');m=read(R/'constructor-ledger-preflight.json')
assert filehash(H/'constructor-ledger-clear-run10-process-receipt.json')=='249792688003a26b9a55d205d8f62c7a45c65e8376bd6d8f357f6c82533f26a4'
assert filehash(R/'constructor-ledger-result.json.gz')==stream['sha256']=='048aa2e4bf6881cf2d3141b4a727df4801de0ac4ff4d9a86facbf16f14cbbcdc'
assert filehash(R/'constructor-ledger-events.jsonl.gz')=='5e717137bf3d6866d9bd75ec16650586010e6c2d36490899fe173a54e990bc85'
h=hashlib.sha256();n=0
with gzip.open(R/'constructor-ledger-result.json.gz','rb') as f:
 while chunk:=f.read(1048576):h.update(chunk);n+=len(chunk)
assert n==stream['uncompressedBytes']==443341010 and h.hexdigest()==stream['uncompressedSha256']=='370daedf1798f38e0488d12278d79e2cf00e1b1ee80c2319cd606933652ab0c7'
with gzip.open(R/'constructor-ledger-result.json.gz','rt') as f:r=json.load(f)
print('loaded terminal result',flush=True)
assert process['status']=='terminal' and process['exitCode']==0 and not process['trackedStatus'];assert process['sourceHead']=='647666884acef2452f9a6439ec0256ff22f04199'
assert process['driversBefore']==process['driversAfter'] and len(process['driversBefore'])==14
for name,digest in process['driversAfter'].items():assert filehash(H/name)==digest
assert process['driversBefore']['constructor_ledger_building_context_candidate.py']=='d8374701a671974b716c394725aed9290aced2dc89e6cadfef16ed8a85f91630'
for f in process['artifacts']+[process['wrapper']]:assert Path(f['path']).stat().st_size==f['bytes'] and filehash(Path(f['path']))==f['sha256']
ap=Path(process['approval']['path']);ap=ap if ap.is_absolute() else ROOT/ap;approval=read(ap);assert filehash(ap)==process['approval']['sha256'];assert approval['parentReleasedRunLane']
for k,v in read(O/'constructor-ledger-building-context-held-approval.json').items():
 if k!='parentReleasedRunLane':assert approval[k]==v
assert r['conditions']==m['conditions'] and r['selectedLedgerContract']==m['selectedLedgerContract'];assert r['status']=='CONDITIONAL_STAGEA_LEDGER_COMPLETE' and r['complete'] is True
assert (r['attemptedOriginalInstructions'],r['committedOriginalInstructions'])==(4272685,4272685)
assert r['blocker'] is None and r['error'] is None
assert r['abortedInstructions']==[]
assert len(r['returnedAllocations'])==110 and len(r['publications'])==109 and len(r['openCalls'])==0 and len(r['records'])==2000 and len(r['blocks'])==20
assert [x['status'] for x in r['records']]==['completed']*2000
level=Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/levels/levl2003.dat').read_bytes();assert sha(level)=='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf'
for i,x in enumerate(r['records']):
 raw=level[0x14043+i*55:0x14043+(i+1)*55];assert x['record']==i+1 and x['rawHex']==raw.hex() and (x['class'],x['model'])==(raw[1],raw[0])
assert [x['record'] for x in r['records'] if x['class']] == list(range(1,110))
assert all(bytes.fromhex(x['rawHex'])==bytes(55) for x in r['records'][109:])
assert all(a['completedInstruction']<b['completedInstruction'] for a,b in zip(r['records'],r['records'][1:]))
for i,block in enumerate(r['blocks']):
 assert block['sha256']==sha(level[0x14043+i*0x157c:0x14043+(i+1)*0x157c])
 assert (block['blockIndex'],block['fileOffset'],block['bytes'],block['buffer'],block['frame'],block['beforePC'],block['resumePC'])==(i,0x14043+i*5500,5500,'0x2180000','0x23ed000','0x484e9a','0x484ebd')

for p in r['phaseReceipts']:
 if 'seedPreservation' in p:
  assert all(x['value']==0x09d78afe and x['knownMask']=='0xffffffff' for x in p['seedPreservation']['rng']);assert all(x['value']==0 and x['knownMask']=='0xff' for x in p['seedPreservation']['classCounters']);assert p['additionalConditionPreservation']['sceneryPoolAlternator']=={'address':'0x96ead5','value':0,'knownMask':'0xff'}
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);pe=module.PE32(Path(m['executable']['path']));assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;instructions={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);assert sha(data)==w['sha256'];ii=list(cs.disasm(data,lo));assert sum(x.size for x in ii)==len(data);instructions.update({x.address:x for x in ii})
assert pe.read(0x4fa7af,5).hex()=='e8dc1f0000' and 0x4fc790 in instructions
for pc,mn,ops in [(0x485035,'mov','dword ptr [ebp + 8], edi'),(0x4eda23,'mov','al, byte ptr [edx + 0x96eac1]'),(0x4eda29,'mov','byte ptr [esi + 0x2e], al'),(0x4eda35,'inc','byte ptr [edx + 0x96eac1]'),(0x4ed8ed,'inc','byte ptr [0x96ead5]')]:assert (instructions[pc].mnemonic,instructions[pc].op_str)==(mn,ops)
for index,c in enumerate(r['calls']):
 pc=int(c['caller'],16);target=int(c['target'],16);assert c['sequence']==index and pc in instructions and target in instructions and instructions[pc].mnemonic=='call'
 if instructions[pc].operands[0].type==capstone.x86.X86_OP_IMM:assert instructions[pc].operands[0].imm==target
 assert c['return']==pc+instructions[pc].size and (c['returned'] or c in r['openCalls'])
returns={c['sequence']:c for c in r['returnedAllocations']};assert len(returns)==110
for c in r['returnedAllocations']:assert c==r['calls'][c['sequence']] and c['returned'] and c['target']=='0x4ed8a0'
assert not r['openCalls']
post=[c for c in r['calls'] if c['caller']=='0x48502d'];assert len(post)==109 and [c['originRecord'] for c in post]==list(range(1,110)) and all(c['returned'] for c in post)
assert len(r['counterCopies'])==len(r['counterIncrements'])==110
# Independent snapshot byte decoding; these are retained values, not a CPU interpreter.
fields={'id':(0x24,2),'class':(0x2a,1),'model':(0x2b,1),'state':(0x2c,1),'counter':(0x2e,1),'ownerRaw':(0x2f,1),'prev':(0,4),'next':(4,4)}
def objectcheck(obj):
 ptr=int(obj['pointer'],16);assert obj['validPoolSlot'] and (ptr-0x8e0428)%179==0
 raw=bytes.fromhex(obj['rawHex']);mask=bytes.fromhex(obj['knownBitsHex']);assert len(raw)==len(mask)==179
 for field,(off,size) in fields.items():assert int.from_bytes(raw[off:off+size],'little')==obj[field]['value'] and mask[off:off+size]==b'\xff'*size
 assert obj['id']['value']==(ptr-0x8e0428)//179
 return raw,mask
for c in returns.values():
 objectcheck(c['allocation']);assert c['returnRegisters']['eax']=={'value':c['allocation']['pointer'],'knownMask':'0xffffffff'}
for index,p in enumerate(r['publications']):
 raw,mask=objectcheck(p['object']);assert p['record']==index+1 and int.from_bytes(raw[8:12],'little')==index+1 and mask[8:12]==b'\xff'*4
 assert p['publishedID']=={'address':hex(int(p['pointer'],16)+8),'value':index+1,'knownMask':'0xffffffff'};assert post[index]['returnRegisters']['edi']=={'value':hex(index+1),'knownMask':'0xffffffff'};assert post[index]['returnRegisters']['ebp']=={'value':p['pointer'],'knownMask':'0xffffffff'}
# Source-derived pool choice under the actual small occupancy range; all mutation
# writer sites and call associations are checked against the trace below.
sys.path.insert(0,str(H));import constructor_ledger_building_context_candidate as q
base=0x5a6830;descriptors=bytearray(pe.read(base,0x5aa600-base))
for a,data in q.b.constant_writes(pe):descriptors[a-base:a-base+len(data)]=data
def d(a,n=1):return int.from_bytes(descriptors[a-base:a-base+n],'little')
alloccalls=[c for c in r['calls'] if c['target']=='0x4ed8a0'];assert len(alloccalls)==110
low=639;high=1839;alternator=0;logical_counts=Counter();allocation_order=[]
for k,(call,copy,inc) in enumerate(zip(alloccalls,r['counterCopies'],r['counterIncrements'])):
 assert copy['allocatorSequence']==inc['allocatorSequence']==call['sequence'] and copy['record']==inc['record']==call['originRecord']
 cls=copy['requestedClass'];assert cls==inc['class'];ptr=int(copy['pointer'],16)
 obj=call['allocation'] if call['returned'] else r['finalLists']['primary']['order'][0];objectcheck(obj);model=obj['model']['value'];assert ptr==int(obj['pointer'],16) and cls==obj['class']['value']
 if call['caller']=='0x485011':
  nr=call['originRecord'];raw=bytes.fromhex(r['records'][nr-1]['rawHex']);assert (cls,model)==(raw[1],raw[0]);assert obj['ownerRaw']['value']==raw[2]
 else:assert call['caller']=='0x485cde' and (cls,model)==(6,10) and call['originRecord']==93 and call['returned']
 f=d(base+3*cls+2);small=bool(f&1)
 if not small and f&0x40 and cls==5:
  flags=d(0x5a79c4+model*24,4);small=bool(flags&0x1000000)
  if flags&0x2000000:alternator=(alternator+1)%256;small|=bool(alternator&1)
 # At most110 allocated, so the high-ID occupancy<=1100 branch cannot require fallback.
 slot=low if small else high
 if small:low-=1
 else:high-=1
 assert ptr==0x8e0428+slot*179 and obj['id']['value']==slot
 assert copy['counter']==logical_counts[cls] and copy['knownMask']=='0xff' and obj['counter']['value']==logical_counts[cls]
 assert not d(base+3*cls+1)&0x10;logical_counts[cls]=(logical_counts[cls]+1)%256
 assert inc['valueAfter']=={'address':hex(0x96eac1+cls),'value':logical_counts[cls],'knownMask':'0xff'}
 allocation_order.append({'callSequence':call['sequence'],'record':call['originRecord'],'returned':call['returned'],'class':cls,'model':model,'poolSlotId':slot,'pointer':hex(ptr),'copiedCounter':copy['counter']})
assert alternator==50 and logical_counts=={1:52,2:2,5:51,6:4,7:1}
assert r['finalLists']['primary']['status']=='complete' and [o['pointer'] for o in r['finalLists']['primary']['order']]==[x['pointer'] for x in reversed(allocation_order)]
print('source, identities, 110 allocations and snapshots checked',flush=True)
ranges=[(0x400000,bytearray(0xd4e000-0x400000)),(0x2000000,bytearray(0x400000))]
def location(a,n):
 for base,mem in ranges:
  if base<=a and a+n<=base+len(mem):return mem,a-base
 raise AssertionError(('outside domain',hex(a),n))
def put(a,n,mask=None):
 mem,off=location(a,n);mem[off:off+n]=b'\xff'*n if mask is None else mask.to_bytes(n,'little')
def get(a,n):
 mem,off=location(a,n);return int.from_bytes(mem[off:off+n],'little')
arrays={'read':r['memoryReads'],'write':r['memoryWrites'],'invalidation':r['invalidationEvents']};cursors=Counter();ordinal=0;supply_seq=0;phases=[];pcs=Counter();tracehash=hashlib.sha256();tracebytes=0
call_cursor=0;stack=[];callbytes=[];returned_order=[];pubbytes=[];pubindex=0;copyindex=0;incindex=0;altindex=0;altwrites=[];altsupplies=[];classvals=[0]*12;root_rets=0;metadata_alt=0;record_reads=[];block_decrements=[];rng_byte_groups=[];rng_group=[];overlapping_controls=Counter();projection_contexts=[]
with gzip.open(R/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  tracehash.update(line);tracebytes+=len(line);row=json.loads(line);kind=row.pop('kind')
  if kind=='conditionedSupply':
   assert row==r['suppliedInputs'][supply_seq] and row['supplySequence']==supply_seq and row['beforeEventOrdinal']==ordinal;supply_seq+=1
   if 'address' in row:
    a=int(row['address'],16);size=row['size'];put(a,size,int(row['knownMask'],16) if 'knownMask' in row else None)
    if a<=0x96ead5<a+size:altsupplies.append(row)
   continue
  if kind=='phaseCheckpoint':phases.append(row);assert row in r['phaseReceipts'] and not stack;continue
  if kind=='sceneryPoolIncrement':
   assert 'eventOrdinal' not in row and row==r['sceneryPoolIncrements'][metadata_alt];assert row['writeEventOrdinal']==ordinal-1;metadata_alt+=1;continue
  assert kind in arrays and row==arrays[kind][cursors[kind]];cursors[kind]+=1;assert row['eventOrdinal']==ordinal;ordinal+=1
  if kind=='invalidation':
   if row['target']=='memory':put(int(row['address'],16),row['size'],int(row['knownMask'],16))
   if row['pc'] in ['0x4a5f63','0x4bdebe'] and row['target']=='memory':projection_contexts.append((row['eventOrdinal'],[c['sequence'] for c in stack]))
   continue
  pc=int(row['pc'],16);a=int(row['address'],16);size=row['size'];mask=int(row['knownMask'],16);assert pc in instructions and pc!=0x4bdebe;ins=instructions[pc];assert not ins.mnemonic.startswith('f');pcs[pc]+=1
  if kind=='read':
   if pc==0x484edc:record_reads.append(row)
   assert get(a,size)==mask,(row,get(a,size))
   if ins.mnemonic=='ret':
    assert size==4 and mask==0xffffffff
    if stack:
     call=stack.pop();assert a+4==call['returnSp'] and call['returned'];returned_order.append(call['sequence'])
     if call['sequence'] in returns:
      obj=returns[call['sequence']]['allocation'];assert get(int(obj['pointer'],16),179)==int.from_bytes(bytes.fromhex(obj['knownBitsHex']),'little')
    else:root_rets+=1
  else:
   assert row['committed'] and size==1;put(a,size,mask)
   if pc==0x485046:block_decrements.append(row)
   if any(base<=a<base+4 for base in (0x89d178,0x89bc72)):
    rng_group.append(row)
    if len(rng_group)==4:
     assert len({x['pc'] for x in rng_group})==1 and [int(x['address'],16) for x in rng_group]==list(range(int(rng_group[0]['address'],16),int(rng_group[0]['address'],16)+4)) and all(x['knownMask']=='0xff' for x in rng_group)
     rng_byte_groups.append(rng_group);rng_group=[]
   if ins.mnemonic=='call':
    callbytes.append(row)
    if len(callbytes)==4:
     call=r['calls'][call_cursor];assert pc==int(call['caller'],16) and [int(w['address'],16) for w in callbytes]==list(range(call['returnSp']-4,call['returnSp'])) and all(w['knownMask']=='0xff' for w in callbytes)
     assert call['parent']==(stack[-1]['sequence'] if stack else None) and call['depth']==len(stack);stack.append(call);call_cursor+=1;callbytes=[]
   if a==0x96ead5:
    assert pc==0x4ed8ed and mask==255 and stack[-1]['target']=='0x4ed8a0';v=r['sceneryPoolIncrements'][altindex];assert v['allocatorSequence']==stack[-1]['sequence'] and v['record']==stack[-1]['originRecord'] and v['writeEventOrdinal']==row['eventOrdinal'];assert (v['valueBefore'],v['valueAfter']['value'],v['parityAfter'])==(altindex%256,(altindex+1)%256,(altindex+1)%2);altindex+=1;altwrites.append(row)
   if 0x96eac1<=a<0x96eacd:
    assert pc==0x4eda35 and mask==255;cls=a-0x96eac1;classvals[cls]=(classvals[cls]+1)%256;v=r['counterIncrements'][incindex];assert v['class']==cls and v['valueAfter']['value']==classvals[cls] and v['allocatorSequence']==stack[-1]['sequence'];incindex+=1
   if pc==0x4eda29:
    v=r['counterCopies'][copyindex];assert a==int(v['pointer'],16)+0x2e and mask==255 and v['allocatorSequence']==stack[-1]['sequence'] and v['counter']==classvals[v['requestedClass']];copyindex+=1
   if a in [0x89031c,0x890320,0x890324,0x890328,0x89c651,0x89c659]:overlapping_controls[(hex(a),hex(pc))]+=1
   if pc==0x485035:
    pubbytes.append(row)
    if len(pubbytes)==4:
     p=r['publications'][pubindex];ptr=int(p['pointer'],16);assert [int(w['address'],16) for w in pubbytes]==list(range(ptr+8,ptr+12)) and all(w['knownMask']=='0xff' for w in pubbytes);assert get(ptr,179)==int.from_bytes(bytes.fromhex(p['object']['knownBitsHex']),'little');assert post[pubindex]['sequence'] in returned_order and not stack;pubindex+=1;pubbytes=[]
assert all(cursors[k]==len(v) for k,v in arrays.items()) and supply_seq==len(r['suppliedInputs']);assert ordinal==r['eventStream']['eventCount'];assert tracehash.hexdigest()==r['rawEventTrace']['uncompressedSha256'] and tracebytes==r['rawEventTrace']['uncompressedBytes']
assert stack==r['openCalls'] and call_cursor==len(r['calls'])==4751 and not callbytes and len(returned_order)==4751
assert [s for s in returned_order if s in returns]==[x['sequence'] for x in r['returnedAllocations']]
assert pubindex==109 and not pubbytes and copyindex==incindex==110 and metadata_alt==altindex==50
assert len(altsupplies)==1 and altsupplies[0]['address']=='0x96ead5' and altsupplies[0]['size']==1 and get(0x96ead5,1)==255
for x in r['finalSeeds']['classCounters']:assert get(int(x['address'],16),1)==int(x['knownMask'],16)==255 and x['value']==classvals[int(x['address'],16)-0x96eac1]
assert get(0x2140000+6320,1602)==0
# Every projection footprint is checked against independently enumerated contracts.
inv=[x for x in r['invalidationEvents'] if x['pc'] in ['0x4a5f63','0x4bdebe']];pos=0;contexts={ordinal:frames for ordinal,frames in projection_contexts};projected=Counter()
literal_contexts=[(2,m,('0x403a00',caller,ret,'0x403bf3',0x403bf8)) for m in (1,18) for caller,ret in [('0x4036e1',0x4036e6),('0x404be6',0x404beb)]]+[(5,m,('0x403c10','0x4a68b6',0x4a68bb,'0x403d3c',0x403d41)) for m in (2,3,6,9)]
for p in r['projections']:
 pc=p['start'];projected[pc]+=1;sp=int(p['entryRegisters']['esp']['value'],16)
 if pc=='0x4a5f63':
  assert p['endExclusive']=='0x4a5fb8' and p['bytes']==85 and p['model'] in [2,3,6,9];n=6;mem=[('0x96eaba',4)];regs=['eax','edx','ebx','ecx','eflags']
 else:
  assert (p['classModel'][0],p['classModel'][1],tuple(p['callerContext'])) in literal_contexts
  assert pc=='0x4bdebe' and p['endExclusive']=='0x4bdfdb' and p['bytes']==285;n=12;mem=[(hex(sp-156),156),(hex(sp+16),6),(hex(sp+28),4),('0x9bc318',1024)];regs=['eax','ebx','ecx','edx','esi','edi','ebp','eflags']
 group=inv[pos:pos+n];pos+=n;assert len(group)==n and all(x['pc']==pc for x in group);assert sorted((x['address'],x['size']) for x in group if x['target']=='memory')==sorted(mem);assert all(x['knownMask']=='0x0' for x in group if x['target']=='memory');assert [x['register'] for x in group if x['target']=='register']==regs;assert all(x['knownMask']=='0x0' for x in group if x.get('register') not in [None,'eflags']);assert int(group[-1]['knownMask'],16)&0x8d5==0
 frames=[r['calls'][i] for i in contexts[group[0]['eventOrdinal']]]
 if pc=='0x4a5f63':assert (frames[-1]['target'],frames[-1]['caller'],frames[-1]['return'],sp)==('0x4a5ef0','0x4ed5b8',0x4ed5bd,frames[-1]['returnSp']-32)
 else:
  a,z=frames[-2:];assert [a['target'],a['caller'],a['return'],z['caller'],z['return']]==p['callerContext'];assert z['target']=='0x4bdd40' and sp==z['returnSp']-36
assert pos==len(inv) and projected=={'0x4bdebe':56,'0x4a5f63':51};assert get(0x96eaba,4)==0 and get(0x9bc318,1024)==0 and all(get(a,4)==0 for a in [0x9bcfc8,0x9bcfd8,0x5d45b0])
assert not any(0x4a5f63<=pc<0x4a5fb8 or 0x4bdebe<=pc<0x4bdfdb or 0x4bee20<=pc<0x4bf622 for pc in pcs)
assert not any(c['target'] in ['0x4bee20','0x4bf1b0'] for c in r['calls'])
assert [x['counter'] for x in r['counterCopies'] if x['requestedClass']==1]==list(range(52));assert r['selectedAssertions']['committedClass1Copies']==r['selectedAssertions']['committedClass1Increments']==r['selectedAssertions']['fullyReturnedSuccessfulClass1Count']==52
assert r['selectedAssertions']['completedRecords']==2000 and r['selectedAssertions']['fullStageAComplete'] and r['selectedAssertions']['finalKnownClass1Seed']=={'address':'0x96eac2','value':52,'knownMask':'0xff'}

assert not rng_group and len(rng_byte_groups)==len(r['rngWrites'])==578
assert [group[0]['pc'] for group in rng_byte_groups]==[x['pc'] for x in r['rngWrites']]
assert all(a['committedInstruction']<z['committedInstruction'] for a,z in zip(r['rngWrites'],r['rngWrites'][1:]))
assert r['rngWrites'][-1]['values']==r['finalSeeds']['rng']
assert all(x['values'][1]=={'address':'0x89bc72','value':0x09d78afe,'knownMask':'0xffffffff'} for x in r['rngWrites'])
assert all(int(group[0]['address'],16)==0x89d178 for group in rng_byte_groups)
assert len(record_reads)==2000
assert all(int(x['address'],16)==0x2180001+55*(i%100) and x['size']==1 and x['knownMask']=='0xff' for i,x in enumerate(record_reads))
assert len(block_decrements)==80 and all(x['knownMask']=='0xff' for x in block_decrements)
for i in range(20):assert [int(x['address'],16) for x in block_decrements[4*i:4*i+4]]==list(range(0x23ed028,0x23ed02c))
assert (instructions[0x485046].mnemonic,instructions[0x485046].op_str)==('dec','dword ptr [esp + 0x28]')
assert (instructions[0x48504a].mnemonic,instructions[0x48504a].operands[0].imm)==('jne',0x484e9a)
assert r['lastPCs'][-2:]==['0x485046','0x48504a'] and r['finalRegisters']['eip']=={'value':'0x485050','knownMask':'0xffffffff'}
assert r['finalRegisters']['edi']=={'value':'0x7d1','knownMask':'0xffffffff'} and r['finalRegisters']['esp']=={'value':'0x23ed000','knownMask':'0xffffffff'}
assert all(r['finalRegisters'][reg]['knownMask']=='0x0' for reg in ['eax','ecx','edx'])
assert 0x485050 not in pcs and not any(c['caller']=='0x485050' for c in r['calls'])
assert r['finalLists']['secondary']['head']['value']==0 and r['finalLists']['secondary']['status']=='complete'
helper=[c for c in r['calls'] if c['target']=='0x4fc790'];assert len(helper)==1 and helper[0]['originRecord']==93 and helper[0]['returned']
new_people=[a for a in allocation_order if a['class']==1 and a['record'] in [106,107,108,109]];assert [x['copiedCounter'] for x in new_people]==list(range(48,52))
all_later=[a for a in allocation_order if a['class']==1 and a['record'] in list(range(94,102))+list(range(106,110))];assert [x['copiedCounter'] for x in all_later]==list(range(40,52))
assert len([p for p in r['projections'] if p['record']==105 and p['classModel']==[2,18]])==3
summary={'verdict':'ACCEPT_COMPLETE_CONDITIONAL_STAGEA_2000_SLOTS_109_PUBLICATIONS_110_RETURNS','originalInstructionsExecutedByReviewer':0,'resultCompressedSha256':stream['sha256'],'resultExpandedSha256':stream['uncompressedSha256'],'attempted':r['attemptedOriginalInstructions'],'committed':r['committedOriginalInstructions'],'eventCount':ordinal,'eventCounts':dict(cursors),'supplies':supply_seq,'phaseCheckpoints':len(phases),'calls':len(r['calls']),'observerReconstructedReturnedCalls':len(returned_order),'openCalls':r['openCalls'],'returnedAllocations':110,'completedRecordSlots':2000,'nonemptyRecordsAndPublications':109,'emptyCompletedSlots':1891,'recordBlocks':20,'allocationOrderAndCopiedCounters':allocation_order,'independentClassCounts':classvals,'class1CopiedCounters':list(range(52)),'finalFourLaterWildmen':new_people,'allTwelveLaterWildmen':all_later,'authoredPublicationIds':list(range(1,110)),'poolSlotIdVersusAuthoredId':'Distinct WORD+0x24 pool slot and DWORD+0x08 authored ordinal; all109 publications checked at actual mask cursor and source MOV. Nested record93 allocation has no separate authored publication.','sceneryAlternator':{'initialCondition':0,'committedIncrementCount':50,'finalValue':50,'rows':r['sceneryPoolIncrements'],'selectionLimit':'Even parity does not universally select high-ID; model9 increases class5 but not this byte. Observed pool IDs independently reproduced under finite initial conditions.'},'projectionCounts':dict(projected),'blocker':r['blocker'],'error':r['error'],'abortedInstructions':r['abortedInstructions'],'selectedAssertions':r['selectedAssertions'],'finalSeeds':r['finalSeeds'],'finalRegisters':r['finalRegisters'],'rngCommittedWriteCount':len(r['rngWrites']),'rngReview':'578 full-known DWORD write groups match the578 reported write PCs and monotonic committed instruction references; every group targets0089d178 and the final reported snapshots agree. Second stream remains initial09d78afe. General RNG arithmetic is not independently reexecuted.','observerValidation':f'All{ordinal} raw observer rows equal retained arrays; contiguous ordinals,440 exact supply cursors and every read mask independently reconstructed.4751 actual CALL-stack writes/RET-stack reads reconstruct all4751 returned calls with zero open frames. Derived alternator rows refer to original committed writes.','valueChecks':'All110 returned object selected values decoded from retained raw179-byte snapshots and masks checked at return. All109 publication snapshots/cursors/source MOV and known EDI values checked. Source-bound descriptors and finite low occupancy reproduce110 pool IDs/order; all class-copy/INC chronology and50 alternator updates checked. This is not a full independent CPU arithmetic/general memory-value interpreter.','loopEvidence':'Canonical DAT and transport hashes cover20 ordered5500-byte blocks; all2000 slots match source bytes and completion metadata,1891 empty slots have no allocation/publication.2000 fully-known source byte reads repeat exact100-slot address sequence;80 known writes implement20 native DWORD block decrements. Final EDI2001/ESPframe/EIP00485050 and last DEC/JNE are consistent; no memory event/call executes at the following postload boundary. Instruction-only PCs/counts remain engine metadata.','remainingUnknowns':{'treeStartFlagsMask':'0','cacheDirtyGridMask':'0','opaquePointersMask':'0 for009bcfc8,009bcfd8,005d45b0','unwrittenAnimationIndexTailBytes':1602,'finalVolatileRegisters':'EAX,ECX,EDX masks0 after last transport; backing numbers carry no value claim'},'limits':['Complete only the predeclared conditional StageA record loop at00485050 before global postload work. No later conversion/replacement or owner-event phase is executed.','All selected startup state/RNG/counter/transport/lifetime and model-derived terrain conditions persist; this is not an actual original Mission3 startup snapshot.','Class1 seed52 follows52 committed copies0..51 under entryseed0. It is not evidence of a universal initial seed or converted/replacement person counter.','Tree proximity gameplay-derived flags and texture/resource outputs remain unknown under exact normal-completion/disjointness assumptions;51 tree and56 cache projections are explicit.','Exact returned-versus-published distinction:110 genuine allocator returns,109 authored nonempty publications,2000 traversed/completed slots.','No product code, parity credit or ordinary browser fix follows from this research result.'],'elapsedSeconds':time.monotonic()-started,'verifierSha256':filehash(Path(__file__))}
p=O/'constructor-ledger-run10-post-review.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'verdict':summary['verdict'],'reviewSha256':filehash(p),'events':ordinal,'counts':dict(cursors),'seconds':summary['elapsedSeconds']},indent=2),flush=True)
