"""Preserve old regressions except the deliberately superseded model18 exclusion."""
from pathlib import Path
import sys,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R));sys.argv=['prior-contexts','constructor_ledger_building_context_candidate']
import test_texture_contexts_independent as t
names=[n for n in unittest.defaultTestLoader.getTestCaseNames(t.IndependentContextTests) if n!='test_no_unproved_new_model18_or_unlisted_classmodels']
suite=unittest.TestSuite(t.IndependentContextTests(n) for n in names)
class RemainingOldNegatives(unittest.TestCase):
 def test_other_old_unproved_combinations_still_reject(self):
  case=t.IndependentContextTests()
  for row,kind in [(t.EXPECTED[0],(2,2)),(t.EXPECTED[3],(5,10)),(t.EXPECTED[3],(2,1))]:
   e,sp,ptr=case.make(row);e.supply(ptr+42,bytes(kind),'remaining historical negative input')
   with self.assertRaises(t.b.Blocked):e.texture_projection()
   self.assertFalse(e.projections);self.assertFalse(e.invalidation_events)
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RemainingOldNegatives))
result=unittest.TextTestRunner(verbosity=2).run(suite);assert result.wasSuccessful()
