"""Final one-literal-context gate; static/host checks only, no original execution."""
from pathlib import Path
import hashlib,json,sys,subprocess,copy
R=Path(__file__).resolve().parent; H=R.parent/'harness-repair';sys.path.insert(0,str(H))
import constructor_ledger_building_context_candidate as q
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head='647666884acef2452f9a6439ec0256ff22f04199'; driver='d8374701a671974b716c394725aed9290aced2dc89e6cadfef16ed8a85f91630'
assert sha(H/'constructor_ledger_building_context_candidate.py')==driver
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=q.b.ROOT,text=True).strip()==head
assert not subprocess.check_output(['git','status','--short'],cwd=q.b.ROOT,text=True).strip()
receipt=H/'constructor-ledger-building-context-verification-receipt01.json'
assert sha(receipt)=='fed8b4f53b9701daa5aae2d11f7fad3c898b95470112ae3ee4ef6c6ca5e66622'
for f in json.loads(receipt.read_text())['files']:
 p=q.b.ROOT/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],f['path']
s=(H/'constructor_ledger_building_context_candidate.py').read_text()
prefixes=['BUILDING_CONTEXT_SOURCE=','BUILDING_CONTEXT_SOURCE_SHA=','RUN09_CONTEXT_FIXTURE=','RUN09_CONTEXT_FIXTURE_SHA='," if b.sha(BUILDING_CONTEXT_SOURCE.read_bytes())", " if b.sha(RUN09_CONTEXT_FIXTURE.read_bytes())", "  'authoredBuildingTextureContextContract':"]
s=''.join(line for line in s.splitlines(keepends=True) if not any(line.startswith(p) for p in prefixes))
old="ADDITIONAL_TEXTURE_CONTEXTS={(2,1):('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)}"
new=old[:-1]+",(2,18):('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)}"
assert s.count(new)==1;s=s.replace(new,old)
assert s==(H/'constructor_ledger_tail_candidate.py').read_text()
assert sha(H/'constructor_ledger_tail_candidate.py')=='44677d49a53d93b36be4d9e4d6db8a2117c3e6372dd4ef1b7d1a0ba6f0052ddf'
mfile=H/'ledger-building-context-preflight01/constructor-ledger-preflight.json';m=json.loads(mfile.read_text())
assert mfile.read_bytes()==(R/'constructor-building-context-preflight-final/constructor-ledger-preflight.json').read_bytes()
prior=json.loads((H/'ledger-tail-preflight01/constructor-ledger-preflight.json').read_text())
delta={'class':2,'model':18,'parentTarget':'0x403a00','parentCaller':'0x404be6','parentReturn':'0x404beb','caller':'0x403bf3','return':'0x403bf8','minRadius':1,'maxRadius':128}
norm=copy.deepcopy(m);norm['driver']=prior['driver'];norm.pop('authoredBuildingTextureContextContract')
assert norm['finiteCallClosure']['textureContexts'].count(delta)==1
norm['finiteCallClosure']['textureContexts'].remove(delta);assert norm==prior
valid=q.approval_bindings(m);q.validate_approval(valid,m)
for field in ['authoredBuildingTextureContextContract','finiteCallClosure']:
 bad=copy.deepcopy(m)
 if field=='finiteCallClosure':bad[field]['textureContexts'].remove(delta)
 else:bad[field]['actualRun09Fixture']['sha256']='0'*64
 try:q.validate_approval(valid,bad)
 except q.b.Blocked:pass
 else:raise AssertionError('changed new context/fixture escaped approval binding')
hold=dict(valid);hold['parentReleasedRunLane']=False
try:q.validate_approval(hold,m)
except q.b.Blocked:pass
else:raise AssertionError('held approval admits execution')
held=R/'constructor-ledger-building-context-held-approval.json';held.write_text(json.dumps(hold,indent=2)+'\n')
logs={'building-context-all-tests-final.log':320,'building-context-independent-final.log':6,'building-context-alternator-independent-final.log':8,'building-context-animation-dispatch-final.log':1,'building-context-forms-final.log':9,'building-context-prior-contexts-current02.log':8}
for name,n in logs.items():
 t=(R/name).read_text();assert f'Ran {n} test' in t and t.rstrip().endswith('OK'),name
assert 'FAILED (failures=1)' in (R/'building-context-prior-contexts-final.log').read_text()
artifacts=[Path(__file__),held,R/'building-texture-cross-product-source-review.json',R/'verify_building_texture_cross_product.py',R/'constructor-run09-context-fixture.json',R/'extract_run09_context_fixture.py',R/'run09-context-fixture01.log',R/'run09-context-fixture02.log',R/'constructor-ledger-run09-post-review.json',R/'test_building_cross_product_independent.py',R/'test_prior_texture_contexts_after_extension.py',R/'building-cross-product-before-extension.log',R/'building-context-prior-contexts-final.log',R/'building-context-static-final.log']+[R/p for p in logs]
r={'verdict':'ACCEPT_EXACT_MODEL18_SHARED_CONTEXT_DIAGNOSTIC_PENDING_PARENT_RELEASE','driverSha256':driver,'verificationReceiptSha256':sha(receipt),'sourceHead':head,'preflightSha256':sha(mfile),'originalInstructionsExecutedByReviewer':0,'deltaReview':'Removing exactly four source/fixture constants, two prepare hash guards, one metadata entry and the literal class2/model18 shared-caller tuple reproduces frozen44677d49 byte-for-byte. All runtime method bodies, source windows, supplies, unknown propagation, projection footprints, call/ledger semantics and caps are unchanged.','manifestReview':'Only driver identity, added tuple and source/fixture contract change; independently prepared preflight is byte-identical. All prior conditions and executable92 windows unchanged.','newContext':delta,'sourceScope':'Independent canonical scan:9387 instructions/92 admitted windows,19 dispatch tables, seven complete chain windows and exactly five direct chain edges. Two authored building models1/18 times two source-bound callsites form four building tuples; four scenery tuples retained. This finite scan is not a universal indirect or recursive closure proof.','fixture':'Immutable run09 fixture binds real parent4595/child4605, actual object008fb0c7, class2/model18, packed ECX lowWORD7ce2, radius3, width7, fully known consumed bytes and all three opaque pointer masks0. Canonical PUSH EAX then PUSH ECX is retained. The initially incorrect reviewer ESI assertion and failed extraction log remain; the full ledger review was unaffected.','verification':{'authorSyntheticTestsIndependentlyRerun':320,'independentTests':32,'independentEightLiteralContextTests':6,'independentAlternatorTests':8,'independentActualSetupDispatcherTests':1,'independentDivisionSetleTests':9,'priorContextTestsWithOnlyNowProvedNegativeReclassified':8,'approvalBinding':'Changed tuple or fixture rejects old approval; parentReleasedRunLane=False rejects execution.','historicalFailure':'Unmodified historical negative fixture expected model18/shared caller to reject. That single obsolete expectation fails as expected under the new proved admission; historical test/log are retained. All seven unchanged old tests and its other three unproved combinations pass in an explicit current wrapper. No assertion was weakened for unproved behavior.','authorFailedHostTest':'Initial new fixture caught a test-only exception-class mismatch between separately imported frozen modules; failed log retained, no driver semantic repair.'},'wrapper':{'sha256':sha(H/'run_constructor_ledger_building_context_once.py'),'scope':'Fresh run10 only; validates exact released approval and fresh storage before launch;14 frozen driver hashes before/after; unchanged1200s outer cap; no automatic retry.'},'limits':['Parent must separately release one native lane; reviewer has executed no original instructions.','One land-clear/class-seed0 conditional ledger diagnostic; first unknown/unadmitted/fault/resource stop remains valid partial evidence, not full completion.','This newly proved model18/source-shared tuple does not remove or regress the seven historical contexts. All actual-object/frame/ESP, radius1..128, width2r+1, knownness and opaque-pointer guards remain; negatives reject before taint.','The projection remains conditional on valid live disjoint opaque resource/texture footprints and normal completion. Genuine brightness and later dirty OR remain; skipped outputs/CPU/stack remain unknown. No neutral-output claim or fabricated return.','Prior tree gameplay-output projection, model-terrain condition, preserved RNG/counter/history lifetimes and canonical transport conditions remain explicit.','Seven enumerated deeper residual call edges and all other unadmitted/decisive-unknown boundaries remain; no full2000-record, conversion/replacement, actual-startup or product-parity claim.','Ignored isolated research guard delta uses static/synthetic verification; product check/build is not applicable.'],'reviewArtifacts':[{'path':str(p.relative_to(q.b.ROOT)),'sha256':sha(p)} for p in artifacts]}
out=R/'constructor-ledger-building-context-final-review.json';out.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'verdict':r['verdict'],'reviewSha256':sha(out),'heldApprovalSha256':sha(held),'verifiedReceiptFiles':len(json.loads(receipt.read_text())['files'])}))
