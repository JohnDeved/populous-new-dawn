#!/usr/bin/env python3
"""Finite source/file audit of authored building models and texture caller sites.

No CPU is created; original executable bytes are only decoded.
"""
from pathlib import Path
import json,struct
import capstone
import constructor_ledger_tail_candidate as l

H=Path(__file__).resolve().parent;b=l.b
# Literal expected contexts, independent of the production dictionaries.
BUILDING=('0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8)
STATE_TWO=('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)
SCENERY=('0x403c10','0x4a68b6',0x4a68bb,'0x403d3c',0x403d41)
EXPECTED=(((2,1),BUILDING),((2,1),STATE_TWO),((2,18),BUILDING),((2,18),STATE_TWO),((5,2),SCENERY),((5,3),SCENERY),((5,6),SCENERY),((5,9),SCENERY))

def main():
 pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;checks=[];windows=[]
 def check(name,passed):
  assert passed,name
  checks.append({'name':name,'passed':True})
 def win(a,z,name):
  raw=pe.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' complete decode',sum(i.size for i in ii)==len(raw))
  windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]});return ii
 for a,z,name in [(0x402ec0,0x403071,'all building-model dispatch paths'),(0x4030c0,0x403264,'all building-state dispatch paths'),(0x403610,0x403813,'common building initialization and direct landscape caller'),(0x4049d0,0x404c4b,'state2 building initialization and alternate landscape caller'),(0x403a00,0x403c03,'complete building landscape helper and sole texture caller'),(0x403c10,0x403d4c,'complete scenery landscape helper and sole texture caller'),(0x4bdd40,0x4bdd7d,'texture frame geometry suppliers')]:win(a,z,name)
 decoded={i.address:i for a,z in l.ranges() for i in cs.disasm(pe.read(a,z-a),a)}
 targets={0x403a00,0x403c10,0x4bdd40};edges=[]
 for i in decoded.values():
  if i.mnemonic in ['call','jmp'] and i.operands[0].type==capstone.x86.X86_OP_IMM and i.operands[0].imm in targets:edges.append((i.address,i.operands[0].imm))
 check('all9387 admitted instructions scanned',len(decoded)==9387)
 check('exact five direct texture-chain edges',sorted(edges)==[(0x4036e1,0x403a00),(0x403bf3,0x4bdd40),(0x403d3c,0x4bdd40),(0x404be6,0x403a00),(0x4a68b6,0x403c10)])
 inv=json.loads(l.INVENTORY.read_text());indirect=[]
 for t in inv['dispatchTables']:
  check('no retained dispatch table targets landscape/texture entries '+t['pc'],not targets.intersection(int(x,16) for x in t['targets']))
  indirect.append({'pc':t['pc'],'tableSha256':t['sha256'],'intersectsTextureChainEntries':False})
 model_table=struct.unpack('<19I',pe.read(0x403074,19*4));state_table=struct.unpack('<6I',pe.read(0x403264,24))
 check('model1 dispatch target',model_table[0]==0x402ee5)
 check('model18 dispatch target',model_table[17]==0x402fbf)
 check('state2 dispatch target',state_table[1]==0x40318a)
 for pc,expected in [(0x402ee5,'56e825070000'),(0x402fbf,'56e84b060000'),(0x40318a,'56e840180000'),(0x4036de,'6a0156e81a030000'),(0x404be3,'6a0156e815eeffff'),(0x403a08,'8b4c2430'),(0x403bf1,'5051e848a10b00'),(0x4bdd54,'0fbf442428668b542424'),(0x4bdd6a,'894c2418')]:check(hex(pc)+' exact argument/dispatch bytes',pe.read(pc,len(bytes.fromhex(expected)))==bytes.fromhex(expected))
 check('model18 explicitly re-enters real state2 initializer',pe.read(0x402fdb,10).hex()=='c6462c0256e85ba60e00')
 level=(b.GAME/'levels/levl2003.dat').read_bytes();buildings=[]
 for n in range(2000):
  raw=level[l.LEVEL_OFFSET+n*55:l.LEVEL_OFFSET+(n+1)*55]
  if raw[1]==2:buildings.append({'record':n+1,'model':raw[0],'owner':raw[2],'rawSha256':b.sha(raw)})
 check('only authored building models1 and18',[(r['record'],r['model']) for r in buildings]==[(1,1),(105,18)])
 sp=H/'constructor-ledger-run09-selected-summary.json';s=json.loads(sp.read_text());frames=s['openCalls'][-2:]
 check('actual model18 caller chain4595 to4605',[(f['sequence'],f['parent'],f['target'],f['caller'],f['return'],f['returnSp']) for f in frames]==[(4595,4589,'0x403a00','0x404be6',0x404beb,0x23ecc38),(4605,4595,'0x4bdd40','0x403bf3',0x403bf8,0x23ecbfc)])
 check('actual model18 pointer',frames[0]['entryRegisters']['esi']=={'value':'0x8fb0c7','knownMask':'0xffffffff'})
 check('actual radius3 and coordinate source',frames[1]['entryRegisters']['eax']=={'value':'0x3','knownMask':'0xffffffff'} and frames[1]['entryRegisters']['ecx']=={'value':'0xb107ce2','knownMask':'0xffffffff'})
 check('actual native projection SP',s['finalRegisters']['esp']=={'value':'0x23ecbd8','knownMask':'0xffffffff'})
 check('rejection preceded model18 skip',s['blocker']['details']['kind']==[2,18] and not any(p.get('record')==105 and p['start']=='0x4bdebe' for p in s['projections']))
 check('actual object belongs to pending model18 allocator',s['counterCopies'][-1]['pointer']=='0x8fb0c7' and s['counterCopies'][-1]['requestedClass']==2 and s['records'][-1]['model']==18)
 source={'status':'SOURCE_AND_RETAINED_RUN09_CROSS_PRODUCT_NO_NATIVE_EXECUTION','script':b.file_record(Path(__file__)),'executable':b.file_record(b.EXE),'frozenDriver':b.file_record(Path(l.__file__)),'inputs':[b.file_record(p) for p in [l.INVENTORY,sp,b.GAME/'levels/levl2003.dat']],'assertions':checks,'windows':windows,'admittedInstructionCount':len(decoded),'allDirectTextureChainEdges':[{'pc':hex(a),'target':hex(t)} for a,t in sorted(edges)],'retainedIndirectDispatchCheck':indirect,'authoredBuildings':buildings,'literalExpectedContexts':[{'class':kind[0],'model':kind[1],'context':list(ctx)} for kind,ctx in EXPECTED],'crossProductReason':'Both authored models enter the same00403610 building initializer. Its direct landscape call is004036e1. Their real state2 path dispatches through004030c0 to004049d0, whose landscape call is00404be6; model18 also explicitly sets state2 after the common initializer. Both callers pass the same actual object via PUSH ESI, and00403a00 has one texture call00403bf3. The finite admitted direct caller set is exhausted by these two sites. This proves the named conditional projection scope for four building tuples; it does not force execution of all four or establish arbitrary nested classes/callers.','guardInputSource':{'parentObjectPointer':'actual DWORD at parent pre-CALL ESP, preserved from original PUSH ESI','geometry':'genuine00403a00 derives radius max(zero-extended shape dimensions>>1)+1, hence1..128; real004bdd40 computes width2r+1','actualRun09':{'object':'0x8fb0c7','classModel':[2,18],'parentArgAddress':'0x23ecc38','coordinateWordAddress':'0x23ecbfc','coordinateWord':'0x7ce2','radiusAddress':'0x23ecc00','radius':3,'widthAddress':'0x23ecbf0','width':7,'projectionEsp':'0x23ecbd8'},'maskQualification':'Context rejection preceded later geometry/opaque-pointer guard checks; exact replay masks are a separate independent fixture obligation, not inferred from the stop.'},'run09CallFrames':frames,'run09ProjectionEntryRegisters':s['finalRegisters'],'limits':['Only named actual object class/model and exact parent/child caller/return/frame tuples qualify. Origin-record type is not the affected object identity.','All old nonvolatile/scratch/dirty/opaque-output taint and normal-completion/disjoint-resource conditions remain unchanged.','No blanket class2 permission. Other models/callers and unsupported indirect-target mutations remain guarded hard stops.','All seven deeper source-tail residual edges remain unclosed. No gameplay or complete constructor path equivalence claim.']}
 p=H/'building-texture-cross-product-source01.json';b.json_write(p,source);print(json.dumps({'path':str(p),'sha256':b.sha(p.read_bytes()),'assertions':len(checks),'windows':len(windows),'literalContexts':len(EXPECTED)}))

if __name__=='__main__':main()
