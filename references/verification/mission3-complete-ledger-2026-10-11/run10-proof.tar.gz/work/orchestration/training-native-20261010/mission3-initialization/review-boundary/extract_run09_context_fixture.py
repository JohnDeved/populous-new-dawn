"""Small target-mask/argument addendum from accepted final JSON, no native execution."""
from pathlib import Path
import gzip,json,hashlib,importlib.util,capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';run=H/'constructor-ledger-clear-run09'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=run/'constructor-ledger-result.json.gz';assert sha(p)=='e8109831f80b166a9ab10fdcf4375b1973432c5a23f5dd213afb96a6ed576eee';assert sha(O/'constructor-ledger-run09-post-review.json')=='502db8e067fd2a2c6a3ab98c29a142daf27598e98393659d40dcaf53a00b310d'
r=json.load(gzip.open(p,'rt'));parent=r['calls'][4595];child=r['calls'][4605]
assert (parent['caller'],parent['target'],parent['return'],parent['returnSp'])==('0x404be6','0x403a00',0x404beb,0x23ecc38)
assert (child['caller'],child['target'],child['return'],child['returnSp'])==('0x403bf3','0x4bdd40',0x403bf8,0x23ecbfc)
sp=0x23ecbd8;ptr=0x8fb0c7
regions=[('parentObjectArgument',0x23ecc38,4,0xffffffff),('objectClassModel',ptr+42,2,0xffff),('packedPosition',sp+36,2,0xffff),('radius',sp+40,2,0xffff),('width',sp+24,4,0xffffffff),('resource3Pointer',0x9bcfc8,4,0),('resource1Pointer',0x9bcfd8,4,0),('texturePointer',0x5d45b0,4,0)]
# Reconstruct just these final masks. All full-stream ordering was already
# verified; supply-before-cursor keys put conditions before the matching event.
state={a+i:0 for _,a,n,_ in regions for i in range(n)};target=set(state);updates=[]
def overlaps(a,n):return any(a<=t<a+n for t in target)
last_writes={}
for seq,v in enumerate(r['suppliedInputs']):
 if 'address' in v:
  a=int(v['address'],16);n=v['size']
  if overlaps(a,n):updates.append(((v['beforeEventOrdinal'],0,seq),a,n,None if 'knownMask' not in v else int(v['knownMask'],16)))
for v in r['memoryWrites']:
 a=int(v['address'],16);n=v['size']
 if overlaps(a,n):
  updates.append(((v['eventOrdinal'],1,0),a,n,int(v['knownMask'],16)))
  for t in target:
   if a<=t<a+n:last_writes[t]=v
for v in r['invalidationEvents']:
 if v['target']=='memory':
  a=int(v['address'],16);n=v['size']
  if overlaps(a,n):updates.append(((v['eventOrdinal'],1,0),a,n,int(v['knownMask'],16)))
for _,a,n,mask in sorted(updates):
 for t in target:
  if a<=t<a+n:state[t]=255 if mask is None else (mask>>(8*(t-a)))&255
masks={}
for name,a,n,want in regions:
 got=sum(state[a+i]<<(8*i) for i in range(n));assert got==want,(name,got,want);masks[name]={'address':hex(a),'size':n,'knownMask':hex(got)}
start=max(v['eventOrdinal'] for v in r['memoryWrites'] if v['pc']=='0x404be5' and v['address']=='0x23ecc38')
pcs={'0x404be5','0x403a08','0x403bf1','0x403bf2','0x4bdd54','0x4bdd59','0x4bdd6a'}
events=sorted([{'kind':kind,**v} for kind,rs in [('read',r['memoryReads']),('write',r['memoryWrites'])] for v in rs if v['pc'] in pcs and v['eventOrdinal']>=start],key=lambda v:v['eventOrdinal'])
assert len(events)==19
for address,size,pc in [(0x23ecc38,4,'0x404be5'),(sp+36,2,'0x403bf2'),(sp+40,2,'0x403bf1'),(sp+24,4,'0x4bdd6a')]:
 assert all(last_writes[address+i]['pc']==pc and last_writes[address+i]['eventOrdinal']>=start for i in range(size))
assert parent['entryRegisters']['esi']=={'value':hex(ptr),'knownMask':'0xffffffff'}
assert child['entryRegisters']['eax']=={'value':'0x3','knownMask':'0xffffffff'}
assert child['entryRegisters']['ecx']=={'value':'0xb107ce2','knownMask':'0xffffffff'}
obj=r['finalLists']['primary']['order'][0];assert obj['pointer']==hex(ptr);raw=bytes.fromhex(obj['rawHex']);assert raw[42:44]==bytes([2,18]) and bytes.fromhex(obj['knownBitsHex'])[42:44]==b'\xff\xff'
spec=importlib.util.spec_from_file_location('context_static_pe',ROOT/'scripts/check-static-mission18-sky.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);pe=module.PE32(Path(r['identity']['path']) if 'path' in r['identity'] else Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/d3dpoptb.exe'));assert hashlib.sha256(pe.data).hexdigest()=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[]
for a,z in [(0x404be5,0x404beb),(0x403a00,0x403a0c),(0x403bef,0x403bf8),(0x4bdd54,0x4bdd6e)]:
 raw=pe.read(a,z-a);ii=list(cs.disasm(raw,a));assert sum(i.size for i in ii)==len(raw);windows.append({'start':hex(a),'endExclusive':hex(z),'sha256':hashlib.sha256(raw).hexdigest(),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]})
result={'status':'INDEPENDENT_RUN09_MODEL18_REJECTION_FIXTURE_NO_NEW_ADMISSION','originalInstructionsExecuted':0,'resultCompressedSha256':sha(p),'resultExpandedSha256':'5150e4cbf3fcada245a42dbdcf2393845711ebc9efacdb22382e5db66b05b429','acceptedFullReviewSha256':sha(O/'constructor-ledger-run09-post-review.json'),'literalContext':['0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8],'classModel':[2,18],'object':hex(ptr),'parent':parent,'child':child,'finalRegisters':r['finalRegisters'],'knownValues':{'parentObjectArgument':ptr,'class':2,'model':18,'packedPosition':0x7ce2,'radius':3,'width':7},'finalTargetMasks':masks,'argumentMemoryEvents':events,'sourceWindows':windows,'valueDerivation':'PUSH ESI at404be5 binds known parent entry ESI8fb0c7; parent MOV403a08 consumes it. PUSH EAX/ECX at403bf1/2 binds known child entry EAX3/ECX0b107ce2; the coordinate consumer reads lowWORD7ce2. Real word radius read4bdd54 and LEA4bdd59 produce2*3+1=7, stored at4bdd6a. All19 exact memory rows and final masks retained. No later target-byte write supersedes these source stores.','limits':['Guard rejected before geometry/pointer checks; later checks were not inferred to have passed. Their actual masks/source-bound values are independently reconstructed here.','Opaque pointer values remain unknown; no concrete resource mapping or return is supplied.','Model18 at the shared caller is a newly excluded combination. Its future admission requires the complete finite source cross-product and independent literal positive/negative tests.'],'extractorSha256':sha(Path(__file__))}
(O/'constructor-run09-context-fixture.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'sha256':sha(O/'constructor-run09-context-fixture.json'),'argumentEvents':len(events)}))
