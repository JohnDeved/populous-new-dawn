"""Eight literal positives, retained run03/run09 and effect-free negative guards."""
import ast,copy,hashlib,json,unittest
from pathlib import Path
from unittest.mock import patch
import unicorn
import constructor_ledger_building_context_candidate as l
import constructor_ledger_tail_candidate as old

b=l.b
BUILDING=('0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8)
STATE_TWO=('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)
SCENERY=('0x403c10','0x4a68b6',0x4a68bb,'0x403d3c',0x403d41)
# No expected row is obtained by iterating either production allowlist.
EXPECTED=(((2,1),BUILDING),((2,1),STATE_TWO),((2,18),BUILDING),((2,18),STATE_TWO),((5,2),SCENERY),((5,3),SCENERY),((5,6),SCENERY),((5,9),SCENERY))

class BuildingContextTests(unittest.TestCase):
 def make(self,kind=(2,18),context=STATE_TWO,radius=3,history=None):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  e=l.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(l.TEXTURE_START,l.TEXTURE_END+5)],protected_inputs=[],enable_texture_projection=True)
  e.phase='authored-record-loop';e.record=105;sp=l.FRAME-0x200;ptr=b.POOL+179;parent_sp=l.FRAME+0x20;coords=0x1212
  regs={r:{'value':hex(v),'knownMask':'0xffffffff'} for r,v in [('esp',sp),('eip',l.TEXTURE_START),('eflags',2)]+[(r,0x12345678) for r in ['eax','ebx','ecx','edx','esi','edi','ebp']]}
  e.frames=[{'target':context[0],'caller':context[1],'return':context[2],'returnSp':parent_sp},{'target':'0x4bdd40','caller':context[3],'return':context[4],'returnSp':sp+36}]
  if history=='run09':
   f=json.loads(l.RUN09_CONTEXT_FIXTURE.read_text());e.frames=[copy.deepcopy(f['parent']),copy.deepcopy(f['child'])];regs=f['finalRegisters'];sp=0x23ecbd8;ptr=0x8fb0c7;parent_sp=0x23ecc38;coords=0x7ce2;radius=3;kind=(2,18)
  if history=='run03':
   f=json.loads(l.CONTEXT_REPAIR_SOURCE.read_text());e.frames=copy.deepcopy(f['callFrames']);regs=f['projection']['entryRegisters'];sp=0x23ecbd8;ptr=0x8fc2f5;parent_sp=0x23ecc38;coords=0x9624;radius=3;kind=(2,1);e.record=1
  for r,v in regs.items():e.reg_supply(r,int(v['value'],16),int(v['knownMask'],16),'authored synthetic reconstruction; source fixture is file-only')
  for a,raw in [(0x5d45a8,b'\x03'),(parent_sp,l.pack(ptr)),(ptr+42,bytes(kind)),(sp-156,bytes(204)),(sp+24,l.pack(2*radius+1)),(sp+36,l.pack(coords,2)),(sp+40,l.pack(radius,2)),(0x9bc318,bytes(1024))]:e.supply(a,raw,'synthetic guard input')
  return e,sp,ptr
 def no_effects(self,e,before):
  self.assertFalse(e.invalidation_events);self.assertFalse(e.projections);self.assertFalse(e.write_events);self.assertEqual(e.register_snapshot(),before);self.assertEqual(e.committed,0)
 def footprint(self,e,sp):
  self.assertEqual(e.reg_value('eip'),l.TEXTURE_END);self.assertEqual(e.reg_value('esp'),sp)
  for a,n in [(sp-156,156),(sp+16,6),(sp+28,4),(0x9bc318,1024)]:self.assertEqual(e.shadow.get(a,n),0)
  self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertEqual(e.shadow.get(sp+24,4),b.MASK32)
  for reg in ['eax','ebx','ecx','edx','esi','edi','ebp']:self.assertEqual(e.shadow.reg_get(reg),0)
  self.assertEqual(e.shadow.reg_get('eflags')&b.ARITH,0);self.assertEqual(e.shadow.reg_get('esp'),b.MASK32)
  self.assertEqual([x['eventOrdinal'] for x in e.invalidation_events],list(range(12)));self.assertFalse(e.events);self.assertFalse(e.write_events);self.assertEqual(e.committed,0)
 def test_independent_literal_eight_contexts_and_frozen_source_receipts(self):
  self.assertEqual(hashlib.sha256(l.BUILDING_CONTEXT_SOURCE.read_bytes()).hexdigest(),l.BUILDING_CONTEXT_SOURCE_SHA)
  self.assertEqual(hashlib.sha256(l.RUN09_CONTEXT_FIXTURE.read_bytes()).hexdigest(),l.RUN09_CONTEXT_FIXTURE_SHA)
  source=json.loads(l.BUILDING_CONTEXT_SOURCE.read_text());self.assertEqual([((x['class'],x['model']),tuple(x['context'])) for x in source['literalExpectedContexts']],list(EXPECTED))
  self.assertEqual(set(l.TEXTURE_CONTEXTS.items())|set(l.ADDITIONAL_TEXTURE_CONTEXTS.items()),set(EXPECTED))
 def test_all_eight_literal_positives_preserve_same_footprint(self):
  for kind,context in EXPECTED:
   e,sp,ptr=self.make(kind,context);e.texture_projection();self.footprint(e,sp);self.assertEqual(e.projections[0]['object'],hex(ptr));self.assertEqual(e.projections[0]['classModel'],list(kind));self.assertEqual(e.projections[0]['callerContext'],list(context))
 def test_all_old_seven_behaviors_match_frozen_tail_driver(self):
  for kind,context in EXPECTED:
   if kind==(2,18) and context==STATE_TWO:continue
   e,sp,ptr=self.make(kind,context);p,_,_=self.make(kind,context);e.texture_projection();old.Ledger.texture_projection(p)
   self.assertEqual(e.projections,p.projections);self.assertEqual(e.invalidation_events,p.invalidation_events);self.assertEqual(e.register_snapshot(),p.register_snapshot())
 def test_retained_run03_and_run09_exact_positive_fixtures(self):
  for history in ['run03','run09']:
   e,sp,ptr=self.make(history=history);entry=e.register_snapshot();e.texture_projection();self.footprint(e,sp);self.assertEqual(e.projections[0]['entryRegisters'],entry)
   self.assertEqual([f['sequence'] for f in e.frames],[2080,2090] if history=='run03' else [4595,4605]);self.assertEqual(e.projections[0]['object'],'0x8fc2f5' if history=='run03' else '0x8fb0c7')
 def test_run09_fixture_restores_new_tuple_while_frozen_tail_rejects(self):
  e,sp,ptr=self.make(history='run09');before=e.register_snapshot()
  with self.assertRaisesRegex(old.b.Blocked,'exact admitted class/model/caller'):old.Ledger.texture_projection(e)
  self.no_effects(e,before);fixture=json.loads(l.RUN09_CONTEXT_FIXTURE.read_text())
  for row in fixture['finalTargetMasks'].values():self.assertEqual(e.shadow.get(int(row['address'],16),row['size']),int(row['knownMask'],16))
  e.texture_projection();self.footprint(e,sp)
 def test_removing_any_expected_tuple_causes_its_literal_fixture_to_fail(self):
  for kind,context in EXPECTED:
   table='ADDITIONAL_TEXTURE_CONTEXTS' if context==STATE_TWO else 'TEXTURE_CONTEXTS'
   with patch.dict(getattr(l,table),{kind:('invalid',)*5}):
    e,sp,ptr=self.make(kind,context);before=e.register_snapshot()
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.no_effects(e,before)
 def test_unproved_class_model_context_combinations_reject_without_effects(self):
  for kind,context in [((2,2),BUILDING),((2,13),STATE_TWO),((2,19),BUILDING),((2,18),SCENERY),((5,9),BUILDING),((5,2),STATE_TWO),((1,1),STATE_TWO)]:
   e,sp,ptr=self.make(kind,context);before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.no_effects(e,before)
 def test_all_eight_tuple_frame_near_misses_reject_before_any_effect(self):
  for kind,context in EXPECTED:
   for index,key,value in [(0,'target','0x403a01'),(0,'caller','0x404be7'),(0,'return',1),(1,'target','0x4bdd41'),(1,'caller','0x403bf4'),(1,'return',1),(1,'returnSp',1)]:
    e,sp,ptr=self.make(kind,context);e.frames[index][key]=value;before=e.register_snapshot()
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.no_effects(e,before)
 def test_model18_actual_object_wins_over_unrelated_origin_record(self):
  e,sp,ptr=self.make(history='run09');e.current_record={'record':105,'class':1,'model':7};e.texture_projection();self.assertEqual(e.projections[0]['classModel'],[2,18]);self.assertEqual(e.projections[0]['object'],'0x8fb0c7')
 def test_model18_unknown_object_geometry_and_opaque_guards_reject_before_effects(self):
  for field in ['object','class','model','esp','coords','radius','width','mode','opaque3','opaque1','texture']:
   e,sp,ptr=self.make(history='run09')
   if field=='esp':e.shadow.reg_put('esp',b.MASK32^1)
   elif field in ['opaque3','opaque1','texture']:e.shadow.put({'opaque3':0x9bcfc8,'opaque1':0x9bcfd8,'texture':0x5d45b0}[field],4,1)
   else:
    a,n={'object':(0x23ecc38,4),'class':(ptr+42,1),'model':(ptr+43,1),'coords':(sp+36,2),'radius':(sp+40,2),'width':(sp+24,4),'mode':(0x5d45a8,1)}[field];e.shadow.put(a,n,0)
   before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.no_effects(e,before)
 def test_model18_radius_bounds_width_and_later_unknown_consumer(self):
  for radius in [1,128]:
   e,sp,ptr=self.make(radius=radius);e.texture_projection();self.footprint(e,sp)
  for radius in [0,129]:
   e,sp,ptr=self.make(radius=radius);before=e.register_snapshot()
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.no_effects(e,before)
  e,sp,ptr=self.make(history='run09');e.supply(sp+24,l.pack(8),'synthetic incorrect width');before=e.register_snapshot()
  with self.assertRaises(b.Blocked):e.texture_projection()
  self.no_effects(e,before)
  e,sp,ptr=self.make(history='run09');e.texture_projection();e.frames=[];code=b.SCRATCH;e.cpu.mem_write(code,bytes.fromhex('803d18c39b0000'));e.windows.append((code,code+7))
  with self.assertRaises(b.Blocked):e.run(code,code+7)
  self.assertEqual(e.committed,0)
 def test_only_tuple_and_preparation_metadata_change(self):
  def defs(module):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(Path(module.__file__).read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
  a,z=defs(old),defs(l);self.assertEqual(set(a),set(z))
  for name in a:
   if name!='prepare':self.assertEqual(a[name],z[name],name)
  self.assertEqual(l.ranges(),old.ranges());self.assertEqual(l.entry_conditions('land-clear'),old.entry_conditions('land-clear'));self.assertEqual(l.TEXTURE_CONTEXTS,old.TEXTURE_CONTEXTS)
  self.assertEqual(set(l.ADDITIONAL_TEXTURE_CONTEXTS.items())-set(old.ADDITIONAL_TEXTURE_CONTEXTS.items()),{((2,18),STATE_TWO)})
  for name in ['TRACE_LIMIT','FINAL_JSON_LIMIT','FINAL_COMPRESSED_LIMIT','OTHER_OUTPUT_ALLOWANCE','SPACE_MARGIN','REQUIRED_FREE','ENTRY','NEXT','FINAL']:self.assertEqual(getattr(l,name),getattr(old,name))

if __name__=='__main__':unittest.main()
