import assert from 'node:assert/strict'
import { registerHooks } from 'node:module'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { serialize } from 'node:v8'
const [mode, output, referenceFile] = process.argv.slice(2)
const reference = referenceFile ? JSON.parse(readFileSync(referenceFile)) : null
const referenceEvents = new Map(reference?.events.filter(e=>e.key).map(e=>[e.key,e]) ?? [])
const occurrences = new Map()
let active=false, entryHash, entryBytes, baselineStopTurn=reference?.terminal.turn, firstDifference, firstHit, startHp
assert(['pre-consumer24e','candidate'].includes(mode))
const root=process.cwd(), url=pathToFileURL(root+'/'), sha=b=>createHash('sha256').update(b).digest('hex')
const head='24e90cbe86b4f970f04f5b531f9bc1744e896e0b', sourceFiles=[], events=[], milestones=[], visits=[]
const readers=new Set(['app/live-combat.ts','app/live-building-combat.ts','app/world-turn.ts','app/scene-entities.ts'])
const before={head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),diff:sha(execFileSync('git',['diff','HEAD','--binary']))}
let world, ordinal=0, eventOverflow=0, priorRoster='', priorFights='', firstMismatch, tests=[]
function person(u){const p=u?.native??u?.entry?.person??u?.fight?.motion??u?.builder?.person;return u&&{id:u.id,team:u.team,kind:u.kind,hp:u.hp,x:u.x,z:u.z,phase:u.personCounter,inside:u.inside,target:u.target,pathLength:u.path.length,work:u.work,p:p&&{counter:p.counter,state:p.state,substate:p.substate,flags2:p.flags2,flags3:p.flags3,flags4:p.flags4,immediate:p.immediateCommand,commands:[...p.commands],commandStatus:p.commandStatus,workTarget:p.workTarget}}}
function snapshot(){return{turn:world.turn,seed:world.randomState,status:world.status,people:world.units.filter(u=>u.team!=='wild').map(person),fights:world.fights.map(f=>({id:f.id,members:[...f.members]})),population:Object.fromEntries(['blue','green','red','yellow'].map(t=>[t,world.units.filter(u=>u.team===t&&u.hp>0).length]))}}
function event(row){if(!active)return;assert(events.length<100000,'bounded assault event capacity');row={ordinal:ordinal++,turn:world.turn,...row};
 if(['response','target'].includes(row.kind)) {const stem=`${row.turn}:${row.kind}:${row.before.id}`,i=occurrences.get(stem)??0;occurrences.set(stem,i+1);row.key=stem+':'+i;
  if(reference&&!firstDifference){const prior=referenceEvents.get(row.key);if(prior&&prior.result!==row.result)firstDifference={key:row.key,baseline:prior,candidate:row};else if(!prior&&row.result)firstDifference={key:row.key,baseline:null,candidate:row,limit:'No same-key baseline call'}}
 } events.push(row)}
globalThis.traceClockBefore=(kind,args)=>{
 if(!active)return null
 if(kind==='scanner'){const p=args[0];return{kind,p:structuredClone(p),turn:world?.turn,unit:person(world?.units.find(u=>u.id===p.id)),levelFlags:args[2],inTower:args[4]}}
 if(kind==='reservation'){const r=args[0],u=world?.units.find(u=>u.attackReservation===r);return{kind,id:u?.id,owner:u?'person':'other',counter:args[1],phase:u?.personCounter,state:u?.native?.state,before:{...r}}}
 const [w,u]=args;return{kind,world:w,before:person(u),next:w.personClock.next}
}
globalThis.traceClockAfter=(kind,args,before,result)=>{
 if(!active||before===null)return
 if(kind==='scanner')event({kind,before:{counter:before.p.counter,flags3:before.p.flags3,phase:before.unit?.phase,id:before.p.id,model:before.p.model,state:before.p.state,levelFlags:before.levelFlags,inTower:before.inTower},result,after:{flags3:args[0].flags3},unit:before.unit})
 else if(kind==='reservation')event({...before,after:{...args[0]}})
 else event({kind,before:before.before,after:person(args[1]),result:typeof result==='object'?result?.id:result,nextBefore:before.next,nextAfter:args[0].personClock.next})
}
function wrap(source,name,kind,exported){const token=`${exported?'export ':''}function ${name}(`;assert.equal(source.split(token).length,2,token);source=source.replace(token,`function observedOriginal_${name}(`);return source+`\n${exported?'export ':''}function ${name}(...args){const before=globalThis.traceClockBefore(${JSON.stringify(kind)},args);const result=observedOriginal_${name}.apply(this,args);globalThis.traceClockAfter(${JSON.stringify(kind)},args,before,result);return result}\n`}
registerHooks({load(href,context,next){if(!href.startsWith(url.href)||!href.endsWith('.ts'))return next(href,context);const path=href.slice(url.href.length);let raw=readFileSync(new URL(href),'utf8');if(mode==='pre-consumer24e'&&readers.has(path))raw=execFileSync('git',['show',`${head}:${path}`],{encoding:'utf8'});let source=raw;
 if(path==='app/live-building-combat.ts')source=wrap(source,'startLiveCombatResponse','response',true)
 if(path==='app/live-combat.ts')source=wrap(source,'automaticTarget','target',false)
 if(path==='app/melee-engagement.ts')source=wrap(source,'automaticCombatScanner','scanner',true)
 if(path==='app/combat-targets.ts')source=wrap(source,'stepAttackReservation','reservation',true)
 if(path==='app/person-clock.ts')source=wrap(source,'visitPrimaryPerson','visit',true)
 if(source!==raw||readers.has(path))sourceFiles.push({path,sourceSha256:sha(raw),observedSha256:sha(source),oldReaderOverride:mode==='pre-consumer24e'&&readers.has(path)})
 return source!==raw||(mode==='pre-consumer24e'&&readers.has(path))?{format:'module-typescript',source,shortCircuit:true}:next(href,context)
}})
globalThis.registerClockTest=(name,fn)=>tests.push({name,fn})
globalThis.traceWorld=w=>{world=w;if(!active)return;
 if(!firstHit){for(const u of w.units)if(startHp.has(u.id)&&u.hp<startHp.get(u.id)){firstHit={turn:w.turn,id:u.id,initialHp:startHp.get(u.id),hp:u.hp,unit:person(u)};break}}
 if((!reference&&firstHit)||(reference&&(firstDifference||w.turn>=baselineStopTurn))){milestones.push({kind:'diagnostic-stop',...snapshot()});throw Error('DIAGNOSTIC_STOP_FIRST_ASSAULT_DECISION')}
}
globalThis.traceMilestone=(kind,w,detail)=>{world=w;if(kind==='attack-entry'&&!active){assert.equal(detail.attempt,0);active=true;const bytes=serialize(w);entryHash=sha(bytes);entryBytes=bytes.length;startHp=new Map(w.units.map(u=>[u.id,u.hp]));if(reference){assert.equal(entryHash,reference.entryHash,'exact pre-assault world must match');assert.equal(w.turn,reference.milestones[0].turn)}}if(active)milestones.push({kind,detail,...snapshot()})}
const file='tests/mission2-replacement.test.mjs',raw=readFileSync(file,'utf8'),stub='data:text/javascript;base64,'+Buffer.from('export default(name,fn)=>globalThis.registerClockTest(name,fn)').toString('base64')
let code=raw.replace("'node:test'",JSON.stringify(stub)).replace(/(['"])(\.\.?\/[^'"]+)\1/g,(_,q,p)=>q+new URL(p,new URL(file,url)).href+q)
code=code.replace('select, setSelection, tick }','select, setSelection, tick as originalTick }')
code+='\nconst tick=(w,dt)=>{worldForObserver(w);originalTick(w,dt);globalThis.traceWorld(w)};const worldForObserver=w=>globalThis.traceMilestoneWorld(w)\n'
globalThis.traceMilestoneWorld=w=>{world=w}
code=code.replace("    setSelection(world, warriors('blue').map(unit => unit.id))","    globalThis.traceMilestone('attack-entry',world,{attempt,target:target.id});setSelection(world, warriors('blue').map(unit => unit.id))")
code=code.replace('    assert.ok(target.hp <= 0,',"    globalThis.traceMilestone('attack-end',world,{attempt,target:target.id,hp:target.hp});assert.ok(target.hp <= 0,")
code=code.replace("  assert.ok(people('green').length > 10)","  globalThis.traceMilestone('population-assertion',world,{actual:people('green').length,expected:'>10'});assert.ok(people('green').length > 10)")
assert(code.includes('tick as originalTick'));assert.equal(code.split("'attack-entry'").length,2);assert.equal(code.split("'attack-end'").length,2);assert.equal(code.split("'population-assertion'").length,2)
await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'))
assert.equal(tests.length,1);let status='passed',error
try{await tests[0].fn()}catch(e){status='failed';error=String(e.stack??e).replace(/data:text[^ )]+/g,'[observed-exact-test]').split('\n').slice(0,4).join('\n')}
const after={head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),diff:sha(execFileSync('git',['diff','HEAD','--binary']))};assert.deepEqual(after,before)
writeFileSync(output,JSON.stringify({mode,source:before,sourceAfter:after,testSha256:sha(raw),observedTestSha256:sha(code),observerSha256:sha(readFileSync(new URL(import.meta.url))),sourceFiles,method:'Exact unchanged Mission2 setup/actions. Event-triggered recording begins at original first assault entry. Full v8 serialized pre-assault worlds must hash equally. Baseline stops after first HP loss, candidate stops after first same-key materially differing actual response/target result or that same baseline turn. Forwarding reads only, no alternate decisions or extended battle. Original campaign acceptance is not evaluated by this early diagnostic.',status,error,entryHash,entryBytes,eventCount:ordinal,events,firstDifference,firstHit,milestones,terminal:world&&snapshot()},null,2)+'\n')
console.log(JSON.stringify({mode,output,status,error,eventCount:ordinal,entryHash,firstDifference,firstHit,terminal:world&&{turn:world.turn,population:snapshot().population}}))
