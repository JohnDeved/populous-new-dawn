from pathlib import Path
import hashlib,json,subprocess,tarfile,gzip,io
root=Path.cwd(); out=root/'references/verification/person-clock-blocked-2026-10-11'
files=set()
def add(p):
 p=Path(p);assert p.is_file(),p;assert not p.is_symlink();files.add(str(p))
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
# Exact tested current source plus pre-existing coherent product source.
for p in subprocess.check_output(['git','diff','--name-only','c8f789dd','--','app','tests','scripts','decomp/research/firewarrior-firing-phase/port.mjs'],text=True).splitlines():add(p)
add('tests/person-clock-consumers.test.mjs');add('references/person-clock.md')
for name in ['actual-caller-red','actual-caller-green01','targeted06','resident-leave07','full-check01','mechanical-and-journey02','marker-boundary05','marker-and-mission6-frontiers07','consumer-red13','consumer-green14','tower-red15','consumer-green16','consumer-focused17','mission2-reader-pair18','mission2-assault-pair19','mission4-input-gate12','mission4-attack-owner10','browser-ordinary01']:
 p=Path('work/orchestration/person-clock')/(name+'.json');add(p)
 for stream in ['stdout','stderr']:
  f=Path(str(p)+'.artifacts')/(stream+'.log')
  if f.exists():add(f)
add('work/orchestration/person-clock/full-check01-failures.json')
for name in ['consumer-head-loader.mjs','mission2-consumer-pair.mjs','mission2-assault-discriminator.mjs','mission2-reader-24e.json','mission2-reader-candidate.json','mission2-assault-24e.json','mission2-assault-candidate.json','mission2-assault-finding.json','consumer-repair-status.md','consumer-repair-manifest01.json','current-classification.md','cell774-source-boundary.json','firewarrior-pin-body-proof.json','firewarrior-pin-body-proof02.json','mission4-input-gate.mjs','mission4-input-baseline.json','mission4-input-candidate.json','mission6-retry-proof.json','remaining-eight.json','create_blocked_bundle.py']:
 add(Path('work/person-clock-diagnosis')/name)
for name in ['browser-review.json','preview-source.json','review.md','world-turn-consumer-audit.json','world-turn-reads.txt','audit_turn_consumers.py','resident-source-binding.json','housed-expiry-calls.json','housed-expiry-disassembly.txt']:
 add(Path('work/review-person-clock-fix-20261011')/name)
for name in ['ordinary-m3-clock.mjs','ordinary1/ordinary-m3.json','ordinary1/receipt.json','ordinary1/server.log','paired-entry-source-comparison.json','upstream-spacing-assessment.md']:
 p=Path('work/person-clock-browser')/name
 if p.exists():add(p)
patch=subprocess.check_output(['git','diff','c8f789dd','--binary','--','app','tests','scripts','decomp/research/firewarrior-firing-phase/port.mjs','references/person-clock.md'])
patchpath=Path('work/person-clock-diagnosis/blocked-source.patch');patchpath.write_bytes(patch);add(patchpath)
manifest={'schemaVersion':1,'base':'c8f789dd4a922f831527f4334c53c3e6365d194e','predecessor':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':'HOLD: source-supported reader law conflicts with unchanged Mission2 acceptance','scope':'Source, test inputs, raw receipts/logs and passive diagnostic evidence only; no original EXE/assets/dependencies/profiles. Older reviews have their original narrower scope. No original native execution.','appDiffSha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--','app'])).hexdigest(),'files':[{'path':p,'bytes':Path(p).stat().st_size,'sha256':digest(p)} for p in sorted(files)]}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(out/'manifest.json').write_bytes(raw)
with open(out/'evidence.tar.gz','wb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for p in sorted(files):
  info=tar.gettarinfo(p,arcname=p);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with open(p,'rb') as src:tar.addfile(info,src)
 info=tarfile.TarInfo('manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
record={'archive':'evidence.tar.gz','bytes':(out/'evidence.tar.gz').stat().st_size,'sha256':digest(out/'evidence.tar.gz'),'manifestSha256':hashlib.sha256(raw).hexdigest(),'members':len(files)+1,'uncompressedMemberBytes':sum(x['bytes'] for x in manifest['files'])+len(raw)}
(out/'archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
