# Person-clock regression classification at frozen app24e

Merge remains **HOLD**. No app edits, native executable runs, seed changes, campaign caps or tactics changes occurred in this diagnosis.

## Results

- The reviewed mechanical phase/save/source-pin fixtures and source-derived Mission3 saved-defense-center predicate pass40/40. Mission3 keeps its actual commands, caps, conversion/cancellation/checkpoint/display outcomes.
- Marker correction additionally passes: capture actual order publication before primary body; assert exact Brave/destination/assignment/task/delay, modulo4 and post-physics radius440, legitimate immediate completion/refcount cleanup and later task release.
- M14: original second-head full-count assertion fails102 with4/5; separate diagnostic observes all five stopped and the next real sample104 counts5. A reviewed all-cohort readiness fixture is permitted but remains unimplemented.
- M18: original secondVolcano reward assertion fails202; real approach completes203/204, sample208 counts6 and grants reward. First head cohort suffers combat losses in both baseline/candidate; preserve partial participation rather than requiring impossible full original cohort. Reviewed partial real-count/reset readiness fixture remains unimplemented.
- Area command: original area6 is correctly retained on acquired-building loss, then clears136 after the target moves outside its zero-extent cell. Tail7 remains and real fight starts140. Precise fixture proposal/source review remains pending.
- M6 standalone conversion: real preacher/victim ownership persists. Six candidate retry decisions and reset delays reproduce exactly from retained seeds and the native recurrence; all reject (%3=2,0,0,0,0,0), leaving timer15 at700. Setup has no supplied phase/RNG. No seed or cap repair justified.
- M6 expansion: original incidental Wildman-footprint assertion fails after naturally different origin/timing. Original downstream outcomes remain blocked at the assertion; no deletion/change justified yet.
- M23: first Yellow birth991 versus967 is retained as failed. A separately admitted continuation fails the unchanged next all-buildings-complete2585 assertion. Actual2585 populations13/13/14 also differ from12/12/16. Full checkpoint equality passed; this is not save divergence.
- M4: original scenario fails114559. First target14 input at8559 passes every actor gate but all10 individual cloned-state plan probes return null; unchanged real input reports no land route and publishes no Unit target. Baseline publishes13 targets and wins firsttarget14 engagement524ticks later. This is pre-publication route rejection, not an empty-shared-queue or missed-primary-visit conclusion.

## Exact M4 boundary

`app/live-command.ts:763–775`: plan before release/adoption/target publication. Normal non-Ctrl model28 uses this legacy target adapter; it does not allocate a shared model28 record. `app/live-pathfinding.ts:58–121` applies target support then selected planner/path-point validation. Actual cell774 is native3328,3328,height0,category0,flags17 and supportsFollower returns true. `app/person-idle.ts:162–184`, retained4d6f90/518200/44f980/518070 show that zero height alone is not original exclusion; support/rest and full-route acceptance have different predicates. No exact original terrain defect or alternate-phase main reproduction is established. See hash-bound `cell774-source-boundary.json`.

## Receipts and limits

All records live under `work/orchestration/person-clock/`: short-frontiers03, reward-frontiers04, marker-boundary05, reward-continuation06, marker-and-mission6-frontiers07, mission4-frontier08, mission23-frontier09, mission4-attack-owner10/11, mission4-input-gate12. Their diagnostic process success does not mean embedded original tests passed. Each embedded test status/failure is retained.

owner10 captured selection after ordinary input deselection and ended vacuously; it is preserved as an observer error, with no product claim. owner11 captures pre-input owners and guards empty reference lists but correctly has no shared orders for this legacy direct-target path. Gate12 captures actual message/targets plus individual detached plan results. Its tautological unitUnchanged field is not used as mutation proof. Its target history includes the test forcedAttack world untilturn62, then the actual scenario begins atturn1; only the latter segment supports location lineage.

App24e remains frozen. Seven test/tool files are dirty (the previous six reviewed fixes plus marker). Reward fixture edits were deferred by parent priority. Fresh mixed-clock source findings from reviewer are separate from this diagnostic and have not been implemented. Full check/build/performance and final review remain blocked.
