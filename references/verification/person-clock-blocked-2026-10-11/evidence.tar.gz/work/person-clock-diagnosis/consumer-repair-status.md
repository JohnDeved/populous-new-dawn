# Five proved person-phase readers: partial repair, acceptance HOLD

Frozen app24e remains the durable predecessor. Current uncommitted app delta changes only the three automatic scanner reads, Unit reservation read/visit eligibility, and Bloodlust render phase. Source inventory is the independent all109-world-turn-use audit. Status-duration adapters, global healing/invisibility, unresolved idle-Hut cadence and other-class clocks retain their old policies; complete native clock parity is not claimed.

Actual source-bound tests: consumer-red13 produced10 intended phase/eligibility failures plus2 tower setup errors;3 controls passed. green14 passed13, retaining the2 setup errors. The corrected tower fixture preserves opponent Shamans during genuine entry. tower-red15 injects the four exact24e app source bodies only for the filtered tower test and reproduces intended0-vs2 and2-vs0 shot failures. consumer-green16 passes15/15 with the corrected fixture. Earlier errors are retained unchanged.

The formatted repair then passed TypeScript and100/103 focused tests in consumer-focused17. All15 new phase tests and prior clock/lifecycle/Hypnotise/save/tower/healing/invisibility/M16 tests pass. Three failures block acceptance:
- Existing direct harvest fixture explicitly sets world.turn to a scan boundary but leaves Unit's phase unpinned.
- Existing squad capacity fixture still distributes3 people to near and1 to far, but the far recipient is the third rather than fourth member. No expected outcome was changed.
- Unchanged ordinary Mission2 replacement scenario fails Green population>10 after real assaults. Later producer-command/replacement outcomes did not execute; no assertion, commands, cap or tactical changes are permitted by this receipt.

No broad gate or campaign equivalence claim follows from these local passes. The Mission2 failure is reported to parent/reviewer; a bounded first-cause comparison is pending direction. No original executable execution occurred. The four-source hash loader is test-only and changes no worktree bytes.
