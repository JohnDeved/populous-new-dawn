// Test-only source binding: run the new tower fixture against the exact frozen
// 24e app readers without altering this worktree or dependency resolution.
import { registerHooks } from 'node:module'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const root = new URL('../../', import.meta.url)
const head = '24e90cbe86b4f970f04f5b531f9bc1744e896e0b'
const source = new Map(['live-combat', 'live-building-combat', 'world-turn', 'scene-entities'].map(name => {
  const path = `app/${name}.ts`, bytes = execFileSync('git', ['show', `${head}:${path}`], {cwd: root})
  process.stderr.write(JSON.stringify({head, path, sha256:createHash('sha256').update(bytes).digest('hex')})+'\n')
  return [new URL(path, root).href, bytes.toString()]
}))
registerHooks({load(url, context, next) {
  if (source.has(url)) return {format:'module-typescript', source:source.get(url), shortCircuit:true}
  return next(url, context)
}})
