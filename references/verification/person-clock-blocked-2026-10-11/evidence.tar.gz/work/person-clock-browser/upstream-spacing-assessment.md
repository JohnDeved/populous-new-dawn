# Remaining paired admission: finite source assessment

Frozen product 24e90cbe. This is a source/timeline comparison only, with no new native execution or movement patch.

The candidate actually admits 513 and300 together on turn1097 (retained counters112/108), and312 and519 together on1099 (114/116). All satisfy parity0. Distinct complete bytes do not imply distinct eligible turns. The identical-byte pair312/513 does not enter together. `training.ts:339–365` matches the retained local `00434610.c:355–428` gate: available capacity, direct state4→5, parity0 and per-axis distance<112. The16-turn entryDelay belongs the already-queued state3 path. It is not a global direct-arrival lock. Therefore neither a capacity-one rule nor a new semaphore is justified.

Two upstream discrepancies are already source-backed in the earlier controlled comparison, and remain unchanged by this PR:

- `live-movement.ts:686–717` formation allocation initializes timer0 without consuming simulation RNG. `00500a30.c:23–38` class10/model1 consumes RNG and writes `(random &31)+32`. Prior accepted controlled native fixture produced49/33, then the next person speed diverged70/86. This establishes a missing constructor effect in that fixture, not its responsibility for these ordinary pairs.
- `004ecac0.c:394–399` rebuilds tribe formation lists by prepending during primary traversal. Browser allocation-time `unshift` is not that end-pass rebuild. Prior controlled fixture recorded opposite ordinal-mapped formation processing order. Reordering allocation IDs is insufficient.

Rejected PR322 attempted composition of such changes but failed ordinary gameplay acceptance. This assessment does not revive it. The current PR has intentionally changed neither formation initialization/RNG nor list ordering. Its ordinary witness does not record formation allocator returns, per-pass rebuilt lists, RNG at those boundaries, or per-person within-turn route/motion calls. It only records after-turn person positions/speed/phase and trusted input boundaries. There is consequently no proof from retained data that one movement discrepancy explains both pairs.

The smallest missing discriminator is an observation-only ordinary trace joining each selected person's formation membership/allocation order, group timer/list order, simulation-RNG boundaries, and motion→route→command8 pre/post states to its actual same-turn occupancy call. Compare those observations against the already retained controlled source facts without changing simulation. Exact native Mission3 startup/formation history remains unproved; the finished conditional constructor ledger is not a substitute. Any future implementation needs independent source/caller review and unchanged gameplay gates, especially Mission2 and the ordinary witness.

Current evidence: `paired-entry-source-comparison.json`, candidate `ordinary1/ordinary-m3.json`, and research `work/orchestration/training-native-20261010/browser/findings.md` / `native/findings.md`. Paused stills are late observations, not matched transition moments; software-rendered frames use nearest wall-clock/turn correlation only.
