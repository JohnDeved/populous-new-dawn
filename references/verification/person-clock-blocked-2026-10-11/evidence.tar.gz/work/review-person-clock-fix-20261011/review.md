# Independent person-clock source review

Issue 29; preview on 2026-10-11. Candidate is unfrozen, author-owned branch `fix/person-allocation-clock-29`, base `c8f789dd4a922f831527f4334c53c3e6365d194e`. Preview fingerprints are in `preview-source.json`. This is not final acceptance. I have made no source edits and run no gameplay, browser, native, or heavy tests.

## Findings requiring resolution

1. **Hypnotise duplicate counter (source blocker).** `stepUnitHypnotise` advances `status.counter` independently after asking for a retained person visit. Native `004d92b0` uses the actual person counter byte for its modulo-eight expiry gate. A passive resident or inactive state can continue advancing the duplicate while the retained byte does not advance. Standalone visits and saved divergent copies are further divergence paths. Author agrees to make the allocation-mode phase a projection and retain the exact old independent behavior in legacy mode. The new injected `status.counter=7` test does not establish correct authority.
2. **Hypnotise early phase visibility (needs explicit resolution/test).** `stepUnitHypnotise` currently invokes the retained visit before `stepLiveMarchingFormations`. Marching reads the actual person's modulo-128 phase. Hypnotised people therefore expose an incremented phase to this consumer while ordinary people expose their previous phase. Native `004ec6f0` puts formations before the primary object pass/Hypnotise epilogue. Changing formation/RNG source is not requested; preserving the consumer's intended phase needs specific care.
3. **Dead Tornado dispatch mismatch (source blocker unless unreachable).** `world-turn` dispatches native state 24 before the HP guard, but `hasPrimaryPersonVisit` rejects a dead state-24 person without `flight`. On a throw visit, that controller installs flight and the object survives cleanup, now missing an increment. State 44 and flight already have exceptions; actual dispatch eligibility must cover state 24 or prove this path impossible.

## Source coverage

Inspected all maintained diff files, the new clock module/test, 11 actual `addUnit` caller sites, adapter creator and owner paths, all changed increment/reset sites, ordinary world-turn branches, level-start command 18 and suspension, construction, route projection, training conversion, Hypnotise, Armageddon, and checkpoint migration/storage.

The implementation's world byte and retained Unit byte provide one canonical authority for live adapters. `createLivePerson` consumes no births. The primary snapshot uses object identity rather than indexes/IDs and checks current membership, excludes births/replacements during the pass, and preserves existing app loop order. Pass-local dedup allows a later pass at the same world turn; it is not global world-turn dedup. `finally` ends the pass. The app's secondary lists hold effects, not a supported class-1 alternate pass. Old saves are permanently whole-world legacy; Armageddon deliberately does the same before reconstructing its roster. New-save incomplete metadata throws rather than synthesizing allocation history. No formation/RNG/admission/capacity implementation changes are present in this preview.

Absolute native startup phase and complete mixed-class allocation ordering are not established by this review. The coordinator's later complete conditional ledger supersedes the old scope note's partial 52-allocation count; neither count is a product seed or universal boot constant.

## Required fixture classification

Three unchanged `training-entry` tests currently require initialized path/animation on the conversion birth tick. Native `00405b80` first allocates/attaches inherited commands and then sets flags2 bit16; `004ec6f0` caches the next object before current dispatch; `preparePersonTurn` performs the deferred initializer on the first later person visit. The new primary membership policy exposes the previously missing boundary.

I recommend permitting stronger tests of both exact boundaries, subject to coordinator authorization:
- At birth: new identities, complete population/stats/mana updates, native owner and shared inherited exit command/refcounts, flags16 pending, retained allocation seed unchanged, and no initialized route/body visit.
- Exactly next eligible tick: same identities/owners, retained byte +1 once, pending flag consumed, correct native model/animation and actual exit route. Preserve all old final movement, queue-successor, capacity and shared-reference cleanup assertions.
- Do not weaken the test to a longer wait or synthesize a same-pass visit.
- Do not widen `unitAnimationSource` only to satisfy the old birth-tick assertion. A pending `createLivePerson` has object0/draw0; making it a native animation source can replace the existing trained-kind fallback with incorrect sprites. Any genuine presentation change needs separate evidence.

The builder fixture's turn33 timer64 assumption similarly depends on the old person phase. The maintained source reserves 64 in `reserveTimber` and `stepScenery` decrements once before later person work. Assert 64 at the observed real reservation event and exact subsequent scenery-visit decay, retaining two fetchers, their non-atomic same-tree race, the reservation flag/count, the later hauler's exclusion, and existing expiry semantics. Do not merely change 64 to63 or tune the fixture turn.

## Evidence inspected so far

- `work/orchestration/person-clock/mission2-unchanged01.json`: passed, unchanged full scenario including >10 Matak survivors and later replacement work, source-bound to preview diff/explicit new files.
- `focused01.json`: author reports 10/10; new tests read independently. Important uncovered cases are listed above.
- `targeted01.json`: failed, 139/144. Three training birth-boundary assertions and builder fixed-turn timer differ as discussed. `follower-transport-owner-consumers` never executes because TypeScript dependency cannot be imported; that is an environment/setup blocker, not a passed test or demonstrated gameplay defect.

## Final acceptance remains pending

Require exact frozen full diff/head, source-bound repaired tests and unchanged Mission 2, rendered ordinary Mission 3 birth-to-owner-to-input-to-admission witness without actor/counter/position injection, death/interruption/building destruction/save/load, affected nontraining checks, full `npm run check` and `npm run build`, TypeScript format/lint/standard receipts, relevant advisory quality evidence, and a bounded performance/allocation check. Current membership checks do linear `w.units.includes` at every visit and allocate a seven-owner projection array on each first visit; their observed cost has not been measured. Existing traces or screenshots alone do not prove doorway symptom improvement or universal one-at-a-time native admission.

## Resident lifecycle correction (06:58 UTC)

The initial scope note's inference that a passive Hut resident has no primary counter visit is disproved by the retained native source chain. This supersedes that preview assumption; it does not authorize promoting the passive browser record into animation/cell/movement ownership.

- `00407150` stores the admitted person's current +0x24 object ID in the actual Hut slot and calls occupancy mode0 on that same pointer.
- `004d80e0` mode0 clears orders and hides/unlinks land-cell membership. `004ee4f0` only rewires the cell list (+0x20/+0x22) and clears flag0x20000. Neither deactivates state nor unlinks the primary allocation list.
- Command8 completion in `00432590` returns the idle state through `004e32a0`. Model2's retained descriptor has idleState17. `004d2740` state17 initializer calls `004d6f90`, which sees inside flag0x800000 and enters state21 (0x15), a nonzero active state.
- State21 initialization in `004d2740` performs the occupancy hide again and calls `004ea460` to release a movement-route reference; that helper is not object retirement. `004d32b0` has a state21 timer body and common epilogue. `004ec6f0` therefore continues advancing the object's counter once per primary visit while housed.
- `00407490` retrieves the exact stored pointer from `unit_land_array[slot]`, calls occupancy mode1 on it, assigns exit anchor/facing/flags16, and returns that same pointer. No class1 allocation or byte reseed occurs on departure.

All eleven supporting exports match `decomp/exports.json`; see `resident-source-binding.json`. This is source evidence, not a fresh native execution.

Recommendation: count the canonical clock for a living valid retained resident, refresh its stored counter, and leave every existing passive simulation/animation/cell eligibility rule unchanged. Test real admission, several exact residence visits, save/load, and exit: same Unit/person identity, zero allocation-byte consumption at both boundaries, retained phase advances through residence, then exactly one normal first exit visit. Also retain failed-entry allocation, death, destruction, and status cleanup coverage.

## Follow-on source review (07:01 UTC)

The author has replaced early allocation-mode Hypnotise work with a non-incrementing per-person epilogue; legacy still uses the old early schedule. This addresses the source ordering issue in principle and requires frozen-source regression verification. Resident clock eligibility now consults validated passive storage without promoting animation/cell owners, and state24 is admitted alongside state44/flight.

A new definite stale-identity risk arises from per-person reversion: `contacts` can capture the current old person in its state body, then the epilogue replaces it. `replaceHypnotisedUnit` leaves that detached old Unit with positive HP; the post-loop contact checks do not verify current identity, and `joinBattle` can act on it. The pre-loop `burningPeople` snapshot likewise needs a current-identity guard before emitting post-loop effects. Author has agreed to guard both contact participants and the burning Unit and add a regression. Remaining post-loop health/death collections are rebuilt from current `w.units`.

Also requested coverage for normal housed Hypnotise expiry. Existing `replaceHypnotisedUnit` calls `releaseTasks`, whose passive path discards resident storage without `leaveLiveBuilding`. Since `buildingAdmission` only bootstraps its six slots once, a removed housed ID may leave a stale slot/count. This appears pre-existing; verify and classify before broadening repairs. Defeated-original-tribe cleanup does not exercise normal reversion/replacement.

Source-reviewed fixture updates now retain the meaningful old assertions and add exact birth/first-visit and reservation-event boundaries. `boundaries03.json` passes 28/28 on its intermediate source; `resident04.json` passes on the subsequent source. These intermediate receipts are not final-head gates. `transport-owner01.json` also passes the 3 transport consumer tests after the dependency setup was repaired.

## Housed Hypnotise deletion edge (07:04 UTC)

Coordinator authorized static read-only disassembly of the missing class1 cleanup edge. The existing canonical PE SHA-256 is `3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f`. Existing research venv supplies Capstone 5.0.7. No original code, Ghidra, or gameplay test was executed.

Raw E8 displacements independently bind:
- `004d9403 → 004ef180` from successful Hypnotise replacement, with the old person pointer;
- `004ef1ce → 004d4b50` for class1 deletion;
- `004d4bb1 → 00407490` for housed-person physical slot removal.

`004d4b62` tests byte `[person+0x0e]` bit0x80, equivalent to full flags2 bit0x800000. The housed branch resolves the building in that person's terrain cell, pushes the same person pointer followed by the building pointer, and calls the already-reviewed occupant remover before the remaining person cleanup. This establishes that a narrow new-policy replacement must release the existing physical occupant, not merely discard the browser resident adapter. It does not prove every other deletion/transport branch.

Exact inspected byte spans, file offsets, raw bytes, hashes, all three edges and limits are retained in `housed-expiry-calls.json`; disassembly in `housed-expiry-disassembly.txt`; reproducible script in `bind_housed_expiry.py`; successful raw output in `housed-expiry-run2.txt`. The first attempt's expiry-function bound ended at004d9400, just before the required call; its resulting assertion failure and corrected boundary are disclosed in `housed-expiry-attempt1-note.txt`. This was a static read-range correction only.

## Frozen source verdict (07:11 UTC)

SOURCE REVIEW CLEAR / ORDINARY BROWSER ADMISSION, not integration acceptance.

Frozen clean head `24e90cbe86b4f970f04f5b531f9bc1744e896e0b`, base `c8f789dd4a922f831527f4334c53c3e6365d194e`; full binary diff SHA-256 `69618dc9d7b0d1e5818372873fcd879a6a0a3bcd230da973a63c7e129c331722`. `git diff --check` passes. Canonical clock module SHA-256 `686ed38da0e232c6ccef176433d344815413b6f3788f068477f1c757da63cd17`.

The final semantic diff resolves the six source findings above: canonical Hypnotise projection and post-body timing; active dead Tornado eligibility; valid retained resident visits; current-identity validation for deferred contacts/trails; source-bound physical slot release for new-policy housed replacement. Resident departure retains its byte, public order adoption does not visit, and the next real tick advances exactly once. Legacy worlds remain whole-world legacy, including further births and saves; Armageddon changes the policy before census reconstruction. No formation, RNG, route-admission, capacity, or renderer changes were introduced.

Inspected `targeted06.json` (152/152, identical final app code), the retained meaningful fixture assertions, and `resident-leave07.json` (passes the exact final test change). These are source/focused evidence only. Parent may authorize the author's ordinary browser lane. Full quality/build, actual ordinary doorway improvement, relevant lifecycle evidence, and bounded actual tick performance remain required before integration acceptance.

Clarification of the earlier ledger note: the complete conditional constructor ledger has 110 returned allocations / 109 publications across 2000 slots, of which exactly 52 allocations are class1 people. The frozen reference's 52-person subset is correct. It is not an actual startup phase or product/migration seed; the complete later ledger supersedes only the earlier incomplete-stage claim.

## Ordinary browser result and partial-scope recommendation (07:20 UTC)

The frozen source-bound ordinary browser scenario and receipt pass. Independent comparison is retained in `browser-review.json`; scenario SHA-256 `b25fece1fb57ead0d006c8cbe430f1f4331d7cd9acb92eee010fb05ce31da37c` differs from retained baseline `68ad9437...` only in passive observers, fail-closed cleanup and explicit limits. Trusted controls, ten selected IDs, five builders, exact target world position, capacity and full queue-chain acceptance are unchanged. Both wrappers restored with zero errors. All copied canonical and adapter counters agree at both trusted-click boundaries and every retained turn snapshot.

This is independently defensible semantic correction evidence, and I support proceeding to full gates for a separately scoped partial merge. It is **not issue 29 symptom completion**. First substate5 starts relative to click change from four at+11/one at+13 to +9,+10,two at+11,+13. Actual physical-slot admissions change from three at+28/two at+30 to one at+27/two at+28/two at+30. Five concurrent substate5 travelers and peak entering count5 remain.

Native `00434610` cases4/5 require available capacity, an even per-person byte and separately signed per-axis goal distance <112, then call `00407150`. At candidate turn1097, IDs513/300 have even bytes112/108, coordinates(11519,39298)/(11520,39299), and gain actual slots1/2. At1099, IDs312/519 have bytes114/116, coordinates(11509,39202)/(11510,39193), and gain slots3/4. Their goal is(11520,39296). These are genuine paired near-coincident admissions, not only animation overlap. Different byte values can share parity. The16-building-turn entryDelay applies only to stopped queue-head release in case3; adding a universal doorway mutex would contradict this local source evidence.

Substate5 describes movement to the inside point; `entering` is an expiring congestion count, not an exact active-traveler count. The world `inside` transition plus physical-slot insertion establishes admission. All13 browser first-seen Blue people were already present at turn79, so the browser establishes retained owner→input→training, while the separate actual-caller RED/GREEN test supplies birth-time evidence. It does not itself observe births.

Rendered frames inspected: retained baseline `entry-frame-003.png` and paused `ordinary-multiple-entering.png`; candidate moving `entry-frame-003.png`, other retained frames and paused screenshot. Visible approach overlap remains. Frame003's nearest received-time observation is baseline1104/candidate1090, with capture lag explicitly unbounded. The paused stills are not comparable transition moments: baseline1118 already has five residents; candidate1097 has three. They must not be presented as a matched before/after fix. Full gates and bounded performance are still pending.

## Full check blocks integration (07:29 UTC)

`full-check01.json` terminates failed: 1997/2024 tests pass, 27 fail. Current merge verdict is HOLD/REJECT, even for the independent partial correction. Do not weaken budgets, desired outcomes, or native expected rows. Author retains24e app while diagnosing first causes.

Sixteen failures have direct fixture/instrumentation explanations: one whole-file Firewarrior pin with byte-identical exposed `stepAreaAttack`; one formation test seeds/counts adapter writes instead of retained visits; twelve gesture fixtures seed only the adapter; one terminal-turning fixture seeds only the adapter; one synthetic loaded-cell checkpoint supplies old Unit records while accidentally retaining fresh allocation metadata. Approved mechanical repairs preserve native expected event/RNG/result rows, make declared phases authoritative on Unit, explicitly mark the supplied old checkpoint legacy, and keep the exact hash guard with its updated verified caller hash. Reviewer also requested syncing both later gesture counter6 resets, including presently passing paths.

Failure titles were misleading in two places. Mission23's991vs967 compares the first Yellow birth TURN. `assert.deepEqual(restored,world)` has already passed through turn2585; there is no demonstrated checkpoint divergence. Later settlement/population/task assertions have not yet run. Mission6's named raid tests reach their raid/setup assertions; their failures occur in an isolated standalone Preacher conversion subscenario and in a sampled natural Wildman occupancy prerequisite respectively.

Paired source-bound Mission3 diagnostic explains the shared pre-sermon failure: both baseline and candidate genuinely dispatch a selected type8 response at2513. Baseline saved defense center26342 yields move(59008,26240); candidate saved center26862 yields(61056,26752) while Blue is still approaching. The scenario hardcodes only the former coordinates and waits until the Blue Preacher dies. `4c5cf0` captures hostile identity plus then-current packed cell; the task retains that cell; `4c5f70` phase5 dispatches to its saved center, not a future player-selected endpoint. A dynamic predicate is source-supported only if it retains active type8, exact Blue identity, phase6, selected>0, live assigned Yellow Preacher, uncancelled model3, and the exact saved-center destination after movement normalization. Identical ordinary commands, limits, authored victim, conversion/interruption/checkpoint assertions remain required; fixing this predicate alone is not a passed journey.

Remaining outcome/timing paths need individual evidence. In particular Mission4 final victory timeout is still unresolved. No build/performance or merge acceptance is claimed.

## 2026-10-11 07:56 UTC: finite phase-consumer audit; source clearance withdrawn

The earlier source-only clearance for browser admission was too broad. The audit had covered person-byte producers and seven mutating visit owners, but missed temporary/read-only projections. App remains frozen at24e90cbe. No final acceptance was issued; integration remains HOLD.

`world-turn-consumer-audit.json` inventories all109 `.turn` property uses in app TypeScript, with explicit classifications and12 native export hashes verified against the research checkout manifest. `world-turn-reads.txt` retains the89 World/w.turn-name matches, and the audit additionally covers other property names and inspected turn-context aliases. Source reads only; no new original execution, gameplay tests or product edits.

Five direct class1 phase gaps form a coherent finite group:

1. `live-combat.ts:212` overwrites scanner phase with World.turn.
2. `live-combat.ts:430` prefilters automatic target scans with World.turn. Its live caller is tower Firewarrior; the ordinary melee wrapper is currently test-only.
3. `live-building-combat.ts:244` does the same prefilter for actual ordinary/preacher response allocation. Both routes reach the same scanner. Native004d4690 reads person+0x2e against model scanMask;004d32b0 calls it with the actual person after the state/health body.
4. `world-turn.ts:1303` advances the Unit-owned attack reservation using global parity. Native0051fed0 reads that object's+0x2e; its duration is every visit, reaction timer alternate person visits. The building caller uses its own building byte and must remain separate. The new-mode eligibility must also honor the actual eligible primary visit, without creating another visit.
5. `scene-entities.ts:522` uses global bit2 for Bloodlust expiry blinking. Native004673b0 branch004691ec..00469303 uses person+0x2e. This source proof does not authorize or require importing different artwork.

Actual-caller tests, if the parent authorizes repair, must choose disagreeing global/person phases and exercise the real ordinary response allocator and tower scanner, pending flags3 consumption, Unit reservation parity/duration on an actual tick, and the live Bloodlust visibility caller. They must verify no query/render increment, retained identity and adapter equality, and legacy-mode preservation. Isolated scanner primitive tests alone do not catch its adapter's wrong projection.

Do not globally replace World.turn. Native004d43a0 explicitly heals on global offset_counter_2&7;004d32b0 explicitly uses global offset_counter for Invisibility blinking; animation stamps are+0x18/sprite serial, not person+0x2e. Global AI/tribe/script, input/activity timestamps, and class10 battle/class6 trigger/secondary-effect approximations remain distinct.

Unresolved/excluded existing adapters are made explicit: automatic Hut seeking uses browser idleTurns>16 and global&15 without a recovered one-to-one native owner; Shield/Bloodlust/Invisibility duration storage is in remaining browser turns, whereas native+a3/a5/b1 decrement on person&7; the procedural Shield has no native expiry blink at all. A timer representation/epilogue or Shield-art migration is not a safe phase search-and-replace and needs its own explicit scope. The current patch cannot claim all native class1 consumers or full scheduler parity.

### Mission4 causal boundary remains separate

The original first target14 command is default non-Ctrl context model28, taking the legacy direct-target path, not a shared command19 or attached command28. The immediate issued snapshots in `mission4-attack-{baseline,candidate}02.json` show baseline13 Units with target14; candidate10 selected Units all still have target=null before any primary tick. Both have zero issued shared order references, so empty queues are not evidence of retirement.

Author's bounded input gate diagnostic confirms all10 candidate canOrder/accepts28 checks pass and target supportsFollower is true, but all actual per-Unit route plans fail and the actual input reports no land route. Candidate target14 at native(3328,3328),cell774,height0 is reached through ordinary state17 recovery before resting19. Existing support and planning gates differ, so height0 alone does not establish invalid standing or the route-failure cause. No command retention, path cutoff, damage, RNG or budget change is justified from this evidence. Unchanged Mission4 victory acceptance still fails and independently blocks shipping.

## 2026-10-11 08:04 UTC: five finite reader repairs reviewed

Parent authorized precisely the five proved direct phase readers, with retained RED first. The author-owned working app diff updates only `live-combat.ts`, `live-building-combat.ts`, `world-turn.ts` and `scene-entities.ts`: it passes actual Unit identity into the scanner, uses retained phase for both prefilters, reads advanced phase for eligible Unit reservations, and reads it for Bloodlust visibility. No new visits, controller reordering, status-duration representation or terrain changes are introduced. All legacy branches remain global phase. No source blocker found within this finite diff; no aggregate/final clearance yet.

New `tests/person-clock-consumers.test.mjs` covers both phase disagreement directions through real response allocation, direct allocator and target query; pending-scan consumption under level suppression; physically admitted Tower Firewarrior visits; actual tick reservation parity/duration and inactive exclusion; old-mode controls; saved phase into the actual renderer with whole-world nonmutation; and global health/Invisibility controls.

Receipt `consumer-red13` has ten intended failing assertions, three passing controls, and two Tower setup failures (victory celebration reached unimplemented Firewarrior action). `consumer-green14` has13 passes and those same two setup failures. These are preserved and must not be counted as Tower phase proof. Corrected Tower setup retains live Shamans through normal public command and physical admission. `tower-red15` then loads the exact four24e source files through `consumer-head-loader.mjs` without changing the worktree; both intended shot assertions fail0!=2/2!=0. `consumer-green16` passes all15 cases on the repaired readers. These receipts were independently read, not rerun by reviewer.

The rendering helper is existing Node-only `tests/support/bloodlust-scene.mjs`: actual makeUnit/updateUnitsFrame/animatePerson execute, while texture loading and projection boundaries are supplied. This proves the live visibility consumer, not browser/GPU artwork parity. The loader's original HEAD hashes and unchanged-source before/after receipts bind its limited RED; filtered Tower run does not load the later renderer hook.

Still required: format/freeze, refreshed mechanical whole-file source pin with byte-identical stepAreaAttack body proof, campaign outcomes and complete full gates. Mission4 failure is not resolved by the15-case reader gate.

## 2026-10-11 08:06 UTC: coherent-scope recommendation after Mission2 regression

`consumer-focused17` typecheck passes; focused tests100/103. All15 new reader tests pass. Two local fixture assertions fail: direct harvest response pins world.turn to a scan visit; squad target assignment still has3-near/1-far but changes which member gets far. More importantly, the unchanged ordinary Mission2 replacement test fails `people('green').length >10` after its natural assault, before its replacement request/command/conversion assertions. This strict prerequisite is retained. It passed on24e before the five reader repairs.

Parent paused heavy work and requested a scope decision. Recommendation: keep draft/HOLD. No defensible narrower default-on production boundary is established. A shared class1 allocation/visit byte necessarily supplies state, route, scanner and reservation consumers; reverting selected readers to stale global phase would knowingly mix policies. Locally correct byte rules also do not prove the browser's creation/dispatch order is globally identical to native. Neither a fixture phase correction nor the two-pair ordinary doorway observation proves campaign safety.

A wholly legacy production default with explicit experimental whole-world opt-in could preserve previous gameplay, but would deliver no ordinary doorway correction and would be a new scope, not a merge-ready issue29 fix. Do not weaken Mission2's survivor prerequisite, adjust its assault controls, or raise unrelated campaign limits. Full acceptance remains blocked; no final merge ACCEPT has been given.
