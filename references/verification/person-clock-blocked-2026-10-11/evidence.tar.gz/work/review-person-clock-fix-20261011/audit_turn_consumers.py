from pathlib import Path
import subprocess,re,json,hashlib,collections
root=Path.cwd(); out=root/'work/review-person-clock-fix-20261011'
raw=subprocess.check_output(['rg','-n',r'\.turn\b','app','--glob','*.ts'],text=True)
rows=[]
specific={
 ('app/live-combat.ts',212):('PROVEN_CLASS1_GAP','combatScan','004d4690 reads person+0x2e against model scanMask; temporary scan overwrites with World.turn.'),
 ('app/live-combat.ts',430):('PROVEN_CLASS1_GAP','automaticTarget prefilter','Same004d4690 person phase; actual tower Firewarrior caller plus exported test-only melee helper.'),
 ('app/live-building-combat.ts',244):('PROVEN_CLASS1_GAP','startLiveCombatResponse prefilter','Same004d4690 person phase; real world-turn and preacher response callers.'),
 ('app/world-turn.ts',1303):('PROVEN_CLASS1_GAP','Unit attackReservation','0051fed0 tests object+0x2e parity. Native004d32b0 invokes after preparation; class1 lifetime/visit eligibility applies.'),
 ('app/scene-entities.ts',522):('PROVEN_CLASS1_GAP','Bloodlust expiry visibility','004673b0 Bloodlust branch004691ec..00469303 reads person+0x2e mask2; artwork remains existing adapter.'),
 ('app/world-turn.ts',1655):('UNRESOLVED_LEGACY_PERSON_ADAPTER','automatic Hut seeking','Browser idleTurns>16 and nearest friendly Hut search. No established one-to-one native routine/clock mapping; do not relabel as canonical or replace phase speculatively.'),
 ('app/spell-effects-runtime.ts',370):('NONPERSON_GLOBAL_CLOCK','Invisibility blink','004d32b0 explicitly tests game_state.offset_counter with mask1/2/4, unlike its separate person-phase duration decrement.'),
 ('app/live-people.ts',277):('NONPERSON_GLOBAL_CLOCK','healing cadence','004d43a0 explicitly tests game_state.offset_counter_2 &7.'),
 ('app/person-idle.ts',218):('NONPERSON_GLOBAL_CLOCK','rest-state initialization','004d7330 tests offset_counter_2 >1, not object counter.'),
 ('app/person-route-recovery.ts',34):('NONPERSON_GLOBAL_CLOCK','recent local-order notice','004d9580 compares offset_counter minus last input stamp <3.'),
 ('app/live-people.ts',553):('NONPERSON_GLOBAL_CLOCK','route recovery context','Carries global input-age clock to004d9580-equivalent initializeRouteRecovery.'),
 ('app/live-resting.ts',156):('NONPERSON_GLOBAL_CLOCK','rest initialization context','Carries global turn for004d7330 initialization; stepRestingPerson phase reads p.counter.'),
 ('app/person-clock.ts',24):('GUARDED_LEGACY_POLICY','adapter initialization','World-turn fallback runs only when allocation mode is absent.'),
 ('app/live-pathfinding.ts',383):('GUARDED_LEGACY_POLICY','route phase fallback','Explicit !hasPersonClock branch; allocation branch projects Unit byte.'),
 ('app/live-construction-runtime.ts',83):('GUARDED_LEGACY_POLICY','builder phase fallback','Explicit legacy branch; allocation branch shares visit/projected Unit byte.'),
 ('app/live-resting.ts',122):('GUARDED_LEGACY_POLICY','resting phase fallback','Explicit legacy branch; allocation branch shares visit/projected Unit byte.'),
 ('app/combat-runtime.ts',126):('OTHER_CLASS_PHASE_ADAPTER','fight relocation gate','Battle/internal class10, not person class1; existing world phase approximation documented by caller.'),
 ('app/combat-runtime.ts',134):('OTHER_CLASS_PHASE_ADAPTER','fight relocation context','Class10 counter approximation, not person byte.'),
 ('app/combat-runtime.ts',457):('OTHER_CLASS_PHASE_ADAPTER','fight orientation cadence','Group/fight class10 processing before ordinary people; not the member Unit byte.'),
 ('app/armageddon.ts',242):('OTHER_CLASS_PHASE_ADAPTER','arena staging','Effect/arena owner; candidate explicitly switches whole world permanently to legacy before census reconstruction.'),
 ('app/hut-smoke-runtime.ts',131):('OTHER_CLASS_PHASE_ADAPTER','secondary owner migration','Independent secondary-effect owner; no class1 dispatcher.'),
}
logical={('app/live-people.ts',1237),('app/live-people.ts',1240),('app/live-people.ts',1271),('app/live-people.ts',1274),('app/stone-head-animation.ts',147)}
ui={'app/minimap-renderer.ts','app/scene-input-runtime.ts','app/globe-renderer.ts','app/globe.ts','app/building-panels.ts','app/construction-panel.ts','app/training-panel.ts','app/workshop-panel.ts','app/scene-effects.ts','app/scene-terrain-runtime.ts','app/scene-camera-runtime.ts','app/scene-worship-acquisition.ts','app/object-panels.ts','app/scene.ts'}
global_files={'app/computer-runtime.ts','app/computer-spells.ts','app/campaign-command-runtime.ts','app/campaign-runtime.ts','app/popscript.ts','app/mana.ts','app/tribe-turns.ts','app/building-damage.ts','app/game-clock.ts'}
timestamps={'app/world-effects.ts','app/training-conversion.ts','app/building-occupants.ts','app/live-building-entry.ts','app/vault.ts','app/level-start-runtime.ts','app/live-command.ts'}
for line in raw.splitlines():
 path,n,text=line.split(':',2); n=int(n);key=(path,n)
 if key in specific:cat,owner,basis=specific[key]
 elif key in logical:cat,owner,basis='ANIMATION_STAMP','logical animation admission','004ed700 stamp+0x18 and004ee7b0 global sprite animation serial; explicitly separate from person+0x2e. Current elapsed-time adapter uses matching World.turn stamps.'
 elif path in ui:cat,owner,basis='PRESENTATION_OR_OBSERVATION','UI/frame/cache/event metadata','No class1 scheduling phase replacement; includes propagated panel blink/global frame aliases and diagnostic timestamps.'
 elif path in global_files:cat,owner,basis='NONPERSON_GLOBAL_CLOCK','world/tribe/AI/campaign clock','World/tribe/script process context. Native anchors include004ec6f0,00418e30,004ecac0,004d0860; no per-Unit identity at predicate.'
 elif path in timestamps:cat,owner,basis='EVENT_TIMESTAMP','activity/input/start/completion time','Global activity and elapsed-time contract, not wrapping person allocation byte.'
 elif path=='app/combat-runtime.ts':cat,owner,basis='EVENT_TIMESTAMP','encounter/fight start','Elapsed motion/action timestamp, not class1 visit phase.'
 elif path=='app/live-people.ts' and n==835:cat,owner,basis='EVENT_TIMESTAMP','legacy fight animation elapsed time','Compares world seconds against fight.started; independent animation adapter.'
 elif path=='app/scene-entities.ts':cat,owner,basis='PRESENTATION_OR_OBSERVATION','morph/frame context','Global elapsed morph/frame operation, not person scheduling byte.'
 elif path=='app/hut-smoke-runtime.ts':cat,owner,basis='OTHER_CLASS_PHASE_ADAPTER','secondary once-per-turn owner','Secondary effects stamp; does not visit class1 people.'
 elif path=='app/world-turn.ts' and 900<=n<=960:cat,owner,basis='OTHER_CLASS_PHASE_ADAPTER','trigger/head cached worship sample','Class6 trigger work/cached count; existing world-phase approximation, not person byte.'
 elif path=='app/world-turn.ts' and n in (507,518,1074):cat,owner,basis='NONPERSON_GLOBAL_CLOCK','logical world turn/time/mana mirror','Global scheduler bookkeeping.'
 elif path=='app/world-turn.ts' and n in (820,821,828):cat,owner,basis='NOT_WORLD_TURN','Lightning local effect turn','fx.lightning.turn, independent spell effect countdown.'
 elif path in ('app/land-bridge.ts','app/lightning.ts'):cat,owner,basis='NOT_WORLD_TURN','spell-effect progress','Local effect age, not World.turn or a class1 byte.'
 elif path=='app/camera-input.ts':cat,owner,basis='NOT_WORLD_TURN','camera angular velocity','Field named turn denotes rotation, not time.'
 elif path=='app/worship-acquisition.ts':cat,owner,basis='NOT_WORLD_TURN','acquisition animation geometry','Randomized turn field, independent effect/presentation record.'
 else:raise RuntimeError((path,n,text))
 rows.append(dict(path=path,line=n,code=text.strip(),classification=cat,owner=owner,basis=basis))
assert len(rows)==109
research=root.parent/'training-native-comparison-20261010/decomp';manifest=json.loads((research/'exports.json').read_text())
bindings=[]
for name in ['004d4690','0051fed0','004d32b0','004d43a0','004d7330','004d9580','004673b0','004ee7b0','004ed700','00418e30','004ecac0','004d0860']:
 p=research/'generated'/f'{name}.c';h=hashlib.sha256(p.read_bytes()).hexdigest();assert manifest['files'][name+'.c']==h
 bindings.append(dict(entry=name,path=str(p),sha256=h,manifestMatch=True))
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),appDiffSha256=hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary','--','app'])).hexdigest(),method='Read-only exhaustive rg property-use inventory in app/*.ts, plus source inspection of turn-context aliases and retained original exports. No native/game/test execution.',counts=dict(collections.Counter(r['classification'] for r in rows)),rows=rows,sourceBindings=bindings,additionalPhaseAdapters=[dict(owner='Shield, Bloodlust, Invisibility duration',app='spell-effects-runtime.ts:246,286,379; world-turn.ts:512-514',source='004d32b0 tail: bytes+a3,+a5,+b1 decrement only on person+2e &7==0.',status='Existing remaining-world-turn adapters; not direct world.turn expressions. Native phase/visit eligibility remains unmodelled. A full timer representation/epilogue migration requires separate explicit scope and tests; do not blindly decrement eight or reinterpret old saves.'),dict(owner='Shield renderer expiry visibility',app='scene-entities.ts:514-519',source='004673b0 preceding Bloodlust branch tests+a5<16 and+2e&2.',status='Existing procedural Shield has no expiry blink at all. Missing renderer behavior, not a world.turn assignment to replace.')],limits=['No claim of complete native scheduler parity or causality for M4 input path rejection.','Automatic idle-Hut adapter source mapping remains unresolved; this inventory exposes it rather than inventing an original gate.','Categories explicitly preserve independent global, presentation and other-class clocks.'])
(out/'world-turn-consumer-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(head=report['head'],counts=report['counts'],sourceBindings=len(bindings),rows=len(rows)),indent=2))
