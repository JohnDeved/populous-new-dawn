#!/usr/bin/env python3
"""Canonical file/source binding and finite lifetime ranges; no original execution."""
from pathlib import Path
import argparse,json,struct
import capstone
import constructor_candidate as b
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();assert not args.out.exists()
 pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[];decoded={};checks=[]
 for lo,hi in [(0x486550,0x48669d),(0x492be0,0x492c23),(0x4858d7,0x4858e6),(0x485e60,0x485f7f),(0x4859a9,0x485a03),(0x485a7b,0x485a8b),(0x461e59,0x461eb5),(0x42b69e,0x42b762)]:
  raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw)
  decoded.update({i.address:i for i in ins});windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
 def bind(pc,m,op):
  i=decoded[pc];assert (i.mnemonic,i.op_str)==(m,op),(hex(pc),i.mnemonic,i.op_str)
  checks.append({'pc':hex(pc),'bytes':i.bytes.hex(),'assertion':m+' '+op})
 for pc,target in [(0x4859a9,0x485660),(0x4858d7,0x486550),(0x4865df,0x525f80),(0x48665f,0x525f80),(0x48666c,0x492be0),(0x4859fe,0x485e60),(0x485a86,0x42b590)]:bind(pc,'call',hex(target))
 for pc,m,op in [(0x48656a,'mov','esi, 0x9608ba'),(0x486590,'mov','al, byte ptr [edi + 0x89b79a]'),(0x48659c,'push','0x5a1e70'),(0x4865d4,'push','0xfffffff'),(0x4865d9,'push','esi'),(0x486674,'lea','eax, [esi + 0x2000]'),(0x48667a,'add','esi, 0x3108'),(0x486681,'mov','dword ptr [esi - 8], eax'),(0x461e60,'cmp','word ptr [eax], 0x3eb'),(0x461e65,'je','0x461eb0')]:bind(pc,m,op)
 assert pe.read(0x5a1e70,6)==b'CPSCR\0'
 hfile=b.GAME/'levels/levl2003.hdr';hdr=hfile.read_bytes();assert hdr[88]==3 and hdr[89:91]==bytes([12,12])
 script=b.GAME/'levels/cpscr012.dat';data=script.read_bytes();assert len(data)==0x3108
 assert b.sha(data)=='d5dfcd826f77909a64cca03ca9d9e3d351d2a7cb3f63eb8ba811b59916e83601'
 assert struct.unpack('<4H',data[:8])==(12,0x3eb,0x3e8,0x3f6)
 slots=[0x9608ba+i*0x3108 for i in range(2)]
 profileRanges=[(0x9606fe,12),(0x96070a,0x38*4),(0x9607ea,0x30*4),(0x9608aa,16),(0x96070a,0xe*4),(0x960712,8),(0x96071e,8*4),(0x960742,2*0xe*4),(0x96081a,2*0xc*4),(0x9608b6,4)]
 assert max(a+n for a,n in profileRanges)==slots[0]
 for slot in slots:
  assert all(not(a<slot+8 and slot<a+n) for a,n in profileRanges)
  assert slot+0x3100>=slot+8
 assert all(i.mnemonic!='call' for i in decoded.values() if 0x485e60<=i.address<0x485f7f)
 # Existing admitted prefix retained every native write; these six-byte spans
 # have neither a write nor an initial supply. No new CPU/run is used here.
 receipt=HERE/'sunlight-run01/sunlight-result.json';r=json.loads(receipt.read_text())
 assert b.sha(receipt.read_bytes())=='e61d5f6bbf61ff8692fc948d4560aab525233b9996b668c93f73c0b8ce436f7a'
 for slot in slots:
  assert not any(slot+2<=int(w['address'],16)<slot+8 for w in r['memoryWrites'])
 # Exact genuine caller continuation after the possible fragment makes its
 # volatile outputs dead; this remains an alternative, not the chosen proposal.
 for pc,m,op in [(0x42b6a3,'add','esp, 4'),(0x42b6b7,'lea','eax, [esi + 0x917]'),(0x42b6bd,'xor','edx, edx'),(0x42b736,'mov','ecx, 0x20')]:bind(pc,m,op)
 output={'status':'SOURCE_BOUND_CANONICAL_SCRIPT_ENTRY_CONDITION','originalInstructionsExecuted':0,'nativeCpuConstructed':False,'script':b.file_record(Path(__file__)),'executable':b.file_record(b.EXE),'header':b.file_record(hfile),'cpscr012':b.file_record(script),'checks':checks,'windows':windows,
  'selection':{'tribeCountFromHdr88':3,'nonplayerIterations':2,'scriptIndicesHdr89And90':[12,12],'fileName':'levels/cpscr012.dat','bytesPerScript':len(data),'firstFourWords':list(struct.unpack('<4H',data[:8]))},
  'sourceOrderedCalls':['004859a9→00485660','004858d7→00486550','004865df or0048665f→00525f80 transport','return004858dc..e5','004859fe→00485e60','00485a86→0042b590'],
  'entrySpans':[{'tribeId':i+1,'slotBase':hex(a),'address':hex(a+2),'bytes':6,'bytesHex':data[2:8].hex(),'words':list(struct.unpack('<3H',data[2:8])),'firstWordEqualityTo0x3eb':True,'rebasedTailPointerAddress':hex(a+0x3100),'rebasedTailPointerValue':hex(a+0x2000)} for i,a in enumerate(slots)],
  'lifetime':{'scriptLoaderTail':'Writes only slot+0x3100 pointer after each successful transport; preserves offsets+2..+7.','hdrLoaderAfterScriptCall':'Only POP EDI/ESI/EBX, stack restoration, RET.','interveningProfileHelper':'No calls; exact source-bound write ranges under HDRcount3 end at009608ba exclusive.','profileWriteRanges':[{'address':hex(a),'bytes':n,'endExclusive':hex(a+n)} for a,n in profileRanges],'globeTail':'Remaining profile switch only changes0089b741 bits and stack arguments; no script span destination.','admittedPrefix':'All retained native committed writes are disjoint from both six-byte spans; checked against fixed result hash.'},
  'boundary':'A successful canonical-file transport is an explicit entry/data condition, not an observed OS read and not permission to return fabricated success from00525f80. Supply only reviewed source-derived memory bytes; do not run filesystem/OS helpers or change original code.',
  'fallbackNotMixed':{'fallbackFirstFourWords':[12,0x3eb,0x3ec,0x3fb],'source':'00492be0 only after both file-read attempts report failure.','warning':'Do not substitute fallback last words for actual CPSCR012 bytes. Both paths share first0x3eb, but an exhaustive success/failure/partial-read proof is not claimed.'},
  'recommendedNextContract':'Bind this canonical script source condition and execute real CMP/JE00461e60/65. No new script projection needed for the conditioned pre-loader segment. Keep other script bytes unknown unless separately sourced.','laterReader':'004615f0 passes base0095d7b2+tribeId*0x3108 to0048c6b0; it consumes these opcode words. No global irrelevance/constructor closure claim.',
  'projectionAlternative':'No implementation. If canonical script transport were unavailable, only00461e60..00461eb0 could be projected with all six bytes plus EAX/ECX/EDX/arithmetic flags tainted. Exact live-out kills retained, but later consumption must abort.'}
 b.json_write(args.out,output);print(json.dumps({'status':output['status'],'windows':len(windows),'exactAssertions':len(checks),'scriptSha256':output['cpscr012']['sha256'],'entrySpans':output['entrySpans'],'originalInstructionsExecuted':0}))
if __name__=='__main__':main()
