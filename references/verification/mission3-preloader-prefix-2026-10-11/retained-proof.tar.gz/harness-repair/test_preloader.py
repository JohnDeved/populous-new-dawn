"""Synthetic x86/host contracts only. No canonical original execution."""
import struct,unittest
from unittest.mock import patch
import unicorn
from unicorn import x86_const as x
import preloader_candidate as z
b=z.b
CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00
class PreloaderTests(unittest.TestCase):
 def make(self,code=b'\x90'):
  cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:cpu.mem_map(a,4096)
  cpu.mem_write(CODE,code+b'\xc3')
  e=z.Preloader(cpu,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(code)+1)],enforce_prefix=False,enforce_palette_context=False,enforce_sunlight=False)
  e.reg_supply('esp',STACK,b.MASK32,'synthetic stack');e.supply(STACK,struct.pack('<I',STOP),'synthetic return');e.reg_supply('eflags',2,b.DF,'synthetic DF')
  return e
 def test_masked_supply_changes_only_requested_bits(self):
  for value in [0,8]:
   e=self.make();e.cpu.mem_write(DATA,b'\xff\xff\xa5')
   e.masked_supply(DATA,2,value,0x108,'synthetic land alternative')
   self.assertEqual(int.from_bytes(e.cpu.mem_read(DATA,2),'little'),(0xffff&~0x108)|value)
   self.assertEqual(e.shadow.get(DATA,2),0x108);self.assertEqual(bytes(e.cpu.mem_read(DATA+2,1)),b'\xa5');self.assertEqual(e.shadow.get(DATA+2,1),0)
   self.assertEqual(e.supplies[-1]['knownMask'],'0x108');self.assertEqual(e.supplies[-1]['valueUnderKnownMask'],hex(value));self.assertEqual(e.event_ordinal,0)
 def test_masked_supply_rejects_values_outside_mask(self):
  for value,mask in [(2,1),(0,0x10000),(-1,0xff)]:
   e=self.make()
   with self.assertRaises(b.Blocked):e.masked_supply(DATA,2,value,mask,'synthetic')
 def test_load_predicate_does_not_know_adjacent_bits(self):
  e=self.make();e.cpu.mem_write(DATA,b'\xff');e.masked_supply(DATA,1,0,2,'synthetic load predicate')
  self.assertEqual(e.shadow.get(DATA,1),2);self.assertEqual(bytes(e.cpu.mem_read(DATA,1)),b'\xfd')
 def test_known_predicate_branch_succeeds_with_other_bits_unknown(self):
  code=b'\xf6\x05'+struct.pack('<I',DATA)+b'\x08\x75\x00'
  for value in [0,8]:
   e=self.make(code);e.masked_supply(DATA,2,value,0x108,'synthetic mode bits');e.run(CODE,STOP)
   self.assertEqual(e.committed,3)
 def test_unknown_adjacent_predicate_still_aborts(self):
  code=b'\xf6\x05'+struct.pack('<I',DATA)+b'\x04\x75\x00';e=self.make(code);e.masked_supply(DATA,2,0,0x108,'synthetic mode bits')
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
  self.assertEqual(e.committed,1)
 def test_sunlight_checkpoint_commits_before_assertion(self):
  e=self.make();e.enforce_sunlight=True;e.sunlight_manifest={'synthetic':True}
  e.cpu.mem_map(0x42b000,4096);e.cpu.mem_write(z.s.STOP,b'\x90');e.windows.append((z.s.STOP,z.s.STOP+1));e.cpu.reg_write(x.UC_X86_REG_EIP,z.s.STOP)
  e.pending={'address':0x100000,'journal':[],'registers':{'edx':b.MASK32},'flags':b.DF,'call':None,'return':None}
  seen=[]
  def check(engine,manifest):
   self.assertIsNone(engine.pending);self.assertEqual(engine.committed,1);self.assertEqual(engine.shadow.reg_get('edx'),b.MASK32);self.assertEqual(manifest,{'synthetic':True});seen.append(True);return ['verified']
  with patch.object(z.s,'assert_claims',check):e._code(e.cpu,z.s.STOP,1,None)
  self.assertEqual(seen,[True]);self.assertEqual(e.sunlight_claims,['verified']);self.assertEqual(e.pending['address'],z.s.STOP)
 def terrain_fixture(self):
  e=self.make();a=0x800000;n=0x40000;e.cpu.mem_map(a,n);e.shadow.regions.append((a,a+n,bytearray(n)))
  mask=bytes.fromhex('040000000000000000fc000000000f00')*16384
  e.shadow.put(a,n,int.from_bytes(mask,'little'));e.cpu.mem_write(a,bytes(255&~v for v in mask))
  return e,{'base':hex(a),'bytes':n,'records':16384,'stride':16,'exactKnownMaskPerRecordHex':mask[:16].hex()}
 def test_full_terrain_bytecoverage_allows_unknown_preserved_values(self):
  e,c=self.terrain_fixture();r=z.assert_terrain(e,c);self.assertEqual(r['bytes'],0x40000);self.assertFalse(r['wholeTerrainKnown'])
 def test_terrain_last_record_unknown_or_wrong_bit_fails(self):
  e,c=self.terrain_fixture();a=int(c['base'],16)+c['bytes']-2;e.shadow.put(a,1,0)
  with self.assertRaisesRegex(b.Blocked,'coverage'):z.assert_terrain(e,c)
  e,c=self.terrain_fixture();a=int(c['base'],16)+c['bytes']-2;e.cpu.mem_write(a,b'\xff')
  with self.assertRaisesRegex(b.Blocked,'not clear'):z.assert_terrain(e,c)
 def test_case_specs_are_explicit_and_keep_real_script_bytes(self):
  for case,v in z.CASES.items():
   c=z.entry_contract(case);self.assertEqual(c['landCase'],case);self.assertEqual(c['maskedSupplies'][0]['valueUnderKnownMask'],hex(v))
   self.assertEqual([row['bytesHex'] for row in c['scriptSpans']],['eb03e803f603']*2)
   self.assertEqual([row['value'] for row in c['rootArguments']],[25,6,0]);self.assertEqual([row['value'] for row in c['ids']],list(range(4)))
  a={r['name']:r for r in z.known_fields('land-clear')};c={r['name']:r for r in z.known_fields('land-set')}
  self.assertEqual(a['tribe1_control_kind']['expectedValue'],1);self.assertEqual(c['tribe1_control_kind']['expectedValue'],2)
  for fields in [a,c]:
   for i in [1,2]:self.assertEqual(fields[f'tribe{i}_script_words']['source'],'canonical successful-transport input, preserved by genuine prefix; not a native prefix write')
 def test_selected_fields_do_not_overlap_or_claim_full_terrain(self):
  for case in z.CASES:
   seen=set()
   for f in z.known_fields(case):
    a=int(f['address'],16);span=set(range(a,a+f['bytes']));self.assertFalse(span&seen,f['name']);seen|=span
   self.assertEqual(len(z.bit_fields(case)),8)
   self.assertFalse(set(range(0x8a03e4,0x8e03e4))&seen)
 def test_approval_binds_case_inputs_checkpoint_and_conditions(self):
  keys=['entry','expectedStop','allowedWindows','entryContract','sunlightCheckpoint','selectedObservables','selectedBitObservables','terrainContract','finalBoundaryContract','requiredUnknownOutputs','conditionalAssumptions','newProjectionCount','expectedInvalidationEvents','eventSchema','sourceInputMap']
  m={'source':{'observedSourceHead':'synthetic','trackedStatus':''},'inputs':[],'landCase':'land-clear',**{k:{} for k in keys}};a=z.approval_bindings(m);z.validate_approval(a,m)
  for key in keys:
   old=m[key];m[key]={'changed':True}
   with self.assertRaises(b.Blocked):z.validate_approval(a,m)
   m[key]=old
  m['landCase']='land-set'
  with self.assertRaises(b.Blocked):z.validate_approval(a,m)
  m['landCase']='land-clear';a['parentReleasedRunLane']=False
  with self.assertRaises(b.Blocked):z.validate_approval(a,m)
 def test_no_approval_cannot_construct_native_cpu(self):
  with patch.object(b,'load_module',side_effect=AssertionError('must not load original CPU')):
   with self.assertRaises((b.Blocked,KeyError)):z.execute(None,None,{},None,None)
 def test_loader_target_is_still_forbidden(self):
  e=self.make();e.windows=z.WINDOWS
  with self.assertRaisesRegex(b.Blocked,'forbidden'):e.check_target(0x42b230)
  e.check_target(0x42b632)
  with self.assertRaises(b.Blocked):e.check_target(z.STOP)
 def test_frozen_dependencies_and_contract_hashes(self):
  self.assertEqual(b.sha(z.SUN.read_bytes()),z.SUN_SHA);self.assertEqual(b.sha(z.MAP.read_bytes()),z.MAP_SHA)
  self.assertEqual(b.sha(z.SCRIPT.read_bytes()),z.SCRIPT_SHA)

if __name__=='__main__':unittest.main(verbosity=2)
