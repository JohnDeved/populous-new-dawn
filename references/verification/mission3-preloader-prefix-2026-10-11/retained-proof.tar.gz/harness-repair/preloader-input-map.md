# One coherent next segment before the loader

Source-only result. No new driver and no original execution. The bounded target is
the existing actual 0042b590 prefix continued from 0042b5a8 through 0042b637,
stopping before CALL 0042b230 at 0042b638. The static checker retains 17 complete
instruction windows and 26 exact instruction assertions in preloader-input-map.json.
The first static attempt had a mistyped expected CALL displacement; its failed log
is retained. The corrected second check passed against canonical bytes.

## Already available, with real producers

- Accepted prefix EDI=008979d3, EBX=0 and conditioned DF=0 are sufficient for the
  caller's next command-ring zero. 0044fa30 does not change EDI or EBX.
- 0044fa30 masks all 16,384 fixed-address terrain records in the 0x40000-byte range.
  It clears flag bit2 at offset0, high six bits of WORD+8 and low four bits of
  BYTE+14. Prior terrain remains unknown. DEC ECX supplies the JNE flags, so no
  unknown terrain bit drives an address or decision in this helper.
- 0042b5ad/af/b4 genuinely clear 6,024 bytes, all four 1,506-byte command rings at
  008979d3..0089915b. Thus the selected ring's index and counter are known zero.
  0042b5b6 then writes the known EBX=0 to turn0089d184, already reset earlier.
- start_mana005aa40c is already supplied as 30000 by the actual constant.dat
  descriptor projection. 0042b70d zeroes tribe mana before 0041a4f0 adds it.
- All shown nested helpers are integer masks, arithmetic, copies or zeroing and
  use the already reviewed finite semantics. No x87, OS, import or clock leaf
  appears in this bounded closure. New windows/conditions still need review.

## Exact entry facts still needed

1. Player byte0089c6f0, consumed at0043e320 as a signed address index and compared
   in0042b68e. Successful New Game's004c3340 writes0. Bind that value's lifetime
   to selected Mission3; the accepted diagnostic has not supplied it.
2. Land-flags mask0x100 at0089c661, tested as BYTE0089c662 bit0 at0047ac30.
   New Game calls0047ac30 at004c34b2. Both normal-return branches leave that bit
   clear, regardless of the entering bit. This is a concrete producer property,
   subject to unchanged lifetime; it is not a whole flagword zero. A clear bit
   selects the real 60-byte temp-command zero, so the following 15-byte ring
   insertion is fully known. A set-bit alternative leaves old temp bytes unknown.
3. Tribe count0096eac0=3 from levl2003.hdr byte88, loaded and stored by
   004859b1/b6. Outer0042b7f0 initializes common fields for all four slots; its
   active reset loop calls0042b660 and00436ff0 only for indices0,1,2.
4. Land-flags bit0x08 at0089c661, tested0042b685, remains prior-history dependent.
   Keep the previously identified labeled0/8 alternatives unless its actual
   producer/lifetime is established. This is the same unresolved mode fact.
5. Load mask0x200 at0089c665, tested via BYTE0089c666 bit1 at0042b7d0. The ordinary
   selected route clears it at0048598a and the gate004859c0/7 reaches0042b590 only
   on clear. Bind that synchronous path, without inventing other load bits.
6. For land08 clear, nonplayer reset00461d70 consumes each tribe's byte+c22 as an
   index. Startup004a512f→0042c150 writes IDs0,1,2,3 at0089ddea+i*0xc65. Neither
   the accepted prefix nor0042b7f0 rewrites these IDs. Bind their lifetime or an
   explicit earlier producer composition; do not infer them from zero memory.

## The concrete remaining nested frontier

For player0, count3, identity IDs and land08 clear, tribes1 and2 reach00461e60:
WORD[0095d7b4 + tribeId*0x3108] == 0x3eb. The exact words are009608bc and009639c4.
The accepted trace has no initial supply or write to either word. The real branch
must not be selected from mapped zeros.

Earlier successful New Game calls0042b7f0 at004c34a8. With compatible count, IDs
and mode, its same00461d70 call always leaves each first word0x3eb, on either
returning branch. This is the smallest source producer lead. Its second and third
words are written only when the first word was unequal, so they cannot become
known merely from the final first-word predicate. Bind the earlier call and
lifetime, or admit an explicit input condition. No diagnostic should be run just
to hit this already identified unknown branch.

The 240-byte table0059d878..0059d968 is copied by REP MOVSD at00461d9c into
tribe+0x36e. It is mutable initialized data; it remains unknown without provenance.
The current segment only copies those entries, so unknown masks can safely follow
them. The two nested leaves004f52c0 and004d1420 operate on other already-zeroed
fields. Table function pointers are not called here. Do not claim complete tribe
state known. Old bits in tribe+0x93d and+0x941 similarly survive pure masks.

## Boundary and later parameters

After tribe reset, the caller performs its remaining fixed zeroing and copies its
three arguments before0042b638. Ordinary globe arguments are25,6,0: HDR[96..98]
become0089b7a1/a2/a3, are zero-extended at004859d8..f2, and are pushed at
00485a83/84/85. They are not supplied in the accepted harness. They may remain
explicit unknown stack copies if this segment stops before the loader, but actual
loader consumption requires that source-bound transport contract.

A later candidate should compose this entire segment once, preserving real order
and the old sunlight checkpoint, and predeclare command/tribe/mask observables.
It should not issue one native probe per helper. Current execution admission ends
at0042b5a8; this source map grants no further execution.
