# Coherent pre-loader candidate: current review boundary

Original execution status: NOT RUN for this extension. The accepted sunlight run
and all four earlier frozen drivers remain unchanged. This separate candidate
requires a fresh case-bound ACCEPT_COHERENT_PRELOADER_PREFIX verdict and explicit
parent lane release before constructing an original CPU.

## Exact scope

The entry remains 0042b590. It retains the complete prior reset/palette checkpoint
at 0042b5a3 and sunlight checkpoint at 0042b5a8, committing the preceding native
instruction before each assertion. It then executes the real terrain-mask helper,
all four command-ring initialization, command-buffer clearing/insertion, active
tribe reset and the caller's remaining fixed zeroing/argument pushes. The stop is
0042b638 BEFORE CALL 0042b230. That target remains explicitly forbidden.

New direct calls: 0044fa30,0047ac30,0043e320,0042b7f0. The finite nested closure is
0042b660,00436ff0,00461d70,004f52c0,004d1420,0041a4f0. There are no new instruction
semantics, x87/OS/import/clock behaviors, function stubs or projections. The only
three omissions are the inherited context-specific camera fragments, with their
unchanged normal/no-fault return condition.

## Entry contract and case labels

--land-case is mandatory and has no default. land-clear supplies bit0x08=0;
land-set supplies bit0x08=1. Neither is claimed to be actual prior Mission3 history.
Both carry these explicit source-bound conditions:

- Player0089c6f0=0 from New Game004c3340, unchanged to the selected prefix.
- Land mask0x100 clear after New Game004c34b2→0047ac30 returns, unchanged to entry.
  Its two real return paths both clear that bit. No whole flagword zero is assumed.
- Load mask0x200 clear from ordinary globe0048598a and004859c0/7 selection gate.
- Tribe count0096eac0=3 from canonical HDR byte88 via004859b1/b6.
- Four identity tribe IDs0..3 from startup004a512f→0042c150, unchanged to entry.
- Root arguments25,6,0 from HDR bytes96..98, original zero-extension/push order.
- Successful canonical CPSCR012 file transport before this entry, as below.

Masked entry supplies expose post knownMask0x108 on two bytes at0089c661 and
knownMask0x02 on byte0089c666. Only the requested value bits are changed; adjacent
concrete placeholder bits are retained and unknown. They are not silently known
zeros. Supplies are recorded before native observation; they are not native writes.
Earlier read-mask traces legitimately gain these supplied bits; only the old
selected checkpoints are required to remain equal, not the complete old traces.

The existing successful/live/disjoint abstract palette allocation, unknown data
and scoped pointer expiry, 40 canonical trig-word condition/protection, source
constant.dat projection and diagnostic cdecl stack/DF conditions also remain.

## Canonical script data replaces the proposed omission

The historical preloader-input-map.md identified an unresolved script comparison.
Current accepted source contract preloader-input-map02.json and
script-transport-proof01.json supersede that frontier; the historical file stays
unchanged. The new candidate does not skip the comparison or choose its branch.

Mission3 HDR[89..90]=12,12. Original004859a9→00485660 calls00486550 at004858d7,
which copies CPSCR012 into the two nonplayer blocks before00485a86→0042b590.
The recovered file is exactly0x3108 bytes, SHA256:
d5dfcd826f77909a64cca03ca9d9e3d351d2a7cb3f63eb8ba811b59916e83601.
Its first four WORDs are12,0x3eb,0x3e8,0x3f6. The candidate supplies only its six
reviewed bytes at009608bc and009639c4: eb03e803f603. Other script bytes remain
unknown. The file-read routines are neither executed nor given invented returns;
this is an explicit canonical successful-transport entry condition.

The script-loader tail changes only slot+0x3100 pointers. HDR-loader tail restores
and returns. The intervening00485e60 has no calls and, with count3, all writes end
at009608ba exclusive, immediately before the first script slot. Extra loop ends
are009607b2 and0096087a. The accepted sunlight write trace does not touch either
six-byte span. Exact source windows and independent lifetime review are retained.

The actual CMP/JE00461e60/65 sees0x3eb and preserves the following real file words.
Fallback00492be0 would instead put0x3ec,0x3fb there; those fallback values are
never supplied. Later004615f0→0048c6b0 consumes this script buffer, so no global
irrelevance or complete constructor-closure claim follows from this boundary.

## Selected observations fixed before execution

Each case predeclares101 nonoverlapping fully known memory fields/regions:
all43 sunlight fields, command/queue/auxiliary zero regions, caller fixed values,
selected tribe counts/list pointers/active flags/IDs/control-kind/mana, the two
script six-byte spans and the three genuinely copied loader arguments. IDs and
script words are explicitly identified as source-conditioned inputs preserved by
the prefix; they are not newly proved native producers. Exact hashes/values are
in each preflight.

Eight additional bit predicates cover only the supplied land/load bits and active
tribe+0x93d/+0x941 reset bits, leaving unrelated preserved bits unknown. Mana30000
comes from the already-applied constant descriptor after each destination is
really zeroed. Control-kind is2 for player0,1 for nonplayer tribes1/2 in land-clear,
and2 for all three in land-set. The fourth tribe is inactive; its untouched
control-kind is not claimed known.

All16,384 terrain records across262,144 bytes must have exactly this known-mask
pattern per16 bytes: 040000000000000000fc000000000f00, with all masked values0.
This proves full coverage of the three source masks, not full terrain values or
terrain zero. Unknown prior terrain bits never determine the fixed addresses or
loop branch; DEC ECX supplies branch flags. The later full terrain reset is outside
this candidate.

The final register contract is EAX25,EBX0,ECX0,EDX6,EDI0096eaba,ESP=initialSTACK-20,
EIP0042b638, all known. ESI/EBP remain unknown. Flags retain known mask0xcc5,
masked value0x44 and unknown AF from the last real XOR. Three stacked arguments
are25,6,0, while the outer saved EBX/EDI eight bytes remain unknown.

Unknown requirements persist for both camera words, palette contents/cache,
expired palette pointer and unsupplied alias0059df24. In land-clear,240 copied
bytes at each nonplayer tribe+0x36e remain unknown: mutable AI defaults were copied
but not fabricated as known. No complete tribe-state claim is made.

Exact new call counts are predeclared: each direct helper once, three calls each
to0042b660,00436ff0 and0041a4f0; land-clear additionally has two calls each to
00461d70,004f52c0 and004d1420, while land-set has zero of those. There may be no
allocation, authored record, open call, aborted instruction or extra projection.

## Recording and gates

The same observer-order stream retains reads, committed byte writes and the same
12 explicit invalidations. No new invalidation is introduced. Ordinals remain
contiguous; attempted writes cannot acquire committed ordinals. Masked initial
supplies carry explicit masks for an independent replay wrapper to verify.

preloader-all-tests02.log records100 passing synthetic tests:86 inherited tests
plus14 new tests covering nonzero unknown placeholder bits, masked known/unknown
predicates, exact checkpoint ordering, whole terrain coverage and last-record
failure, both case contracts, scope/hash binding and forbidden loader target.
Both case preflights were prepared without original instruction execution.

The gate binds the selected case, all five driver hashes, exact source/input map,
CPSCR/header/input hashes, the full inherited checkpoint and every new condition,
observable/window/boundary before native_cpu construction. Each future released
run must use a new output directory,2,000,000-instruction/180-second native bound
and an outer process receipt/timeout. No run is authorized by this document.
