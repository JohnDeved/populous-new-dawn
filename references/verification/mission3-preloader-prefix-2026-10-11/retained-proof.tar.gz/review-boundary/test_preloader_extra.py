"""Reviewer synthetic host/x86 tests only; no canonical code dispatch."""
from pathlib import Path
import sys,struct,unittest
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'harness-repair'))
import test_preloader as t
z,b=t.z,t.b
class Extra(unittest.TestCase):
 def test_script_fields_are_labeled_supplied_and_preserved(self):
  for case in z.CASES:
   fields={f['name']:f for f in z.known_fields(case)}
   for name in ['tribe1_script_words','tribe2_script_words']:
    source=fields[name]['source'].lower();self.assertNotEqual(source,'genuine prefix writes');self.assertIn('preserv',source)
 def test_masked_supply_never_promotes_prior_known_neighbors(self):
  e=t.PreloaderTests().make();e.supply(t.DATA,b'\xff\xff','synthetic older complete knowledge')
  e.masked_supply(t.DATA,2,8,0x108,'synthetic restricted boundary')
  self.assertEqual(e.shadow.get(t.DATA,2),0x108);self.assertEqual(e.event_ordinal,0)
  self.assertEqual(int.from_bytes(e.cpu.mem_read(t.DATA,2),'little')&0x108,8)
 def test_masked_supply_requires_source_and_rejects_negative_mask(self):
  for source,mask in [('',0x108),('synthetic',-1)]:
   e=t.PreloaderTests().make()
   with self.assertRaises(b.Blocked):e.masked_supply(t.DATA,2,0,mask,source)
 def test_unknown_240byte_copy_remains_unknown_with_nonzero_placeholders(self):
  e=t.PreloaderTests().make(bytes.fromhex('f3a5'));dst=t.DATA+512
  e.cpu.mem_write(t.DATA,bytes([0xa5])*240)
  for reg,value in [('esi',t.DATA),('edi',dst),('ecx',60)]:e.reg_supply(reg,value,b.MASK32,'synthetic copy index')
  e.run(t.CODE,t.STOP)
  self.assertEqual(bytes(e.cpu.mem_read(dst,240)),bytes([0xa5])*240)
  self.assertEqual(e.shadow.get(dst,240),0);self.assertEqual(len(e.write_events),240)
  self.assertEqual(len(e.read_events),61) # 60 iterations plus root RET
  self.assertEqual(sorted(x['eventOrdinal'] for x in e.read_events+e.write_events),list(range(301)))
 def test_real_equality_branch_needs_only_first_word_not_following_words(self):
  code=bytes.fromhex('66813d')+struct.pack('<I',t.DATA)+bytes.fromhex('eb037400')
  e=t.PreloaderTests().make(code);e.supply(t.DATA,bytes.fromhex('eb03'),'synthetic source-backed first word');e.cpu.mem_write(t.DATA+2,b'\xaa\xbb\xcc\xdd')
  e.run(t.CODE,t.STOP);self.assertEqual(e.shadow.get(t.DATA+2,4),0)
  e=t.PreloaderTests().make(code);e.cpu.mem_write(t.DATA,bytes.fromhex('eb03'));e.shadow.put(t.DATA,2,0x7fff)
  with self.assertRaises(b.Blocked):e.run(t.CODE,t.STOP)
  self.assertEqual(e.committed,0)
if __name__=='__main__':unittest.main(verbosity=2)
