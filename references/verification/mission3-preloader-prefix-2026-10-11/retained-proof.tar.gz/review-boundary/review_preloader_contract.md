# Coherent pre-loader continuation: source-only review

The finite continuation is 0042b5a8 through 0042b637, stopping at 0042b638 before
the loader CALL. The existing actual 0042b590 entry and sunlight checkpoint stay
intact. No driver change or original execution was performed by this reviewer.

## Accepted source closure

The author's initial input map matches 17 canonical instruction windows and 26
exact assertions. The finite closure has the four direct helpers 0044fa30,
0047ac30, 0043e320 and 0042b7f0, plus 0042b660, 00436ff0, 00461d70, 004f52c0,
004d1420 and 0041a4f0. It contains no OS/import/x87/clock call.

The real prefix supplies the command-ring zero and terrain masks. Four command
rings occupy [008979d3,0089915b); all 6,024 bytes are zeroed before the selected
15-byte insertion. Terrain uses fixed 16-byte records, clearing only the declared
bits; prior terrain contents remain otherwise unknown. Starting mana 30,000 is
already source-bound through constant.dat and is added after the real mana zero.
The 240-byte table copied at 00461d9c stays unknown unless separately bound.

## Script branch now has an actual data supplier

The historical tentative six-byte taint design is unnecessary for the canonical
successful-file case. Use the newly verified transport and lifetime instead:

1. The globe calls 00485660 at 004859a9. Its final helper call at 004858d7 invokes
   00486550 before entering the root prefix at 00485a86.
2. Canonical Mission 3 HDR byte 88 is 3; bytes 89 and 90 are both 12. The script
   loader therefore selects CPSCR012.DAT for two nonplayer script blocks.
3. The available canonical file is exactly 0x3108 bytes, SHA256
   d5dfcd826f77909a64cca03ca9d9e3d351d2a7cb3f63eb8ba811b59916e83601.
   Its first four words are 12, 0x3eb, 1000, 1014. Block bases are 009608ba and
   009639c2, making the consumed first words 009608bc and 009639c4.
4. The loader's subsequent pointer writes are at block+0x3100 and do not touch
   these words. Its HDR parent then only restores registers and returns.
5. The sole intervening globe helper, 00485e60, has no calls. All its global
   stores for HDR count 3 are inside [009606fe,009608ba), ending exactly before
   the first script block. The remaining globe switch writes only header flags.
6. The accepted reset/palette/sunlight prefix has no overwrite of either selected
   six-byte range. The new segment reaches the real equality branch; it preserves
   both following words when the first word is 0x3eb.

This is a successful canonical-file data-transport boundary. It does not execute
or fabricate an OS return. Supply only the bytes required by the selected proof,
or bind any additionally supplied bytes explicitly to their true file offsets.
Do not combine the successful file's following words 1000/1014 with fallback
00492be0 values 0x3ec/0x3fb. That fallback occurs only after both file attempts fail.

## Remaining entry facts and conditions

- Player 0089c6f0=0: exact successful-New-Game writer 004c3340; retain explicit
  unchanged-lifetime condition unless its whole route is separately closed.
- Land flag mask 0x100 clear: successful New Game calls 0047ac30 at 004c34b2;
  both returning paths leave that bit clear. Its intervening lifetime is still
  a condition. Supply only that bit, not adjacent flags or the whole word.
- Tribe count 0096eac0=3: HDR[88] is copied by 004859b1/b6 on the real route.
- Land bit 0x08: history remains unresolved. Any 0/8 cases must be separately
  labeled conditions; neither case may be called the proven actual campaign mode.
- Load mask 0x200 clear: 0048598a and the clear-bit gate 004859c0/c7 bind the
  selected route. Keep unrelated load bits unknown and verify intervening stores.
- Tribe IDs 0,1,2,3: startup 004a512f→0042c150 writes 0089ddea+i*0xc65.
  Keep unchanged lifetime as an explicit condition; no whole tribe-memory seed.
- Caller arguments 25,6,0: HDR[96..98], zero extension at 004859d8..f2 and pushes
  at 00485a83/84/85 supply the exact stack transport. They may be left unknown
  copies if omitted from the selected proof, but cannot be invented for a later
  loader extension.

Land08 clear with player0/count3/identity IDs reaches nonplayer tribes1/2 and
executes their real script equality branches. Land08 set bypasses that path.
The changed source-bound entry flags may increase old reset read masks without
changing the preserved selected sunlight checkpoint; this is expected and must
be described truthfully in new supply/event receipts.

## Fresh execution gate

A coherent candidate must preserve the old 43-field sunlight checkpoint and
predeclare new command/tribe/terrain-mask/CPU/stack observables and required
unknown outputs. Partial flag supplies must record their real masks. All original
code windows and the new source/data/condition contract must be hash-bound.
No new script projection is needed or recommended. The existing three camera
omissions and all old conditions remain unchanged. Original execution stays held
until a frozen candidate passes independent review and the parent releases a lane.

No full tribe state, AI interpreter, allocator independence, constructor, postpass
or gameplay result is established. A concrete later reader is process_tribe_2 at
004615f0, which passes the script base to interpret_script_upper.

## Retained checks

- review_preloader_boundary.py / preloader-boundary-review.json: initial finite
  source map, branch effects and exact native live-out kills. Its alternative
  six-byte taint design is only historical design analysis, not a run admission.
- review_script_transport.py / script-transport-lifetime-review.json: preferred
  actual script transport, six complete canonical windows, all profile store
  sites, file identity and immediate word lifetime.
