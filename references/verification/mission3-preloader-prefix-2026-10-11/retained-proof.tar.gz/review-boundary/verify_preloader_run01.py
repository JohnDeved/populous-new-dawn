"""File-only, source-derived observer-schedule review. NEVER executes original code."""
from pathlib import Path
from collections import Counter
import hashlib,importlib.util,json,struct,sys
import capstone
LABEL=sys.argv[1];assert LABEL in ('clear','set');CASE='land-'+LABEL
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';R=H/f'preloader-{LABEL}-run01'
sha=lambda raw:hashlib.sha256(raw).hexdigest();read=lambda p:json.loads(p.read_text());digest=lambda v:sha(json.dumps(v,sort_keys=True).encode())
PIN={'clear':('e2b325146a78d54061b55e129240fcf7fbebf0f64949756f228739ee447aa6ca',307361),'set':('32de84de613be26a5209eac10ddf0a30795435b67a94da1544405824046ec39b',305667)}
raw=(R/'preloader-result.json').read_bytes();assert sha(raw)==PIN[LABEL][0];r=json.loads(raw);m=read(R/'preloader-preflight.json');v=read(O/f'preloader-{LABEL}-review-verdict.json');a=read(H/f'preloader-{LABEL}-run01-approval-released.json');process=read(H/f'preloader-{LABEL}-run01-process-receipt.json')
assert a['parentReleasedRunLane'] and not v['parentReleasedRunLane']
for k,value in v.items():
 if k!='parentReleasedRunLane':assert a[k]==value,k
assert process['approval']['sha256']==sha((H/f'preloader-{LABEL}-run01-approval-released.json').read_bytes())
assert m==read(H/f'preloader-{LABEL}-preflight02/preloader-preflight.json')
assert process['exitCode']==0 and process['status']=='passed' and not process['trackedStatus']
assert process['sourceHead']==m['source']['observedSourceHead']==a['observedSourceHead']
assert process['driversBefore']==process['driversAfter']
for name,d in process['driversBefore'].items():assert sha((H/name).read_bytes())==d
for name,d in v['reviewedHashes'].items():assert sha((H/name).read_bytes())==d
for name,item in process['artifacts'].items():
 data=(H/name).read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
assert a['sourceBindingSha256']==digest(m['source']) and a['inputBindingSha256']==digest(m['inputs'])
keys=['entry','expectedStop','allowedWindows','entryContract','sunlightCheckpoint','selectedObservables','selectedBitObservables','terrainContract','finalBoundaryContract','requiredUnknownOutputs','conditionalAssumptions','newProjectionCount','expectedInvalidationEvents','eventSchema','sourceInputMap']
assert a['scopeBindingSha256']==digest({k:m[k] for k in keys})
for item in [m['driver'],m['frozenSunlight'],m['frozenPrefix'],m['projectedReset'],m['frozenEngine'],m['sourceInputMap'],m['executable'],*m['inputs']]:
 data=Path(item['path']).read_bytes();assert sha(data)==item['sha256'] and len(data)==item['bytes']
for k in ['scope','landCase','conditionalAssumptions','entryContract','notRun','driver','frozenSunlight','frozenPrefix','projectedReset','frozenEngine']:assert r[k]==m[k],k
assert r['landCase']==CASE and r['status']=='COHERENT_PRELOADER_SELECTED_OBSERVABLES_PASSED'
assert r['attemptedOriginalInstructions']==r['committedOriginalInstructions']==PIN[LABEL][1]
assert not r['openCalls'] and not r['allocations'] and not r['abortedInstructions'] and r['blocker'] is None and r['error'] is None and r['recordsVisited']==0
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);pe=p.PE32(Path(m['executable']['path']))
assert sha(pe.data)==r['identity']['sha256']=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;rows={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);ins=list(cs.disasm(data,lo));assert sum(i.size for i in ins)==len(data) and sha(data)==w['sha256'];rows.update({i.address:i for i in ins})
sunraw=(H/'sunlight-run01/sunlight-result.json').read_bytes();assert sha(sunraw)=='e61d5f6bbf61ff8692fc948d4560aab525233b9996b668c93f73c0b8ce436f7a';sun=json.loads(sunraw);del sunraw
trusted_contract=read(O/'sunlight-run01-replay-contract.json');assert sha((O/'sunlight-run01-replay-contract.json').read_bytes())=='be546ae8bc06d6e740d08408bef4eee727bdab628ad7533ef62d9d8b5b9a6fbf'
assert r['sunlightCheckpointAssertions']==sun['selectedObservableAssertions'] and r['sunlightCheckpointRegisters']==sun['after']['registers']
assert r['prefixObservableAssertions']==sun['prefixObservableAssertions'] and r['prefixBoundary']==sun['prefixBoundary'] and r['projections']==sun['projections']
# Initial bytes are verified independently. Partial supplies explicitly leave
# neighboring bits unknown, irrespective of their concrete mapped placeholder.
initial=list(trusted_contract['initialMemory']);sup=r['suppliedInputs'];assert len(sup)==302
for old,new in zip(sun['suppliedInputs'],sup[:289]):
 for k in ['register','address','size','value','knownMask','sha256']:
  if k in old:assert new[k]==old[k],(k,old,new)
entry=m['entryContract'];expected_extra=[]
for f in entry['maskedSupplies']:
 address=int(f['address'],16);mask=int(f['knownMask'],16);value=int(f['valueUnderKnownMask'],16);n=f['size']
 placeholder=bytearray(n)
 for section in pe.sections:
  for i in range(n):
   delta=address+i-section['va']
   if 0<=delta<section['rawSize']:placeholder[i]=pe.data[section['fileOffset']+delta]
 native=int.from_bytes(placeholder,'little');data=((native&~mask)|value).to_bytes(n,'little')
 expected_extra.append({'address':hex(address),'size':n,'sha256':sha(data),'knownMask':hex(mask),'valueUnderKnownMask':hex(value),'source':f['source']})
 initial.append({'address':hex(address),'size':n,'knownMask':hex(mask),'source':f['source']})
def add_input(f,data):
 expected_extra.append({'address':f['address'],'size':len(data),'sha256':sha(data),'source':f['source']})
 initial.append({'address':f['address'],'size':len(data),'knownMask':hex((1<<(8*len(data)))-1),'source':f['source']})
for f in [entry['player'],entry['count']]+entry['ids']:add_input(f,bytes([f['value']]))
for f in entry['scriptSpans']:add_input(f,bytes.fromhex(f['bytesHex']))
for f in entry['rootArguments']:add_input(f,struct.pack('<I',f['value']))
assert sup[289:]==expected_extra
known={}
for item in initial:
 address=int(item['address'],16);mask=int(item['knownMask'],16)
 for i in range(item['size']):assert address+i not in known;known[address+i]=(mask>>(8*i))&255
# Prefix schedule is the previously independently source-derived and pinned
# sunlight receipt, adjusted ONLY by the two newly known land bits. This is not
# a fresh PC sort of the current receipt; observer ordinals remain authoritative.
expected=[]
for kind,e in sorted([(k,e) for k in ['memoryReads','memoryWrites','invalidationEvents'] for e in sun[k]],key=lambda item:item[1]['eventOrdinal']):
 e=dict(e)
 if kind!='invalidationEvents':
  address=int(e['address'],16);extra=sum(({0x89c661:8,0x89c662:1}.get(address+i,0))<<(8*i) for i in range(e['size']))
  e['knownMask']=hex(int(e['knownMask'],16)|extra)
 if kind in ('memoryWrites','invalidationEvents') and (kind=='memoryWrites' or e['target']=='memory'):
  address=int(e['address'],16);mask=int(e['knownMask'],16)
  for i in range(e['size']):known[address+i]=(mask>>(8*i))&255
 expected.append((kind,e))
assert len(expected)==158959
S=0x23ed000;TR=0x89d1c8;STR=0xc65
newcalls=[]
def rd(pc,a,n):
 mask=sum(known.get(a+i,0)<<(8*i) for i in range(n));expected.append(('memoryReads',{'pc':hex(pc),'address':hex(a),'size':n,'knownMask':hex(mask)}));return mask
def wr(pc,a,n,mask=None):
 mask=(1<<(8*n))-1 if mask is None else mask
 for i in range(n):
  k=(mask>>(8*i))&255;known[a+i]=k;expected.append(('memoryWrites',{'pc':hex(pc),'address':hex(a+i),'size':1,'knownMask':hex(k),'committed':True}))
def bitop(pc,a,n,force):
 mask=rd(pc,a,n);wr(pc,a,n,mask|force)
def copy(pc,src,dst,n):
 for offset in range(0,n,4):wr(pc,dst+offset,4,rd(pc,src+offset,4))
def call(pc,target,returnpc,returnsp,parent):
 seq=2055+len(newcalls);newcalls.append((hex(pc),hex(target),returnpc,parent,returnsp));wr(pc,returnsp-4,4);return seq
# Fixed terrain mask helper, no preexisting terrain value is consumed decisively.
call(0x42b5a8,0x44fa30,0x42b5ad,S-8,None)
for i in range(16384):
 a=0x8a03e4+16*i;bitop(0x44fa3a,a,4,4);bitop(0x44fa40,a+14,1,15);bitop(0x44fa44,a+8,2,0xfc00)
rd(0x44fa4d,S-12,4)
wr(0x42b5b4,0x8979d3,6024);wr(0x42b5b6,0x89d184,4)
call(0x42b5bc,0x47ac30,0x42b5c1,S-8,None);rd(0x47ac30,0x89c662,1);wr(0x47ac37,S-16,4);wr(0x47ac46,0x897997,60);rd(0x47ac48,S-16,4);rd(0x47ac49,S-12,4)
call(0x42b5c6,0x43e320,0x42b5cb,S-8,None);rd(0x43e320,0x89c6f0,1);wr(0x43e327,S-16,4,0)
rd(0x43e33f,0x8979d7,2);wr(0x43e346,0x8979d7,2);rd(0x43e34c,0x89c6f0,1);rd(0x43e353,0x89d184,4);wr(0x43e35b,0x897997,4);rd(0x43e362,0x89c6f0,1);rd(0x43e36f,0x8979d3,2)
for rp,wp,off,n in [(0x43e37e,0x43e382,0,4),(0x43e388,0x43e38b,4,4),(0x43e38e,0x43e391,8,4),(0x43e394,0x43e398,12,2),(0x43e39c,0x43e39f,14,1)]:wr(wp,0x8979d9+off,n,rd(rp,0x897997+off,n))
rd(0x43e3a2,0x8979d3,2);wr(0x43e3a7,0x8979d3,2);rd(0x43e3b5,S-16,4);rd(0x43e3b6,S-12,4)
outer=call(0x42b5cb,0x42b7f0,0x42b5d0,S-8,None);wr(0x42b7f0,S-16,4,0);wr(0x42b7f6,S-20,4)
for pc,a,n in [(0x42b7fe,0x89798d,4),(0x42b800,0x897991,4),(0x42b803,0x897995,2),(0x42b80c,0x8926c7,4),(0x42b811,0x8926cb,4)]:wr(pc,a,n)
for i in range(4):
 t=TR+i*STR;wr(0x42b820,t+0xc20,1)
 for pc,off in [(0x42b832,0x949),(0x42b838,0x91d),(0x42b83e,0x925),(0x42b844,0x885),(0x42b84a,0x881),(0x42b850,0x945),(0x42b856,0x94d)]:wr(pc,t+off,4)
 for pcs,off in [([0x42b85c,0x42b85e,0x42b861,0x42b864,0x42b867],0xa27),([0x42b871,0x42b873,0x42b876,0x42b879,0x42b87c],0xa39)]:
  for j,pc in enumerate(pcs):wr(pc,t+off+j*4,2 if j==4 else 4)
 for pc,off,n in [(0x42b885,0xa4b,88),(0x42b887,0xaa3,2),(0x42b894,0xaa5,108),(0x42b8a1,0xb11,108),(0x42b8ae,0xb7d,40),(0x42b8bc,0xba5,4),(0x42b8be,0xba9,4),(0x42b8c1,0xbad,2),(0x42b8ca,0xbaf,40)]:wr(pc,t+off,n)
rd(0x42b8d4,0x96eac0,1)
for i in range(3):
 t=TR+i*STR;wr(0x42b8e2,S-24,4);active=call(0x42b8e3,0x42b660,0x42b8e8,S-24,outer)
 rd(0x42b660,S-24,1);wr(0x42b664,S-32,4);wr(0x42b668,S-36,4);wr(0x42b67e,t+0xc1f,1);rd(0x42b685,0x89c661,1)
 if LABEL=='clear':
  rd(0x42b68e,0x89c6f0,1)
  if i==0:
   wr(0x42b6b2,t+0x36,1424);wr(0x42b6b4,t+0x5c6,2);wr(0x42b6b6,t+0x5c8,1)
  else:
   wr(0x42b696,t+0xc1f,1);wr(0x42b69d,S-40,4);nonplayer=call(0x42b69e,0x461d70,0x42b6a3,S-40,active)
   for pc,a,mask in [(0x461d70,S-48,0xffffffff),(0x461d73,S-52,0xffffffff),(0x461d79,S-56,0xffffffff),(0x461d7a,S-60,0)]:wr(pc,a,4,mask)
   rd(0x461d7b,S-40,4);wr(0x461d82,t+0x36,1424);wr(0x461d84,t+0x5c6,2);wr(0x461d90,t+0x5c8,1);copy(0x461d9c,0x59d878,t+0x36e,240)
   wr(0x461d9e,S-64,4);wr(0x461d9f,t+0x59e,4);wr(0x461da5,t+0x5be,1);call(0x461dac,0x4f52c0,0x461db1,S-64,nonplayer)
   rd(0x4f52c0,S-64,4);bitop(0x4f52c4,t+0x596,4,0x10);rd(0x4f52cb,S-68,4);wr(0x461dba,t+0x5b4,1)
   for j in range(10):wr(0x461dc6,t+0x476+8*j,1);wr(0x461dcc,t+0x477+8*j,1)
   for j in range(8):wr(0x461ddc,t+0x4ce+12*j,1)
   wr(0x461de5,S-64,4);call(0x461de6,0x4d1420,0x461deb,S-64,nonplayer);rd(0x4d1420,S-64,4)
   for pc,off,n in [(0x4d1426,0x52e,2),(0x4d142e,0x53a,1),(0x4d1434,0x532,4),(0x4d143a,0x536,4)]:wr(pc,t+off,n)
   rd(0x4d1445,S-68,4);rd(0x461deb,t+0xc22,1);wr(0x461dfd,0x960815+48*i,1)
   for j in range(22):wr(0x461e0b,t+0x53f+4*j,1)
   rd(0x461e14,t+0xc22,1);wr(0x461e3a,0x9608b2+0x3108*i,4);rd(0x461e41,t+0xc22,1);rd(0x461e60,0x95d7b4+0x3108*i,2)
   for pc,a in [(0x461eb0,S-60),(0x461eb1,S-56),(0x461eb2,S-52),(0x461eb3,S-48),(0x461eb4,S-44)]:rd(pc,a,4)
 for pc,off,n in [(0x42b6bf,0x917,4),(0x42b6c1,0x91b,2),(0x42b6cb,0xa0d,4),(0x42b6cd,0xa11,4),(0x42b6d0,0xa15,4),(0x42b6d3,0xa19,4),(0x42b6d6,0xc20,1),(0x42b6dd,0x949,4),(0x42b6e3,0x91d,4),(0x42b6e9,0x925,4),(0x42b6ef,0x885,4),(0x42b6f5,0x945,4),(0x42b701,0x94d,4),(0x42b707,0x951,4),(0x42b70d,0x955,4),(0x42b713,0x959,4),(0x42b719,0x95d,4),(0x42b71f,0x94d,4),(0x42b725,0xc26,4),(0x42b727,0xc2a,4),(0x42b72a,0xc2e,4),(0x42b733,0xc32,4),(0x42b73b,0xc36,4),(0x42b73e,0xc3a,2)]:wr(pc,t+off,n)
 wr(0x42b748,S-40,4);wr(0x42b749,t+0xa1f,4);wr(0x42b74b,t+0xa23,4);wr(0x42b750,t+0x969,128);rd(0x42b752,0x5aa40c,4);wr(0x42b758,S-44,4);wr(0x42b759,S-48,4);call(0x42b75a,0x41a4f0,0x42b75f,S-48,active)
 rd(0x41a4f0,S-48,4);rd(0x41a4f4,S-44,4);rd(0x41a4f8,t+0x955,4);wr(0x41a4f8,t+0x955,4);rd(0x41a4fe,S-52,4)
 rd(0x42b768,t+0xc1f,1);bitop(0x42b771 if LABEL=='clear' and i else 0x42b776,t+0x93d,4,0x20)
 k=rd(0x42b779,t+0x93d,4);wr(0x42b780,t+0x93d,4,k|0x20000);wr(0x42b787,t+0x93d,4,k|0x60000)
 k=rd(0x42b789,t+0x941,4)
 for pc,bit in [(0x42b792,2),(0x42b79b,4),(0x42b7a4,8),(0x42b7ad,16),(0x42b7b6,32),(0x42b7bf,1),(0x42b7ca,128)]:k|=bit;wr(pc,t+0x941,4,k)
 rd(0x42b7d0,0x89c666,1);k=rd(0x42b7d9,t+0x93d,4);wr(0x42b7de,t+0x93d,4,k|1);wr(0x42b7e3,t+0x93d,4,k|3);bitop(0x42b7e5,t+0x941,4,64)
 rd(0x42b7ec,S-36,4);rd(0x42b7ed,S-32,4);rd(0x42b7ee,S-28,4)
 wr(0x42b8ec,S-24,4);call(0x42b8ed,0x436ff0,0x42b8f2,S-24,outer);wr(0x436ff0,S-32,4);rd(0x436ff3,S-24,4);wr(0x437002,t+0x8bf,80);wr(0x437004,t+0x90f,2);rd(0x437006,S-32,4);rd(0x437007,S-28,4);rd(0x42b8fd,0x96eac0,1)
rd(0x42b906,S-20,4);rd(0x42b907,S-16,4);rd(0x42b908,S-12,4)
for pc,a,n in [(0x42b5d0,0x96aa7a,2),(0x42b5de,0x895ebb,1),(0x42b5e4,0x96aa78,2),(0x42b5ed,0x895ebc,1),(0x42b5f3,0x64f4a0,7996),(0x42b5f5,0x64f4a0+7996,1),(0x42b600,0x96aaba,8192),(0x42b60c,0x96caba,8192)]:wr(pc,a,n)
rd(0x42b613,S+12,4);wr(0x42b617,S-12,4);wr(0x42b618,0x89ce5c,1);rd(0x42b61d,S+8,4);wr(0x42b621,0x89ce5e,1);rd(0x42b626,S+4,4);wr(0x42b62a,S-16,4);wr(0x42b62b,S-20,4);wr(0x42b62c,0x89ce5d,1);wr(0x42b632,0x89ce5f,1)
for ordinal,(kind,e) in enumerate(expected):e['eventOrdinal']=ordinal
actual=sorted([(kind,e) for kind in ['memoryReads','memoryWrites','invalidationEvents'] for e in r[kind]],key=lambda item:item[1]['eventOrdinal'])
assert len(actual)==len(expected),(len(actual),len(expected))
for ordinal,(want,got) in enumerate(zip(expected,actual)):assert want==got,(ordinal,want,got)
print(CASE,'source-derived events matched',len(expected))
# Freeze the independently produced schedule contract, then use the pure helper
# for mask/provenance reconstruction only. It executes no instructions.
counts=dict(Counter(kind for kind,e in expected));metadata={'schemaVersion':1,'ordering':'observer','eventCount':len(expected),'firstOrdinal':0,'lastOrdinal':len(expected)-1,'counts':counts};assert r['eventStream']==metadata
pc_rules={kind:{} for kind in ['memoryReads','memoryWrites']}
for kind,e in expected:
 if kind in pc_rules:
  pc=int(e['pc'],16);assert pc in rows
  assert not any(f['start']<=pc<f['stop'] for f in m['sunlightCheckpoint']['omittedFragments'])
  rule=pc_rules[kind].setdefault(e['pc'],{'sizes':set(),'knownMasks':set()});rule['sizes'].add(e['size']);rule['knownMasks'].add(e['knownMask'])
for rules in pc_rules.values():
 for rule in rules.values():rule['sizes']=sorted(rule['sizes']);rule['knownMasks']=sorted(rule['knownMasks'])
contract={'case':'reviewed coherent preloader '+CASE,'eventStream':metadata,'memoryRanges':trusted_contract['memoryRanges'],'forbiddenPcRanges':trusted_contract['forbiddenPcRanges']+[[0x42b638,0x42b63d]],'pcRules':pc_rules,'initialMemory':initial,'invalidationEvents':[e for kind,e in expected if kind=='invalidationEvents']}
helperpath=Path('/workspace/scratch/69fd8163d94e/native-event-replay-20261011/scripts/native-event-replay.py');HELPER_SHA='8a016740eef10a95e61e821b1a8adf5a9999025074e8b332ae2a32d9102d4f16';assert sha(helperpath.read_bytes())==HELPER_SHA
spec=importlib.util.spec_from_file_location('pure_replay',helperpath);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper);contract_hash=helper.contract_digest(contract)
contract_path=O/f'preloader-{LABEL}-run01-replay-contract.json';contract_path.write_text(json.dumps(contract,indent=2)+'\n')
state=helper.replay_receipt(raw,PIN[LABEL][0],contract,contract_hash);assert state.counts==counts
calltuple=lambda e:(e['caller'],e['target'],e['return'],e['parent'],e['returnSp'])
assert [calltuple(e) for e in r['calls']]==[calltuple(e) for e in sun['calls']]+newcalls
assert all(e['returned'] and e['sequence']==index for index,e in enumerate(r['calls']))
claims=r['selectedObservableAssertions'];assert len(claims['fields'])==len(m['selectedObservables'])==101 and len(claims['bits'])==8
lastwriters=[]
for expectedfield,claim in zip(m['selectedObservables'],claims['fields']):
 assert all(claim[k]==expectedfield[k] for k in ['name','address','bytes']);a=int(claim['address'],16);n=claim['bytes'];mask=(1<<(8*n))-1
 assert claim['knownMask']==hex(mask) and state.known_mask(a,n)==mask
 if 'expectedValue' in expectedfield:assert claim['value']==expectedfield['expectedValue'] and claim['sha256']==sha(claim['value'].to_bytes(n,'little'))
 else:assert claim['sha256']==expectedfield['expectedSha256']
 sources=state.byte_sources(a,n);inputs=claim['name'].endswith('_id') or claim['name'].endswith('_script_words')
 assert all(s[0]==('initial' if inputs else 'write') for s in sources),(claim['name'],set(sources))
 lastwriters.append({'name':claim['name'],'sourceKind':'preserved source-conditioned input' if inputs else 'native write','sourcePcs':sorted({s[2] for s in sources if s[0]=='write'})})
for f,claim in zip(m['selectedBitObservables'],claims['bits']):
 assert all(claim[k]==value for k,value in f.items());a=int(f['address'],16);n=f['bytes'];mask=state.known_mask(a,n);want=int(f['requiredKnownMask'],16)
 assert int(claim['actualKnownMask'],16)==mask and mask&want==want and claim['actualValueUnderRequiredMask']==f['expectedMaskedValue']
terrain=m['terrainContract'];baseaddr=int(terrain['base'],16);pattern=bytes.fromhex(terrain['exactKnownMaskPerRecordHex']);expectedmask=pattern*16384
for i in range(16384):assert state.known_mask(baseaddr+16*i,16)==int.from_bytes(pattern,'little')
assert claims['terrain']=={'base':hex(baseaddr),'bytes':0x40000,'records':16384,'knownMaskSha256':sha(expectedmask),'valueUnderMaskSha256':sha(bytes(0x40000)),'wholeTerrainKnown':False}
unknown=[(0x899f8d,64),(0x2010000,1024),(0x87eff8,4),(0x59df24,4),(0x5fe3f0,8),(S-8,8)]
if LABEL=='clear':unknown += [(TR+i*STR+0x36e,240) for i in (1,2)]
assert claims['unknownRanges']==[{'address':hex(a),'bytes':n,'knownMask':'0x0'} for a,n in unknown]
for a,n in unknown:assert state.known_mask(a,n)==0
bound=m['finalBoundaryContract'];after=r['after']['registers']
for reg,value in bound['knownRegisters'].items():assert after[reg]=={'value':hex(value),'knownMask':'0xffffffff'}
for reg in bound['unknownRegisters']:assert after[reg]['knownMask']=='0x0'
assert after['eflags']['knownMask']==bound['eflagsKnownMask'] and int(after['eflags']['value'],16)&int(bound['eflagsKnownMask'],16)==int(bound['eflagsValueUnderMask'],16)
newcounts=Counter(target for caller,target,ret,parent,sp in newcalls);assert claims['newCalls']=={target:newcounts[target] for target in claims['newCalls']}
script_reads=[e for e in r['memoryReads'] if e['pc']=='0x461e60'];table_reads=[e for e in r['memoryReads'] if e['pc']=='0x461d9c']
assert len(script_reads)==(2 if LABEL=='clear' else 0) and len(table_reads)==(120 if LABEL=='clear' else 0)
assert not any(e['pc'] in ('0x461e67','0x461e84','0x461ea6') for e in r['memoryWrites'])
report={'verdict':'ACCEPT_CONDITIONAL_COHERENT_PRELOADER_RESULT','landCase':CASE,'reviewerOriginalInstructionsExecuted':0,'resultSha256':PIN[LABEL][0],'processReceiptSha256':sha((H/f'preloader-{LABEL}-run01-process-receipt.json').read_bytes()),'driverSha256':m['driver']['sha256'],'approvalSha256':process['approval']['sha256'],'committedOriginalInstructions':PIN[LABEL][1],'sourceDerivedOrderedEventsVerified':len(expected),'eventCounts':counts,'knownFieldsVerified':101,'bitPredicatesVerified':8,'terrainRecordsVerified':16384,'terrainBytesVerified':262144,'terrainValuesOnlyKnownUnderMasks':True,'sunlightCheckpointFieldsVerified':43,'resetPaletteCheckpointFieldsVerified':33,'projections':3,'newProjections':0,'allGenuineCallsReturned':len(r['calls']),'newCallsByTarget':dict(newcounts),'realScriptEqualityReads':len(script_reads),'unknownTableCopyDwordReads':len(table_reads),'scriptWordsPreservedFromCanonicalInput':True,'rootArgumentsAtFinalStack':[25,6,0],'finalCpuAndUnknownRangesVerified':True,'replayHelperSha256':HELPER_SHA,'replayContractCanonicalSha256':contract_hash,'replayContractFileSha256':sha(contract_path.read_bytes()),'selectedObservableProvenance':lastwriters,'conditions':m['conditionalAssumptions'],'notRun':m['notRun'],'evidenceLimits':['The validated prior sunlight event schedule is reused under its pinned result hash; only newly supplied land-bit knowledge is added. New continuation event order/address/size/masks are derived from exact source loops and stack offsets.','Pure helper replay reconstructs memory masks/provenance, not register values or native instruction retirement.','Native write values are not in events. Final values use frozen assertions plus source-bound expected constants, preserved inputs and prior host math.','Cases are separate conditioned executions with different control-kind and nested calls. Passing both does not establish the actual historical land bit or whole-state equivalence.','No loader, bank initialization, allocator, authored constructor, postpass or gameplay is admitted.']}
out=O/f'preloader-{LABEL}-run01-post-review.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','landCase','sourceDerivedOrderedEventsVerified','eventCounts','knownFieldsVerified','bitPredicatesVerified','realScriptEqualityReads','unknownTableCopyDwordReads','reviewerOriginalInstructionsExecuted']}))
