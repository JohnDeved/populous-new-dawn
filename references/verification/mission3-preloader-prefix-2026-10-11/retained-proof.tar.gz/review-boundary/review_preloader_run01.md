# Coherent pre-loader: independent review of both cases

Accepted as two distinct conditioned selected-observable results, each stopping
at 0042b638 before the loader CALL. The reviewer executed no original instructions.
The five frozen drivers, case-bound held/released approvals, process/input/source
receipts and runtime tool identities match. The two original run windows were
serial. No replay performance improvement is claimed.

## Results

- land-clear: 307,361 committed instructions; result SHA256
  e2b325146a78d54061b55e129240fcf7fbebf0f64949756f228739ee447aa6ca.
  All 361,667 observer events match the independent source schedule:
  80,159 reads, 281,496 committed byte writes and 12 invalidations.
- land-set: 305,667 committed instructions; result SHA256
  32de84de613be26a5209eac10ddf0a30795435b67a94da1544405824046ec39b.
  All 356,519 observer events match the independent source schedule:
  80,006 reads, 276,501 committed byte writes and 12 invalidations.

Both preserve the earlier 33-field reset/palette and 43-field sunlight checkpoints.
Each passes all 101 predeclared fully known memory fields, eight bit predicates,
final CPU/stack/unknown-output requirements and exact known-mask coverage across
16,384 terrain records / 262,144 bytes. The three final stacked loader arguments
are source-bound 25,6,0. Terrain values are established only under the three masks;
untouched terrain bits are not claimed known or zero.

## Independent event and provenance review

The pinned, previously source-verified sunlight schedule was reused, adding only
the explicitly supplied land-bit knowledge. New continuation events were derived
from the original fixed-address loops, exact source order and stack offsets.
Every recorded event's ordinal, PC, address, width and mask matched that schedule.
All native event PCs lie in the byte-bound admitted windows; none are in omitted
fragments or the forbidden loader. Call topology, return sites, parent frames and
stack positions match the independent schedule, with every genuine call returned.

The frozen pure helper then reconstructed masks/provenance using independently
built contracts and externally pinned result hashes. It does not execute native
code, replay register values or reconstruct memory values. Selected values remain
supported by the frozen native assertions and independently reviewed source/data
expectations. Preserved IDs and script bytes are correctly identified as supplied
inputs, rather than native producers.

## Preserve the real case differences

Land-clear performs two nonplayer resets, two real script equality comparisons
and 120 DWORD reads copying unknown AI defaults. Both 240-byte destination copies
remain unknown. The nonplayer control-kind fields are 1.

Land-set bypasses those nonplayer resets: no script comparison or AI-table copy
occurs, and all three active tribes have control-kind 2. The different call graph
and event counts were checked directly. Passing both cases does not prove whole
state equivalence or identify the actual historical land bit.

The genuine equality branch preserves canonical CPSCR012 words 0x3eb,1000,1014.
No fallback script words, extra script projection, allocator return or OS success
value were fabricated. Both cases retain exactly the three old camera omissions
and their 12 invalidation descriptors. Camera/palette uncertainties, expired
palette pointer, unsupplied alias and saved outer registers remain unknown.

## Conditions and next boundary

All old normal/no-fault FP, live/disjoint palette-renaming, canonical trig and
cdecl fixture conditions remain. Player0, clear land0x100 and startup identity
IDs keep explicit unchanged-lifetime conditions. HDR/CPSCR transport is the
reviewed canonical successful-file condition. Land0x08 remains separately labeled
0/8; actual campaign history is unresolved.

No loader0042b230, bank initialization, allocator, authored-record constructor,
postpass or gameplay ran. The next useful proof is a grouped source/data assessment
of the actual loader dependencies before the first authored constructor, retaining
pool reset and bank/animation order. This result does not admit that continuation
or establish the eventual Mission 3 class1 seed.

## Review receipts

- preloader-clear-run01-post-review.json SHA256:
  f1fa1f1137c9a364bb3139701716882be8e9fe16a4be6aa8ae82bcc114d62d75.
- preloader-set-run01-post-review.json SHA256:
  bfcf99da6a9b0500b5c7925fecc1678d2cd3604a6985e5e44e5fceed14fa9d04.
- Clear replay contract canonical digest:
  d191495aedc41f61c55489e84524fc4bc27d93b63627be12f48bee9da40b9006.
- Set replay contract canonical digest:
  a46e5a44a67c468d24c810ba932f5b2f55d6f6a703d950ff82b4743781865565.

The paired summary binds both per-case reports/contracts and the wrapper hash.
