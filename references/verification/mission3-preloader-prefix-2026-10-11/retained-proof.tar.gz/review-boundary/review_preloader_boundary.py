"""Canonical static review only. No emulation, original execution or driver edits."""
from pathlib import Path
import hashlib,importlib.util,json,struct
import capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary'
sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((H/'preloader-input-map.json').read_text())
for k in ['script','executable','acceptedPrefixReceipt','header']:
 p=Path(j[k]['path']);raw=p.read_bytes();assert len(raw)==j[k]['bytes'] and sha(raw)==j[k]['sha256']
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);pe=p.PE32(Path(j['executable']['path']))
assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;rows={}
for w in j['windows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));assert sum(i.size for i in ins)==len(raw) and sha(raw)==w['sha256']
 assert [{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]==w['instructions'];rows.update({i.address:i for i in ins})
for c in j['checks']:
 i=rows[int(c['pc'],16)];assert i.bytes.hex()==c['bytes'] and i.mnemonic+' '+i.op_str==c['assertion']
assert Path(j['header']['path']).read_bytes()[88]==3 and list(Path(j['header']['path']).read_bytes()[96:99])==[25,6,0]
# Complete finite call closure in actual source order.
starts=[0x42b5a8,0x44fa30,0x47ac30,0x43e320,0x42b7f0,0x42b660,0x436ff0,0x461d70,0x4f52c0,0x4d1420,0x41a4f0]
ends={int(w['start'],16):int(w['endExclusive'],16) for w in j['windows']}
calls=[]
for start in starts:
 for pc,i in rows.items():
  if start<=pc<ends[start] and i.mnemonic=='call':
   assert len(i.operands)==1 and i.operands[0].type==capstone.x86.X86_OP_IMM
   target=i.operands[0].imm;assert target in starts;calls.append((hex(pc),hex(target)))
assert sorted(calls)==sorted([('0x42b5a8','0x44fa30'),('0x42b5bc','0x47ac30'),('0x42b5c6','0x43e320'),('0x42b5cb','0x42b7f0'),('0x42b8e3','0x42b660'),('0x42b8ed','0x436ff0'),('0x42b69e','0x461d70'),('0x42b75a','0x41a4f0'),('0x461dac','0x4f52c0'),('0x461de6','0x4d1420')])
assert all(not i.mnemonic.startswith('f') and i.mnemonic not in ['int','syscall','sysenter','rdtsc'] for start in starts for pc,i in rows.items() if start<=pc<ends[start])
# The only differing outputs of the nested equality branch are six bytes,
# EAX/ECX/EDX and arithmetic flags; the branch contains no stack mutation/call.
lo,hi=0x461e60,0x461eb0;fragment=[i for pc,i in rows.items() if lo<=pc<hi];assert sum(i.size for i in fragment)==hi-lo
writes=[];regwrites=set()
for i in fragment:
 readregs,written=i.regs_access();regwrites.update(i.reg_name(r) for r in written)
 assert i.mnemonic not in ['call','push','pop','ret','enter','leave']
 for op in i.operands:
  if op.type==capstone.x86.X86_OP_MEM:
   assert i.reg_name(op.mem.base) not in ['esp'] and i.reg_name(op.mem.index) not in ['esp']
   if op.access & capstone.CS_AC_WRITE:writes.append((i.address,op.size,i.mnemonic,i.op_str))
assert writes==[(0x461e67,2,'mov','word ptr [eax], 0x3eb'),(0x461e84,2,'mov','word ptr [eax*8 + 0x95d7b6], 0x3ec'),(0x461ea6,2,'mov','word ptr [eax*8 + 0x95d7b8], 0x3fb')]
assert regwrites<=set(['eax','ecx','edx','eflags']) and regwrites==set(['eax','ecx','edx','eflags'])
# Bind kills; verify all prior instructions on this actual return path do not
# semantically read the prior GPR. Self-XOR is a definition despite flags metadata.
kill={'eax':0x42b6b7,'edx':0x42b6bd,'ecx':0x42b736}
path=[rows[pc] for pc in sorted(rows) if 0x461eb0<=pc<0x461eb5]+[rows[pc] for pc in sorted(rows) if 0x42b6a3<=pc<0x42b6a8 or 0x42b6b7<=pc<=0x42b736]
for reg,k in kill.items():
 for i in path:
  if i.address==k:break
  readregs,_=i.regs_access();assert reg not in {i.reg_name(r) for r in readregs},(reg,hex(i.address))
 else:raise AssertionError('missing kill')
assert (rows[0x42b6b7].mnemonic,rows[0x42b6b7].op_str)==('lea','eax, [esi + 0x917]')
assert (rows[0x42b6bd].mnemonic,rows[0x42b6bd].op_str)==('xor','edx, edx')
assert (rows[0x42b736].mnemonic,rows[0x42b736].op_str)==('mov','ecx, 0x20')
assert (rows[0x42b6a3].mnemonic,rows[0x42b6a3].op_str)==('add','esp, 4')
# Additional concrete producer and later reader, canonical bounded bytes only.
extra=[]
for lo,hi in [(0x492be0,0x492c23),(0x486550,0x48669d),(0x461649,0x461680)]:
 raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo));extra.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]})
# Full helper end is checked separately below; reader slice is intentionally a
# byte-bound excerpt, not a declaration of full call closure for later gameplay.
def extra_ins(pc):
 for w in extra:
  for i in w['instructions']:
   if int(i['pc'],16)==pc:return i
 raise AssertionError(hex(pc))
for pc,op in [(0x492bfe,'word ptr [eax + 0x9608ba], 0xc'),(0x492c07,'word ptr [eax + 0x9608bc], 0x3eb'),(0x492c10,'word ptr [eax + 0x9608be], 0x3ec'),(0x492c19,'word ptr [eax + 0x9608c0], 0x3fb')]:assert extra_ins(pc)['operands']==op
assert extra_ins(0x4865df)['operands']=='0x525f80' and extra_ins(0x48665f)['operands']=='0x525f80' and extra_ins(0x48666c)['operands']=='0x492be0'
assert extra_ins(0x4865e9)['mnemonic']=='je' and extra_ins(0x486669)['mnemonic']=='je'
# The branch-dependent bytes are disjoint from the segment's other global
# regions; stack is a separately disjoint diagnostic fixture.
script_ranges=[(0x95d7b4+t*0x3108,6) for t in (1,2)]
other_ranges=[(0x8a03e4,0x40000),(0x897997,60),(0x8979d3,6024),(0x89d1c8,4*0xc65),(0x64f4a0,0x7cf*4+1),(0x96aaba,0x2000),(0x96caba,0x2000)]
for a,n in script_ranges:
 assert all(a+n<=lo or lo+size<=a for lo,size in other_ranges)
 for t in (1,2):assert not a<=0x960815+t*0x30<a+n and not (a<0x9608b2+t*0x3108+4 and 0x9608b2+t*0x3108<a+n)
report={'verdict':'ACCEPT_FINITE_SOURCE_MAP_AND_NARROW_TAINT_DESIGN_NOT_EXECUTION','originalInstructionsExecuted':0,'driverChanges':False,'inputMapSha256':sha((H/'preloader-input-map.json').read_bytes()),'canonicalWindowsVerified':17,'canonicalInstructionAssertionsVerified':26,'finiteCalls':calls,'extensionBoundary':['0x42b5a8','0x42b638'],'exactEntryFacts':j['requiredEntryFacts'],'callerArguments':[25,6,0],'scriptBranch':{'window':['0x461e60','0x461eb0'],'bytesSha256':sha(pe.read(0x461e60,0x50)),'writes':[{'pc':hex(pc),'size':size,'instruction':mn+' '+op} for pc,size,mn,op in writes],'targetRanges':[{'address':hex(a),'bytes':n} for a,n in script_ranges],'followingWordsConsumedInThisSegment':False,'wholeAllocationIndependenceProved':False,'minimumRealBranchCondition':'Only first words 009608bc/009639c4 = 0x3eb; following four bytes per tribe remain unknown. This would be an explicit assumption, not established actual history.','narrowProjectionDesign':'Alternatively skip only this branch/store fragment in the exact 0042b69e→00461d70 nonplayer context; taint all six bytes and EAX/ECX/EDX/arithmetic flags; preserve native pops/return and all other code. No extra stack footprint. Later decisive consumers must stop.','nativeKills':{'arithmeticFlags':'0x42b6a3','eax':'0x42b6b7','edx':'0x42b6bd','ecx':'0x42b736'}},'producerConclusion':'00492be0 provides defaults only when both 00486550 file attempts fail; it is not unconditional entry provenance. Earlier New Game 0042b7f0 likewise needs compatible count/IDs/mode and unchanged lifetime.','laterReader':'004615f0 forms base0095d7b2 + id*0x3108 and calls interpret_script_upper; later script consumption prevents a global irrelevance claim.','extraSourceWindows':extra,'limits':['Current native admission still ends0042b5a8. A driver/observable/condition/taint implementation needs fresh review and separate release.','Selected player/count/mode/ID suppliers are concrete but their historical transport/lifetime still needs binding or explicit conditions.','Land08=8 bypasses this nested branch; land08=0 with player0/count3/identity IDs reaches tribes1,2. Do not infer either from wholeword zeros.','No full tribe state, AI-script contents, allocation independence, campaign startup or gameplay proof.']}
(O/'preloader-boundary-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['verdict','canonicalWindowsVerified','canonicalInstructionAssertionsVerified','originalInstructionsExecuted']}))
