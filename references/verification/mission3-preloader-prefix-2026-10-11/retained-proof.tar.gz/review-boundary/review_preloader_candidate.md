# Frozen coherent pre-loader candidate review

Verdict: ACCEPT_COHERENT_PRELOADER_PREFIX for each separately labeled case, with
parentReleasedRunLane=false in both immutable reviewer payloads. No original
instructions were executed by this reviewer.

Driver SHA256: 90c4dd29f55029062de8847984ef87fff13cbef79d4ef39343ffc01179051793.
Source HEAD: 7bc4c8c53a0a36070d86153653720a9d5a849171; tracked status clean.

- land-clear preflight: 88e57e8082a01861b8e628453b6ebb74f908af3ff06d3d3bd89bdfd014326e40.
- land-set preflight: 634203f7d45b2b4add921f15529876ad26e6ed6f2947a36360fa6985418bf297.
- Held clear verdict: e90b03fb7315d7f0e6e8668c4135212dee38e46785785d9ea596f97fab2c5691.
- Held set verdict: 5dfd22202e416b764e09d4543b6354a9d9f95ab9cf86339b5cf9516f10bf5715.

## Verified

All 100 author synthetic tests and five independent tests pass. Both fresh
static preparations are byte-identical to the frozen preflights. Every verification
receipt file and all frozen dependencies match their hashes.

The one review defect was a provenance label: the two supplied script spans had
been labeled genuine prefix writes. The repaired candidate identifies them as
canonical successful-transport inputs preserved by the genuine prefix. Synthetic
assertions check the repaired label for both cases. No semantics changed.

The candidate retains the old reset/palette and sunlight checkpoints, committing
prior instructions before checking them. It adds only the reviewed code windows
and entry facts, then stops exactly at 0042b638 before the forbidden loader target.
No additional instruction semantics, projection, OS bridge or fabricated return
is introduced. The actual script CMP/JE executes on source-bound canonical bytes.

Masked supplies change and mark known only the declared bits. The independent
tests check conservative knowledge when neighbors were previously known, missing
sources/invalid masks, a 240-byte unknown REP copy with nonzero concrete bytes,
and a genuine synthetic equality branch requiring its first word while leaving
following words unknown. Adjacent unknown predicate consumption remains blocked.

Each case fixes 101 fully known fields, eight partial-bit predicates, exact
262,144-byte terrain-mask coverage, call counts and final CPU/stack/unknown-output
requirements. Terrain old bits remain unknown. The clear case retains both
240-byte AI-table copies unknown. The old camera/palette uncertainties persist.

## Conditions and admission limits

The source/data/lifetime contract is consolidated in review_preloader_contract.md.
Player0, clear land0x100 and identity IDs retain explicit earlier-producer lifetime
conditions. Land0x08 is a labeled alternative, not a proven actual campaign mode.
Canonical HDR/CPSCR transport, old trig/FP/heap conditions and cdecl fixture remain
explicit. No fallback script words or wholeword flag zeros are supplied.

The two held verdicts are case-bound and cannot substitute for each other. The
parent owns separate lane release. Until terminal results and independent reviews
exist, publication may claim only static/synthetic preparation and conditional
admission. No loader, bank initialization, constructor, allocator, postpass or
gameplay execution is admitted.
