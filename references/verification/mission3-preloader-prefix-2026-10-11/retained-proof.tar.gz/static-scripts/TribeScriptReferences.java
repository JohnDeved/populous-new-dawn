import java.nio.file.*;
import ghidra.app.script.GhidraScript;
public class TribeScriptReferences extends GhidraScript {
 public void run() throws Exception {
  StringBuilder o=new StringBuilder();
  for(long tribe=0;tribe<4;tribe++) { for(long off=0;off<8;off++) { long a=0x0095d7b2L+tribe*0x3108L+off;
   for(var r:getReferencesTo(toAddr(a))) {
    var f=getFunctionContaining(r.getFromAddress());var i=getInstructionAt(r.getFromAddress());
    o.append(Long.toHexString(a)).append("\t").append(r.getFromAddress()).append("\t").append(r.getReferenceType()).append("\t").append(f==null?"NO_FUNCTION":f.getEntryPoint()).append("\t").append(i==null?"DATA":i.toString()).append("\n");
   }
  }
  } Files.writeString(Path.of(getScriptArgs()[0]),o.toString());println("TRIBE_SCRIPT_REFERENCES_COMPLETE");
 }
}
