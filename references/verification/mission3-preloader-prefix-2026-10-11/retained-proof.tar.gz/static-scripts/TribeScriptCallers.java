import java.nio.file.*;
import ghidra.app.script.GhidraScript;
public class TribeScriptCallers extends GhidraScript {
 public void run() throws Exception {
  StringBuilder o=new StringBuilder();
  for(long a:new long[]{0x00492be0L,0x00486550L}) {
   for(var r:getReferencesTo(toAddr(a))) {
    var f=getFunctionContaining(r.getFromAddress());var i=getInstructionAt(r.getFromAddress());
    o.append(Long.toHexString(a)).append("\t").append(r.getFromAddress()).append("\t").append(r.getReferenceType()).append("\t").append(f==null?"NO_FUNCTION":f.getEntryPoint()).append("\t").append(i==null?"DATA":i.toString()).append("\n");
   }
  }
  Files.writeString(Path.of(getScriptArgs()[0]),o.toString());println("TRIBE_SCRIPT_CALLERS_COMPLETE");
 }
}
