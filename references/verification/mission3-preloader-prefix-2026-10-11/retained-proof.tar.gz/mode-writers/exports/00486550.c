/* Ghidra 12.1.3 pseudocode; entry 00486550; FUN_00486550.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00486550(void)

{
  int iVar1;
  undefined *puVar2;
  int iVar3;
  undefined1 local_224 [4];
  undefined1 local_220 [272];
  char local_110 [272];

  iVar3 = 0;
  if (DAT_0089b799 != 1 && -1 < (int)(DAT_0089b799 - 1)) {
    puVar2 = &DAT_009608ba;
    do {
      FUN_004fffe0(local_220,s_LEVELS_0059cd2c,0);
      _sprintf(local_110,s__s__s_03d__s_00599838,local_220,s_CPSCR_005a1e70,
               (uint)(byte)(&DAT_0089b79a)[iVar3],&DAT_00599850);
      FUN_004a3200();
      FUN_004a3d20();
      FUN_005001b0(&DAT_0089cd23,local_110);
      iVar1 = FUN_00525f80(&DAT_0089cd23,puVar2,0xfffffff,local_224);
      if (iVar1 != 0) {
        FUN_00500040(local_220,s_LEVELS_0059cd2c,0);
        _sprintf(local_110,s__s__s_03d__s_00599838,local_220,s_CPSCR_005a1e70,
                 (uint)(byte)(&DAT_0089b79a)[iVar3],&DAT_00599850);
        FUN_004a3200();
        FUN_004a3d20();
        FUN_005001b0(&DAT_0089cd23,local_110);
        iVar1 = FUN_00525f80(&DAT_0089cd23,puVar2,0xfffffff,local_224);
        if (iVar1 != 0) {
          FUN_00492be0(iVar3);
        }
      }
      iVar3 = iVar3 + 1;
      *(undefined **)(puVar2 + 0x3100) = puVar2 + 0x2000;
      puVar2 = puVar2 + 0x3108;
    } while (iVar3 < (int)(DAT_0089b799 - 1));
  }
  return;
}
