/* Ghidra 12.1.3 pseudocode; entry 0047ac30; FUN_0047ac30.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_0047ac30(void)

{
  int iVar1;
  undefined4 *puVar2;

  if ((DAT_0089c661 & 0x100) == 0) {
    puVar2 = &DAT_00897997;
    for (iVar1 = 0xf; iVar1 != 0; iVar1 = iVar1 + -1) {
      *puVar2 = 0;
      puVar2 = puVar2 + 1;
    }
    return;
  }
  DAT_0089c661 = DAT_0089c661 & 0xfffffeff;
  return;
}
