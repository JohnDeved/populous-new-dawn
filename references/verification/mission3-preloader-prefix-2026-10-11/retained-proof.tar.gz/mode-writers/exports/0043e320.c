/* Ghidra 12.1.3 pseudocode; entry 0043e320; FUN_0043e320.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_0043e320(void)

{
  short *psVar1;
  short sVar2;
  int iVar3;

  iVar3 = DAT_0089c6f0 * 0x5e2;
  psVar1 = (short *)((int)&DAT_008979d3 + iVar3);
  if (*(short *)((int)&DAT_008979d7 + iVar3) == 0) {
    *(undefined2 *)((int)&DAT_008979d7 + iVar3) = 1;
    *(undefined4 *)((int)&DAT_00897997 + DAT_0089c6f0 * 0xf) = DAT_0089d184;
    iVar3 = DAT_0089c6f0 * 0xf;
    sVar2 = *psVar1;
    *(undefined4 *)((int)psVar1 + sVar2 * 0xf + 6) = *(undefined4 *)((int)&DAT_00897997 + iVar3);
    *(undefined4 *)((int)psVar1 + sVar2 * 0xf + 10) = *(undefined4 *)((int)&DAT_0089799b + iVar3);
    *(undefined4 *)((int)psVar1 + sVar2 * 0xf + 0xe) = *(undefined4 *)((int)&DAT_0089799f + iVar3);
    *(undefined2 *)((int)psVar1 + sVar2 * 0xf + 0x12) = *(undefined2 *)((int)&DAT_008979a3 + iVar3);
    *(undefined1 *)((int)psVar1 + sVar2 * 0xf + 0x14) = (&DAT_008979a5)[iVar3];
    sVar2 = *psVar1;
    *psVar1 = sVar2 + 1;
    if (99 < (short)(sVar2 + 1)) {
      *psVar1 = 0;
    }
  }
  return;
}
