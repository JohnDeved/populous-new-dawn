/* Ghidra 12.1.3 pseudocode; entry 00485e60; FUN_00485e60.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485e60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;

  iVar3 = 0;
  DAT_009606fe = 0;
  DAT_00960702 = 0;
  DAT_00960706 = 0;
  puVar4 = &DAT_0096070a;
  for (iVar2 = 0x38; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  puVar4 = &DAT_009607ea;
  for (iVar2 = 0x30; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  DAT_009608aa = 0;
  DAT_009608ae = 0;
  DAT_009608b2 = 0;
  DAT_009608b6 = 0;
  if (param_1 != 99) {
    DAT_00960702 = *(undefined4 *)(&DAT_0089a051 + param_1 * 0x18);
    DAT_009606fe = *(undefined4 *)(&DAT_0089a04d + param_1 * 0x18);
    DAT_00960706 = *(undefined4 *)(&DAT_0089a055 + param_1 * 0x18);
    puVar4 = &DAT_0089a3a9;
    puVar1 = &DAT_0096070a;
    for (iVar2 = 0xe; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar1 = *puVar4;
      puVar4 = puVar4 + 1;
      puVar1 = puVar1 + 1;
    }
    _DAT_00960712 = 0;
    _DAT_00960716 = 0;
    puVar4 = &DAT_0096071e;
    for (iVar2 = 8; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar4 = 0;
      puVar4 = puVar4 + 1;
    }
    if (0 < (int)(DAT_0089b799 - 1)) {
      puVar1 = &DAT_00960742;
      puVar4 = &DAT_0089b9f9;
      do {
        puVar5 = puVar4;
        puVar6 = puVar1;
        for (iVar2 = 0xe; iVar2 != 0; iVar2 = iVar2 + -1) {
          *puVar6 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar6 = puVar6 + 1;
        }
        puVar1 = puVar1 + 0xe;
        iVar3 = iVar3 + 1;
        puVar4 = puVar4 + 0x24;
      } while (iVar3 < (int)(DAT_0089b799 - 1));
    }
    iVar2 = 0;
    if (DAT_0089b799 != 1 && -1 < (int)(DAT_0089b799 - 1)) {
      puVar1 = &DAT_0096081a;
      puVar4 = &DAT_0089b9a9;
      do {
        puVar5 = puVar4;
        puVar6 = puVar1;
        for (iVar3 = 0xc; iVar3 != 0; iVar3 = iVar3 + -1) {
          *puVar6 = *puVar5;
          puVar5 = puVar5 + 1;
          puVar6 = puVar6 + 1;
        }
        puVar1 = puVar1 + 0xc;
        iVar2 = iVar2 + 1;
        puVar4 = puVar4 + 0x24;
      } while (iVar2 < (int)(DAT_0089b799 - 1));
    }
    DAT_009608b6 = DAT_0089b79d;
  }
  return;
}
