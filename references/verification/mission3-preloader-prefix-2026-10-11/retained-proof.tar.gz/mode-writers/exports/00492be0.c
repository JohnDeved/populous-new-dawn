/* Ghidra 12.1.3 pseudocode; entry 00492be0; FUN_00492be0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_00492be0(int param_1)

{
  param_1 = param_1 * 0x3108;
  *(undefined2 *)(&DAT_009608ba + param_1) = 0xc;
  *(undefined2 *)(&DAT_009608bc + param_1) = 0x3eb;
  *(undefined2 *)(&DAT_009608be + param_1) = 0x3ec;
  *(undefined2 *)(&DAT_009608c0 + param_1) = 0x3fb;
  return;
}
