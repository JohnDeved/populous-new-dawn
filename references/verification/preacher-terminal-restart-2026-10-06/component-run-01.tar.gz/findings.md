# One-run command17 restart result

The exact fixed component hypothesis held. At pair2, actual native stop and
setters select source48/draw16, while frozen b2 port remains168/14. Both have
f1=0/f2=1 after the updater. All six predicted endpoints and the three visit event
sequences match. Pair3 converges to source160/draw19, timer7, f1=0/f2=0.

This was one granted CPU4 execution of source90d79f20. The launcher exited0
in1.586s, completed three controller plus three updater calls and has no remaining
process-group members. Source, input, tool and manifest postflight hashes match.
Both RNG words remain unchanged. No read touched the unobserved maxLife bytes.
Native instructions per call:60,48,222,46,271,38; all bounded calls returned.
The native composition took0.035s against the10s ceiling; this is a budget receipt,
not a performance comparison. Raw stdout/stderr, call/write records, all snapshots,
exact event boundaries and unmasked differences are included.

The native restart events are stop → upper17 → lower48/16; the port has no pair2
events. Pair3 has native stop → upper17 → lower48/16 → upper95 → lower160/19 →
acquisition0. Port lower-setter intent labels and native raw argument dwords stay
explicit. A transient entry-bit difference occurs at pair1 and disappears during
pair2. It alone is not a lasting or rendered gameplay defect.

The component result requires independent evidence review. No gameplay change has
been made. Ordinary reachability came from the accepted historical169b baseline;
no current rendered restart frame or original-game scheduler was executed here.
A later ordinary observation remains a separate bounded decision.
