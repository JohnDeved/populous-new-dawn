from pathlib import Path
import datetime, errno, hashlib, json, socket, subprocess, sys
root=Path.cwd()
out=root/'work/orchestration/combined-parity'
proposal=json.loads((out/'browser-launch-proposal.json').read_text())
inputs=json.loads((out/'browser-receipt-inputs.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==proposal['qaHead']=='15a057056d88282686d2eb7e84dae1c843f6edb8'
assert git('status','--porcelain')==''
for p in ['app','public','scripts','tests','engineering','package.json','package-lock.json']:
 assert git('rev-parse','HEAD:'+p)==git('rev-parse',proposal['deliveryHead']+':'+p)
for item in inputs['frozenInputs']:assert sha(item['path'])==item['sha256'],item['path']
dep=root/'node_modules';assert not dep.is_symlink() and (dep.stat().st_dev,dep.stat().st_ino)==(27,1978923)
assert sha(dep/'.package-lock.json')=='65e45d0a87d1ecd4fbf56508b9821eb3bfb3867c8477db4aaa1452eb2bed13d8'
assert sha(root/'package-lock.json')=='c1599d8d7e3f028e290a13561c653cf926e739e98eb9ec1b476dbe1c2a4558ba'
launch=Path(inputs['outputRoot']);assert not launch.exists();launch.mkdir();(launch/'tmp').mkdir()
def connect():
 with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as connection:
  connection.settimeout(1);return connection.connect_ex(('127.0.0.1',proposal['port']))
before=connect();assert before==errno.ECONNREFUSED,('Existing or uncertain loopback port',before)
pre={'status':'ready','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'deliveryHead':proposal['deliveryHead'],'sameLaunchInvocation':True,'port':proposal['port'],'connectEx':before,'argv':proposal['command'],'inputCount':len(inputs['frozenInputs'])+len(inputs['additionalAtLaunch']),'dependencyDevice':dep.stat().st_dev,'dependencyInode':dep.stat().st_ino}
(launch/'prelaunch.json').write_text(json.dumps(pre,indent=2)+'\n')
command=['node','scripts/orchestration/command-receipt.mjs','--output','work/orchestration/combined-parity-browser-01/outer-01.json']
for p in [*[item['path'] for item in inputs['frozenInputs']],*inputs['additionalAtLaunch']]:command+=['--input',p]
command+=['--',*proposal['command']]
result=subprocess.run(command,cwd=root)
outer=json.loads((launch/'outer-01.json').read_text())
for stream in ['stdout','stderr']:assert sha(outer['artifacts'][stream])==outer[stream+'Sha256']
innerpath=launch/'run/receipt.json';inner=json.loads(innerpath.read_text()) if innerpath.exists() else {}
after=connect()
cleanup={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sameLaunchInvocation':True,'outerStatus':outer['status'],'outerExit':outer.get('exitCode'),'outerSignal':outer.get('signal'),'sourceAndInputsStable':outer.get('source')==outer.get('sourceAfter'),'harnessStatus':inner.get('status'),'harnessFinishedAt':inner.get('finishedAt'),'harnessFailure':inner.get('failure'),'connectEx':after,'loopbackReleased':after==errno.ECONNREFUSED,'contract':'Existing ephemeral harness finally awaits owned browser/server cleanup; no persistent profile or foreign process control.'}
(launch/'terminal-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
print(json.dumps(cleanup),flush=True)
assert cleanup['sourceAndInputsStable'] and cleanup['loopbackReleased']
assert outer['status']=='passed' and outer['exitCode']==0 and inner.get('status')=='passed'
sys.exit(result.returncode)
