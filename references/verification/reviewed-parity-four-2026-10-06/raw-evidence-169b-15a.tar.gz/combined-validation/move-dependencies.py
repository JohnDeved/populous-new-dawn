from pathlib import Path
import hashlib, json, subprocess
root=Path.cwd()
source=root.parent/'firewarrior-firing-phase-fix-20261006/node_modules'
target=root/'node_modules'
output=root/'work/orchestration/combined-parity/dependency-transfer'
assert not output.exists(); output.mkdir()
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='169b5f38e8cc9f7aacbae222ba804ac519ec1f27'
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
assert source.is_dir() and not source.is_symlink() and not target.exists()
assert (source.stat().st_dev,source.stat().st_ino)==(27,1978923)
expected='65e45d0a87d1ecd4fbf56508b9821eb3bfb3867c8477db4aaa1452eb2bed13d8'
assert sha(source/'.package-lock.json')==expected
for name in ['package.json','package-lock.json']: assert (source.parent/name).read_bytes()==(root/name).read_bytes()
assert sha(root/'package-lock.json')=='c1599d8d7e3f028e290a13561c653cf926e739e98eb9ec1b476dbe1c2a4558ba'
lock=(source/'.package-lock.json').read_bytes()
(output/'original-installed-lock.json').write_bytes(lock)
record={'status':'before','source':str(source),'destination':str(target),'sourceInode':source.stat().st_ino,'sourceDevice':source.stat().st_dev,'sourceEntries':len(list(source.iterdir())),'rootLocks':{name:sha(root/name) for name in ['package.json','package-lock.json']},'installedLock':expected,'coordination':'Parent granted receipted transfer of released terminal dependency tree and one serial full check/build on 2026-10-06 at 11:19 UTC. No native/browser execution.'}
(output/'before.json').write_text(json.dumps(record,indent=2)+'\n')
source.rename(target)
source.mkdir(); (source/'.package-lock.json').write_bytes(lock)
assert (target.stat().st_dev,target.stat().st_ino)==(27,1978923)
assert sha(target/'.package-lock.json')==sha(source/'.package-lock.json')==expected
assert list(source.iterdir())==[source/'.package-lock.json']
record.update(status='passed',destinationInode=target.stat().st_ino,destinationDevice=target.stat().st_dev,destinationEntries=len(list(target.iterdir())),preservedSourceStubSha256=sha(source/'.package-lock.json'),preservedLockCopySha256=sha(output/'original-installed-lock.json'))
(output/'after.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
