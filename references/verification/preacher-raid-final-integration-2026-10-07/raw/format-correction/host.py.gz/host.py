from pathlib import Path
import datetime,gzip,hashlib,json,os,signal,stat,subprocess,time
root=Path.cwd();out=root/'work/orchestration/preacher-raid-format-fix-01';donor=root.parent/'preacher-automatic-response-qa-20261006/node_modules';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();assert [donor.stat().st_dev,donor.stat().st_ino]==[27,1978923]
def inventory():
 rows={}
 for parent,dirs,files in os.walk(donor,followlinks=False):
  for name in dirs+files:
   p=Path(parent)/name;s=p.lstat();key=str(p.relative_to(donor))
   if stat.S_ISLNK(s.st_mode):rows[key]={'link':os.readlink(p),'mode':s.st_mode}
   elif stat.S_ISREG(s.st_mode):rows[key]={'sha256':sha(p),'size':s.st_size,'mode':s.st_mode}
 return rows
before=inventory();(out/'dependencies-before.json.gz').write_bytes(gzip.compress((json.dumps(before,sort_keys=True)+'\n').encode(),mtime=0));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='2f0c50379d89f603f4e51de006169ae04c9d2380';assert not subprocess.check_output(['git','status','--porcelain'],text=True)
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';command=['/usr/bin/timeout','--signal=TERM','--kill-after=3s','30s','/usr/bin/taskset','--cpu-list','0-3',node,str(out/'format.mjs')];started=now();env={'PATH':str(Path(node).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','TZ':'UTC','NODE_OPTIONS':'','NODE_PATH':'','TMPDIR':str(out)}
def members(pid):
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   raw=(p/'stat').read_text();parts=raw[raw.rfind(')')+2:].split()
   if int(parts[2])==pid:found.append(int(p.name))
  except (OSError,ValueError,IndexError):pass
 return found
with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
 child=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 (out/'started.json').write_text(json.dumps({'head':head,'startedAt':started,'pid':child.pid,'command':command})+'\n')
 try:rc=child.wait(timeout=34)
 except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);rc=child.wait(timeout=2)
 if members(child.pid):os.killpg(child.pid,signal.SIGKILL);time.sleep(.1)
after=inventory();(out/'dependencies-after.json.gz').write_bytes(gzip.compress((json.dumps(after,sort_keys=True)+'\n').encode(),mtime=0));changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();diff=subprocess.check_output(['git','diff','--','app/computer-runtime.ts']);(out/'format.diff').write_bytes(diff);receipt={'head':head,'startedAt':started,'finishedAt':now(),'exitCode':rc,'command':command,'sourceChanges':changed,'dependencyIdentity':[donor.stat().st_dev,donor.stat().st_ino],'dependenciesUnchanged':before==after,'remainingProcessGroup':members(child.pid),'dependencyMoves':[],'nodeSha256':sha(Path(node))};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert rc==0 and before==after and changed==['app/computer-runtime.ts'] and not receipt['remainingProcessGroup']
