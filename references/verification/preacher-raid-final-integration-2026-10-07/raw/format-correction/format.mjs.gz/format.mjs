import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import ts from '../../../..//preacher-automatic-response-qa-20261006/node_modules/typescript/lib/typescript.js'
const target = 'app/computer-runtime.ts'
const folder = 'work/orchestration/preacher-raid-format-fix-01'
const formatter = '../preacher-automatic-response-qa-20261006/node_modules/oxfmt/bin/oxfmt'
const before = readFileSync(target, 'utf8')
writeFileSync(`${folder}/before.ts`, before, { flag: 'wx' })
const applied = spawnSync(process.execPath, [formatter, target], { stdio: 'inherit', timeout: 15000 })
assert.equal(applied.status, 0)
const after = readFileSync(target, 'utf8')
writeFileSync(`${folder}/after.ts`, after, { flag: 'wx' })
const canonical = text => {
  const file = ts.createSourceFile(target, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  assert.equal(file.parseDiagnostics.length, 0)
  return ts.createPrinter({ removeComments: true }).printFile(file)
}
assert.equal(canonical(after), canonical(before), 'TypeScript AST printer is identical')
const checked = spawnSync(process.execPath, [formatter, '--check', target], { stdio: 'inherit', timeout: 15000 })
assert.equal(checked.status, 0)
const sha = text => createHash('sha256').update(text).digest('hex')
writeFileSync(`${folder}/correspondence.json`, JSON.stringify({ before:sha(before), after:sha(after),
  canonicalSha256:sha(canonical(after)), parseErrors:0, canonicalEqual:true,
  scope:'One-file formatting only; no application import, test, aggregate or build' }, null, 2)+'\n', { flag:'wx' })
