import subprocess,sys,os,time,json,signal
from pathlib import Path
root=Path(__file__).parent
child=None
started=time.time()
clean={'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timeoutSeconds':60,'cpu':[4]}
def exists(group):
 try: os.killpg(group,0);return True
 except ProcessLookupError: return False
def cleanup():
 if child and exists(child.pid):
  os.killpg(child.pid,signal.SIGTERM)
  try: child.wait(timeout=2)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2)
def stop(signum,frame):
 cleanup();raise SystemExit(128+signum)
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,stop)
try:
 child=subprocess.Popen(['taskset','-c','4',sys.argv[1],str(root/'diagnostic.mjs')],start_new_session=True)
 clean['pid']=child.pid;clean['processGroup']=os.getpgid(child.pid)
 clean['processIdentity']=Path(f'/proc/{child.pid}/stat').read_text()
 (root/'started.json').write_text(json.dumps(clean,indent=2)+'\n')
 try: rc=child.wait(timeout=58)
 except subprocess.TimeoutExpired: clean['timedOut']=True;cleanup();rc=124
finally:
 cleanup()
 clean.update({'elapsedSeconds':time.time()-started,'exitCode':locals().get('rc'),'resourcesReleased':child is not None and not exists(child.pid),'finishedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
 (root/'cleanup.json').write_text(json.dumps(clean,indent=2)+'\n')
sys.exit(rc if clean['resourcesReleased'] else 125)
