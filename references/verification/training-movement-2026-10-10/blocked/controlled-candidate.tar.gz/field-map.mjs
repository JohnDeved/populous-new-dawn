// Native byte offsets are transcribed from the repository's source-bound native
// checkers. No original executable or check script is executed by this adapter.
export const sources = [
  'scripts/check-native-person-state.py', 'scripts/check-native-person-motion.py',
  'scripts/check-native-physics-driver.py', 'scripts/check-native-route-advance.py',
  'scripts/check-native-marching.py', 'scripts/check-native-person-update.py',
  'scripts/check-native-animation.py', 'scripts/check-native-occupants.py',
  'scripts/check-native-mana.py', 'scripts/check-native-celebration.py',
]
export const personFields = {
  id:[0x24,'H'],class:[0x2a,'B'],model:[0x2b,'B'],state:[0x2c,'B'],substate:[0x2d,'B'],
  counter:[0x2e,'B'],tribe:[0x2f,'b'],physics:[0x30,'B'],
  flags2:[0xc,'I'],flags3:[0x14,'I'],flags4:[0x10,'I'],
  stamp:[0x18,'I'],supportHeight:[0x1c,'h'],marchCooldown:[0x1e,'B'],
  cellNext:[0x20,'H'],cellPrevious:[0x22,'H'],angle:[0x26,'H'],
  reactionTimer:[0x31,'B'],reactionDuration:[0x32,'B'],
  object:[0x33,'H'],renderFlags:[0x35,'H'],f1:[0x37,'h'],f2:[0x39,'B'],
  draw:[0x3a,'B'],morph:[0x3b,'B'],palette:[0x3c,'B'],x:[0x3d,'H'],y:[0x3f,'H'],h:[0x41,'h'],
  goalX:[0x4f,'H'],goalY:[0x51,'H'],destinationX:[0x53,'H'],destinationY:[0x55,'H'],
  turnAngle:[0x57,'H'],turnY:[0x59,'H'],heading:[0x5d,'H'],speed:[0x5f,'h'],
  motionTimer:[0x61,'h'],motionGroup:[0x63,'h'],recoveryCounter:[0x65,'B'],motionMode:[0x66,'B'],motionIndex:[0x67,'B'],
  anchorX:[0x68,'H'],anchorY:[0x6a,'H'],maxLife:[0x6c,'h'],life:[0x6e,'h'],
  timer:[0x70,'h'],target:[0x72,'H'],link:[0x74,'H'],assignment:[0x76,'H'],cargo:[0x78,'H'],
  selectionFlags:[0x7a,'B'],previousState:[0x7d,'B'],slowTurn:[0x7e,'B'],
  formationCell:[0x80,'H'],anchorFlags:[0x82,'B'],orderLocation:[0x83,'H'],reservationNext:[0x85,'H'],
  stateObject:[0x87,'H'],workTarget:[0x89,'H'],immediateCommand:[0x9b,'H'],workFlags:[0x9d,'H'],vehicle:[0x9f,'H'],
  savedVehicle:[0xa1,'H'],burnTrail:[0xa4,'B'],commandCursor:[0xa6,'B'],commandStatus:[0xa7,'B'],
  animationMode:[0xa8,'B'],commandAux:[0xa9,'B'],commandPhase:[0xaa,'B'],orderDelay:[0xab,'B'],formationDelay:[0xab,'B'],
  damageAttacker:[0xb0,'B'],healthMarker:[0xb0,'B'],statusFlags:[0xb2,'B'],disguise:[0xb2,'B'],
  morphTimer:[0x72,'h'],morphFrames:[0x71,'B'],
}
export const buildingFields = {
  id:[0x24,'H'],class:[0x2a,'B'],model:[0x2b,'B'],state:[0x2c,'B'],counter:[0x2e,'B'],tribe:[0x2f,'b'],
  object:[0x33,'h'],angle:[0x26,'H'],anchorX:[0x7a,'H'],anchorY:[0x7c,'H'],x:[0x3d,'H'],y:[0x3f,'H'],h:[0x41,'h'],
  flags2:[0xc,'I'],flags3:[0x14,'I'],flags4:[0x10,'I'],cellNext:[0x20,'H'],cellPrevious:[0x22,'H'],
  activity:[0x9c,'H'],inside:[0xa6,'B'],trainingTimer:[0x9a,'H'],trainingCost:[0x96,'H'],
  entryDelay:[0xab,'B'],lastActivity:[0x7e,'I'],queueHead:[0xa2,'H'],queueFrom:[0xac,'B'],entering:[0xad,'B'],entryTimer:[0xae,'B'],
  storedMana:[0x98,'H'],manaNext:[0xa0,'H'],
}
export function decodeFields(hex, fields) {
  if (typeof hex !== 'string' || !/^(?:[0-9a-f]{2})+$/i.test(hex) || hex.length < 0xb3*2) throw new Error('Missing or incomplete original unit bytes')
  const b = Buffer.from(hex,'hex'), methods={H:'readUInt16LE',h:'readInt16LE',I:'readUInt32LE',B:'readUInt8',b:'readInt8'}
  return Object.fromEntries(Object.entries(fields).map(([k,[o,f]])=>[k,b[methods[f]](o)]))
}
export function decodePerson(hex) {
  const p=decodeFields(hex,personFields), b=Buffer.from(hex,'hex')
  p.commands=Array.from({length:8},(_,i)=>b.readUInt16LE(0x8b+i*2))
  p.displacement={x:b.readInt16LE(0x43),y:b.readInt16LE(0x45),h:b.readInt16LE(0x47)}
  p.velocity={x:b.readInt16LE(0x49),y:b.readInt16LE(0x4b),z:b.readInt16LE(0x4d)}
  // Browser nullable occupancy is a projection of the captured native flag.
  p.building = p.flags2 & 0x800000 ? p.workTarget : null
  return p
}
export function decodeBuilding(hex) {
  const p=decodeFields(hex,buildingFields),b=Buffer.from(hex,'hex')
  p.occupants=Array.from({length:6},(_,i)=>b.readUInt16LE(0x86+i*2))
  return p
}
