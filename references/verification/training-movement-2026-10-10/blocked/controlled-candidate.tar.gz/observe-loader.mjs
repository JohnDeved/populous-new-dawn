// Diagnostic-only load hooks. Original source files remain untouched. Every
// replacement is an exact, unique anchor; inserted calls only copy observations.
import { registerHooks } from 'node:module'
import { createHash } from 'node:crypto'
const digest = source => createHash('sha256').update(source).digest('hex')
export const patchedSources = []
function replaceOne(source, before, after) {
  if (source.split(before).length !== 2) throw new Error(`Observer anchor is not unique: ${before}`)
  return source.replace(before, after)
}
registerHooks({
  load(url, context, nextLoad) {
    const result = nextLoad(url, context)
    if (!url.endsWith('/app/live-building-entry.ts') && !url.endsWith('/app/live-pathfinding.ts') && !url.endsWith('/app/building-occupants.ts')) return result
    const original = String(result.source)
    let source = original
    if (url.endsWith('/app/building-occupants.ts')) {
      source = replaceOne(source, 'export function enterBuilding(', 'function observedOriginalEnterBuilding(')
      source += '\nexport function enterBuilding(...args: Parameters<typeof observedOriginalEnterBuilding>) {\n  globalThis.__trainingObserve?.("admission-pre", args[1]);\n  const result = observedOriginalEnterBuilding(...args);\n  globalThis.__trainingObserve?.("admission-post", args[1], { result });\n  return result;\n}\n'
    }
    if (url.endsWith('/app/live-building-entry.ts')) {
      source = replaceOne(source, '  p.cargo = Math.round(u.cargo * 100)\n', '  p.cargo = Math.round(u.cargo * 100)\n  globalThis.__trainingObserve?.("post-counter", p)\n')
      source = replaceOne(source, '    ctx.randomState = w.randomState\n    moveLivePerson(w, u, p)\n', '    ctx.randomState = w.randomState\n    globalThis.__trainingObserve?.("pre-motion", p)\n    moveLivePerson(w, u, p)\n    globalThis.__trainingObserve?.("post-motion", p)\n')
      source = replaceOne(source, '  let admitted = false\n', '  globalThis.__trainingObserve?.("pre-command", p)\n  let admitted = false\n')
      source = replaceOne(source, '  u.cargo = p.cargo / 100\n  u.heading', '  globalThis.__trainingObserve?.("post-command", p)\n  u.cargo = p.cargo / 100\n  u.heading')
    }
    if (url.endsWith('/app/live-pathfinding.ts')) {
      if (source.includes('    if (p !== u.entry?.person) p.counter = w.turn & 255\n')) source = replaceOne(source, '    if (p !== u.entry?.person) p.counter = w.turn & 255\n', '    globalThis.__trainingObserve?.("pre-route-counter-guard", p, { writesCounter: p !== u.entry?.person })\n    if (p !== u.entry?.person) p.counter = w.turn & 255\n    globalThis.__trainingObserve?.("post-route-counter-guard", p)\n')
      else source = replaceOne(source, '    p.counter = w.turn & 255\n', '    globalThis.__trainingObserve?.("pre-route-counter-write", p)\n    p.counter = w.turn & 255\n    globalThis.__trainingObserve?.("post-route-counter-write", p)\n')
    }
    patchedSources.push({ url, originalSha256: digest(original), observedSha256: digest(source), mode: 'observation-only' })
    return { ...result, source }
  },
})
