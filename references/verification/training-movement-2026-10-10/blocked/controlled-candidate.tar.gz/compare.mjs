import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
const hash=b=>createHash('sha256').update(b).digest('hex')
const [nativePath,browserPath]=process.argv.slice(2)
if(!nativePath||!browserPath)throw Error('Usage: node compare.mjs NATIVE_RESULT BROWSER_RESULT')
const n=JSON.parse(fs.readFileSync(nativePath)),b=JSON.parse(fs.readFileSync(browserPath)),out=path.join(path.dirname(browserPath),'comparison.json')
assert.equal(b.validation.status,'passed','initial equivalence validation must pass before timeline comparison')
const diffs=(expected,actual)=>Object.entries(expected).flatMap(([key,value])=>{
  const target=key==='cellPrev'?'cellPrevious':key
  if(!(target in actual))return []
  return JSON.stringify(value)===JSON.stringify(actual[target])?[]:[{field:target,native:value,browser:actual[target]}]
})
const personKeys=['id','class','model','state','substate','counter','tribe','physics','flags2','flags3','flags4','stamp','supportHeight','cellNext','cellPrev','angle','object','renderFlags','f1','f2','draw','morph','palette','x','y','h','goalX','goalY','destinationX','destinationY','turnAngle','turnY','heading','speed','motionTimer','motionGroup','motionIndex','recoveryCounter','motionMode','anchorX','anchorY','maxLife','life','timer','target','assignment','cargo','selectionFlags','previousState','slowTurn','anchorFlags','orderLocation','reservationNext','workTarget','immediateCommand','vehicle','commandCursor','commandStatus','animationMode','commandAux','commandPhase','formationDelay','statusFlags','displacement','commands']
const pick=(obj,keys)=>Object.fromEntries(keys.filter(k=>k in obj).map(k=>[k,obj[k]]))
const phases=[],missing=[]
for(const visit of n.turnVisits){
  const bv=b.turnVisits.find(v=>v.turn===visit.turn&&v.id===visit.id)
  if(!bv){missing.push({turn:visit.turn,id:visit.id,phase:'person visit'});continue}
  for(const [nativePhase,browserPhase,label]of [['before','post-counter','post-counter/preparation'],['preCommand','pre-command','post-motion/pre-command'],['after',null,'post-person']]){
    if(!visit[nativePhase]){missing.push({turn:visit.turn,id:visit.id,phase:nativePhase});continue}
    const actual=browserPhase?b.phases.find(p=>p.turn===visit.turn&&p.phase===browserPhase&&p.person.id===visit.id)?.person:bv.after
    if(!actual){missing.push({turn:visit.turn,id:visit.id,phase:browserPhase});continue}
    const differences=diffs(pick(visit[nativePhase],personKeys),actual)
    phases.push({turn:visit.turn,id:visit.id,phase:label,differences})
  }
}
const nontrivial=['x','y','h','substate','state','counter','speed','heading','angle','goalX','goalY','destinationX','destinationY','turnAngle','turnY','motionGroup','motionIndex','recoveryCounter','assignment','formationDelay','flags2','flags3','flags4','workTarget']
const first=predicate=>phases.flatMap(p=>{const differences=p.differences.filter(predicate);return differences.length?[{...p,differences}]:[]})[0]??null
const endTurns=n.timeline.flatMap(nt=>{
 const bt=b.timeline.find(t=>t.turn===nt.turn);if(!bt)return []
 return [{turn:nt.turn,building:diffs(nt.building,bt.building),randomState:nt.randomState===bt.randomState?null:{native:nt.randomState,browser:bt.randomState},poseRandom:nt.poseRandom===bt.poseRandom?null:{native:nt.poseRandom,browser:bt.poseRandom},outsideEntering:{native:nt.people.filter(p=>p.substate===5&&!(p.flags2&0x800000)).map(p=>p.id),browser:bt.outsideEntering}}]
})
const nativeAdmissions=n.admissions.map(a=>({turn:a.turn,id:a.person,result:a.result})),browserAdmissions=b.admissions.filter(a=>a.phase==='admission-post').map(a=>({turn:a.turn,id:a.person.id,result:a.result}))
const groupByTurn=rows=>Object.entries(Object.groupBy(rows.filter(r=>r.result),r=>r.turn)).map(([turn,rs])=>({turn:Number(turn),ids:rs.map(r=>r.id)}))
const admissionsEqual=JSON.stringify(nativeAdmissions)===JSON.stringify(browserAdmissions)
const nativeAllocations=n.events.filter(e=>e.name==='allocate'&&e.turn>0&&e.args[0]===10&&e.args[1]===1)
const formationMapping=nativeAllocations.map((a,i)=>({ordinal:i+1,nativeId:a.resultId,browserId:b.formationAllocations[i]?.id,nativeTurn:a.turn,browserTurn:b.formationAllocations[i]?.turn}))
const mapId=id=>formationMapping.find(x=>x.nativeId===id)?.browserId
const formationTurns=n.timeline.flatMap(nt=>{const bt=b.timeline.find(t=>t.turn===nt.turn);if(!bt)return [];const active=nt.formations.filter(g=>g.class),other=bt.formations.filter(g=>g.class);return [{turn:nt.turn,nativeOrder:active.map(g=>g.id),mappedNativeOrder:active.map(g=>mapId(g.id)),browserOrder:other.map(g=>g.id),differences:active.flatMap(g=>{const bg=other.find(o=>o.id===mapId(g.id));if(!bg)return [{nativeId:g.id,browserId:mapId(g.id),missing:true}];const fields=diffs(Object.fromEntries(Object.entries(g).filter(([k])=>!['id','bytes','counter'].includes(k))),bg);return fields.length?[{nativeId:g.id,browserId:bg.id,fields}]:[]})}]})
const firstFormationDifference=formationTurns.find(t=>t.differences.length||JSON.stringify(t.mappedNativeOrder)!==JSON.stringify(t.browserOrder))??null
const routeRecords=n.timeline.flatMap(nt=>{const bt=b.timeline.find(t=>t.turn===nt.turn);if(!bt)return [];return [{turn:nt.turn,recordsEqual:hash(Buffer.from(nt.routes.recordsHex,'hex'))===bt.routes.recordsSha256,fields:diffs(pick(nt.routes,['active','last','cursor']),bt.routes)}]})
const projectTerrain=hex=>{const input=Buffer.from(hex,'hex'),out=Buffer.alloc(16384*12);for(let i=0;i<16384;i++){const a=i*16,o=i*12;out.writeUInt32LE(input.readUInt32LE(a),o);out.writeInt16LE(input.readInt16LE(a+4),o+4);out.writeUInt16LE(input.readUInt16LE(a+8),o+6);out[o+8]=input[a+12];out[o+9]=input[a+10];out[o+10]=input[a+14];out[o+11]=input[a+15]}return hash(out)}
const terrainComparison=(n.terrainTrace??[]).flatMap(nt=>{const bt=b.terrainTrace?.find(t=>t.turn===nt.turn);if(!bt)return [{turn:nt.turn,missing:true}];return [{turn:nt.turn,beforeEqual:projectTerrain(nt.before.terrainHex)===bt.before.projectionSha256,afterEqual:projectTerrain(nt.after.terrainHex)===bt.after.projectionSha256,queueCount:{native:nt.after.count,browser:bt.after.count},browserTextureEventCount:bt.events.length}]})
const capacity=5
const maxEntering=(ts)=>Math.max(0,...ts.map(t=>t.building.entering))
const queue=state=>{const ids=[];for(let id=state.building.queueHead;id;){assert(!ids.includes(id));ids.push(id);const p=state.people.find(p=>p.id===id);assert(p);id=p.reservationNext}return ids}
const result={status:first(()=>true)?'diverged':'matched-observed-projection',scope:'Source-bound controlled browser-model/native CPU diagnostic; neither full-world nor rendered parity',nativePath,browserPath,initialValidation:b.validation.status,schedule:b.binding.schedule,comparedNativeTurns:endTurns.length,nativeTurns:n.timeline.length,browserTurns:b.timeline.length,missing,firstObservedPersonDifference:first(()=>true),firstControlDifference:first(d=>nontrivial.includes(d.field)),firstCounterDifference:first(d=>d.field==='counter'),firstPositionDifference:first(d=>['x','y','h'].includes(d.field)),firstRouteDifference:first(d=>['motionGroup','motionIndex','goalX','goalY','destinationX','destinationY','turnAngle','turnY'].includes(d.field)),firstBuildingDifference:endTurns.find(t=>t.building.length)??null,firstRngDifference:endTurns.find(t=>t.randomState||t.poseRandom)??null,admissions:{equal:admissionsEqual,native:nativeAdmissions,browser:browserAdmissions,nativeByTurn:groupByTurn(nativeAdmissions),browserByTurn:groupByTurn(browserAdmissions)},capacity,terrainComparison,formationMapping,firstFormationDifference,formationTurns,firstRoutePoolDifference:routeRecords.find(t=>!t.recordsEqual||t.fields.length)??null,routeRecords,maxEntering:{native:maxEntering(n.timeline),browser:maxEntering(b.timeline)},final:{native:{turn:n.timeline.at(-1)?.turn,inside:n.timeline.at(-1)?.building.inside,queue:n.timeline.length?queue(n.timeline.at(-1)):null},browser:{turn:b.timeline.at(-1)?.turn,inside:b.timeline.at(-1)?.building.inside,queue:b.timeline.length?queue(b.timeline.at(-1)):null}},phases,endTurns,limits:b.limits}
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({status:result.status,initialValidation:result.initialValidation,turns:result.comparedNativeTurns,firstObserved:result.firstObservedPersonDifference,firstControl:result.firstControlDifference,firstCounter:result.firstCounterDifference,firstPosition:result.firstPositionDifference,admissions:result.admissions,maxEntering:result.maxEntering,final:result.final,output:out}))
