import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import assert from 'node:assert/strict'
const D=path.dirname(new URL(import.meta.url).pathname),N=path.resolve(D,'../tight-native/attempt01'),root=path.resolve(D,'../../../../..'),source=path.resolve(root,'training-movement-composition-20261010')
const read=p=>JSON.parse(fs.readFileSync(p)),hash=b=>createHash('sha256').update(b).digest('hex')
const initial=read(path.join(N,'initial.json')),fixture=read(path.join(N,'../fixture.json'))
const tag=id=>initial.people.find(p=>p.id===id)?.geometryTag??id
const difference=(a,b)=>Object.keys({...a,...b}).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k])).map(k=>({field:k,native:a[k]??null,app:b[k]??null}))
const rows=state=>({turn:state.turn,inside:state.building.inside,enteringCounter:state.building.entering,outsideSubstate5:state.people.filter(p=>p.substate===5&&!(p.flags2&0x800000)).map(p=>tag(p.id)),queue:state.queue??null})
const native=read(path.join(N,'result.json'))
const summary={scope:'Reduced tight-eight controlled model diagnostic; 33 paired turns; no ordinary UI reproduction or global lifetime claim',fixture,initialNative:{randomState:initial.randomState,poseRandom:initial.poseRandom,visitOrder:initial.allocationOrder.filter(id=>initial.people.some(p=>p.id===id)).map(tag),phases:initial.people.map(p=>({tag:tag(p.id),counter:p.counter,angle:p.angle}))},native:{status:native.status,admissions:native.admissions.map(a=>({turn:a.turn,tag:tag(a.person),result:a.result})),timeline:native.timeline.map(rows)},arms:{}}
for(const arm of ['exact-native-snapshot','app-producer01','phase-only-counter-control']){
 const result=read(path.join(D,arm,'result.json')),comparison=read(path.join(D,arm,'comparison.json'))
 const counts={};for(const p of comparison.phases)for(const d of p.differences)counts[d.field]=(counts[d.field]??0)+1
 const buildingCounts={};for(const p of comparison.endTurns)for(const d of p.building)buildingCounts[d.field]=(buildingCounts[d.field]??0)+1
 const timeline=result.timeline.map(rows),admissions=result.admissions.filter(a=>a.phase==='admission-post').map(a=>({turn:a.turn,tag:tag(a.person.id),result:a.result}))
 const current=new Map(initial.people.map(p=>[p.id,p])),outsideDuringVisits=[]
 for(const v of result.turnVisits){current.set(v.id,v.after);outsideDuringVisits.push({turn:v.turn,tag:tag(v.id),tags:[...current.values()].filter(p=>p.substate===5&&!(p.flags2&0x800000)).map(p=>tag(p.id))})}
 summary.arms[arm]={status:result.status,sourceHead:result.binding.head,initialValidation:result.validation.status,initialRandomState:result.initial.randomState,initialPoseRandom:result.initial.poseRandom,admissions,timeline,maxOutsideSubstate5EndTurn:Math.max(...timeline.map(t=>t.outsideSubstate5.length)),maxOutsideSubstate5AfterPersonVisit:Math.max(...outsideDuringVisits.map(t=>t.tags.length)),maxEnteringCounter:Math.max(...timeline.map(t=>t.enteringCounter)),finalInside:timeline.at(-1).inside,personDifferenceCounts:counts,buildingDifferenceCounts:buildingCounts,firstObserved:comparison.firstObservedPersonDifference,firstControl:comparison.firstControlDifference,firstPosition:comparison.firstPositionDifference,firstRng:comparison.firstRngDifference,firstFormation:comparison.firstFormationDifference,firstRoutePool:comparison.firstRoutePoolDifference,formationMapping:comparison.formationMapping,terrainAllBeforeAfterEqual:comparison.terrainComparison.every(t=>t.beforeEqual&&t.afterEqual)}
 fs.writeFileSync(path.join(D,arm,'per-turn-summary.json'),JSON.stringify({admissions,timeline,outsideDuringVisits},null,2)+'\n')
 if(arm==='app-producer01'){
  const control=read(path.join(D,'exact-native-snapshot/initial-browser.json'))
  summary.producer={initialPersonDifferences:control.people.map(p=>({tag:tag(p.id),id:p.id,differences:difference(p,result.initial.people.find(q=>q.id===p.id))})),worldScalarDifferences:difference(Object.fromEntries(['randomState','poseRandom','orderActive','orderCursor','cellHeadsSha256','browserNextId'].map(k=>[k,control[k]])),Object.fromEntries(['randomState','poseRandom','orderActive','orderCursor','cellHeadsSha256','browserNextId'].map(k=>[k,result.initial[k]]))),events:result.producerTrace.map(e=>({phase:e.phase,id:e.id??e.person?.id,tag:tag(e.id??e.person?.id),personCounter:e.person?.counter,worldRandomState:e.world.randomState,people:e.world.people.map(p=>({tag:tag(p.id),counter:p.counter,state:p.state,angle:p.angle,speed:p.speed}))}))}
 }
}
const control=read(path.join(D,'exact-native-snapshot/initial-browser.json')),phase=read(path.join(D,'phase-only-counter-control/initial-browser.json')),app=read(path.join(D,'app-producer01/initial-browser.json'))
const counterDeltas=[]
for(const p of control.people){const q=phase.people.find(q=>q.id===p.id),produced=app.people.find(q=>q.id===p.id);assert.equal(q.counter,produced.counter);counterDeltas.push({id:p.id,tag:tag(p.id),native:p.counter,intervention:q.counter,actualApp:produced.counter})}
const normalize=s=>{s=structuredClone(s);for(const p of s.people)p.counter=0;for(const u of s.units)u.entry.person.counter=0;return s}
assert.deepEqual(normalize(control),normalize(phase))
summary.counterOnlyIndependentAssertion={passed:true,statement:'Across separately generated initial-browser captures, every captured field including person-owner aliases, full command pool, full route arrays, RNG, building, formation/cell-head hash and visit order is exactly equal after masking only person counters. Each intervened counter equals actual app-produced value mapped by fixture geometry tag.',counterDeltas}
summary.native.maxOutsideSubstate5EndTurn=Math.max(...summary.native.timeline.map(t=>t.outsideSubstate5.length))
summary.native.maxEnteringCounter=Math.max(...summary.native.timeline.map(t=>t.enteringCounter))
summary.conclusion='Exact-native-input candidate matches tight admissions/mapped movement/RNG/formation/routes. Actual app materialization/resting/command produces a four-way burst but carries numerous non-counter confounds. Counter-only intervention changes admission timing and produces a pair, not the four-way burst or ordinary triple. Phase synchronization alone is insufficient to explain this reduced fixture; no global counter repair or ordinary-M3 cause is established.'
fs.writeFileSync(path.join(D,'summary.json'),JSON.stringify(summary,null,2)+'\n')
const repo=path.resolve(D,'../../../..')
const manifest={capturedAt:new Date().toISOString(),runtime:process.version,research:{root:repo,head:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),status:execFileSync('git',['status','--short'],{cwd:repo,encoding:'utf8'})},candidate:{root:source,head:execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),status:execFileSync('git',['status','--short'],{cwd:source,encoding:'utf8'})},sourceFiles:execFileSync('git',['ls-files','app'],{cwd:source,encoding:'utf8'}).trim().split('\n').filter(p=>/\.(ts|tsx|json)$/.test(p)).map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(source,p)))}))}
fs.writeFileSync(path.join(D,'source-manifest.json'),JSON.stringify(manifest,null,2)+'\n')
console.log(JSON.stringify({summary:path.join(D,'summary.json'),counterOnlyAssertion:'passed',arms:Object.fromEntries(Object.entries(summary.arms).map(([k,v])=>[k,{admissions:v.admissions,maxOutside:v.maxOutsideSubstate5EndTurn,finalInside:v.finalInside}]))}))
