from pathlib import Path
D=Path(__file__).parent
s=(D/'replay.mjs').read_text().replace("['native-snapshot','app-producer'].includes(arm)","['native-snapshot','app-producer','phase-only-intervention'].includes(arm)")
s=s.replace("adapter:['replay.mjs'", "adapter:['replay-phase-only.mjs'")
needle="  const initialBrowser=worldSnap();"
s=s.replace(needle,"""  if(arm==='phase-only-intervention') {
    const producerSource=path.join(here,'app-producer01/initial-browser.json'),produced=readJSON(producerSource)
    const pre=worldSnap(),changes=[]
    for(const p of people){
      const tag=initial.people.find(q=>q.id===p.id).geometryTag
      const mappedId=initial.people.find(q=>q.geometryTag===tag).id
      const app=produced.people.find(q=>q.id===mappedId);assert(app)
      changes.push({geometryTag:tag,id:p.id,nativeCounter:p.counter,actualAppCounter:app.counter})
      p.counter=app.counter
    }
    const post=worldSnap()
    const mask=state=>{for(const p of state.people)p.counter=0;for(const u of state.units)u.entry.person.counter=0;return state}
    assert.deepEqual(mask(structuredClone(pre)),mask(structuredClone(post)),'intervention changes only person counters and owner aliases')
    const intervention={label:'Artificial browser-only counter intervention; not actual app pipeline or native oracle',source:producerSource,sourceSha256:hash(fs.readFileSync(producerSource)),changes,allOtherSnapshotFieldsExactlyEqual:true,beforeSha256:hash(JSON.stringify(pre)),afterSha256:hash(JSON.stringify(post))}
    fs.writeFileSync(path.join(output,'intervention.json'),JSON.stringify(intervention,null,2)+'\\n')
    binding.intervention=intervention
  }
"""+needle)
s=s.replace("'App producer initial state may differ", "'Phase-only intervention copies only actual arm2-produced counters into native-derived browser state; native oracle remains unmodified', 'App producer initial state may differ")
(D/'replay-phase-only.mjs').write_text(s)
