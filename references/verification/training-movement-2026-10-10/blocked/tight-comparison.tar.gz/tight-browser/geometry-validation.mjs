import assert from 'node:assert/strict'
import fs from 'node:fs'
import {createHash} from 'node:crypto'
export function validateGeometry(fixture,initial,native){
 const hash=b=>createHash('sha256').update(b).digest('hex')
 assert.equal(hash(fs.readFileSync(fixture.geometrySource)),fixture.geometrySourceSha256)
 assert.equal(initial.turn,fixture.initialTurn)
 assert.equal(initial.turn,0)
 assert.equal(initial.people.length,8)
 assert.equal(new Set(initial.people.map(p=>p.geometryTag)).size,8)
 for(const p of initial.people){
  const f=fixture.people.find(f=>f.geometryTag===p.geometryTag);assert(f)
  for(const k of ['x','y','h'])assert.equal(p[k],f[k],`tag ${p.geometryTag}: ${k}`)
  assert.equal(p.angle,0)
 }
 assert.deepEqual(initial.allocationOrder.filter(id=>initial.people.some(p=>p.id===id)).map(id=>initial.people.find(p=>p.id===id).geometryTag),fixture.desiredPrimaryPersonVisitOrder)
 for(const key of ['model','object','tribe','angle','anchorX','anchorY','h'])assert.equal(initial.building[key],fixture.building[key])
 assert.deepEqual(native.turnVisits.filter(v=>v.turn===1).map(v=>initial.people.find(p=>p.id===v.id).geometryTag),fixture.desiredPrimaryPersonVisitOrder)
 assert.equal(native.status,'completed')
}
