from pathlib import Path
D=Path(__file__).parent
p=D/'replay.mjs';s=p.read_text()
s=s.replace("const [initialPath,resultPath,outputName='replay',schedule='browser']", "const [initialPath,resultPath,outputName='replay',schedule='browser',arm='native-snapshot']")
s=s.replace("assert.ok(['browser','native-clock-control'].includes(schedule))", "assert.equal(schedule,'browser'); assert.ok(['native-snapshot','app-producer'].includes(arm))")
s=s.replace("const initial=readJSON(initialPath),native=readJSON(resultPath)","const initial=readJSON(initialPath),native=readJSON(resultPath),fixturePath=path.resolve(path.dirname(initialPath),'../fixture.json'),fixture=readJSON(fixturePath)\nconst beforePath=path.join(path.dirname(initialPath),'before-command.json'),beforeCommand=readJSON(beforePath)\nconst {validateGeometry}=await import('./geometry-validation.mjs'); validateGeometry(fixture,initial,native)")
s=s.replace("'app/live-building-entry.ts','app/live-people.ts'", "'app/live-command.ts','app/live-resting.ts','app/person-idle.ts','app/resting-slots.ts','app/command-context.ts','app/selection-runtime.ts','app/live-building-entry.ts','app/live-people.ts'")
s=s.replace("[initialPath,resultPath].map", "[initialPath,resultPath,fixturePath,beforePath].map")
s=s.replace("node:process.version,schedule,adapter:","node:process.version,schedule,arm,adapter:")
s=s.replace("'field-map.mjs','compare.mjs'", "'field-map.mjs','compare.mjs','geometry-validation.mjs'")
s=s.replace("50aefe1d49f70057380bf9a5fa8f0b319c8ad441", "96a465d1b3dfb7ff7aae34865088308dc26d4783")
s=s.replace("building.model===5&&building.object===95&&building.angle===0&&building.anchorX===16384&&building.anchorY===16384,'exact Temple model5 object95 pose'", "building.model===fixture.building.model&&building.object===fixture.building.object&&building.angle===fixture.building.angle&&building.anchorX===fixture.building.anchorX&&building.anchorY===fixture.building.anchorY,'exact input-bound Warrior Hut pose'")
s=s.replace("targets Temple", "targets Warrior Hut")
s=s.replace("kind:'temple'", "kind:'camp'")
s=s.replace("assert.deepEqual(buildingOutsidePoint(buildingPose(b)),{x:16640,y:15232})", "assert.deepEqual(buildingOutsidePoint(buildingPose(b)),fixture.building.outsidePoint)")
s=s.replace("assert.deepEqual(buildingInsidePoint(buildingPose(b)),{x:16640,y:16448})", "assert.deepEqual(buildingInsidePoint(buildingPose(b)),fixture.building.insidePoint)")
s=s.replace("const phases=[],turnVisits=[],timeline=[],admissions=[],formationAllocations=[],terrainTrace=[]", "const phases=[],turnVisits=[],timeline=[],admissions=[],formationAllocations=[],terrainTrace=[],producerTrace=[]")
s=s.replace("const worldSnap=()=>({turn:w.turn,people:people.map(snapPerson)", "const worldSnap=()=>({turn:w.turn,people:people.map(snapPerson),visitOrder:w.units.map(u=>u.id),units:structuredClone(w.units),orders:structuredClone(w.buildingOrders),fullRoutes:structuredClone(w.motionRoutes)")
s=s.replace("  const initialBrowser=worldSnap();", """  if(arm==='app-producer') {
    const {stepLiveResting}=await import(path.join(root,'app/live-resting.ts'))
    const {removeObjectFromCell}=await import(path.join(root,'app/object-cells.ts'))
    const {command,liveCommandContext}=await import(path.join(root,'app/live-command.ts'))
    const {createPersonOrders}=await import(path.join(root,'app/person-orders.ts'))
    // Reset only the person/bootstrap portion to pre-command native world inputs.
    // Native person records are removed, never copied into the app producer.
    for(const p of people)removeObjectFromCell(w.objectCells,p)
    w.units=[];people=[];w.selected=[]
    w.randomState=beforeCommand.randomState;w.cosmeticRandom.randomState=beforeCommand.poseRandom
    const ob=Buffer.from(beforeCommand.orderPoolHex,'hex')
    w.buildingOrders={records:Array.from({length:800},(_,i)=>({model:ob[i*10],flags:ob[i*10+1],references:ob.readUInt16LE(i*10+2),object:ob.readUInt16LE(i*10+4),a:ob.readUInt16LE(i*10+6),b:ob.readUInt16LE(i*10+8)})),cursor:beforeCommand.orderCursor,active:beforeCommand.orderActive}
    Object.assign(b.admission,decodeBuilding(beforeCommand.building.bytes))
    const r=beforeCommand.routes
    w.motionRoutes={records:Uint8Array.from(Buffer.from(r.recordsHex,'hex')),active:r.active,last:r.last,cursor:r.cursor,failedSearches:Uint8Array.from(Buffer.from(r.failedSearchesHex,'hex')),pathResult:Uint8Array.from(Buffer.from(r.pathResultHex,'hex'))}
    for(const k of ['skip','computerLimit','humanLimit','computerRequests','humanRequests'])w.pathfinding[k]=r[k]
    w.indexedSearch.set(Buffer.from(beforeCommand.formationSearchHex,'hex'))
    w.status='playing';w.paused=false
    const producerSnap=(phase,extra={})=>producerTrace.push({phase,world:worldSnap(),...structuredClone(extra)})
    globalThis.__producerObserve=(phase,p,extra={})=>producerSnap(phase,{person:p,...extra})
    producerSnap('before-materialization',{initialWorldRng:beforeCommand.randomState,initialPoseRng:beforeCommand.poseRandom})
    for(const tag of fixture.desiredPrimaryPersonVisitOrder){
      const geometry=fixture.people.find(p=>p.geometryTag===tag),id=initial.people.find(p=>p.geometryTag===tag).id
      producerSnap('before-addUnit',{tag,id,geometry})
      const u=addUnit(w,'blue','brave',browserPosition(geometry));u.id=id;u.heading=Math.PI
      producerSnap('after-addUnit',{tag,id,unit:u})
    }
    w.selected=w.units.map(u=>u.id)
    for(const u of w.units){
      producerSnap('before-stepLiveResting',{id:u.id})
      stepLiveResting(w,u)
      people=w.units.map(u=>u.native).filter(Boolean)
      producerSnap('after-stepLiveResting',{id:u.id})
    }
    for(const p of people){const f=fixture.people.find(f=>initial.people.find(q=>q.id===p.id).geometryTag===f.geometryTag);assert.equal(p.x,f.x);assert.equal(p.y,f.y);assert.equal(p.h,f.h)}
    producerSnap('before-public-command',{context:liveCommandContext(w,{...b,id:b.id})})
    const accepted=command(w,{...b,id:b.id})
    people=w.units.map(u=>u.entry?.person??u.native).filter(Boolean)
    producerSnap('after-public-command',{accepted})
    assert.equal(accepted,true,'public shared training command accepted')
    assert.equal(people.length,8)
    assert(people.every(p=>p.commandStatus===8),'all app-produced people retain command8')
    assert.equal(new Set(people.map(p=>p.commands[p.commandCursor])).size,1)
    w.nextId=Math.max(...initial.allocationOrder)+1
    delete globalThis.__producerObserve
  }
  const initialBrowser=worldSnap();""")
s=s.replace("timeline,turnVisits,phases,admissions,formationAllocations", "timeline,turnVisits,phases,admissions,producerTrace,formationAllocations")
s=s.replace("'Imported synthetic native snapshot; not ordinary browser UI or rendered pixels'", "'Arm native-snapshot imports exact native initial; arm app-producer retains native pre-command world/building but invokes real app addUnit, stepLiveResting and public command. Neither is ordinary browser UI or rendered pixels',...fixture.limits,'App producer initial state may differ in flags, motion, routes, RNG, cells, and other records as well as counter. No phase-only causal attribution is made'")
p.write_text(s)
# Wrap materialization without changing callers or values.
p=D/'observe-loader.mjs';s=p.read_text()
s=s.replace("!url.endsWith('/app/building-occupants.ts'))", "!url.endsWith('/app/building-occupants.ts') && !url.endsWith('/app/live-people.ts'))")
s=s.replace("    if (url.endsWith('/app/building-occupants.ts')) {", """    if(url.endsWith('/app/live-people.ts')) {
      source=replaceOne(source,'export function createLivePerson(', 'function observedOriginalCreateLivePerson(')
      source += '\\nexport function createLivePerson(...args: Parameters<typeof observedOriginalCreateLivePerson>) {\\n globalThis.__producerObserve?.("before-createLivePerson", null, {unit:args[1]});\\n const result=observedOriginalCreateLivePerson(...args);\\n globalThis.__producerObserve?.("after-createLivePerson", result);\\n return result;\\n}\\n'
    }
    if (url.endsWith('/app/building-occupants.ts')) {""")
p.write_text(s)
