import assert from 'node:assert/strict'
import levelSix from '../../../app/level-six.ts'
import scriptSix from '../../../app/original-script-six.json' with { type: 'json' }
import { addUnit, browserPosition, createWorld, joinBattle, tick as underlyingTick } from '../../../app/model.ts'
import { migrateCheckpoint } from '../../../app/game-store.ts'
import { syncLivePersonCells } from '../../../app/live-people.ts'
import { stepLiveConversionVictim, stepLivePreaching as underlyingPreaching } from '../../../app/live-movement.ts'
import { currentPersonOrder } from '../../../app/person-orders.ts'
import { stepOutcome } from '../../../app/tribe-turns.ts'
import { buildingFootprintCells, buildingModel } from '../../../app/building-shapes.ts'
import { nativeCellIndex, nativePosition } from '../../../app/world-terrain-runtime.ts'
import { spiralCell } from '../../../app/native-math.ts'
import rules from '../../../app/original-rules.json' with { type: 'json' }
import { campaignInternal, withCampaignTribe } from '../../../app/campaign-runtime.ts'
import { stepComputerTasks } from '../../../app/computer-runtime.ts'
import { createComputerQueue, requestAttack, stepAttackTask } from '../../../app/computer.ts'
import { createLivePerson } from '../../../app/live-people.ts'


import { openSync, writeSync, writeFileSync, readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const sha = text => createHash('sha256').update(text).digest('hex')
const out = new URL('./', import.meta.url)
const fd = openSync(new URL('trace.jsonl', out), 'wx')
let tickCount = 0, preachingCount = 0, nextWorld = 0, lastWorld
const worlds = new WeakMap(), states = new WeakMap()
const wanted = ['id','class','model','tribe','state','previousState','substate','speed','life','x','y','h','goalX','goalY','flags2','flags3','flags4','workFlags','workTarget','vehicle','disguise','group','computerAssignment','counter','commandStatus','commandAux','commandPhase','timer','assignment','immediateCommand','commands','commandCursor','cellPrevious','cellNext','damageAttacker']
const pick = p => p && Object.fromEntries(wanted.filter(k=>k in p).map(k=>[k,p[k]]))
const person = u => u.builder?.person ?? u.flight ?? u.fight?.motion ?? u.native ?? u.entry?.person
function unit(w,u,detail=false) {
  const p=person(u), native=u.native, registered=w.objectCells.objects.get(u.id)
  const order=p&&currentPersonOrder(w.buildingOrders,p)
  const cell=p?((p.y>>9)*128+(p.x>>9)):null
  const chain=[]
  if(detail && cell!==null){const seen=new Set(); for(let id=w.objectCells.heads[cell]; id&&!seen.has(id);){seen.add(id);chain.push(id);id=w.objectCells.objects.get(id)?.cellNext??0;}}
  const result={id:u.id,team:u.team,kind:u.kind,hp:u.hp,x:u.x,z:u.z,target:u.target,inside:u.inside,work:u.work,
    fight:u.fight?{...u.fight,motion:undefined}:null, fighting:u.fighting, flight:!!u.flight,
    p:detail?pick(p):p&&{state:p.state,substate:p.substate,life:p.life,commandStatus:p.commandStatus,workTarget:p.workTarget},
    order:order&&{...order},nativeOwner:p===native,registryOwner:registered===p,
    nativeRegistered:native&&registered===native,cell,linked:p?!!(p.flags2&0x20000):false}
  if(detail){result.chain=chain;result.inChain=chain.includes(u.id);result.registry=pick(registered);result.native=pick(native);result.path=u.path;result.goal=u.goal;}
  return result
}
function neighbors(w,p){
  if(!p)return[]
  const cells=[],rx=1,cx=p.x>>9,cy=p.y>>9
  for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++){
    const cell=((cy+y+128)%128)*128+((cx+x+128)%128), objects=[],seen=new Set()
    for(let id=w.objectCells.heads[cell];id&&!seen.has(id);){seen.add(id);const record=w.objectCells.objects.get(id);objects.push({id,record:pick(record),unit:w.units.find(u=>u.id===id)?unit(w,w.units.find(u=>u.id===id),false):null});id=record?.cellNext??0;}
    cells.push({cell,head:w.objectCells.heads[cell],objects})
  }
  return cells
}
function observe(w,kind){
  if(!worlds.has(w))worlds.set(w,++nextWorld)
  lastWorld=w
  const world=worlds.get(w), previous=states.get(w)??{vitals:new Map(),preachers:new Map()}
  const tasks=w.campaignAIs.flatMap((ai,tribe)=>ai?.tasks?.flatMap((t,index)=>t.type===20?[{tribe,index,...t}]:[])??[])
  const members=new Set(tasks.flatMap(t=>t.members))
  const preachers=w.units.filter(u=>u.kind==='preacher').map(u=>unit(w,u,true))
  const keyPreachers=new Map(preachers.map(u=>[u.id,JSON.stringify([u.order,u.p?.state,u.p?.substate,u.p?.speed,u.registryOwner,u.p?.immediateCommand])]))
  const interesting=preachers.filter(u=>previous.preachers.get(u.id)!==keyPreachers.get(u.id)).map(u=>({id:u.id,cells:neighbors(w,person(w.units.find(v=>v.id===u.id)))}))
  const vitals=new Map(w.units.map(u=>[u.id,JSON.stringify([u.team,u.kind,u.hp,u.target,u.inside,u.work,u.fight?{...u.fight,motion:undefined}:null,u.native?.state,u.native?.workTarget])]))
  const changed=[]
  for(const u of w.units)if(previous.vitals.get(u.id)!==vitals.get(u.id))changed.push(unit(w,u,members.has(u.id)))
  for(const id of previous.vitals.keys())if(!vitals.has(id))changed.push({id,removed:true,previous:JSON.parse(previous.vitals.get(id))})
  const record={kind,world,turn:w.turn,tick:tickCount,preaching:preachingCount,random:w.randomState,poseRandom:w.cosmeticRandom.randomState,status:w.status,tasks,preachers,raiders:w.units.filter(u=>members.has(u.id)&&u.kind!=='preacher').map(u=>unit(w,u,true)),changed,interesting,population:w.units.length,killCredits:w.killCredits}
  writeSync(fd,JSON.stringify(record)+'\n')
  states.set(w,{vitals,preachers:keyPreachers})
}
function tick(w,dt){if(!worlds.has(w))observe(w,'new-world');underlyingTick(w,dt);tickCount++;observe(w,'tick')}
function stepLivePreaching(w,u){underlyingPreaching(w,u);preachingCount++;observe(w,'supplied-preaching')}
function test(name,run){
 const startedAt=new Date().toISOString();
 try{run();writeFileSync(new URL('result.json',out),JSON.stringify({name,kind:'fixed-step maintained scenario',status:'passed',startedAt,finishedAt:new Date().toISOString(),tickCount,preachingCount,finalTurn:lastWorld?.turn},null,2)+'\n');console.log('PASSED',name,tickCount,preachingCount)}
 catch(error){const result={name,kind:'fixed-step maintained scenario',status:'failed',startedAt,finishedAt:new Date().toISOString(),tickCount,preachingCount,finalTurn:lastWorld?.turn,error:{name:error.name,message:error.message,actual:error.actual,expected:error.expected,stack:error.stack}};writeFileSync(new URL('result.json',out),JSON.stringify(result,null,2)+'\n');console.error(JSON.stringify(result));process.exitCode=1}
}

test('Mission 6 Chumara trains Preachers and launches its first mixed raid', () => {
  let world = createWorld(6)
  world.campaignAIs[3].variables[20] = 1 // Keep this established scenario focused on Chumara's raid.
  world.manaTribes[3].active = false
  for (
    let turn = 0;
    turn < 3000 &&
    !(
      world.campaignAIs[2].attributes[2] === 1 &&
      world.buildings.some(building => building.team === 'yellow' && buildingModel(building) === 5)
    );
    turn++
  )
    tick(world, 1 / 12)
  assert.equal(world.campaignAIs[2].attributes[2], 1)
  assert.equal(
    world.buildings.filter(building => building.team === 'yellow' && buildingModel(building) === 5)
      .length,
    1
  )

  world = migrateCheckpoint(structuredClone(world))
  for (
    let turn = 0;
    turn < 6000 &&
    !(
      world.buildings.some(
        building =>
          building.team === 'yellow' && buildingModel(building) === 5 && building.progress === 1
      ) && world.units.some(unit => unit.team === 'yellow' && unit.kind === 'preacher')
    );
    turn++
  )
    tick(world, 1 / 12)
  assert.equal(
    world.buildings.filter(
      building =>
        building.team === 'yellow' && buildingModel(building) === 5 && building.progress === 1
    ).length,
    1
  )
  assert.ok(world.units.some(unit => unit.team === 'yellow' && unit.kind === 'preacher'))

  const restored = migrateCheckpoint(structuredClone(world))
  assert.ok(
    restored.buildings.some(
      building =>
        building.team === 'yellow' && buildingModel(building) === 5 && building.progress === 1
    )
  )
  assert.ok(restored.units.some(unit => unit.team === 'yellow' && unit.kind === 'preacher'))

  for (
    let turn = 0;
    turn < 10000 && !restored.campaignAIs[2].tasks.some(task => task.flags & 1 && task.type === 20);
    turn++
  )
    tick(restored, 1 / 12)
  const attack = restored.campaignAIs[2].tasks.find(task => task.flags & 1 && task.type === 20)
  assert.deepEqual(
    restored.campaignAIs[2].attributes.slice(6, 17),
    [12, 20, 0, 3, 25, 0, 80, 30, 2, 2, 0]
  )
  assert.ok(withCampaignTribe(restored, 2, () => campaignInternal(restored, 1147)) > 4)
  assert.ok(withCampaignTribe(restored, 2, () => campaignInternal(restored, 1148)) > 2)
  assert.deepEqual(
    attack && {
      requested: attack.requested,
      damage: attack.extra,
      marker: attack.mode,
      quotas: attack.quotas,
      scheduled: (restored.turn - 1 + 2 + 179) & 511,
    },
    { requested: 4, damage: 20, marker: 0, quotas: [0, 80, 30, 0, 0, 0], scheduled: 0 }
  )
  assert.equal(restored.campaignAIs[2].variables[1], 1)

  const raiding = migrateCheckpoint(structuredClone(restored)),
    restoredAttack = raiding.campaignAIs[2].tasks.find(task => task.flags & 1 && task.type === 20)
  assert.ok(restoredAttack)
  assert.equal(
    raiding.campaignAIs[2].tasks.filter(task => task.flags & 1 && task.type === 20).length,
    1
  )
  for (let turn = 0; turn < 64 && restoredAttack.members.length < 4; turn++) tick(raiding, 1 / 12)
  assert.deepEqual(
    restoredAttack.members.map(id => raiding.units.find(unit => unit.id === id)?.kind).sort(),
    ['preacher', 'warrior', 'warrior', 'warrior']
  )
  for (let turn = 0; turn < 3000 && restoredAttack.phase !== 16; turn++) tick(raiding, 1 / 12)
  assert.equal(restoredAttack.phase, 16)
  const preacherId = restoredAttack.members.find(
      id => raiding.units.find(unit => unit.id === id)?.kind === 'preacher'
    ),
    preacher = raiding.units.find(unit => unit.id === preacherId),
    preacherPerson = preacher && (preacher.native ?? preacher.fight?.motion)
  assert.equal(
    preacherPerson && currentPersonOrder(raiding.buildingOrders, preacherPerson)?.model,
    17
  )
  assert.ok(
    restoredAttack.members.some(id => {
      const unit = raiding.units.find(unit => unit.id === id),
        person = unit && (unit.native ?? unit.fight?.motion),
        order = person && currentPersonOrder(raiding.buildingOrders, person)
      return order?.model === 19 && order.a === restoredAttack.target && order.b === 0x0808
    })
  )
  const converting = migrateCheckpoint(structuredClone(raiding)),
    convertingPreacher = converting.units.find(unit => unit.id === preacherId)
  converting.units = converting.units.filter(unit => unit.id === preacherId)
  syncLivePersonCells(converting)
  const knownIds = new Set(converting.units.map(unit => unit.id)),
    conversionPoint = browserPosition(
      convertingPreacher.native ?? convertingPreacher.fight?.motion
    ),
    victim = addUnit(converting, 'blue', 'brave', {
      x: conversionPoint.x + 1,
      z: conversionPoint.z,
    })
  for (let turn = 0; turn < 700 && converting.units.some(unit => unit.id === victim.id); turn++) {
    stepLivePreaching(converting, convertingPreacher)
    const liveVictim = converting.units.find(unit => unit.id === victim.id)
    if (liveVictim?.native?.state === 23) stepLiveConversionVictim(converting, liveVictim)
  }
  assert.ok(
    converting.units.some(
      unit =>
        !knownIds.has(unit.id) &&
        unit.team === 'yellow' &&
        unit.kind === 'brave' &&
        (unit.native?.flags4 ?? 0) & 0x40000
    )
  )
  const originalMembers = [...restoredAttack.members]
  let abortTurn = null,
    retired = false
  for (let turn = 0; turn < 513; turn++) {
    const phase = restoredAttack.phase,
      elapsed = restoredAttack.elapsed,
      fallback = restoredAttack.fallback,
      active = !!(restoredAttack.flags & 1),
      owners = phase === 6 ? originalMembers.map(id => {
        const unit = raiding.units.find(unit => unit.id === id),
          person = raiding.objectCells.objects.get(id),
          order = person && currentPersonOrder(raiding.buildingOrders, person)
        assert.ok(unit && person)
        assert.ok([unit.flight, unit.fight?.motion, unit.native, unit.entry?.person,
          unit.builder?.person].includes(person))
        return {
          id, person, state: person.state, speed: person.speed,
          fightOwned: unit.fight?.motion === person,
          immediate: person.immediateCommand, cursor: person.commandCursor,
          commands: [...person.commands],
          queuedModel: raiding.buildingOrders.records[person.commands[person.commandCursor]]?.model,
          order, payload: order && { ...order },
        }
      }) : []
    tick(raiding, 1 / 12)
    const activeRaids = raiding.campaignAIs[2].tasks.filter(task => task.flags & 1 && task.type === 20)
    assert.ok(activeRaids.length <= 1)
    if (activeRaids.length) assert.equal(activeRaids[0], restoredAttack)
    if (phase === 6 && restoredAttack.phase === 23) {
      // 004d14f0 aborts on an admitted combat member, even while others move.
      const combat = owners.find(owner => owner.id === preacherId && owner.fightOwned &&
        [25, 29].includes(owner.state))
      assert.ok(combat)
      assert.equal(combat.order?.model, 32)
      assert.ok(combat.immediate > 0)
      assert.equal(combat.queuedModel, 3)
      assert.ok(owners.some(owner => owner.state === 10 && owner.speed > 0 && owner.order?.model === 3))
      assert.equal(abortTurn, null)
      assert.ok(elapsed <= 1800)
      assert.equal(fallback, 23)
      assert.equal(restoredAttack.elapsed, 1801)
      assert.equal(restoredAttack.fallback, 23)
      assert.equal(restoredAttack.flags & 1, 1)
      assert.deepEqual(restoredAttack.members, originalMembers)
      for (const owner of owners) {
        assert.equal(raiding.objectCells.objects.get(owner.id), owner.person)
        assert.equal(owner.person.immediateCommand, owner.immediate)
        assert.equal(owner.person.commandCursor, owner.cursor)
        assert.deepEqual(owner.person.commands, owner.commands)
        assert.equal(currentPersonOrder(raiding.buildingOrders, owner.person), owner.order)
        assert.deepEqual(owner.order, owner.payload)
      }
      abortTurn = raiding.turn
    }
    if (active && !(restoredAttack.flags & 1)) {
      assert.equal(phase, 23)
      assert.ok(abortTurn !== null && raiding.turn > abortTurn)
      assert.equal(restoredAttack.phase, 23)
      assert.equal(restoredAttack.elapsed, 1801)
      assert.equal(restoredAttack.flags & 3, 0)
      assert.deepEqual(restoredAttack.members, [])
      retired = true
    }
    if (retired) {
      assert.equal(activeRaids.length, 0)
      assert.equal(restoredAttack.flags & 1, 0)
      assert.deepEqual(restoredAttack.members, [])
    }
  }
  assert.ok(abortTurn !== null)
  assert.ok(retired)
  assert.ok(originalMembers.every(id => raiding.units.some(unit => unit.id === id && unit.hp > 0)))
})

