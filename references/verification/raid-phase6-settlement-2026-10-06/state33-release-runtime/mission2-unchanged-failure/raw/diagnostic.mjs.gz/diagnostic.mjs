import './mission2.mjs'
import { run } from './observer.mjs'
await run()
