from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path.cwd();out=root/'work/orchestration/preacher-mission1-owner-replay-20261007';old=root.parent/'preacher-command32-expiry-20261006/work/orchestration/preacher-raid-regressions-20261006';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
game=(root/'tests/game.test.mjs').read_text();names=['mission-one Dakini launches its native attack route when Blue enters marker three','mission-one Dakini launches its later building attack when Blue overwhelms it']
def section(name):
 start=game.index("test('"+name+"'");end=game.find('\ntest(',start+1);return game[start:end]
scenarios=[section(name) for name in names]
prefix=game[:game.index("test('")].replace("import test from 'node:test';","import { test, observeTick } from './observer.mjs';").replace(' tick,',' tick as underlyingTick,').replace("'./level-start-fixture.mjs'","'../../../tests/level-start-fixture.mjs'").replace("'../app/","'../../../app/")
prefix+='\nfunction tick(w,dt){return observeTick(underlyingTick,w,dt)}\n'+next(line for line in game.splitlines() if line.startswith('function until('))+'\n'
prefix+=game[game.index('function registeredRaidPerson('):game.index("test('"+names[0]+"'")]
(out/'mission1.mjs').write_text(prefix+'\n'.join(s.replace("'../app/","'../../../app/") for s in scenarios))
for i,s in enumerate(scenarios):(out/f'case-{i+1}-source.txt').write_text(s)
(out/'cases.json').write_text(json.dumps({'names':names,'count':2,'sourceFiles':{'tests/game.test.mjs':hashlib.sha256(game.encode()).hexdigest()},'transform':'Exact two maintained tests including accepted actual-owner helper; only relative import relocation, node:test registration and read-only post-tick alias. All other inputs/assertions/budgets unchanged.','scenarioHashes':[hashlib.sha256(s.encode()).hexdigest() for s in scenarios]},indent=2)+'\n')
for name in ['observer.mjs','guardian.py','closure-host.mjs']:
 s=(old/name).read_text().replace('preacher-raid-regressions-20261006','preacher-mission1-owner-replay-20261007').replace('48a84610254d3ad5cddb600c266ed9a151233b79',head)
 (out/name).write_text(s)
(out/'diagnostic.mjs').write_text("import './mission1.mjs'\nimport { run } from './observer.mjs'\nawait run()\n")
shutil.copyfile('/tmp/prepare_pr247_mission1_owners.py',out/'prepare-source.py')
