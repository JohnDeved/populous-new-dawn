import { createStartedWorld, retainFixtureUnits } from '../../../tests/level-start-fixture.mjs';
import {createLivePerson,syncLivePersonCells} from '../../../app/live-people.ts';
import {currentPersonOrder} from '../../../app/person-orders.ts';
import {worshipPositions} from '../../../app/worship.ts';
import {nativePosition} from '../../../app/model.ts';
import assert from 'node:assert/strict';
import { test, observeTick } from './observer.mjs';
import {createHash} from 'node:crypto';
import nativeModels from '../../../app/original-models.json' with {type:'json'};
import level from '../../../app/level-one.ts';
import levelTwo from '../../../app/level-two.ts';
import scriptTwo from '../../../app/original-script-two.json' with {type:'json'};
import {reincarnationStoneRise,reincarnationTurns,stepReincarnation} from '../../../app/reincarnation.ts';
import {AUDIO_CUES} from '../../../app/audio.ts';
import {buildingGradeVertices,buildingPosition} from '../../../app/building-shapes.ts';
import {browserPosition} from '../../../app/model.ts';
import {messageText,messageViewPoint} from '../../../app/messages.ts';
import originalScript from '../../../app/original-script.json' with {type:'json'};
import {createTooltip,forcedTooltipObject,showObjectTooltip,stepTooltip} from '../../../app/tooltips.ts';
import {modelMatrix,modelPoint} from '../../../app/projection.ts';
import {runScript,scriptState} from '../../../app/popscript.ts';
import {campaignCommand,recordSpellCast,rotateBuildingPlan,addBuilding,buildingObject,buildingPose,buildingPlanPose,placementError} from '../../../app/model.ts';
import { createWorld, createGift, tick as underlyingTick, cast, command, select, placeBuilding, findPath, walkable, worldPoint, HOME, ENEMY, manaRate, housing, populationLimit, breedingWork, trainingCost, meleeDamage, addUnit, unitAnimation, unitAnimationSource, maxHp, entrance, nativeAngle, nativeStep, nativeStep3D, nativeTerrainCross, nativeTerrainHeight, terrainCross, makeTerrain, height, markerHeight, nativeCellPoint, removeHead, GRID, random, fightPosition, joinBattle } from '../../../app/model.ts';
const advance=(w,seconds)=>{for(let i=0;i<seconds*30;i++)tick(w,1/30);};

function tick(w,dt){return observeTick(underlyingTick,w,dt)}
function until(w,ready,seconds){for(let i=0;i<seconds*12&&!ready()&&w.status==='playing';i++)tick(w,1/12);assert.ok(ready(),'gameplay condition reached within its turn budget');}
function registeredRaidPerson(w,id){
 const unit=w.units.find(unit=>unit.id===id),person=w.objectCells.objects.get(id);
 assert.ok(unit&&unit.hp>0&&person&&person.id===unit.id,'raid order observation requires its living intended unit');
 assert.ok([unit.flight,unit.fight?.motion,unit.native,unit.entry?.person,unit.builder?.person].includes(person),'raid order observation requires its actual registered owner');
 return person;
}

test('mission-one Dakini launches its native attack route when Blue enters marker three',async()=>{
 const {joinBattle}=await import('../../../app/model.ts');
 const {currentPersonOrder}=await import('../../../app/person-orders.ts');
 const {requestAttack}=await import('../../../app/computer.ts');
 const w=createWorld();until(w,()=>!w.ai.tasks.some(t=>t.flags&1&&t.type===24),2);
 addUnit(w,'red','warrior',ENEMY);
 until(w,()=>!w.ai.tasks.some(t=>t.flags&1&&t.type===6),10);
 const marker=nativeCellPoint(level.markers[3]),staging=(level.markers[3]&0xff00)|((level.markers[3]+12)&255);
 addUnit(w,'blue','warrior',{x:marker.x,z:marker.z+12});
 const redStart=nativeCellPoint(staging);
 for(const unit of w.units.filter(u=>u.team==='red'&&u.kind!=='shaman'))Object.assign(unit,redStart);
 w.ai.defencePosition=staging;w.ai.variables[50]=1;w.ai.variables[2]=0;w.turn=201;tick(w,1/12);
 const task=w.ai.tasks.find(t=>t.flags&1&&t.type===20);
 assert.deepEqual(task&&{phase:task.phase,target:task.target,requested:task.requested,damage:task.extra,marker:task.mode,retreatPercent:task.retreatPercent,quotas:task.quotas},{phase:3,target:level.markers[3],requested:3,damage:999,marker:3,retreatPercent:50,quotas:[11,12,13,16,17,19].map(index=>w.ai.attributes[index])});
 assert.equal(w.ai.variables[8],1);assert.equal(w.ai.variables[2],1);
 until(w,()=>task.members.length===3,2);
 assert.deepEqual(task.members.map(id=>w.units.find(u=>u.id===id).kind),['brave','warrior','warrior']);
 const phases=[];let radiusDistance=0;until(w,()=>{if(phases.at(-1)!==task.phase)phases.push(task.phase);if(task.phase!==11)return false;radiusDistance=Math.min(...task.members.map(id=>{const u=w.units.find(unit=>unit.id===id);return Math.hypot(u.x-marker.x,u.z-marker.z);}));return true;},20);
 const attacker=w.units.find(u=>u.id===task.members[0]),owner=attacker.native,target=addUnit(w,'blue','warrior',attacker);target.hp=10;joinBattle(w,attacker,target);
 assert.equal(attacker.native,null);assert.equal(attacker.fight.motion,owner);
 until(w,()=>{if(attacker.fight){assert.equal(task.phase,11);assert.equal(attacker.fight.motion,owner);return false;}return target.hp===0;},20);
 assert.equal(attacker.native,owner,'combat restores the one retained person/order owner');
 until(w,()=>{if(phases.at(-1)!==task.phase)phases.push(task.phase);return task.phase===14;},20);
 assert.ok(radiusDistance>1.5,'native radius advances before exact marker arrival');assert.deepEqual(phases.slice(-5),[10,11,12,6,14]);
 assert.equal(w.ai.selectionOwner,10);assert.equal(w.ai.flags&2,0);
 const members=[...task.members],victim=addUnit(w,'blue','warrior',marker),hp=victim.hp;
 until(w,()=>members.every(id=>currentPersonOrder(w.buildingOrders,registeredRaidPerson(w,id))?.model===19),20);
 const attackIds=members.map(id=>registeredRaidPerson(w,id).commands.find(Boolean));
 assert.equal(new Set(attackIds).size,1,'the attack area order is shared by the whole group');
 assert.equal(w.buildingOrders.records[attackIds[0]].references,3);
 until(w,()=>victim.hp<hp,30);assert.equal(task.damage,0,'ordinary wounds do not credit the native task threshold');
 until(w,()=>victim.hp===0,30);assert.equal(task.damage,2,'a warrior death credits its native model score once');
 task.damage=task.extra;
 until(w,()=>!(task.flags&1),60);
 assert.ok(members.every(id=>currentPersonOrder(w.buildingOrders,registeredRaidPerson(w,id))?.model!==19));
 requestAttack(w.ai,task.origin,3,1,999,w.ai.attributes.slice(11,17),0,true,1);
 assert.equal(task.flags&1,1,'phase 23 releases the same queue slot for the next wave');
});

test('mission-one Dakini launches its later building attack when Blue overwhelms it',async()=>{
 const {currentPersonOrder}=await import('../../../app/person-orders.ts');
 const {requestAttack}=await import('../../../app/computer.ts');
 const script={fields:[[2,1],[2,1223],[0,999],[2,1224],[0,0],[0,-1]]},args=[1118,0,1071,1,2,3,3,3,1078,4,5,5,4];
 const packed=p=>((p.x>>>8)&254)|(p.y&0xfe00);
 const direct=createWorld(),blueBuildings=direct.buildings.filter(b=>b.team==='blue');direct.randomState=2;
 campaignCommand(direct,1059,args,script);
 let task=direct.ai.tasks.find(t=>t.flags&1&&t.type===20);
 assert.equal(task.target,packed(buildingPosition(buildingPose(blueBuildings[1]))));assert.equal(task.entity,blueBuildings[1].id);
 assert.equal(direct.randomState,1896349699,'building selection consumes one native draw');
 const fallback=createWorld();fallback.buildings=[];fallback.units=fallback.units.filter(u=>u.kind!=='shaman');fallback.randomState=2;
 const bluePeople=fallback.units.filter(u=>u.team==='blue'&&u.hp>0),person=bluePeople[1896349699%bluePeople.length];
 campaignCommand(fallback,1059,args,script);task=fallback.ai.tasks.find(t=>t.flags&1&&t.type===20);
 assert.equal(task.target,packed(nativePosition(fallback,person)),'an empty building list falls back to allocation-ordered people');assert.equal(task.entity,person.id);
 assert.equal(fallback.randomState,1896349699,'person-only fallback consumes one native draw');

 const w=createWorld();until(w,()=>!w.ai.tasks.some(t=>t.flags&1&&t.type===24),2);w.units=[];
 const target=w.buildings.filter(b=>b.team==='blue')[1],near={x:target.x+4,z:target.z};
 addUnit(w,'red','shaman',near);for(let i=0;i<3;i++)addUnit(w,'red','brave',near);
 addUnit(w,'blue','shaman',ENEMY);for(let i=0;i<8;i++)addUnit(w,'blue','brave',ENEMY);
 w.randomState=2;w.ai.variables[50]=1;w.turn=81;tick(w,1/12);
 task=w.ai.tasks.find(t=>t.flags&1&&t.type===20);
 assert.deepEqual([11,12,13,16,17,19].map(i=>w.ai.attributes[i]),[100,100,0,0,0,1]);
 assert.deepEqual(task&&{phase:task.phase,target:task.target,entity:task.entity,requested:task.requested,marker:task.mode,retreatPercent:task.retreatPercent,quotas:task.quotas},{phase:3,target:packed(buildingPosition(buildingPose(target))),entity:target.id,requested:4,marker:0,retreatPercent:50,quotas:[11,12,13,16,17,19].map(i=>w.ai.attributes[i])});
 assert.equal(w.ai.variables[3],1,'the original one-shot attack latch closes');
 until(w,()=>task.members.length===3,2);
 until(w,()=>!!(task.flags&1)&&task.members.length>=3&&task.members.every(id=>currentPersonOrder(w.buildingOrders,registeredRaidPerson(w,id))?.model===19),30);
 task.flags=0;task.members=[];w.turn=337;tick(w,1/12);
 assert.ok(!w.ai.tasks.some(t=>t.flags&1&&t.type===20),'the latched script does not launch another attack');

 const moving=createWorld();until(moving,()=>!moving.ai.tasks.some(t=>t.flags&1&&t.type===24),2);
 const blue=moving.units.find(u=>u.team==='blue'&&u.kind==='brave'),members=moving.units.filter(u=>u.team==='red'&&u.kind!=='shaman').slice(0,3);
 requestAttack(moving.ai,packed(nativePosition(moving,blue)),0,3,999,[100,0,0,0,0,0],0,true,1,blue.id);
 const pursuit=moving.ai.tasks.find(t=>t.flags&1&&t.type===20);pursuit.phase=15;pursuit.members=members.map(u=>u.id);moving.ai.cursor=moving.ai.tasks.indexOf(pursuit);
 until(moving,()=>pursuit.phase===16,10);
 blue.x+=24;const destination=packed(nativePosition(moving,blue));
 until(moving,()=>pursuit.target===destination&&pursuit.members.every(id=>{const unit=moving.units.find(u=>u.id===id),order=unit&&currentPersonOrder(moving.buildingOrders,unit.native);return order?.model===19&&order.a===destination;}),20);
});
