import './mission1.mjs'
import { run } from './observer.mjs'
await run()
