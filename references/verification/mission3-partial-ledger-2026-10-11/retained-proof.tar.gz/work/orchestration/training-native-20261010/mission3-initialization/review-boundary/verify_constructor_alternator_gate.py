"""Final static/synthetic alternator gate; never dispatches original instructions."""
from pathlib import Path
import ast,hashlib,json,sys,subprocess
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';sys.path.insert(0,str(H))
import constructor_ledger_alternator_candidate as q
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head='df1840cad597e9b134443c5c364d775440cbebbe';driver='ce1d4a3632a1502751d3bc1d066b40472da16eeb8c2cd631e283a3a9ee143fb5'
assert sha(H/'constructor_ledger_alternator_candidate.py')==driver
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=q.b.ROOT,text=True).strip()==head
assert not subprocess.check_output(['git','status','--short'],cwd=q.b.ROOT,text=True).strip()
receipt=H/'constructor-ledger-alternator-verification-receipt01.json';assert sha(receipt)=='355f6cbb0bdef951cee506539726b8bb11eab7055e89bf3e7ca0248b7b88e0aa'
for f in json.loads(receipt.read_text())['files']:
 p=q.b.ROOT/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
def funcs(p):
 out={}
 for node in ast.parse(p.read_text()).body:
  if isinstance(node,ast.FunctionDef):out[node.name]=ast.dump(node)
  elif isinstance(node,ast.ClassDef):
   for f in node.body:
    if isinstance(f,ast.FunctionDef):out[node.name+'.'+f.name]=ast.dump(f)
 return out
old=funcs(H/'constructor_ledger_operand_candidate.py');new=funcs(H/'constructor_ledger_alternator_candidate.py')
changed=sorted(k for k in old.keys()|new.keys() if old.get(k)!=new.get(k))
assert changed==sorted(['alternator_assertions','Ledger._write','prepare','Ledger.__init__','Ledger.checkpoint_seeds','entry_conditions','ledger_assertions','Ledger.commit','apply_entry','execute'])
assert sum(k in old and old[k]==v for k,v in new.items())==35
pf=H/'ledger-alternator-preflight01/constructor-ledger-preflight.json';m=json.loads(pf.read_text());prior=json.loads((H/'ledger-operand-preflight01/constructor-ledger-preflight.json').read_text())
assert pf.read_bytes()==(R/'constructor-alternator-preflight-final/constructor-ledger-preflight.json').read_bytes()
extra=[c for c in m['conditions'] if c not in prior['conditions']];assert len(extra)==1 and '0096ead5' in extra[0]
norm=json.loads(json.dumps(m));norm['source']=prior['source'];norm['driver']=prior['driver'];norm['conditions'].remove(extra[0]);norm.pop('sceneryPoolAlternatorContract');assert norm==prior
base='adae85b9df3085f2f63b4661195dd80fd633a2b3';paths=subprocess.check_output(['git','diff','--name-only',base,head],cwd=q.b.ROOT,text=True).splitlines();assert all(p=='decomp/research/training-entry-composition.md' or p.startswith('references/verification/mission3-first-record-2026-10-11/') for p in paths)
# Pure validation only. A true released field is used to test binding, never to run anything.
valid=q.approval_bindings(m);q.validate_approval(valid,m)
for key in ['conditions','sceneryPoolAlternatorContract']:
 changed_manifest=json.loads(json.dumps(m))
 if key=='conditions':changed_manifest[key].pop()
 else:changed_manifest[key]['initialValue']=1
 try:q.validate_approval(valid,changed_manifest)
 except q.b.Blocked:pass
 else:raise AssertionError('new contract field escaped approval binding')
hold=dict(valid);hold['parentReleasedRunLane']=False
try:q.validate_approval(hold,m)
except q.b.Blocked:pass
else:raise AssertionError('held review authorized execution')
(R/'constructor-ledger-alternator-held-approval.json').write_text(json.dumps(hold,indent=2)+'\n')
artifacts=[R/'constructor-dispatch-inputs-source-review.json',R/'verify_constructor_dispatch_inputs.py',R/'test_alternator_independent.py',R/'alternator-independent-final.log',R/'alternator-all-tests-final.log',R/'alternator-animation-dispatch-final.log',R/'alternator-forms-final.log',R/'alternator-contexts-final.log',R/'alternator-static-final.log',R/'constructor-ledger-alternator-held-approval.json',Path(__file__)]
r={'verdict':'ACCEPT_CONDITIONAL_ALTERNATOR_SEAM_AND_COMMITTED_LEDGER_PENDING_PARENT_RELEASE','driverSha256':driver,'sourceHead':head,'verificationReceiptSha256':sha(receipt),'preflightSha256':sha(pf),'originalInstructionsExecutedByReviewer':0,'sourceReviewSha256':sha(R/'constructor-dispatch-inputs-source-review.json'),'deltaReview':{'changedFunctions':changed,'unchangedFunctionBodies':35,'newSupply':'Only BYTE0096ead5=0/full-mask at first selected kernel; original reset source plus explicit omitted-history lifetime. Every selected setup kernel checks preservation; no later reseed.','manifest':'Only new sceneryPoolAlternatorContract, one explicit condition, current driver/source identities. All91 windows, prior inputs/conditions/projections, opcode semantics, numeric budgets and completion assertions unchanged.','sourceHeadChange':'Docs/evidence-only first-record publication verified.'},'runtimeWriteAndLawReview':['The actual write hook journals before checking every interval overlap; exact unprefixed INC004ed8ed is admitted only under active primary-allocator frame in authored-record phase. Other direct/indirect/partial/wide writers fail with rollback and no committed write ordinal.','Unknown counter bits still reject before INC. Protected-memory or other failed transactions do not acquire committed rows. Prior committed increments survive later faults.','Commit rows bind actual allocator frame, record, previous byte, full-known next byte, parity, committed instruction and original write ordinal. Derived metadata does not allocate another observer ordinal.','Final reconciliation checks all overlapping committed write events, count/order/reference, byte mask, old/new modulo256 sequence and full-known final byte. This counts committed INCs including nested/open/failed allocations, never returned allocation count.','Odd parity forces low-ID selection; even parity may preserve a prior descriptor selection. All actual descriptor/capacity/list decisions continue. No counter-based pool replacement or descriptor approximation.','Class counters/occupancies/related-record reserves remain separately tracked; no destructor neutrality or universal alias absence inferred. Unadmitted calls and decisive unknowns still stop.'],'verification':{'authorSyntheticTestsIndependentlyRerun':301,'independentAlternatorTests':8,'independentActualSetupDispatcherTests':1,'independentDivisionSetleTests':9,'independentLiteralTextureContextTests':8,'staticPreflight':'byte-identical to frozen author preflight','approvalTamperChecks':'Both new condition and alternator contract hash-bound; held parent release rejects.','independentCases':['257 sequential commits including255→0, nested open-frame association, original write references','CF value/mask preservation across byte arithmetic boundaries','literal byte, word and DWORD indirect overlap rollback; all bytes and register/mask state checked','missing/wrong frame and wrong phase reject; partial/unknown mask rejects','protected allowed INC rollback with no derived commit','tampered row/value/parity/reference and unregistered overlapping write rejected','actual setup dispatcher still gets300s, original historical context regressions and integer operand cases still pass']},'wrapper':{'sha256':sha(H/'run_constructor_ledger_alternator_once.py'),'scope':'One fresh run08 output only after exact approval and storage admission;1200s outer limit; twelve driver hashes retained before/after; no automatic retry.'},'limits':['Parent lane release required separately; reviewer did not execute original instructions.','Only the single declared land-clear/class-seed0 conditional diagnostic is admitted. A conservative partial stop is valid evidence, not full constructor completion.','Actual startup lifetime, all omitted selected-state/RNG/transport conditions, model-derived terrain and resource projection normal-completion/disjointness remain explicit.','No final class1 expectation, seed recovery, population completion, parity credit or product/main/deployment repair is established.','Existing181 unadmitted direct edges, nested effects and unsupported/input/fault/resource boundaries can still stop the run.','No product check/build needed for ignored isolated research Python; all authored synthetic/static regressions above are retained.'],'reviewArtifacts':[{'path':str(p.relative_to(q.b.ROOT)),'sha256':sha(p)} for p in artifacts]}
(R/'constructor-ledger-alternator-final-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'verdict':r['verdict'],'reviewSha256':sha(R/'constructor-ledger-alternator-final-review.json'),'heldApprovalSha256':sha(R/'constructor-ledger-alternator-held-approval.json')}))
