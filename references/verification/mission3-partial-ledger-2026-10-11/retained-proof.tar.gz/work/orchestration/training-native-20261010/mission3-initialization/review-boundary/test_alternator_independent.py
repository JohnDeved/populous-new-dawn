"""Literal independent oracles; authored synthetic x86 only, no original file dispatch."""
from pathlib import Path
import sys,unittest
from unittest.mock import patch
import unicorn
H=Path(__file__).resolve().parent.parent/'harness-repair';sys.path.insert(0,str(H))
import constructor_ledger_alternator_candidate as q
b=q.b
CODE,DATA,ADDR,STACK=0x100000,0x96e000,0x96ead5,0x300800
class AlternatorIndependent(unittest.TestCase):
 def make(self,raw='fe05d5ea9600',value=0,mask=255,flags=2,flagmask=b.MASK32):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:c.mem_map(a,4096)
  code=bytes.fromhex(raw);c.mem_write(CODE,code)
  e=q.Ledger(c,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(code))],protected_inputs=[])
  for reg,v in [('esp',STACK),('eax',0xaabbccdd),('edi',ADDR),('ebx',0),('ecx',0),('edx',0),('esi',0),('ebp',0)]:e.reg_supply(reg,v,b.MASK32,'synthetic known register')
  e.reg_supply('eflags',flags,flagmask,'synthetic flag input');e.supply(ADDR-4,b'ABCD'+bytes([value])+b'EFGH','synthetic isolated data');e.shadow.put(ADDR,1,mask)
  e.phase='authored-record-loop';e.record=17;e.frames=[{'sequence':4,'target':'0x4ed8a0','returned':False}]
  return e,len(code)
 def drive(self,e,n):
  # Relocate only the guard PC to our authored program, preserving literal byte/form/address checks.
  with patch.object(q,'ALTERNATOR_INC',CODE):
   try:e.cpu.emu_start(CODE,CODE+n,count=100);e.commit()
   except BaseException:e.rollback();raise
 def test_source_contract_addresses_are_literal(self):
  self.assertEqual(q.ALTERNATOR,0x96ead5);self.assertEqual(q.ALTERNATOR_INC,0x4ed8ed)
 def test_257_commits_wrap_and_associate_open_nested_frames(self):
  e,n=self.make()
  for k in range(257):
   e.frames=[{'target':'0x4ed8a0','sequence':2,'returned':False},{'target':'0x4ed8a0','sequence':100+k,'returned':False}]
   self.drive(e,n);r=e.scenery_pool_increments[-1]
   self.assertEqual((r['valueBefore'],r['valueAfter']['value'],r['parityAfter']),(k%256,(k+1)%256,(k+1)%2));self.assertEqual(r['allocatorSequence'],100+k);self.assertEqual(r['record'],17);self.assertEqual(r['writeEventOrdinal'],e.write_events[-1]['eventOrdinal'])
  self.assertFalse(e.allocations);self.assertEqual(e.observed(ADDR,1)['value'],1)
  with patch.object(q,'ALTERNATOR_INC',CODE):self.assertEqual(q.alternator_assertions(e)['committedIncrements'],257)
 def test_cf_preserved_with_known_or_unknown_provenance(self):
  for value in [0,127,255]:
   for cf in [0,1]:
    for known in [True,False]:
     e,n=self.make(value=value,flags=2|cf,flagmask=b.MASK32 if known else b.MASK32^b.CF);self.drive(e,n)
     self.assertEqual(e.reg_value('eflags')&b.CF,cf);self.assertEqual(e.shadow.reg['eflags']&b.CF,b.CF if known else 0);self.assertEqual(e.observed(ADDR,1)['value'],(value+1)%256)
 def test_byte_word_and_dword_aliases_rollback_all_bytes(self):
  # Immediate byte store and register-sized indirect stores, including crossing the byte.
  for raw,offset in [('c605d5ea960000',0),('8907',-3),('8907',-1),('668907',-1),('8807',0)]:
   e,n=self.make(raw);e.reg_supply('edi',ADDR+offset,b.MASK32,'synthetic alias');before=bytes(e.cpu.mem_read(ADDR-4,9));regs=e.register_snapshot()
   with self.assertRaisesRegex(b.Blocked,'unclassified write'):self.drive(e,n)
   self.assertEqual(bytes(e.cpu.mem_read(ADDR-4,9)),before);self.assertEqual(e.shadow.get(ADDR-4,9),(1<<72)-1);self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertEqual(e.committed,0);self.assertEqual(e.event_ordinal,len(e.read_events));self.assertTrue(e.aborted[0]['attemptedWrites'])
   for r in ['eax','edi','esp','eflags']:self.assertEqual(e.register_snapshot()[r],regs[r])
 def test_inc_rejects_missing_wrong_frame_and_wrong_phase(self):
  for frames,phase in [([], 'authored-record-loop'),([{'target':'0x4ed580','sequence':3}], 'authored-record-loop'),([{'target':'0x4ed8a0','sequence':3}], 'selected-kernel')]:
   e,n=self.make();e.frames=frames;e.phase=phase
   with self.assertRaisesRegex(b.Blocked,'unclassified write'):self.drive(e,n)
   self.assertEqual(e.observed(ADDR,1)['value'],0);self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertEqual(e.event_ordinal,len(e.read_events));self.assertEqual(e.committed,0)
 def test_unknown_or_partial_byte_cannot_be_incremented(self):
  for mask in [0,1,0xfe,0x7f]:
   e,n=self.make(mask=mask)
   with self.assertRaises(b.Blocked):self.drive(e,n)
   self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertEqual(e.committed,0);self.assertEqual(e.shadow.get(ADDR,1),mask)
 def test_protected_allowed_inc_rolls_back_without_derived_commit(self):
  e,n=self.make();e.cpu.mem_protect(DATA,4096,unicorn.UC_PROT_READ);before=e.register_snapshot()
  with self.assertRaises((b.Blocked,unicorn.UcError)):self.drive(e,n)
  self.assertEqual(e.observed(ADDR,1)['value'],0);self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertEqual(e.committed,0)
  for r in ['eax','esp','eflags']:self.assertEqual(e.register_snapshot()[r],before[r])
 def test_rows_and_alias_write_chronology_are_checked(self):
  for field,bad in [('valueBefore',3),('parityAfter',0),('writeEventOrdinal',123)]:
   e,n=self.make();self.drive(e,n);e.scenery_pool_increments[0][field]=bad
   with patch.object(q,'ALTERNATOR_INC',CODE):
    with self.assertRaises(b.Blocked):q.alternator_assertions(e)
  e,n=self.make();self.drive(e,n);e.write_events.append({'address':hex(ADDR-1),'size':4})
  with patch.object(q,'ALTERNATOR_INC',CODE):
   with self.assertRaisesRegex(b.Blocked,'count mismatch'):q.alternator_assertions(e)
if __name__=='__main__':unittest.main()
