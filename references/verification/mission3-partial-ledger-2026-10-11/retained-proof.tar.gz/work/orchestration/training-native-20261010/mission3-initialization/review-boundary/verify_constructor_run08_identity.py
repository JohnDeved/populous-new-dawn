"""Independent retained-file/DAT identity correlation; no browser or original execution."""
from pathlib import Path
from collections import Counter
import json,hashlib,struct
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';R=B/'review-boundary'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=H/'constructor-run08-identity-map.json';assert sha(p)=='e08cf8223c8c01421a293dbe36c4f136dedef7eecbbb496a5608e65526e2235a';j=json.loads(p.read_text());assert len(j['assertions'])==117 and all(v['passed'] for v in j['assertions'])
for f in [j['script']]+j['inputs']:assert Path(f['path']).stat().st_size==f['bytes'] and sha(f['path'])==f['sha256']
prior=R/'constructor-ledger-run08-post-review.json';assert sha(prior)=='18f576213d77783e650a7f30e83a7d20e1a57196a0919a7b58753a34b6acbd00';review=json.loads(prior.read_text());native=[x for x in review['allocationOrderAndCopiedCounters'] if x['class']==1];assert len(native)==40
level=Path(j['inputs'][-1]['path']).read_bytes();src=(ROOT/'app/level-three.ts').read_text();imp=json.loads(src.split('export default ',1)[1].strip().removesuffix(';'));objects={o['index']+1:o for o in imp['objects']};assert hashlib.sha256(level).hexdigest()==imp['sourceSha256']
# Independently decode all52 people coordinates, not just the candidate subset.
for n,o in objects.items():
 raw=level[0x14043+(n-1)*55:0x14043+n*55];x,z=struct.unpack_from('<hh',raw,3)
 assert (o['type'],o['model'],o['owner'],o['x'],o['z'])==(raw[1],raw[0],raw[2],x/256-8,-z/256-8)
for got,want in zip(j['completedClass1AuthoredMapping'],native):
 assert (got['sequence'],got['originRecord'],got['pointer'],got['id'],got['class'],got['model'],got['counter'])==(want['callSequence'],want['record'],want['pointer'],want['poolSlotId'],want['class'],want['model'],want['copiedCounter'])
 n=got['authoredRecord'];assert n==want['record'] and got['importedZeroBasedIndex']==n-1;o=objects[n];assert got['browserAuthoredPosition']=={'x':o['x'],'z':o['z']} and got['ownerRaw']==o['owner'];raw=level[0x14043+(n-1)*55:0x14043+n*55];assert got['rawRecordSha256']==hashlib.sha256(raw).hexdigest()
assert [x['record'] for x in native]==list(range(10,27))+list(range(30,45))+list(range(46,54));assert [x['copiedCounter'] for x in native]==list(range(40))
pending=[n for n,o in objects.items() if o['type']==1 and n>93];assert pending==list(range(94,102))+list(range(106,110))
for row,n in zip(j['unexecutedLaterWildmen'],pending):assert row=={'record':n,'class':1,'model':1,'owner':255,'position':{'x':objects[n]['x'],'z':objects[n]['z']}}
manifest=json.loads(Path(j['inputs'][1]['path']).read_text());events_path=Path(j['inputs'][2]['path']);people_path=Path(j['inputs'][3]['path']);assert sha(events_path)==manifest['members']['ordinary1/owner-source-events.json'];assert sha(people_path)==manifest['members']['ordinary1/owner-summary.json']
events=json.loads(events_path.read_text())['events'];people=json.loads(people_path.read_text())['people'];assert len(people)==len(j['ordinarySelectedCohort'])==10
for row,person in zip(j['ordinarySelectedCohort'],people):
 assert (row['browserReplacementId'],row['retainedOwnerId'])==(person['id'],person['chosenOwnerId'])
 birth=[e for e in events if e['worldId']==2 and e['site']=='createLivePerson.return' and e['unit']['id']==person['id'] and e['unit']['aliases']['observed']==person['chosenOwnerId']];assert len(birth)==1;e=birth[0];u=e['unit'];owners=[o for o in u['owners'] if o['ownerId']==person['chosenOwnerId']];assert len(owners)==1
 assert 'convertStartingWildman' in e['extra']['stack'];assert (row['sourceEventSequence'],row['birthTurn'],row['browserBirthCounter'],row['birthPosition'])==(e['sequence'],e['turn'],owners[0]['person']['counter'],{'x':u['x'],'z':u['z']})
 all_candidates=[n for n,o in objects.items() if o['type']==1 and (o['x'],o['z'])==(u['x'],u['z'])]
 assert all_candidates==row['coordinateCandidateAuthoredRecords'] and set(all_candidates)<=set(pending);assert row['provenOriginalAllocationId'] is None
assert set(x['birthTurn'] for x in j['ordinarySelectedCohort'])=={17,20,21}
r={'verdict':'ACCEPT_AUTHORED_IDENTITY_AND_LIMITED_BROWSER_BIRTH_COORDINATE_CORRELATION','originalInstructionsExecuted':0,'browserExecuted':False,'packetSha256':sha(p),'acceptedRun08ReviewSha256':sha(prior),'checks':{'nativeClass1Rows':40,'allCanonicalImportedObjectsAndCoordinateTransforms':len(objects),'sourceAssertions':117,'retainedOwnerBirths':10,'laterUnexecutedWildmen':12,'candidateSearch':'Across every authored person, not only later records; no earlier completed person shares a selected birth coordinate.'},'class1Groups':[{'records':'10–26 and30–44','count':32,'class':1,'model':1,'ownerRaw':255},{'records':'46','count':1,'class':1,'model':7,'ownerRaw':0},{'records':'47','count':1,'class':1,'model':7,'ownerRaw':2},{'records':'48–53','count':6,'class':1,'model':2,'ownerRaw':2}],'ordinaryBirthRows':j['ordinarySelectedCohort'],'limits':['DAT ordinal/imported index and conditional native allocation/counter association are exact for40 completed people. Pool ID, authored ID and browser replacement ID remain separate.','Ten retained browser owners were created by startup conversion at turns17/20/21. Their birth positions correspond only to unexecuted later authored groups94–101/106–109 in this level.','Duplicate authored coordinates give candidate groups, not a uniquely identified destroyed source Wildman. Even unique coordinates do not establish cross-engine original replacement pool IDs or counters.','Browser birth counters16/19/20 are retained-browser facts only; original conversion waves and later scheduler phase remain unexecuted.','No exact final startup seed, replacement-counter offset, product fix or actual startup-history recovery inferred.'],'verifierSha256':sha(Path(__file__))}
(R/'constructor-run08-identity-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'verdict':r['verdict'],'reviewSha256':sha(R/'constructor-run08-identity-review.json')}))
