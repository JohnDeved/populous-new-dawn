"""Authored synthetic allocator-shaped programs and host input contracts only."""
import hashlib,json,unittest
from types import SimpleNamespace
from unittest.mock import patch
import unicorn
import constructor_ledger_alternator_candidate as l
import constructor_ledger_operand_candidate as old
b=l.b;CODE=0x100000;PC=l.ALTERNATOR_INC;A=l.ALTERNATOR;STACK=l.FRAME;ROOT=0x4ed8a0;UNKNOWN=0x2000100

def rel(op,pc,target):return bytes([op])+((target-pc-5)&b.MASK32).to_bytes(4,'little')
class AlternatorTests(unittest.TestCase):
 def make(self,post=b'\xc3',nested=False,flags=2,flagmask=b.MASK32):
  cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  cpu.mem_map(CODE,4096);cpu.mem_map(b.BASE,b.END-b.BASE);cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  cpu.mem_write(CODE,rel(0xe8,CODE,ROOT)+b'\xc3')
  entry=(b'\x49'+rel(0xe9,ROOT+1,PC)) if nested else rel(0xe9,ROOT,PC)
  cpu.mem_write(ROOT,entry)
  if nested:post=b'\x85\xc9\x74\x05'+rel(0xe8,PC+10,ROOT)+b'\xc3'
  cpu.mem_write(PC,b'\xfe\x05'+l.pack(A)+post)
  e=l.Ledger(cpu,[(CODE,4096),(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(CODE,CODE+6),(ROOT,PC+6+len(post))],protected_inputs=[])
  e.phase='authored-record-loop';e.record=2
  for r,v in [('eax',0),('edx',0),('ecx',2 if nested else 0),('esp',STACK)]:e.reg_supply(r,v,b.MASK32,'authored synthetic registers')
  e.reg_supply('eflags',flags,flagmask,'authored synthetic flags');e.supply(STACK,l.pack(b.STOP),'synthetic root return');e.supply(A,b'\0','synthetic source-conditioned alternator');e.supply(b.SEED,b'\0','synthetic class1 seed');return e
 def test_one_commit_has_actual_call_and_write_reference(self):
  e=self.make();e.run(CODE,b.STOP);a=l.alternator_assertions(e);self.assertEqual(a['committedIncrements'],1);self.assertEqual(a['finalKnownByte']['value'],1);row=e.scenery_pool_increments[0];self.assertEqual((row['record'],row['allocatorSequence'],row['valueBefore'],row['parityAfter']),(2,0,0,1));w=next(w for w in e.write_events if w['eventOrdinal']==row['writeEventOrdinal']);self.assertEqual(w['address'],hex(A));self.assertTrue(w['committed']);self.assertEqual(e.allocations[0]['allocation']['pointer'],'0x0')
 def test_256_commits_wrap255_to0_without_reseed(self):
  e=self.make()
  for k in range(256):
   e.reg_supply('esp',STACK,b.MASK32,'synthetic repeated root frame, no alternator reseed');e.run(CODE,b.STOP)
  a=l.alternator_assertions(e);self.assertEqual(a['committedIncrements'],256);self.assertEqual(a['finalKnownByte']['value'],0);self.assertEqual((e.scenery_pool_increments[-1]['valueBefore'],e.scenery_pool_increments[-1]['valueAfter']['value']),(255,0));self.assertEqual(len([s for s in e.supplies if s.get('address')==hex(A)]),1)
 def test_open_allocation_after_later_unknown_still_counts_commit(self):
  e=self.make(post=b'\x80\x3d'+l.pack(UNKNOWN)+b'\0\xc3')
  with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'):e.run(CODE,b.STOP)
  self.assertEqual(len(e.frames),1);self.assertFalse(e.allocations);self.assertEqual(l.alternator_assertions(e)['committedIncrements'],1);self.assertEqual(l.ledger_assertions(e,False)['fullyReturnedSuccessfulAllocations'],[])
 def test_nested_and_failed_returns_count_in_entry_order(self):
  e=self.make(nested=True);e.run(CODE,b.STOP);self.assertEqual([r['allocatorSequence'] for r in e.scenery_pool_increments],[0,1]);self.assertEqual(e.events[1]['parent'],0);self.assertEqual([r['valueAfter']['value'] for r in e.scenery_pool_increments],[1,2]);self.assertEqual(len(e.allocations),2);self.assertEqual(l.ledger_assertions(e,False)['fullyReturnedSuccessfulAllocations'],[]);self.assertEqual(l.alternator_assertions(e)['committedIncrements'],2)
 def test_original_inc_preserves_known_and_unknown_carry(self):
  for cf,known in [(0,True),(1,True),(0,False),(1,False)]:
   flags=2|(b.CF if cf else 0);e=self.make(flags=flags,flagmask=b.MASK32 if known else b.MASK32^b.CF);e.run(CODE,b.STOP);self.assertEqual(bool(e.reg_value('eflags')&b.CF),bool(cf));self.assertEqual(bool(e.shadow.reg['eflags']&b.CF),known)
 def test_even_parity_can_keep_prior_low_pool_selection(self):
  # Authored equivalent of AL prior selection + real parity TEST/JE/MOV.
  post=b'\xf6\x05'+l.pack(A)+b'\x01\x74\x02\xb0\x01\xc3'
  e=self.make(post=post);e.run(CODE,b.STOP) # odd sets AL1
  e.reg_supply('esp',STACK,b.MASK32,'synthetic repeated root frame');e.run(CODE,b.STOP) # even keeps previously selected AL1
  self.assertEqual(e.reg_value('al'),1);self.assertEqual(e.scenery_pool_increments[-1]['parityAfter'],0);self.assertTrue(l.alternator_assertions(e)['evenParityDoesNotIdentifySelectedPool'])
 def alias(self,raw,address,value=None):
  e=self.make();e.frames=[];e.cpu.mem_write(CODE,raw+b'\xc3');e.windows[0]=(CODE,CODE+len(raw)+1);e.reg_supply('edi',address,b.MASK32,'synthetic alias address');e.reg_supply('eax',value if value is not None else 0xaabbccdd,b.MASK32,'synthetic alias source');e.supply(A-4,bytes.fromhex('112233440055667788'),'synthetic surrounding bytes');return e
 def test_byte_word_dword_and_partial_alias_writes_rollback(self):
  for raw,addr in [(b'\x88\x07',A),(b'\x66\x89\x07',A-1),(b'\x89\x07',A-2),(b'\xc6\x05'+l.pack(A)+b'\xff',A)]:
   e=self.alias(raw,addr);before=bytes(e.cpu.mem_read(A-4,9));mask=e.shadow.get(A-4,9)
   with self.assertRaisesRegex(b.Blocked,'unclassified write overlapping'):e.run(CODE,b.STOP)
   self.assertEqual(bytes(e.cpu.mem_read(A-4,9)),before);self.assertEqual(e.shadow.get(A-4,9),mask);self.assertEqual(e.committed,0);self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertTrue(e.aborted[0]['attemptedWrites']);self.assertEqual(e.event_ordinal,0)
 def test_protected_wide_alias_restores_all_bytes_registers_and_masks(self):
  e=self.alias(b'\x89\x07',A-2);e.cpu.mem_protect(A&~4095,4096,unicorn.UC_PROT_READ);before=bytes(e.cpu.mem_read(A-4,9));regs=e.register_snapshot();mask=e.shadow.get(A-4,9)
  with self.assertRaises(b.Blocked):e.run(CODE,b.STOP)
  self.assertEqual(bytes(e.cpu.mem_read(A-4,9)),before);self.assertEqual(e.shadow.get(A-4,9),mask);self.assertFalse(e.write_events);self.assertFalse(e.scenery_pool_increments);self.assertEqual(e.event_ordinal,0)
  for reg in ['eax','ebx','ecx','edx','esi','edi','ebp','esp','eflags']:self.assertEqual(e.register_snapshot()[reg],regs[reg])
 def test_fault_after_prior_commit_preserves_only_prior_alternator_row(self):
  e=self.make();e.run(CODE,b.STOP);first=dict(e.scenery_pool_increments[0]);e.reg_supply('esp',STACK,b.MASK32,'synthetic second frame');e.cpu.mem_protect(A&~4095,4096,unicorn.UC_PROT_READ)
  with self.assertRaises(b.Blocked):e.run(CODE,b.STOP)
  self.assertEqual(e.scenery_pool_increments,[first]);self.assertEqual(l.alternator_assertions(e)['committedIncrements'],1);self.assertEqual(e.observed(A,1)['value'],1);self.assertEqual(len([w for w in e.write_events if w['address']==hex(A)]),1)
 def test_same_inc_bytes_at_unclassified_pc_reject_and_rollback(self):
  e=self.alias(b'\xfe\x05'+l.pack(A),A);before=bytes(e.cpu.mem_read(A,1))
  with self.assertRaisesRegex(b.Blocked,'unclassified write overlapping'):e.run(CODE,b.STOP)
  self.assertEqual(bytes(e.cpu.mem_read(A,1)),before);self.assertFalse(e.scenery_pool_increments);self.assertFalse(e.write_events)
 def test_exact_pc_wrong_phase_or_allocator_context_rejects(self):
  for mode in ['phase','caller']:
   e=self.make()
   if mode=='phase':e.phase='setup'
   else:
    e.cpu.mem_write(CODE,rel(0xe9,CODE,PC));e.windows[0]=(CODE,CODE+5)
   with self.assertRaisesRegex(b.Blocked,'unclassified write overlapping'):e.run(CODE,b.STOP)
   self.assertEqual(e.observed(A,1)['value'],0);self.assertFalse(e.scenery_pool_increments);self.assertFalse([w for w in e.write_events if w['address']==hex(A)])
 def test_unknown_counter_still_rejects_before_inc(self):
  e=self.make();e.shadow.put(A,1,0)
  with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'):e.run(CODE,b.STOP)
  self.assertFalse(e.scenery_pool_increments);self.assertFalse([w for w in e.write_events if w['address']==hex(A)])
 def test_faulting_counter_write_has_no_committed_increment_ordinal(self):
  e=self.make();e.cpu.mem_protect(A&~4095,4096,unicorn.UC_PROT_READ)
  with self.assertRaises(b.Blocked):e.run(CODE,b.STOP)
  self.assertFalse(e.scenery_pool_increments);self.assertFalse([w for w in e.write_events if w['address']==hex(A)]);self.assertEqual(e.observed(A,1)['value'],0)
 def test_law_rejects_unobserved_write_missing_row_or_final_unknown(self):
  for kind in ['missing-row','wrong-before','wrong-after','unknown-final']:
   e=self.make();e.run(CODE,b.STOP)
   if kind=='missing-row':e.scenery_pool_increments.clear()
   elif kind=='wrong-before':e.scenery_pool_increments[0]['valueBefore']=5
   elif kind=='wrong-after':e.scenery_pool_increments[0]['valueAfter']['value']=5
   else:e.shadow.put(A,1,0)
   with self.assertRaises(b.Blocked):l.alternator_assertions(e)
 def test_setup_preservation_checks_zero_and_never_reseeds(self):
  e=self.make();e.phase='setup'
  for a,n,val in [(0x89c6dd,2,3),(0x89d188,4,0),(0x5d45a8,1,3),(0x89ce37,1,0)]:e.supply(a,l.pack(val,n),'synthetic existing condition')
  e.supply(0x96eac1,bytes(12),'synthetic existing class seeds')
  for a in [0x89d178,0x89bc72]:e.supply(a,l.pack(0x09d78afe),'synthetic existing RNG')
  e.checkpoint_seeds('synthetic');self.assertEqual(e.phase_receipts[-1]['additionalConditionPreservation']['sceneryPoolAlternator']['value'],0)
  e.cpu.mem_write(A,b'\x01');count=len(e.supplies)
  with self.assertRaisesRegex(b.Blocked,'changed conditioned scenery'):e.checkpoint_seeds('synthetic changed')
  self.assertEqual(e.observed(A,1)['value'],1);self.assertEqual(len(e.supplies),count)
class ContractTests(unittest.TestCase):
 def test_source_contract_hash_and_one_new_named_entry_supply(self):
  self.assertEqual(hashlib.sha256(l.DISPATCH_INPUTS.read_bytes()).hexdigest(),l.DISPATCH_INPUTS_SHA);z=json.loads(l.DISPATCH_INPUTS.read_text());self.assertEqual(z['onlyProposedAdditionalEntrySupply']['address'],'0x96ead5');self.assertEqual(z['onlyProposedAdditionalEntrySupply']['value'],0);self.assertEqual(len(z['groupedControls']),12)
  source=(l.HERE/'constructor_ledger_alternator_candidate.py').read_text();self.assertEqual(source.count("e.supply(ALTERNATOR,b'\\0'"),1)
 def test_only_new_condition_is_named_alternator_lifetime(self):
  old_conditions=old.entry_conditions('land-clear');new=l.entry_conditions('land-clear');extra=[s for s in new if s not in old_conditions];self.assertEqual(len(extra),1);self.assertIn('0096ead5',extra[0]);self.assertEqual([s for s in new if s not in extra],old_conditions)
 def test_all_windows_contexts_and_resource_limits_unchanged(self):
  self.assertEqual(l.ranges(),old.ranges())
  for name in ['TEXTURE_CONTEXTS','ADDITIONAL_TEXTURE_CONTEXTS','TRACE_LIMIT','FINAL_JSON_LIMIT','FINAL_COMPRESSED_LIMIT','OTHER_OUTPUT_ALLOWANCE','SPACE_MARGIN','REQUIRED_FREE','ENTRY','NEXT','FINAL']:self.assertEqual(getattr(l,name),getattr(old,name))
if __name__=='__main__':unittest.main()
