#!/usr/bin/env python3
"""File-only authored-record and retained ordinary-cohort comparison."""
from pathlib import Path
import hashlib,json

H=Path(__file__).resolve().parent
ROOT=H.parents[4]
OWNER=ROOT.parent/'training-owner-observation-20261010'
GAME=ROOT.parent/'original-game-restoration-20261010/game'

def sha(x):return hashlib.sha256(x).hexdigest()
def rec(p):
 raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
def main():
 checks=[]
 def check(name,value):
  assert value,name
  checks.append({'name':name,'passed':True})
 p=ROOT/'references/verification/training-owner-2026-10-10/manifest.json';published=json.loads(p.read_text())
 obs=OWNER/'work/issue29-owner-observation/ordinary1/owner-source-events.json';owners=obs.with_name('owner-summary.json')
 for x in [obs,owners]:check('published observer hash '+x.name,sha(x.read_bytes())==published['members']['ordinary1/'+x.name])
 events=json.loads(obs.read_text())['events'];people=json.loads(owners.read_text())['people']
 ip=ROOT/'app/level-three.ts';src=ip.read_text();imp=json.loads(src.split('export default ',1)[1].strip().removesuffix(';'));by_index={r['index']:r for r in imp['objects']}
 check('ordinary and current imported Mission3 bytes match',ip.read_bytes()==(OWNER/'app/level-three.ts').read_bytes())
 dat=GAME/'levels/levl2003.dat';level=dat.read_bytes();check('canonical DAT matches imported source hash',sha(level)==imp['sourceSha256'])
 sp=H/'constructor-ledger-run08-selected-summary.json';s=json.loads(sp.read_text());alloc=s['selectedAssertions']['fullyReturnedSuccessfulAllocations'];class1=[r for r in alloc if r['class']==1]
 check('forty completed class1 counters in genuine order',[r['counter'] for r in class1]==list(range(40)))
 rows=[]
 for a in class1:
  n=a['originRecord'];raw=level[0x14043+(n-1)*55:0x14043+n*55];imported=by_index[n-1]
  check('authored record '+str(n)+' agrees with native returned class/model/owner',raw[1]==a['class'] and raw[0]==a['model'] and raw[2]==a['ownerRaw'])
  check('imported record '+str(n)+' retains raw class/model/owner',raw[1]==imported['type'] and raw[0]==imported['model'] and raw[2]==imported['owner'])
  rows.append({**a,'authoredRecord':n,'importedZeroBasedIndex':n-1,'browserAuthoredPosition':{'x':imported['x'],'z':imported['z']},'rawRecordSha256':sha(raw),'identityLimit':'Exact DAT/imported-record association; pool slot ID is not authored ID or browser replacement ID.'})
 check('forty-person group membership',[r['authoredRecord'] for r in rows]==list(range(10,27))+list(range(30,45))+list(range(46,54)))
 pending=[r for r in imp['objects'] if r['type']==1 and r['index']+1>93]
 check('twelve later Wildmen remain unexecuted',[r['index']+1 for r in pending]==list(range(94,102))+list(range(106,110)))
 mapped=[]
 for person in people:
  birth=[e for e in events if e['worldId']==2 and e['site']=='createLivePerson.return' and e['unit']['id']==person['id'] and e['unit']['aliases']['observed']==person['chosenOwnerId']]
  check('one retained owner birth '+str(person['id']),len(birth)==1)
  e=birth[0];u=e['unit'];chosen=next(o for o in u['owners'] if o['ownerId']==person['chosenOwnerId']);stack=e['extra']['stack']
  check('real startup conversion stack '+str(person['id']),'convertStartingWildman' in stack)
  candidates=[r['index']+1 for r in pending if r['x']==u['x'] and r['z']==u['z']]
  check('birth coordinate matches later authored group '+str(person['id']),bool(candidates))
  mapped.append({'browserReplacementId':person['id'],'retainedOwnerId':person['chosenOwnerId'],'sourceEventSequence':e['sequence'],'birthTurn':e['turn'],'browserBirthCounter':chosen['person']['counter'],'birthPosition':{'x':u['x'],'z':u['z']},'coordinateCandidateAuthoredRecords':candidates,'provenOriginalAllocationId':None,'identityLimit':'Coordinate correspondence only. The source event records the replacement, not the destroyed Wildman ID; duplicate authored positions are ambiguous. No original conversion or cross-engine ID mapping was executed.'})
 out={'status':'SOURCE_AND_RETAINED_OBSERVER_COMPARISON_NO_NEW_EXECUTION','script':rec(Path(__file__)),'inputs':[rec(x) for x in [sp,p,obs,owners,ip,dat]],'assertions':checks,'completedClass1AuthoredMapping':rows,'ordinarySelectedCohort':mapped,'unexecutedLaterWildmen':[{'record':r['index']+1,'class':r['type'],'model':r['model'],'owner':r['owner'],'position':{'x':r['x'],'z':r['z']}} for r in pending],'conclusion':'The partial conditional ledger proves40 earlier class1 allocations/counters0..39. The12 Blue-start Wildmen are later authored records and remain unexecuted. The ten observed training owners were new replacements at turns17/20/21, not these completed40 objects. This narrows allocation-counter ownership but supplies no exact Mission3 replacement seed or safe product offset.','remainingBoundaries':['Complete the conditional StageA loop including nested allocations.','Global post-load and omitted prior-history preservation are separate conditions/gates.','Execute/recover relevant real startup conversion waves and first scheduled visits before assigning original replacement counters.','Browser birth positions suggest later authored groups but do not independently identify duplicate source Wildmen or original pool IDs.']}
 target=H/'constructor-run08-identity-map.json';target.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'path':str(target),'sha256':sha(target.read_bytes()),'assertions':len(checks),'completedClass1':len(rows),'cohort':len(mapped)}))

if __name__=='__main__':main()
