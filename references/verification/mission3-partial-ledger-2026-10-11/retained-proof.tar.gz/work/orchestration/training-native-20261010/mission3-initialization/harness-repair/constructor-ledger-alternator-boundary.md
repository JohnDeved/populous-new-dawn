# Source-bound scenery pool alternator seam and committed ledger

This separate candidate preserves accepted run07 and frozen423311e1. Record1's genuine hut construction/postprocessing/published authored ID1 completed in pool slot639. Record2 then stopped before `004ed8ed INC BYTE[0096ead5]` because its input byte was unknown. Class1 had not allocated or changed its counter.

## One additional named entry condition

Original reset `0042bfa7 XOR EBX,EBX` followed by `0042bfbf MOV BYTE[0096ead5],BL` defines zero. The separately accepted projected-reset receipt contains that genuine committed write. The grouped source contract covers the complete record loop, primary allocator and class/state dispatch; it inventories39 global operands and12 control groups across seven windows. Other pool/reserve counters have existing genuine producers or already named seams. The sprite animation clock stays intentionally unknown.

The new condition supplies only BYTE[0096ead5]=0 at the first selected kernel, with an explicit unchanged lifetime across omitted earlier callers. Each genuine setup checkpoint must preserve it. There is no reseed after setup or between records. This source-bound condition does not establish the actual original Mission3 lifetime.

## Genuine updates and selected observable

The original INC, following parity TEST, descriptor flags, capacity checks and list selection execute genuinely. No instruction or branch is omitted. Every runtime memory write overlapping the byte is monitored, including wider/indirect aliases. The hook first journals the attempted bytes; any writer other than the exact unprefixed six-byte INC at004ed8ed in the active primary allocator and record-loop phase aborts and rolls back. Rejected writes receive no committed observer ordinal.

The predeclared law counts all committed INC executions, including nested allocations, allocation failures and constructors that remain open. After k such increments, the full-known byte equals k modulo256. It does not count returned allocations. Odd parity can force the low-ID list; even parity does not imply the high-ID list because the descriptor can already select low and later capacity/list decisions remain genuine. Existing class-counter, total-count and destructor/list changes remain separately recorded by the original event ledger; this byte is not substituted for those counts.

Each `sceneryPoolIncrements` result row contains record and allocator sequence, old/new byte, parity, committed instruction number and `writeEventOrdinal`. The optional raw `sceneryPoolIncrement` row is derived metadata referencing the existing committed byte-write event; it has no new observer ordinal. Final assertions reconcile all overlapping committed write records, row count/order, modulo256 progression, and the fully known final byte. Unknown final masks or an unclassified/missing write invalidate the claim.

## Verification and gate

301 host/authored-synthetic tests pass, including18 new tests. They exercise the actual Unicorn hook/run path for byte/word/DWORD/partial/protected alias writes and rollback,255→0 after256 genuine synthetic increments, nested/open/null-return associations, carry preservation, even parity with AL already1, unknown-input stops, fault after a prior valid increment, and setup mutation without reseeding. Initial focused failures were confined to a reused synthetic root stack pointer; the failed log is retained and the fixture now explicitly resets only its caller frame.

All91 executable windows, prior input/projection conditions, opcode semantics, budgets and allocation-completion assertions remain unchanged. No original execution occurred while preparing this candidate. Fresh independent review plus separate parent release is required for the proposed single run08. No retry, alternate seed, land case, global post-load pass or gameplay is implicitly admitted. Product check/build is not applicable to this ignored isolated research delta.
