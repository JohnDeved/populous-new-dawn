# Exact candidate standard-gate evidence

Frozen source bd07a6302bb0170e9d6dc235983c2a961694d753, draft PR241.
The independently accepted application and all tracked source stayed unchanged.

- One full npm check passed: TypeScript, all1,349 tests, parity consistency and
  orchestration validation. No failed or skipped test. Duration349.76s under900s.
- One production build passed in32.20s under300s.
- Scoped Oxfmt and ESLint passed. Scoped Oxlint exited0 with one unchanged
  prefer-export-from warning, reproduced on the exact d358 baseline with the same
  config. The baseline source bytes and filename-only normalization are retained.
  This is scoped attribution, not a claim that repository-wide legacy lint is clean.

All gates used CPU0–3 serially. Both terminal full-gate receipts retain raw streams,
source/tree/dirty-state/lock/inode fingerprints and empty owned process groups.
Build notices about large chunks, static route classification, plugin timing and
existing proxy/npm settings remain in raw logs; none was suppressed or configured
away. No browser, new native comparison, deployment or dependency installation ran.

The real dependency directory moved once from the terminal candidate0ef tree,
preserving device27/inode1978923, installed lock65e45d0a87d1ecd4fbf56508b9821eb3bfb3867c8477db4aaa1452eb2bed13d8
and root lockc1599d8d7e3f028e290a13561c653cf926e739e98eb9ec1b476dbe1c2a4558ba.
The donor retains only its exact lock stub. The directory remains terminal in the
fix tree pending coordinator-owned QA transfer; no commands remain active.

Ordinary passive cutoff evidence and final integration review remain pending.
The accepted native component and current port regression do not fill the missing
intermediate rendered witness or establish a visible improvement.
