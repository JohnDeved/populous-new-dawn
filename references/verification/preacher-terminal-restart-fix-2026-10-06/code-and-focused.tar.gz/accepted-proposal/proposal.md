# Native sermon cutoff and restart field proposal

Status: source-only proposal for independent review. No runtime edit, new native
execution, browser launch, package check or dependency movement has occurred.
Implementation worktree: preacher-terminal-restart-fix-20261006, clean base
`d35835caba6f6d89d9ca97a4f87a4b68744a6bbf`; its full tree equals frozen b2.
The accepted proof and result branch remain unchanged at aa328370.

## Exact proposed source delta

Only app/preacher-conversion.ts runtime code changes:

1. Import the existing stopPersonMovement helper from person-state.ts.
2. At the existing `if (p.timer >= 840)` transition, retain substate4 and also set
   `p.flags2 = (p.flags2 | 0x40000000) >>> 0`.
3. In phase4's existing no-following branch, retain substate2 and its entry-bit
   write, then call:
   `stopPersonMovement(p, (_, object) => effects.animate(object))`.

No new fixture-derived model, command, cargo, listener, frame or counter predicate
is proposed. The canonical terminal transition and no-following stop are shared
controller behavior. Narrowing them to the one supplied actor would create a new
condition absent from the original. The proposal explicitly includes this shared
branch consequence; it does not claim the one executed case proves every consumer.

The turning block stays exactly where it is. Do not move it inside timer<840.
The known >4-listener terminal turning/RNG discrepancy remains outside the repair.
Command32's existing post-switch expiry/release condition, following-order return,
substate1/5 arrival and phase2 entry logic remain unchanged.

## Native field and consumer ownership

Accepted executed source: 90d79f20e2931d61e8125a7a7a4ecf11b634201d.
The single granted case executes original controller0043a4d0, stop004d4ee0,
upper004d4040, lower004ee700 and updater004ee7b0. Its independently accepted raw
result is in references/verification/preacher-terminal-restart-2026-10-06 on the
research branch. No further native execution is requested by this proposal.

- At0043aa63, the original writes substate4;0043aa67 jumps to0043ab24, which ORs
  flags2 with0x40000000. This is a terminal entry-state write, not an RNG draw or
  animation call. Preserve every other flags2 bit and all existing branch order.
- At0043aae3/0043aae7, phase4 with no following order writes substate2 and the entry
  bit, then0043aaef calls004d4ee0. This call is absent in the current port.
- Actual004d4ee0 writes speed0 and selects an animation row through the existing
  cargo/airborne rules. It does not release motion routes, delete path caches,
  clear browser paths, change order ownership, acquire/release listeners or draw RNG.
- The existing stopPersonMovement implementation owns that same speed/row operation.
  In the executed cargo0, grounded model4 case it selects row0/model4→object17,
  whose actual upper/lower setters select source48/draw16.
- The lower/upper setters own object, draw, morph, renderFlags, palette, f1 and
  possible f2 clamp, plus upper assignment bit0x80 cleanup. In the accepted case:
  speed remains0; assignment remains272; morph0/palette240/renderFlags384 remain;
  source changes168→48 and draw14→16; f2 is retained0; the normal updater advances
  f2 to1. Do not add explicit f1/f2 resets at phase4.
- The next phase2 visit retains its existing stop then object95 sequence, explicit
  f1=1/f2=0, duration8→timer7 and updater0/0. Thus both streams converge on160/19.
  Counter/stamp/serial ownership remains with existing scheduling and animation.
- Both RNG words remain unchanged in the proved three-pair, empty-listener domain.
  No world-wide or positive-listener RNG invariant is inferred from that case.

The live `effects.stop` adapter is deliberately not reused for the new phase4 call.
app/live-movement.ts:595–602 first calls releasePersonRoute, clearLivePath and only
then stopPersonMovement. releasePersonRoute mutates motionGroup/motionIndex and
route reference/active records; clearLivePath can release another registered route,
delete the per-unit pathfinding entry and replace u.path. None is owned by004d4ee0.
Calling the primitive directly through the already supplied effects.animate keeps
those unproved side effects out of the new branch. Existing entry/arrival uses of
the broader callback remain unchanged by this patch.

## Shared-controller impact and evidence limits

Production entry is world-turn.ts:1319–1324 for current orders17/31/32, then
stepLivePreaching runs physics/routes and requires native state10 before the order
queue. person-order-update.ts:144–159 maps31/32 to the same17 controller adapter.
The command model is therefore not a sound boundary for pretending this change
only affects17. The following consequences are explicit and reviewable:

- Command17: the ordinary empty-listener cutoff/restart state and complete native
  component field outcomes are established. The current-b2 ordinary candidate
  reaches the same branch, but its intermediate restart render was skipped.
- Command31/Tower: its existing producer retains building occupancy. If it reaches
  the same terminal/no-following branches it receives the original entry bit and
  speed/animation stop too. This proposal adds no31 producer, occupancy change,
  five-cell radius change, completion change or claimed Tower rendered witness.
  Preserve building/workTarget/flags4, queue ownership and acquisition/release rules.
- Command32: it receives those shared branch operations if reached. Its existing
  post-switch expiry can still release/return1 on odd visits or phase4 where the
  original returns0. Original expiry/release is inside the even-counter scan tail;
  the port checks it after the switch. This predicate gap is not repaired, hidden
  or described as whole-controller equality. Both implementations set the shared
  terminal entry bit before any eligible scan tail; the bit is not17-specific.
- Positive listeners and active-at840 gestures: no listener counting, assignment64,
  turning mode, commandPhase or RNG branch moves. The terminal entry bit and shared
  stop also apply if such supplied states reach these branches, as in canonical
  code. Their complete native world composition is unproved by the one case.
- Cargo/airborne/vehicle: the existing stop and upper-setter selectors remain the
  sole owners. Do not hardcode source48 or introduce a new visibility/vehicle rule.
  Cargo chooses the existing row4; airborne flags use existing row12/2 behavior.
  Native004d4ee0's airborne selector can clear flags2 bit0x8000 when row2 applies.
  Vehicle-specific upper animation is not composed by the accepted proof. The
  live animation adapter's existing empty object map and unsupported hypothetical
  vehicle sermon remain an explicit limitation, not a new completed capability.
  Normal transport state30 is handled before the sermon dispatcher; no ordinary
  state10 vehicle-sermon producer has been established here. No vehicle adapter
  repair or new native case is included.

These shared effects are a consequence of repairing two original shared operations,
not permission to repair their other behaviors. If preserving31/32 byte-for-byte
is a hard task requirement, this exact source-faithful proposal needs a coordinator
scope decision rather than silently adding a fixture-specific runtime guard.

## Failure-first regression plan after proposal acceptance

Use a small Node test with only the controller, existing stop/setters/updater and
local JSON imports. It needs no node_modules. Derive the expected case from the
accepted raw native result with recorded SHA256; do not regenerate native outputs
or modify the accepted proof fixture. Freeze input and expected phase snapshots.

1. Reproduce the exact one-case/three-pair native projection. Before the patch,
   demonstrate the current flags2 and source/draw divergences. After the patch,
   require all45 mapped fields, synthesized raw256, commands/order, both RNGs and
   controller returns to equal accepted native phases without masks. The expected
   source sequence is168/14→48/16→160/19, with normal updater frames0→1→0.
2. Use an effects.stop callback that throws on a direct phase4 visit; verify the
   new branch uses the primitive animation adapter instead. Preserve supplied
   route-group/index and route/cache sentinels because the controller has no world
   route API to mutate. Assert no sound, acquire or release on that phase4 visit.
3. Bounded supplied shared-controller assertions for17/31/32 verify the same
   phase4 speed/animation operation, building/workTarget/vehicle/cargo ownership,
   entry bit and queue identities. They are port regressions backed by shared
   static native instructions, not new original execution or ordinary producers.
   Keep the existing command32 expiry outcome explicit in its supplied case.
4. The existing following-order branch must still release/return before any new
   stop; entry/arrival callback ordering is unchanged. Preserve the known turning
   fixture behavior at timer839/status bit2 clear rather than weakening or claiming
   that gap is fixed. Existing gesture reset/RNG tests remain required later.

The later live integration test/ordinary observation should use the shipped adapter
and normal clock. No tests or runtime code are implemented until this field proposal
is accepted. Full check/build/quality/browser work needs the coordinator's later
resource decision; none is launched for this proposal.

## Existing render evidence, not a new browser request

Accepted candidate0ef original stream: true render4173/substate4/source168/draw14;
model-only phase4-to-2 at4174; next true render4175/source160/draw19. No4174 image
or pixel buffer exists. Accepted baseline9a similarly skips4246/4247 and renders
historical source160/draw19 at4248. The hash-bound observer calls the real renderer
before recording and removes only same-turn duplicates. The intermediate interval
was skipped in these captured main-render streams.

A later passive ordinary capture can establish reachability and owned state even
when rendering skips. A visible-improvement claim needs actual boundary pixels;
do not force a renderer/tick, alter cadence or infer pixels from model state.
