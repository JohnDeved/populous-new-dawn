# Preacher terminal restart candidate code review

Base d35835caba6f6d89d9ca97a4f87a4b68744a6bbf, candidate
bd07a6302bb0170e9d6dc235983c2a961694d753. The clean fix worktree changes exactly
four files. Accepted research source, native execution, baseline/browser artifacts
and historical b2 checker outputs remain immutable.

The runtime diff imports an existing primitive, restores the terminal entry bit,
and calls the primitive animation stop on phase4/no-following. It does not invoke
the broader route/path cleanup callback or change clock, rendering, arrival,
following-order completion, positive-listener turning or command32 expiry gates.
Shared operation effects are explicit in the accepted field proposal.

The new fixture derives from native SHA1751ba217c1870a16a667fe638f7e250729bda62e01a1d16638f868f5c2e829c,
executed source90d79f20 and independent ACCEPT. It retains the original complete
record snapshots; it is not a newly recorded fixture or original execution.

Failure-first50e65e82: six focused tests, four expected failures (terminal bit,
restart family, speed-only stop and shared restart); queue completion and existing
turning behavior pass. Focused4e9639e5: all six pass, all mapped/raw256 phases match
native and source hashes are unchanged. Those exact tested application/test inputs
remain byte-identical at candidatebd07a630, so the receipt is reused honestly.

The maintained standalone replay reads current source, not a frozen b2 head. Its
old inventory fails on this candidate because the terminal flags now equal native.
The checker edit removes only that permitted mismatch, requiring equality instead;
27 cases,63 visits,73 requests,all input hashes,raw bytes and raw events stay fixed.
Before/after current-port stdout bytes are identical. The updated replay passes and
retains exactly the turning/RNG and odd32 completion residuals, plus44 raw-event
rows. The full failed/current outputs are included; no native instruction ran.

The read-only planner flags app/preacher-conversion.ts and both new test paths as
unmapped. Adding the checker path selects the broad campaign subsystem gates as
well as repository check/build. This mapping does not establish their relevance.
Exact source review must cover the unmapped paths and the coordinator must choose
appropriate integration/quality/ordinary-browser gates. None of those full/native/
browser gates has run here; no dependency was moved. Typecheck,format,lint,build
and ordinary rendered impact remain pending, not passed by these focused receipts.

No visible improvement is claimed. The retained ordinary candidate and baseline
both skip the intermediate phase4-to-2 main-render interval. Later passive evidence
must preserve that distinction and must never force a render or change cadence.
