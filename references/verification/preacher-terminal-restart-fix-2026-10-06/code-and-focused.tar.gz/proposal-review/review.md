# Runtime field-proposal review

Verdict: **ACCEPT for the proposed bounded implementation. No blocking findings.**

Reviewed proposal SHA256
2366ba21475c15a3d5ed06541443911941fcbc4270b022799cb65063936014a2,
manifest SHA256
3c9ea94a87af0bd1eb818fd48fcd4fee1bca071431ea7978ea7620eb514e5477.
All14 bound source files match. Isolated fix base
 d35835caba6f6d89d9ca97a4f87a4b68744a6bbf is clean; its tree
3caa1e1337836a8ccca8c9e83da6c3a2f1baf5a5 equals frozen b2's entire tree.
This is source-only review; no native,application,browser or package job ran.

The exact runtime delta is appropriate: preserve the existing timer>=840 predicate
and its location, OR the entry bit while entering substate4, then add the existing
stopPersonMovement primitive through effects.animate only in phase4's no-following
branch, after its existing substate2/entry-bit writes. The original instructions
0043aa63→0043ab24 and0043aae3→0043aaef support these operations. The independently
accepted original write/event result supports the fixed on-foot17 composition.

## Owned state and unchanged consumers

The primitive owns speed0 and the existing cargo/airborne row selection. Its
existing animation setter owns source/draw,morph,palette,renderFlags,f1,conditional
f2 clamp and assignment-bit0x80 cleanup. Airborne row2 can clear flags2 bit0x8000.
These are original operations, not fixture-specific source48 assignments. No new
manual frame reset is justified. In the accepted case, phase4 changes only
source168/14 to48/16 beyond the existing state/entry changes; the normal updater
advances0→1. Existing phase2 then selects95 and converges to160/19,timer7,frame0.

The broad live effects.stop callback must remain unused by this new branch. Its
releasePersonRoute/clearLivePath calls own motion group/index,route references,
path cache membership and u.path; none is owned by004d4ee0. Direct primitive use
preserves those existing phase4 route/path states. It also leaves the following-
order early return/release branch,existing phase2 and arrival callbacks unchanged.
No queue ownership,clock,renderer cadence or new RNG operation is added.

## Shared branches and explicit remaining gaps

The original controller and production dispatcher share17/31/32. The native
terminal entry bit and no-following stop are not17-only operations. The proposal
correctly avoids artificial command/model/cargo/listener guards derived solely
from the executed fixture, while limiting its composed-result claim to that fixture.

Command32 requires particular care: original expiry/release is gated inside the
even-counter scan tail. The port's post-switch check can still release/return1 on
odd visits or phase4 where native returns0. Restoring the shared entry bit/stop
does not fix this predicate gap. The proposal explicitly preserves that code and
excludes32 completion or whole-controller parity from acceptance. Likewise it
leaves the positive-listener terminal turning/RNG gap unchanged: the turning block
must not move inside timer<840 as part of this patch.

Tower/cargo/airborne/vehicle selectors remain owned by existing helpers. No building,
workTarget,flags4,occupancy,radius or transport rule changes. The existing live
animation adapter's empty vehicle-object map and lack of an established ordinary
state10 vehicle-sermon producer remain limitations; this review accepts no new
vehicle/Tower composition claim or adapter repair. Ordinary transport state30 is
handled before sermon dispatch in the actual world-turn source.

## Verification and claims

The proposed fixed three-pair all45-field/raw256/RNG/order regression against
accepted native output is appropriate. The phase4 throwing broad-stop callback
and preserved route/path sentinels protect the key ownership boundary. Following-
order and shared supplied regressions should preserve existing32 release and
turning outcomes explicitly, not turn them into passing native-equality claims.
No additional native cases or case expansion is needed for this proposal.

The remaining candidate is to be implemented and checked under the coordinator's
resource decision, then reviewed at its exact final head. This proposal acceptance
is not final code or evidence acceptance.

Existing ordinary source/model reachability remains separate from pixels. The
intermediate render was skipped in the retained streams. Any later lightweight
passive capture must preserve normal clocks and rendering, and visible improvement
must remain conditional on actual boundary pixels. Do not force a frame to fill
that gap. PR240 is not expanded.
