# Passive Preacher cutoff plan review

Decision: **ACCEPT the source-only plan** at QA `53bd2a40527b2db6587aa356174507f6065f64f3`. No concrete plan blocker remains. This decision does not approve a driver or launch that does not yet exist.

The full change from accepted QA `0ef63ba8e1dbf2ef51e33626948e179116c40ca4` is exactly two files, `qa/preacher-cutoff-passive/README.md` and `source-inputs.json`. The final change after `3d214571f42f9bc9ee1166b36dc45881e6aa4694` only expands the native source pin to `90d79f20e2931d61e8125a7a7a4ecf11b634201d`; the plan is unchanged. I independently verified clean Git, accepted QA ancestry, all 12 helper hashes and byte equality to accepted QA, all 11 application/input hashes, and all four app/public/scripts/tests trees against main `d35835caba6f6d89d9ca97a4f87a4b68744a6bbf`. There are no dependencies or new runnable files in this plan directory. Whitespace checking passes.

## Evidence and source assessment

The plan reuses the accepted ordinary Mission 3 Vault, Temple, one actual trainee admission/replacement, safe-point acquisition and native-owner input validation. The inherited 5×5 ground interior checks, detached native context, strict drift guard, original recipient, bounded pre-dispatch repick and no retry after dispatch remain intact. It reuses `chainPhaseObservers`, not the baseline's full-world observation body. Per-person scalar reads with compact queue/identity and zero-listener/threat predicates are appropriate for this narrower task. Imports and geometry work are excluded from the controller callbacks.

I inspected the existing game clock and inherited observer chain. `clock.afterTurn` runs before `animateLiveObjects(w, 'logical')`, so its sample cannot prove updated animation or rendered presentation. The plan correctly requires separate next-beforeTurn pairing with native owner, source and stamp, and labels it `next-beforeTurn-after-update`. An original main renderer invocation supplies separate `render-after-updater` evidence. Preserving original callback receiver, arguments, return, count and descriptors, restoring in finally, and failing on observer/restoration errors are explicit requirements for the forthcoming driver.

The plan keeps the actual fresh model 3 to command 17 entry, adjacent visits, complete timers 1 through 840, detailed terminal/reset/next-entry sequence and first resumed loop. It selects the cutoff from actual transitions rather than historical turn numbers. It records native-domain mismatch if a natural active 176/184 terminal gesture differs from the accepted native supplied idle 168 case. It does not repair that mismatch by extending a cycle or changing RNG. Exact terminal entry/stop fields and application adoption remain bound to the separate runtime review. The planned scope does not include commands 31/32 or their separate release/expiry behavior.

No stale controller-phase mesh is promoted to render evidence. The optional maximum of three 128×128 framebuffer crops can only follow actual original main rendering, synchronously, on the valid current default framebuffer. No render invocation, hidden body, pause, tick, clock change or live-state write is allowed. Readback start/end time and buffer orientation are retained. A PNG encoded from those bytes must be labelled a framebuffer crop. A skipped reset remains `render-not-observed`; it neither invalidates the model-state witness nor establishes visible improvement. Mesh submission alone and non-differential crops cannot claim isolated body pixels. These boundaries directly address the historical unrendered middle cutoff without requiring a fresh baseline or new framework.

## Finite execution boundary

The future driver must preserve the original 360-second acquisition, 900 adjacent logical visits and 120 wall seconds from observed fresh command 17 entry, including observer and readback costs. Its finite outcome is the paired cutoff, next phase 2 entry and first resumed loop, or the first failed owner/predicate/bound. The original 2800-row ceiling includes any detailed cutoff records. The focused test list covers missed entry, skipped visits, incorrect controller/update/render labels, stale mesh, wrong owner/pair, duplicated callbacks, restoration failure and expired bounds, with a source guard against passive callback mutations.

The proposed envelope is 540-second harness, 570-second outer SIGINT plus 20-second kill grace, private port 4405, CPUs 0–3, and fresh task-owned 0700 TMP/cache/output paths. This is proportionate to the unchanged 360+120-second stages plus startup and cleanup. It is a proposed envelope only. Final runner source, exact argv, runtime and explicit input hashes, dependency ownership/transfer, port availability, and the adopted application must be frozen and independently reviewed before the parent's single-run grant. This plan creates no extra comparison run.

## Verification and limits

This review used read-only source and hash checks; no browser, package, native or application gates were executed. TypeScript format/lint/Oxlint and application check/build are not applicable to the current Markdown/JSON-only delta. Focused source/structural checks suffice here; the runtime owner retains its application gate obligations, and the new QA driver will need its own focused syntax and dependency-free regressions.

Native source acceptance and the earlier ordinary baseline/candidate results remain separately scoped evidence. The historical candidate attempt 01 input failure, bootstrap failure-first result, and unrendered middle frames are not relabelled. This plan proves no visible fix, full original-game parity, audio mixer result or hardware performance improvement.

## Exact artifacts

- Plan SHA256: `102407ed12f6f1fe4932b7846c9f4204f23ee76a58ac6e60a05d1c33e6036594`
- Input manifest SHA256: `d7e55996ee899f1c9c86f863159f79e84366931d8080f4b892c8a29e9006bd9b`
- Owner source-only receipt SHA256: `2664dfa5fad56ee1cea2280ac7f4a70654c322cb2931a7c04360b6051e60bb52`
- Independent audit: `work/reviews/preacher-cutoff-passive-plan-audit-53bd2a40.json`
