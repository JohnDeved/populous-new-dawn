import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
const root=resolve(process.argv[2]??'work/issue29-owner-observation/ordinary1')
const read=name=>JSON.parse(readFileSync(resolve(root,name),'utf8'))
const report=read('ordinary-m3.json'), raw=read('owner-source-events.json'), receipt=read('receipt.json')
const worldId=report.ownerInitial.worldId, events=raw.events.filter(e=>e.worldId===worldId),click=report.trustedClickOwners
const pre=click.before[0].owners,post=click.after[0].owners
const bySequence=new Map(events.map(e=>[e.sequence,e]))
const counts=xs=>Object.fromEntries([...new Set(xs)].map(k=>[k,xs.filter(x=>x===k).length]))
const owner=(unit,id)=>unit.owners.find(p=>p.ownerId===id)
const brief=(unit,id)=>{const row=owner(unit,id);if(!row)return null;const p=row.person;return {ownerId:id,counter:p.counter,state:p.state,previousState:p.previousState,substate:p.substate,speed:p.speed,commandPhase:p.commandPhase,restingStates:[1,17,19].includes(p.state),currentOrderId:row.currentOrderId,orders:row.orders,aliases:unit.aliases,work:unit.work,inside:unit.inside,builderTask:unit.builderTask}}
const writes=events.filter(e=>e.site.endsWith('.after')&&(e.site.includes('Counter')||e.site.includes('rephase')))
const actualCounter=e=>owner(e.unit,e.unit.aliases.observed)?.person.counter
const summaries=report.selected.map(id=>{
 const before=pre.people.find(u=>u.id===id),after=post.people.find(u=>u.id===id)
 const handler=events.filter(e=>e.unit.id===id&&e.sequence>pre.sequence&&e.sequence<=post.sequence)
 const chosen=handler.find(e=>e.site==='issueLiveOrders.bindingChosen'), key=chosen?.unit.aliases.observed
 const personEvents=events.filter(e=>e.unit.id===id)
 const creations=personEvents.filter(e=>e.site==='createLivePerson.return').map(e=>({sequence:e.sequence,turn:e.turn,ownerId:e.unit.aliases.observed,counter:actualCounter(e),randomState:e.randomState,stack:e.extra.stack}))
 const changes=writes.filter(e=>e.unit.id===id).map(e=>{const before=bySequence.get(e.sequence-1);return {sequence:e.sequence,site:e.site,turn:e.turn,ownerId:e.unit.aliases.observed,before:actualCounter(before),after:actualCounter(e),beforeRandomState:before.randomState,afterRandomState:e.randomState,state:owner(e.unit,e.unit.aliases.observed)?.person.state,aliases:e.unit.aliases}})
 const spans=[]
 for(const e of changes){const last=spans.at(-1);if(last&&last.site===e.site&&last.ownerId===e.ownerId&&e.turn===last.lastTurn+1){last.lastTurn=e.turn;last.lastSequence=e.sequence;last.count++;last.lastBefore=e.before;last.lastAfter=e.after}else spans.push({site:e.site,ownerId:e.ownerId,firstTurn:e.turn,lastTurn:e.turn,firstSequence:e.sequence,lastSequence:e.sequence,count:1,firstBefore:e.before,firstAfter:e.after,lastBefore:e.before,lastAfter:e.after})}
 const pickedEvents=changes.filter(e=>e.ownerId===key)
 return {id,wasBuilder:report.builders.includes(id),chosenOwnerId:key,before:brief(before,key),after:brief(after,key),sameObject:after.aliases.entry===key,creations,rephaseSpans:spans,lastRephaseBeforeClick:pickedEvents.filter(e=>e.sequence<pre.sequence).at(-1)??null,firstRephaseAfterClick:pickedEvents.find(e=>e.sequence>post.sequence)??null,handler:handler.map(e=>({sequence:e.sequence,site:e.site,turn:e.turn,randomState:e.randomState,owner:brief(e.unit,e.unit.aliases.observed??key)}))}
})
const rows=report.timeline.rows, timeline=rows.map(r=>({turn:r.turn,randomState:r.owners.randomState,counters:r.owners.people.map(u=>({id:u.id,owners:u.owners.map(o=>({ownerId:o.ownerId,counter:o.person.counter,state:o.person.state,substate:o.person.substate,speed:o.person.speed})),aliases:u.aliases})),outside:r.people.filter(u=>u.inside===null&&u.entry?.substate===5).map(u=>u.id),inside:r.people.filter(u=>u.inside===report.target.id).map(u=>u.id)}))
const transitions=[];for(let i=1;i<timeline.length;i++){const now=timeline[i],prev=timeline[i-1];const ids=now.inside.filter(id=>!prev.inside.includes(id));if(ids.length)transitions.push({turn:now.turn,ids})}
const result={status:report.status,base:receipt.source.commit,fingerprint:receipt.source.fingerprint,sourceAfter:receipt.sourceAfter,worldId,sourceEvents:{all:raw.events.length,live:events.length,otherWorlds:counts(raw.events.filter(e=>e.worldId!==worldId).map(e=>e.worldId)),bySite:counts(events.map(e=>e.site)),errors:raw.errors},click:{turn:pre.turn,beforeSequence:pre.sequence,afterSequence:post.sequence,beforeRandomState:pre.randomState,afterRandomState:post.randomState,beforeCosmeticRandom:pre.cosmeticRandom,afterCosmeticRandom:post.cosmeticRandom,selected:pre.selected,pre:click.before[0],post:click.after[0]},people:summaries,admission:{maxOutside:Math.max(...timeline.map(r=>r.outside.length)),maxOutsideRows:timeline.filter(r=>r.outside.length===Math.max(...timeline.map(r=>r.outside.length))),transitions,terminal:report.terminalAcceptance},timeline}
writeFileSync(resolve(root,'owner-summary.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({status:result.status,worldId,sourceEvents:result.sourceEvents,clickTurn:pre.turn,randomState:[pre.randomState,post.randomState],people:summaries.map(p=>({id:p.id,builder:p.wasBuilder,owner:p.chosenOwnerId,beforeCounter:p.before?.counter,afterCounter:p.after?.counter,beforeState:p.before?.state,beforeSpeed:p.before?.speed,sameObject:p.sameObject,creations:p.creations.map(({stack,...r})=>r),lastRephaseBeforeClick:p.lastRephaseBeforeClick,firstRephaseAfterClick:p.firstRephaseAfterClick})),admission:{maxOutside:result.admission.maxOutside,transitions,terminal:report.terminalAcceptance}},null,2))
