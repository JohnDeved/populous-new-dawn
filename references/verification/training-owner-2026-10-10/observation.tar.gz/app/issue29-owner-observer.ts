// Isolated diagnostic instrumentation. Observer-owned maps/arrays only; no game writes,
// no gameplay calls, no RNG, no orders, no scheduling. Source data is copied synchronously.
const owners = new WeakMap<object, number>()
const worlds = new WeakMap<object, number>()
let ownerSerial = 0, worldSerial = 0, serial = 0
const events: unknown[] = [], errors: string[] = []
const ownerId = (p: any) => {
  if (!p || typeof p !== 'object') return null
  if (!owners.has(p)) owners.set(p, ++ownerSerial)
  return owners.get(p)!
}
const worldId = (w: any) => {
  if (!worlds.has(w)) worlds.set(w, ++worldSerial)
  return worlds.get(w)!
}
const copy = (x: any) => x === undefined ? null : structuredClone(x)
function snapshotUnit(w: any, u: any, p?: any) {
  if (!u) return null
  const aliases = { native: u.native, builder: u.builder?.person, entry: u.entry?.person,
    flight: u.flight, fight: u.fight?.motion, resident: u.resident?.person,
    pathfinding: w.pathfinding?.people.get(u.id), registered: w.objectCells?.objects.get(u.id), observed: p }
  const unique = [...new Set(Object.values(aliases).filter(Boolean))]
  const ownerSnapshots = unique.map(person => ({ ownerId: ownerId(person), person: copy(person),
    currentOrderId: person.immediateCommand || person.commands?.[person.commandCursor] || 0,
    orders: [...new Set([person.immediateCommand, ...(person.commands ?? [])].filter(Boolean))].map(id => ({id, record: copy(w.buildingOrders?.records[id])})) }))
  return { id: u.id, kind: u.kind, team: u.team, hp: u.hp, x: u.x, z: u.z, heading: u.heading,
    inside: u.inside, work: u.work, target: u.target, tree: u.tree, cargo: u.cargo, guard: u.guard,
    path: copy(u.path), harvest: copy(u.harvest), delivery: copy(u.delivery),
    builderTask: u.builder ? copy(Object.fromEntries(Object.entries(u.builder).filter(([key]) => key !== 'person'))) : null,
    residentBuilding: u.resident?.building ?? null, vault: copy(u.vault),
    aliases: Object.fromEntries(Object.entries(aliases).map(([key, value]) => [key, ownerId(value)])), owners: ownerSnapshots }
}
function snapshot(w: any, ids: number[]) {
  return { sequence: serial, worldId: worldId(w), level: w.outcome?.level, turn: w.turn, time: w.time,
    randomState: w.randomState, cosmeticRandom: copy(w.cosmeticRandom), speed: w.speed, paused: w.paused,
    selected: [...w.selected], lastOrderTurn: w.lastOrderTurn, people: ids.map(id => snapshotUnit(w, w.units.find((u: any) => u.id === id))) }
}
export function recordOwnerSource(site: string, w: any, u: any, p?: any, extra?: any) {
  try {
    if (typeof window === 'undefined' || u.team !== 'blue') return
    if (events.length >= 80000) throw Error('Source observer capacity reached')
    events.push({ sequence: ++serial, site, worldId: worldId(w), level: w.outcome?.level, turn: w.turn, time: w.time,
      randomState: w.randomState, cosmeticRandom: copy(w.cosmeticRandom), speed: w.speed, paused: w.paused,
      unit: snapshotUnit(w, u, p), extra: copy(extra) })
  } catch (error) { if (errors.length < 8) errors.push(String(error)) }
}
if (typeof window !== 'undefined') (window as any).issue29OwnerSource = {
  snapshot, read: () => ({ events, errors, ownerCount: ownerSerial, worldCount: worldSerial }),
}
