from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd(); out=root/'work/issue29-owner-observation'; manifest=[]
def change(name,edits):
 p=root/name; before=p.read_text(); after=before
 for a,b in edits:
  assert after.count(a)==1,(name,a,after.count(a))
  after=after.replace(a,b)
 p.write_text("import { recordOwnerSource } from './issue29-owner-observer.ts'\n"+after)
 manifest.append({'path':name,'originalSha256':hashlib.sha256(before.encode()).hexdigest(),'instrumentedSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'edits':[{'anchor':a,'replacement':b} for a,b in edits]})
change('app/live-people.ts',[
 ('  return {\n    id: u.id,','  const created: LivePerson = {\n    id: u.id,'),
 ('    computerAssignment: 0,\n  }\n}',"    computerAssignment: 0,\n  }\n  recordOwnerSource('createLivePerson.return', w, u, created, { stack: new Error().stack })\n  return created\n}")])
for name,anchor,label in [
 ('app/live-resting.ts','    p.counter = w.turn & 255','stepLiveResting.rephase'),
 ('app/live-pathfinding.ts','    p.counter = w.turn & 255','stepLiveRoute.rephase'),
 ('app/live-construction-runtime.ts','  p.counter = w.turn & 255','processBuilderWork.rephase'),
]:
 indent=anchor[:len(anchor)-len(anchor.lstrip())]
 change(name,[(anchor,f"{indent}recordOwnerSource('{label}.before', w, u, p)\n{anchor}\n{indent}recordOwnerSource('{label}.after', w, u, p)")])
change('app/live-movement.ts',[
 ('export function adoptLiveOrders(w: World, u: Unit, p: LivePerson) {',"export function adoptLiveOrders(w: World, u: Unit, p: LivePerson) {\n  recordOwnerSource('adoptLiveOrders.before', w, u, p)"),
 ('    u.native = p\n  }\n}\n\n// Player clicks',"    u.native = p\n  }\n  recordOwnerSource('adoptLiveOrders.after', w, u, p)\n}\n\n// Player clicks"),
 ('  let count = 0\n  const bindings',"  for (const u of units) recordOwnerSource('issueLiveOrders.before', w, u, undefined, { command, replace, playerReplacement })\n  let count = 0\n  const bindings"),
 ('  return { accepted, count }\n}',"  for (const u of units) recordOwnerSource('issueLiveOrders.after', w, u, undefined, { command, replace, playerReplacement, accepted, count })\n  return { accepted, count }\n}")])
change('app/level-start-runtime.ts',[
 ('    p.counter = people.findIndex(o => o.model === 7 && o.owner === tribeForTeam(u.team)) & 255',"    recordOwnerSource('levelStart.authoredCounter.before', w, u, p)\n    p.counter = people.findIndex(o => o.model === 7 && o.owner === tribeForTeam(u.team)) & 255\n    recordOwnerSource('levelStart.authoredCounter.after', w, u, p)"),
 ('    p.counter = site.counter',"    recordOwnerSource('levelStart.siteCounter.before', w, u, p)\n    p.counter = site.counter\n    recordOwnerSource('levelStart.siteCounter.after', w, u, p)")])
(out/'source-instrumentation.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':manifest},indent=2)+'\n')
