#!/bin/bash
set -u
export TMPDIR=/workspace/scratch/69fd8163d94e/training-owner-observation-tmp-20261010
cd /workspace/scratch/69fd8163d94e/training-owner-observation-20261010 || exit 1
out="$PWD/work/issue29-owner-observation"
test ! -e "$out/ordinary1" || { echo 'Evidence destination already exists'; exit 1; }
printf '%s\n' "$$" > "$out/owned-runner.pid"
node scripts/local-render/harness.mjs --game-root "$PWD" --browser /workspace/scratch/69fd8163d94e/recovery-20261010b/browser/chrome-headless-shell-linux64/chrome-headless-shell --port 4195 --timeout 510000 --scenario "$out/ordinary-m3-owner.mjs" --output "$out/ordinary1" > "$out/ordinary1-command.log" 2>&1
result=$?
printf '%s\n' "$result" > "$out/ordinary1-exit-code.txt"
printf 'Ordinary Mission3 owner observation exit %s\n' "$result"
exit "$result"
