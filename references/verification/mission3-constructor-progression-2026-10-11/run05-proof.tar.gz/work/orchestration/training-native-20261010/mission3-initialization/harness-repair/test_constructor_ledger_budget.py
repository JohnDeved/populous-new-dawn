"""Host-only budget selection tests; no original execution."""
import hashlib,unittest
from types import SimpleNamespace
import constructor_ledger_budget_candidate as l
class BudgetTests(unittest.TestCase):
 def fake(self):
  events=[];e=SimpleNamespace(phase=None,boundary_registers=lambda *a:events.append(('boundary',a)),supply=lambda *a:events.append(('supply',a)),run=lambda *a,**k:events.append(('run',a,k)),checkpoint_seeds=lambda *a:events.append(('checkpoint',a)));return e,events
 def test_only_exact_animation_cut_uses300seconds(self):
  e,events=self.fake();l.Ledger.cut(e,0x42c4b6,0x42c5ee,'startup animation transform');r=next(v for v in events if v[0]=='run');self.assertEqual(r[1],(0x42c4b6,0x42c5ee));self.assertEqual(r[2],{'budget':3000000,'timeout_us':300000000});self.assertEqual(events[-1],('checkpoint',('startup animation transform',)))
 def test_other_cuts_and_similar_ranges_keep240seconds(self):
  for start,stop in [(0x42c4b6,0x42c5ed),(0x42c4b7,0x42c5ee),(0x40c8a5,0x40c8d8),(0x484e7b,0x484e9a)]:
   e,events=self.fake();l.Ledger.cut(e,start,stop,'startup animation transform');r=next(v for v in events if v[0]=='run');self.assertEqual(r[2],{'budget':3000000,'timeout_us':240000000})
 def test_all_root_calls_keep240seconds(self):
  for root in [0x4ed820,0x4eef50,0x493a40,0x44ddc0,0x42c4b6]:
   e,events=self.fake();l.Ledger.root(e,root,'synthetic root');r=next(v for v in events if v[0]=='run');self.assertEqual(r[2],{'budget':3000000,'timeout_us':240000000})
 def test_entire_delta_is_only_two_exact_budget_substitutions(self):
  old=(l.HERE/'constructor_ledger_closure_candidate.py').read_text();self.assertEqual(hashlib.sha256(old.encode()).hexdigest(),'2f5254fc3a649b1ba642ad92b1cdbc14dbe986c9d7f5957fce91fdd440572431')
  expected=old.replace('self.run(start,stop,budget=3_000_000,timeout_us=240_000_000);self.checkpoint_seeds(label)','self.run(start,stop,budget=3_000_000,timeout_us=300_000_000 if (start,stop)==(0x42c4b6,0x42c5ee) else 240_000_000);self.checkpoint_seeds(label)').replace("'perKernelTimeoutSeconds':240,'perBlockInstructions'","'perKernelTimeoutSeconds':240,'startupAnimationTimeoutSeconds':300,'perBlockInstructions'")
  self.assertEqual((l.HERE/'constructor_ledger_budget_candidate.py').read_text(),expected)
 def test_all_event_storage_and_outer_guards_retained(self):
  self.assertEqual((l.TRACE_LIMIT,l.FINAL_JSON_LIMIT,l.FINAL_COMPRESSED_LIMIT,l.OTHER_OUTPUT_ALLOWANCE,l.SPACE_MARGIN,l.REQUIRED_FREE),(512*l.MIB,1536*l.MIB,512*l.MIB,64*l.MIB,256*l.MIB,1344*l.MIB))
  source=(l.HERE/'constructor_ledger_budget_candidate.py').read_text();self.assertIn("'globalAttemptedInstructionLimit':12000000",source);self.assertIn("'globalObserverEventLimit':5000000",source);self.assertIn("'outerProcessTimeoutSeconds':1200",source);self.assertIn("'perBlockTimeoutSeconds':240",source)
if __name__=='__main__':unittest.main()
