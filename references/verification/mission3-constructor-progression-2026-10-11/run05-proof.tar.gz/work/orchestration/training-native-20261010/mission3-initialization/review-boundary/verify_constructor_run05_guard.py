"""File-only guard regression and reject-before-projection check; no CPU/mask replay."""
from pathlib import Path
import gzip,hashlib,json
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';ROOT=next(p for p in H.parents if (p/'GOAL.md').exists())
def sha(p):
 h=hashlib.sha256();n=0
 with Path(p).open('rb') as f:
  while c:=f.read(1024*1024):h.update(c);n+=len(c)
 return n,h.hexdigest()
def prefix(p):
 lines=[]
 with gzip.open(p,'rt') as f:
  for line in f:
   if line.startswith('  "memoryReads":'):break
   lines.append(line)
 return json.loads(''.join(lines).rstrip().rstrip(',')+'\n}')
p=H/'constructor-ledger-clear-run05-process-receipt.json';z=json.loads(p.read_text());assert z['status']=='terminal' and z['exitCode']==2;assert z['driversBefore']==z['driversAfter'] and len(z['driversAfter'])==9
for name,s in z['driversAfter'].items():assert sha(H/name)[1]==s
for f in z['artifacts']+[z['wrapper'],z['approval']]:
 q=Path(f['path']);q=q if q.is_absolute() else ROOT/q;assert sha(q)==(f['bytes'],f['sha256'])
a=json.loads((ROOT/z['approval']['path']).read_text());held=json.loads((R/'constructor-ledger-budget-held-approval.json').read_text());held['parentReleasedRunLane']=True;assert all(a.get(k)==v for k,v in held.items())
out=H/'constructor-ledger-clear-run05';sr=json.loads((out/'constructor-ledger-result-stream-receipt.json').read_text());digest=hashlib.sha256();size=0
with gzip.open(out/'constructor-ledger-result.json.gz','rb') as f:
 while c:=f.read(1024*1024):digest.update(c);size+=len(c)
assert (size,digest.hexdigest())==(sr['uncompressedBytes'],sr['uncompressedSha256'])
v=prefix(out/'constructor-ledger-result.json.gz');old=prefix(H/'constructor-ledger-clear-run03/constructor-ledger-result.json.gz')
assert v['complete'] is False and v['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP'
assert v['attemptedOriginalInstructions']==v['committedOriginalInstructions']==4069009
assert v['blocker']['pc']=='0x4bdebe' and v['blocker']['details']=={'kind':[2,1],'context':['0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8]}
assert not v['projections'] and not v['abortedInstructions'] and not v['returnedAllocations'];assert len(v['records'])==1 and v['records'][0]['status']=='entered';assert len(v['openCalls'])==9
assert v['finalRegisters']==old['projections'][0]['entryRegisters']
oldcalls={c['sequence']:c for c in old['calls']};frames=[]
for c in v['openCalls'][-2:]:
 d=oldcalls[c['sequence']]
 for k in ['sequence','parent','caller','target','return','returnSp','entryRegisters']:assert c[k]==d[k]
 frames.append({k:c[k] for k in ['sequence','parent','caller','target','return','returnSp']})
assert oldcalls[2080]['returned'] and oldcalls[2090]['returned'];assert oldcalls[2090]['parent']==2080
assert len(v['counterCopies'])==len(v['counterIncrements'])==1
# Inspect only projection-relevant event descriptors, not full masks/values.
invalidations=[];forbidden=[];rows=0
with gzip.open(out/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  rows+=1
  if line.startswith(b'{"kind":"invalidation"'):
   e=json.loads(line);invalidations.append(e)
   if e['pc']=='0x4bdebe':forbidden.append(e)
  elif b'"pc":"0x4bd' in line:
   e=json.loads(line)
   if 0x4bdebe<=int(e['pc'],16)<0x4bdfdb:forbidden.append(e)
assert not forbidden
report={'verdict':'ACCEPT_LIMITED_GUARD_REGRESSION_CLASSIFICATION','originalInstructionsExecutedByReviewer':0,'processSha256':sha(p)[1],'resultGzipSha256':sr['sha256'],'expandedSha256':sr['uncompressedSha256'],'expandedBytes':size,'eventGzipSha256':sha(out/'constructor-ledger-events.jsonl.gz')[1],'allNineFrozenHashesStable':True,'releasedApprovalSha256':z['approval']['sha256'],'status':v['status'],'complete':False,'attemptedAndCommittedOriginalInstructions':4069009,'blocker':v['blocker'],'actualFramesMatchingRun03':frames,'oldProjectionEntryEqualsNewFinalRegisters':True,'rejectBeforeSkip':{'projectionCount':0,'abortedInstructions':0,'invalidationsAtProjectionPc':0,'memoryEventsInOmittedRange':0,'rawRowsScannedForThisQuestion':rows,'allInvalidationDescriptorsInspected':len(invalidations)},'partialLedger':{'returnedAllocations':0,'completedRecords':0,'enteredRecords':1,'openCalls':9,'counterCopies':v['counterCopies'],'counterIncrements':v['counterIncrements']},'finding':'The strengthened new caller guard omitted the actual00404be6→00403a00 tuple already present in accepted run03. Review verified proposed tuples but missed this retained observed caller; this is an overrestrictive admission regression.','requiredRepair':'Bind exact source first-argument and call/return bytes at00404be3..00404beb; add only the exact justified context, keep actual object class/model and all projection footprint/alias/liveout guards; add a run03-frame-derived regression plus prior/new negative contexts. Fresh hash review and parent release before any retry.','limits':['Full compressed identities and expanded result hash/length checked. Small result metadata/call prefix and projection-relevant raw descriptors inspected.','No full observer/mask reconciliation, CPU arithmetic replay or independent all-value reconstruction. No new native execution.','This retains a partial first allocation and zero returned/completed objects. No new final count, startup or gameplay claim.'],'verifierSha256':sha(Path(__file__))[1]}
(R/'constructor-ledger-run05-guard-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS_LIMITED_GUARD_REVIEW','reviewSha256':sha(R/'constructor-ledger-run05-guard-review.json')[1],'rowsScanned':rows,'originalInstructionsExecuted':0}))
