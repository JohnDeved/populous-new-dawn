#!/usr/bin/env python3
"""Finite, source-only operand-form and dispatch audit; never creates a CPU."""
from pathlib import Path
import collections,json
import capstone
import constructor_ledger_context_candidate as l
H=Path(__file__).resolve().parent;b=l.b;x=capstone.x86

def main():
 pe=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;rows={};windows=[];checks=[]
 def check(name,test):
  assert test,name
  checks.append({'name':name,'passed':True})
 for a,z in l.ranges():
  raw=pe.read(a,z-a);ii=list(cs.disasm(raw,a));check(hex(a)+' complete admitted window',sum(i.size for i in ii)==len(raw));windows.append({'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw)});rows.update((i.address,i) for i in ii)
 base={'mov','movsx','movzx','lea','and','or','xor','test','add','sub','cmp','inc','dec','push','pop','call','ret','stosb','stosw','stosd','rep stosb','rep stosw','rep stosd','rep movsd','jmp','nop'}|set(b.BRANCH_FLAGS)
 extensions={'shl','shr','sar','ror','imul','cdq','idiv','div','neg','not','adc','sbb','bsr'}
 forms={};unsupported=[];direct=[];indirect=[];shift_cl=[]
 for pc,i in sorted(rows.items()):
  ops=i.operands;m=i.mnemonic
  form=[{'type':{x.X86_OP_REG:'register',x.X86_OP_MEM:'memory',x.X86_OP_IMM:'immediate'}.get(o.type,str(o.type)),'bytes':o.size,**({'register':i.reg_name(o.reg)} if o.type==x.X86_OP_REG else {})} for o in ops]
  reasons=[]
  if m not in base|extensions:reasons.append('unhandled mnemonic')
  if i.addr_size!=4 or any(p not in (0,0x66,0xf3) for p in i.prefix):reasons.append('unhandled address/segment/other prefix')
  for o in ops:
   if o.type==x.X86_OP_REG and i.reg_name(o.reg) not in b.ALIASES:reasons.append('unhandled register')
   if o.type==x.X86_OP_MEM and o.mem.segment and not (m.split()[-1] in ['stosb','stosw','stosd','movsd'] and i.reg_name(o.mem.segment)=='es' and not any(p in [0x26,0x2e,0x36,0x3e,0x64,0x65] for p in i.prefix)):reasons.append('explicit segment requires review')
  if m in ['push','pop'] and any(o.size!=4 for o in ops):reasons.append('non-DWORD stack form')
  if m=='pop' and ops[0].type!=x.X86_OP_REG:reasons.append('nonregister POP')
  if m=='ret' and ops:reasons.append('callee-cleanup RET')
  if m=='rep movsd' and i.bytes.hex()!='f3a5':reasons.append('noncanonical REP MOVSD prefix')
  if m in ['div','idiv'] and not (len(ops)==1 and ops[0].type==x.X86_OP_REG and ops[0].size in (2,4)):reasons.append('divisor form unsupported by frozen engine')
  if m=='imul' and not ((len(ops)==1 and ops[0].size==4) or (len(ops)==2 and ops[0].type==x.X86_OP_REG and all(o.size==4 for o in ops)) or (len(ops)==3 and ops[0].type==x.X86_OP_REG and ops[2].type==x.X86_OP_IMM and ops[0].size in (2,4))):reasons.append('IMUL form unsupported')
  if m=='bsr' and not (len(ops)==2 and all(o.type==x.X86_OP_REG and o.size==4 for o in ops)):reasons.append('BSR form unsupported')
  if m in ['shl','shr','sar','ror']:
   if ops[1].type==x.X86_OP_IMM:
    if ops[1].imm&31>=ops[0].size*8:reasons.append('immediate count outside admitted finite width')
   elif ops[1].type==x.X86_OP_REG and i.reg_name(ops[1].reg)=='cl':shift_cl.append({'pc':hex(pc),'instruction':m+' '+i.op_str})
   else:reasons.append('shift count form unsupported')
  row={'pc':hex(pc),'bytes':i.bytes.hex(),'mnemonic':m,'operands':i.op_str,'operandForms':form,'prefixes':list(i.prefix),'formClassification':'unsupported' if reasons else 'covered subject to runtime provenance, address/target and native-fault guards','reasons':reasons,'reachability':'observed failed instruction in run06' if pc==0x404153 else 'static admitted code; not execution/reachability evidence'}
  sig=json.dumps([m,[(o['type'],o['bytes']) for o in form],list(i.prefix)],sort_keys=True);forms.setdefault(sig,{'mnemonic':m,'operandForms':[{k:v for k,v in o.items() if k!='register'} for o in form],'prefixes':list(i.prefix),'pcs':[]})['pcs'].append(hex(pc))
  if reasons:unsupported.append(row)
  if m in ['call','jmp']:
   if ops[0].type==x.X86_OP_IMM:
    target=ops[0].imm;direct.append({'pc':hex(pc),'kind':m,'target':hex(target),'admitted':any(a<=target<z for a,z in l.ranges()),'instructionBoundary':target in rows,'classification':'admitted target; forms audited' if target in rows else 'unsupported residual target; first actual taken edge stops, no reachability exclusion inferred'})
   else:indirect.append({'pc':hex(pc),'kind':m,'bytes':i.bytes.hex(),'operand':i.op_str,'classification':'actual pointer/index must be known and target admitted; table membership alone grants no execution'})
 check('exactly two frozen capability gaps',[(r['pc'],r['mnemonic']) for r in unsupported]==[('0x404153','idiv'),('0x422de5','setle')])
 check('only three CL count sites', [r['pc'] for r in shift_cl]==['0x422b4f','0x422b7b','0x44fa0f'])
 count_sources=[]
 for a,z,name in [(0x422b30,0x422b55,'AND CL7 before first byte shift'),(0x422b57,0x422b86,'AND CL7 before second byte shift'),(0x44f9fa,0x44fa11,'CL7 minus DL masked7 before DWORD shift'),(0x404139,0x404157,'observed memory IDIV zero guard and CDQ'),(0x422dc8,0x422def,'unexecuted SETLE after known-input CMP')]:
  raw=pe.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' complete',sum(i.size for i in ii)==len(raw));count_sources.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]})
 inv=json.loads(l.INVENTORY.read_text());tables=[]
 for t in inv['dispatchTables']:
  # Retained source inventory already binds each table/remap's canonical bytes.
  targets=[{'address':s,'admitted':any(a<=int(s,16)<z for a,z in l.ranges()),'instructionBoundary':int(s,16) in rows} for s in t['targets']]
  tables.append({**t,'targetAdmission':targets,'scope':'All admitted instruction targets are included in the9332-instruction scan. Any nonadmitted target remains a fail-closed capability boundary, without claiming that direct authored models exclude nested dispatch.'})
 out={'status':'SOURCE_ONLY_FINITE_CAPABILITY_AUDIT_NO_NATIVE_EXECUTION','script':b.file_record(Path(__file__)),'driver':b.file_record(H/'constructor_ledger_context_candidate.py'),'executable':b.file_record(b.EXE),'inventory':b.file_record(l.INVENTORY),'assertions':checks,'windowCount':len(windows),'instructionCount':len(rows),'mnemonics':dict(sorted(collections.Counter(i.mnemonic for i in rows.values()).items())),'windows':windows,'operandFormGroups':list(forms.values()),'unsupportedInstructionForms':unsupported,'directControlEdges':direct,'indirectControlSites':indirect,'dispatchTables':tables,'sourceCountAndGapWindows':count_sources,'clShiftBound':'All three native CL suppliers bound the consumed value to0..7; byte shifts therefore remain below width. Unknown source/input guards still apply.','proposedSemanticDelta':['Known DWORD memory IDIV with known EDX:EAX and effective address; retain genuine read and native zero/overflow/access fault rollback. No8-bit division or new MUL/shift/string opcode support.','Byte register SETLE with known ZF/SF/OF, preserve every flag and unaffected register bits. Static admitted walk-mask helper only; no claim this path has run.'],'runtimeResiduals':['Unknown operands/addresses and table contents remain guarded.','Known divisor zero, quotient overflow or invalid memory may still trigger real faults and abort.','Direct/indirect targets outside admitted windows remain blocked; nested state/constructor activation is not excluded.','This covers finite admitted instruction forms, not all original code or proof every original execution would finish.']}
 path=H/'constructor-capability-audit01.json';b.json_write(path,out);print(json.dumps({'path':str(path),'sha256':b.sha(path.read_bytes()),'instructions':len(rows),'windows':len(windows),'formGroups':len(forms),'gaps':len(unsupported),'dispatchTables':len(tables),'outsideDirectTargets':sum(not r['admitted'] for r in direct),'outsideTableTargets':sum(not r['admitted'] for t in tables for r in t['targetAdmission'])}))
if __name__=='__main__':main()
