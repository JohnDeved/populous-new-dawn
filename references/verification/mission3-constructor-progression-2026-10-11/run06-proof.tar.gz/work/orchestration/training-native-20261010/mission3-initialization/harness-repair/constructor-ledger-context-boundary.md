# Historical texture-context guard repair

This separate candidate preserves frozen budget driver `86a296a3` and all run05 evidence. Run05 stopped before projection because the newly restricted caller table omitted a genuine call already accepted in run03. No returned allocation or completed record was established.

## Exact delta

Add only the class2/model1 context:
`00404be6 → 00403a00`, return `00404beb`, then `00403bf3 → 004bdd40`, return `00403bf8`.
The six previously admitted building/scenery tuples remain intact. Model18 at the newly added caller is still rejected. Executable windows, source inputs, unknown-state guards, projections, event semantics, budgets, model terrain and selected-ledger assertions are unchanged. The new preflight additionally binds the historical source/evidence contract.

Canonical `00404be3 PUSH 1; 00404be5 PUSH ESI` establishes the actual first argument; `00403a08 MOV ECX,[ESP+30h]` consumes it after the native prologue. The object comes from the genuine parent call frame, not the originating authored record or the projection's volatile registers. The native texture frame retains ESP = child pre-CALL ESP minus36. Source-derived geometry bounds and all opaque-resource pointer/alias conditions remain enforced.

## Historical regression evidence

`constructor-context-repair-source.json` binds run03's full compressed result and its accepted expanded identity, calls2080 and2090, actual projection entry registers, raw observer events2547793..2547796,2547813,2548443..2548450,2548472..2548478, and four canonical byte windows. Observer events prove known masks; concrete argument values derive from the retained call-entry registers and canonical PUSH/LEA/store instructions. The summary alone is not the call-frame source.

Seven literal positive fixtures are independently enumerated in the new test and checked against the reviewer's immutable fixture. They are never generated from production `TEXTURE_CONTEXTS`. Each caller/return/target near miss, unknown argument/model/frame/geometry, unjustified class/model combination and gained opaque-pointer provenance rejects before any taint. Removing an expected production tuple makes its independent fixture fail. The exact historical fixture fails the frozen regressed guard and passes both the original61c7 projection and this repaired candidate with identical output invalidations/register masks. Additional bytes seeded solely for synthetic footprint testing are labeled synthetic, not captured game state.

All prior conditions remain explicit, including land-clear/class-seed0, RNG09d78afe, successful abstract transports, model-derived terrain, and normal completion/disjoint opaque resource writes for the existing285-byte texture projection. No original Mission3 startup or completed allocation count is claimed. Later decisive unknowns and unsupported targets still stop with partial committed changes and open calls preserved.

## Admission and verification

265 host/authored-synthetic tests pass. The first focused test log is retained: one host exception-class mismatch across separately loaded frozen modules was fixed in the new test only. Static preflight executes zero original instructions and preserves all91 windows. The old and new preflights compare exactly after removing current-driver/source-binding metadata and the one added context.

No original execution is authorized by this packet. Fresh independent review and a separate parent release are required. The one-run wrapper would use fresh run06 paths and the unchanged1200-second outer bound; animation300seconds, all other phases240seconds, instruction/event/storage limits unchanged. No retry or checkpoint reuse is implicit. Standard product check/build gates are not applicable to this ignored, isolated research-only delta; no product files changed.
