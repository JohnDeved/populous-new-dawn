"""Host-only actual setup dispatch contract; run() is a recorder, never a CPU."""
from pathlib import Path
from types import SimpleNamespace
import importlib,sys,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'harness-repair'))
q=importlib.import_module(sys.argv.pop(1) if len(sys.argv)>1 else 'constructor_ledger_context_candidate')
class StopAfterDispatch(Exception):pass
class AnimationDispatch(unittest.TestCase):
 def test_actual_setup_uses_declared_animation_budget(self):
  calls=[]
  def run(start,stop,**kw):calls.append((start,stop,kw));raise StopAfterDispatch()
  fake=SimpleNamespace(root=lambda *args:None,boundary_registers=lambda *args:None,supply=lambda *args:None,run=run,phase=None)
  with self.assertRaises(StopAfterDispatch):q.setup(fake,{})
  self.assertEqual(calls,[(0x42c4b6,0x42c5ee,{'budget':3000000,'timeout_us':300000000})])
if __name__=='__main__':unittest.main()
