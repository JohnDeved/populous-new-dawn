#!/usr/bin/env python3
"""Bind the retained successful run03 texture context; source/file reads only."""
from pathlib import Path
import gzip,json,capstone
import constructor_ledger_budget_candidate as old
H=Path(__file__).resolve().parent;b=old.b

def main():
 checks=[]
 def check(name,value):
  assert value,name
  checks.append({'name':name,'passed':True})
 result=H/'constructor-ledger-clear-run03/constructor-ledger-result.json.gz'
 events=H/'constructor-ledger-clear-run03/constructor-ledger-events.jsonl.gz'
 fixture=H.parent/'review-boundary/constructor-texture-independent-fixture.json'
 review=H.parent/'review-boundary/constructor-ledger-run03-post-review.json'
 check('retained run03 compressed result identity',old.stream_file_record(result)['sha256']=='11ef1baf0a11b556be9a1e624b79f5e8520f8770d001c7f21f1c742b61b10e26')
 check('retained run03 raw events identity',old.stream_file_record(events)['sha256']=='ce55fba5d017dc259ac90705820433f5eaa0bd0e4c28f40b3641acb462a3720e')
 check('independent immutable fixture identity',b.sha(fixture.read_bytes())=='0a6dce0aae2241b574ae5eb98a6bd9ff22a26d03d95e4c0c476fc9e02de42c73')
 with gzip.open(result,'rt') as f:
  prefix=''
  while '"memoryReads":' not in prefix:
   part=f.read(65536)
   if not part or len(prefix)>16000000:raise RuntimeError('missing bounded result metadata prefix')
   prefix+=part
 data=json.loads(prefix.split('"memoryReads":')[0].rstrip().removesuffix(',')+'}')
 frames=[x for x in data['calls'] if x['sequence'] in [2080,2090]];projection=data['projections'][0]
 check('retained genuine frame chain',[(x['sequence'],x['parent'],x['caller'],x['target'],x['return'],x['returnSp']) for x in frames]==[(2080,2074,'0x404be6','0x403a00',0x404beb,0x23ecc38),(2090,2080,'0x403bf3','0x4bdd40',0x403bf8,0x23ecbfc)])
 check('observed projection object and native ESP',projection['object']=='0x8fc2f5' and projection['entryRegisters']['esp']=={'value':'0x23ecbd8','knownMask':'0xffffffff'})
 check('source ESI first argument',frames[0]['entryRegisters']['esi']=={'value':'0x8fc2f5','knownMask':'0xffffffff'})
 check('source radius PUSH EAX and coordinates PUSH ECX',frames[1]['entryRegisters']['eax']=={'value':'0x3','knownMask':'0xffffffff'} and frames[1]['entryRegisters']['ecx']=={'value':'0x7b09624','knownMask':'0xffffffff'})
 check('actual first object class/model',data['records'][0]['class']==2 and data['records'][0]['model']==1)
 independent=json.loads(fixture.read_text());check('projection equals independently extracted full result',projection==independent['run03Projection'])
 for actual,ind in zip(frames,independent['run03CallFrames']):check('independent frame '+str(actual['sequence']),all(actual[k]==v for k,v in ind.items()))
 wanted={'0x404be5','0x403a08','0x403bf1','0x403bf2','0x4bdd54','0x4bdd59','0x4bdd6a'};rows=[]
 with gzip.open(events,'rt') as f:
  for line in f:
   if any('"pc":"'+pc+'"' in line for pc in wanted):rows.append(json.loads(line))
 check('parent pointer read source mask',any(x['kind']=='read' and x['pc']=='0x403a08' and x['address']=='0x23ecc38' and x['size']==4 and x['knownMask']=='0xffffffff' and x['eventOrdinal']==2547813 for x in rows))
 for pc,a,n,ordinal in [('0x404be5',0x23ecc38,4,2547793),('0x403bf1',0x23ecc00,4,2548443),('0x403bf2',0x23ecbfc,4,2548447),('0x4bdd6a',0x23ecbf0,4,2548475)]:
  check(pc+' actual committed byte masks',[(int(x['address'],16),x['eventOrdinal']) for x in rows if x['pc']==pc and x['kind']=='write' and x['knownMask']=='0xff' and x['committed']]==[(a+i,ordinal+i) for i in range(n)])
 p=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[]
 for name,a,z in [('actual hut caller and argument',0x404bd7,0x404bee),('parent prologue first argument',0x403a00,0x403a0c),('actual child arguments and return',0x403be9,0x403c03),('texture frame and geometry',0x4bdd40,0x4bdd7d)]:
  raw=p.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' complete window',sum(i.size for i in ii)==len(raw));windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]})
 for a,raw in [(0x404be3,'6a0156e815eeffff'),(0x403a08,'8b4c2430'),(0x403bf1,'5051e848a10b00'),(0x4bdd54,'0fbf442428668b542424'),(0x4bdd6a,'894c2418')]:check(hex(a)+' exact argument bytes',p.read(a,len(bytes.fromhex(raw)))==bytes.fromhex(raw))
 check('parent pre-CALL ESP argument offset',4+32+3*4==0x30)
 check('native texture SP and argument offsets',0x23ecbfc-36==0x23ecbd8 and 0x23ecbd8+0x28==0x23ecc00)
 out={'status':'SOURCE_AND_RETAINED_RECEIPT_ONLY_NO_NATIVE_EXECUTION','script':b.file_record(Path(__file__)),'executable':b.file_record(b.EXE),'frozenBudgetDriver':b.file_record(H/'constructor_ledger_budget_candidate.py'),'run03Result':old.stream_file_record(result),'run03Events':old.stream_file_record(events),'run03PostReview':b.file_record(review),'independentFixture':b.file_record(fixture),'assertions':checks,'windows':windows,'callFrames':frames,'projection':projection,'eventReferences':rows,'guardInputReconstruction':{'parentFirstArgument':{'address':'0x23ecc38','value':'0x8fc2f5','knownMask':'0xffffffff'},'objectClassModel':[2,1],'coordinateWord':{'address':'0x23ecbfc','value':'0x9624','knownMask':'0xffff'},'radiusWord':{'address':'0x23ecc00','value':3,'knownMask':'0xffff'},'widthDword':{'address':'0x23ecbf0','value':7,'knownMask':'0xffffffff'}},'delta':'Add only actual class2/model1 caller00404be6, preserving the six existing contexts. No added model18 permission for this caller. All argument, frame, geometry, opaque-pointer, output-footprint and later-consumption guards are unchanged.','limits':'Observer rows carry masks rather than values. Argument values derive from the retained genuine call-entry registers plus canonical PUSH and width LEA/store bytes. Prior accepted full mask review remains separate. No restored native state or new original instruction execution.'}
 path=H/'constructor-context-repair-source.json';b.json_write(path,out);print(json.dumps({'path':str(path),'sha256':b.sha(path.read_bytes()),'assertions':len(checks),'windows':len(windows)}))
if __name__=='__main__':main()
