"""Read-only source/retained trace slices; no canonical CPU."""
from pathlib import Path
import gzip,hashlib,json,re,sys
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';sys.path.insert(0,str(H))
import constructor_ledger_context_candidate as q
import capstone
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=H/'constructor-context-repair-source.json';assert sha(p)=='e2afde7260b46a94d61e0378e512c2e71ed40d5b4ed75b3269bd9ced7e71f235';j=json.loads(p.read_text())
for key in ['script','executable','frozenBudgetDriver','run03Result','run03Events','run03PostReview','independentFixture']:
 f=j[key];assert Path(f['path']).stat().st_size==f['bytes'] and sha(f['path'])==f['sha256']
pe=q.b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);n=0
for w in j['windows']:
 a,z=int(w['start'],16),int(w['endExclusive'],16);raw=pe.read(a,z-a);assert hashlib.sha256(raw).hexdigest()==w['sha256']
 ii=[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in cs.disasm(raw,a)];assert ii==w['instructions'];n+=len(ii)
fixture=json.loads((R/'constructor-texture-independent-fixture.json').read_text());assert j['projection']==fixture['run03Projection']
for c,d in zip(j['callFrames'],fixture['run03CallFrames']):assert all(c[k]==v for k,v in d.items())
refs={e['eventOrdinal']:e for e in j['eventReferences']};found={}
# Locate only the exact independently checked argument/mask rows; full mask chronology is the prior run03 review.
with gzip.open(j['run03Events']['path'],'rb') as f:
 for line in f:
  if any(x in line for x in [b'"pc":"0x404be5"',b'"pc":"0x403a08"',b'"pc":"0x403bf1"',b'"pc":"0x403bf2"',b'"pc":"0x4bdd54"',b'"pc":"0x4bdd59"',b'"pc":"0x4bdd6a"']):
   e=json.loads(line)
   if e['eventOrdinal'] in refs:assert e==refs[e['eventOrdinal']];found[e['eventOrdinal']]=e
assert len(found)==len(refs)==19
c,d=j['callFrames'];g=j['guardInputReconstruction'];assert c['sequence']==2080 and d['sequence']==2090 and d['parent']==2080
assert int(c['entryRegisters']['esi']['value'],16)==int(g['parentFirstArgument']['value'],16)==0x8fc2f5
assert int(d['entryRegisters']['eax']['value'],16)&65535==g['radiusWord']['value']==3
assert int(d['entryRegisters']['ecx']['value'],16)&65535==int(g['coordinateWord']['value'],16)==0x9624
assert g['widthDword']['value']==2*g['radiusWord']['value']+1==7
assert int(g['parentFirstArgument']['address'],16)==c['returnSp'];assert int(j['projection']['entryRegisters']['esp']['value'],16)==d['returnSp']-36
for a,h in [(0x404be3,'6a0156e815eeffff'),(0x403bf1,'5051e848a10b00'),(0x4bdd5e,'8d0c4501000000')]:assert pe.read(a,len(bytes.fromhex(h)))==bytes.fromhex(h)
report={'verdict':'ACCEPT_HISTORICAL_CONTEXT_SOURCE_REPAIR','originalInstructionsExecuted':0,'sourceReceiptSha256':sha(p),'sourceWindows':4,'sourceInstructionRows':n,'sourceReportedAssertions':len(j['assertions']),'retainedRawArgumentEventsMatched':19,'independentFixtureSha256':sha(R/'constructor-texture-independent-fixture.json'),'literalContexts':fixture['expectedContexts'],'actualArgumentValues':g,'limits':'Argument values reconstructed from genuine retained call-entry registers plus canonical PUSH and LEA/store instructions. Observer rows independently matched for masks/locations only. No new native execution or full run03 replay.','verifierSha256':sha(Path(__file__))}
(R/'constructor-context-source-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS','sha256':sha(R/'constructor-context-source-review.json'),'sourceRows':n,'argumentEventRows':len(found)}))
