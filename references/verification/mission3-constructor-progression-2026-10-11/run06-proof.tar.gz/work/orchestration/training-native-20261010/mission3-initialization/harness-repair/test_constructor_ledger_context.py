"""Independent literal guard fixtures and retained-run regression; no original x86."""
import copy,hashlib,json,unittest
from unittest.mock import patch
import unicorn
import constructor_ledger_context_candidate as l
import constructor_ledger_inputs_candidate as original
import constructor_ledger_budget_candidate as previous
b=l.b
# Immutable expected tuples: never built by iterating the production allowlist.
HISTORICAL=('0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8)
BUILDING=('0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8)
SCENERY=('0x403c10','0x4a68b6',0x4a68bb,'0x403d3c',0x403d41)
EXPECTED=(((2,1),HISTORICAL),((2,1),BUILDING),((2,18),BUILDING),((5,2),SCENERY),((5,3),SCENERY),((5,6),SCENERY),((5,9),SCENERY))
FIXTURE=l.HERE.parent/'review-boundary/constructor-texture-independent-fixture.json'
SOURCE=l.HERE/'constructor-context-repair-source.json'
class ContextRegressionTests(unittest.TestCase):
 def make(self,kind=(2,1),context=HISTORICAL,radius=1,historical=False):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  e=l.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(l.TEXTURE_START,l.TEXTURE_END+5)],protected_inputs=[],enable_texture_projection=True)
  e.phase='authored-record-loop';e.record=1;sp=l.FRAME-0x200;ptr=b.POOL+179;parent_sp=l.FRAME+0x20
  if historical:
   fixture=json.loads(SOURCE.read_text());sp=0x23ecbd8;ptr=0x8fc2f5;parent_sp=0x23ecc38;radius=3
   e.frames=copy.deepcopy(fixture['callFrames'])
   for r,v in fixture['projection']['entryRegisters'].items():e.reg_supply(r,int(v['value'],16),int(v['knownMask'],16),'synthetic reconstruction of retained run03 entry')
  else:
   e.frames=[{'target':context[0],'caller':context[1],'return':context[2],'returnSp':parent_sp},{'target':'0x4bdd40','caller':context[3],'return':context[4],'returnSp':sp+36}]
   for r,v in [('esp',sp),('eip',l.TEXTURE_START),('eflags',2)]+[(r,0x12345678) for r in ['eax','ebx','ecx','edx','esi','edi','ebp']]:e.reg_supply(r,v,b.MASK32,'authored synthetic fixture')
  for a,raw in [(0x5d45a8,b'\x03'),(parent_sp,l.pack(ptr)),(ptr+0x2a,bytes(kind)),(sp-156,bytes(204)),(sp+24,l.pack(2*radius+1)),(sp+36,l.pack(0x9624 if historical else 0x1212,2)),(sp+40,l.pack(radius,2)),(0x9bc318,bytes(1024))]:e.supply(a,raw,'synthetic guard test; consumed historical values bound separately in source receipt')
  return e,sp,ptr
 def assert_footprint(self,e,sp):
  self.assertEqual(e.reg_value('eip'),l.TEXTURE_END);self.assertEqual(e.reg_value('esp'),sp)
  for a,n in [(sp-156,156),(sp+16,6),(sp+28,4),(0x9bc318,1024)]:self.assertEqual(e.shadow.get(a,n),0)
  self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertEqual(e.shadow.get(sp+24,4),b.MASK32)
  for r in ['eax','ebx','ecx','edx','esi','edi','ebp']:self.assertEqual(e.shadow.reg_get(r),0)
  self.assertEqual(e.shadow.reg_get('eflags')&b.ARITH,0);self.assertEqual(e.shadow.reg_get('esp'),b.MASK32)
  self.assertEqual([r['eventOrdinal'] for r in e.invalidation_events],list(range(12)))
  self.assertFalse(e.events);self.assertFalse(e.write_events);self.assertEqual(e.committed,0)
 def test_fixture_hashes_and_independent_literal_contexts(self):
  self.assertEqual(hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),'0a6dce0aae2241b574ae5eb98a6bd9ff22a26d03d95e4c0c476fc9e02de42c73')
  self.assertEqual(hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'e2afde7260b46a94d61e0378e512c2e71ed40d5b4ed75b3269bd9ced7e71f235')
  f=json.loads(FIXTURE.read_text());self.assertEqual([((r['class'],r['model']),tuple(r['context'])) for r in f['expectedContexts']],list(EXPECTED))
  self.assertEqual(f['run03ResultGzipSha256'],'11ef1baf0a11b556be9a1e624b79f5e8520f8770d001c7f21f1c742b61b10e26')
 def test_all_seven_literal_contexts_preserve_exact_output_footprint(self):
  for kind,context in EXPECTED:
   with self.subTest(kind=kind,context=context):
    e,sp,ptr=self.make(kind,context);e.texture_projection();self.assert_footprint(e,sp);self.assertEqual(e.projections[0]['callerContext'],list(context));self.assertEqual(e.projections[0]['object'],hex(ptr))
 def test_exact_historical_run03_frames_entry_and_argument_regression(self):
  e,sp,ptr=self.make(historical=True);before=e.register_snapshot();e.texture_projection();self.assert_footprint(e,sp)
  self.assertEqual(e.projections[0]['entryRegisters'],json.loads(SOURCE.read_text())['projection']['entryRegisters']);self.assertEqual(e.projections[0]['callerContext'],list(HISTORICAL));self.assertEqual(e.projections[0]['classModel'],[2,1]);self.assertEqual(e.observed(sp+24,4)['value'],7)
  self.assertEqual([r['sequence'] for r in e.frames],[2080,2090]);self.assertEqual(e.frames[1]['parent'],2080)
 def test_historical_fixture_is_rejected_by_frozen_regressed_guard(self):
  e,sp,ptr=self.make(historical=True)
  with self.assertRaisesRegex(previous.b.Blocked,'exact admitted class/model/caller'):previous.Ledger.texture_projection(e)
  self.assertFalse(e.invalidation_events);self.assertFalse(e.projections)
 def test_historical_projection_footprint_preserves_run03_implementation(self):
  e,sp,ptr=self.make(historical=True);old,_,_=self.make(historical=True);e.texture_projection();original.Ledger.texture_projection(old)
  self.assertEqual(e.invalidation_events,old.invalidation_events);self.assertEqual(e.register_snapshot(),old.register_snapshot())
  new=dict(e.projections[0]);new.pop('classModel');new.pop('callerContext');self.assertEqual(new,old.projections[0])
 def test_each_literal_positive_is_independent_of_allowlist_mutation(self):
  with patch.object(l,'ADDITIONAL_TEXTURE_CONTEXTS',{}):
   e,sp,ptr=self.make(historical=True)
   with self.assertRaisesRegex(b.Blocked,'exact admitted class/model/caller'):e.texture_projection()
  for kind,context in EXPECTED[1:]:
   with patch.dict(l.TEXTURE_CONTEXTS,{kind:('bad',)*5}):
    e,sp,ptr=self.make(kind,context)
    with self.assertRaisesRegex(b.Blocked,'exact admitted class/model/caller'):e.texture_projection()
 def test_every_tuple_field_near_miss_rejects_before_taint(self):
  for kind,context in EXPECTED:
   for frame,key,val in [(0,'caller','0x404be7'),(0,'return',1),(0,'target','0x403a01'),(1,'caller','0x403bf4'),(1,'return',1),(1,'target','0x4bdd41'),(1,'returnSp',1)]:
    e,sp,ptr=self.make(kind,context);e.frames[frame][key]=val
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events);self.assertFalse(e.projections)
 def test_unjustified_model18_historical_caller_and_wrong_models_reject(self):
  for kind in [(2,18),(2,13),(5,2),(1,1)]:
   e,sp,ptr=self.make(kind,HISTORICAL)
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_all_literal_contexts_use_actual_object_instead_of_origin_record(self):
  for kind,context in EXPECTED:
   e,sp,ptr=self.make(kind,context);e.current_record={'record':99,'class':1,'model':7};e.record=99;e.texture_projection();self.assertEqual(e.projections[0]['classModel'],list(kind));self.assertEqual(e.projections[0]['object'],hex(ptr))
 def test_every_context_retains_unknown_argument_frame_geometry_guards(self):
  for kind,context in EXPECTED:
   for field in ['object-pointer','class','model','esp','coords','radius','width']:
    e,sp,ptr=self.make(kind,context)
    if field=='esp':e.shadow.reg_put('esp',b.MASK32^1)
    else:
     a,n={'object-pointer':(e.frames[0]['returnSp'],4),'class':(ptr+0x2a,1),'model':(ptr+0x2b,1),'coords':(sp+36,2),'radius':(sp+40,2),'width':(sp+24,4)}[field];e.shadow.put(a,n,((1<<(8*n))-1)^1)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
 def test_every_context_retains_opaque_pointer_and_mode_guards(self):
  for kind,context in EXPECTED:
   for address in l.OPAQUE_POINTERS+(0x5d45a8,):
    e,sp,ptr=self.make(kind,context)
    if address==0x5d45a8:e.shadow.put(address,1,0)
    else:e.shadow.put(address,4,1)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
 def test_historical_wrong_geometry_rejects_before_taint(self):
  for a,n,val in [(0x23ecbf0,4,8),(0x23ecc00,2,0),(0x23ecc00,2,129)]:
   e,sp,ptr=self.make(historical=True);e.supply(a,l.pack(val,n),'authored wrong geometry')
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_all_radius_endpoints_remain_source_bounded(self):
  for kind,context in EXPECTED:
   for radius in ([1,128] if kind[0]==2 else [0,127]):
    e,sp,ptr=self.make(kind,context,radius);e.texture_projection();self.assert_footprint(e,sp)
 def test_later_decisive_unknown_output_read_remains_blocked(self):
  e,sp,ptr=self.make(historical=True);e.texture_projection();e.frames=[];code=b.SCRATCH;e.cpu.mem_write(code,bytes.fromhex('803d18c39b0000'));e.windows.append((code,code+7))
  with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'):e.run(code,code+7)
  self.assertEqual(e.committed,0)
 def test_only_one_literal_context_added_to_production(self):
  actual=list(l.TEXTURE_CONTEXTS.items())+list(l.ADDITIONAL_TEXTURE_CONTEXTS.items());self.assertEqual(set(actual),set(EXPECTED));self.assertEqual(l.TEXTURE_CONTEXTS,previous.TEXTURE_CONTEXTS)
 def test_all_execution_windows_conditions_and_resource_caps_unchanged(self):
  self.assertEqual(l.ranges(),previous.ranges());self.assertEqual(l.entry_conditions('land-clear'),previous.entry_conditions('land-clear'))
  for name in ['TRACE_LIMIT','FINAL_JSON_LIMIT','FINAL_COMPRESSED_LIMIT','OTHER_OUTPUT_ALLOWANCE','SPACE_MARGIN','REQUIRED_FREE','ENTRY','NEXT','FINAL']:self.assertEqual(getattr(l,name),getattr(previous,name))
 def test_frozen_budget_driver_unchanged(self):self.assertEqual(hashlib.sha256((l.HERE/'constructor_ledger_budget_candidate.py').read_bytes()).hexdigest(),'86a296a3df0385cfb5487e92fdeedba2002ee58f2fb22601e8c961bdc1518cb2')
if __name__=='__main__':unittest.main()
