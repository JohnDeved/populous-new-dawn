# Correction: animation budget dispatch in runs05 and06

The frozen budget-only repair86a296a3 changed `Ledger.cut` to select300seconds for the animation range, and declared300seconds in preflight. The actual `setup()` path does not call that helper for animation: it invokes `e.run(0042c4b6,0042c5ee,...timeout_us=240000000)` directly.

Consequently, the original instructions in runs05 and06 still used the240-second animation cap. Both passed the animation phase at the same2,344,732 total committed instructions as prior completed runs. Their progress cannot be attributed to an increased animation budget. Historical manifest/declaration fields saying300seconds describe an ineffective attempted change, not the actual dispatch.

The original run04 timeout and all raw run04–06 receipts remain intact. This correction changes neither their executed instruction counts nor terminal status. It invalidates any claim that runs05/06 demonstrated recovery under a300-second animation allowance. No timing-cause or comparative performance claim follows.

The new unfrozen operand candidate changes the actual setup call to300seconds. Its regression calls the real `setup()` with a host-only recorder and stops at the first run dispatch, after verifying the three genuine preceding root selections. The same fixture exposes240seconds in frozen6efb7128. This correction requires a fresh review and separate release before any original retry.

Independent findings are retained in `../review-boundary/constructor-ledger-run06-stop-review.json` and `../review-boundary/test_animation_setup_dispatch.py`. Their original files remain unchanged.
