"""Independent finite source-map checks; no canonical CPU dispatch."""
from pathlib import Path
import hashlib,json,struct,sys,collections
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';sys.path.insert(0,str(H))
import constructor_ledger_context_candidate as q
import capstone
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();p=H/'constructor-capability-audit01.json';assert sha(p)=='4dcc446986477e5aec4cd8fe810cabe54ec9206892f0dfc3702cf306c70c8f84';j=json.loads(p.read_text());pe=q.b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;rows={}
for w in j['windows']:
 a,z=int(w['start'],16),int(w['endExclusive'],16);raw=pe.read(a,z-a);assert hashlib.sha256(raw).hexdigest()==w['sha256'];ii=list(cs.disasm(raw,a));assert sum(i.size for i in ii)==len(raw);rows.update({i.address:i for i in ii})
assert len(rows)==9332 and len(j['windows'])==91;assert collections.Counter(i.mnemonic for i in rows.values())==j['mnemonics']
seen=[];x=capstone.x86
for group in j['operandFormGroups']:
 for pc in group['pcs']:
  i=rows[int(pc,16)];seen.append(i.address);assert i.mnemonic==group['mnemonic'];assert list(i.prefix)==group['prefixes'];assert [{'type':{x.X86_OP_REG:'register',x.X86_OP_MEM:'memory',x.X86_OP_IMM:'immediate'}[o.type],'bytes':o.size} for o in i.operands]==group['operandForms']
assert len(seen)==len(set(seen))==len(rows)
for e in j['directControlEdges']:
 i=rows[int(e['pc'],16)];t=int(e['target'],16);assert i.mnemonic==e['kind'] and i.operands[0].type==x.X86_OP_IMM and i.operands[0].imm==t;assert e['instructionBoundary']==(t in rows);assert e['admitted']==any(a<=t<z for a,z in q.ranges())
assert sum(not e['admitted'] for e in j['directControlEdges'])==181
for t in j['dispatchTables']:
 a=int(t['base'],16);raw=pe.read(a,4*t['count']);assert hashlib.sha256(raw).hexdigest()==t['sha256'];assert [hex(v) for v in struct.unpack('<'+'I'*t['count'],raw)]==t['targets'];assert all(int(v,16) in rows for v in t['targets'])
for w in j['sourceCountAndGapWindows']:
 a,z=int(w['start'],16),int(w['endExclusive'],16);raw=pe.read(a,z-a);assert hashlib.sha256(raw).hexdigest()==w['sha256'];assert [{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in cs.disasm(raw,a)]==w['instructions']
assert [(e['pc'],e['bytes']) for e in j['unsupportedInstructionForms']]==[('0x404153','f77c243c'),('0x422de5','0f9ec0')]
result={'verdict':'ACCEPT_FINITE_SOURCE_CAPABILITY_INVENTORY_NOT_EXECUTION_ADMISSION','inputSha256':sha(p),'originalInstructionsExecuted':0,'independentCanonicalChecks':{'windows':91,'instructions':9332,'operandGroups':160,'directCallJumpEdges':len(j['directControlEdges']),'nonadmittedDirectEdges':181,'dispatchTables':19,'exactCountAndGapWindows':5},'gaps':[{'pc':'00404153','form':'IDIV DWORD memory','observed':'run06 rejected operand form before native IDIV'},{'pc':'00422de5','form':'SETLE AL','observed':'static only; no execution/reachability claim'}],'limits':['The two listed form gaps agree with frozen planner cases, but input/flag/address guards, native faults and unadmitted targets still apply. No guarantee of completion or exhaustive whole-program reachability.','Do not treat direct-model exclusions as nested-call closure. All181 outside direct edges remain real residual boundaries.','All three CL supplier slices bound0..7 under actual executed predecessors; no new shift semantics needed. Runtime unknownness remains guarded.','Future candidate requires independent memory-IDIV/SETLE flag/fault tests and actual setup dispatcher budget regression.'],'verifierSha256':sha(Path(__file__))}
(R/'constructor-capability-source-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS_SOURCE_ONLY','sha256':sha(R/'constructor-capability-source-review.json')}))
