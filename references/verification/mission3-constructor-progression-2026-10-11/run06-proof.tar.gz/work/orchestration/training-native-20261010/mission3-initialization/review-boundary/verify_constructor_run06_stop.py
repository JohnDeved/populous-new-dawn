"""File-only limited semantic-form stop and prior guard-success review."""
from pathlib import Path
import gzip,hashlib,json
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';ROOT=next(p for p in H.parents if (p/'GOAL.md').exists())
def sha(p):
 h=hashlib.sha256();n=0
 with Path(p).open('rb') as f:
  while c:=f.read(1024*1024):h.update(c);n+=len(c)
 return n,h.hexdigest()
def prefix(p):
 a=[]
 with gzip.open(p,'rt') as f:
  for line in f:
   if line.startswith('  "memoryReads":'):break
   a.append(line)
 return json.loads(''.join(a).rstrip().rstrip(',')+'\n}')
p=H/'constructor-ledger-clear-run06-process-receipt.json';assert sha(p)[1]=='aa70ad7edb9d2458d1d9a8244f2ca1cde51e5518977ba3e5b7e2300336007dfa';z=json.loads(p.read_text());assert z['status']=='terminal' and z['exitCode']==2 and z['driversBefore']==z['driversAfter'] and len(z['driversAfter'])==10
for n,s in z['driversAfter'].items():assert sha(H/n)[1]==s
for f in z['artifacts']+[z['wrapper'],z['approval']]:
 q=Path(f['path']);q=q if q.is_absolute() else ROOT/q;assert sha(q)==(f['bytes'],f['sha256'])
held=json.loads((R/'constructor-ledger-context-held-approval.json').read_text());held['parentReleasedRunLane']=True;a=json.loads((ROOT/z['approval']['path']).read_text());assert all(a.get(k)==v for k,v in held.items())
out=H/'constructor-ledger-clear-run06';sr=json.loads((out/'constructor-ledger-result-stream-receipt.json').read_text());h=hashlib.sha256();size=0
with gzip.open(out/'constructor-ledger-result.json.gz','rb') as f:
 while c:=f.read(1024*1024):h.update(c);size+=len(c)
assert (size,h.hexdigest())==(sr['uncompressedBytes'],sr['uncompressedSha256'])
v=prefix(out/'constructor-ledger-result.json.gz');assert not v['complete'] and v['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP';assert (v['attemptedOriginalInstructions'],v['committedOriginalInstructions'])==(4076210,4076209)
assert v['blocker']['pc']=='0x404153' and v['blocker']['reason']=='only 32-bit register divisor admitted';assert v['abortedInstructions']==[{'pc':'0x404153','instruction':'idiv dword ptr [esp + 0x3c]','bytes':'f77c243c','status':'not-committed','attemptedWrites':[]}]
assert not v['returnedAllocations'] and len(v['records'])==1 and v['records'][0]['status']=='entered' and len(v['openCalls'])==5 and v['selectedAssertions']['completedRecords']==0
contexts=[['0x403a00','0x404be6',0x404beb,'0x403bf3',0x403bf8],['0x403a00','0x4036e1',0x4036e6,'0x403bf3',0x403bf8]]
assert [x['callerContext'] for x in v['projections']]==contexts;assert all(x['classModel']==[2,1] and x['start']=='0x4bdebe' and x['endExclusive']=='0x4bdfdb' for x in v['projections'])
fixture=json.loads((R/'constructor-texture-independent-fixture.json').read_text());assert v['projections'][0]['entryRegisters']==fixture['run03Projection']['entryRegisters']
rows=0;inv=[];cmp=[];rejected=[]
with gzip.open(out/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  rows+=1
  if b'"pc":"0x4bdebe"' in line:
   e=json.loads(line);assert e['kind']=='invalidation';inv.append(e)
  if b'"pc":"0x404153"' in line:rejected.append(json.loads(line))
  if b'"pc":"0x40414b"' in line:cmp.append(json.loads(line))
assert len(inv)==24 and not rejected
for start in [0,12]:
 group=inv[start:start+12];assert [e['eventOrdinal'] for e in group]==list(range(group[0]['eventOrdinal'],group[0]['eventOrdinal']+12))
assert len(cmp)==1 and cmp[0]['kind']=='read' and cmp[0]['size']==4 and cmp[0]['knownMask']=='0xffffffff';assert cmp[0]['address']==hex(int(v['finalRegisters']['esp']['value'],16)+0x3c)
report={'verdict':'ACCEPT_LIMITED_IDIV_FORM_STOP_AND_GUARD_RESTORATION','originalInstructionsExecutedByReviewer':0,'processSha256':sha(p)[1],'resultGzipSha256':sr['sha256'],'expandedSha256':sr['uncompressedSha256'],'expandedBytes':size,'eventGzipSha256':sha(out/'constructor-ledger-events.jsonl.gz')[1],'allTenFrozenHashesStable':True,'releasedApprovalSha256':z['approval']['sha256'],'status':v['status'],'attemptedOriginalInstructions':v['attemptedOriginalInstructions'],'committedOriginalInstructions':v['committedOriginalInstructions'],'complete':False,'blocker':v['blocker'],'abortedInstruction':v['abortedInstructions'][0],'stopTransaction':{'memoryReadWriteEventsAtRejectedPc':0,'attemptedWriteJournal':[],'eax':v['finalRegisters']['eax'],'edx':v['finalRegisters']['edx'],'priorDivisorCmpRead':cmp[0],'classification':'Engine rejects DWORD memory divisor form before native IDIV; this is not evidence of divide-by-zero, quotient overflow or an unknown operand.'},'restoredGuardBehavior':{'actualContexts':contexts,'projectionCount':2,'firstProjectionEntryEqualsRun03':True,'exact12InvalidationsPerProjection':True,'projectionInvalidationDescriptorsChecked':24,'rawRowsScannedForScopedChecks':rows},'partialLedger':{'returnedAllocations':0,'completedRecords':0,'enteredRecords':1,'openCalls':5,'counterCopies':v['counterCopies'],'counterIncrements':v['counterIncrements']},'budgetCorrection':{'path':'constructor-review-corrections-publication-addendum.json','sha256':sha(R/'constructor-review-corrections-publication-addendum.json'),'actualAnimationSeconds':240,'declaredButUnusedAnimationSeconds':300},'limits':['Checked terminal identities, expanded result hash/length, metadata/call/projection prefix and scoped event descriptors. No full ordered mask replay or independent CPU/value reconstruction.','No returned allocation or final class1 count. Conditional model terrain, selected-state history and opaque texture conditions still apply.','A memory-divisor extension must prove known effective address/divisor/EDX:EAX, undefined flags, divide-error rollback and actual setup timeout dispatch with independent tests; fresh hash gate and parent release remain required.'],'verifierSha256':sha(Path(__file__))[1]}
(R/'constructor-ledger-run06-stop-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS_LIMITED_STOP_REVIEW','reviewSha256':sha(R/'constructor-ledger-run06-stop-review.json')[1],'rowsScanned':rows,'originalInstructionsExecuted':0}))
