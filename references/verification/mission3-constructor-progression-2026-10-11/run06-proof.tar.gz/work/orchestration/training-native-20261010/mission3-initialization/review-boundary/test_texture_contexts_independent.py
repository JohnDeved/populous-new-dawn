"""Independent literal-context regression; only authored synthetic memory/CPU."""
from pathlib import Path
import hashlib,importlib,json,sys,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R.parent/'harness-repair'))
MODULE=sys.argv.pop(1) if len(sys.argv)>1 and not sys.argv[1].startswith('-') else 'constructor_ledger_budget_candidate'
q=importlib.import_module(MODULE);b=q.b
import unicorn
p=R/'constructor-texture-independent-fixture.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='0a6dce0aae2241b574ae5eb98a6bd9ff22a26d03d95e4c0c476fc9e02de42c73'
F=json.loads(p.read_text());EXPECTED=F['expectedContexts']
class IndependentContextTests(unittest.TestCase):
 def make(self,row,radius=None):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  e=q.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(0x4bdebe,0x4bdfdb+5)],protected_inputs=[],enable_texture_projection=True)
  # Absolute frame positions come from retained run03 calls, not production constants/table.
  sp=0x23ecbd8;parent_sp=0x23ecc38;ptr=0x8fc2f5;t=row['context'];radius=3 if radius is None else radius
  e.phase='authored-record-loop';e.record=999;e.origin={'deliberatelyDifferent':'nested object is authoritative'}
  e.frames=[{'target':t[0],'caller':t[1],'return':t[2],'returnSp':parent_sp},{'target':'0x4bdd40','caller':t[3],'return':t[4],'returnSp':0x23ecbfc}]
  for name,r in F['run03Projection']['entryRegisters'].items():e.reg_supply(name,int(r['value'],16),int(r['knownMask'],16),'synthetic fixture register')
  for a,raw in [(sp-156,bytes(204)),(0x5d45a8,b'\x03'),(parent_sp,q.pack(ptr)),(ptr+42,bytes([row['class'],row['model']])),(sp+24,q.pack(2*radius+1)),(sp+36,q.pack(0x9624,2)),(sp+40,q.pack(radius,2)),(0x9bc318,bytes(1024))]:e.supply(a,raw,'independent synthetic fixture')
  return e,sp,ptr
 def test_all_literal_contexts_including_actual_run03(self):
  for row in EXPECTED:
   e,sp,ptr=self.make(row);e.texture_projection();self.assertEqual(len(e.projections),1);self.assertEqual(e.projections[0]['object'],hex(ptr));self.assertEqual(e.projections[0]['classModel'],[row['class'],row['model']]);self.assertEqual(e.projections[0]['callerContext'],row['context']);self.assertEqual(e.reg_value('eip'),0x4bdfdb)
 def test_exact_footprint_for_every_literal_context(self):
  for row in EXPECTED:
   e,sp,ptr=self.make(row);e.texture_projection()
   self.assertEqual(len(e.invalidation_events),12);self.assertEqual(e.shadow.get(sp-156,156),0);self.assertEqual(e.shadow.get(sp+16,6),0);self.assertEqual(e.shadow.get(sp+28,4),0);self.assertEqual(e.shadow.get(0x9bc318,1024),0)
   self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertEqual(e.observed(sp+24,4)['value'],7);self.assertEqual(e.reg_value('esp'),sp)
   for reg in ['eax','ebx','ecx','edx','esi','edi','ebp']:self.assertEqual(e.shadow.reg_get(reg),0)
   self.assertFalse(e.shadow.reg['eflags']&b.ARITH);self.assertFalse(e.events);self.assertFalse(e.write_events);self.assertEqual(e.committed,0)
 def test_each_call_tuple_component_is_required(self):
  for row in EXPECTED:
   for f,key,val in [(0,'target','0x1'),(0,'caller','0x1'),(0,'return',1),(1,'target','0x1'),(1,'caller','0x1'),(1,'return',1),(1,'returnSp',1)]:
    e,sp,ptr=self.make(row);e.frames[f][key]=val
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.projections);self.assertFalse(e.invalidation_events)
 def test_no_unproved_new_model18_or_unlisted_classmodels(self):
  for row,kind in [(EXPECTED[0],(2,18)),(EXPECTED[0],(2,2)),(EXPECTED[3],(5,10)),(EXPECTED[3],(2,1))]:
   e,sp,ptr=self.make(row);e.supply(ptr+42,bytes(kind),'synthetic wrong classmodel')
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_unknown_pointer_or_classmodel_never_taints(self):
  for row in EXPECTED:
   for a,n in [(0x23ecc38,4),(0x8fc2f5+42,1),(0x8fc2f5+43,1)]:
    e,sp,ptr=self.make(row);e.shadow.put(a,n,0)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
 def test_opaque_alias_conditions_unchanged(self):
  for row in EXPECTED:
   for a in [0x9bcfc8,0x9bcfd8,0x5d45b0]:
    e,sp,ptr=self.make(row);e.shadow.put(a,4,1)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
 def test_literal_geometry_bounds_and_unknown_width(self):
  for row in EXPECTED:
   bad=[0,129] if row['class']==2 else [128]
   for radius in bad:
    e,sp,ptr=self.make(row,radius)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
   e,sp,ptr=self.make(row);e.shadow.put(sp+24,4,0)
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_scenery_zero_radius_retains_exact_width(self):
  for row in EXPECTED[3:]:
   e,sp,ptr=self.make(row,0);e.texture_projection();self.assertEqual(e.observed(sp+24,4)['value'],1)
if __name__=='__main__':unittest.main()
