# Conditional StageA finite call-closure delta after run03

This separate candidate preserves run03 driver61c7 and its reviewed partial result. No new original execution is admitted by this document. It retains the same single land-clear/class-seed0 condition, genuine20×100 transport ordering, source-relative setup, partial-allocation distinction, resources and stop00485050 before the global postload pass.

## Finite source closure

Inventory02 binds73 complete windows,468 direct FLOW rows and19 indirect dispatch tables/remaps against the canonical EXE. It records indexed/global operands, executable tail targets and local direct-model dispatch exclusions. Those exclusions are scoped to the explicit selector at that local dispatch. They do not exclude later state changes or different nested classes/models. All residual targets and decisive unknown operands still abort.

Twenty source-bound integer helper bodies are added, covering the first-hut population/list/height leaves, actual person animation tail, scenery state/wood/shadow/height/job paths, class6 position paths, class7/model23 setup, and scenery-triggered walk-mask updates. Admission of a body does not admit its residual callees. The body/call/dispatch inventory is a finite safety map, not a complete constructor-reachability proof.

Notable residuals are real queue flush0044df40, job helper004503f0, neighbor damage00409200/004ba410, nondefault person command/state paths and position helper004047b0/00518200. Initial empty job/terrain/pool state cannot exclude these after earlier records mutate it. Model9 is authored record103, and record102 shares its authored coordinates; its actual neighbor scan is retained. Nested allocations retain their actual class/model and all guards.

## Two added entry conditions

- WORD0089c6dd=3 at the first selected kernel. Original globe producer0048596b stores the selected level argument; person consumer004d5a11 compares12. The value and omitted-history lifetime are explicitly conditioned.
- DWORD0089d188=0 at the first selected kernel. Reset0042bfa7 establishes EBX0 and0042bfdc stores it, also present in the accepted conditional projected-reset evidence. Model9's real004a5fed comparison and004a5ff9 neighbor call are retained.

Every selected setup checkpoint asserts both values still known and unchanged. No later reseed or reset is inserted. The person animation tail's004d426b test consumes existing0089d17c mask02-clear; no extra00895da8 or whole-byte supply is introduced. Other unbound fields remain unknown.

## Texture projection contexts

The previously reviewed omission remains exactly004bdebe..004bdfdb, with the same dirty-grid, scratch-stack, all-GPR-exceptESP and arithmetic-flag taint. The genuine brightness loop, final004206d0 dirty OR and epilogue remain native. Valid live disjoint opaque resources and normal completion remain explicit conditions; their pointers/backing remain unknown.

The affected object is read from the actual enclosing helper's first argument at its recorded pre-CALL ESP. It is never taken from the originating authored record, which can differ during nested allocation. All complete caller tuples and object class/model are checked:

- Class2 models1/18: enclosing004036e1→00403a00, return004036e6; texture00403bf3→004bdd40, return00403bf8.
- Class5 models2/3/6/9: enclosing004a68b6→00403c10, return004a68bb; texture00403d3c→004bdd40, return00403d41.

The real source derives radius from unsigned byte shape dimensions: buildings use max(floor(x/2),floor(y/2))+1, range1..128; scenery omits the+1, range0..127. Width2*radius+1 and both consumed WORD arguments must be known, native ESP must equal the recorded texture pre-CALL ESP−36, and opaque pointer masks must remain zero. Unsupported class/model, caller, frame or geometry stops before any taint. Source-only addendum binds all these sites. No new omitted range or native return is invented.

## Integer and receipt delta

New helper code uses CL-count shifts. The new engine permits a fully known CL count with the existing finite1/2/4-byte destinations and conservative flags. Count is masked31; zero preserves the destination and flags, counts at or above destination width reject, and nonzero counts require known destination. ROR only defines OF for count1 and preserves unrelated flags. UnknownCL, unsupported prefixes, faulted writes and decisive undefined-flag consumption fail closed. No other integer semantics change.

Supplies retain their phase/order insertion cursors. Native reads, committed writes and invalidations retain contiguous shared observer ordinals. Compressed result/raw trace and before/after hash receipts retain the unchanged storage and process limits. Failed synthetic bring-up logs are kept beside the final passing receipt. The exact inventory01 generator was recovered separately with its original SHA256; inventory02 and its generator remain separately retained.
