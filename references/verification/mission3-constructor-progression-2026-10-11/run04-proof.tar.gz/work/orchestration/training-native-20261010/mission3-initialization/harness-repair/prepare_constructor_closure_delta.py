#!/usr/bin/env python3
"""Source-only closure input and texture-context addendum; never creates a CPU."""
from pathlib import Path
import hashlib,json
import capstone
import constructor_ledger_inputs_candidate as old
H=Path(__file__).resolve().parent;O=H/'constructor-call-closure-source';b=old.b

def main():
 p=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;checks=[];windows=[]
 inv=O/'call-inventory02.json';assert b.sha(inv.read_bytes())=='7302d10ec951d57225f8fd0a070732bf7e00bebbb7a8472fc359314816997504'
 def check(n,v):
  assert v,n
  checks.append({'name':n,'passed':True})
 def window(name,a,z):
  raw=p.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' complete bytes',sum(i.size for i in ii)==len(raw));windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]});return ii
 for name,a,z in [('reset zero source',0x42bfa0,0x42bfe2),('level selection producer',0x4858f0,0x485972),('level consumer',0x4d5a11,0x4d5a23),('model9 startup predicate',0x4a5fed,0x4a6006),('building enclosing call',0x4036d5,0x4036f5),('scenery enclosing call',0x4a68a1,0x4a68bb),('building radius and real call',0x403bc1,0x403c03),('scenery radius and real call',0x403d14,0x403d4c),('texture own frame/width',0x4bdd40,0x4bdd7d),('existing game bit guard',0x4d426b,0x4d4297)]:window(name,a,z)
 def exact(a,raw):check(hex(a)+' exact bytes',p.read(a,len(bytes.fromhex(raw)))==bytes.fromhex(raw))
 for a,raw in [(0x42bfa7,'33db'),(0x42bfdc,'891d88d18900'),(0x48596b,'668935ddc68900'),(0x4d5a11,'66833dddc689000c'),(0x4a5fed,'833d88d1890002'),(0x4036e1,'e81a030000'),(0x4a68b6,'e855d3f5ff'),(0x403bf3,'e848a10b00'),(0x403d3c,'e8ff9f0b00'),(0x4d426b,'f6057cd1890002')]:exact(a,raw)
 # Bounds are from unsigned one-byte shape dimensions, not captured render output.
 check('building radius1..128',min(max(a//2,c//2)+1 for a in range(256) for c in range(256))==1 and max(max(a//2,c//2)+1 for a in range(256) for c in range(256))==128)
 check('scenery radius0..127',min(max(a//2,c//2) for a in range(256) for c in range(256))==0 and max(max(a//2,c//2) for a in range(256) for c in range(256))==127)
 # Source body: SUB ESP,16 + PUSH four nonvolatiles, in addition to CALL return4.
 check('exact native projection ESP offset',4+16+4*4==36)
 z={'status':'SOURCE_ONLY_NO_NATIVE_EXECUTION','driver':b.file_record(Path(__file__)),'inventory':b.file_record(inv),'assertions':checks,'windows':windows,'newConditions':[{'address':'0x89c6dd','size':2,'value':3,'source':'selected Mission3 argument SI stored0048596b','entry':'first selected kernel','lifetime':'explicit unchanged condition across omitted history; every selected setup checkpoint must preserve; never reseed later'},{'address':'0x89d188','size':4,'value':0,'source':'reset EBX zero→0042bfdc, supported by separately accepted conditional projected-reset trace','entry':'first selected kernel','lifetime':'same explicit preservation condition; real model9 test and neighbor effects remain active'}],'unchangedBitCondition':{'address':'0x89d17c','mask':'0x02','value':0,'consumer':'004d426b','note':'Existing source-bound later-loader condition. No extra00895da8 or whole-byte supply.'},'contextObject':'Read object pointer at parent pre-CALL ESP, the actual enclosing helper first argument; class/model come from that object, never originRecord. Guard complete enclosing and texture call triples.','radius':{'class2':[1,128],'class5':[0,127],'width':'2*radius+1 genuinely produced before omitted loop'},'projectionLimits':'Only existing004bdebe..004bdfdb source footprint under valid/live/disjoint opaque resources and normal completion. Same stack/dirty-grid/GPR/flags taint; all preceding brightness and following dirty OR remain genuine.','residuals':['004a9030 neighbor damage00409200/004ba410 and state transitions are real and unclosed; preceding records can populate neighbors.','0044ddf0 queue flush0044df40 can activate after earlier writes; initial queue0 is not permanent exclusion.','00494f50 job helper004503f0 can activate after real job mutations; initial count0 is not permanent exclusion.','Nondefault person/other states and nested classes/models retain actual guarded branches and unsupported targets.','Animation tails, tree proximity flags, opaque resources and other unsupplied inputs remain unknown.']}
 out=O/'closure-delta-source-contract.json';out.write_text(json.dumps(z,indent=2)+'\n');print(json.dumps({'file':str(out),'sha256':b.sha(out.read_bytes()),'checks':len(checks),'windows':len(windows),'native':0}))
if __name__=='__main__':main()
