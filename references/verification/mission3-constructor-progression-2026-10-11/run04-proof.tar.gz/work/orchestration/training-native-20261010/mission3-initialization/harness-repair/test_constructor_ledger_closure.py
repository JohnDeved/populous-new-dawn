"""Host and authored synthetic x86 only. Never runs canonical instructions."""
from pathlib import Path
import hashlib,json,tempfile,unittest
from unittest.mock import patch
import unicorn
from unicorn import x86_const as x
import constructor_ledger_closure_candidate as l
b=l.b;CODE,DATA,STACK,STOP=0x100000,0x200000,0x300800,0x300f00
class KnownClTests(unittest.TestCase):
 def make(self,raw,value=0x81234567,count=1,mask=b.MASK32):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
  for a in [CODE,DATA,0x300000]:c.mem_map(a,4096)
  c.mem_write(CODE,bytes.fromhex(raw)+b'\xc3');e=l.Ledger(c,[(CODE,4096),(DATA,4096),(0x300000,4096)],[(CODE,CODE+len(bytes.fromhex(raw))+1)],protected_inputs=[])
  for r,v,m in [('esp',STACK,b.MASK32),('eax',value,mask),('ecx',count,b.MASK32),('eflags',2|b.CF|b.OF,b.MASK32)]:e.reg_supply(r,v,m,'synthetic')
  e.supply(STACK,l.pack(STOP),'synthetic stop');return e
 def test_known_cl_shift_forms(self):
  for code,val,n,want in [('d3e0',3,2,12),('d3e8',0x81234567,4,0x08123456),('d3f8',0x81234567,4,0xf8123456),('66d3e0',0xabcd0123,3,0xabcd0918),('d2e0',0x12345603,2,0x1234560c)]:
   e=self.make(code,val,n);e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),want);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.CF|b.PF|b.ZF|b.SF)
 def test_count_one_defines_of_but_not_af(self):
  e=self.make('d3e0',0x80000000,1);e.run(CODE,STOP);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ARITH&~b.AF);self.assertTrue(e.reg_value('eflags')&b.OF)
 def test_ror_changes_only_cf_of_masks(self):
  for n in [1,2,13]:
   e=self.make('d3c8',0x81234567,n);old=e.reg_value('eflags');e.run(CODE,STOP);self.assertEqual(e.shadow.reg['eflags']&b.ARITH,b.ARITH if n==1 else b.ARITH&~b.OF);self.assertEqual(e.reg_value('eflags')&(b.SF|b.ZF|b.AF|b.PF),old&(b.SF|b.ZF|b.AF|b.PF))
 def test_zero_or_masked_zero_count_preserves_unknown_dest_and_flags(self):
  for n in [0,32,64,224]:
   for code in ['d3e0','66d3e0','d2c8']:
    e=self.make(code,0x81234567,n,0x00ff00ff);e.shadow.reg['eflags']=b.DF|b.CF;e.run(CODE,STOP);self.assertEqual(e.reg_value('eax'),0x81234567);self.assertEqual(e.shadow.reg_get('eax'),0x00ff00ff);self.assertEqual(e.shadow.reg['eflags'],b.DF|b.CF)
 def test_unknown_cl_rejected_before_execution(self):
  for mask in [0,0x0f,0x7f]:
   e=self.make('d3e0');e.shadow.reg_put('cl',mask)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0);self.assertFalse(e.write_events)
 def test_unknown_destination_nonzero_count_rejected(self):
  e=self.make('d3e0',3,2,0)
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  self.assertEqual(e.committed,0)
 def test_unsupported_width_counts_and_prefixes_rejected(self):
  for raw,n in [('d2c8',8),('d2c8',9),('66d3c8',16),('66d3c8',17),('66d3e0',16),('67d3e0',1),('f0d3e0',1)]:
   e=self.make(raw,count=n)
   with self.assertRaises(b.Blocked):e.run(CODE,STOP)
   self.assertEqual(e.committed,0)
 def test_undefined_of_cannot_drive_branch(self):
  e=self.make('d3c87000',count=2)
  with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(CODE,STOP)
  self.assertEqual(e.committed,1)
 def test_memory_cl_shift_records_real_read_committed_write_order(self):
  e=self.make('d32500002000',count=2);e.supply(DATA,l.pack(3),'synthetic');e.run(CODE,STOP);self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),l.pack(12));rows=sorted(e.read_events+e.write_events,key=lambda r:r['eventOrdinal']);self.assertEqual([r['eventOrdinal'] for r in rows],list(range(len(rows))));self.assertEqual(rows[0]['address'],hex(DATA));self.assertTrue(all(r.get('committed') for r in rows[1:5]))
 def test_memory_fault_commits_no_attempted_shift_write(self):
  e=self.make('d32500002000',count=2);e.supply(DATA,l.pack(3),'synthetic');e.cpu.mem_protect(DATA,4096,unicorn.UC_PROT_READ)
  with self.assertRaises(b.Blocked):e.run(CODE,STOP)
  self.assertEqual(bytes(e.cpu.mem_read(DATA,4)),l.pack(3));self.assertFalse(e.write_events);self.assertEqual(e.committed,0)
class ContextTests(unittest.TestCase):
 def make(self,kind=(2,1),radius=1):
  c=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32);c.mem_map(b.BASE,b.END-b.BASE);c.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
  e=l.Ledger(c,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],[(l.TEXTURE_START,l.TEXTURE_END+5)],protected_inputs=[],enable_texture_projection=True)
  e.phase='authored-record-loop';sp=l.FRAME-0x200;ptr=b.POOL+179;parent_sp=l.FRAME+0x20;t=l.TEXTURE_CONTEXTS[kind]
  e.frames=[{'target':t[0],'caller':t[1],'return':t[2],'returnSp':parent_sp},{'target':'0x4bdd40','caller':t[3],'return':t[4],'returnSp':sp+36}]
  for r,v in [('esp',sp),('eip',l.TEXTURE_START),('eflags',2)]+[(r,0x12345678) for r in ['eax','ebx','ecx','edx','esi','edi','ebp']]:e.reg_supply(r,v,b.MASK32,'synthetic')
  for a,raw in [(0x5d45a8,b'\x03'),(parent_sp,l.pack(ptr)),(ptr+0x2a,bytes(kind)),(sp-156,bytes(204)),(sp+24,l.pack(2*radius+1)),(sp+36,l.pack(0x1212,2)),(sp+40,l.pack(radius,2)),(0x9bc318,bytes(1024))]:e.supply(a,raw,'synthetic')
  return e,sp,ptr
 def test_all_six_exact_contexts_admitted(self):
  for kind in l.TEXTURE_CONTEXTS:
   e,sp,ptr=self.make(kind);e.texture_projection();self.assertEqual(e.projections[0]['classModel'],list(kind));self.assertEqual(e.reg_value('eip'),l.TEXTURE_END);self.assertEqual(e.reg_value('esp'),sp);self.assertFalse(e.events);self.assertEqual(e.committed,0)
 def test_actual_nested_object_wins_over_originating_record(self):
  e,sp,ptr=self.make((5,3));e.current_record={'record':99,'class':1,'model':7};e.record=99;e.texture_projection();self.assertEqual(e.projections[0]['classModel'],[5,3]);self.assertEqual(e.projections[0]['object'],hex(ptr))
 def test_zero_radius_only_scenery_context(self):
  for kind in l.TEXTURE_CONTEXTS:
   e,sp,ptr=self.make(kind,0)
   if kind[0]==2:
    with self.assertRaisesRegex(b.Blocked,'width/radius'):e.texture_projection()
    self.assertFalse(e.invalidation_events)
   else:e.texture_projection();self.assertEqual(e.observed(sp+24,4)['value'],1)
 def test_exact_output_footprint_equal_for_new_contexts(self):
  for kind in l.TEXTURE_CONTEXTS:
   e,sp,ptr=self.make(kind);e.texture_projection();self.assertEqual(e.shadow.get(sp-156,156),0);self.assertEqual(e.shadow.get(sp+16,6),0);self.assertEqual(e.shadow.get(sp+28,4),0);self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertEqual(e.shadow.get(sp+24,4),b.MASK32);self.assertEqual(e.shadow.get(0x9bc318,1024),0);self.assertEqual(len(e.invalidation_events),12)
   self.assertEqual([v['eventOrdinal'] for v in e.invalidation_events],list(range(12)));self.assertFalse(e.write_events)
 def test_all_parent_and_top_context_mismatches_rejected_before_taint(self):
  for kind in l.TEXTURE_CONTEXTS:
   for frame,key,val in [(0,'caller','0x1'),(0,'return',1),(0,'target','0x1'),(1,'caller','0x1'),(1,'return',1),(1,'target','0x1'),(1,'returnSp',1)]:
    e,sp,ptr=self.make(kind);e.frames[frame][key]=val
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events);self.assertFalse(e.projections)
 def test_cross_class_contexts_and_unlisted_models_rejected(self):
  for kind,bad in [((2,1),(5,3)),((5,3),(2,18)),((5,3),(5,10)),((2,18),(2,13))]:
   e,sp,ptr=self.make(kind);e.supply(ptr+0x2a,bytes(bad),'synthetic wrong model')
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.projections)
 def test_unknown_model_or_pointer_rejected_before_taint(self):
  for which in ['pointer','model']:
   e,sp,ptr=self.make((5,3));e.shadow.put(e.frames[0]['returnSp'] if which=='pointer' else ptr+0x2b,4 if which=='pointer' else 1,0)
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_known_or_partial_opaque_pointer_rejected(self):
  for addr in l.OPAQUE_POINTERS:
   for mask in [1,255,b.MASK32]:
    e,sp,ptr=self.make((5,3));e.shadow.put(addr,4,mask)
    with self.assertRaises(b.Blocked):e.texture_projection()
    self.assertFalse(e.invalidation_events)
 def test_new_context_outputs_cannot_decide_later(self):
  e,sp,ptr=self.make((5,9));e.texture_projection();e.frames=[];code=b.SCRATCH;e.cpu.mem_write(code,bytes.fromhex('803d18c39b0000'));e.windows.append((code,code+7))
  with self.assertRaisesRegex(b.Blocked,'unbound consumed operand'):e.run(code,code+7)
  self.assertEqual(e.committed,0)
 def test_width_radius_and_unknown_geometry_rejected(self):
  for radius,width,unknown in [(129,259,False),(128,257,False),(1,2,False),(1,3,True)]:
   e,sp,ptr=self.make((5,3),radius);e.supply(sp+24,l.pack(width),'synthetic wrong width')
   if unknown:e.shadow.put(sp+36,2,0)
   with self.assertRaises(b.Blocked):e.texture_projection()
   self.assertFalse(e.invalidation_events)
 def test_setup_conditions_required_and_preserved_without_reseed(self):
  e,sp,ptr=self.make();e.supply(0x89ce37,b'\0','synthetic');e.supply(0x89c6dd,l.pack(3,2),'synthetic');e.supply(0x89d188,l.pack(0),'synthetic');e.supply(0x96eac1,bytes(12),'synthetic')
  for a in [0x89d178,0x89bc72]:e.supply(a,l.pack(0x09d78afe),'synthetic')
  e.checkpoint_seeds('synthetic');self.assertEqual(e.phase_receipts[-1]['additionalConditionPreservation']['levelNumber']['value'],3)
  for address,size,val in [(0x89c6dd,2,12),(0x89d188,4,3)]:
   e.supply(address,l.pack(val,size),'synthetic altered by kernel')
   with self.assertRaisesRegex(b.Blocked,'level-number/startup counter'):e.checkpoint_seeds('synthetic')
   self.assertEqual(e.observed(address,size)['value'],val);e.supply(address,l.pack(3 if size==2 else 0,size),'synthetic restore test only')
class StaticContractTests(unittest.TestCase):
 def test_all_twenty_new_roots_covered_and_forbidden_residuals_unchanged(self):
  for root in [0x41b3f0,0x4ee580,0x44e940,0x432260,0x4044b0,0x44fad0,0x494f50,0x4a79f0,0x403c10,0x4a80b0,0x44f980,0x4a8860,0x50bcd0,0x401b10,0x404540,0x4b9fc0,0x4d3ea0,0x4d4040,0x422a60,0x422bd0]:self.assertTrue(any(a<=root<z for a,z in l.ranges()))
  for target in [0x4bee20,0x4bf1b0,0x409200,0x4ba410,0x44df40,0x42b230,0x4ec630,0x432df0,0x4047b0,0x518200,0x4503f0]:self.assertFalse(any(a<=target<z for a,z in l.ranges()))
 def test_original_inputs_driver_frozen_and_inventory_bound(self):
  self.assertEqual(hashlib.sha256((l.HERE/'constructor_ledger_inputs_candidate.py').read_bytes()).hexdigest(),l.FROZEN_INPUTS_SHA);self.assertEqual(hashlib.sha256(l.INVENTORY.read_bytes()).hexdigest(),l.INVENTORY_SHA)
 def test_no_old_camera_skips_armed(self):
  e,sp,ptr=ContextTests().make();self.assertEqual(e.skips,[])
 def test_entry_condition_descriptions_and_minimal_context_list(self):
  self.assertTrue(any('0089c6dd' in x and '0089d188' in x for x in l.entry_conditions('land-clear')));self.assertEqual(set(l.TEXTURE_CONTEXTS),{(2,1),(2,18),(5,2),(5,3),(5,6),(5,9)})
if __name__=='__main__':unittest.main()
