#!/usr/bin/env python3
"""Finite source-only FLOW/dispatch/input inventory. Never constructs a CPU."""
from pathlib import Path
import collections,hashlib,json,struct
import capstone
import constructor_ledger_inputs_candidate as l
H=Path(__file__).resolve().parent;O=H/'constructor-call-closure-source';b=l.b

def main():
 p=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
 checks=[];windows=[];roots={};flow=[];files=l.BOUND_FILES+[O/'constructor-call-bounds.tsv']
 def check(n,v):
  assert v,n
  checks.append({'name':n,'passed':True})
 def win(name,a,z):
  raw=p.read(a,z-a);ii=list(cs.disasm(raw,a));check(name+' full decode',sum(i.size for i in ii)==len(raw))
  windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ii]});return ii
 for file in files:
  for line in file.read_text().splitlines():
   r=line.split('\t')
   if r[0]=='RANGE':
    root,a,z=[int(s,16) for s in r[1:]];ii=win('root '+r[1],a,z);roots.setdefault(root,{}).update({i.address:i for i in ii})
   elif r[0]=='FLOW':flow.append({'file':str(file.relative_to(b.ROOT)),'root':r[1],'pc':r[2],'kind':r[3],'target':r[4],'ghidra':r[5]})
   elif r[0]=='MISSING':raise AssertionError(line)
 # (instruction, table,count, remap address/count). Count is independently source-bounded by preceding CMP.
 specs=[(0x4ed590,0x4ed608,11,None,0),(0x4ed64f,0x4ed6c4,11,None,0),(0x485b18,0x485db8,7,None,0),(0x485c06,0x485dd4,4,0x485de4,11),(0x4d2410,0x4d2718,8,None,0),(0x402ed0,0x403074,19,None,0),(0x4a5fc9,0x4a61bc,19,None,0),(0x4fa548,0x4fa7c4,10,None,0),(0x509c2e,0x50a59c,93,None,0),(0x403d97,0x403edc,4,None,0),(0x403e63,0x403eec,4,None,0),(0x4030e5,0x403264,6,None,0),(0x4d290b,0x4d3134,44,None,0),(0x4a6239,0x4a6444,13,None,0),(0x4a66ed,0x4a67a8,5,0x4a67bc,11),(0x4fa804,0x4fa8c0,10,None,0),(0x4042de,0x4043dc,4,None,0),(0x4a88cf,0x4a8940,4,None,0)]
 allins={pc:i for x in roots.values() for pc,i in x.items()};dispatch=[];tables={}
 for pc,base,count,remap,n in specs:
  i=allins[pc];op=i.operands[0];check(hex(pc)+' indexed4 memory JMP',i.mnemonic=='jmp' and op.type==capstone.x86.X86_OP_MEM and op.mem.disp==base and op.mem.scale==4 and not op.mem.base)
  raw=p.read(base,count*4);targets=list(struct.unpack('<'+'I'*count,raw));table={'pc':hex(pc),'base':hex(base),'count':count,'sha256':b.sha(raw),'targets':[hex(t) for t in targets],'mutability':'canonical .text immutable input, not executable admission by table membership'}
  if remap:
   rr=p.read(remap,n);check(hex(pc)+' remap target bounds',max(rr)<count);table['remap']={'base':hex(remap),'count':n,'hex':rr.hex(),'sha256':b.sha(rr)}
  dispatch.append(table);tables[pc]=targets
 indirect=[pc for pc,i in allins.items() if i.mnemonic in ('jmp','call') and i.operands[0].type!=capstone.x86.X86_OP_IMM]
 check('all retained indirect branches enumerated',set(indirect)==set(tables))
 # Local direct-model exclusion only: no interprocedural/nested reachability claim.
 selected={0x4ed590:[0,1,4,5,6],0x4ed64f:[0,1,4,5,6],0x4d2410:[0,1,6],0x402ed0:[0,17],0x4a5fc9:[1,2,5,8],0x4fa548:[1,5],0x509c2e:[22]}
 local={}
 for root,ii in roots.items():
  todo=[root];seen=set();calls=set();escapes=[]
  while todo:
   pc=todo.pop()
   if pc in seen:continue
   if pc not in ii:escapes.append(hex(pc));continue
   seen.add(pc);i=ii[pc];n=pc+i.size
   if i.mnemonic.startswith('ret'):continue
   if i.mnemonic=='call':calls.add(pc);todo.append(n);continue
   if i.mnemonic=='jmp':
    if i.operands[0].type==capstone.x86.X86_OP_IMM:todo.append(i.operands[0].imm)
    else:todo.extend(tables[pc][k] for k in selected.get(pc,range(len(tables[pc]))))
   elif i.group(capstone.CS_GRP_JUMP):todo.extend([n,i.operands[0].imm])
   else:todo.append(n)
  local[root]={'visited':seen,'calls':calls,'escapes':sorted(set(escapes))}
 for f in flow:
  root,pc,t=map(lambda x:int(x,16),(f['root'],f['pc'],f['target']));i=allins[pc]
  check('FLOW '+f['pc']+' matches canonical target',i.operands[0].type==capstone.x86.X86_OP_IMM and i.operands[0].imm==t)
  f['bytes']=i.bytes.hex();f['admission']='run03-window' if any(a<=t<z for a,z in l.ranges()) else 'unclosed'
  f['directModelScope']='locally-reachable-or-unclosed'
  if root in [0x4ed580,0x4ed640,0x4d23d0,0x402ec0,0x4a5ef0,0x4fa530,0x509c10] and pc not in local[root]['visited']:
   f['directModelScope']='excluded-by-direct-authored-dispatch-only';f['nestedScope']='unclosed; other class/model can be produced by nested allocations and must hit actual guards'
  if root==0x40c880:f['admission']='excluded-from-selected-setup-cuts';f['directModelScope']='outside-entry-seam'
  if pc in [0x4bdf96,0x4bdf9d]:f['admission']='inside-reviewed-omission-only';f['directModelScope']='exact-context-required'
  f['newFiniteSourceWindow']=any(int(r['start'],16)<=t<int(r['endExclusive'],16) for r in windows if int(r['name'].split()[-1],16) in [int(x.split('\t')[1],16) for x in (O/'constructor-call-bounds.tsv').read_text().splitlines() if x.startswith('RANGE')])
 # Mutable operands are inventory, not a blanket knownness claim. Dynamic aliases retain full instruction evidence.
 operands=[]
 for root,ii in roots.items():
  for pc,i in ii.items():
   for op in i.operands:
    if op.type==capstone.x86.X86_OP_MEM and (not op.mem.base or op.mem.disp>=0x400000):
     operands.append({'root':hex(root),'pc':hex(pc),'access':op.access,'size':op.size,'base':i.reg_name(op.mem.base),'index':i.reg_name(op.mem.index),'scale':op.mem.scale,'displacement':hex(op.mem.disp),'instruction':i.mnemonic+' '+i.op_str})
 raw=bytearray(p.read(0x5a6830,0x5aa600-0x5a6830))
 for a,x in b.constant_writes(p):
  if 0x5a6830<=a<a+len(x)<=0x5aa600:raw[a-0x5a6830:a-0x5a6830+len(x)]=x
 def data(a,n):return bytes(raw[a-0x5a6830:a-0x5a6830+n])
 descriptors={'building':[{'model':m,'address':hex(0x5a7228+m*76),'hex':data(0x5a7228+m*76,76).hex(),'flags':hex(int.from_bytes(data(0x5a7270+m*76,4),'little')),'nestedEffectWord':int.from_bytes(data(0x5a7266+m*76,2),'little')} for m in [1,18]],'person':[{'model':m,'defaultState':data(0x5a7064+m*50,1)[0],'flags':hex(data(0x5a7090+m*50,1)[0])} for m in [1,2,7]],'scenery':[{'model':m,'address':hex(0x5a79b0+m*24),'hex':data(0x5a79b0+m*24,24).hex(),'woodMax':int.from_bytes(data(0x5a79b4+m*24,2),'little'),'defaultState':data(0x5a79c1+m*24,1)[0],'flags14':hex(data(0x5a79c4+m*24,1)[0]),'flags15':hex(data(0x5a79c5+m*24,1)[0]),'flags16':hex(data(0x5a79c6+m*24,1)[0])} for m in [2,3,6,9]]}
 level=(b.GAME/'levels/levl2003.dat').read_bytes();counts=collections.Counter((level[l.LEVEL_OFFSET+i*55+1],level[l.LEVEL_OFFSET+i*55]) for i in range(2000) if level[l.LEVEL_OFFSET+i*55+1]);check('canonical109 direct records',sum(counts.values())==109)
 for name,a,z in [('level-number original producer',0x4858f0,0x4859a0),('tribe count producers',0x42b7f0,0x42b909),('person initializer level predicate',0x4d5920,0x4d59c6)]:win(name,a,z)
 result={'status':'SOURCE_ONLY_FINITE_INVENTORY_NOT_EXECUTION_ADMISSION','source':b.source_identity(),'driver':b.file_record(Path(__file__)),'frozenRun03Driver':b.file_record(H/'constructor_ledger_inputs_candidate.py'),'files':[b.file_record(x) for x in files],'executable':b.file_record(b.EXE),'originalInstructionsExecuted':0,'limits':['Local direct-model dispatch exclusions do not establish nested-allocation reachability or later state invariance.','Window admission does not prove mutable inputs known or all reachable callees supported.','All source-bound mutable table values are the existing explicit canonical seam condition plus constant.dat writes.','Later job/terrain/state mutations invalidate initial-zero exclusions; leave their real branches and guards.'], 'assertions':checks,'authoredCounts':[{'class':c,'model':m,'count':n} for (c,m),n in sorted(counts.items())],'descriptorConditions':descriptors,'dispatchTables':dispatch,'flowInventory':flow,'absoluteOrIndexedGlobalOperands':operands,'localWalks':{hex(r):{'visitedInstructionCount':len(x['visited']),'callPCs':[hex(x) for x in sorted(x['calls'])],'externalTailTargets':x['escapes']} for r,x in local.items()},'windows':windows}
 (O/'call-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'file':str(O/'call-inventory.json'),'sha256':b.sha((O/'call-inventory.json').read_bytes()),'checks':len(checks),'windows':len(windows),'flows':len(flow),'dispatches':len(dispatch),'native':0}))
if __name__=='__main__':main()
