"""Limited file-only timeout classification. No full observer/mask replay."""
from pathlib import Path
import gzip,hashlib,json,sys
R=Path(__file__).resolve().parent;H=R.parent/'harness-repair';ROOT=next(p for p in H.parents if (p/'GOAL.md').exists())
def digest(p):
 h=hashlib.sha256();n=0
 with Path(p).open('rb') as f:
  while c:=f.read(1024*1024):h.update(c);n+=len(c)
 return n,h.hexdigest()
def prefix(p):
 lines=[]
 with gzip.open(p,'rt') as f:
  for line in f:
   if line.startswith('  "memoryReads":'):break
   lines.append(line)
 return json.loads(''.join(lines).rstrip().rstrip(',')+'\n}')
proc=H/'constructor-ledger-clear-run04-process-receipt.json';assert digest(proc)[1]=='3c801392336d20d423f7e85c93fda02bf4d57f4dc013745b714287ffb7540f07'
z=json.loads(proc.read_text());assert z['status']=='terminal' and z['exitCode']==2 and z['outerTimeoutSeconds']==1200
assert z['driversBefore']==z['driversAfter'];assert len(z['driversAfter'])==8
for name,s in z['driversAfter'].items():assert digest(H/name)[1]==s
for f in z['artifacts']+[z['wrapper'],z['approval']]:
 p=Path(f['path']);p=p if p.is_absolute() else ROOT/p;assert digest(p)==(f['bytes'],f['sha256'])
a=json.loads((ROOT/z['approval']['path']).read_text());held=json.loads((R/'constructor-ledger-closure-held-approval.json').read_text());held['parentReleasedRunLane']=True
assert all(a.get(k)==v for k,v in held.items())
out=H/'constructor-ledger-clear-run04';receipt=json.loads((out/'constructor-ledger-result-stream-receipt.json').read_text());h=hashlib.sha256();size=0
with gzip.open(out/'constructor-ledger-result.json.gz','rb') as f:
 while c:=f.read(1024*1024):h.update(c);size+=len(c)
assert (size,h.hexdigest())==(receipt['uncompressedBytes'],receipt['uncompressedSha256'])
v=prefix(out/'constructor-ledger-result.json.gz');old=prefix(H/'constructor-ledger-clear-run03/constructor-ledger-result.json.gz')
assert v['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP' and v['complete'] is False
assert v['committedOriginalInstructions']==2340238 and v['attemptedOriginalInstructions']==2340239
assert v['blocker']=={'reason':'instruction/time bound before exact stop','phase':'startup animation transform','pc':'0x42c5b4'}
assert all(not v[k] for k in ['blocks','records','calls','openCalls','returnedAllocations','counterCopies','counterIncrements','rngWrites','publications','projections'])
assert len(v['phaseReceipts'])==3
for this,prior in zip(v['phaseReceipts'],old['phaseReceipts']):
 for key in ['phase','pc','committedInstructions','seedPreservation']:assert this[key]==prior[key]
assert v['abortedInstructions'][0]['pc']=='0x42c5b4' and v['abortedInstructions'][0]['status']=='not-committed'
assert v['abortedInstructions'][0]['bytes']=='668906'
assert v['committedOriginalInstructions']-v['phaseReceipts'][-1]['committedInstructions']<3000000
assert v['runtimeSeconds']>=240 and v['runtimeSeconds']<z['elapsedSeconds']<1200
assert v['selectedAssertions']['fullStageAComplete'] is False and v['selectedAssertions']['completedRecords']==0
report={'verdict':'ACCEPT_LIMITED_TERMINAL_RESOURCE_STOP_CLASSIFICATION','originalInstructionsExecutedByReviewer':0,'processSha256':digest(proc)[1],'resultGzipSha256':digest(out/'constructor-ledger-result.json.gz')[1],'expandedBytes':size,'expandedSha256':h.hexdigest(),'eventGzipSha256':digest(out/'constructor-ledger-events.jsonl.gz')[1],'allEightFrozenDriverHashesStable':True,'releasedApprovalSha256':z['approval']['sha256'],'status':v['status'],'complete':False,'processExitCode':2,'processElapsedSeconds':z['elapsedSeconds'],'resultRuntimeSeconds':v['runtimeSeconds'],'attemptedOriginalInstructions':v['attemptedOriginalInstructions'],'committedOriginalInstructions':v['committedOriginalInstructions'],'blocker':v['blocker'],'completedPhaseCheckpoints':[{'phase':x['phase'],'committedInstructions':x['committedInstructions']} for x in v['phaseReceipts']],'comparison':'First three checkpoint PCs/counts/seed snapshots match run03. Run03 animation endpoint2344732 is4494 committed instructions beyond this stop; this is instruction progress comparison, not a performance benchmark.','emptyConstructorOutputs':['blocks','records','calls','openCalls','returnedAllocations','counterCopies','counterIncrements','rngWrites','publications','projections'],'abortedInstruction':v['abortedInstructions'][0],'classificationEvidence':'Engine emu_start has240000000 microseconds and3000000 phase instruction bound. Animation committed2320216, total runtime242.521s, outer process exited normally at269.877s; no recorded unknown/target/import fault. Evidence supports phase wall-time stop, not instruction cap or outer timeout.','verificationLimits':['Compressed identities and complete expanded result SHA/length verified; only small metadata prefix parsed.','No full observer chronology/mask replay, no independent memory value or CPU arithmetic replay, no original execution. Pending rollback journal is source-consistent metadata, not separately reconstructed from all events.','No constructor progress, count result, branch equivalence, actual startup or product-fix claim.','A retry requires fresh budget-bound driver/preflight/review and separate parent release; current approval is spent.'],'budgetAssessment':'Animation-only wall-time headroom can be raised while keeping all instruction/event/storage/outer caps and exact semantics/inputs/windows. No need to broaden other phase budgets from this evidence.','verifierSha256':digest(Path(__file__))[1]}
(R/'constructor-ledger-run04-terminal-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS_LIMITED_TERMINAL_REVIEW','reportSha256':digest(R/'constructor-ledger-run04-terminal-review.json')[1],'originalInstructionsExecuted':0}))
