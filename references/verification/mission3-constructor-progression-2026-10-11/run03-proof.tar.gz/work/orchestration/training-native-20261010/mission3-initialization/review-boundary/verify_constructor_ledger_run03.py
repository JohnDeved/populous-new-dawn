"""File-only audit of frozen run03. Does not construct a CPU or execute x86."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,heapq,importlib.util,json,struct,time
import capstone
ROOT=Path.cwd();B=ROOT/'work/orchestration/training-native-20261010/mission3-initialization';H=B/'harness-repair';O=B/'review-boundary';R=H/'constructor-ledger-clear-run03'
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1048576):h.update(data)
 return h.hexdigest()
started=time.monotonic();stream=read(R/'constructor-ledger-result-stream-receipt.json');process=read(H/'constructor-ledger-clear-run03-process-receipt.json');m=read(R/'constructor-ledger-preflight.json')
assert filehash(R/'constructor-ledger-result.json.gz')==stream['sha256']=='11ef1baf0a11b556be9a1e624b79f5e8520f8770d001c7f21f1c742b61b10e26'
assert filehash(R/'constructor-ledger-events.jsonl.gz')=='ce55fba5d017dc259ac90705820433f5eaa0bd0e4c28f40b3641acb462a3720e'
h=hashlib.sha256();n=0
with gzip.open(R/'constructor-ledger-result.json.gz','rb') as f:
 while chunk:=f.read(1048576):h.update(chunk);n+=len(chunk)
assert n==stream['uncompressedBytes']==403101672 and h.hexdigest()==stream['uncompressedSha256']=='005a74ce87fb58012ee04b9cdf116537a0d20575cb7794a661299bf782de729f'
with gzip.open(R/'constructor-ledger-result.json.gz','rt') as f:r=json.load(f)
print('loaded',flush=True)
assert process['status']=='terminal' and process['exitCode']==2 and not process['trackedStatus']
assert process['driversBefore']==process['driversAfter']
assert process['driversBefore']['constructor_ledger_inputs_candidate.py']=='61c7aa644c53bd953b3447d393a72e5db0d4dc4f64c45b66fff4e26fb763b60d'
ap=Path(process['approval']['path']);ap=ap if ap.is_absolute() else ROOT/ap;approval=read(ap)
assert filehash(ap)==process['approval']['sha256'] and approval['parentReleasedRunLane']
held=read(O/'constructor-ledger-inputs-held-approval.json')
for k,v in held.items():
 if k!='parentReleasedRunLane':assert approval[k]==v,(k,approval.get(k),v)
assert r['conditions']==m['conditions'] and r['selectedLedgerContract']==m['selectedLedgerContract']
assert r['status']=='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP' and r['complete'] is False
assert (r['attemptedOriginalInstructions'],r['committedOriginalInstructions'])==(4069039,4069038)
assert r['blocker']['pc']=='0x404c15' and r['blocker']['record']==1 and r['blocker']['reason']=='outside exact approved text windows'
assert r['blocker']['details']=={'target':'0x41b3f0'}
assert len(r['abortedInstructions'])==1 and r['abortedInstructions'][0]['pc']=='0x404c15' and r['abortedInstructions'][0]['attemptedWrites']==[]
assert not r['returnedAllocations'] and not r['publications']
assert len(r['openCalls'])==7 and r['openCalls'][0]['target']=='0x4ed8a0' and r['openCalls'][0]['caller']=='0x485011' and not r['openCalls'][0]['returned']
assert len(r['records'])==len(r['blocks'])==1 and r['records'][0]['status']=='entered'
level=(Path('/workspace/scratch/69fd8163d94e/original-game-restoration-20261010/game/levels/levl2003.dat')).read_bytes()
assert sha(level)=='eb239eabebbcde37c1e1633b149d48977cedf432348a12fc5ee6b4be74c049bf'
assert r['records'][0]['rawHex']==level[0x14043:0x14043+55].hex()
assert r['selectedAssertions']['completedRecords']==0 and r['selectedAssertions']['fullStageAComplete'] is False
assert r['selectedAssertions']['committedClass1Copies']==r['selectedAssertions']['committedClass1Increments']==r['selectedAssertions']['fullyReturnedSuccessfulClass1Count']==0
assert r['selectedAssertions']['finalKnownClass1Seed']=={'address':'0x96eac2','value':0,'knownMask':'0xff'}
for p in r['phaseReceipts']:
 if 'seedPreservation' in p:
  assert all(x['value']==0x09d78afe and x['knownMask']=='0xffffffff' for x in p['seedPreservation']['rng'])
  assert all(x['value']==0 and x['knownMask']=='0xff' for x in p['seedPreservation']['classCounters'])
spec=importlib.util.spec_from_file_location('static_pe',ROOT/'scripts/check-static-mission18-sky.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);pe=module.PE32(Path(m['executable']['path']))
assert sha(pe.data)=='3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f'
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True;instructions={}
for w in m['allowedWindows']:
 lo,hi=int(w['start'],16),int(w['endExclusive'],16);data=pe.read(lo,hi-lo);assert sha(data)==w['sha256'];ins=list(cs.disasm(data,lo));assert sum(x.size for x in ins)==len(data);instructions.update({x.address:x for x in ins})
assert pe.read(0x404c15,5).hex()=='e8d6670100'
assert r['abortedInstructions'][0]['bytes']=='e8d6670100'
for call in r['calls']:
 pc=int(call['caller'],16);target=int(call['target'],16);assert pc in instructions and target in instructions,(call['caller'],call['target'])
 assert instructions[pc].mnemonic=='call'
 if instructions[pc].operands[0].type==capstone.x86.X86_OP_IMM:assert instructions[pc].operands[0].imm==target
 assert call['returned'] or call in r['openCalls']
# Reconstruct only memory known-bit provenance. This is not an independent CPU
# value interpreter and does not infer retirement counts from observer ordinals.
ranges=[(0x400000,bytearray(0xd4e000-0x400000)),(0x2000000,bytearray(0x400000))]
def location(a,n):
 for base,mem in ranges:
  if base<=a and a+n<=base+len(mem):return mem,a-base
 raise AssertionError(('outside memory domain',hex(a),n))
def put(a,n,mask=None):
 mem,off=location(a,n);mem[off:off+n]=bytes([255])*n if mask is None else mask.to_bytes(n,'little')
def get(a,n):
 mem,off=location(a,n);return int.from_bytes(mem[off:off+n],'little')
arrays={'read':r['memoryReads'],'write':r['memoryWrites'],'invalidation':r['invalidationEvents']};cursors=Counter();ordinal=0;supply_seq=0;phases=[];pcs=Counter();tracehash=hashlib.sha256();tracebytes=0;stop_byte_touches=[]
with gzip.open(R/'constructor-ledger-events.jsonl.gz','rb') as f:
 for line in f:
  tracehash.update(line);tracebytes+=len(line);row=json.loads(line);kind=row.pop('kind')
  if kind=='conditionedSupply':
   assert row==r['suppliedInputs'][supply_seq] and row['supplySequence']==supply_seq and row['beforeEventOrdinal']==ordinal
   supply_seq+=1
   if 'address' in row:
    a=int(row['address'],16);size=row['size'];put(a,size,int(row['knownMask'],16) if 'knownMask' in row else None)
    if a<=0x89ce37<a+size:stop_byte_touches.append(('supply',row))
   continue
  if kind=='phaseCheckpoint':phases.append(row);assert row in r['phaseReceipts'];continue
  assert kind in arrays and row==arrays[kind][cursors[kind]],(kind,cursors[kind])
  cursors[kind]+=1;assert row['eventOrdinal']==ordinal;ordinal+=1
  if kind=='invalidation':
   if row['target']=='memory':put(int(row['address'],16),row['size'],int(row['knownMask'],16))
   continue
  pc=int(row['pc'],16);a=int(row['address'],16);size=row['size'];mask=int(row['knownMask'],16)
  assert pc in instructions and pc!=0x404c15,(row['pc'],kind)
  assert not instructions[pc].mnemonic.startswith('f'),instructions[pc].mnemonic
  pcs[pc]+=1
  if kind=='read':assert get(a,size)==mask,(row,get(a,size))
  else:
   assert row['committed'] and size==1;put(a,size,mask)
   if a<=0x89ce37<a+size:stop_byte_touches.append(('write',row))
assert all(cursors[k]==len(v) for k,v in arrays.items()) and supply_seq==len(r['suppliedInputs'])
assert ordinal==r['eventStream']['eventCount'] and get(0x89ce37,1)==255
assert tracehash.hexdigest()==r['rawEventTrace']['uncompressedSha256'] and tracebytes==r['rawEventTrace']['uncompressedBytes']
assert get(0x2140000+6320,1602)==0
for x in r['finalSeeds']['classCounters']:assert get(int(x['address'],16),1)==int(x['knownMask'],16)

assert not any(x['target']=='0x41b3f0' for x in r['calls'])
assert len(r['projections'])==1
projection=r['projections'][0];assert projection['start']=='0x4bdebe' and projection['endExclusive']=='0x4bdfdb' and projection['kind']=='omitted-texture-cache-derived-output'
sp=int(projection['entryRegisters']['esp']['value'],16)
inv=[x for x in r['invalidationEvents'] if x['pc']=='0x4bdebe'];assert len(inv)==12
expected=[('memory',sp-156,156),('memory',sp+16,6),('memory',sp+28,4),('memory',0x9bc318,1024)]
actual=[(x['target'],int(x['address'],16),x['size']) for x in inv if x['target']=='memory'];assert sorted(actual)==sorted(expected)
assert all(x['knownMask']=='0x0' for x in inv if x['target']=='memory')
assert [x['register'] for x in inv if x['target']=='register']==['eax','ebx','ecx','edx','esi','edi','ebp','eflags']
assert all(x['knownMask']=='0x0' for x in inv if x.get('register') not in [None,'eflags'])
assert int(inv[-1]['knownMask'],16)&0x8d5==0
assert get(0x9bc318,1024)==0 and all(get(a,4)==0 for a in [0x9bcfc8,0x9bcfd8,0x5d45b0])
assert not any(0x4bdebe<=pc<0x4bdfdb or 0x4bee20<=pc<0x4bf622 for pc in pcs)
assert pcs[0x4bde94]>0 and pcs[0x4206d0]>0
assert not any(x['target'] in ['0x4bee20','0x4bf1b0'] for x in r['calls'])
assert any(x['caller']=='0x4bdfdb' and x['target']=='0x4206d0' and x['returned'] for x in r['calls'])
assert any(x['target']=='0x4bdd40' and x['returned'] for x in r['calls'])
stat_counts={}
for pc,address in [(0x44de5b,0x68c6d0),(0x44deab,0x6906dc)]:
 reads=[x for x in r['memoryReads'] if int(x['pc'],16)==pc];writes=[x for x in r['memoryWrites'] if int(x['pc'],16)==pc]
 assert all(x['knownMask']=='0x0' and int(x['address'],16)==address and x['size']==4 for x in reads)
 assert len(writes)==4*len(reads) and all(x['knownMask']=='0x0' and address<=int(x['address'],16)<address+4 for x in writes)
 stat_counts[hex(pc)]={'reads':len(reads),'byteWrites':len(writes)}
assert any(x.get('address')=='0x690ae8' and x['size']==2048 and x['knownMask']=='0x0' and 'model terrain boundary' in x['reason'] for x in r['invalidationEvents'])
assert any(x.get('address')=='0x6906e0' and x['size']==1024 and x['knownMask']=='0x0' and 'model terrain boundary' in x['reason'] for x in r['invalidationEvents'])

summary={'status':'ACCEPT_CONDITIONAL_DIAGNOSTIC_STOP','resultCompressedSha256':stream['sha256'],'resultUncompressedSha256':stream['uncompressedSha256'],'attempted':r['attemptedOriginalInstructions'],'committed':r['committedOriginalInstructions'],'eventCount':ordinal,'counts':dict(cursors),'supplies':supply_seq,'phaseCheckpoints':len(phases),'calls':len(r['calls']),'openCalls':r['openCalls'],'records':r['records'],'blocks':r['blocks'],'counterCopies':r['counterCopies'],'counterIncrements':r['counterIncrements'],'rngWrites':r['rngWrites'],'selectedAssertions':r['selectedAssertions'],'blocker':r['blocker'],'abortedInstructions':r['abortedInstructions'],'finalRegisters':r['finalRegisters'],'finalSeeds':r['finalSeeds'],'suppressionByteProvenance':{'knownMask':255,'suppliesOrCommittedWrites':stop_byte_touches},'animationTailMask':'all 1602 bytes unknown','textureProjection':projection,'textureInvalidations':inv,'statisticEventCounts':stat_counts,'retainedBrightnessWrites':pcs[0x4bde94],'finalDirtyOrEvents':pcs[0x4206d0],'observerValidation':'All raw rows equal final arrays; ordinals contiguous; mid-run supplies applied at exact insertion cursor; every read mask equals reconstructed prior supplies/committed writes/invalidations. Raw memory-event and call PCs match source-bound instruction boundaries.','limits':['Observer chronology is not retirement proof.','This is mask/provenance reconciliation, not independent CPU arithmetic replay.','Conditional model terrain and omitted-history/input seams remain as predeclared.','No successful allocation, record completion, class1 total or actual startup result established.','Mode3/initializer-suppression0 and valid disjoint opaque-resource/normal-return conditions remain explicit.'],'originalInstructionsExecutedByReviewer':0,'elapsedSeconds':time.monotonic()-started}
p=O/'constructor-ledger-run03-post-review.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':filehash(p),'events':ordinal,'counts':dict(cursors),'openCalls':len(r['openCalls']),'counterCopies':r['counterCopies'],'counterIncrements':r['counterIncrements'],'seconds':summary['elapsedSeconds']},indent=2),flush=True)
