#!/usr/bin/env python3
"""Conditional Mission3 StageA diagnostic; no original execution without exact review.

All 20 blocks and 2,000 slot iterations remain genuine. A constructor-critical
unknown is a retained diagnostic stop, never a completed-ledger success.
"""
from pathlib import Path
import argparse,gzip,hashlib,importlib.util,io,json,platform,shutil,struct,sys,time
HERE=Path(__file__).resolve().parent
FROZEN=HERE/'preloader_candidate.py';FROZEN_SHA='90c4dd29f55029062de8847984ef87fff13cbef79d4ef39343ffc01179051793'
if hashlib.sha256(FROZEN.read_bytes()).hexdigest()!=FROZEN_SHA:raise RuntimeError('frozen preloader drift')
spec=importlib.util.spec_from_file_location('ledger_frozen_preloader',FROZEN);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);s=v.s;b=v.b
SCOPE='conditional-mission3-stageA-real-record-loop-diagnostic'
ENTRY,NEXT,FINAL=0x484ebd,0x484e9a,0x485050
FRAME=b.STACK;STACK_BOTTOM=0x23d0000
OBJECTS,FACES,POINTS,RAWFRAMES,RAWSTARTS,VELE,STARTS,FRAMES,CHAINS,SHAPES,BUFFER=(0x2000000,0x2010000,0x20c0000,0x20d0000,0x20e0000,0x20f0000,0x2120000,0x2130000,0x2140000,0x2150000,0x2180000)
LEVEL_OFFSET,BLOCK_BYTES=0x14043,0x157c
TREE_START,TREE_END=0x4a5f63,0x4a5fb8
TEXTURE_START,TEXTURE_END=0x4bdebe,0x4bdfdb
OPAQUE_POINTERS=(0x9bcfc8,0x9bcfd8,0x5d45b0)
STAT_INCREMENTS={0x44de5b:0x68c6d0,0x44deab:0x6906dc}
BOUND_FILES=[HERE.parent/'constructor-function-bounds.tsv',HERE.parent/'constructor-selected-helpers.tsv',HERE/'first-hut-source/first-hut-bounds.tsv']
TERRAIN=HERE/'constructor-terrain01'
ASSETS=b.INPUT_NAMES+['data/vele-0.ani','data/vspr-0.inf']
SETUP_WINDOWS=b.POOL_WINDOWS+v.NEW_WINDOWS+[(0x42c4b6,0x42c5ee),(0x40c8a5,0x40c8d8),(0x40c920,0x40c9e2),(0x40c7d8,0x40c818),(0x40ce30,0x40cf6d),(0x418de0,0x418e29),(0x484e09,0x484e3a),(0x484e7b,NEXT),(ENTRY,FINAL),(0x401090,0x4010ac),(0x401790,0x40191a),(0x586000,0x586034)]

MIB=1024*1024
TRACE_LIMIT=512*MIB
FINAL_JSON_LIMIT=1536*MIB
FINAL_COMPRESSED_LIMIT=512*MIB
OTHER_OUTPUT_ALLOWANCE=64*MIB
SPACE_MARGIN=256*MIB
REQUIRED_FREE=TRACE_LIMIT+FINAL_COMPRESSED_LIMIT+OTHER_OUTPUT_ALLOWANCE+SPACE_MARGIN

class GzipTrace:
 """Lossless streaming trace; complete gzip footer on normal or diagnostic stop."""
 def __init__(self,path,limit=TRACE_LIMIT):
  self.raw=Path(path).open('wb');self.gzip=gzip.GzipFile(fileobj=self.raw,mode='wb',mtime=0,compresslevel=6);self.text=io.TextIOWrapper(self.gzip,encoding='utf-8',newline='\n');self.limit=limit;self.closed=False;self.uncompressed_bytes=0;self.uncompressed_hash=hashlib.sha256()
 def write(self,text):
  if len(text.encode('utf-8'))>MIB:raise b.Blocked('oversized trace row; resource contract exceeded')
  written=self.text.write(text);raw=text.encode('utf-8');self.uncompressed_bytes+=len(raw);self.uncompressed_hash.update(raw);return written
 def flush(self):self.text.flush();self.raw.flush()
 def near_limit(self):return self.raw.tell()>=max(0,self.limit-4*MIB)
 def close(self):
  if not self.closed:self.text.close();self.raw.close();self.closed=True

def check_storage(out):
 free=shutil.disk_usage(out).free
 if free<REQUIRED_FREE:raise b.Blocked('insufficient free space for conservative output budget',freeBytes=free,requiredFreeBytes=REQUIRED_FREE)
 return {'freeBytesAtAdmission':free,'requiredFreeBytes':REQUIRED_FREE,'traceCompressedByteLimit':TRACE_LIMIT,'finalUncompressedJsonByteLimit':FINAL_JSON_LIMIT,'finalCompressedJsonByteLimit':FINAL_COMPRESSED_LIMIT,'otherOutputAllowance':OTHER_OUTPUT_ALLOWANCE,'margin':SPACE_MARGIN,'guarantee':'Admission snapshot only; concurrent external disk use may still cause an explicit I/O failure.'}

def stream_file_record(path):
 path=Path(path);digest=hashlib.sha256();size=0
 with path.open('rb') as handle:
  while chunk:=handle.read(MIB):digest.update(chunk);size+=len(chunk)
 return {'path':str(path),'bytes':size,'sha256':digest.hexdigest()}

def write_bounded_json(path,value,limit=FINAL_JSON_LIMIT):
 path=Path(path);partial=path.with_suffix(path.suffix+'.partial');handle=GzipTrace(partial,FINAL_COMPRESSED_LIMIT);total=0
 try:
  for chunk in json.JSONEncoder(indent=2).iterencode(value):
   size=len(chunk.encode('utf-8'))
   if total+size+1>limit:raise b.Blocked('uncompressed JSON resource limit exceeded; complete event gzip and explicit partial result retained',limitBytes=limit,writtenBytes=total)
   if handle.near_limit():raise b.Blocked('compressed result resource boundary reached; complete event gzip and explicit partial result retained')
   handle.write(chunk);total+=size
  handle.write('\n')
 finally:handle.close()
 partial.rename(path)
 return {**stream_file_record(path),'uncompressedBytes':handle.uncompressed_bytes,'uncompressedSha256':handle.uncompressed_hash.hexdigest(),'format':'lossless gzip JSON; no expanded disk duplicate'}


def ranges():
 result=list(SETUP_WINDOWS)
 for file in BOUND_FILES:
  for line in file.read_text().splitlines():
   row=line.split('\t')
   if row[0]=='RANGE' and row[1] not in ['0040c880','004bee20','004bf1b0']:result.append((int(row[2],16),int(row[3],16)))
 return sorted(set(result))

def pack(n,size=4):return n.to_bytes(size,'little')

def selected_seeds(e):return {'rng':[e.observed(a,4) for a in [0x89d178,0x89bc72]],'classCounters':[e.observed(0x96eac1+i,1) for i in range(12)]}

class Ledger(v.Preloader):
 def __init__(self,*args,level=None,enable_tree_projection=False,enable_texture_projection=False,**kwargs):
  super().__init__(*args,enforce_sunlight=False,enforce_prefix=False,enforce_palette_context=False,skips=[],**kwargs)
  self.level=level;self.enable_tree_projection=enable_tree_projection;self.enable_texture_projection=enable_texture_projection;self.blocks=[];self.records=[];self.current_record=None
  self.phase_receipts=[];self.counter_copies=[];self.counter_increments=[];self.rng_writes=[];self.publications=[];self.trace_sink=None
 def trace(self,kind,event):
  if self.trace_sink:self.trace_sink.write(json.dumps({'kind':kind,**event},separators=(',',':'))+'\n')
 def annotate_supply(self):
  self.supplies[-1].update(supplySequence=len(self.supplies)-1,phase=self.phase,beforeEventOrdinal=self.event_ordinal,pc=hex(self.reg_value('eip')))
  self.trace('conditionedSupply',self.supplies[-1])
 def supply(self,*args,**kwargs):
  super().supply(*args,**kwargs);self.annotate_supply()
 def reg_supply(self,*args,**kwargs):
  super().reg_supply(*args,**kwargs);self.annotate_supply()
 def masked_supply(self,*args,**kwargs):
  super().masked_supply(*args,**kwargs);self.annotate_supply()
 def memory_event(self,kind,event):
  super().memory_event(kind,event);self.trace(kind,(self.read_events if kind=='read' else self.write_events)[-1])
 def invalidation(self,*args,**kwargs):
  super().invalidation(*args,**kwargs);self.trace('invalidation',self.invalidation_events[-1])
 def invalidate_memory(self,pc,address,size,reason):
  self.shadow.put(address,size,0);self.invalidation(pc,'memory',size,0,reason,address=hex(address))
 def invalidate_register(self,pc,reg,reason,mask=0):
  self.shadow.reg_put(reg,mask);self.invalidation(pc,'register',4,mask,reason,register=reg)
 def boundary_registers(self,label,regs=None):
  if self.pending or self.frames:raise b.Blocked('setup boundary has unfinished instruction/call')
  self.invalidate_memory(self.reg_value('eip'),STACK_BOTTOM,FRAME+0x400-STACK_BOTTOM,'new selected-kernel frame; prior diagnostic stack provenance expires')
  for reg in ['eax','ebx','ecx','edx','esi','edi','ebp']:
   self.invalidate_register(self.reg_value('eip'),reg,'declared selected-kernel entry; '+label)
  self.reg_supply('esp',FRAME,b.MASK32,'declared isolated source-kernel frame; '+label)
  self.reg_supply('eflags',2,b.DF,'cdecl DF0 entry condition; '+label)
  for reg,value in (regs or {}).items():self.reg_supply(reg,value,b.MASK32,'source-bound selected-kernel entry; '+label)
 def checkpoint_seeds(self,label):
  state=selected_seeds(self)
  if self.observed(0x5d45a8,1)['value']!=3:raise b.Blocked('selected setup changed conditioned landscape mode3')
  if self.observed(0x89ce37,1)['value']!=0:raise b.Blocked('selected setup changed conditioned initializer-suppression byte')
  if [x['value'] for x in state['rng']]!=[0x09d78afe]*2 or any(x['value']!=0 for x in state['classCounters']):raise b.Blocked('selected kernel changed conditioned initial RNG/counters',phase=label,state=state)
  self.phase_receipts.append({'phase':label,'pc':hex(self.reg_value('eip')),'committedInstructions':self.committed,'seedPreservation':state,'additionalConditionPreservation':{'initializerSuppression':self.observed(0x89ce37,1),'landscapeMode':self.observed(0x5d45a8,1)}})
  self.trace('phaseCheckpoint',self.phase_receipts[-1])
  if self.trace_sink:self.trace_sink.flush()
 def root(self,address,label):
  self.phase=label;self.boundary_registers(label);self.supply(FRAME,pack(b.STOP),'diagnostic root return sentinel, no original caller or stub')
  self.run(address,b.STOP,budget=3_000_000,timeout_us=240_000_000);self.checkpoint_seeds(label)
 def cut(self,start,stop,label,regs=None):
  self.phase=label;self.boundary_registers(label,regs);self.run(start,stop,budget=3_000_000,timeout_us=240_000_000);self.checkpoint_seeds(label)
 def transport(self,index):
  if self.level is None or index!=len(self.blocks) or not 0<=index<20:raise b.Blocked('invalid canonical transport block sequence')
  if self.pending or self.frames or self.reg_value('esp')!=FRAME:raise b.Blocked('transport frame mismatch')
  if self.reg_value('eip')!=NEXT:raise b.Blocked('transport outside exact before-message boundary')
  if self.observed(FRAME+0x28,4)['value']!=20-index or self.reg_value('edi')!=1+100*index or self.shadow.reg_get('edi')!=b.MASK32:raise b.Blocked('transport block/record position mismatch')
  off=LEVEL_OFFSET+index*BLOCK_BYTES;raw=self.level[off:off+BLOCK_BYTES]
  if len(raw)!=BLOCK_BYTES:raise b.Blocked('short canonical block')
  before=selected_seeds(self)
  # Entire declared scratch stack below this caller frame is invalidated. No
  # return value or fabricated CALL/RET event is introduced by this boundary.
  self.invalidate_memory(NEXT,STACK_BOTTOM,FRAME-STACK_BOTTOM,'omitted transport stack footprint; all below-frame bytes unknown')
  for reg in ['eax','ecx','edx']:self.invalidate_register(NEXT,reg,'omitted message/file volatile live-out')
  self.invalidate_register(NEXT,'eflags','omitted message/file arithmetic flags',self.shadow.reg['eflags']&~b.ARITH)
  self.supply(BUFFER,raw,f'conditioned successful canonical DAT block {index}; file offset {off:#x}, original transfer count {BLOCK_BYTES:#x}')
  self.supply(FRAME+0x18,pack(BLOCK_BYTES),'conditioned successful transport byte count; genuine following CMP retained')
  self.blocks.append({'blockIndex':index,'fileOffset':off,'bytes':len(raw),'sha256':b.sha(raw),'buffer':hex(BUFFER),'frame':hex(FRAME),'beforePC':hex(NEXT),'resumePC':hex(ENTRY),'kind':'conditioned-data-boundary-not-native-instruction','selectedStateBefore':before,'preservationCondition':'All prior known game state and pointer mappings outside the transported buffer/byte-count and below-frame stack retain their values across omitted message/file calls; nonvolatile registers and caller frame retain their values.'})
 def tree_projection(self):
  if not self.enable_tree_projection or self.phase!='authored-record-loop':raise b.Blocked('scenery omission outside admitted phase')
  self.check_target(TREE_START);self.check_target(TREE_END)
  if not self.frames or self.frames[-1]['target']!='0x4a5ef0' or self.frames[-1]['caller']!='0x4ed5b8' or self.frames[-1]['return']!=0x4ed5bd:raise b.Blocked('scenery omission outside exact constructor dispatch')
  if self.shadow.reg_get('esp')!=b.MASK32 or self.reg_value('esp')!=self.frames[-1]['returnSp']-32:raise b.Blocked('scenery omission native frame mismatch')
  for reg,value in [('ebx',v.TRIBE),('ecx',0)]:
   if self.shadow.reg_get(reg)!=b.MASK32 or self.reg_value(reg)!=value:raise b.Blocked('scenery omission entry register mismatch',register=reg)
  ptr=self.reg_value('esi');self.require(self.shadow.reg_get('esi'),b.MASK32,'scenery object pointer')
  for reg in ['bp','di']:self.require(self.shadow.reg_get(reg),65535,'scenery known position half',register=reg)
  sp=self.reg_value('esp');self.require(self.shadow.get(sp+0x10,4),b.MASK32,'scenery local position setup')
  model=self.observed(ptr+0x2b,1)['value']
  if model is None:raise b.Blocked('unknown scenery model at omission')
  flags=self.observed(0x5a79c5+24*model,1)
  if flags['value'] is None or flags['value']&4:raise b.Blocked('scenery omitted path lacks canonical model guard')
  entry=self.register_snapshot()
  self.invalidate_memory(TREE_START,0x96eaba,4,'omitted gameplay-derived four-tribe proximity outputs')
  for reg in ['eax','edx','ebx','ecx']:self.invalidate_register(TREE_START,reg,'omitted gameplay-derived proximity register live-out')
  self.invalidate_register(TREE_START,'eflags','omitted gameplay-derived proximity arithmetic flags',self.shadow.reg['eflags']&~b.ARITH)
  self.projections.append({'start':hex(TREE_START),'endExclusive':hex(TREE_END),'bytes':85,'kind':'omitted-gameplay-derived-output','record':self.record,'object':hex(ptr),'model':model,'entryRegisters':entry,'preserved':['esi','ebp','edi','esp','prior local position bytes'],'conditions':'Normal completion of omitted pure integer loop; exact four possible output bytes and uncertain live-outs remain unknown; later decisive consumption aborts.'})
  self.cpu.reg_write(self.x.UC_X86_REG_EIP,TREE_END)
 def texture_projection(self):
  if not self.enable_texture_projection or self.phase!='authored-record-loop':raise b.Blocked('texture omission outside admitted phase')
  self.check_target(TEXTURE_START);self.check_target(TEXTURE_END)
  if len(self.frames)<2:raise b.Blocked('texture omission lacks nested constructor call frame')
  f=self.frames[-1];parent=self.frames[-2]
  if f['target']!='0x4bdd40' or f['caller']!='0x403bf3' or f['return']!=0x403bf8 or parent['target']!='0x403a00':raise b.Blocked('texture omission outside exact first-hut landscape call')
  sp=self.reg_value('esp')
  if self.shadow.reg_get('esp')!=b.MASK32 or sp!=f['returnSp']-36:raise b.Blocked('texture omission native frame mismatch')
  if self.observed(0x5d45a8,1)['value']!=3:raise b.Blocked('texture omission lacks source-bound mode3 condition')
  # Parent frame arg is read from its genuine CALL frame, never guessed from
  # a volatile register. Only the source-audited class2/model1 path is admitted.
  ptr=self.observed(parent['returnSp'],4)['value']
  if ptr is None or self.observed(ptr+0x2a,1)['value']!=2 or self.observed(ptr+0x2b,1)['value']!=1:raise b.Blocked('texture omission is not class2/model1')
  for a in OPAQUE_POINTERS:
   if self.shadow.get(a,4)!=0:raise b.Blocked('opaque resource pointer unexpectedly gained concrete provenance',address=hex(a))
  # Actual loop consumes two16-bit arguments, and the genuine brightness loop
  # has established its width atSP+18. Validate these before replacing outputs.
  for a,n in [(sp+0x24,2),(sp+0x28,2),(sp+0x18,4)]:self.require(self.shadow.get(a,n),(1<<(8*n))-1,'texture omission known geometric argument')
  radius=self.observed(sp+0x28,2)['value'];width=self.observed(sp+0x18,4)['value']
  if not 1<=radius<=128 or width!=2*radius+1:raise b.Blocked('texture omission geometric width/radius mismatch')
  if not (STACK_BOTTOM<=sp-156 and sp+32<=FRAME+0x400):raise b.Blocked('texture omission stack outside declared scratch frame')
  entry=self.register_snapshot()
  self.invalidate_memory(TEXTURE_START,0x9bc318,0x400,'omitted texture/cache loop dirty grid; all possible1024 output bytes unknown')
  self.invalidate_memory(TEXTURE_START,sp-156,156,'omitted texture loop calls: two args, return slot, largest0x80 locals and four saved registers')
  self.invalidate_memory(TEXTURE_START,sp+0x10,6,'omitted texture/cache loop local DWORD and WORD writes')
  self.invalidate_memory(TEXTURE_START,sp+0x1c,4,'omitted texture/cache loop local DWORD write; widthSP+18 preserved')
  for reg in ['eax','ebx','ecx','edx','esi','edi','ebp']:self.invalidate_register(TEXTURE_START,reg,'omitted texture/cache loop uncertain register live-out')
  self.invalidate_register(TEXTURE_START,'eflags','omitted texture/cache loop arithmetic flags',self.shadow.reg['eflags']&~b.ARITH)
  self.projections.append({'start':hex(TEXTURE_START),'endExclusive':hex(TEXTURE_END),'bytes':TEXTURE_END-TEXTURE_START,'kind':'omitted-texture-cache-derived-output','record':self.record,'object':hex(ptr),'entryRegisters':entry,'preserved':['esp','saved nonvolatile stack slotsSP..SP+15','genuine preceding terrain brightness','genuine subsequent004206d0 dirty OR'],'opaqueOutputs':'res_array1 index*8+2/+3 and texture8x8 byte tiles remain unknown under disjoint-live-resource condition; pointers remain unknown','conditions':'All opaque source/destination accesses valid and normal completion; opaque resource/texture write footprints disjoint from all mapped game/selected asset/stack state, except declared scratch stack. No assertion of original fault absence or universal alias independence.'})
  self.cpu.reg_write(self.x.UC_X86_REG_EIP,TEXTURE_END)
 def plan_unknown_stat_increment(self,ins):
  address=STAT_INCREMENTS.get(ins.address)
  if address is None:return False
  x=self.cs_module.x86;ops=ins.operands
  if ins.mnemonic!='inc' or len(ops)!=1 or ops[0].type!=x.X86_OP_MEM or ops[0].size!=4 or ops[0].mem.base or ops[0].mem.index or ops[0].mem.disp!=address or any(ins.prefix):raise b.Blocked('source-bound statistic INC encoding changed')
  self.operand(ops[0],ins) # The real read remains observed, with its actual mask.
  self.destination(ops[0],0,ins) # Conservative unknown result, no invented input.
  self.flags(0,b.PF|b.AF|b.ZF|b.SF|b.OF) # INC preserves CF; later CMPs decide.
  return True
 def _code(self,c,a,n,unused):
  try:
   if self.trace_sink and self.trace_sink.near_limit():
    self.commit();raise b.Blocked('compressed trace resource boundary reached before next instruction')
   if self.attempted>=12000000 or self.event_ordinal>=5000000:
    self.commit();raise b.Blocked('global finite diagnostic instruction/event budget reached')
   if a==TEXTURE_START:
    self.commit();self.texture_projection();return
   if a==TREE_START:
    self.commit();self.tree_projection();return
   if self.phase=='authored-record-loop' and a==0x484edc:
    self.commit();number=self.reg_value('edi');self.require(self.shadow.reg_get('edi'),b.MASK32,'record ordinal')
    if number!=len(self.records)+1:raise b.Blocked('record iteration missing/duplicated',number=number)
    offset=LEVEL_OFFSET+(number-1)*55;buf=BUFFER+((number-1)%100)*55
    if self.reg_value('esi')!=buf+1 or self.shadow.reg_get('esi')!=b.MASK32:raise b.Blocked('record pointer/order mismatch')
    self.record=number;self.origin={'fileOffset':offset,'block':(number-1)//100,'withinBlock':(number-1)%100}
    self.current_record={'record':number,'fileOffset':offset,'rawHex':self.level[offset:offset+55].hex(),'buffer':hex(buf),'class':self.level[offset+1],'model':self.level[offset],'status':'entered','allocationSequences':[]}
    self.records.append(self.current_record)
  except b.Blocked as error:self.fail(error)
  super()._code(c,a,n,unused)
 def commit(self):
  p=self.pending;pc=p['address'] if p else None
  copy=None
  if pc==0x4eda29:
   ptr=self.reg_value('esi');copy={'record':self.record,'pointer':hex(ptr),'requestedClass':self.reg_value('edx'),'counter':self.reg_value('al'),'knownMask':hex(self.shadow.reg_get('al')),'allocatorSequence':next((f['sequence'] for f in reversed(self.frames) if f['target']=='0x4ed8a0'),None)}
  super().commit()
  if copy is not None:self.counter_copies.append(copy)
  if pc==0x4eda35:self.counter_increments.append({'record':self.record,'class':self.reg_value('edx'),'valueAfter':self.observed(0x96eac1+self.reg_value('edx'),1),'allocatorSequence':next((f['sequence'] for f in reversed(self.frames) if f['target']=='0x4ed8a0'),None)})
  if p:
   touched={a for a,n,old,k in p['journal']}
   if any(a<=byte<a+4 for a in [0x89d178,0x89bc72] for byte in touched):self.rng_writes.append({'pc':hex(pc),'record':self.record,'values':[self.observed(a,4) for a in [0x89d178,0x89bc72]],'committedInstruction':self.committed})
  if pc==0x485035:
   ptr=self.reg_value('ebp');self.publications.append({'record':self.record,'pointer':hex(ptr),'publishedID':self.observed(ptr+8,4),'object':self.object_snapshot(ptr)})
  if pc==0x485038 and self.current_record is not None:self.current_record['status']='completed';self.current_record['completedInstruction']=self.committed
 def _plan(self,ins):
  if self.plan_unknown_stat_increment(ins):return
  m=ins.mnemonic;ops=ins.operands;x=self.cs_module.x86;plan=self.pending
  # No segment/address/lock/repetition extensions. Operand-size66 is admitted
  # only for the finite integer forms below.
  if m in b.BRANCH_FLAGS:
   self.require(self.shadow.reg['eflags'],b.BRANCH_FLAGS[m],'branch flags',instruction=m)
   f=self.reg_value('eflags');cf=bool(f&b.CF);zf=bool(f&b.ZF);sf=bool(f&b.SF);of=bool(f&b.OF);pf=bool(f&b.PF)
   taken={'je':zf,'jne':not zf,'ja':not cf and not zf,'jae':not cf,'jb':cf,'jbe':cf or zf,'jg':not zf and sf==of,'jge':sf==of,'jl':sf!=of,'jle':zf or sf!=of,'jo':of,'jno':not of,'js':sf,'jns':not sf,'jp':pf,'jnp':not pf}[m]
   if taken:
    target=self.scalar(ops[0],ins)
    if target!=self.stop:self.check_target(target)
   return
  extensions={'shl','shr','sar','ror','imul','div','idiv','neg','not','adc','sbb'}
  if m in extensions:
   if any(p not in (0,0x66) for p in ins.prefix):raise b.Blocked('unsupported constructor integer prefix')
   if any(op.size not in (1,2,4) for op in ops if op.type!=x.X86_OP_IMM):raise b.Blocked('unsupported constructor integer width')
  if m=='sub' and len(ops)==2 and ops[0].type==ops[1].type==x.X86_OP_REG and ops[0].reg==ops[1].reg:
   self.destination(ops[0],(1<<(8*ops[0].size))-1,ins);self.flags(b.ARITH);return
  if m in ['shl','shr','sar','ror']:
   if len(ops)!=2 or ops[1].type!=x.X86_OP_IMM or ops[0].type not in (x.X86_OP_REG,x.X86_OP_MEM):raise b.Blocked('only immediate shifts/rotates admitted')
   bits=ops[0].size*8;count=ops[1].imm&31
   if not count:
    if ops[0].type==x.X86_OP_MEM:
     _,known,_=self.operand(ops[0],ins);self.destination(ops[0],known,ins)
    return
   if count>=bits:raise b.Blocked('shift count at/above width is not admitted')
   self.scalar(ops[0],ins);self.destination(ops[0],(1<<bits)-1,ins)
   if m=='ror':self.flags(b.CF|(b.OF if count==1 else 0),b.CF|b.OF)
   else:self.flags(b.CF|b.PF|b.ZF|b.SF|(b.OF if count==1 else 0))
   return
  if m=='imul':
   if len(ops)==3 and ops[0].type==x.X86_OP_REG and ops[2].type==x.X86_OP_IMM and ops[0].size in (2,4):
    self.scalar(ops[1],ins);self.destination(ops[0],(1<<(8*ops[0].size))-1,ins);self.flags(b.CF|b.OF);return
   return super()._plan(ins)
  if m in ['div','idiv'] and len(ops)==1 and ops[0].type==x.X86_OP_REG and ops[0].size==2:
   for reg in ['ax','dx']:self.require(self.shadow.reg_get(reg),65535,'16-bit division dividend',register=reg)
   self.scalar(ops[0],ins);plan['registers'].update(ax=65535,dx=65535);self.flags(0);return
  if m in ['not','neg'] and len(ops)==1:
   self.scalar(ops[0],ins);self.destination(ops[0],(1<<(8*ops[0].size))-1,ins)
   if m=='neg':self.flags(b.ARITH)
   return
  if m in ['adc','sbb']:
   self.require(self.shadow.reg['eflags'],b.CF,'arithmetic carry')
   same=m=='sbb' and ops[0].type==ops[1].type==x.X86_OP_REG and ops[0].reg==ops[1].reg
   if not same:
    for op in ops:self.scalar(op,ins)
   self.destination(ops[0],(1<<(8*ops[0].size))-1,ins);self.flags(b.ARITH);return
  return super()._plan(ins)

def entry_conditions(case):
 return [
 'This is a conditioned selected-state seam, not a captured original Mission3 startup. Omitted earlier game/UI/audio/OS calls are not proved neutral.',
 'Landscape mode005d45a8=3 at first selected kernel, preserved through selected setup. Source changed-landscape path stores raw HDR landscape25 (not filename character) at0042b35e and calls004bd230, whose004bd233 writes3; prior-history lifetime remains an explicit seam condition.',
 'At the exact class2/model1 texture/cache loop, unknown resource3/resource1/texture pointers designate valid live storage. Every possible opaque write is disjoint from all mapped game state, selected assets, and scratch stack; only declared stack temporaries and direct dirty grid are exempt. Omitted work completes normally; its outputs remain unknown and later decisive consumption aborts.',
 'Initializer-suppression BYTE[0089ce37] equals0 at the first selected kernel and survives selected setup and omitted history to the record loop. Special class2 producer004b89ee can write1; allocator clears004edac9/004edcba occur only afterward and do not prove this entry condition.',
 'RNG DWORDs0089d178/0089bc72 equal09d78afe and all12 class counters0096eac1..cc equal0 at first selected kernel; every genuine selected setup kernel must preserve them. There is no reseed before the record loop.',
 'All supplied earlier-produced selected state and pointer mappings retain their values across omitted intervening callers until their next genuine producer. This includes every known byte later consumed, not only final reported counters.',
 'Canonical asset transports succeed into live disjoint abstract allocations with the declared addresses. Addresses are an explicit concrete seam condition; this diagnostic does not claim invariance under arbitrary heap relocation.',
 'At each20 block boundary, omitted message/file operations return normally, preserve all prior known game state outside specified buffer/bytecount/stack footprints, preserve nonvolatile registers and caller frame, and write the exact canonical next0x157c bytes. Volatile registers, arithmetic flags and all scratch stack bytes below the frame are invalidated.',
 'Model-derived terrain bytes use the hashed native-validated TypeScript model under land80clear. They are not exact native Mission3 output; genuine constructor terrain-sensitive decisions can change if these supplied bytes differ.',
 'Actual interface state10, player0, tribe count/owner limit3 and tutorial-load bit clear retain their named source producers; queued interface2 is not substituted.',
 f'Land08 is explicitly {case}; actual prior campaign history remains unresolved.',
 'The exact85-byte scenery tribe-proximity loop is omitted gameplay-derived output; four flag bytes and uncertain CPU live-outs become unknown. No other scenery instructions or allocations are omitted. Later decisive consumption aborts.',
 'DF=0 and declared flat32-bit valid scratch frames hold at selected producer boundaries. All other unsupplied mutable memory/register bits remain unknown.']

def mapped_assets():
 return [('objects/objs0-6.dat',OBJECTS),('objects/facs0-6.dat',FACES),('objects/pnts0-6.dat',POINTS),('objects/shapes.dat',SHAPES),('data/vstart-0.ani',RAWSTARTS),('data/vfra-0.ani',RAWFRAMES),('data/vele-0.ani',VELE),('objects/aniob0-6.dat',0x5aa118),('objects/morph0-6.dat',0x87cc08)]

def prepare(out,case):
 if case not in v.CASES:raise b.Blocked('explicit land case required')
 pe=b.load_pe();import capstone
 cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);windows=[]
 for lo,hi in ranges():
  raw=pe.read(lo,hi-lo);ins=list(cs.disasm(raw,lo))
  if sum(i.size for i in ins)!=len(raw):raise b.Blocked('split constructor diagnostic window',start=hex(lo),end=hex(hi))
  windows.append({'start':hex(lo),'endExclusive':hex(hi),'sha256':b.sha(raw)})
 level=(b.GAME/'levels/levl2003.dat').read_bytes();records=[level[LEVEL_OFFSET+i*55:LEVEL_OFFSET+(i+1)*55] for i in range(2000)]
 if len(level)!=192137 or sum(r[1]!=0 for r in records)!=109:raise b.Blocked('canonical StageA record layout drift')
 prerequisite=json.loads((HERE/'first-hut-source/source-contract.json').read_text())
 if prerequisite['status']!='SOURCE_ONLY_NO_NATIVE_EXECUTION' or not all(x['passed'] for x in prerequisite['assertions']):raise b.Blocked('first-hut source contract not verified')
 terrain=json.loads((TERRAIN/'receipt.json').read_text())
 input_files=[b.file_record(b.GAME/f) for f in sorted(set(ASSETS))]
 # Hash all model source/input/output artifacts, not just the model receipt.
 model_files=[b.file_record(p) for p in [HERE/'prepare_constructor_terrain.mjs',b.ROOT/'app/native-terrain.ts',b.ROOT/'app/native-math.ts',b.ROOT/'app/original-rules.json',TERRAIN/'receipt.json',TERRAIN/'terrain.bin',TERRAIN/'walk0.bin',TERRAIN/'walk1.bin']]
 for source in terrain['sources']:
  path=Path(source['path']);path=path if path.is_absolute() else b.ROOT/path
  if b.sha(path.read_bytes())!=source['sha256']:raise b.Blocked('model source differs from retained generation receipt',path=str(path))
 for artifact in terrain['files']:
  if b.sha((TERRAIN/artifact['name']).read_bytes())!=artifact['sha256']:raise b.Blocked('model output differs from retained receipt',file=artifact['name'])
 if b.sha((TERRAIN/'terrain.bin').read_bytes())!='b8818040d5899527f659648007468516bca0725e182b70e96835ceff28210e7c':raise b.Blocked('conditioned model terrain drift')
 m={'status':'PREPARED_CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_NOT_EXECUTED','originalInstructionsExecuted':0,'scope':SCOPE,'landCase':case,'driver':b.file_record(Path(__file__)),'frozenPreloader':b.file_record(FROZEN),'source':b.source_identity(),'executable':b.file_record(b.EXE),'inputFiles':input_files,'boundFiles':[b.file_record(p) for p in BOUND_FILES],'modelFiles':model_files,'modelReceipt':terrain,
  'firstHutSourceContract':b.file_record(HERE/'first-hut-source/source-contract.json'),'firstHutSourceAuditScript':b.file_record(HERE/'prepare_first_hut_contract.py'),'frozenPriorLedger':b.file_record(HERE/'constructor_ledger_candidate.py'),'allowedWindows':windows,'recordEntry':hex(ENTRY),'firstRecordBody':hex(0x484edc),'nextTransportBoundary':hex(NEXT),'finalStopBeforeGlobalPostpass':hex(FINAL),
  'conditions':entry_conditions(case),'preloaderInputs':v.entry_contract(case),
  'mutableCanonicalTableCondition':{'start':'0x5a6830','endExclusive':'0x5aa600','source':'canonical mutable class/model/object descriptors at seam, then apply all244 source-bound constant.dat writes; no universal pre-entry nonmutation claim'},
  'immutablePEInputs':'File-backed .text, first RX CSEG and .rdata bytes are immutable source data. Execution remains restricted to exact approved windows, never whole sections.',
  'mappedAssets':[{'file':f,'address':hex(a),'bytes':(b.GAME/f).stat().st_size,'sha256':b.sha((b.GAME/f).read_bytes())} for f,a in mapped_assets()],
  'abstractAllocations':[{'name':name,'address':hex(a),'bytes':n,'initialContents':'unknown unless canonical raw file supplied'} for name,a,n in [('objects',OBJECTS,8532),('faces',FACES,680940),('points',POINTS,59508),('rawFrames',RAWFRAMES,31688),('rawStarts',RAWSTARTS,3168),('vele',VELE,160760),('starts',STARTS,4752),('frames',FRAMES,23766),('chains',CHAINS,7922),('shapes',SHAPES,(b.GAME/'objects/shapes.dat').stat().st_size),('transportBuffer',BUFFER,0x10000)]],
  'setupOrder':['startup pool bounds004ed820→IDs004ed880→related reserve0049b640; early list construction is omitted under selected-state lifetime condition, later genuine reset rebuilds it','startup animation0042c4b6..0042c5ee','startup shape relocation0040c8a5..0040c8d8','preloader tribe reset0042b7f0','loader pool/field reset004eef50 then terrain zero0042b27f then job-table reset00493a40 at original caller0042b2b6','bank6 relocation0040c920→24aniob rows0040c7d8..0040c818→morph0040ce30→fixedflags00418de0','level terrain-queue reset0044ddc0 at original00484a62, after bank and before declared model terrain',
  'declared model terrain/known walk masks after native terrain zero; source order height→process→walk→third-plane overlay retained by model','genuine64-byte tribe-ID copy00484e09..00484e3a','genuine third lighting byte→sunlight→block count00484e7b..00484e9a','20 conditioned canonical transports and genuine100-slot iterations each'],
  'treeProjection':{'start':hex(TREE_START),'endExclusive':hex(TREE_END),'bytes':85,'sha256':b.sha(pe.read(TREE_START,85)),'requiredCaller':'004ed5b8→004a5ef0','unknownMemory':{'address':'0x96eaba','bytes':4},'unknownRegisters':['eax','edx','ebx','ecx'],'arithmeticFlagsUnknown':True,'omittedOutputKind':'gameplay-derived proximity flags','laterDecisiveReads':'abort'},
  'constructorPrerequisites':{'initializerSuppression':{'address':'0x89ce37','value':0,'kind':'explicit seam/lifetime condition','specialWriter':'004b89ee writes1; later allocator clears do not prove entry'},'landscapeMode':{'address':'0x5d45a8','value':3,'kind':'changed-landscape producer plus explicit seam/lifetime condition'},'genuineAddedProducers':['00493a40 job-table reset','0044ddc0 terrain-queue reset'],'stillUnknown':['sprite animation clock','opaque resource and texture pointers/backing','terrain statistic counters; genuine INC propagates unknown','other unclosed constructor inputs']},
  'terrainQueueBoundary':{'count':'0 at006906d8','dirty':'all0 at0068c6d8..006906d8','source':'genuine0044ddc0 reset plus explicit model final empty queue/dirty condition, checked by frozen model generator','unknownPayloads':[{'address':'0x690ae8','size':2048},{'address':'0x6906e0','size':1024}],'statistics':'remain unknown; reset did not clear them'},
  'textureProjection':{'start':hex(TEXTURE_START),'endExclusive':hex(TEXTURE_END),'sha256':b.sha(pe.read(TEXTURE_START,TEXTURE_END-TEXTURE_START)),'caller':'00403bf3→004bdd40; parent00403a00; class2/model1 only','dirtyGridUnknown':['0x9bc318','0x9bc718'],'opaquePointerAddresses':[hex(a) for a in OPAQUE_POINTERS],'stackUnknown':'SP-156..SP-1 plus own localsSP+16..SP+21 andSP+28..SP+31; saved slotsSP..SP+15 andwidthSP+24..SP+27 retained','registersUnknown':['eax','ebx','ecx','edx','esi','edi','ebp','arithmetic flags'],'preserved':'genuine brightness before and genuine004206d0 dirty OR after','externalOutputCondition':'valid live opaque resource/texture footprints disjoint from mapped game/selected assets/stack; normal completion; all outputs unknown'},
  'lightingDefaultConditions':[{'address':'0x937aae','value':28,'producer':'00401040','source':'earlier sunlight default, unchanged lifetime condition; not DAT transport'},{'address':'0x937aaf','value':15,'producer':'00401040','source':'earlier sunlight default, unchanged lifetime condition; not DAT transport'}],
  'supplySchema':{'supplySequence':'stable zero-based order','beforeEventOrdinal':'apply at this observer insertion boundary; supplies are not native writes/instructions','phase':'source-selected phase label','pc':'boundary PC','mask':'full-known for ordinary memory supply, explicit knownMask for masked/register supply'},
  'outputBudget':{'requiredFreeBytes':REQUIRED_FREE,'traceCompressedByteLimit':TRACE_LIMIT,'finalUncompressedJsonByteLimit':FINAL_JSON_LIMIT,'finalCompressedJsonByteLimit':FINAL_COMPRESSED_LIMIT,'otherOutputAllowance':OTHER_OUTPUT_ALLOWANCE,'freeSpaceMargin':SPACE_MARGIN,'traceFormat':'gzip UTF-8 JSONL with lossless rows and terminal footer','resultFormat':'gzip JSON with uncompressed SHA256/byte length in separate stream receipt; no expanded disk duplicate','resourceStop':'Explicit diagnostic stop before next instruction near compressed budget; complete gzip is closed. If final JSON exceeds its uncompressed/compressed cap, preserve .partial and fail the process rather than truncate silently. External disk interference remains possible.'},
  'budgets':{'globalAttemptedInstructionLimit':12000000,'globalObserverEventLimit':5000000,'perKernelInstructions':3000000,'perKernelTimeoutSeconds':240,'perBlockInstructions':3000000,'perBlockTimeoutSeconds':240,'outerProcessTimeoutSeconds':1200,'expectedSetupCostBasis':'No new performance claim. Accepted run02 setup committed4026774 instructions before record loop; added job reset has27612 bulk DWORD iterations plus120 six-DWORD slot clears, and queue reset has4864 bulk DWORD iterations. Prior exact pool diagnostic retired1507177 instructions; animation is bounded by792 starts,3961 frames,16076 elements and at most792*791/2 prior-chain comparisons. Each setup phase has its own finite cap; no repeated standalone original run is planned.','retainedTrace':'All reads and committed byte writes, invalidations, failed instruction journals and last40 PCs; process timeout retains process logs and any phase receipts written before it.'},
  'recordBlocks':[{'index':i,'fileOffset':LEVEL_OFFSET+i*BLOCK_BYTES,'bytes':BLOCK_BYTES,'sha256':b.sha(level[LEVEL_OFFSET+i*BLOCK_BYTES:LEVEL_OFFSET+(i+1)*BLOCK_BYTES])} for i in range(20)],
  'selectedLedgerContract':{'predeclaredClassSeed':0,'predeclaredRng':'0x09d78afe','expectedTotalClass1Count':None,'recordSlots':2000,'authoredNonempty':109,'successfulReturnedAllocationFields':['pool slot identity','class','model','ownerRaw','state','counter','prev','next'],'publishedRecordFields':['record ordinal','object pointer','published ID'],'allocationOrder':'genuine CALL entry sequence including nested calls; return order separately retained','counterLaw':'For every committed class1 counter-copy/increment pair, copied value is entry seed plus prior committed class1 increments modulo256. A blocked initializer can already have committed the copy/increment; distinguish from fully returned allocations.','rngChronology':'each genuine committed write to either stream, including partial constructors','objectBytes':'all179 raw bytes plus bit masks retained; only predeclared listed fields claim full knownness','diagnosticStop':'first unknown decisive operand/address/branch, unsupported instruction/target, import, x87, fault, or finite budget; retain open calls and all preceding committed mutations'},
  'forbidden':['loader0042b230','all original OS/import calls','all original x87','global postload pass00485050 onward','gameplay004ec630','any instruction outside listed windows'],
  'nativeStatus':'NOT_RUN'}
 b.json_write(out/'constructor-ledger-preflight.json',m);return pe,m

def approval_bindings(m):
 digest=lambda v:b.sha(json.dumps(v,sort_keys=True).encode())
 return {'verdict':'ACCEPT_CONDITIONAL_CONSTRUCTOR_LEDGER_DIAGNOSTIC','parentReleasedRunLane':True,'scope':SCOPE,'landCase':m['landCase'],'driverSha256':b.sha(Path(__file__).read_bytes()),'frozenPreloaderSha256':FROZEN_SHA,'observedSourceHead':m['source']['observedSourceHead'],'sourceBindingSha256':digest(m['source']),'contractBindingSha256':digest({k:val for k,val in m.items() if k not in ['source','driver','nativeStatus','status']})}

def validate_approval(approval,m):
 for k,val in approval_bindings(m).items():
  if approval.get(k)!=val:raise b.Blocked('missing exact constructor diagnostic review/parent release',field=k)
 if m['source']['trackedStatus']:raise b.Blocked('tracked source drift')

def apply_entry(e,pe,m):
 # PE mutable zero-filled memory is never implicitly known.
 for sec in pe.sections:
  if sec['name'] in ['.text','.rdata'] or sec['va']==0x586000:
   e.supply(sec['va'],pe.read(sec['va'],sec['rawSize']),'canonical file-backed immutable PE bytes; no added execution authority')
 e.supply(0x5a6830,pe.read(0x5a6830,0x5aa600-0x5a6830),'explicit mutable canonical class/model descriptor seam condition')
 for a,raw in b.constant_writes(pe):e.supply(a,raw,'source-bound constant.dat descriptor writes;244 total')
 for a in [0x89d178,0x89bc72]:e.supply(a,pack(0x09d78afe),'explicit conditioned initial RNG, preservation asserted through every selected setup kernel')
 e.supply(0x96eac1,bytes(12),'explicit conditioned12 class seeds at first selected kernel')
 e.supply(0x89d180,bytes(4),'reset-produced zero total-unit count retained across omitted history condition')
 for f,a in mapped_assets():e.supply(a,(b.GAME/f).read_bytes(),'successful canonical asset transport; '+f)
 for a,val in [(0x895ec1,OBJECTS),(0x895ecd,OBJECTS+8532),(0x895ec5,FACES),(0x895ec9,POINTS),(0x59df3c,SHAPES),(0x5ca2ec,64),(0x59df44,STARTS),(0x59df48,FRAMES),(0x59df4c,VELE),(0x59df54,CHAINS),(0x59df58,STARTS+4752),(0x59df5c,FRAMES+23766),(0x59df60,VELE+160760),(0x59df68,CHAINS+7922),(0x59df0c,BUFFER)]:e.supply(a,pack(val),'declared successful live allocation/pointer seam; exact selected source descriptor')
 e.supply(0x5d45a8,b'\x03','explicit source-bound changed-landscape mode3 seam and lifetime condition')
 e.supply(0x89ce37,b'\0','explicit initializer-suppression byte0 entry condition; special producer004b89ee can set1, later allocator clear is not provenance')
 e.supply(0x89ce39,b'\x01','source0040c794 bank loaded-before-relocation state, conditioned')
 e.supply(0x88f000,pack(10),'actual globe synchronous interface state10, lifetime conditioned')
 e.supply(0x89c6f0,b'\0','source NewGame player0, lifetime conditioned')
 e.supply(0x96eac0,b'\x03','canonical HDR tribe count3');e.supply(0x96eabf,b'\x03','canonical HDR owner limit3')
 for row in m['preloaderInputs']['maskedSupplies']:e.masked_supply(int(row['address'],16),row['size'],int(row['valueUnderKnownMask'],16),int(row['knownMask'],16),row['source'])
 e.masked_supply(0x89c668,1,0,4,'successful NewGame tutorial bit clear, constructor seam lifetime condition')
 e.masked_supply(0x89c661,1,0,0x80,'explicit model terrain land80clear condition')
 # masked_supply replaces the mask, so combine disjoint predicates explicitly.
 e.masked_supply(0x89c661,2,v.CASES[m['landCase']],0x188,'explicit land100clear/80clear/08case constructor predicates')
 e.masked_supply(0x89d17c,1,0,2,'source later loader0042b2d7 clears game bit2 before constructor; does not justify skipping earlier477780')
 for row in m['preloaderInputs']['ids']:e.supply(int(row['address'],16),bytes([row['value']]),row['source'])
 for row in m['preloaderInputs']['scriptSpans']:e.supply(int(row['address'],16),bytes.fromhex(row['bytesHex']),row['source'])
 for a in s.TRIG:e.supply(a,pe.read(a,4),'canonical sampled trig seam condition')
 e.supply(0x586034,pe.read(0x586034,64),'canonical immutable sqrt table')
 # No palette, camera, sprite tick or tribe start coordinate value is supplied.

def setup(e,m):
 e.root(0x4ed820,'startup pool bounds');e.root(0x4ed880,'startup pool IDs');e.root(0x49b640,'startup related reserve')
 e.phase='startup animation transform';e.boundary_registers(e.phase,{'esi':RAWSTARTS,'edi':RAWFRAMES})
 e.supply(FRAME+0x14,pack(RAWFRAMES+31688),'source animation raw frame end');e.supply(FRAME+0x18,pack(RAWSTARTS+3168),'source animation raw start end')
 e.run(0x42c4b6,0x42c5ee,budget=3_000_000,timeout_us=240_000_000);e.checkpoint_seeds(e.phase)
 if e.shadow.get(CHAINS+6320,1602):raise b.Blocked('animation unwritten tail falsely known')
 e.cut(0x40c8a5,0x40c8d8,'startup shape relocation')
 e.root(0x42b7f0,'preloader tribe reset')
 e.root(0x4eef50,'loader pool reset before terrain zero')
 e.cut(0x42b27f,0x42b281,'loader terrain zero',{'edi':0x8a03e4,'eax':0,'ecx':0x10000})
 e.phase_receipts.append({'phase':'empty-pool-validation','details':b.validate_pool(e)})
 e.root(0x493a40,'loader job-table reset after pool and terrain zero')
 e.root(0x40c920,'bank6 relocation');e.cut(0x40c7d8,0x40c818,'bank6 aniob24 rows');e.root(0x40ce30,'bank6 morph');e.root(0x418de0,'bank6 fixed flags')
 e.root(0x44ddc0,'level terrain-queue reset before model terrain condition')
 for name,a in [('terrain.bin',0x8a03e4),('walk0.bin',0x96aaba),('walk1.bin',0x96caba)]:e.supply(a,(TERRAIN/name).read_bytes(),'explicit hashed model-derived selected terrain input; '+name)
 # Model preprocessing leaves no queued/dirty work, but its historical queue
 # payload bytes are not modeled. Do not retain the earlier reset zeros there.
 e.invalidate_memory(e.reg_value('eip'),0x690ae8,2048,'model terrain boundary: prior queue coordinate payload provenance expires')
 e.invalidate_memory(e.reg_value('eip'),0x6906e0,1024,'model terrain boundary: prior queue condition payload provenance expires')
 level=e.level;e.supply(BUFFER,level[0x14000:0x14040],'successful canonical pre-record64-byte tribe block')
 e.cut(0x484e09,0x484e3a,'genuine tribe ID field copy')
 e.supply(BUFFER,level[0x14040:0x14043],'successful canonical three-byte lighting transport')
 for i,value in enumerate([28,15]):e.supply(0x937aae+i,bytes([value]),'source00401040 earlier default lighting byte; explicit lifetime condition through omitted history, not a DAT copy')
 e.cut(0x484e7b,NEXT,'genuine record-prefix sunlight and block count')
 e.supply(FRAME+0x2c,bytes(16),'source original entry zeroes four per-owner authored-record counts; seam frame condition')
 for i in range(4):e.supply(FRAME+0x40+4*i,pack(i),'source original entry identity owner remapping; seam frame condition')
 e.phase='authored-record-loop'

def ledger_assertions(e,complete):
 # A completed allocator call can return0 on exhaustion. Only successful valid
 # returned nodes are counted, in CALL entry order, not nested return order.
 returned=sorted(e.allocations,key=lambda a:a['sequence']);valid=[]
 for event in returned:
  obj=event['allocation']
  if obj.get('pointer')=='0x0':continue
  if not obj.get('validPoolSlot'):raise b.Blocked('returned allocation pointer invalid/unknown',sequence=event['sequence'])
  for name in ['id','class','model','ownerRaw','state','counter','prev','next']:
   if obj[name]['value'] is None:raise b.Blocked('predeclared returned allocation field unknown',field=name,sequence=event['sequence'])
  valid.append({'sequence':event['sequence'],'originRecord':event['originRecord'],'caller':event['caller'],'pointer':obj['pointer'],'id':obj['id']['value'],'class':obj['class']['value'],'model':obj['model']['value'],'ownerRaw':obj['ownerRaw']['value'],'counter':obj['counter']['value']})
 increments=[x for x in e.counter_increments if x['class']==1];copies=[x for x in e.counter_copies if x['requestedClass']==1]
 for i,row in enumerate(copies):
  if row['knownMask']!='0xff' or row['counter']!=i%256:raise b.Blocked('class1 committed counter-copy law violated',index=i,row=row)
 if len(increments)>len(copies) or len(copies)>len(increments)+1:raise b.Blocked('committed copy/increment partial transaction mismatch')
 for i,row in enumerate(increments):
  if row['valueAfter']['value']!=(i+1)%256:raise b.Blocked('class1 committed increment law violated',index=i)
 if e.observed(b.SEED,1)['value']!=len(increments)%256:raise b.Blocked('final class1 seed differs from committed genuine increments')
 for row in e.publications:
  if row['publishedID']['value']!=row['record']:raise b.Blocked('record publication ordinal mismatch')
 if complete and (len(e.blocks)!=20 or len(e.records)!=2000 or any(r['status']!='completed' for r in e.records) or e.frames):raise b.Blocked('incomplete StageA mislabeled complete')
 return {'fullyReturnedSuccessfulAllocations':valid,'fullyReturnedSuccessfulClass1Count':sum(x['class']==1 for x in valid),'committedClass1Copies':len(copies),'committedClass1Increments':len(increments),'finalKnownClass1Seed':e.observed(b.SEED,1),'partialInitializersCanAlreadyIncrement':True,'completedRecords':sum(x['status']=='completed' for x in e.records),'lastCompletedRecord':max((x['record'] for x in e.records if x['status']=='completed'),default=None),'fullStageAComplete':complete}

def protect_image(cpu,pe):
 """Original section permissions over mapped PE bytes, never the shadow extent."""
 import unicorn
 data=pe.data;header=struct.unpack_from('<I',data,60)[0];optional=struct.unpack_from('<H',data,header+20)[0]
 base=struct.unpack_from('<I',data,header+24+28)[0];size=struct.unpack_from('<I',data,header+24+56)[0];end=base+((size+4095)&~4095)
 if base!=b.BASE or not size or end>b.END:raise b.Blocked('PE image outside declared shadow domain')
 mapped=[(lo,hi+1) for lo,hi,permissions in cpu.mem_regions()]
 sections=[]
 for i,sec in enumerate(pe.sections):
  flags=struct.unpack_from('<I',data,header+24+optional+i*40+36)[0];perms=0
  if flags&0x40000000:perms|=unicorn.UC_PROT_READ
  if flags&0x80000000:perms|=unicorn.UC_PROT_WRITE
  if flags&0x20000000:perms|=unicorn.UC_PROT_EXEC
  lo=sec['va'];length=(max(sec['virtualSize'],sec['rawSize'])+4095)&~4095;hi=lo+length
  if lo<base or hi>end or lo&4095:raise b.Blocked('PE section protection exceeds actual image',section=sec['name'])
  coverage=sum(max(0,min(hi,z)-max(lo,a)) for a,z in mapped)
  if coverage!=length:raise b.Blocked('PE section has unmapped protection bytes',section=sec['name'])
  sections.append((lo,length,perms))
 # Protect only actual mapped header/inter-section spans inside SizeOfImage.
 # Synthetic gaps stay unmapped; the canonical mapper happens to be contiguous.
 for lo,hi in mapped:
  start=max(base,lo);stop=min(end,hi)
  if start<stop:cpu.mem_protect(start,stop-start,unicorn.UC_PROT_READ)
 for lo,length,perms in sections:
  if length:cpu.mem_protect(lo,length,perms)


def execute(pe,m,approval,out):
 validate_approval(approval,m) # Must precede native_cpu and any original execution.
 storage=check_storage(out) # Conservative byte admission before CPU construction.
 import unicorn,capstone
 helper=b.load_module('ledger_native_helper',b.ROOT/'scripts/decomp.py');cpu,identity=helper.native_cpu(b.EXE);cpu.mem_map(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)
 e=Ledger(cpu,[(b.BASE,b.END-b.BASE),(b.SCRATCH,b.SCRATCH_END-b.SCRATCH)],ranges(),iat=pe.imports,level=(b.GAME/'levels/levl2003.dat').read_bytes(),enable_tree_projection=True,enable_texture_projection=True)
 protect_image(cpu,pe)
 e.forbidden[FINAL]='global post-load callbacks, outside StageA'
 error=None;complete=False;claims=None;started=time.monotonic()
 trace=GzipTrace(out/'constructor-ledger-events.jsonl.gz');e.trace_sink=trace
 try:
  apply_entry(e,pe,m);setup(e,m)
  for i in range(20):
   e.transport(i);e.run(ENTRY,NEXT if i<19 else FINAL,budget=3_000_000,timeout_us=240_000_000)
  claims=ledger_assertions(e,True);complete=True;status='CONDITIONAL_STAGEA_LEDGER_COMPLETE'
 except BaseException as exc:
  complete=False
  error={'type':type(exc).__name__,'message':str(exc),'details':getattr(exc,'details',None)};status='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_STOP'
  try:claims=ledger_assertions(e,False)
  except BaseException as assertion:claims={'partialLedgerAssertionFailure':str(assertion),'details':getattr(assertion,'details',None)};status='CONDITIONAL_CONSTRUCTOR_DIAGNOSTIC_INVALID'
 trace.flush();trace.close();e.trace_sink=None
 result={'status':status,'scope':SCOPE,'complete':complete,'identity':identity,'tools':{'python':sys.version,'unicorn':unicorn.__version__,'capstone':capstone.__version__,'platform':platform.platform()},'runtimeSeconds':time.monotonic()-started,'conditions':m['conditions'],'selectedLedgerContract':m['selectedLedgerContract'],'attemptedOriginalInstructions':e.attempted,'committedOriginalInstructions':e.committed,'phaseReceipts':e.phase_receipts,'blocks':e.blocks,'records':e.records,'calls':e.events,'openCalls':e.frames,'returnedAllocations':e.allocations,'counterCopies':e.counter_copies,'counterIncrements':e.counter_increments,'rngWrites':e.rng_writes,'publications':e.publications,'selectedAssertions':claims,'projections':e.projections,'blocker':e.blocker,'error':error,'abortedInstructions':e.aborted,'lastPCs':e.last,'finalRegisters':e.register_snapshot(),'finalSeeds':selected_seeds(e),'finalLists':e.snapshot(),'suppliedInputs':e.supplies,'memoryReads':e.read_events,'memoryWrites':e.write_events,'invalidationEvents':e.invalidation_events,'eventStream':e.event_stream(),'driver':b.file_record(Path(__file__)),'source':m['source'],'rawEventTrace':{**stream_file_record(out/'constructor-ledger-events.jsonl.gz'),'uncompressedBytes':trace.uncompressed_bytes,'uncompressedSha256':trace.uncompressed_hash.hexdigest()},'storageAdmission':storage}
 stream_receipt=write_bounded_json(out/'constructor-ledger-result.json.gz',result)
 b.json_write(out/'constructor-ledger-result-stream-receipt.json',stream_receipt);return result

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('mode',choices=['prepare','run-ledger']);ap.add_argument('--case',choices=list(v.CASES),required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--approval',type=Path);a=ap.parse_args()
 if a.out.exists():raise b.Blocked('new output directory required')
 a.out.mkdir(parents=True);pe,m=prepare(a.out,a.case)
 if a.mode=='prepare':print(json.dumps({'status':m['status'],'windows':len(m['allowedWindows']),'originalInstructionsExecuted':0}));return
 if not a.approval:raise b.Blocked('fresh exact review and parent release required')
 r=execute(pe,m,json.loads(a.approval.read_text()),a.out);print(json.dumps({'status':r['status'],'committedOriginalInstructions':r['committedOriginalInstructions'],'blocker':r['blocker'],'error':r['error'],'selectedAssertions':r['selectedAssertions']}))
 if r['status']!='CONDITIONAL_STAGEA_LEDGER_COMPLETE':raise SystemExit(2)
if __name__=='__main__':main()
