import java.nio.file.*;
import ghidra.app.script.GhidraScript;
public class FirstHutBounds extends GhidraScript {
 public void run() throws Exception {
  StringBuilder o=new StringBuilder();
  for(long a:new long[]{0x00493a40L,0x00493770L,0x0044ddc0L,0x0044ddf0L,0x004b9ef0L,0x00403a00L,0x00403f00L,0x00450d50L,0x004bdd40L,0x004bee20L,0x004bf1b0L,0x004206d0L}) {
   var f=getFunctionAt(toAddr(a));
   if(f==null){o.append("MISSING\t").append(Long.toHexString(a)).append("\n");continue;}
   o.append("FUNCTION\t").append(f.getEntryPoint()).append("\t").append(f.getName()).append("\n");
   for(var range:f.getBody().getAddressRanges()) o.append("RANGE\t").append(f.getEntryPoint()).append("\t").append(range.getMinAddress()).append("\t").append(range.getMaxAddress().add(1)).append("\n");
   for(var i:currentProgram.getListing().getInstructions(f.getBody(),true)) {
    if(i.getFlowType().isCall() || i.getFlowType().isJump()) {
     var flows=i.getFlows();boolean emitted=false;
     for(var target:flows) if(i.getFlowType().isCall() || !f.getBody().contains(target)) {o.append("FLOW\t").append(f.getEntryPoint()).append("\t").append(i.getAddress()).append("\t").append(i.getFlowType()).append("\t").append(target).append("\t").append(i.toString()).append("\n");emitted=true;}
     if(flows.length==0) o.append("INDIRECT\t").append(f.getEntryPoint()).append("\t").append(i.getAddress()).append("\t").append(i.getFlowType()).append("\t").append(i.toString()).append("\n");
    }
   }
  }
  Files.writeString(Path.of(getScriptArgs()[0]),o.toString());println("CONSTRUCTOR_SELECTED_HELPERS_COMPLETE");
 }
}
