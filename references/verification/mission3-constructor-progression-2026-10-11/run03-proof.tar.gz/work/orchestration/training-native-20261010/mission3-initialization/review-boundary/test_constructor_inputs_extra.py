"""Independent synthetic-only follow-up tests; no canonical PE loaded/executed."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'harness-repair'))
import constructor_ledger_inputs_candidate as l
import test_constructor_ledger_inputs as authored
b=l.b
class IndependentInputsTests(unittest.TestCase):
 def test_stat_inc_preserved_known_carry_can_decide_but_unknown_carry_stops(self):
  for pc,address in l.STAT_INCREMENTS.items():
   for cf in (0,1,None):
    e=authored.StatisticExecutionTests().make(pc,address,0xffffffff,0,cf,b'\x72\x00')
    if cf is None:
     with self.assertRaisesRegex(b.Blocked,'branch flags'):e.run(pc,pc+8)
     self.assertEqual(e.committed,1)
    else:e.run(pc,pc+8);self.assertEqual(e.committed,2)
    self.assertEqual(e.shadow.get(address,4),0)
 def test_partial_opaque_pointer_is_rejected_before_any_projection_mutation(self):
  for address in l.OPAQUE_POINTERS:
   for mask in (1,0xff000000,0x0000ffff):
    e,sp,ptr=authored.FirstHutRepairTests().texture();e.shadow.put(address,4,mask)
    with self.assertRaisesRegex(b.Blocked,'opaque resource pointer'):e.texture_projection()
    self.assertEqual(e.shadow.get(0x9bc318,1),255);self.assertEqual(e.shadow.get(sp,16),(1<<128)-1);self.assertFalse(e.projections)
 def test_projection_cpu_output_is_not_consumed_as_known(self):
  e,sp,ptr=authored.FirstHutRepairTests().texture();e.texture_projection();e.frames=[]
  code=b.BASE;e.cpu.mem_write(code,b'\x83\xf8\x00');e.windows.append((code,code+3))
  with self.assertRaisesRegex(b.Blocked,'unbound'):e.run(code,code+3)
  self.assertEqual(e.committed,0)
if __name__=='__main__':unittest.main()
