# Conditional StageA input consolidation after reviewed partial run02

This is a separate candidate. `constructor_ledger_candidate.py` (9b601521…) and both prior runs remain unchanged. Run02 reached the first class2/model1 allocation, committed its counter copy0/increment1, then stopped at the unknown initializer-suppression byte. It returned no allocations and completed no records. This packet does not reclassify that result.

## Scope and source conditions

The same single land-clear/class-seed0/RNG09d78afe case remains. The genuine20×100 record transport/order, nested allocation calls, per-record postprocessing and ID publication remain, stopping before00485050 global callbacks. Unknown decisive inputs and unsupported targets/imports/x87 still stop. This is a conditional selected-state ledger, not a captured Mission3 startup or proof of its final allocation count.

Two explicitly named entry conditions are added before the first selected setup kernel:

- BYTE0089ce37=0: initializer suppression is clear. The special class2 producer004b89ee writes1. Later clears004edac9/004edcba cannot establish the first value. Every selected setup checkpoint verifies preservation; no reseed/re-supply occurs at the record loop.
- BYTE005d45a8=3: landscape mode3. Canonical HDR[96..98]=25,6,0 passes through the real globe/preloader arguments.0042b35e writes raw landscape25 to0089ce3d.0042a3aa converts a separate filename character to'p'; it does not turn that global into ASCII.0042b389 compares raw25 with0x36(54), choosing004bd230 on the changed-landscape path;004bd233 writes3. Same-landscape/prior-history and omitted-caller preservation remain conditions, not proved history.

Other prior seam conditions remain in the preflight, including mutable class/model tables with all244 constant writes, live concrete selected asset buffers, RNG/class counters, pool/tribe state, named mode bits and successful transport preservation of every previously known game byte later consumed. Model-derived terrain remains separately identified and hashed; it is not exact native Mission3 output.

## Genuine added producers and execution windows

-00493a40 runs after genuine pool reset004eef50/terrain zero0042b27f and before bank relocation, matching caller0042b2b6. It clears110448 bytes at0093a770, establishes manager fields and120 job records at0093a7a0 (stride24). This closes the actual first-hut00493770 job-table read.
-0044ddc0 runs after bank setup and before the model terrain condition, matching00484a62. It clears2048 coordinate bytes00690ae8,1024 conditional bytes006906e0,16384 dirty bytes0068c6d8, and queue count006906d8. The model condition ends with empty queue/dirty state, so these control outputs remain compatible. The historical coordinate/conditional queue payloads are invalidated after the model boundary; reset zeros must not remain falsely known across omitted preprocessing. The frozen model generator explicitly asserts empty queue, dirty array and recursion state before publishing its receipt.
-The newly bounded genuine first-hut helpers include00493770,004b9ef0,00403a00,00403f00,00450d50,004bdd40 and004206d0. The texture leaf bodies are source-audited but excluded from executable windows. Queue flush0044df40 remains an explicit unsupported target if reached. No broader renderer reconstruction is claimed.

Queue reset does not initialize0068c6d0 or006906dc. Only their exact original INC sites0044de5b/0044deab gain conservative unknown propagation: the real DWORD read/write executes; result and OF/SF/ZF/AF/PF remain unknown; CF is preserved. No guessed counter input is supplied. Following canonical CMP instructions kill the uncertain flags before their branch decisions. Any later decisive read of these unknown counters still stops.

## Texture/cache output projection

Retain the real mode3 branch and entire brightness loop. Only004bdebe..004bdfdb is omitted. Resume at the genuine004206d0 call, then execute the native saved-register/stack epilogue.

Admission requires the actual authored-loop phase, top call00403bf3→004bdd40 with return00403bf8, parent target00403a00, and a known class2/model1 object from that parent's genuine argument. ESP must equal the recorded pre-CALL stack minus36; position/radius/width must be known, radius1..128, width2*radius+1. Both targets must be admitted. Resource3, resource1 and texture pointer words at009bcfc8,009bcfd8 and005d45b0 must remain completely unknown; a known-null or partially known fixture is rejected.

At projection ESP=S:

- Taint the complete1024-byte dirty grid009bc318..009bc718.
- Taint[S−156,S), covering arguments, return slot, maximum0x80 leaf locals and four saved GPRs.
- Taint only direct own-local outputs[S+16,S+22) and[S+28,S+32). Preserve saved slots[S,S+16) and untouched width[S+24,S+28).
- Taint EAX/EBX/ECX/EDX/ESI/EDI/EBP and arithmetic flags. Preserve ESP and unrelated flags. Native POPs restore the saved nonvolatiles later.

The two source leaves004bee20 and004bf1b0 contain no calls. Their only non-stack write sites store one texture byte per8×8 loop, eight rows with stride256. For byte tile coordinates the destination domain is1MiB. The skipped outer loop's other writes are metadata byte2/3 through signed resource indices and direct dirty-grid bytes. Resource3 index reads occupy a32768-byte domain. No original RNG, pool, class-counter write or allocator call is present in this source closure.

This footprint still needs a strong explicit alias/termination condition: all opaque source and destination accesses are valid live domains, signed metadata indices are in their valid allocation range, and every opaque write is disjoint from all mapped game/executable/input/selected asset bytes and live stack except the declared scratch footprint. These allocations are not fabricated or mapped as known zero. Their pointers and backing remain unknown. This is not universal alias independence, recovered original allocation addresses, or a claim that the omitted code could not fault. Normal completion is conditional. Later decisive reads of resource pointers/backing or direct dirty outputs abort.

No invented CALL/RET events, OS return values or texture bytes are emitted. Projection invalidations retain observer ordinals; the projection envelope is separate from genuine instructions/calls. The earlier separately reviewed scenery proximity projection remains unchanged and is gameplay-derived.

## Evidence and resource limits

`prepare_first_hut_contract.py` is source-only and binds full canonical windows, exact source write/call sites, selector/producers, texture range arithmetic and stack bounds. `first-hut-source/export-receipt.json` retains the read-only/noanalysis12-root Ghidra batch and missing fade-leaf export. Two earlier tool-start failures were configuration-directory errors before project access and are retained beside it.

Prior run02 setup committed4026774 instructions before the record loop. Added job/queue producers are finitely bounded (27612 bulk job DWORDs plus120×6 slot DWORDs;4864 queue DWORDs). Existing per-phase3million/global12million instructions,5million observer events,240-second phase and1200-second process caps remain. This is a cost bound for admission, not a performance prediction or promise that all109 authored records will finish. Compressed trace/result budgets and free-space admission remain unchanged; resource stops preserve their distinction from completed ledgers.

Every original run still requires fresh hash-bound review and a separate parent lane release. No new original run occurred while preparing this packet.
