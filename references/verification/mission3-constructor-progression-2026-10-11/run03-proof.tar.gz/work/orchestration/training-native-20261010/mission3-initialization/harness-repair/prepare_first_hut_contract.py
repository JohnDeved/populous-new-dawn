#!/usr/bin/env python3
"""Source-only first-hut prerequisite/projection audit. Never constructs a CPU."""
from pathlib import Path
import hashlib,json,struct
import constructor_ledger_candidate as old
import capstone
b=old.b;H=Path(__file__).resolve().parent;O=H/'first-hut-source'
def main():
 p=b.load_pe();cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32);cs.detail=True
 assertions=[];windows=[]
 def check(name,value):
  assert value,name
  assertions.append({'name':name,'passed':True})
 def window(name,a,z):
  raw=p.read(a,z-a);ins=list(cs.disasm(raw,a));check(name+' complete decoding',sum(i.size for i in ins)==len(raw))
  windows.append({'name':name,'start':hex(a),'endExclusive':hex(z),'sha256':b.sha(raw),'instructions':[{'pc':hex(i.address),'bytes':i.bytes.hex(),'mnemonic':i.mnemonic,'operands':i.op_str} for i in ins]});return ins
 def byte(pc,raw):check(hex(pc)+' source bytes',p.read(pc,len(bytes.fromhex(raw)))==bytes.fromhex(raw))
 for n,a,z in [('suppression special writer',0x4b89d7,0x4b89f3),('allocator suppression gate and clear',0x4eda87,0x4edad7),('secondary suppression gate and clear',0x4edc84,0x4edcc3),('loader producer order',0x42b230,0x42b3cd),('level queue producer order',0x484a10,0x484a67),('raw landscape selector',0x42b34e,0x42b39e),('filename char independent',0x42a39a,0x42a3ad),('mode2 producer',0x4bd170,0x4bd177),('mode3 producer',0x4bd230,0x4bd23a),('globe header operands',0x4859d8,0x4859f6),('globe loader args',0x485a7b,0x485a8b)]:window(n,a,z)
 byte(0x4b89ee,'a237ce8900');byte(0x4eda87,'380d37ce8900');byte(0x4edac9,'c60537ce890000');byte(0x4edc84,'803d37ce890000');byte(0x4edcba,'c60537ce890000')
 byte(0x42b35e,'881d3dce8900');byte(0x42b389,'803d3dce890036');byte(0x4bd233,'c605a8455d0003');byte(0x42a3aa,'80c357')
 hdr=(b.GAME/'levels/levl2003.hdr').read_bytes();check('canonical HDR landscape25 bank6 flags0',list(hdr[96:99])==[25,6,0]);check('raw25 differs from selector54',hdr[96]!=0x36);check('filename char is p',hdr[96]+0x57==ord('p'))
 roots={}
 for row in (O/'first-hut-bounds.tsv').read_text().splitlines():
  r=row.split('\t')
  if r[0]=='RANGE':roots[int(r[1],16)]=window('helper '+r[1],int(r[2],16),int(r[3],16))
 check('all12 exact roots found',len(roots)==12)
 texture=window('omitted texture resource loop',0x4bdebe,0x4bdfdb)
 writes=[]
 for i in texture:
  for op in i.operands:
   if op.type==capstone.x86.X86_OP_MEM and op.access&capstone.CS_AC_WRITE:writes.append({'pc':hex(i.address),'instruction':i.mnemonic+' '+i.op_str,'bytes':op.size,'base':i.reg_name(op.mem.base),'index':i.reg_name(op.mem.index),'disp':op.mem.disp})
 check('only2 source leaf calls in omitted loop',[i.operands[0].imm for i in texture if i.mnemonic=='call']==[0x4bf1b0,0x4bee20])
 external=[w for w in writes if w['base']!='esp'];check('exact3 external write sites',[w['pc'] for w in external]==['0x4bdf4c','0x4bdf56','0x4bdfaf'])
 check('metadata writes are bytes2/3 atindex8',[(w['bytes'],w['disp']) for w in external[:2]]==[(1,2),(1,3)])
 leaf_summary=[]
 for start,store in [(0x4bee20,0x4bf14e),(0x4bf1b0,0x4bf59c)]:
  ins=roots[start];check(hex(start)+' leaf no calls',not any(i.mnemonic=='call' for i in ins));check(hex(start)+' leaf no x87',not any(i.mnemonic.startswith('f') for i in ins))
  nonstack=[]
  for i in ins:
   for op in i.operands:
    if op.type==capstone.x86.X86_OP_MEM and op.access&capstone.CS_AC_WRITE and op.mem.base!=capstone.x86.X86_REG_ESP:nonstack.append(i)
  check(hex(start)+' exactly one nonstack store site',[i.address for i in nonstack]==[store]);leaf_summary.append({'entry':hex(start),'onlyNonstackWritePC':hex(store),'writeSize':1,'count':'8 rows times8 bytes','rowStride':256,'normalReturn':'preserves EBX/ESI/EDI/EBP with real prologue/epilogue; EAX/ECX/EDX and arithmetic flags uncertain'})
 check('dirty grid indices cover exactly0..1023',{(x>>2)+(y&~3)*8 for x in range(128) for y in range(128)}==set(range(1024)))
 offsets=[(x&~31)*2048+(x&31)*8+(y&~31)*8192+(y&31)*2048 for x in range(128) for y in range(128)]
 check('texture tiled stores confined to1MiB',min(offsets)==0 and max(offsets)+7*256+8==0x100000)
 check('largest skipped leaf stack footprint is156',8+4+0x80+16==0x9c)
 byte(0x403bf3,'e848a10b00');byte(0x4bdd40,'83ec10');byte(0x4bdd43,'803da8455d0003');byte(0x4bdfdb,'e8f026f6ff');byte(0x4206d0,'830d70f4640002')
 result={'status':'SOURCE_ONLY_NO_NATIVE_EXECUTION','sourceHead':b.source_identity(),'executable':b.file_record(b.EXE),'script':b.file_record(Path(__file__)),'header':b.file_record(b.GAME/'levels/levl2003.hdr'),'bounds':b.file_record(O/'first-hut-bounds.tsv'),'assertions':assertions,'windows':windows,'skippedLoopExplicitWrites':writes,'textureLeaves':leaf_summary,'proposal':{'range':['0x4bdebe','0x4bdfdb'],'requiredCaller':'00403bf3→004bdd40 under00403a00, class2/model1','retained':'mode3 branch, entire genuine brightness loop, subsequent004206d0 dirty OR, saved nonvolatile slots and native epilogue','unknownOutputs':{'dirtyGrid':['0x9bc318','0x9bc718'],'stackRelativeToProjectionESP':[[-156,0],[16,22],[28,32]],'registers':['eax','ebx','ecx','edx','esi','edi','ebp'],'flags':'arithmetic flags only'},'aliasCondition':'resource index domain32768 bytes, signed metadata index accesses and1MiB texture destination mapping are valid live storage. Every opaque write is disjoint from all mapped game/executable/input/selected asset state and live stack except explicitly tainted scratch footprint. Resource pointers and backing remain unknown. This is an entry condition, not recovered original mapping or universal alias proof.','normalCompletionCondition':True,'laterConsumers':'Any decisive read of unknown resource pointer, metadata/texture output or direct dirty bytes aborts.','allocationFootprint':'No RNG/class/pool writes or allocation calls in skipped source under stated disjointness; reads and arithmetic themselves are not reproduced.'},'openFrontiers':['Terrain queue flush0044df40 is not newly admitted; source partial diagnostic stops if reached.','Other unclosed constructor-critical inputs/targets remain fail-closed.','Land08clear and RNG/class seeds remain explicit conditions.']}
 b.json_write(O/'source-contract.json',result);print(json.dumps({'assertions':len(assertions),'windows':len(windows),'sha256':b.sha((O/'source-contract.json').read_bytes())}))
if __name__=='__main__':main()
