/* Ghidra 12.1.3 pseudocode; entry 004bf1b0; FUN_004bf1b0.
 * See ../README.md and ../exports.json. Types/names may be inferred. Not compilable original source. */


void FUN_004bf1b0(ushort param_1,undefined1 *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  ushort uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  char *pcVar15;
  char *pcVar16;
  int iVar17;
  int iVar18;
  undefined1 *puVar19;
  undefined4 local_80;
  int local_7c;
  int local_78;
  int local_74;
  int local_70;
  int local_6c;
  int local_68;
  int local_64;
  int local_60;
  int local_5c;
  int local_58;
  int local_54;
  int local_50;
  int local_4c;
  int local_2c;
  uint local_28;
  int local_24;
  uint local_20;
  int local_1c;
  uint local_18;

  uVar8 = (param_1 & 0xfe) * 2 | param_1 & 0xfe00;
  uVar9 = (uint)(byte)(&DAT_008a03f1)[uVar8 * 4];
  local_7c = (short)(&DAT_008a03e8)[uVar8 * 2] + 0x4b;
  if (((&DAT_008a03ee)[uVar8 * 4] != 0) &&
     (local_7c = (short)(&DAT_008a03e8)[uVar8 * 2] + 0x96, 0x3fe < local_7c)) {
    local_7c = 0x3fe;
  }
  local_6c = 0x20;
  uVar10 = (uint)(byte)(&DAT_008a03ee)[uVar8 * 4];
  if ((*(byte *)(&DAT_008a03e4 + uVar8) & 8) == 0) {
    local_6c = 0;
  }
  bVar6 = (byte)(param_1 >> 8);
  uVar7 = CONCAT11(bVar6,(byte)param_1 + 2);
  local_80 = (uint)uVar7;
  uVar8 = (local_80 & 0xfe) * 2 | uVar7 & 0xfe00;
  bVar1 = (&DAT_008a03f1)[uVar8 * 4];
  local_74 = (short)(&DAT_008a03e8)[uVar8 * 2] + 0x4b;
  if (((&DAT_008a03ee)[uVar8 * 4] != 0) &&
     (local_74 = (short)(&DAT_008a03e8)[uVar8 * 2] + 0x96, 0x3fe < local_74)) {
    local_74 = 0x3fe;
  }
  local_64 = 0x20;
  if ((*(byte *)(&DAT_008a03e4 + uVar8) & 8) == 0) {
    local_64 = 0;
  }
  local_80._0_2_ = CONCAT11(bVar6 + 2,(byte)param_1 + 2);
  uVar7 = (ushort)local_80;
  local_80 = (uint)(ushort)local_80;
  uVar11 = (local_80 & 0xfe) * 2 | uVar7 & 0xfe00;
  iVar12 = uVar11 * 4;
  bVar2 = (&DAT_008a03f1)[iVar12];
  local_70 = (short)(&DAT_008a03e8)[uVar11 * 2] + 0x4b;
  if (((&DAT_008a03ee)[iVar12] != '\0') &&
     (local_70 = (short)(&DAT_008a03e8)[uVar11 * 2] + 0x96, 0x3fe < local_70)) {
    local_70 = 0x3fe;
  }
  local_60 = 0x20;
  bVar3 = (&DAT_008a03ee)[iVar12];
  if ((*(byte *)(&DAT_008a03e4 + uVar11) & 8) == 0) {
    local_60 = 0;
  }
  uVar7 = CONCAT11(bVar6 + 2,(byte)param_1);
  local_80 = (uint)uVar7;
  uVar11 = (local_80 & 0xfe) * 2 | uVar7 & 0xfe00;
  iVar12 = uVar11 * 4;
  bVar4 = (&DAT_008a03f1)[iVar12];
  local_78 = (short)(&DAT_008a03e8)[uVar11 * 2] + 0x4b;
  if (((&DAT_008a03ee)[iVar12] != '\0') &&
     (local_78 = (short)(&DAT_008a03e8)[uVar11 * 2] + 0x96, 0x3fe < local_78)) {
    local_78 = 0x3fe;
  }
  local_68 = 0x20;
  bVar5 = (&DAT_008a03ee)[iVar12];
  if ((*(byte *)(&DAT_008a03e4 + uVar11) & 8) == 0) {
    local_68 = 0;
  }
  local_5c = (bVar1 - uVar9) * 0x2000;
  local_24 = uVar9 << 0x10;
  local_58 = (local_74 - local_7c) * 0x2000;
  local_20 = local_7c << 0x10;
  iVar12 = (byte)(&DAT_008a03ee)[uVar8 * 4] - uVar10;
  local_54 = iVar12 * 0x2000;
  local_1c = uVar10 << 0x10;
  iVar13 = local_68 - local_6c;
  local_64 = local_64 - local_6c;
  local_50 = local_64 * 0x2000;
  local_18 = local_6c << 0x10;
  local_6c = 8;
  pcVar15 = (char *)(((uint)((bVar6 & 0xe) >> 1) * 0x100 + (uint)(((byte)param_1 & 0xe) >> 1)) *
                     0x20 + DAT_005d45d0);
  do {
    local_2c = local_1c;
    local_28 = local_18;
    local_4c = 8;
    iVar14 = local_24;
    uVar8 = local_20;
    do {
      puVar19 = param_2;
      pcVar16 = pcVar15;
      iVar17 = (int)uVar8 >> 0x10;
      uVar11 = uVar8 & 0xffff00ff;
      uVar8 = uVar8 + local_58;
      iVar18 = (iVar14 >> 0x10) + ((int)*pcVar16 >> 2);
      if ((char)((uint)iVar18 >> 8) != '\0') {
        if (iVar18 < 0) {
          iVar18 = 0;
        }
        else if (0xff < iVar18) {
          iVar18 = 0xff;
        }
      }
      iVar14 = iVar14 + local_5c;
      *puVar19 = (&DAT_0096eae0)
                 [((int)(local_28 & 0xffff00ff) >> 8) +
                  (uint)*(byte *)((uint)*(byte *)(((int)uVar11 >> 8) +
                                                  ((int)((int)*(short *)(DAT_005d45b8 + iVar17 * 2)
                                                         * (int)*pcVar16 & 0xfffffc03U) >> 2) +
                                                  iVar18 + DAT_005d45c8) + (local_2c >> 0x12) * 0x80
                                 + DAT_005d45cc)];
      local_2c = local_2c + local_54;
      local_28 = local_28 + local_50;
      local_4c = local_4c + -1;
      pcVar15 = pcVar16 + 4;
      param_2 = puVar19 + 1;
    } while (local_4c != 0);
    local_24 = local_24 + (bVar4 - uVar9) * 0x2000;
    local_20 = local_20 + (local_78 - local_7c) * 0x2000;
    local_1c = local_1c + (bVar5 - uVar10) * 0x2000;
    local_18 = local_18 + iVar13 * 0x2000;
    param_2 = puVar19 + 0xf9;
    pcVar15 = pcVar16 + 0x3e4;
    local_5c = local_5c +
               ((int)(((uint)bVar2 - (uint)bVar4) * 0x2000 + (bVar1 - uVar9) * -0x2000) >> 3);
    local_58 = local_58 + ((local_70 - local_78) * 0x2000 + (local_74 - local_7c) * -0x2000 >> 3);
    local_54 = local_54 + ((int)(((uint)bVar3 - (uint)bVar5) * 0x2000 + iVar12 * -0x2000) >> 3);
    local_50 = local_50 + ((local_60 - local_68) * 0x2000 + local_64 * -0x2000 >> 3);
    local_6c = local_6c + -1;
  } while (local_6c != 0);
  return;
}
