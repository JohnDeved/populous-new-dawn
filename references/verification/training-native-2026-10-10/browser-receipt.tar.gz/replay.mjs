// Execute only the production browser-model approach/admission callers. This
// diagnostic is not a full world tick, rendered browser, ordinary UI, or fix.
import { patchedSources } from './observe-loader.mjs'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import assert from 'node:assert/strict'
import { decodePerson, decodeBuilding, personFields, buildingFields, sources as fieldSources } from './field-map.mjs'
const here=path.dirname(fileURLToPath(import.meta.url)), root=process.env.TRAINING_BROWSER_SOURCE_ROOT ? path.resolve(process.env.TRAINING_BROWSER_SOURCE_ROOT) : path.resolve(here,'../../../..')
const [initialPath,resultPath,outputName='replay',schedule='browser']=process.argv.slice(2)
if(!initialPath||!resultPath) throw new Error('Usage: node replay.mjs INITIAL_JSON RESULT_JSON NEW_OUTPUT_NAME [browser|native-clock-control]')
assert.ok(['browser','native-clock-control'].includes(schedule))
const output=path.join(here,outputName)
fs.mkdirSync(output)
const hash=data=>createHash('sha256').update(data).digest('hex')
const readJSON=p=>JSON.parse(fs.readFileSync(p,'utf8'))
const initial=readJSON(initialPath),native=readJSON(resultPath)
const sourcePaths=['app/live-building-entry.ts','app/live-people.ts','app/live-pathfinding.ts','app/live-movement.ts','app/training.ts','app/building-occupants.ts','app/world-turn.ts','app/person-orders.ts','app/person-order-update.ts','app/person-state.ts','app/person-motion.ts','app/person-routes.ts','app/route-advance.ts','app/object-cells.ts','app/marching-formations.ts','app/world-state.ts','app/original-rules.json','app/original-shapes.json','app/original-units.json','decomp/generated/00500a30.c','decomp/generated/004ecac0.c','decomp/generated/004ed8a0.c',...fieldSources]
const binding={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),trackedDiffSha256:hash(execFileSync('git',['diff','--binary','HEAD'],{cwd:root})),sources:sourcePaths.map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(root,p)))})),inputs:[initialPath,resultPath].map(p=>({path:path.resolve(p),sha256:hash(fs.readFileSync(p))})),node:process.version,schedule,adapter:['replay.mjs','observe-loader.mjs','field-map.mjs','compare.mjs'].map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(here,p)))}))}
fs.writeFileSync(path.join(output,'binding.json'),JSON.stringify(binding,null,2)+'\n')
const issues=[],notes=[],assertions=[]
const require=(test,label)=>{assertions.push({label,passed:!!test});if(!test)issues.push(label)}
const raw=(hex,n,label)=>{require(typeof hex==='string'&&hex.length===n*2,`${label}: ${n} captured bytes required`);return typeof hex==='string'?Buffer.from(hex,'hex'):Buffer.alloc(0)}
let people=[],building,orders=[]
try {
  require(native.sourceHead==='50aefe1d49f70057380bf9a5fa8f0b319c8ad441','native fixture source is declared comparison base')
  people=initial.people.map(p=>decodePerson(p.bytes));building=decodeBuilding(initial.building.bytes)
  for(let i=0;i<people.length;i++)for(const [k,v]of Object.entries(initial.people[i])) {
    const key=k==='cellPrev'?'cellPrevious':k
    if(key in people[i])require(JSON.stringify(people[i][key])===JSON.stringify(v),`person ${people[i].id} decoded ${key} equals native named capture`)
  }
  for(const [k,v]of Object.entries(initial.building))if(k in building)require(JSON.stringify(building[k])===JSON.stringify(v),`building decoded ${k} equals native named capture`)
  const bytes=raw(initial.orderPoolHex,8000,'command pool')
  if(bytes.length===8000)orders=Array.from({length:800},(_,i)=>({model:bytes[i*10],flags:bytes[i*10+1],references:bytes.readUInt16LE(i*10+2),object:bytes.readUInt16LE(i*10+4),a:bytes.readUInt16LE(i*10+6),b:bytes.readUInt16LE(i*10+8)}))
  require(people.length===8,'exactly eight Braves')
  require(people.every(p=>p.class===1&&p.model===2&&p.tribe===building.tribe),'eight same-tribe original model2 Braves')
  require(building.class===2&&building.model===5&&building.object===95&&building.angle===0&&building.anchorX===16384&&building.anchorY===16384,'exact Temple model5 object95 pose')
  require(building.inside===0&&people.every(p=>!(p.flags2&0x800000)),'everyone initially outside')
  const commandIds=people.map(p=>p.immediateCommand||p.commands[p.commandCursor])
  require(commandIds.every(id=>id>0)&&new Set(commandIds).size===1,'one shared nonzero command identity on all eight people')
  const command=orders[commandIds[0]]
  require(command?.model===8&&command.a===building.id&&command.references===8,'shared command8 targets Temple with eight references')
  require(initial.gameFlags&32,'native training completion disabled')
  for(const key of ['turn','gameFlags','levelFlags2','landFlags','playerTribe','randomState','poseRandom','orderCursor','orderActive'])require(Number.isInteger(initial[key]),`captured world.${key}`)
  raw(initial.terrainHex,16384*16,'terrain');raw(initial.tribesHex,4*0xc65,'tribes');raw(initial.poolHex,2000*179,'unit pool');raw(initial.classCountersHex,12,'allocation class counters');raw(initial.formationSearchHex,192,'indexed search')
  for(let i=0;i<2;i++)raw(initial.walkMasksHex?.[i],8192,`walkMask${i}`)
  raw(initial.routes?.recordsHex,401*109,'routes');raw(initial.routes?.failedSearchesHex,80,'route failed searches');raw(initial.routes?.pathResultHex,1033,'route result')
  for(const key of ['active','last','cursor','skip','computerLimit','humanLimit','computerRequests','humanRequests'])require(Number.isInteger(initial.routes?.[key]),`captured routes.${key}`)
  require(Array.isArray(initial.formations)&&!initial.formations.length,'initially no formations')
  require(initial.walkMaskPointer===0x96aaba,'native selects walk mask0 consumed by browser live path')
  require(Array.isArray(initial.allocationOrder)&&people.every(p=>initial.allocationOrder.includes(p.id)),'native allocation/list order contains each Brave')
}catch(error){issues.push(String(error.stack??error))}
const validation={status:issues.length?'blocked':'passed',issues,notes,assertions}
fs.writeFileSync(path.join(output,'initial-validation.json'),JSON.stringify(validation,null,2)+'\n')
if(issues.length){console.log(JSON.stringify({status:'blocked-before-simulation',issues,output}));process.exitCode=2}else{
  await replay()
}
async function replay(){
  const {createWorldState,addUnit}=await import(path.join(root,'app/world-state.ts'))
  const {browserPosition}=await import(path.join(root,'app/world-coordinates.ts'))
  const {buildingPose,buildingOutsidePoint,buildingInsidePoint}=await import(path.join(root,'app/building-shapes.ts'))
  const {stepBuildingEntry}=await import(path.join(root,'app/live-building-entry.ts'))
  const {stepLiveMarchingFormations}=await import(path.join(root,'app/live-movement.ts'))
  const {stepBuildingEntryClocks}=await import(path.join(root,'app/training.ts'))
  const {ageFailedRoutes}=await import(path.join(root,'app/person-routes.ts'))
  const {processTerrain}=await import(path.join(root,'app/native-terrain.ts'))
  const w=createWorldState(3),terrain=Buffer.from(initial.terrainHex,'hex'),tribes=Buffer.from(initial.tribesHex,'hex')
  // createWorldState supplies containers for consumers deliberately not visited.
  // Every decisive person/building/order/land/RNG value comes from original bytes.
  w.units=[];w.buildings=[];w.effects=[];w.trees=[];w.vehicles=[];w.shrines=[]
  w.turn=initial.turn;w.manaWorld.turn=w.turn;w.randomState=initial.randomState;w.cosmeticRandom.randomState=initial.poseRandom
  w.manaWorld.gameFlags=initial.gameFlags;w.manaWorld.playerTribe=initial.playerTribe;w.levelFlags2=initial.levelFlags2;w.land.landFlags=initial.landFlags
  w.terrainVersion=1;w.landVersion=1 // Prevent compatibility terrain from overwriting the imported native map.
  for(let i=0;i<16384;i++){const a=i*16;w.land.flags[i]=terrain.readUInt32LE(a);w.land.heights[i]=terrain.readInt16LE(a+4);w.objectCells.heads[i]=terrain.readUInt16LE(a+6);w.land.buildingIds[i]=terrain.readUInt16LE(a+8);w.land.categories[i]=terrain[a+12];w.land.cliffs[i]=terrain[a+10];w.land.shadows[i]=terrain[a+14];w.land.regions[i]=terrain[a+15]}
  if(initial.terrainQueue){const q=initial.terrainQueue;assert.equal(q.count,q.queued.length);assert.equal(q.textureUpdates.length,q.count);w.land.queued=q.queued.slice();w.land.textureUpdates=q.textureUpdates.slice();w.land.dirty.set(Buffer.from(q.dirtyHex,'hex'));w.land.attempts=q.attempts;w.land.duplicates=q.duplicates;w.land.recursing=!!q.recursing;assert.equal(q.landFlags,w.land.landFlags)}
  for(let i=0;i<2;i++)w.land.walkMasks[i].set(Buffer.from(initial.walkMasksHex[i],'hex'))
  for(let i=0;i<4;i++){const a=i*0xc65;w.manaTribes[i].playerType=tribes[a+0xc1f];w.manaTribes[i].flags2=tribes.readUInt32LE(a+0x941);w.castingTribes[i].flags=tribes.readUInt32LE(a+0x93d)}
  const globalsPath=path.join(path.dirname(initialPath),'initial-runtime-globals.bin')
  const globals=fs.readFileSync(globalsPath),offset=a=>a-0x890000
  assert.equal(globals.length,0x100000,'exact captured native runtime-global extent')
  w.pathfinding.measure={distance:globals.readInt32LE(offset(0x9557a4)),dirty:globals[offset(0x9557aa)],tribes:globals[offset(0x9557ab)]}
  assert.equal(w.pathfinding.measure.dirty,0,'this bounded replay does not run territory-cost query')
  binding.runtimeGlobals={path:path.resolve(globalsPath),sha256:hash(globals),consumed:[{address:'0x9557a4',field:'path measure distance',value:w.pathfinding.measure.distance},{address:'0x9557aa',field:'path measure dirty',value:w.pathfinding.measure.dirty},{address:'0x9557ab',field:'path measure tribes',value:w.pathfinding.measure.tribes}]}
  w.buildingOrders={records:orders,cursor:initial.orderCursor,active:initial.orderActive}
  const rr=initial.routes
  w.motionRoutes={records:Uint8Array.from(Buffer.from(rr.recordsHex,'hex')),active:rr.active,last:rr.last,cursor:rr.cursor,failedSearches:Uint8Array.from(Buffer.from(rr.failedSearchesHex,'hex')),pathResult:Uint8Array.from(Buffer.from(rr.pathResultHex,'hex'))}
  for(const k of ['skip','computerLimit','humanLimit','computerRequests','humanRequests'])w.pathfinding[k]=rr[k]
  w.pathfinding.state.checkingPerson=rr.checkingPerson??0;w.pathfinding.solver.tribeRequests=rr.requests.slice();w.indexedSearch.set(Buffer.from(initial.formationSearchHex,'hex'))
  const b={...browserPosition(building),id:building.id,team:'blue',kind:'temple',anchor:{x:building.anchorX,y:building.anchorY},object:building.object,angle:building.angle*Math.PI/1024,progress:1,hp:1,level:1,timer:building.storedMana,counter:building.counter,admission:building,damageState:null,foundation:building.h/45}
  w.buildings.push(b)
  for(const p of people){const u=addUnit(w,'blue','brave',browserPosition(p));u.id=p.id;u.hp=p.life/20;u.cargo=p.cargo/100;u.heading=Math.PI-p.angle*Math.PI/1024;u.work=b.id;u.entry={person:p,orders:w.buildingOrders};w.objectCells.objects.set(p.id,p)}
  w.selected=people.filter(p=>p.selectionFlags&128).map(p=>p.id)
  w.objectCells.objects.set(building.id,building)
  w.units.sort((a,b)=>initial.allocationOrder.indexOf(a.id)-initial.allocationOrder.indexOf(b.id))
  w.nextId=Math.max(...initial.allocationOrder)+1 // Explicit browser identity namespace; new IDs are mapped by allocation ordinal only.
  assert.deepEqual(buildingOutsidePoint(buildingPose(b)),{x:16640,y:15232})
  assert.deepEqual(buildingInsidePoint(buildingPose(b)),{x:16640,y:16448})
  const cellValidation=[]
  for(let cell=0;cell<16384;cell++)for(let id=w.objectCells.heads[cell],prev=0,seen=new Set();id;){assert(!seen.has(id),'cyclic cell');seen.add(id);const p=w.objectCells.objects.get(id);assert(p,`unknown cell identity ${id}`);assert.equal(p.cellPrevious,prev);assert.equal(((p.y>>9)*128+(p.x>>9)),cell);cellValidation.push(id);prev=id;id=p.cellNext}
  assert.deepEqual(cellValidation.slice().sort((a,b)=>a-b),initial.allocationOrder.slice().sort((a,b)=>a-b))
  const phases=[],turnVisits=[],timeline=[],admissions=[],formationAllocations=[],terrainTrace=[]
  const terrainSnapshot=()=>{const raw=Buffer.alloc(16384*12);for(let i=0;i<16384;i++){const a=i*12;raw.writeUInt32LE(w.land.flags[i],a);raw.writeInt16LE(w.land.heights[i],a+4);raw.writeUInt16LE(w.land.buildingIds[i],a+6);raw[a+8]=w.land.categories[i];raw[a+9]=w.land.cliffs[i];raw[a+10]=w.land.shadows[i];raw[a+11]=w.land.regions[i]}return {projectionSha256:hash(raw),landFlags:w.land.landFlags,count:w.land.queued.length,queued:w.land.queued.slice(),textureUpdates:w.land.textureUpdates.slice(),dirtySha256:hash(w.land.dirty),attempts:w.land.attempts,duplicates:w.land.duplicates,recursing:w.land.recursing}}
  const snapPerson=p=>structuredClone(p)
  const snapBuilding=()=>structuredClone(b.admission)
  const queue=()=>{const ids=[];for(let id=b.admission.queueHead;id;){assert(!ids.includes(id),'cyclic queue');ids.push(id);id=people.find(p=>p.id===id).reservationNext}return ids}
  const worldSnap=()=>({turn:w.turn,people:people.map(snapPerson),building:snapBuilding(),formations:structuredClone(w.marching),randomState:w.randomState,poseRandom:w.cosmeticRandom.randomState,queue:queue(),outsideEntering:people.filter(p=>p.substate===5&&!(p.flags2&0x800000)).map(p=>p.id),routes:{active:w.motionRoutes.active,last:w.motionRoutes.last,cursor:w.motionRoutes.cursor,recordsSha256:hash(w.motionRoutes.records)},orderActive:w.buildingOrders.active,orderCursor:w.buildingOrders.cursor,cellHeadsSha256:hash(w.objectCells.heads),browserNextId:w.nextId})
  globalThis.__trainingObserve=(phase,p,extra={})=>{const event={turn:w.turn,phase,person:snapPerson(p),building:snapBuilding(),randomState:w.randomState,poseRandom:w.cosmeticRandom.randomState,...extra};phases.push(event);if(phase.startsWith('admission-'))admissions.push(event)}
  const initialBrowser=worldSnap();fs.writeFileSync(path.join(output,'initial-browser.json'),JSON.stringify(initialBrowser,null,2)+'\n')
  const limit=native.timeline.length,errorBoundary=native.error?{turn:native.error.turn,phase:native.error.phase,address:native.error.eip}:null
  let error=null
  try{
    for(let turn=initial.turn+1;turn<=limit;turn++){
      w.turn=turn;w.manaWorld.turn=turn
      w.pathfinding.solver.tribeRequests.fill(0);w.pathfinding.state.searches=0;Object.assign(w.pathfinding.solver,{attempts:0,detours:0,steps:0,limited:0})
      phases.push({turn,phase:'pre-formations',world:worldSnap()});stepLiveMarchingFormations(w);phases.push({turn,phase:'post-formations',world:worldSnap()})
      const clocks=()=>{phases.push({turn,phase:'pre-building-clocks',building:snapBuilding()});b.counter=(b.counter+1)&255;stepBuildingEntryClocks(b.admission,b.counter);phases.push({turn,phase:'post-building-clocks',building:snapBuilding()})}
      if(schedule==='browser')clocks()
      for(const u of w.units){const p=u.entry?.person;if(!p)throw new Error(`Entry owner lost for ${u.id}`);const before=worldSnap(),beforeIds=w.marching.map(g=>g.id);stepBuildingEntry(w,u,b);const after=worldSnap();turnVisits.push({turn,id:u.id,before:before.people.find(p=>p.id===u.id),after:after.people.find(p=>p.id===u.id),buildingBefore:before.building,buildingAfter:after.building});for(const g of w.marching)if(!beforeIds.includes(g.id))formationAllocations.push({ordinal:formationAllocations.length+1,turn,id:g.id,members:g.members.slice()})}
      if(schedule!=='browser')clocks()
      if(initial.terrainQueue){const before=terrainSnapshot(),events=[];processTerrain(w.land,{surface:cell=>events.push(['surface',cell]),globe:cell=>events.push(['globe',cell])});terrainTrace.push({turn,before,after:terrainSnapshot(),events})}
      ageFailedRoutes(w.motionRoutes)
      timeline.push(worldSnap())
    }
  }catch(e){error=String(e.stack??e)}finally{delete globalThis.__trainingObserve}
  fs.writeFileSync(path.join(output,'binding.json'),JSON.stringify(binding,null,2)+'\n')
  const result={status:error?'blocked':native.status==='completed'?'completed-native-window':'completed-partial-native-window',binding,patchedSources,validation,initial:initialBrowser,timeline,turnVisits,phases,admissions,formationAllocations,terrainTrace,error,nativeErrorBoundary:errorBoundary,limits:['Imported synthetic native snapshot; not ordinary browser UI or rendered pixels','Production live approach/admission caller runs unchanged except read-only observation calls','Only per-turn path request reset, formation, building entry clocks and entry-person callers are scheduled; AI, health, ambient, broader building processor and other world systems omitted','Production browser building-before-person order retained unless explicitly labeled native-clock-control','Native source run excludes logical animation; this adapter also excludes animation phase','Native terrain queue is imported when captured and real browser processTerrain runs at late turn; texture surface/globe consumers are observation-only and no render equivalence is claimed','Native pool allocation not ported; initial IDs preserved, future browser formation IDs kept and require allocation-ordinal mapping','No training completion/exit or visual crossing claims','Building hp=1 is only a live-positive adapter projection from native class2/state2/nonremoved flags; native life remains in raw bytes','Browser animation stamp and alias fields are not shared byte storage; omitted animation phase and distinct alias fields remain explicit boundaries']}
  fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(result)+'\n')
  console.log(JSON.stringify({status:result.status,turns:timeline.length,admissions:admissions.filter(a=>a.phase==='admission-post').map(a=>({turn:a.turn,id:a.person.id,result:a.result})),error,output}))
}
