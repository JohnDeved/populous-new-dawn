# Issue 29 controlled browser-model adapter

Base production source: `50aefe1d49f70057380bf9a5fa8f0b319c8ad441`.
All work here is ignored diagnostic code, with no production/tracked edits.

## Scope

This adapter imports a source-bound native post-command snapshot. It executes
production `stepLiveMarchingFormations`, `stepBuildingEntryClocks`, and
`stepBuildingEntry`, including its actual movement, pathfinding, command queue,
training controller and building admission callers. It is not a full `tick`,
ordinary pointer/UI witness, rendered browser, original-game render or completion
proof. Training stays disabled (`gameFlags & 32`). No exit timing is inferred.

Primary scheduling retains the browser's building-clock-before-people ordering.
The separately named `native-clock-control` puts those same entry clocks after
people to isolate this known scheduling difference. Neither mode substitutes the
full original building processor. Original ambient/health/person/world processing
outside the browser caller remains an explicit difference, not a supplied claim
of equivalent full composition.

`observe-loader.mjs` only inserts copied observations and wraps the real exported
admission call; exact unique textual anchors fail closed if code changes. The
original and observed source hashes are recorded. No simulation expressions are
replaced. Observations include the retained counter before/after the production
route-counter assignment, per-person pre/post motion and command, and real
admission calls/return values. Source files remain untouched.

## Initial validation

`field-map.mjs` maps source-proved native 179-byte records using retained checker
offsets. Native named fields are independently compared with the raw decode.
The shared command must be nonzero, model 8, target the same Temple and have eight
references. Missing world/planner/RNG/pool/terrain inputs block simulation.
Person and building identities are retained, all initial cell head/next/previous
chains are checked, native primary person order is used, and object95/angle0
geometry is asserted as approach `(16640,15232)` and inside `(16640,16448)`.

The initial native pool and rolling class-counter bytes are retained, but the
browser does not implement that allocator. Its later formation `nextId++` identity
is preserved, requiring explicit allocation-ordinal mapping to original IDs. This
is a known adapter boundary and must not be called raw allocator equivalence.

An initial failure was caught before simulation: `attempt02` had empty person
command queues despite returning from the command producer. Its retained
`initial-rejected-attempt02/initial-validation.json` prevents treating that idle
native turn as a training comparison. The native owner corrected the missing
source tribe-list producer and ordinary state restart.

## Commands

From the worktree root, after native owner confirms its execution lane is idle:

    node work/orchestration/training-native-20261010/browser/replay.mjs NATIVE_INITIAL NATIVE_RESULT NEW_OUTPUT_NAME browser
    node work/orchestration/training-native-20261010/browser/compare.mjs NATIVE_RESULT BROWSER_RESULT

`TRAINING_BROWSER_SOURCE_ROOT` optionally selects another existing clean source
worktree for the same imported snapshot. Output stays here, and each run records
its own exact source commit and tracked-diff hash. This does not authorize any
production edit or claim the rejected counter guard is safe to merge.

Each output directory is new and immutable after generation. A run is limited to
the complete native timeline window; it will not invent a native continuation.
`comparison.json` distinguishes first person/control/counter/position/route/RNG
changes, actual admission calls, concurrent approach entrants, resident capacity,
and queue identities. Visual crossing is not measured.

## Final verified handoff

Use `final-main-attempt08/` and `final-guard-attempt08/` for final results. Their
initial validation passes and every one of48 pre/post terrain projections matches
the complete native terrain consumer. Neither person/admission timeline matches
exactly: see `findings.md` for first divergences and source-backed formation
constructor/list-lifecycle gaps. `portable-review/` is a280KB review subset with
raw-evidence hashes, source bindings, exact input records and per-turn outcomes.
It intentionally contains no original-game asset files or global RAM dump.
Full raw traces remain beside it in the ignored task directory.
