"""Export bounded synthetic-fixture review data, never original assets/global RAM."""
import json, hashlib
from pathlib import Path
base = Path(__file__).resolve().parent.parent
out = base / 'browser/portable-review'
out.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def write(name, value, compact=False):
    (out/name).write_text(json.dumps(value, indent=None if compact else 2, separators=(',', ':') if compact else None)+'\n')
ni, nr = base/'native/attempt08/initial.json', base/'native/attempt08/result.json'
i, n = read(ni), read(nr)
results = {'native': n}
for label, name in [('main', 'final-main-attempt08'), ('guard', 'final-guard-attempt08')]:
    d = base/'browser'/name
    c, r = read(d/'comparison.json'), read(d/'result.json')
    results[label] = r
    compact = {k:v for k,v in c.items() if k not in ['phases', 'endTurns', 'formationTurns', 'routeRecords']}
    compact.update(binding=r['binding'], observationSources=r['patchedSources'], validationAssertions=len(r['validation']['assertions']), rawResultSha256=sha(d/'result.json'), rawComparisonSha256=sha(d/'comparison.json'))
    write(name+'.json', compact)
summary = dict(
    sourceHead=n['sourceHead'], nativeStatus=n['status'], nativeInitialSha256=sha(ni), nativeResultSha256=sha(nr), turn=i['turn'],
    world={k:i[k] for k in ['gameFlags','landFlags','levelFlags2','playerTribe','randomState','poseRandom']},
    building=i['building'], people=i['people'], allocationOrder=i['allocationOrder'], secondaryOrder=i['secondaryOrder'],
    classCountersHex=i['classCountersHex'], formations=i['formations'], orderCursor=i['orderCursor'], orderActive=i['orderActive'],
    sharedOrderHex=i['orderPoolHex'][20:40], terrainQueue={k:v for k,v in i['terrainQueue'].items() if k!='dirtyHex'},
    inputBlobs={k:{'bytes':len(i[k])//2,'sha256':hashlib.sha256(bytes.fromhex(i[k])).hexdigest()} for k in ['terrainHex','tribesHex','poolHex','orderPoolHex','formationSearchHex']},
    routes={k:v for k,v in i['routes'].items() if not k.endswith('Hex')},
    nativeAdmissions=[{'turn':a['turn'],'id':a['person'],'result':a['result']} for a in n['admissions']],
)
write('native-input-summary.json', summary)
root = base.parents[2]
source = root/'decomp/generated/00500a30.c'
rng = dict(source='decomp/generated/00500a30.c case1', sourceSha256=sha(source),
    formula='z=(state*0x24a1+0x24df) modulo2^32; next=((z>>13)|(z<<19)) modulo2^32; timer=((z>>13)&31)+32',
    inputBrowserTurn25Rng=768717543, draws=[])
x = rng['inputBrowserTurn25Rng']
for ordinal in [1,2]:
    z = (x*0x24a1+0x24df)&0xffffffff
    x = ((z>>13)|(z<<19))&0xffffffff
    rng['draws'].append(dict(ordinal=ordinal,state=x,timer=((z>>13)&31)+32))
rng['nativeTurn25Rng'] = n['timeline'][24]['randomState']
assert x == rng['nativeTurn25Rng']
rng['matches'] = True
write('formation-rng.json', rng)
keys = ['id','counter','x','y','h','state','substate','speed','motionGroup','motionIndex','reservationNext','flags2']
slim = []
for turn in range(1,49):
    row = {'turn':turn}
    for label, result in results.items():
        t = result['timeline'][turn-1]
        row[label] = dict(rng=t['randomState'],poseRng=t['poseRandom'],
            building={k:t['building'][k] for k in ['inside','entering','entryDelay','entryTimer','queueHead','occupants']},
            people=[{k:p[k] for k in keys} for p in t['people']])
    slim.append(row)
write('turn-summary.json', slim, compact=True)
manifest = {str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.glob('*.json')) if p.name!='manifest.json'}
write('manifest.json', manifest)
print(json.dumps({'status':'exported','bytes':sum(p.stat().st_size for p in out.iterdir()),'path':str(out)}))
