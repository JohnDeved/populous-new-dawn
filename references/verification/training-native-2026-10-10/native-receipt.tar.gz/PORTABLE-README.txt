Portable bounded native admission receipt

Outcome: original CPU-only eight-Brave / one Temple composition, 48 turns, actual admissions on turns 33, 40, 43, 46, 48; five inside, three waiting. Read findings.md for explicit limits and failed setup attempts.

Repository: JohnDeved/populous-new-dawn at 50aefe1d49f70057380bf9a5fa8f0b319c8ad441.
Original executable SHA256: 3a5065c7420b3fcde208bf220bc86dfbac95e025ab2492caf9c7ea5308dfbe4f.
Python/Unicorn/Capstone exact versions, original asset paths/hashes and loader hash are in each result.json::tools/sources.

Reproduction is authorized only within the isolated original movement/training fixture. Do not launch the executable or provide OS/import/network bridges. Install the pinned Unicorn 2.1.4 and Capstone 5.0.7 in a private venv. Restore the recorded original adjacent assets and source checkout. Put the exact frozen attempt08/driver.py bytes at work/orchestration/training-native-20261010/native/native_driver.py in that checkout (the ROOT calculation assumes this depth). The driver uses the exact recorded executable absolute path; reproduce that layout or review a separate path-only wrapper/change and record its new hash. From repository root run PYTHONDONTWRITEBYTECODE=1 work/orchestration/training-native-20261010/native/venv/bin/python work/orchestration/training-native-20261010/native/native_driver.py NEW_UNIQUE_TAG. Existing output directories are refused. Never use --record. This receipt preparation does not execute the command.

All eight attempts and exact source hashes are preserved. Attempts 01-03 are failed setup attempts, not training evidence; 04-07 are explicitly superseded or controlled. The authoritative run is 08. Compare the canonical JSON SHA256 of {timeline,turnVisits,admissions}, sorted keys and compact separators, to bbfda83f9cc9f73db26224e332f163be41e3b1532d79741f77948e002c857b88.

The archive contains generated simulation snapshots and receipts, no executable/assets, no venv, no raw runtime-global binary and no static machine-code extracts. Original assets are required separately and identified by hashes. Logical animation/outer scheduling and partially inspected 0x4f0e00 remain unproved, as do training completion/exit timing and full rendered-game trajectory.
